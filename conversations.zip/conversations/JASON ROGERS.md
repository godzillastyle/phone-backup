

## CONVERSATIONS WITH JASON ROGERS

### CONVERSATION ON 07-17-2020

**Jason Rogers**: Commissioner, Jason Rogers here. When you have a moment to chat give me a ring at your convenience. 

### CONVERSATION ON 08-01-2020

**Jason Rogers**: Give me a call at your convenience. Have some information for you 

### CONVERSATION ON 08-28-2020

**Jeff Bergosh**: Hello Jason— thanks for taking the time to speak with me earlier today.  I’m hearing there is some kind of incident going on in West Escambia County with dozens of police and fire units heading that way.  Any idea what is happening?  Thanks!

**Jason Rogers**: I am just pulling in to Public Safety and I’ll go to Dispatch and get details give me just a minute

**Jeff Bergosh**: Thx

**Jason Rogers**: It’s a SO involved shooting 

**Jeff Bergosh**: Oh, okay.  Hope everyone’s alright

**Jason Rogers**: We have two incidents going on in W. Esc. One is a man hunt with shots fired and the other is an officer calling for help. 

**Jeff Bergosh**: Wow!  I hope everyone is alright! Thanks for the heads up and if you hear anything else please let me know.  Thanks!

**Jason Rogers**: Yes Sir no problem 

**Jason Rogers**: SWAT setting up, the suspect is held up in the words and Negotiations is enroute, second situation is under control and all SO officers are reportedly ok. 

**Jeff Bergosh**: That’s good that they are alright.  Hope they catch the bad guy

**Jason Rogers**: Bad guy has been shot 3 times in the abdomen, in custody and being transported to the hospital. FYI 

**Jeff Bergosh**: Thanks for heads up!

**Jason Rogers**: Yes sir, don’t forget to send me that picture for my investigative discovery as I look into the other issue 

**Jeff Bergosh**: Station 6

**Jason Rogers**: Ok thanks 

### CONVERSATION ON 08-31-2020

**Jason Rogers**: Commisioner just wanted to update you on some information. I am speaking to Janna today on the discipline issue, the investigation into the signs is ongoing but making progress, and I had a long discussion with our EMS manager about staffing. We currently have eight open positions at EMS and have a recruiting plan working with a community college paramedic program. We will be bringing it before the BCC I believe for a MOU to get their students riding with us to make a feeder program. I would like to go over the station location information with you this week sometime if you’re available so you can see the data pre meeting.  As always feel free to call anytime. Have a good day.

**Jeff Bergosh**: Thank you Jason I greatly appreciate that.  Do u have a moment to talk?

**Jason Rogers**: Yes sir 

### CONVERSATION ON 09-08-2020

**Jeff Bergosh**: Jason, can you please call Mr. Doug Ard at 850-490-0688?  He’s building a house over near Paradise Beach and he’s concerned about the ISO rating and has some information about the support agreement with Lillian Volunteer Fire Department

**Jason Rogers**: Yes Sir, do I need to call him tonight or is tomorrow ok?

**Jeff Bergosh**: Tomorrow is fine thanks

**Jason Rogers**: No problem, I’ll give you a call tomorrow to follow up

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-09-2020

**Jason Rogers**: Spoke with Mr. Ard I will be following up with him as well.  I completely understand his situation and I am sympathetic. I’m going to meet with Cassie to see how likely it is we get this temporary station up this year. i’ll keep you posted as well. 

**Jeff Bergosh**: Thanks

### CONVERSATION ON 09-11-2020

**Jason Rogers**: When you have a moment to talk I have a few things to run by you

**Jason Rogers**: Dispatch is running the numbers now for both EMS & Fire responses to the ER 

**Jeff Bergosh**: Thx

**Jason Rogers**: Emailed 

**Jeff Bergosh**: Thx

### CONVERSATION ON 10-29-2020

**Jason Rogers**: Just to keep you updated, I have multiple things to report out later today. I have Williams and a BC in the office with another commissioner to answer questions on the call audio. I’m asking for a audio file on a thumb drive.

**Jeff Bergosh**: Okay thx for heads up

### CONVERSATION ON 11-05-2020

**Jeff Bergosh**: Hey Jason thanks for putting together those files on the jump drive. I was unable to open it and listen to it with any of the programs that I have on my computer so appreciate you putting it together for me but I’ll have to find a different way to listen to it I guess.

**Jason Rogers**: Ok let me ask if the player is downloadable and I’ll get back to you 

