

## CONVERSATIONS WITH DC REEVES

### CONVERSATION ON 07-15-2020

**DC Reeves**: Hey Jeff it’s DC - exciting meeting today haha... wondered if you had some time to chat about TDT next week? Wanted to get your thoughts. Let me know

**Jeff Bergosh**: Yeah Doug always makes it interesting with his BS comments.  Sure we can chat, just give me a call in the afternoons any time.  Hope all is well!

**DC Reeves**: Great! Thanks man! Hanging in there at the brewery! Or trying!

**Jeff Bergosh**: I hear ya.  Tough time to be in hospitality business.

Hold fast— this too shall pass!!

**DC Reeves**: We have plenty to drink our sorrows away in the meantime! I’ll give you a shout next week

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-17-2020

**DC Reeves**: Hey - don’t you think it would be wise to begin sports but push back the start of school to after Labor Day? Buy us a few weeks to stop the surge?

**DC Reeves**: I’ve seen a modified schedule where that’s not really impactful to much to do so.

**Jeff Bergosh**: I’d say skip the fall semester all together.  This things moving fast— like a train

**Jeff Bergosh**: And I’m not buying the BS from Lanza that 16,17,and 18 year olds can ride on crowded buses with no masks and this will be fine——but if 18 and 19 year old college students party at spring break together —- that’s “Dangerous”.  Both are dangerous—or neither are

**DC Reeves**: Right 

**DC Reeves**: I’m trying to get people (hospitals etc) lined up before Monday’s school board meeting

**DC Reeves**: Malcolm won’t give a shit what I think but if hospital officials say it’s a good idea to delay 3 weeks he’ll have to do it

**Jeff Bergosh**: He’s pretty stubborn but I hope he will listen

**Jeff Bergosh**: Not till this shit passes

**DC Reeves**: Lumon is talking to Lanza about it - I Called Faulkner and Will Condon 

**DC Reeves**: But time is of the essence because of the board meeting Monday

**DC Reeves**: We need Lanza to be on board with it I think

### CONVERSATION ON 08-11-2020

**Jeff Bergosh**: Hey DC— just making sure you got the meeting credentials for tomorrow morning’s coffee with the commissioner event.  Looking forward to it!  Let me know you got them and you’re good to go for tomorrow morning at 6:30– we’ll see you then!

**DC Reeves**: Yep! All good thanks!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2020

**DC Reeves**: Congrats Jeff!

**Jeff Bergosh**: Thanks DC!!

### CONVERSATION ON 03-13-2021

**Jeff Bergosh**: LOL

