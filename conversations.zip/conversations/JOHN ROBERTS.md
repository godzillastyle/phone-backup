

## CONVERSATIONS WITH JOHN ROBERTS

### CONVERSATION ON 01-13-2020

**Jeff Bergosh**: Hello John and happy new year. I’m just touching base to see if we have a committee meeting this evening? I could not find anything online or on the Facebook page but I’m assuming we will have one tonight 630 at the library is that correct? Thanks

Jeff Bergosh

**Jeff Bergosh**: Thanks

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: On way back down now

**Jeff Bergosh**: You and the residents deserve this project and that’s why I led the board in a turnaround and a unanimous approval.  But this D2 commissioner didn’t and doesn’t rate the level of support I gave him today due to his continuing machinations that have poisoned the board.  Had it not been for you John, I would very likely NOT led the board in approving this today.  Your advocacy and appearance today helped save this project.

**Jeff Bergosh**: 👍

