

## CONVERSATIONS WITH GARY CRAWLEY

### CONVERSATION ON 12-20-2020

**Jeff Bergosh**: Hi Gary this is Jeff Bergosh. Sally  and I have discussed it and we have decided upon a color for the kitchen walls. It’s Behr Ivory lace.  Thanks very much.

**Gary Crawley**: Perfect. 

**Gary Crawley**: Enjoy your trip 

### CONVERSATION ON 12-21-2020

**Jeff Bergosh**: Thank you Gary!  Merry Christmas to you and your family

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: 👍

**Gary Crawley**: Glad you like it 

### CONVERSATION ON 01-29-2021

**Gary Crawley**: Perfect. 

### CONVERSATION ON 02-02-2021

**Jeff Bergosh**: Outstanding!!  Thanks Danny!

**Gary Crawley**: Nice work 

### CONVERSATION ON 02-05-2021

**Gary Crawley**: Good morning everyone. Just a quick update. The remaining 5 Upper cabinets will be installed on Monday. Original plan was to install tomorrow afternoon-however I was gently reminded that tomorrow is our sons birthday and we have dinner plans with him on Saturday. So I need to push to Monday. The electricians can then come and complete all the lighting. Base cabinets will be in by Tuesday the 16th. Superior Granite is scheduled for the 17th to measure and get the countertops completed. I'll send some pictures later today of your cabinets in the shop you may enjoy. Let me know if you have any questions/concerns. Thanks. 

### CONVERSATION ON 02-24-2021

**Jeff Bergosh**: Hey Danny hey Gary-- I really really like the way the kitchen is coming together thank you so much for all your hard work! Next Tuesday Superior Granite is going to install the quartz countertops I just want to make sure that we are all on the same page in terms of the sink and where the faucet goes in relation to the sink: SALLY and I both want to make sure the faucet is centered on the sink not to the right as it is currently temporarily installed. We definitely want it centered with the actuator on the right of the faucet   Please let me know that we are going to do it this way thanks a lot guys!

**Gary Crawley**: Glad you are happy with it. Yes we confirmed with Superior to cut the stone so that the faucet is centered. Have a great day 

### CONVERSATION ON 03-05-2021

**Gary Crawley**: Doors.   Doors.  Doors

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-11-2021

**Gary Crawley**: Jeff. If you can provide me your email address I will send you an updated invoice. I’m showing $6214.42 including tax and upgrades/add one

**Jeff Bergosh**: Jeffbergosh@gmail.com

**Jeff Bergosh**: Thanks Gary!

### CONVERSATION ON 03-15-2021

**Gary Crawley**: Would it be ok if I bring my wife tonight and she take some professional pictures of the kitchen?

**Jeff Bergosh**: Absolutely!

**Gary Crawley**: Thanks. See you tonight around 7. Enjoy the rest of your day

**Jeff Bergosh**: Thanks Gary— you too!  

### CONVERSATION ON 04-18-2021

**Jeff Bergosh**: Hello Gary, it’s Jeff Bergosh, I’m picking up my door right now and was wondering if I can drop it by your shop?

**Gary Crawley**: Sure. 613 Copper Ridge Drive 

**Gary Crawley**: I’m in the shop now 

**Jeff Bergosh**: Okay thx I’ll bring it by👍

**Jeff Bergosh**: On way 

### CONVERSATION ON 05-03-2021

**Gary Crawley**: Now that your floors are done I can look to deliver and install your door and bench. Looks like Friday is the first day I have open and the weather looks good that day. Does Friday work for you?

**Jeff Bergosh**: Sure does.  Danny has the key if you can grab it from him, although my kids will probably be there if you’re planning on coming in the morning.  Thanks Gary!

### CONVERSATION ON 05-06-2021

**Gary Crawley**: As you know last week I hurt my back. Much better now but unfortunately now Danny has hurt himself. Nothing major but between the two injuries it has really slowed us down and we are way behind schedule. With that said I really need to push everything back about a week. That would put me delivering and installing your door and bench to next Friday or Saturday. We will be working this weekend to try and catch up some and will try and make it sooner if we can. I hope you understand and I sincerely apologize for the delay and inconvenience. Thanks

**Jeff Bergosh**: Okay thx for the heads up

### CONVERSATION ON 05-14-2021

**Jeff Bergosh**: Are you all coming by today for the door and bench install?  Or is tomorrow looking better?  Hope you all are all healed up!

Jeff B

**Gary Crawley**: Will be heading your way in a few minutes. Finishing up here in about 30 minutes or so and then will load and head your way 

**Jeff Bergosh**: Awesome thanks Gary!

**Gary Crawley**: There you go. I hope you enjoy. The lid stays in the up position for storage in and out. You need to hold onto it to close. Too big and heavy for soft close hinges 

**Jeff Bergosh**: Wow!  Nice.  It’s bigger than I thought as well!

**Jeff Bergosh**: How’s the door looking?

**Gary Crawley**: Good

**Gary Crawley**: Did you not get any door pictures?

**Jeff Bergosh**: Oh my gosh—- I did.  Thanks—— just didn’t see them

**Jeff Bergosh**: Question though— we bought a handle for that door did you all not see it?  It’s inside the pantry on the right near the floor

**Gary Crawley**: No I didn’t see it

**Gary Crawley**: Do you want me to replace it 

**Jeff Bergosh**: Did you find it?  If so yes that would be great.  Sorry I didn’t remind you all about it beforehand

**Jeff Bergosh**: It’s a nice one that goes well with the decor

**Gary Crawley**: Okay I will change it out. Maybe you can find a use for the other one 

**Gary Crawley**: Old knob and the one I had put on are on your bench 

**Jeff Bergosh**: Awesome!!  Thank you Gary!!

**Gary Crawley**: You’re welcome.

