

## CONVERSATIONS WITH MOM MARSH

### CONVERSATION ON 11-18-2019

**MOM Marsh**: November 30 Saturday is the multi-birthdays celebration at 5 PM and 100% can com:
Everyone is available at 5 pm Saturday November 30th!!! Whew! Now what do we do? There is a 7 PM performance of “Matilda, The Musical” a family comedy at Horton Plaza Theatre. Restaurants everywhere or we could do dinner at 5 at our house or movie or bowling or roller skating or hot chocolate, ice-skating and see the tree at the Hotel Del or dinner and game night at our house or Christmas Caroling at a rest home or dinner at Corvette Diner or ???

### CONVERSATION ON 11-25-2019

**MOM Marsh**: Saint Nicholas phoned us last night before dark about 3:45 and we talked for an hour😁👏

**MOM Marsh**: Yes indeed!!!

### CONVERSATION ON 11-30-2019

**MOM Marsh**: Is Your family going to watch the Civil War game between the University of Oregon ducks and the Oregon State beavers today at 3 o’clock your time 1 o’clock our time today Saturday love you bye

**Jeff Bergosh**: Around here the world stops, traffic comes to a halt, there are no Cars on the road, there are no people on the streets, there is nobody shopping at Walmart—-and no phones get answered when the Alabama Crimson Tide plays Auburn in the iron bowl.

**MOM Marsh**: The Ducks just won 24-10!!!10 go decks 24 to 10 skews me 24 to 10 the ducks won why is it showing it

### CONVERSATION ON 12-01-2019

**MOM Marsh**: Please ask Sally to call us on the home phone!!!🤪

**Jeff Bergosh**: Okay will do—she’s at choir practice right now but I’ll have her call when she gets back

**MOM Marsh**: Thank you 😊 

### CONVERSATION ON 12-05-2019

**MOM Marsh**: Patti and Tom Wilser are coming to our house for Christmas Morning 10 AM and ret:
Patti and Tom Wilser are arriving in SD on SWAirlines at 10 AM on December 25 and returning December 28!!! I am so excited!!!

### CONVERSATION ON 12-16-2019

**MOM Marsh**: So proud of you 🙏🥰😁

**Jeff Bergosh**: Way to go!

### CONVERSATION ON 02-11-2020

**MOM Marsh**: Your not just woofing young man, part of the deal

**MOM Marsh**: 🤪

**MOM Marsh**: 😆 

### CONVERSATION ON 02-12-2020

**MOM Marsh**: 11 pm Tuesday 

**MOM Marsh**: OK! OK! 

**MOM Marsh**: Pun🤪

### CONVERSATION ON 02-13-2020

**MOM Marsh**: Stay tuned young man

**MOM Marsh**: I have two months to get well and healthy and that is my intention! We fully plan to take the boys to Europe April 3-19!

### CONVERSATION ON 02-14-2020

**MOM Marsh**: Lahaina it's in Maui we are in Waikiki which is in !
Oahu

### CONVERSATION ON 02-15-2020

**MOM Marsh**: A ToastMaster installation photo in boppa'sTibet hat

### CONVERSATION ON 04-01-2020

**MOM Marsh**: So good 😊 

### CONVERSATION ON 04-08-2020

**MOM Marsh**: Click https://us04web.zoom.us/j/9852632189?pwd=WThkVnBLNkNKUytVQlFrNklGZTI2Zz09 to join a Zoom meeting

### CONVERSATION ON 04-09-2020

**MOM Marsh**: https://youtu.be/D8tW85BArw4

**MOM Marsh**: Short message from JEREMY McGarrity

**MOM Marsh**: Matthew made this a few days ago 🥰

**MOM Marsh**: Farmer Boppa’s Garden🥰

### CONVERSATION ON 04-10-2020

**MOM Marsh**: No

### CONVERSATION ON 04-12-2020

**Jeff Bergosh**: Happy Easter!!

### CONVERSATION ON 04-18-2020

**MOM Marsh**: Almost 20 now!

**MOM Marsh**: Yes 

**MOM Marsh**: What?

**MOM Marsh**: When?

### CONVERSATION ON 06-01-2020

**MOM Marsh**: What image?

**MOM Marsh**: Dylan got back together with Dominique from high school. They are in love...

### CONVERSATION ON 06-02-2020

**MOM Marsh**: Very applicable for today!

### CONVERSATION ON 06-03-2020

**MOM Marsh**: Happy Anniversary to you today!

**Jeff Bergosh**: Thank you!!!

**Jeff Bergosh**: We celebrated on Sunday ❤️👍

### CONVERSATION ON 06-22-2020

**MOM Marsh**: Father’s Day 2020

**MOM Marsh**: Gifts from Martha and Kathy!😋🥰

**MOM Marsh**: We had 16 at our party!

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: Sure

### CONVERSATION ON 08-18-2020

**MOM Marsh**: Congratulations! You won by a lot!!!

**Jeff Bergosh**: Love you!!!  We won it!   It’s official!!!!

### CONVERSATION ON 08-19-2020

**MOM Marsh**: Congratulations! Drive safely to Milwaukee and give Nicholas a hug from Grandma! 🥰🙏🏻😃💕👌

**Jeff Bergosh**: I will and thank you!  We love and miss you all!!  Stay safe and hopefully we will all be together for Christmas!

**MOM Marsh**: Amen!!! Hallelujah!!! That would be awesome!!!

### CONVERSATION ON 08-20-2020

**MOM Marsh**: ETA?

**Jeff Bergosh**: We’re here😎👍

**MOM Marsh**: Wahoo!!!

### CONVERSATION ON 08-21-2020

**MOM Marsh**: How is your room?

**Jeff Bergosh**: It’s really nice!

**MOM Marsh**: Did You receive a bottle of champagne and a flower bouquet bouquet of flowers upon arrival in your room and a note that said love congratulations and love from mom and dad Marsh?

**MOM Marsh**: They charged our Visa!

**Jeff Bergosh**: No not yet but we’ve been gone all day on a fishing boat.  Thank you!!

**MOM Marsh**: Wow Brandon caught it?

**Jeff Bergosh**: Yes— Lake Trout!

**MOM Marsh**: Fantastic way to go Brandon!

**Jeff Bergosh**: Sally and Nick just teamed up to catch a nice Lake Trout!

**MOM Marsh**: Congratulations Nicholas and Sally!

**MOM Marsh**: I have never tried to catch a fish!

**Jeff Bergosh**: You would have had a blast!!

**Jeff Bergosh**: Thank you so much!!!! So thoughtful!!!!

**MOM Marsh**: Congratulations!!!

**Jeff Bergosh**: Thank you!!!!!

**Jeff Bergosh**: How thoughtful!  We LOVE it

**MOM Marsh**: Great 🥰👌

**MOM Marsh**: Out to dinner 🥰😎😃

**Jeff Bergosh**: Yep!  We r Taking the kids to one of the better steak houses here in town

**MOM Marsh**: Fun memories being made!!!

### CONVERSATION ON 08-24-2020

**MOM Marsh**: Travel mercies!!!

**MOM Marsh**: 4 drivers in your vehicle!

### CONVERSATION ON 12-29-2020

**MOM Marsh**: Did you all have lunch? 

### CONVERSATION ON 01-15-2021

**MOM Marsh**: Found this in Cadillac? What is it?

**Jeff Bergosh**: LOL I’ve been looking for that.  It’s a music player-external speaker

### CONVERSATION ON 05-08-2021

**MOM Marsh**: Thank you so much for your gift of this gorgeous flower arrangement!!!

**MOM Marsh**: Yea.   Gorgeous.   And nice too
Love to you Sam.          Dad

**MOM Marsh**: We doesn’t to come to visit you all!!!

**MOM Marsh**: We do want to 

**MOM Marsh**: Autocorrect 🤪

**MOM Marsh**: Aren’t August and September your hottest months?

**MOM Marsh**: I mean temperature!!!

### CONVERSATION ON 12-21-2021

**Jeff Bergosh**: Here’s our flight info— look forward to seeing you all in two days!!

**MOM Marsh**: Airline????

**Jeff Bergosh**: Southwest

**MOM Marsh**: Thank you 

