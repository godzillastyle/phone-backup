

## CONVERSATIONS WITH LINDA WEST

### CONVERSATION ON 04-15-2020

**Jeff Bergosh**: Thank you Linda—stay safe!

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: You 

