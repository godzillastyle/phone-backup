

## CONVERSATIONS WITH DANNY ZIMMERN

### CONVERSATION ON 10-24-2019

**Jeff Bergosh**: Hey Danny just want to let you know I spoke to Paula in accounting and no issues at all the whole thing is squared away. It appears that Maguire and Jim Reeves split the balance that was left after what I paid. So I just wanted to let you know that it's all good thanks and have a good weekend!

**Danny Zimmern**: 👍

### CONVERSATION ON 12-26-2019

**Jeff Bergosh**: Hey Danny hope the holidays are treating you well hope all is going good. This came back to me this week which was kind of surprising. I sent it to you in October in thanks for all your help in my campaign Fundraiser.Anyway I wanted you to know that I had sent it out and that it wasn't delivered and I want you to know how much I appreciated all your help!  The US post office strikes again!

**Danny Zimmern**: Thanks Jeff!  Keep charging ahead!

### CONVERSATION ON 01-02-2020

**Danny Zimmern**: Did you ever get my email? You and your lovely bride need to be at Seville quarter by about 5:45 Saturday evening.

### CONVERSATION ON 01-03-2020

**Jeff Bergosh**: Danny you can count SALLY and I in for this----thank you so much for the generous invitation. What is the dress attire ??

**Danny Zimmern**: Whatever you feel comfortable with. Jeans and a sport coat probably for the commissioner

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-04-2020

**Jeff Bergosh**: Hey Danny- we are on way there.  Any chance of me purchasing two extra wristbands for my son who is visiting from college in Milwaukee and for my daughter?

**Danny Zimmern**: I'd have to handle getting them in and Iwont be there til like 6:30

**Jeff Bergosh**: Ok thanks 

### CONVERSATION ON 01-14-2020

**Danny Zimmern**: Any interest in coming tonight?

**Jeff Bergosh**: I have a pre-existing commitment to speak at the South Gulf Manor Yearly Home Owner's Association Meeting at 6:00 so I can't make it.  Thanks for the invite Danny!  I know Michelle is going to kill it tonight though--that's quite a host list!

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Danny---I wanted to let you know that I just got my latest poll results back from Gravis.  I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary by 30 points!  Thought you might like to know that 

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Danny!

**Danny Zimmern**: Awesome Jeff!  

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Salzman's numbers have narrowed as well in my poll..... 53-47. Mike is down to a 6-point lead

**Danny Zimmern**: Perfect!  

**Danny Zimmern**: I talked w her.  She is thrilled.

**Danny Zimmern**: and working hard

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2020

**Danny Zimmern**: Wheres victory celebration?

**Jeff Bergosh**: Low key at the house tonight.  LOL

**Jeff Bergosh**: Close election

**Danny Zimmern**: You should be fine and rightfully so.  Go Jeff Go!

**Danny Zimmern**: Nice.   Congratulations!

**Jeff Bergosh**: Thanks Danny!

### CONVERSATION ON 09-16-2020

**Danny Zimmern**: Can you call for a 2 minute call?

**Jeff Bergosh**: Yes

**Danny Zimmern**: Calling now

### CONVERSATION ON 09-17-2020

**Danny Zimmern**: Any luck on Ash B?  Sounds like Cody wants it all.

**Jeff Bergosh**: He's not on the list I saw

**Jeff Bergosh**: Is it a different name maybe?

**Danny Zimmern**: Our friend wants Ash Britt (North of I-10)  Cody has partnered (for political help) with I think Ceres, a company without Florida connections 

**Danny Zimmern**: Was AB on list of finalists?

**Jeff Bergosh**: Didn't see it

**Danny Zimmern**: Lets help a brother if we can

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Danny what is the attire tonight? Business casual? Or full on casual shorts and a polo with a hat? Thanks a lot and I'm looking forward to it!!

Jeff Bergosh

**Danny Zimmern**: full on casual

**Jeff Bergosh**: 👍. Thx!

