

## CONVERSATIONS WITH BILL CROSS

### CONVERSATION ON 05-18-2020

**Bill Cross**: https://podcasts.apple.com/us/podcast/things-police-see-first-hand-accounts/id1384355891?i=1000470634529

**Bill Cross**: Here is the podcast that I told you about. My son telling some of his experiences as a K9 Officer.

**Jeff Bergosh**: Cool Bill!  I’ll check it out— thanks for sharing!

**Bill Cross**: I thought I sent it to your brother. I am the village idiot when it comes to technology. Let me know what you think after you listen to the podcast.
On another note how can I get a sign for my yard?

**Jeff Bergosh**: Thanks Bill!  I’ll bring one today—just tell me the address—-and thank you!!

### CONVERSATION ON 05-22-2020

**Bill Cross**: My address is 7983 Beulah Rd. Sorry I am so late getting back to you.

**Bill Cross**: My house is 500 feet off the road.

**Jeff Bergosh**: Awesome— I’ll put one there.  Needed one on Beulah road so thank you Bill!

**Bill Cross**: No problem, I hope you have a great Memorial Day Weekend.

**Jeff Bergosh**: You as well Bill!

**Bill Cross**: I’m driving with Do Not Disturb While Driving turned on. I’ll see your message when I get where I’m going.

**Bill Cross**: (I’m not receiving notifications. If this is urgent, reply “urgent” to send a notification through with your original message.)

### CONVERSATION ON 05-23-2020

**Bill Cross**: After you listen to my son’s podcast can you send it to Gary? Thx

**Jeff Bergosh**: Will do it Bill

**Bill Cross**: Thank you.

