

## CONVERSATIONS WITH JAY INGWELL

### CONVERSATION ON 12-06-2019

**Jay Ingwell**: GREAT interview on FOX!

**Jeff Bergosh**: Thanks Jay!

**Jeff Bergosh**: Very proud of Our first responders today—-heroic!

**Jay Ingwell**: Yes they are!

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: Since Ira will be out of the office--please take your completed job packages directly to Heather once completed 

Thanks

Jeff 

### CONVERSATION ON 08-06-2020

**Jay Ingwell**: Great job during the debate.  Not even close between you and Mr. Owens.  Where was Jesse?  Saw him earlier that day waving.

**Jeff Bergosh**: Thank you Jay!  Jesse doesn’t do any forums he’s blown off the last two.  He also doesn’t fill out the surveys because he’s uneducated and incapable of doing it intelligently.  He is my big competition which is crazy

**Jay Ingwell**: I’d like to pick your brain regarding impact fees.  After your victory.

**Jeff Bergosh**: We will do that!  12 days

**Jay Ingwell**: 👍 

### CONVERSATION ON 08-18-2020

**Jay Ingwell**: Congratulations Jeff!

**Jeff Bergosh**: Thanks Jay!!

### CONVERSATION ON 09-16-2020

**Jay Ingwell**: Jeff hoping you and your family weathered the storm ok.  Good on this end.  Reaching out on behalf of the HOA due to a potential FDEP / EPA issue in the form of a sewage spill.  Have 4' to go until flow-over into the county retention pond.  A contract has been signed with a management co and they had a plumbing resource coming out this week to prep for the generator but things have changed due to the storm.  Can you assist in rectifying the issue.  Either a pump out or power restoration.  I'm literally and physically low man in the neighborhood.

**Jeff Bergosh**: Hi Jay thanks we are okay over here I will call and see what we can do.  Isn't it the developer that's maintaining that lift station for you all now?

**Jeff Bergosh**: Hi Jay thanks we are okay over here I will call and see what we can do.  Isn't it the developer that's maintaining that lift station for you all now?

**Jay Ingwell**: No we had to settle and take responsibility for it.  We appreciate whatever you can do.  Goal is to get it pumped out and have been calling companies. 

### CONVERSATION ON 09-18-2020

**Jay Ingwell**: Thanks for calling, we were able to get the lift station pumped out. We appreciate you being there.  On an unrelated note, Perdido Key Drive has a major issue with safety.  Since this is a county road their Commish needs to take action.    Power poles with lines attached are down on the East bound lane and are not very visible.  Saw a vehicle strike one just before curfew last night.  We knew they were there having just driven West bound.  On our return we were following a vehicle coming from Orange Beach, obviously oblivious to the poles and lines sitting 3 feet off the deck.  No warnings no nothing.  We can discuss at your convenience.   I know you have a ton going on and I appreciate your dedication.

**Jay Ingwell**: Looking south near Ocean Breeze West

### CONVERSATION ON 12-24-2020

**Jay Ingwell**: Merry Christmas to you and the family.  Two items: 1- when will final debris pickup occur, I’ve got two trees worth staged (since Thanksgiving) next to road by the retention pond.  We’re on a cul de sac so may have been missed.
2- would like to speak with you about a MSBU for our lift station. Lawsuit has been settled.

Thanks for everything.  I know you are extremely busy with two full time jobs.

**Jeff Bergosh**: Hi Jay!  Merry Christmas to you all as well.  Text me your address and I will send the debris removal request to our haulers.  About the MSBU— we can discuss it when I get back to Pensacola and I’ll assist however I can.

**Jay Ingwell**: Thanks Jeff.  Address 8079 Thoroughbred Road Pensacola 32526

**Jeff Bergosh**: Got it Jay.  They are off today and tomorrow but I’ll get this sent over so it can be worked next week.

**Jay Ingwell**: Thank you so much and sorry to bother you so close to Christmas.

**Jeff Bergosh**: No worries at all Jay you’re not bothering me!

### CONVERSATION ON 12-28-2020

**Jay Ingwell**: Thank you Jeff, debris was picked up today.

**Jeff Bergosh**: Glad they got that taken care of!!

**Jay Ingwell**: Hopefully all of County is taken care of.

### CONVERSATION ON 04-30-2021

**Jay Ingwell**: Good morning Jeff, could I call you today to run an idea past you?

**Jeff Bergosh**: Sure.  Anytime Jay!

**Jay Ingwell**: ~ 30 min

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-03-2021

**Jay Ingwell**: Jeff thank you for the recognition tonight.  It is appreciated but not necessary.  I enjoy doing what I can to make the County a better place, as I know you do as well.

**Jeff Bergosh**: Thanks Jay, for all you do!

### CONVERSATION ON 12-11-2021

**Jay Ingwell**: Can I give you a call?

**Jeff Bergosh**: Sure

**Jay Ingwell**: Our address is 8079 Thoroughbred Road.  Lot is to south of me.

**Jeff Bergosh**: I’m all over it

**Jay Ingwell**: We appreciate it Jeff.  One other note the county needs to verify the proper inspections have taken place, primarily the footers.  We had a variance request a few months ago due to footers not meeting set back requirements.  The county inspector missed it.  Again thanks.

**Jeff Bergosh**: Will request that as well.  Composing the email as I type this

**Jay Ingwell**: Thank you Jeff.  Enjoy the rest of your weekend.

**Jeff Bergosh**: You too.  BTW— I’m BCCing you and Dawnmarie on what I’m pressing the send button on rn

**Jay Ingwell**: Thank you.

### CONVERSATION ON 12-15-2021

**Jeff Bergosh**: Andrew I'm on the line but can't hear anything, are you all on the call?

**Jay Ingwell**: Jeff have you heard anything from staff?    They have workers out there today.

**Jeff Bergosh**: Yes I have.  Horace called Monday and they are going back through all the paperwork to check what inspections have been done and whether or not this work is being constructed as permitted.  I’m waiting for their response

**Jay Ingwell**: Thank you Jeff.  Our HOA manager is supposedly issuing a cease and desist due to the plans not being approved by the HOA for development standards, ascetics and neighborhood conformity.   

**Jay Ingwell**: Should we notify the county so that no more work can commence on site?

**Jeff Bergosh**: I’m not sure if we can shut them down until we have a definitive determination back from Engineering Jay

**Jay Ingwell**: I appreciate it.  I’ll get the HOA to post the cease and desist.

