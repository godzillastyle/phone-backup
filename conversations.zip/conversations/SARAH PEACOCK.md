

## CONVERSATIONS WITH SARAH PEACOCK

### CONVERSATION ON 10-16-2020

**Jeff Bergosh**: FYI Sarah... County staff will have this operational before class starts today.  Thanks for pushing, and bringing it to my attention.  have a great weekend!

Jeff Bergosh

