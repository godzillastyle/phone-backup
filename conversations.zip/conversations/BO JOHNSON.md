

## CONVERSATIONS WITH BO JOHNSON

### CONVERSATION ON 06-21-2021

**Jeff Bergosh**: Hey Bo I’ve had several people reach out to me about that and it was my understanding that it was going to be contracted through the purchasing office with an open solicitation. But I don’t know if that ever happened with all the turnover in staff that we have had. So I will check on that and get back to you on what the latest status is. I don’t believe there’s a selectee as of yet I think it will be an open process. I hope all is well.

**Jeff Bergosh**: Thanks Bo!  It was a great weekend despite the weather.  Take care!

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: Thanks Bo— and I do believe it will.  ROW acquisition is in the 5 year work plan and this project is the county’s number one priority at TPO so it’s definitely a contender for a federal money dump!

