

## CONVERSATIONS WITH DEBBIE BOWERS

### CONVERSATION ON 09-19-2020

**Debbie Bowers**: Still working on it but I may have just found 1000 hot meals but need confirmation 

**Debbie Bowers**: LVM, 1,000 meals at 4:45 p.m.

**Jeff Bergosh**: Thank you!

### CONVERSATION ON 09-21-2020

**Debbie Bowers**: I'm not sure if we talked after a message you left me, which I just saw. Salvation Army was at the Equestrian Center today at noon serving lunch. I apologize for getting back to you so late.

### CONVERSATION ON 10-09-2020

**Debbie Bowers**: My apologies for the late notice. A white male, 5'7", 145 lb, black hair, brown eyes, escaped from a road crew working at the park on Bauer Rd this morning around 8 a.m. this morning, most recent sighting around 1:30. Will keep you posted. Debbie 

**Debbie Bowers**: 27 years old

**Jeff Bergosh**: Thx

**Debbie Bowers**: Correction - escaped around 10:30 a.m. this morning 

**Debbie Bowers**: He was just captured.

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-05-2020

**Debbie Bowers**: ECSO and Corrections are currently searching for an inmate who was inadvertently released from jail. He had the same last name of an inmate who was supposed to be released. He is considered dangerous but is not known to be armed.  Will notify you when he is apprehended.

**Jeff Bergosh**: Okay thanks

### CONVERSATION ON 12-06-2020

**Debbie Bowers**: He is back in custody. 

### CONVERSATION ON 12-07-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-29-2020

**Jeff Bergosh**: Hi Debbie-- I have some questions about the $3,5 Million Dollar agreement with Ascension Sacred Heart.  Can you call me at your earliest convenience so we can discuss?   Thanks!!

### CONVERSATION ON 01-07-2021

**Debbie Bowers**: Not that it matters, excep you're on TV, but you're sitting right in front of D2 name plaque. Just thought you might want to know 

**Jeff Bergosh**: Oh my gosh-- can someone please fix that??

**Jeff Bergosh**: Ever

**Debbie Bowers**: Sharon is going to come up after he stops speak

**Jeff Bergosh**: Thx

**Debbie Bowers**: Clause 3, 2nd paragraph, last line, always uninsured

**Jeff Bergosh**: That's what I thought

### CONVERSATION ON 02-15-2021

**Debbie Bowers**: Commissioner, due to icy conditions through noon tomorrow, we are closing the County offices except for essential personnel. Please call me or Eric with any questions. 

**Jeff Bergosh**: Okay thanks for the heads up

### CONVERSATION ON 03-13-2021

**Debbie Bowers**: Hi, there were 1-3 armed men at NAS, ECSO took them in custody without incident.  Public Safety staged 4 ambulances and fire apparatus in preparation for any outcome. Everyone has stood down with incident over.

**Debbie Bowers**: Good news, Honor Guard spotted with rifle, 9-1-1 called, Public Safety and ECSO responded accordingly. No true incident. 

**Jeff Bergosh**: Thanks for update

### CONVERSATION ON 03-17-2021

**Debbie Bowers**: Hi, in preparation for potential storms tonight, we have additional staffing on the north end, including day shift at Century staying on duty through night and additional ambulance and QRV. All personnel including volunteers are on notice for call in for any emergency. 

### CONVERSATION ON 07-16-2021

**Debbie Bowers**:  Matt is comfortable we have time because we can do extensions if need be, at least for a year or so.

**Jeff Bergosh**: Okay great thank you Debbie!

### CONVERSATION ON 08-25-2021

**Debbie Bowers**: Hi, not too be blonde, but is our meeting this afternoon at your County office here?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: LOL

**Debbie Bowers**: Thanks

