

## CONVERSATIONS WITH BOBBY BONSIGNORE

### CONVERSATION ON 09-07-2020

**Jeff Bergosh**: Thanks Bobby!  Great to see you all as well!  I hope you all had a great Labor Day weekend!

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: Hey Bobby-  I hope you and the family are okay.  Stay safe and I’ll be praying for you all and your new condo!!  Hope it is okay!

Jeff Bergosh 

### CONVERSATION ON 09-20-2021

**Jeff Bergosh**: Thanks Bobby I will look into it.  Pretty sure we can get WEAR there for sure!

**Jeff Bergosh**: I spoke to D4 office today—Board Chairman Bender will be making the proclamation in person on Saturday and we will ratify it at our next meeting.  Once you have the time firmed up for Saturday I’ll call WEAR producer to get it covered.

**Jeff Bergosh**: 👍

