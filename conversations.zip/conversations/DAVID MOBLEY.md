

## CONVERSATIONS WITH DAVID MOBLEY

### CONVERSATION ON 12-31-2019

**David Mobley**: Hi
So very sorry to hear about Rocky. I saw him earlier this week out running and will miss him greeting us when we drive up.
Our condolences.
David and Olga

### CONVERSATION ON 02-22-2020

**David Mobley**: You said 45  that are forty inches  and 40 that are  seventy inches ..right
I got er done..

**David Mobley**: 😁

**David Mobley**: Throw me some Moon Pies Mister!!!!😭

**Jeff Bergosh**: Thanks David!!

**David Mobley**: Yw

### CONVERSATION ON 02-23-2020

**David Mobley**: Hi¿I am free if you need help putting up signs today. I can bring my post hole diggers and will take half the time.¿Call me when you finish eating.¿David,your neighbor

**Jeff Bergosh**: Thank you David!

**Jeff Bergosh**: Okay I'm ready if you are

**David Mobley**: Otay Buckwheat..be there in 2 min

**David Mobley**: Hi¿If u will put that box of 1 ft 2x2s in the back of my truck in the camper shell at your convenience and let me know when you have I will het them cut for you.¿Enjoyed today.¿David,your neighbor

**David Mobley**: It is not locked

### CONVERSATION ON 02-24-2020

**Jeff Bergosh**: Will do it this morning---thank you David!!

### CONVERSATION ON 03-01-2020

**Jeff Bergosh**: Hello David- wondering if you might have some time to help me cut wood?

**David Mobley**: When?

**Jeff Bergosh**: When is good for you?

### CONVERSATION ON 09-04-2020

**David Mobley**: Hi Jeff¿Do you still want to use the tlr? If so I could back it into your driveway and put chocks on the wheels and you could stump directly in after each load and haul it off whenever you are finished. This way you will not have to handle them twice..

**David Mobley**: Dump in is what I meant.

### CONVERSATION ON 12-31-2020

**David Mobley**: HAPPY NEW YEAR

Danny is doing a good job as 'your nosey neighbor ' cks on him daily. Very interesting to chat with and watch to get new ideas. 
Only problem he is having is the squatters are not controlling their goats and they keep picking up his tools and trying to chew on some. Plus as he found out they are not house broken leaving piles all over the floor and furniture. 
The ducks like swimming in the big tub and the chickens roost on the backs of the furniture but the fresh eggs are nice to have and very tasty.
Other than that they have been pretty quiet except tonight they are having about 50 of their 'friends' over to celebrate with a bon fire in the back yard and instead of fireworks they are shooting off their rifles and shotguns. Gonna be lots of noise..hope it does not scare Carson. He likes playing with goats.

Hope you are having fun and being safe. Don't bring back any new strains of Covid...we have enough problems to worry about like 9 Mile Road being completed.

HAPPY NEW YEAR..

BUBBA

**Jeff Bergosh**: Ha ha ha LOL!!  Thanks for the progress update neighbor!  Just don't let the goats and chickens do too much damage!

Happy New Year to you and Olga!  Thanks for keeping an eye on things!

Jeff and Sally

**David Mobley**: Have safe travels home. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-04-2021

**David Mobley**: Have a safe trip and the squatters are gone. Molly Maids did a nice job of cleaning up. Will miss the fresh eggs.

### CONVERSATION ON 01-05-2021

**Jeff Bergosh**: LOL thanks David!  See you all tomorrow!

### CONVERSATION ON 06-12-2021

**Jeff Bergosh**: We got the pizza thank you!!

**David Mobley**: Hi
Do you know anyone at ECUA as eater pressure here suddenly went to zero and they don't answer emergency number. 
Thanks
David

**David Mobley**: Nature Trail also no water.
Just be a big break as went to zero immediately.

**Jeff Bergosh**: I'll find out right now

**David Mobley**: Thanks

**Jeff Bergosh**: David thank you very much for letting SALLY use the appliance dolly. I just brought it back to your house and leaned it up against your garage thanks again!

**David Mobley**: Thanks for the ECUA INFO.

**David Mobley**: Oh wow...just remembered tonight is Saturday and it is bath day..moght have skipped the last Sat bath

**David Mobley**: Water is on..thanks

