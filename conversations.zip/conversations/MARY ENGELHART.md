

## CONVERSATIONS WITH MARY ENGELHART

### CONVERSATION ON 11-20-2019

**Mary Engelhart**: Can you tell me what this means for Mandeville Ln. Property by Gleaton’s .Corner of Pine Forest and Mandeville 

**Jeff Bergosh**: Will do

### CONVERSATION ON 12-03-2019

**Mary Engelhart**: Mandeville Ln is here at the meeting 

**Mary Engelhart**: Just so you know, all is against it

**Jeff Bergosh**: Okay thx for heads up

**Mary Engelhart**: Appreciate anything you can do to help☺️

**Jeff Bergosh**: What is the issue today up for the planning board’s consideration

**Mary Engelhart**: Ok, thank you

### CONVERSATION ON 12-04-2019

**Mary Engelhart**: Hey, I was just wondering if you got the message yesterday about seeing if December 13 at 4 o’clock would work for coffee meeting with neighbors

### CONVERSATION ON 12-15-2019

**Mary Engelhart**: See ya tomorrow at 5, Neighborhood coffee meeting at my house

**Jeff Bergosh**: I’ll be there!  Thanks 

### CONVERSATION ON 12-16-2019

**Mary Engelhart**: engy302000@yahoo.com

**Jeff Bergosh**: Got it

**Jeff Bergosh**: Thanks again for the treats and for hosting

**Mary Engelhart**: Thank you again for coming ☺️

### CONVERSATION ON 01-07-2020

**Mary Engelhart**: Thanks for all you do for our District ☺️

**Jeff Bergosh**: Thank you Mary!

**Mary Engelhart**: I would not want your job

**Jeff Bergosh**: It has its moments😎

**Mary Engelhart**: Laughed at “It has its moments😎”

### CONVERSATION ON 02-02-2020

**Mary Engelhart**: I have about 30 of the forms filled out when you want to get them☺️

**Jeff Bergosh**: That’s awesome Mary!! Thank you!!

### CONVERSATION ON 02-03-2020

**Mary Engelhart**: When are you picking up?

**Jeff Bergosh**: Hi Mary—can I grab them this afternoon on my way home from work—at around 4:30 ish?

**Mary Engelhart**: Sure no problem 

**Jeff Bergosh**: Also—i need to speak to you about Thursday’s agenda.  Do u have a quick minute?

**Mary Engelhart**: Bad news

**Jeff Bergosh**: No

**Mary Engelhart**: Still dropping by?

### CONVERSATION ON 02-19-2020

**Mary Engelhart**: Sorry, I can't talk right now.

**Mary Engelhart**: In a meeting, will call you in a little bit

### CONVERSATION ON 03-05-2020

**Jeff Bergosh**: Good Morning Mary—just wanted you to know that the Pine Forest Road/Gleaton property hearing is on today’s agenda only for scheduling a hearing next month, April 2nd.  I will urge that we hold off, as I did last month— but the meeting will more than likely be scheduled for April 2nd regardless.  So that’s the date to be ready to speak.  Please pass the word to your neighbors that may be interested in this.

**Mary Engelhart**: Ok, thank you for update. Let me know time?

**Jeff Bergosh**: If it is scheduled, it will be at or after 5:30 on the 2nd of April

**Mary Engelhart**: Liked “If it is scheduled, it will be at or after 5:30 on the 2nd of April”

### CONVERSATION ON 03-07-2020

**Mary Engelhart**: Horrible accident just happened down from Mandeville, 

We don’t need apartments added to growing problem. 
Praying for those involved 

**Mary Engelhart**: We heard it when it happened, white truck went airborne , and landed

### CONVERSATION ON 03-18-2020

**Mary Engelhart**: Just thought you might wanna know Justin Labrato is my nephew. He is my oldest sister Laurie‘s son☺️

**Jeff Bergosh**: Wow what a small world!  He’s got a high power job!

**Mary Engelhart**: Liked “Wow what a small world!  He’s got a high power job!”

### CONVERSATION ON 03-20-2020

**Mary Engelhart**: I vote to close the Beach!!!!please

**Jeff Bergosh**: It’s quite a discussion

**Mary Engelhart**: We have been listening, if y’all don’t close it , I feel the governor will

**Mary Engelhart**: Thank you for all of your hard work, thank you for closing the beach

**Jeff Bergosh**: Thanks Mary

### CONVERSATION ON 03-31-2020

**Mary Engelhart**: Please tell me you don’t agree with Underhill  , just read the story of what he wants to reopen. 

### CONVERSATION ON 04-02-2020

**Mary Engelhart**: Happy Birthday Jeff!!!

**Jeff Bergosh**: Thank you Mary!

### CONVERSATION ON 04-13-2020

**Mary Engelhart**: Do you think you could put in a request to get Mandeville Ln swept and cut. Have a lot of buildup. Thank you☺️

### CONVERSATION ON 04-14-2020

**Jeff Bergosh**: Will do Mary!

**Mary Engelhart**: Thank you 😊, have a good day

### CONVERSATION ON 04-17-2020

**Mary Engelhart**: Darrin and I picked up all the trash up and down Mandeville Lane out of the ditches, now we just need the county to come. Thank you so much

**Jeff Bergosh**: Got it—it’s in the works.  Thanks for helping out in the meantime!

**Mary Engelhart**: Liked “Got it—it’s in the works.  Thanks for helping out in the meantime!”

### CONVERSATION ON 04-28-2020

**Mary Engelhart**: Thank you for bringing them to Beulah ☺️

**Jeff Bergosh**: 👍👍

### CONVERSATION ON 06-04-2020

**Jeff Bergosh**: I missed your call— in a bcc meeting.  Pine Forest FLU change is dropped from the agenda

**Mary Engelhart**: I was calling about sign posted. So it has been dropped now

**Jeff Bergosh**: Yes.  Apparently they are going to reach out to you all and they want to meet with you all.

**Jeff Bergosh**: So you should expect a cal from attorney Will Dunaway

**Mary Engelhart**: His calling me?

**Jeff Bergosh**: Yes, more than likely

### CONVERSATION ON 07-01-2020

**Mary Engelhart**: My email has been sent to all of the county commissioners. My parents name is on it also. We have about 6 to 7 other Mandeville Lane residence sending emails to

**Mary Engelhart**: Thank you for all you’ve tried to do, I really hope that this does not go through

### CONVERSATION ON 07-02-2020

**Mary Engelhart**: Did receive our email

**Jeff Bergosh**: Yes I did thanks this helps a lot!

**Mary Engelhart**: Liked “Yes I did thanks this helps a lot!”

**Mary Engelhart**: Please keep us posted

**Jeff Bergosh**: We dropped it tonight

**Jeff Bergosh**: The emails helped!

**Mary Engelhart**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Hey Mary- great talking to you today.  If you’re available and can assist—we will be doing campaign sign waving  on two Saturdays from 11:00-2:00. August 1st at the entrance to the Pensacola Interstate Fairgrounds and August 15th at the Kentucky Fried Chicken at the intersection of Mobile Hwy and Michigan Avenue.  If you could come down and help that would be awesome!!  I’ll have shirts for everyone and also I’ll provide sodas and lunch!  Thanks!!

**Mary Engelhart**: Liked “Hey Mary- great talking to you today.  If you’re available and can assist—we will be doing campaign sign waving  on two Saturdays from 11:00-2:00. August 1st at the entrance to the Pensacola Interstate Fairgrounds and August 15th at the Kentucky Fried Chicken at the intersection of Mobile Hwy and Michigan Avenue.  If you could come down and help that would be awesome!!  I’ll have shirts for everyone and also I’ll provide sodas and lunch!  Thanks!!”

### CONVERSATION ON 07-17-2020

**Mary Engelhart**: Well you already have 3 votes, mailed ours in today☺️

**Jeff Bergosh**: Thank you Mary!!!!!  Greatly appreciate your support

**Mary Engelhart**: Liked “Thank you Mary!!!!!  Greatly appreciate your support”

### CONVERSATION ON 07-27-2020

**Mary Engelhart**: This was in some of the residence mailbox, do we need to submit another email , send the one we sent before or what ? Due to how bad Covid-19 is no one will be attending 

**Jeff Bergosh**: I need to discuss this with you 

**Mary Engelhart**: Ok

**Jeff Bergosh**: I’ll call u when I get out of this meeting I’m in

**Jeff Bergosh**: Thx

**Mary Engelhart**: Ok, thank you

### CONVERSATION ON 08-01-2020

**Mary Engelhart**: Hey sorry we aren’t going to be able to make it today to wave, we are helping my parents out in the yard

**Jeff Bergosh**: No problem thanks Mary!  Hopefully you can make our next event two weeks from today at the Intersection of Michigan and Mobile Hwy— the KFC

**Jeff Bergosh**: From 11:00-2:00

**Mary Engelhart**: We will be in Tallahassee, moving Sydney ☺️

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-06-2020

**Mary Engelhart**: Any update from meeting?

**Jeff Bergosh**: I voted against it 

**Jeff Bergosh**: The board voted me down 4-1

**Mary Engelhart**: So now to state

**Jeff Bergosh**: It goes to Tallahassee and will be there for 3 months 

**Jeff Bergosh**: Will need residents for that meeting

**Mary Engelhart**: Maybe Covid want be so bad, a lot of people were probably there tonight

**Mary Engelhart**: Y’all voted on masks too

**Jeff Bergosh**: We’re discussing it right now

**Mary Engelhart**: I want them

### CONVERSATION ON 08-07-2020

**Jeff Bergosh**: Not three votes in support.  It was a 4-1 against because it was a poorly conceived effort at doing something “on the fly” so Lumon could score political points with his constituency. 

**Mary Engelhart**: I watched it, he tried hard. But I understand it is hard to do when the sheriff’s department said they want do anything in the matter. But I would have loved to see what 3 weeks would do to the numbers. 

### CONVERSATION ON 08-18-2020

**Mary Engelhart**: Congratulations!!! I knew you would get re- elected☺️

**Jeff Bergosh**: Thank you very much Mary it was a great night I appreciate all your help and support!

**Mary Engelhart**: Liked “Thank you very much Mary it was a great night I appreciate all your help and support!”

### CONVERSATION ON 09-08-2020

**Mary Engelhart**: When you have a second will you call me back

### CONVERSATION ON 09-17-2020

**Mary Engelhart**: Call me when u have a minute 

**Jeff Bergosh**: K

**Mary Engelhart**: I have a county question that I really need an answer. My neighbor is threatening me

**Mary Engelhart**: The daughter messaged me too on Facebook, this is it

### CONVERSATION ON 09-29-2020

**Jeff Bergosh**: Hello Mary—I wanted to remind you that tonight at 6:00PM at the Bellview Fire Station we will have a neighborhood meeting with Development Services and the owners/developers of that property that is adjacent to where you all live.  They were supposed to have mailed out invitations to the neighbors.  Hope you all can make it!

**Mary Engelhart**: I didn’t get a notice, but some of the neighbors did. I know some are attending ☺️

**Jeff Bergosh**: Okay thanks and I hope you will be there too

**Mary Engelhart**: I am unable to make it tonight. Hope all goes well, I know some of the neighbors are coming.

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Hello Mary I hope all is well.  The final hearing for the change of the FLU for the Pine Forest property will take place on Thursday evening— in case the residents want to show up and speak out.

**Mary Engelhart**: Thank you, I’ll let them know☺️

