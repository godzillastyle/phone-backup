

## CONVERSATIONS WITH DAVE MIDGORDEN

### CONVERSATION ON 01-10-2020

**Jeff Bergosh**: Hey Dave—I hope you’re enjoying your time off and that you’re having a good week. If you could can you please enter your electronica timesheet?

**Dave Midgorden**: Jeff 
--I'll d that

**Dave Midgorden**: Nothing like. some time away

**Jeff Bergosh**: 👍😎 I know what you mean!

**Dave Midgorden**: I went to submit and suddenly it showed 4181962 hours on holiday pay!!!

**Jeff Bergosh**: Uh oh—that’s not right

**Dave Midgorden**: So I'll have to play with this some-I'll let you know whether I get this straightened out or not

### CONVERSATION ON 09-14-2020

**Jeff Bergosh**: Good evening-  I’m just letting you all know that I have not been told that we are not to report to work. Therefore I am authorizing liberal leave for any of you who wish to make storm preparations and not come to work tomorrow. It will just be charged to PTO on your time sheet. I am not sure if the gate guards will let us in tomorrow—-as again I’ve not been told one way or the other. I’ll be coming in in the morning and if anyone else Comes in and is stopped please let us all know. Just reply to this text if you know for sure you will be taking leave tomorrow and not coming in otherwise we will see y’all at work tomorrow.

Jeff B

**Dave Midgorden**: I believe I'll just stay home tomorrow then

### CONVERSATION ON 09-15-2020

**Dave Midgorden**: Unless the weather guessers are wrong, they show the hurricane hitting Mobile Bay at 7:00 tomorrow morning

**Dave Midgorden**: I don't plan on coming in tomorrow

**Jeff Bergosh**: Got it.  Thanks Dave, stay safe.

**Dave Midgorden**: Okay then, enjoy the storm

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: This should be obvious to everyone but nobody is working today.  It’s just too unsafe.  I’ll text everyone when I get information on reopening.  Meanwhile, stay safe!

**Dave Midgorden**: Still hitting hard here

**Jeff Bergosh**: Same here in Beulah

**Jeff Bergosh**: All--- I just spoke to Mark Powell and the power is out to most of the base the front gate is secured and the Loveless bridge is not passable according to him. Apparently it was hit by a barge too- just like the 3 mile bridge. back gate is secured. they're working on a third way in ---apparently there's a third gate behind the airfield but I don't know where that is. The county will be implementing dusk to dawn curfews as we have reports of looting and lots of flooding lots of roads closed lots of trees down. The NMCI network is down and Mark will call me tomorrow and let me know if building 458 has power or whether or not the PBSS network is up.  Please shoot me an individual text to let me know if you are alright, whether or not you have power, and how your house fared in the storm.  I will be speaking with Tony soon to determine work schedules for us going forward.  

**Dave Midgorden**: No power, nine huge trees down, shingles flown off the roof

**Dave Midgorden**: At this point can't even get off my block

**Jeff Bergosh**: Okay stay safe.  

**Dave Midgorden**: Trees and power lines down

**Dave Midgorden**: In the road 

**Jeff Bergosh**: Okay be safe-I will let you know work status/ schedule after I speak to Tony.

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: Dave- if you have power and are able to do so I need you to submit your timesheet online for this week

**Jeff Bergosh**: Dave are you there?

**Dave Midgorden**: No power and no internet to do that

**Jeff Bergosh**: Okay no problem we can do it Monday if you can’t do it from your iPhone

### CONVERSATION ON 09-25-2020

**Jeff Bergosh**: Dave—I went to approve your time sheet and you have listed 32 hours of overtime instead of 32 hours of straight time can you please go into the online time system and make this correction I have sent it back for correction

### CONVERSATION ON 10-05-2020

**Dave Midgorden**: Jeff, almost got my generator set up like I want but got contractors coming got the roof tomorrow.  Haven't heard anything from some issues I've been expecting-but Ira is briefed and can handle them if they raise their ugly head.

**Dave Midgorden**: Gonna take care of all this tomorrow and don't plan on coming in unless the sky falls

**Jeff Bergosh**: Sounds good Dave good luck!

### CONVERSATION ON 12-04-2020

**Jeff Bergosh**: Dave I hope you're feeling better this morning just was going to ask to see if you were able to put in your time in the electronic timesheet five days of PTO? If you could do that for us it would greatly assist. I hope you're feeling better

**Dave Midgorden**: I'll give it a shot

**Dave Midgorden**: Still can't get the Dr office to call back

**Dave Midgorden**: Should be in Monday

**Jeff Bergosh**: Okay thanks Dave!

### CONVERSATION ON 06-17-2021

**Dave Midgorden**: Holly shit

**Dave Midgorden**: Well-I'll certainly NOT come in tomorrow then!! 

**Jeff Bergosh**: 👍

