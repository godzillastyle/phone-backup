

## CONVERSATIONS WITH DANIELLE APOLINAR

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Road is blocked

**Jeff Bergosh**: I’m down the

**Jeff Bergosh**: I’m by the gateway inn by the base by the bridge

