

## CONVERSATIONS WITH TODD LEONARD

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: Yes it was good catching up!  Thanks for what you’re doing for our students!!

**Jeff Bergosh**: Not yet I DVR’d it.  Did it turn out well?

**Jeff Bergosh**: Will do.  Thanks Todd!

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: Thought it went well!  They did great at disguising the voice!

**Jeff Bergosh**: Will do and yes they are!

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: That paper hates me and loves propaganda like that video.   If they did an op Ed they would probably do it in support of it LOL

