

## CONVERSATIONS WITH RENEE BENINAUGHTY

### CONVERSATION ON 03-25-2020

**Renee Beninaughty**: Hey there it Renee! When will the commission vote on whether or not to extend closure of beaches? 

### CONVERSATION ON 03-26-2020

**Jeff Bergosh**: April 2nd

**Renee Beninaughty**: Ok that’s what I thought. Thanks! 

### CONVERSATION ON 04-22-2020

**Renee Beninaughty**: Let me know when you’re ready 

**Renee Beninaughty**: We’ll be FaceTiming from an email that says mbrian 

**Jeff Bergosh**: Ready

### CONVERSATION ON 12-28-2020

**Renee Beninaughty**: Hey there Randy said you’d do a quick FaceTime! Just let me know when you could do it. Thanks! 

### CONVERSATION ON 02-09-2021

**Renee Beninaughty**: Hey Jeff it’s Renee B with channel 3 news if you can give me a call 

**Renee Beninaughty**: He’s back! So just let me know when you’re ready 

**Jeff Bergosh**: Ok will do

**Jeff Bergosh**: How about in 5 minutes?

**Renee Beninaughty**: That’s perfect! 

**Jeff Bergosh**: Ready when you are

**Renee Beninaughty**: Okay I’ll give you a call on my laptop 

**Jeff Bergosh**: 👍

**Renee Beninaughty**: Calling now 

**Renee Beninaughty**: Tried calling twice 

**Jeff Bergosh**: I answered both times

### CONVERSATION ON 02-10-2021

**Renee Beninaughty**: Hey Jeff! The medical examiner gave me the Death stats for Escambia County. Did they happen to also give this to you and if so can you send a pic? I can’t find it today!!

### CONVERSATION ON 03-11-2021

**Renee Beninaughty**: About to call one second sorry haha 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: *near miss

**Renee Beninaughty**: Hey there!!! Sorry I accidentally left my work phone at the station. I will definitely give him a call! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-30-2021

**Jeff Bergosh**: Great— thanks!  It’s on my calendar

**Jeff Bergosh**: Sorry pocket dialed you 

**Renee Beninaughty**: No worries!! 

