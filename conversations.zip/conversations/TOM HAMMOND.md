

## CONVERSATIONS WITH TOM HAMMOND

### CONVERSATION ON 12-24-2020

**Jeff Bergosh**: Sure Tom, let’s do that.  I’m out of state at the moment but let’s talk after I return early next month.  Merry Christmas to you all as well.

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Thanks!

