

## CONVERSATIONS WITH DEBBIE DEGROOTE

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Hi Debbie I'm in a meeting I'll call u after

