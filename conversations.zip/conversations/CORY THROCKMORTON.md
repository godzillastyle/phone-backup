

## CONVERSATIONS WITH CORY THROCKMORTON

### CONVERSATION ON 04-23-2021

**Jeff Bergosh**: Hello Cory, this is Jeff Bergosh.  My wife Sally and I are excited to be purchasing your condo at Tristan Towers.  I have a couple of questions if you have a moment to talk.  I’d greatly appreciate it. Thanks!

### CONVERSATION ON 05-02-2021

**Cory Throckmorton**: Here are the financials for the first couple bookings....

### CONVERSATION ON 05-03-2021

**Cory Throckmorton**: FYI, we are scheduled to sign Thursday at 330.

**Jeff Bergosh**: Right on, we’re right after you all the next day

### CONVERSATION ON 05-05-2021

**Cory Throckmorton**: What is your email?

**Jeff Bergosh**: jeffbergosh@gmail.com

**Cory Throckmorton**: Ok, going to send pics.

**Cory Throckmorton**: Did you call utilities?

**Jeff Bergosh**: Doing it today

**Jeff Bergosh**: Cox and Gulf Power

**Cory Throckmorton**: Inverse

**Cory Throckmorton**: Uverse 

**Jeff Bergosh**: Oh— not Cox?  Thx.  I’ll call ATT

**Cory Throckmorton**: I’m going to call gulf power right now.

**Jeff Bergosh**: Okay thx

**Cory Throckmorton**: If your done with GP give me a call.

**Jeff Bergosh**: I just got off the phone with Gulf Power and my account has been established starting Monday the 10 th.  They confirmed no service interruption over the weekend

### CONVERSATION ON 05-06-2021

**Cory Throckmorton**: Current codes, #0916 for gate and lobby, 1744 for the condo door, leaving all keys at Surety today.

**Jeff Bergosh**: Okay thank you Cory I’ll pick them up tomorrow.  I never heard back from ATT but I’ll try them again later this afternoon.

**Jeff Bergosh**: Also, can you text me Chrys Crockett’s contact information?

Thanks very much

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-07-2021

**Cory Throckmorton**: Instructions for door handle.

**Jeff Bergosh**: Thx

**Cory Throckmorton**: I will work on wireless thermostat soon.

**Jeff Bergosh**: Thank you!

**Cory Throckmorton**: Today’s check in

**Cory Throckmorton**: Are we official?

**Jeff Bergosh**: Yes— signed off at 4:00.

**Cory Throckmorton**: Congrats!

### CONVERSATION ON 05-08-2021

**Jeff Bergosh**: Thank you!

**Cory Throckmorton**: I talked to Bill the AC guy and he said he just doesn’t have time. I would recommend Peaden. I have used them a few times and been impressed. Remind me to tell you about filters next time we talk.

**Jeff Bergosh**: Okay thanks for closing the loop on that.  On Tuesday I’ll remind you about the filters.  Thanks Cory.

### CONVERSATION ON 05-09-2021

**Jeff Bergosh**: Good Morning Cory: I tried for the last three days to complete the transfer process of the Internet service. This is been an extremely frustrating challenge and I’ve probably talked to 15 or so AT&T representatives—— nobody can get it done. I certainly do not want to lose Internet accessibility at the unit when we are in the heart of the busy season. Can I pay you for the next three months worth of service and fix this problem after the season? I have no confidence in AT&T’s ability to complete this process: it was an eight hour evolution yesterday including a trip to the AT&T store where no one could fix it. Please let me know your thoughts on that thanks

**Cory Throckmorton**: Sure, no problem 

**Jeff Bergosh**: Much appreciated.  

**Jeff Bergosh**: If possible, let’s just subtract the three months worth of service charges from the first guest payout you send me.

**Cory Throckmorton**: Ok, sounds good.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-11-2021

**Cory Throckmorton**: What is your Venmo handle?

**Jeff Bergosh**: @jeff-bergosh 

**Jeff Bergosh**: I think

**Cory Throckmorton**: You can screenshot it to be sure

**Jeff Bergosh**: Will do

**Cory Throckmorton**: I am not going to be able to make it out there tomorrow. I had the airline flight from hell yesterday that ended up canceling and I am still stuck in Dallas. Hopefully I get home this afternoon but I’m gonna need tomorrow to catch up on things around the house. But at any time if you have questions about anything you can always call.

**Jeff Bergosh**: Oh— I had us down for 1300 today at the property?

**Jeff Bergosh**: I’m meeting Chrys there at 1200

**Cory Throckmorton**: Ya, I won’t even be in Pensacola by then.

**Jeff Bergosh**: Okay no problem

**Cory Throckmorton**: Just sent your first payment!

**Jeff Bergosh**: Just got it!  Thanks!  Did you subtract 3 months for internet?

**Cory Throckmorton**: I did, 58 x 3

**Jeff Bergosh**: Perfect

**Jeff Bergosh**: I’m pretty flexible on times/days due to my job

**Cory Throckmorton**: I will call you later when you are at the unit. Few things I want to tell you about.

**Jeff Bergosh**: So we can work it on your schedule

**Jeff Bergosh**: Cory I’m setting up the thermostat account but I need the device MAC ID and the device CRC.  The website says this information is on the thermostat ID that came with the unit.

**Cory Throckmorton**: I think it is on the unit itself, I would call them and they will walk you through it.

**Jeff Bergosh**: It says it’s on the back of the unit

**Cory Throckmorton**: Yes, I think the whole face plate pulls off. Also I just remembered, the box might be in the cabinet above the refrigerator.

**Jeff Bergosh**: Thanks Cory

**Cory Throckmorton**: Are you changing the door code?

**Jeff Bergosh**: No not yet 

**Cory Throckmorton**: Ok, so all codes the same, about to text the next check in.

**Jeff Bergosh**: 👍

**Cory Throckmorton**: This is what I send after I confirm the number.

Great! The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is 3.

**Jeff Bergosh**: Perfect

### CONVERSATION ON 05-12-2021

**Jeff Bergosh**: Good Morning Cory.  A couple of quick questions:  the next guest arrives tomorrow afternoon, the 13th, right?  Also, I cannot get any of the keys you left to open the weight room- exercise room.  Do you have that key?  Thanks!

**Cory Throckmorton**: Watsonlgp@aol.com

**Cory Throckmorton**: Linda’s email

**Jeff Bergosh**: Thx

**Cory Throckmorton**: Tomorrow’s check in.

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-13-2021

**Jeff Bergosh**: Hey Cory- just wanted to let you know that David Kotchie just called and re-booked with me for July31-August 7th.  So the system worked so if you want to go ahead and contact the next one prior to David Kotchie that would be great!  Thanks!

**Cory Throckmorton**: Excellent!

**Cory Throckmorton**: This is my more typical review.

**Jeff Bergosh**: That’s awesome!  Was that the previous renter, right before this one?

**Cory Throckmorton**: That just came through today, 4/29 - 5/2

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-14-2021

**Cory Throckmorton**: She wants to rebook and will be calling you soon.

**Jeff Bergosh**: Fantastic thank you Cory!

**Cory Throckmorton**: How did the AC do today?

**Jeff Bergosh**: It appears to be working again.

**Cory Throckmorton**: 👍

**Jeff Bergosh**: Been watching it all day.  It seems to operate better when left in the on position rather than the auto position

**Cory Throckmorton**: Gotcha 

**Jeff Bergosh**: But I’m having the service call tomorrow anyway just to make sure

### CONVERSATION ON 05-16-2021

**Jeff Bergosh**: Cory who are the next guests that are checking in today?

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-17-2021

**Cory Throckmorton**: Pretty sure that’s it

**Jeff Bergosh**: Okay I’ll call her thanks

### CONVERSATION ON 05-18-2021

**Cory Throckmorton**: Just Venmoed that

**Jeff Bergosh**: Okay thanks Cory. 

**Jeff Bergosh**: Jacinda Rea called and re-booked with me yesterday evening for July 24-30.  Thanks for assisting with this transition Cory!

**Cory Throckmorton**: Good deal, shall I cancel the next one?

**Jeff Bergosh**: Sure.  It seems to be working thus far.  And of course feel free to tell them my number and email and that I intend to honor the listing at the same rate and I’m holding the spots blocked for their call.  Thanks!

**Cory Throckmorton**: 👍

**Cory Throckmorton**: Sounds like they broke the rules and had a dog, maybe that’s where the Pee came from. Notice I did not give her five stars back.

**Jeff Bergosh**: I had a feeling there was something going on.  Thanks for sharing— yeah she definitely broke the rules but hey, she gave five stars LOL

**Jeff Bergosh**: Phillip Zebol just re-booked for the period July 18-24.  Thanks for facilitating that!

**Cory Throckmorton**: Perfect! I will cancel some more this afternoon.

**Jeff Bergosh**: 👍

**Cory Throckmorton**: She wants to rebook, canceling now.

**Jeff Bergosh**: Okay standing by

**Cory Throckmorton**: Wants to rebook, canceling now, this is a big one, payout of almost 2500.

**Jeff Bergosh**: Fantastic.  Should I call them, or wait until they reach out to me?

**Cory Throckmorton**: You can call him if you want, but I would wait until this evening when he sees the cancellation, he also has your number.

**Jeff Bergosh**: Okay I’ll hold back.  I got your email — is that the payment for the current guest?

**Jeff Bergosh**: $1012.46

**Cory Throckmorton**: Yes

**Cory Throckmorton**: Ha, the big one just asked if you are the commissioner when I sent him your info.

**Jeff Bergosh**: He’s doing his research LOL

**Jeff Bergosh**: .........I just hope he doesn’t do too much research if he’s a Democrat he won’t like me and he won’t rebook

**Cory Throckmorton**: He said he lives next door to Tristan, but he is bringing his kids down, rented another unit as well.

**Jeff Bergosh**: That’s really cool that he’s doing that for his family

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: Hi Cory— I got Dorfman rebooked and got a call from Karen Hall, she’s going to re-book as well today or tomorrow.  Thanks for helping me work through this.  Also, I got the payout this morning from the current guest, thanks for that!

**Cory Throckmorton**: Good deal, will cancel a couple more this afternoon.

**Jeff Bergosh**: 👍

**Cory Throckmorton**: Wants to rebook. Cancelling now

**Jeff Bergosh**: Ok thx!

**Cory Throckmorton**: Wants to rebook, canceling now.

**Jeff Bergosh**: Fantastic!

### CONVERSATION ON 05-20-2021

**Jeff Bergosh**: Hey Cory, every one has re booked, so as of right now all of the July and August bookings you had have re-booked with me.  Wayne Talent booked with me for June 24th through the 30 th-  so now all that remains is the period between today and June 23.  So if you’re ready to cancel a couple more in June we can do that.  Getting close to wrapping this up— and I greatly appreciate your assistance!

**Cory Throckmorton**: Ok, I will do a couple more tomorrow.  👌

**Jeff Bergosh**: Thx!👍

### CONVERSATION ON 05-21-2021

**Cory Throckmorton**: Hey, just a heads up, had no time today to work on bookings, and tomorrow we go to to St Thomas so may be middle of next week before I get to the next ones.

**Jeff Bergosh**: Okay thx for heads up

### CONVERSATION ON 05-23-2021

**Cory Throckmorton**: Wants to rebook, canceling now.

**Jeff Bergosh**: Right on!  Thanks Cory!

**Cory Throckmorton**: Wants to rebook, canceling now

**Jeff Bergosh**: Fantastic!

### CONVERSATION ON 05-24-2021

**Cory Throckmorton**: Wants to rebook, canceling now, I think we should make this the last cancel.

**Jeff Bergosh**: I agree.  Otherwise too close to the arrival date.  Greatly appreciate your willingness to help get these re-bookings captured.  Thanks very much Cory!

**Cory Throckmorton**: My pleasure. So there will be two more under me, and we will be complete!

**Cory Throckmorton**: Have you received any of your own bookings yet?

**Jeff Bergosh**: Yes I have had 2 new ones for August of this year— the rest of the calendar is sold out

**Jeff Bergosh**: I had one guy cancel, and someone rebooked within 15 minutes out of the clear blue sky.  

**Cory Throckmorton**: Awesome!

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: Cory-  just got the payment, thank you!

**Jeff Bergosh**: Also, I re-booked the final two groups yesterday as well.  Thanks again for the smooth transition!

**Cory Throckmorton**: Good deal, no problem.

**Cory Throckmorton**: I gave Thursday’s check in codes.

**Jeff Bergosh**: Okay thanks for that.  

### CONVERSATION ON 05-27-2021

**Jeff Bergosh**: Right on!!  Great job Cory!!  LOL

**Cory Throckmorton**: 🤣

