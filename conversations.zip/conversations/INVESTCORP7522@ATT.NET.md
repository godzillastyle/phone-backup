

## CONVERSATIONS WITH INVESTCORP7522@ATT.NET

### CONVERSATION ON 11-02-2019

**investcorp7522@att.net**: Jeff, 
       Please tell Sally I have her items for the Clinic fundraiser. I’ll drop them by when convenient to you two. 
Gibb 🙂

**Jeff Bergosh**: Thank you Gibb—great to see you and Liz today

**investcorp7522@att.net**: Always Great seeing you and Sally! 

**Jeff Bergosh**: Gibb——thank you so much for the donations to Sally’s fundraiser!!! This stuff is awesome and it will really help us raise money for the health and Hope clinic!!! Please tell Tommy we said thank you soooo much!!!!

**investcorp7522@att.net**: You are most welcome Jeff!

**investcorp7522@att.net**: I shall extend thanks to Tommy and Outcast.

### CONVERSATION ON 12-07-2019

**investcorp7522@att.net**: G’morning and a VERY MERRY CHRISTMAS to the Jeff & Sally Bergosh family! Just wanted to thank you for our beautiful, informative card! 🎄🎁🎅🏽
Gibb & Liz

**Jeff Bergosh**: Thank you Gibb!!!!  Merry Christmas to you and Liz!

### CONVERSATION ON 12-30-2019

**investcorp7522@att.net**: Tommy just told me about Rocky. We’re so sorry Jeff. Liz and I liked to hear Rocky expressing himself as we walked by. 🙂 We’ll miss him.

**Jeff Bergosh**: Thanks Gibb.  We’re all heartbroken.  Thanks for the kind words

**investcorp7522@att.net**: I know it’s as if a close family member has departed. 

**Jeff Bergosh**: Yes it is.  We will miss him.

### CONVERSATION ON 03-26-2020

**investcorp7522@att.net**: Good call on opening the beaches, Jeff! We’re all concerned about the Virus, but a balanced approach considering the wellbeing of the citizens as well as the economic impact MUST be taken into account. Thank you for taking the lead on this!
Gibb

**Jeff Bergosh**: Thank you Gibb!

### CONVERSATION ON 03-31-2020

**investcorp7522@att.net**: Jeff, could you find out what happened to the rifle Mike Hoyland
shot the terrorist on NAS with.  We’d like to buy it and give it to Mike. Is this possible?  
Gibb

**Jeff Bergosh**: I will ask

**investcorp7522@att.net**: Thank you Jeff. Mike expressed wanting it. Some friends would like to buy it and give it to him. He doesn’t know 

**investcorp7522@att.net**: It may not be possible.

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: Absolutely Mark-- thanks for joining in and I hope you and your family stay safe as well!

