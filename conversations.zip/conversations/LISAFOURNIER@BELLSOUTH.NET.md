

## CONVERSATIONS WITH LISAFOURNIER@BELLSOUTH.NET

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Gerald I'm in a meeting I'll call you right back

### CONVERSATION ON 11-29-2020

**lisafournier@bellsouth.net**: Do you live in Ensley? 

**Jeff Bergosh**: No, Beulah

**lisafournier@bellsouth.net**: Okay thanks. I want to make a donation to the cold weather shelter and don’t think I’m going to have time to drive up there. I’m leaving to go out of town tomorrow evening and hoping to get it to them tomorrow before I leave. Hope you had a great Thanksgiving with your family. Take care.

### CONVERSATION ON 12-16-2020

**lisafournier@bellsouth.net**: https://www.pnj.com/story/news/2020/12/16/covid-19-vaccine-naval-hospital-pensacola-gives-first-doses-nwfl/3927480001/

### CONVERSATION ON 12-17-2020

**Jeff Bergosh**: Congrats Lisa— it’s in today’s paper.  Any reaction?

**lisafournier@bellsouth.net**: None really. I had it about 930. I didn’t even feel them do the shot. About 7pm I was really tired. Not sleepy, just exhausted. Slept well. Woke up without the tiredness. My arm is sore- but I’ve have some flu shots that have hurt worse. It’s just sore. No fever. No muscle aches. No redness or anything. I can’t wait to move beyond this disaster. I get the 2nd shot Jan 5, by Jan 11, I will be 100% immune.

### CONVERSATION ON 12-25-2020

**Jeff Bergosh**: Merry Christmas!!

### CONVERSATION ON 06-24-2021

**lisafournier@bellsouth.net**: Hi Jeff. Hope all is well with you and your family. I know you are no longer associated with the schools but I have a general question. How do you make a FOIA request to the Escambia School board. I want all emails between administration, the school board, teachers, and staff regarding critical race theory. To whom to I submit this request?

Think they’ll comply or will I have to engage legal representation? 

### CONVERSATION ON 09-08-2021

**lisafournier@bellsouth.net**: I watched your morning coffee….. I have a question that no one seems to address. Vaccinations done at the Navy Hospital and the VA are not reported to Florida Shots, not reported to the state, and not broken down by county. The numbers are never added to anything except the US as a whole. Given that the Navy Hospital has vaccinated more than 20,000 and I am guessing the VA about the same, our percentage is WAY off. It would be nice if someone would contact both facilities, get a number and add those to our percentage. I am guessing we are over 70% first shot. 

Secondly, many- including me- would appreciate the hospital number to include how many vaccinated and unvaccinated. You just have to look around the web to see really great examples. A number doesn’t mean much.

Finally, reporting deaths are difficult- and is a victim of the person processing it. When a 95 year old person dies with CoVid- is that really OF CoVid. Or a person who is in a car wreck but has CoVid? That number is never accurate and means nothing. 

This is what the people want.

**Jeff Bergosh**: Thanks for that info I’ll ask about the shit reporting— that is a huge number of vaccinations.  Are you certain this is not reported to the state???

**Jeff Bergosh**: How could that be??

**lisafournier@bellsouth.net**: Absolutely. Can you give me a real quick call at 8504921008, I just have a minute but it’s difficult to write. 

But yes. Nothing is reported.

**lisafournier@bellsouth.net**: https://covid.cdc.gov/covid-data-tracker/

**lisafournier@bellsouth.net**: What if we put on the dashboard how many monoclonal antibody treatments given -- knowing other people were getting them would make people ask questions. Administration of MAB will protect the hospital systems.

