

## CONVERSATIONS WITH ROBERT RINKE

### CONVERSATION ON 12-05-2019

**Jeff Bergosh**: Thanks very much Robert.  It was a long night.......but thankful for incremental progress 

**Jeff Bergosh**: Absolutely, Have a great night Robert.

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

