

## CONVERSATIONS WITH PHYLLIS WOODBURN

### CONVERSATION ON 03-16-2020

**Jeff Bergosh**: http://agenda.myescambia.com/agenda_publish.cfm?id=&mt=ALL&get_month=3&get_year=2020&dsp=agm&seq=17120&rev=0&ag=4352&ln=51030&nseq=17139&nrev=0&pseq=16898&prev=0#ReturnTo51030

Phyllis- the above link will take you to our agenda item from the public meeting held on November 18, 2019.

As we discussed in our telephone conversation I will have my secretary send you a hard copy of this document as well upon her return next week.

**Jeff Bergosh**: Yes ma'am you're welcome

