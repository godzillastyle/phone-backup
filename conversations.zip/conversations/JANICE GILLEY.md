

## CONVERSATIONS WITH JANICE GILLEY

### CONVERSATION ON 10-20-2019

**Jeff Bergosh**: If so, how long is it for and did it include the "engineer" positions? Or was it same language and just a 3% pay increase?

**Janice Gilley**: They only issue the IAFF agreed to was the 3% MOU that we sent to all the unions. It was separate from the bargaining agreement.  

**Janice Gilley**: It is only for this fiscal year. 

**Jeff Bergosh**: Do you have the MOU electronically that you could send to me--the executed agreement?

**Janice Gilley**: Yes sir. 

**Jeff Bergosh**: Is it a public document I can blog about?

**Janice Gilley**: Yes sir. 

**Janice Gilley**: Just sent it. 

**Jeff Bergosh**: Thank you!

**Jeff Bergosh**: Also-congrats on the positive articles in the PNJ!!!

**Janice Gilley**: We are still in bargaining,  so this is not all that they have requested as far as salaries or wage increases.  That part is not public yet.

**Janice Gilley**: I will brief you all.

**Jeff Bergosh**: Got it.  Thx

**Janice Gilley**: Thank you sir. BTW, you know my granddad always said it is best to never believe your own press lest you get the big head or too big for your britches.  So, I will take this one in stride and keep my nose to the grindstone.   

**Jeff Bergosh**: That was sage advice from your grandfather!  Have a great Sunday Janice!

### CONVERSATION ON 10-22-2019

**Janice Gilley**: The FDOT meeting is going well. 

**Janice Gilley**: WEAR is here. I do not see PNJ yet. 

**Janice Gilley**: Good turnout, and quite a few information consultants here for FDOT too. 

**Janice Gilley**: They provided an outside tent for overflow, but it has not been used. 

**Janice Gilley**: Thinning out.

**Janice Gilley**: I know all 4 of the people that are not FDOT folks 

**Janice Gilley**: There were no significant events. Every one appeared to have their questions answered.  I had a good time. It was like old home week. Hope your event went well.  

**Jeff Bergosh**: Thank you very much Janice!!

### CONVERSATION ON 10-29-2019

**Janice Gilley**: Sir. I spoke to Mr. Chaney.  The commissioner and our legal dept are trying to resolve the issue for the family he is concerned about.  I think a resolution is in the works, but Mr. Chaney may not be aware of it yet.  

**Jeff Bergosh**: Thanks very much for this update--he can be rather animated at times!

### CONVERSATION ON 11-04-2019

**Janice Gilley**: Sir, I just accepted Bob Dye's resignation. The facilities director position posted on November 1st.  I will work on the Risk Management position posting.  He did provide the appropriate notice for his 2 positions, his last day will be February 2, 2020. 

**Jeff Bergosh**: Thanks for the heads up hope he is alright, I really like Bob 

**Janice Gilley**: I do too. I have not spoken with him. It was a letter. 

**Jeff Bergosh**: Perhaps he just feels like it's time?  I wish him all the best

**Janice Gilley**: I wanted to be a bit more clear,  Bob has decided to retire. 

**Jeff Bergosh**: Oh okay that makes me feel a whole lot better!  I'm happy for him

### CONVERSATION ON 11-05-2019

**Jeff Bergosh**: Please call me when you have a moment--thanks

### CONVERSATION ON 11-06-2019

**Janice Gilley**: Sir,  we have had a serious incident with on of our firemen around 4 am.   At this time it appears that he was hit by a large truck at the scene of an accident on the Muscogee Bridge. Please pray for a good outcome.  JD is on route to the hospital and will provide us an update from there. 

**Jeff Bergosh**: Oh my God--I hope he is okay.  I will keep him in my prayers.  Thank you for the heads up.

**Janice Gilley**: Just pray. 

**Jeff Bergosh**: 🙏

**Janice Gilley**: I just heard from JD, he is with the family. He was hit by a log truck and did not make it. We have not released the name.  We are also having issues with our CMR phone line, so we are working on that too. You may get calls from media.  We are all headed to the office. 

**Jeff Bergosh**: Okay sorry to hear that.

**Jeff Bergosh**: What a terrible tragedy.

**Janice Gilley**: Yes sir.  I am absolutely sick. 

**Jeff Bergosh**: Me too

### CONVERSATION ON 11-07-2019

**Jeff Bergosh**: He will probably have something on at the 6 o'clock news that's why am in my office watching

**Janice Gilley**: The county continues to  cooperate with an ongoing state investigation that includes the gathering of records, some of which are housed at the public safety building. ¿

**Janice Gilley**: This is our official response.  

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 11-11-2019

**Janice Gilley**: Sir, I wanted you to know that about 35 leaders from EM, EMS, Fire, DOD, Hillcrest, the Bradshaw family and the state are working on the funeral details this morning. We will have more details soon to you and the public. 

**Janice Gilley**: FHP, the army and Sheriff personnel too. 

**Janice Gilley**: Sir I have sent you service details for tomorrow to your district email please call with any questions.

**Jeff Bergosh**: Thanks for the update

### CONVERSATION ON 11-12-2019

**Jeff Bergosh**: Good morning Janice:  my intention is to attend the funeral this morning. I will be heading that direction around 845 this morning just wanted to know a couple of things where will we be parking? Will there be parking reserved at Hillcrest for us? With respect to the procession are we driving our personal vehicles if we want to participate or are we going to be riding on a county vehicle? Please advise and thank you!

**Janice Gilley**: Can you call me? 

**Jeff Bergosh**: Yes

**Janice Gilley**: Sir, we will have parking solely for the commissioners at the church.  Pull up to the back of the church off of Guidy. Ask for Eric Gilmore and any of his volunteers.  They can assist you with a spot.  If you plan to go to the graveside service,  we can fit you in a fire vehicle. Be warned that you may not return to the church before 3 pm. 

**Janice Gilley**: You already know most of that. 😉 

**Jeff Bergosh**: Thank you very much Janice

**Janice Gilley**: Sir, here are photos of the location of the parking spots.

**Janice Gilley**: Here is where you will come in off Guidy

**Jeff Bergosh**: Got it, on way

**Janice Gilley**: [Auto Reply] I am attending the Dwain Bradshaw ceremonies and unavailable. I will respond as soon as available.  Thank you. 

### CONVERSATION ON 11-13-2019

**Janice Gilley**: Sir, we are going into day 2 of our bargaining with the ECAT ATU. Please do not be surprised if you hear that their leader is not happy.  Your team is working to do right by not only you and the employees, but also the taxpayers and the riders.  An executive session is scheduled for Monday to give you a status update on all 5 CBAs. 

**Jeff Bergosh**: Thanks very much for the heads up!

### CONVERSATION ON 11-14-2019

**Jeff Bergosh**: Janice--do u have a minute for a quick question, for a call?

### CONVERSATION ON 11-26-2019

**Janice Gilley**: FYI. Cedric Alexander is being appointed to ECUA today. Governor office called. 

**Jeff Bergosh**: Thanks for the heads up.  Good for Cedric, he's a nice guy

### CONVERSATION ON 11-27-2019

**Jeff Bergosh**: Did Dr. Edler submit any answer to the harassment complaint which was due by COB yesterday?

**Janice Gilley**: I am waiting for a call back from HR to see if they have any documents. 

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Has anyone asked Matt Selover if he is going to provide comment?  I don't believe he intends on doing this

**Janice Gilley**: I was not part of that process, but it is my understanding that both parties were told of the five day response timeframe. 

**Janice Gilley**: I will check

**Jeff Bergosh**: I've spoken to Matt Selover and he has already provided his comments

**Jeff Bergosh**: To you, HR, and John Dosh according to what he told me

### CONVERSATION ON 12-02-2019

**Janice Gilley**: Hope you had a nice Thanksgiving.  Wanted to touch base, HR did receive a response from Dr. Edler on Tuesday.  

**Jeff Bergosh**: Thanks Janice, hope you had a good Thanksgiving as well.  Does the 10 day clock start for releasing Spainhower's 6-24-19 report start today as previously discussed?

**Janice Gilley**: Yes sir. 

### CONVERSATION ON 12-04-2019

**Janice Gilley**: Sir, We have a Paramedic that has been arrested for domestic violence. His name is Mike Murphy.  He has not notified us, but social media has. 

**Janice Gilley**: And we verified that it is him. 

**Jeff Bergosh**: That's a shame to hear but thanks for the heads up.  Do you think it will hit the news media?

**Janice Gilley**: Yes sir. 

### CONVERSATION ON 12-06-2019

**Janice Gilley**: Sir, EMS is responding to an active shooter situation onboard NAS.  I will keep you updated. 

**Janice Gilley**: Shooter is down.  

**Janice Gilley**: Escambia Public Safety is at the base gate ready to set up Mass Casualty and Trauma Incident Command if requested by NAS. 

**Janice Gilley**: If the commissioners would like to write a statement, we can post to each of their Twitter accounts and retweet from the County. Email statement to cmr@myescambia.com

### CONVERSATION ON 12-07-2019

**Janice Gilley**: I wanted you to be aware that Engine 16 was involved in an accident. They hit a vehicle, the vehicle hit a house. There is structural damage at 3385 Barrancas & County Club Drive. A patient was transported to the hospital. FHP is in route. At this time, it appears that the car was at fault. No injury to our staff or fire engine reported at this time. I will keep you updated later this morning if there is anything new to share.  

**Janice Gilley**: Sir I wanted to make you aware that the Escambia EOC is becoming the joint information center for the FBI. Your staff was there late last night and back again early this morning.  We will be letting the press in at approximately 8:00 a.m. We will keep you updated throughout the day with talk points for your consideration and any information that we believe will be helpful to you.  

**Jeff Bergosh**: Thank you Janice!

**Janice Gilley**: Here is an update from the EOC:  They are getting a later start than we discussed.  FBI will brief at 8 at NAS and all further briefings will be at EOC starting between 10-12. 

**Janice Gilley**: I am very aware of the EMS Murphy situation and can answer your  questions.  

**Jeff Bergosh**: Thanks

**Janice Gilley**: Sir, we are sending regular updates to your District email. Let me know if we should use a different email address.  

**Jeff Bergosh**: Thanks that's perfect.  Thanks for keeping us posted

### CONVERSATION ON 12-08-2019

**Jeff Bergosh**: Good morning Janice.  Are you at the EOC by chance?

**Janice Gilley**: I'll call you back.

**Janice Gilley**: Sir, this is not for public disclosure yet, but you have been invited to participate in a press conference with the Governor at the EOC at 4 pm Central. Please let Laura and I know if you will come. She is copied on this text. 

### CONVERSATION ON 12-09-2019

**Janice Gilley**: Just FYI, we have been taking measures to protect our County network for most of the weekend.  We are hopeful that our proactive work will keep us safe from cyber issues. I can share more tomorrow.  

**Jeff Bergosh**: Jennifer Munoz from ch3 will be calling

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: Janice I'm trying to reach you and your mailbox is full just for your information. I'm calling to check on the status of the emails and the information that I requested at our meeting to days ago. I had her anything back from you Jana or anyone and I want to know the status of getting the documents I requested and also the status of getting my questions that I left with you answered please advise soon

**Janice Gilley**: Can you speak now?

**Jeff Bergosh**: Yes

### CONVERSATION ON 12-27-2019

**Jeff Bergosh**: FYI

**Janice Gilley**: [Auto Reply] In the woods and unavailable.  Thank you. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: Janice:

Karen Stewart Wood------a 28 year Paramedic Supervisor that endured horrific harassment and mistreatment in EMS before she was forced out of her job that she loved --------would really like to speak with you about what happened to her. And about how our policy was not followed.   Her telephone number is

850-554-9657

Would you please give her a call and hear her out?

**Janice Gilley**: Yes sir. 

**Jeff Bergosh**: Thank you I spoke to her today and she will be expecting your call

**Janice Gilley**: I spoke with Ms. Wood today. We will be meeting with her. 

**Jeff Bergosh**: Thank you 

### CONVERSATION ON 02-29-2020

**Jeff Bergosh**: Janice - I'm very concerned about the way several volunteer firefighter trainees have been run out by ECFR.  Have you spoken with Kyle McCullough, he says he reached out to you with the information he gave me.  I'm disgusted and I want to know what we can do about it.  IAFF on one hand say they welcome volunteers but they are actively working to undermine them according to what I have now learned.  They even went so far as calling the volunteers' employer to discourage participation.  This is outlandish!!!!

**Janice Gilley**: Yes sir. I have met Kyle several times. He is a fine young man. I have asked Keith Morris to get with him and interview him before he leaves about the continued concerns. I agree with you.  On a tangential note, we got over 100 applications for Public Safety Director. The right strong leader in that department will be able to make needed improvements and change. 

**Jeff Bergosh**: Agreed 

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: A number of people are asking and I don’t know the answer

**Janice Gilley**: No sir. Not the pier

**Janice Gilley**: It is run by a vendor though.

**Janice Gilley**: He can decide what to do. 

### CONVERSATION ON 04-17-2020

**Janice Gilley**: Sir, FYI, I will be out of the office due to illness today. It is NOT COVID related. 

**Jeff Bergosh**: Okay thanks hope you're feeling better!

### CONVERSATION ON 05-20-2020

**Janice Gilley**: Rick Harper is a yes for June 3rd. I am getting the email he wants to use for the invite. 

**Jeff Bergosh**: Awesome thank you Janice!

### CONVERSATION ON 06-30-2020

**Jeff Bergosh**: Just found out about this via Facebook 

### CONVERSATION ON 08-03-2020

**Janice Gilley**: Chief Powell says yes. He will see if the medical staff is available too. 

**Jeff Bergosh**: Outstanding!  Thanks Janice!

**Jeff Bergosh**: Looks like they'll be coming to our meeting as well

### CONVERSATION ON 08-18-2020

**Janice Gilley**: Congratulations! Hope you get some rest and have a nice, safe trip. 

**Jeff Bergosh**: Thank you Janice!!!!

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: Please call me when u can--important

**Janice Gilley**: [Auto Reply] I am currently in the EOC responding to Sally. I will respond as soon as available.  Thank you. 

### CONVERSATION ON 09-20-2020

**Jeff Bergosh**: Good morning Janice.  I have an elderly, single woman who lives on Jackson Street and has had on power for multiple days.  I'd like to bring her a care package of supplies if that is possible (Ice, water, MRes). Is there some of these items at the EOC I could pick up and deliver to her?

**Jeff Bergosh**: She lives at 1816 W. JACKSON Street

**Janice Gilley**: Name

**Jeff Bergosh**: 292-0818. Jroanne Bergman

**Janice Gilley**: Thank  you 

**Jeff Bergosh**: Thank you

**Janice Gilley**: Ms Bergman has her supplies.

**Jeff Bergosh**: Thank you so much Janice for doing that she's a really sweet lady and she has no one helping her again thanks to you and your staff for stepping up

### CONVERSATION ON 09-21-2020

**Janice Gilley**: Hey, I was in the briefing. Call when you can if you need me.n

**Jeff Bergosh**: Thanks Janice-- was just trying to find out if FEMA will pick up debris from private roads and streets.  Like inside Nature Trail or on private roads along Frank Reeder Road.  Do you know the answer on this?  Thanks Janice

**Janice Gilley**: Sir, If the private roads are behind a locked gate the answer has been a definite No. We are still working through whether or not a private road without a gate is a No.  

**Janice Gilley**: All that being said, we are asking for clarification so we have it in writing. 

**Jeff Bergosh**: Okay thanks for that.  So what should I tell constituents in Nature Trail---- huge subdivision with lots of debris.  They have a gate and a gate guard.   I'm sure if they see debris cleanup trucks coming-- they'll open the gate

### CONVERSATION ON 09-22-2020

**Jeff Bergosh**: Do you have a moment to talk this morning?  I'm going in the radio at 8:35 and just wanted some additional information before I go on

**Janice Gilley**: Yes sir. Is 8:15 good?

**Jeff Bergosh**: Perfect-- thx

**Janice Gilley**: contact Crisis Cleanup at 800.451.1954

▫	Florida Baptist Disaster Relief is also available to assist with debris cleanup, mucking, tarp installation and mold remediation – 904.253.9924



### CONVERSATION ON 10-28-2020

**Jeff Bergosh**: Thanks Grover

**Janice Gilley**: We will work on this ASAP.

**Janice Gilley**: There are trucks in the area picking up.  

### CONVERSATION ON 03-29-2021

**Jeff Bergosh**: Hi Laura hi Janice my brother circuit court judge Gary Bergosh will also be attending today's ribbon-cutting I'm just calling to see if we can set a chair up for him as well so that he can join us please advise and thank you!

**Janice Gilley**: We are planning to recognize him for sure.  I am almost there and will look for a chair.

