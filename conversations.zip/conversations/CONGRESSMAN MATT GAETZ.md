

## CONVERSATIONS WITH CONGRESSMAN MATT GAETZ

### CONVERSATION ON 04-17-2020

**Jeff Bergosh**: Good Morning Congressman Gaetz—thanks for your service and all you are doing for NW Florida as our Representative.  I’m reaching out to you this morning to see if you would join me, our County Administrator, and our Emergency Manager on a Zoom livestream on Wednesday morning, April 29th.  I do a weekly “coffee with the commissioner event” on Facebook and I have had all three of the CEO’s of Pensacola’s hospitals on over the last three weeks and it has been very well received.  Lots of questions and great answers on the medical side of the Chinese Coronavirus. Now that we are transitioning to re-opening the county, state, and country—I know there would be a lot of constituent questions and a great discussion about recovery and the federal role moving forward.  We do it early 6:30-7:30 AM central—so thanks in advance for considering it and I hope you could carve out a little time to participate.  If you can and are willing, I just need to know what address to send the Zoom invite to.  And again—thanks for all you do!

Sincerely,

Jeff Bergosh 
County Commissioner District 1

**Jeff Bergosh**: Yes

**Jeff Bergosh**: We’ve Been doing them all digitally on zoom and then live streaming them on Facebook so that constituents can ask questions in real time but yet we can all be safely socially distanced

**Jeff Bergosh**: Okay thanks, sounds good!

### CONVERSATION ON 04-29-2020

**Jeff Bergosh**: Thanks for participating!

**Jeff Bergosh**: Thank you very much Matt that was a great great question and answer session —-and if you’re ever available man I’d love to have you on again!!!

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Congratulations on your re-election Congressman Gaetz!!

### CONVERSATION ON 12-15-2020

**Jeff Bergosh**: Understand totally.  I just wanted to run an idea by you for this Holiday Season—- with so many Americans planning on travel and so many Governors in blue states restricting travel and stifling families from enjoying the holidays —-I just thought if you had any “in” with the President It would be a great way for him to go out: freeing America for Christmas and New Year’s 2020 by proclamation nullifying the powers of the bully governors to kill Christmas this year.  Wouldn’t that be great?  A pardon for Americans from these hypocrite Governors like Newsome.  We shouldn’t feel like criminals traveling between states to visit family for Christmas.

I hope you have a very merry Christmas with your family!

Jeff Bergosh

