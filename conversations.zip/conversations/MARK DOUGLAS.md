

## CONVERSATIONS WITH MARK DOUGLAS

### CONVERSATION ON 12-13-2019

**Jeff Bergosh**: Mark it was great meeting you and speaking with you thank you very much for playing golf with us today and thank you for the photo. I look forward to talking to you again.

