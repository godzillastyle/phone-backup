

## CONVERSATIONS WITH BOB STERRIKER

### CONVERSATION ON 03-09-2020

**Jeff Bergosh**: Sure Bob

**Jeff Bergosh**: Do you have a minute to chat?

**Jeff Bergosh**: Alright

**Jeff Bergosh**: Sure, I’ll be here.  No problem

