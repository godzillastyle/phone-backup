

## CONVERSATIONS WITH PASTOR GORDON GODFREY

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: Thank you so much Pastor Godfrey!

**Jeff Bergosh**: Sally and I be there at the event— and I don’t want any recognition but I certainly hope that you will give the recognition deserved to Sheriff Morgan the Escambia County sheriffs office and our EMS units that were the true heroes today that stopped the threat and saved lives

**Jeff Bergosh**: Thank you Pastor!  

### CONVERSATION ON 06-19-2020

**Jeff Bergosh**: Thank you Pastor Godfrey!

### CONVERSATION ON 06-24-2020

**Jeff Bergosh**: Pastor Godfrey thank you—I loved the conversation and greatly appreciate you!!!

