

## CONVERSATIONS WITH SUSAN SANDERS

### CONVERSATION ON 11-08-2019

**Jeff Bergosh**: Good morning Susan this is Jeff Bergosh and I wanted to let you know the board approved the $1000 sponsorship of your Veterans Day event today. We approve it at last nights meeting. I am planning on attending your function today and I am bringing my son Nick who is in the Navy he’s here in town visiting. I just need to know what time the event starts can you please let me know and text it to me?

