

## CONVERSATIONS WITH DEER RUN RESIDENT

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: School Board Member for D1

**Jeff Bergosh**: 👍

