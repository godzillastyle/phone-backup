

## CONVERSATIONS WITH BRUCE WOODY

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Bruce, I just sent this to Vicki.


Hello Vicki— I am getting numerous angry emails about the proposed ECUA Transfer Station at Pine Forest Road.  Although we are not approving the Transfer Station tonight— a lot of folks believe we will be.  I would appreciate it if you, Bruce and your project manager could attend our meeting this evening to answer these folks that will be coming to speak.  Let me know who from ECUA will be here at our meeting tonight to handle this

