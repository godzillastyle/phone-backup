

## CONVERSATIONS WITH ANDREW MCKAY

### CONVERSATION ON 11-25-2019

**Andrew MCKay**: So if I understand you correctly, the sunshine law means you can never talk to  anyone about anything unless you are on the dais at a properly advertised meeting.   Do I have it right?   =)

**Jeff Bergosh**: According to some self proclaimed Facebook experts, yes🙂

**Jeff Bergosh**: ........which of course is ridiculous

**Andrew MCKay**: =)

### CONVERSATION ON 12-19-2019

**Jeff Bergosh**: I was somewhat inartful in the way I described my proposed solution to Partisan impeachment on your show just now. If they wanted to fix it and make sure it never again happens unless it's truly bi-partisan ---the constitutional amendment could specify that in order for impeachment to move forward from the house of representatives  the articles must be approved by a majority vote which MUST include no less than 25% of the membership of the minority party

**Jeff Bergosh**: This way neither party could Weaponized impeachment as I fear will happen going forward

**Andrew MCKay**: Interesting point on future demographics.   You're always welcome here.  =)

**Jeff Bergosh**: Thx Andrew

### CONVERSATION ON 01-27-2020

**Andrew MCKay**: Do you know the name of the design firm for bellview library?
When do you think the project will be complete?  

**Jeff Bergosh**: STOA

**Andrew MCKay**: Thx

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/tomorrow-dr-john-lanza-will-join-me-for.html?m=1

Andrew:  I am going to have Dr. Lanza on as my special guest tomorrow for my live Facebook coffee with the commissioner event. It starts at 6:30 AM and he will be taking questions live on Facebook. If you have any questions you would like for me to ask him please send them or you could participate yourself by tuning in if you'd like. Hope all is well

**Andrew MCKay**: Thanks! 

**Andrew MCKay**: Useful service would  be for Lanza to give clear COVID-19 vs allergy symptom guidance.  Also COVID-19 vs flu and cold, but I know that's muddier.

### CONVERSATION ON 04-03-2020

**Andrew MCKay**: Happy birthday yesterday!

**Jeff Bergosh**: Thx

### CONVERSATION ON 04-08-2020

**Andrew MCKay**: Dude you gotta change your morning radio listen.   I reported the sterilization machine heavily after Faulkner told you that last week  And the "overnight" executive order you and Lanza hadn't seen last time we had reported that all morning that day.  =)

### CONVERSATION ON 04-09-2020

**Jeff Bergosh**: I listen I just missed that segment apparently.  

**Andrew MCKay**: Listen to 4 hours!  =)      
The coffees are very useful.  Keep them up.  

**Jeff Bergosh**: LOL I have to work at some point!!! Thanks for the compliment Andrew.  I will have Gay Nord on from West Florida Hospital next week--should be a good discussion.  

### CONVERSATION ON 04-16-2020

**Andrew MCKay**: THANK YOU for calling in.  I should have asked you last night to be on so we could talk about it.  That's my fault.  

**Jeff Bergosh**: Thanks Andrew!  I'm always available; like you I'm an early riser👍

**Andrew MCKay**: And also I do appreciate the coffees.  It's been very good information.  
What time do you get on base?  7?

**Jeff Bergosh**: Typically between 6:15-7:00

**Jeff Bergosh**: Thanks for the compliment on the coffees

### CONVERSATION ON 04-22-2020

**Andrew MCKay**: Good coffee w Commissioner today!

**Jeff Bergosh**: Thx Andrew--some good discussions.

### CONVERSATION ON 05-27-2020

**Andrew MCKay**: Maybe some local media didn't cover it....NewsRadio, however...¿¿https://m.facebook.com/story.php?story_fbid=3447829221912767&id=121233071239082¿¿And at least once in an interview ¿¿http://podcast.newsradio1620.com/post/6239/Alex_Andrade_-_Florida_State_Rep_District_2.html 

**Jeff Bergosh**: Glad that you did--that was a powerful win for school districts!

**Andrew MCKay**: Huge!  I also was surprised no one else seemed to notice a huge financial win for Escambia.   

**Jeff Bergosh**: Yes it was!

### CONVERSATION ON 06-03-2020

**Andrew MCKay**: Very productive coffee this morning!   Robot tax...
fascinating! 

**Jeff Bergosh**: Interesting to think about, right?  If the robots are doing all the work who's gonna pay the costs for the universal basic income? 😎

**Andrew MCKay**: Just so long as the robots never become self aware....

**Jeff Bergosh**: Exactly, because then we'll have Skynet.

**Andrew MCKay**: Don't say its name out loud!

### CONVERSATION ON 06-24-2020

**Andrew MCKay**: Outstanding coffee today.  Wonderful idea to have all the baptists on.  Great stuff!

**Jeff Bergosh**: Thanks Andrew!

### CONVERSATION ON 07-24-2020

**Andrew MCKay**: Thank you!

**Jeff Bergosh**: Absolutely!

### CONVERSATION ON 08-03-2020

**Jeff Bergosh**: Also-- what is the format- what are the ground rules if you don't mind letting me know......thx!

Jeff Bergosh

**Andrew MCKay**: 530.  Let me double check.  I have a call today on format.  

**Jeff Bergosh**: 👍

**Andrew MCKay**: 530 confirmed. 
I think the format plan is same as 2016...40 seconds per answer.  

**Jeff Bergosh**: Perfect.  Thanks

### CONVERSATION ON 08-18-2020

**Andrew MCKay**: Congratulations.   Ready to take an in air victory lap?

**Jeff Bergosh**: Sure!  Thanks Andrew

### CONVERSATION ON 09-21-2020

**Andrew MCKay**: Hey sir.  Do you want to be on tomorro to talk about D1 impact and restoration?  I have 835 open. 

**Jeff Bergosh**: Sure.  Thanks Andrew

**Andrew MCKay**: Of course!

### CONVERSATION ON 09-22-2020

**Jeff Bergosh**: Andrew:  any chance we can use Corey Taylor's "Black Eyes Blue" as intro music this morning?

**Andrew MCKay**: Got it. 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Thx

**Andrew MCKay**: Thank you! 

**Andrew MCKay**: http://newsradio1620.com/podcast/09-22-20-jeff-bergosh-escambia-county-commissioner-district-1/

### CONVERSATION ON 10-07-2020

**Andrew MCKay**: Another productive CWTC today.  Good stuff. 

**Jeff Bergosh**: Thanks Andrew!

### CONVERSATION ON 11-25-2020

**Jeff Bergosh**: It's like on the plane "install the oxygen mask on yourself first and then on your children next" 

**Andrew MCKay**: I like that.  Do you want to call or I can just quote you?

**Jeff Bergosh**: You could just quote me I just thought it was an interesting analogy or metaphor

**Andrew MCKay**: Agreed.  Especially if we are the real rescuers of the world.  Our econ is the global first responder of sorts 

### CONVERSATION ON 12-09-2020

**Jeff Bergosh**: Andrew: it's not as simple as you make it out to be and I think your presentation this morning was out of context and ignored several very important facts related to the development kind of disappointing

**Andrew MCKay**: I know you head to work now, but I'd be glad to give you time to respond..   I have 708 or 718 open.   I'd do it now but we are crammed on time. 

**Jeff Bergosh**: 7:08

**Andrew MCKay**: Perfect.   Call at 706

**Jeff Bergosh**: 
👍

**Jeff Bergosh**: Intro music or no?  LOL

**Andrew MCKay**: Sure!  What do you want?  Christmas metal?

**Jeff Bergosh**: Absolutely!!

Band "A Day To Remember"
Song. "Holdin' it down for the underground"

**Jeff Bergosh**: Thanks!

**Andrew MCKay**: Thanks!   Good segment.

**Jeff Bergosh**: Thanks for allowing the rebuttal

**Andrew MCKay**: Always

### CONVERSATION ON 12-15-2020

**Andrew MCKay**: You should listen now.  

**Jeff Bergosh**: Thanks for airing that and putting it in the proper context.  I appreciate that!

**Andrew MCKay**: Of course! 

### CONVERSATION ON 01-11-2021

**Jeff Bergosh**: We didn't approve that deal

### CONVERSATION ON 01-12-2021

**Andrew MCKay**: Hey FYI I'm talking here about the lake Charlene and Doug's absence stuff here at 638.  

**Jeff Bergosh**: Thx for heads up

**Jeff Bergosh**: I'll comment if you'd like

**Andrew MCKay**: I actually meant to call you last night but time got away from me with the football game

**Jeff Bergosh**: Tell me when

**Andrew MCKay**: Right now I'm covering it

**Jeff Bergosh**: Can I comment to clarify my position?

**Andrew MCKay**: Sure if you think I miss it.  After

**Jeff Bergosh**: K thx

**Jeff Bergosh**: I certainly want to weigh in

**Andrew MCKay**: Ok you can call now if that works for you.  

**Jeff Bergosh**: Will do

**Andrew MCKay**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-19-2021

**Andrew MCKay**: Sorry about not getting the CSC spot.  Given how you agreed to let Lumon take the Board slot, that stinks.    

**Jeff Bergosh**: Thanks Andrew -- but it is not surprising to me.  I know it would've been a difficult choice to put two commissioners on this board. And I knew that when I stepped aside for Lumon. Nevertheless---I'm thrilled for those who were selected; I think this board is solid and they're going to do some great things for our community!

**Andrew MCKay**: Well that's certainly magnanimous of you to say, but i still think it's a snub and given your history and passion for the issue it's unfortunate.   

**Jeff Bergosh**: That's nice of you to say, thanks Andrew.  There were some powerful names on that list; happy that my first two selectees, Tori Woods and David Peaden got seated.  I think they'll do great things.  And I look at it like this: just because I'm not on that board--- does not mean I won't be involved--because I plan to be. 😎👍

**Andrew MCKay**: Thats certainly appropriate!   =)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Have a great weekend!

**Andrew MCKay**: You too.

### CONVERSATION ON 03-24-2021

**Andrew MCKay**: 7 member board?   Intriguing.  Wanna talk about it premeeting tomorrow?  I have 618 open or 718 your preference. 

**Jeff Bergosh**: Sure.  How about 6:18

**Andrew MCKay**: Perfect talk then 

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: Good Morning Andrew.  Any chance I could request the song "Life on Standby". By the band Hawthorne Heights?  Good, gentle, relaxing melody for your morning listeners...🙂

**Andrew MCKay**: Haha.  Davis was jist asking me.  Sure.  

**Andrew MCKay**: We are ready if you want to call

**Andrew MCKay**: Thanks perfect

**Jeff Bergosh**: Thank you Andrew!

### CONVERSATION ON 04-07-2021

**Andrew MCKay**: I was just calling to get your opinion of the diverging diamond at 9 mile.  Not urgent. 

### CONVERSATION ON 05-14-2021

**Jeff Bergosh**: Thank you for covering this!!!

**Andrew MCKay**: Absolutely.   It's atrocious.   Thank YOU for covering it.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-07-2021

**Andrew MCKay**: I've read your blog. Do you want time to respond in the morning?  635?

**Jeff Bergosh**: Thanks Andrew- but there's nothing to respond to.  My blog post on this topic is my complete statement on this matter.  👍

**Andrew MCKay**: I understand.

### CONVERSATION ON 06-15-2021

**Jeff Bergosh**: Andrew just for clarification purposes I believe Commissioner Barry said that was insulting in reply to a quip that was made by the budget Director about something in her opinion not looking good politically.

**Jeff Bergosh**: Of course I do not presume to speak for him that was my impression from the conversation. You should watch that particular exchange again for context.

**Andrew MCKay**: Yes agreed.  Her comment numbers don't lie was said too close in proximity to his reply for that to have been what he was reacting to.  

**Andrew MCKay**: He didn't have enough time to have been reacting to the 2nd bit.

**Jeff Bergosh**: I like Amber I think she does a decent job. And I think she walked it back professionally after he reacted. I think she walked it back by saying look I'm making the presentation here's the presentation. That was the smart play

**Andrew MCKay**: Agreed 

**Jeff Bergosh**: 👍

**Andrew MCKay**: Were you at the swearing in yesterday?  I know the city isn't in your district, but if I missed you I apologize.  

**Jeff Bergosh**: Unfortunately I could not make that event.

**Andrew MCKay**: No worries.   I just try to mention who's there and I didn't want to not if you had been. 

**Jeff Bergosh**: Thx for that

### CONVERSATION ON 07-23-2021

**Jeff Bergosh**: If you saw the Rolling Stones in 1989 that would've been the steel wheels tour that they were on with guns and roses and living color. I actually saw that show at the LA Coliseum and it was amazing. If they come anywhere near Pensacola including New Orleans it would be a show to see!

**Andrew MCKay**: Yes steel wheels and yes they were fantastic..  but oh man do I have a story to tell you about that concert. 

**Jeff Bergosh**: I remember they finished the show with honky-tonk women and they had these gigantic inflatable blowup dolls on either side of the stage and has a 21-year-old I thought wow these guys in their 50s are really putting on a hell of a show! Now they're in their 80s lol

**Jeff Bergosh**: I'd love to hear it!

**Andrew MCKay**: Omg i had forgotten about the inflatables!  Hahahshaha.

**Jeff Bergosh**: 😁👍

**Jeff Bergosh**: Backed up over the bridge

**Andrew MCKay**: Thanks!  

### CONVERSATION ON 08-18-2021

**Andrew MCKay**: Do you know when Belleview library is scheduled to be done?

**Jeff Bergosh**: Early Spring 22

**Andrew MCKay**: Thx

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-03-2021

**Jeff Bergosh**: Cabron is a Spanish cuss word....

**Andrew MCKay**: Haha I didn't know that.   

**Jeff Bergosh**: Means bastard

**Jeff Bergosh**: LOL

**Andrew MCKay**: Thats gonna have to  become my go to imprecation.

**Jeff Bergosh**: 😂

**Jeff Bergosh**: Que Pasa, Chango?

**Andrew MCKay**: Small boy?

**Jeff Bergosh**: Monkey

**Andrew MCKay**: Ahhhh...

### CONVERSATION ON 09-13-2021

**Andrew MCKay**: Do you want to be on tomorrow to talk about your ECFR ideas?  I have 805 open.  

**Jeff Bergosh**: Sure!  Thanks 

**Jeff Bergosh**: Want me to call, or u call me?

**Andrew MCKay**: If you call us it's easier for us.   437 1620.  Call at 805, we'll be on air at 809.  Celine Dion bumper music?   =)

**Jeff Bergosh**: LOL Celine Dion??  How about the band Hatebreed and the song "Remain Nameless". That'll wake the listeners up

**Jeff Bergosh**: I'll call at 0805

**Andrew MCKay**: Cool.  Talk then.

### CONVERSATION ON 09-14-2021

**Andrew MCKay**: We get 30 minutes into a 120 minute

**Andrew MCKay**: 12 minute interview!

**Andrew MCKay**: Thank you, as always.

**Jeff Bergosh**: Thanks Andrew!

**Andrew MCKay**: https://www.newsradio923.com/podcast/09-14-21-jeff-bergosh-escambia-commissioner/

**Jeff Bergosh**: Thanks!

**Andrew MCKay**: I'm listening to today's meeting and i have a question..  Was your request for jazz fest to come out of this year's funds?  It sounded that way to me but I wanted to double check and not assume. 

### CONVERSATION ON 09-15-2021

**Jeff Bergosh**: No, I want to see about having that event funded directly through the budget process next year. It's already happened this year

**Andrew MCKay**: Okay, that makes more sense.   Cuz it sounded like you were trying to add it to this year, but I couldn't reconcile that with your repeated emphasis on applicants not getting money who didn't apply on time.  So they were already funded this year, and you were advocating for them to get money again next year, right?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: In a more straightforward manner as they have proven themselves with their track record

**Andrew MCKay**: Gotcha thx.  

**Jeff Bergosh**: 👍

**Andrew MCKay**: Do you happen to have a 2000 district map?  I went looking and couldn't find one.

**Jeff Bergosh**: Stafford is going to bring one.  I have a PNJ article from '93 that shows it partially.  I'll email it to you.  What's your email address?

**Andrew MCKay**: Perfect. Andrew@newsradio1620.com 

