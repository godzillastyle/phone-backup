

## CONVERSATIONS WITH LUMON MAY

### CONVERSATION ON 12-26-2019

**Jeff Bergosh**: Merry Christmas Lumon!

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Just picked up 127 more envelopes from Evergreen.

### CONVERSATION ON 02-21-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-18-2020

**Jeff Bergosh**: Hey Lumon-great job today with the press conference!

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Congratulations on your great win tonight Lumon!!  I look forward to working with you to make our community as best it can be over the next four years!!!!

### CONVERSATION ON 08-23-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: We’re playing phone tag!  

### CONVERSATION ON 09-04-2021

**Jeff Bergosh**: On way now

**Jeff Bergosh**: We’re on at 6:00 right?

**Jeff Bergosh**: Where’d u park?

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-05-2021

**Jeff Bergosh**: We are here and seated already thank you!

