

## CONVERSATIONS WITH STEVE STROBERGER

### CONVERSATION ON 05-22-2020

**Steve Stroberger**: I know your busy. Can you take a short call?

**Steve Stroberger**: Steve Stroberger

**Steve Stroberger**: The email should be in your inbox now.

**Steve Stroberger**: Apparently he’s already been on Facebook admitting he’s the one who releases the shade meeting docs.

**Jeff Bergosh**: Thanks

**Steve Stroberger**: Here’s the screen shot. The post on Facebook that started it all.

**Steve Stroberger**: These following three screen shots are from the Innerarity Island Sewer Project Facebook page. Underhill’s post.

**Steve Stroberger**: Actually there were four.

**Steve Stroberger**: Umm...numb nuts can’t stop himself.

**Steve Stroberger**: He’s on Facebook now.

**Steve Stroberger**: He’s looking out for the public good. Underhill thinks he’s Edward Snowden and may be booking a flight for Moscow soon.😀

**Steve Stroberger**: Just to stir the pot, he’s saying that Barry and May lied. Does he spend all his time Facebooking?

**Steve Stroberger**: Okay, I’m out. Sorry.

**Jeff Bergosh**: He’s a strange bird that’s for sure!  Thanks for this info!

### CONVERSATION ON 05-26-2020

**Steve Stroberger**: Underhill said he’s  going on the Burnie Thompson show tonight at 5:35p.

### CONVERSATION ON 05-30-2020

**Steve Stroberger**: I’m having second thoughts about having you invite Gene Valentino to the BOCC. I don’t want Underhill to turn this into his political shit show. I think Gene would be compelling, but I think Underhill would just say his political enemies are after him, again. Thoughts?

**Steve Stroberger**: Also, we won’t be ready for the upcoming BOCC. I’ll be attending the 18 Jun BOCC. How do I get our issue on the 18 June agenda?

**Jeff Bergosh**: I’ll work on that from my end.  I’ll request Alison Rigers bring it for discussion under her portion of the agenda

### CONVERSATION ON 06-02-2020

**Steve Stroberger**: Do you know what that asshole Underhill is up to? He’s been changing the narrative. He’s now a champion for island residents. On the Burnie Thompson podcast he says regarding the shade docs, “We are about to hit these citizens with the largest MSBU ever in this county. They have a right to know what happened to them.” Now he’s having the Innerarity Island sewer project added to the agenda this Thursday. I think he highjacked my call with Doug Broxson last Thursday (he knew about it) so he can tell everyone this Thursday he’s either got grant money for the sewer or he’s working on it w/o the other county commissioners because they’re (you) hiding something and won’t release the shade docs. The dam docs are already out there, but he’s playing this up like the other commissioners are a bunch of crooks. This is him trying to help Owens with his election with you.

### CONVERSATION ON 06-03-2020

**Jeff Bergosh**: He is a real piece of work!  People see through what he’s done here though.

### CONVERSATION ON 06-08-2020

**Steve Stroberger**: Has Alison Rogers put the Innerarity Island sewer project on the agenda for the next BOCC? I’m coming back on the 18th with all my neighbors.

**Steve Stroberger**: Also I’ve decided that having Gene Valentino talk on our behalf will be beneficial. He’ll be there separately and on his own volition. So I’m requesting that you invite Gene. Underhill can make this political, but he won’t escape is own stupidity and frankly I can’t wait to see his foot in his mouth again. He’s the one bringing Gene into this conversation on Facebook and in the BOCC. Will you invite Gene?

**Jeff Bergosh**: Sure will

**Steve Stroberger**: Thanks. BTW I hope you and the rest of the commissioners recognize that Underhill is where my ordnance is targeting.

### CONVERSATION ON 06-17-2020

**Steve Stroberger**: Jeff, I didn’t see our issue on the agenda tomorrow. I asked Joe Ward to ask you if it was going to be an add-on, and it is not. What gives? I’ve got 40-55 people coming and the Open Forum is a waste of time. Please add it yourself or have Alison Rogers do it as you said you were. If your concerned about Gene Valentino’s attendance don’t be. He’s not going to be there. 

This issue is not going to go away by ignoring it.

### CONVERSATION ON 06-20-2020

**Jeff Bergosh**: Good morning gentlemen: My inbox is blowing up from residents of Innerarity Island that do not want all lots sold, do not want them sold quickly, and apparently appear to be supporting Doug Underhill’s plan of a massive MSBU to be put on the residents of the island. They are saying that the folks at the meeting in the blue shirts do not speak for the majority of the residents. What is this all about? Is this Doug and Johnathan at work trying to stir up a ruckus? Please let me know as soon as possible— without a clear path and a clear consistent direction from residents ———I’m worried that we can’t make this a manageable cost for you.  Please advise....

**Steve Stroberger**: 
Jeff, nobody wants all the lots sold in a fire sale. And nobody wants Seascape sold off to pay for this sewer system that ECUA wants given to them gift wrapped. Underhill has been online disparaging Joe and Rod. Saying Joe single handily got us in this situation and Rod, who has been probably the one person actually trying to preserve Seascape, is now the scapegoat for selling off Seascape. Ridiculous! Those residents have been fooled into thinking that Seascape was going to be preserved, when it has been Underhill’s intention to sell it off to his Terra Firma buddies all along. He thinks this is his break though and he now has permission to do it. He’d been threatening to sell off Seascape on Facebook.

**Steve Stroberger**: Your right Jeff. Underhill has been working to divide this island and he has played the HOA Board and its supporters into thinking that they could keep Seascape and limit homeownership on Innerarity. Those few want to pay an outrageous MSBU and service their own grinder pumps. The majority of supporters want ECUA to have some skin in the game. They have in Beach Haven and other places. It’s also their job to get funds for projects just like this one. You know the Beach Haven issue, they received more than $5M in grants and ECUA put almost $2M into that community. 

**Jeff Bergosh**: I want to be helpful—and I will be.  I’ll be waiting with interest to see what this price tag will be in Early September......and I’ll attempt to bring a solution that’s fair.  I just need to know who speaks for Innerarity, the majority of Innerarity?

**Steve Stroberger**: That’s a more complicated question than you think Jeff. I’m going to respond via separate correspondence.

### CONVERSATION ON 10-08-2020

**Steve Stroberger**: The residents of Innerarity Island thank you.

Steve Stroberger

**Jeff Bergosh**: Thanks Steve— but for what?

**Steve Stroberger**: Radio this morning about Innerarity Island debris removal.

**Jeff Bergosh**: 👍

**Steve Stroberger**: While my neighbors are so willing to take no for an answer, I’ve been lobbying my ass off. Thanks again. Glad it wasn’t Doug on the radio.

**Jeff Bergosh**: Thanks Steve.  Yes, I definitely agree it’s BS for them to not pick up from private neighborhoods when FEMA money comes in

**Jeff Bergosh**: We all pay federal tax

**Steve Stroberger**: Yes we do. I’ll stop calling Janice Gilley’s office now.

### CONVERSATION ON 12-02-2020

**Steve Stroberger**: Jeff, this is Steve Stroberger. This is my new mobile number. I’m getting ready to give you a call.

### CONVERSATION ON 12-14-2020

**Steve Stroberger**: Hey Jeff. I’m going to be out of town beginning Friday until the first week in January, can we get together this week? I can meet you on the base if that’s convenient.

### CONVERSATION ON 12-15-2020

**Jeff Bergosh**: He Steve I’m stacked this week as I leave the state for Christmas Holidays on Monday for two weeks.  I’ll call you later today and we can set something up.

**Steve Stroberger**: Sounds good.

### CONVERSATION ON 02-04-2021

**Steve Stroberger**: Kevin Wade is entertaining, but still a bit of a wacko. 

### CONVERSATION ON 02-05-2021

**Jeff Bergosh**: I think he means well

### CONVERSATION ON 05-08-2021

**Steve Stroberger**: I just watched the discussion about the vaccine and COVID from last Thursday. “Until we know more about this novel virus, even if you’re not in the risk group and fully vaccinated continue to wear a mask, social distance, and be very afraid.” That’s ridiculous! I know that’s what you wanted to say.

Steve

### CONVERSATION ON 05-09-2021

**Jeff Bergosh**: It is ridiculous

### CONVERSATION ON 06-16-2021

**Jeff Bergosh**: In a meeting will call back

### CONVERSATION ON 06-17-2021

**Steve Stroberger**: Today has been the biggest shit show.

**Steve Stroberger**: Not sure how you stomach some of those people, let alone Underhill.

**Jeff Bergosh**: It’s not fun

### CONVERSATION ON 07-06-2021

**Steve Stroberger**: Hey Jeff. Can we get lunch and talk about generational poverty and what to do about it? I know it’s a monolithic issue, but I think you see the root cause as I do. I’d like to discuss it because I’m getting the question about gentrification moving crime into our western communities. We can’t just move away from the problem. 

Steve S.

### CONVERSATION ON 07-07-2021

**Jeff Bergosh**: Sure Steve.  I’ll check my calendar.  Let’s talk later today, call at your convenience after 0900

### CONVERSATION ON 11-18-2021

**Jeff Bergosh**: He wanted to go fast until he didn’t get what you wanted now he wants to take the position that we can wait after the rest of us have done the work

**Steve Stroberger**: Prove it to me Jeff, push it to 2023.

**Jeff Bergosh**: Fuck that

**Jeff Bergosh**: He got his ass kicked he’s a liar don’t believe them if you do you do it at your own peril

**Steve Stroberger**: You can make it happen Jeff. 

**Jeff Bergosh**: What are you listening to tonight is a sore loser desperately trying to win

**Jeff Bergosh**: This is nothing more than a sales job and I hope that you realize that

**Steve Stroberger**: I’m just trying to work for the people out here where I have a shit load of support to be the next commissioner.

**Steve Stroberger**: If it can wait then make it wait.

**Jeff Bergosh**: Anyone that wants to wait should’ve been there in July and August when I was screaming to say let’s wait till 2023 but people are asleep at the switch not paying attention and I’m not gonna get yo-yoed

**Steve Stroberger**: Doug will never sit next to you again

**Jeff Bergosh**: The horses left the barn

**Jeff Bergosh**: He will he’ll have to for the next year unless he quits

**Steve Stroberger**: He’s quitting Jeff. I can be your partner on the west side.

**Steve Stroberger**: I will win if I’m allowed to compete.

**Jeff Bergosh**: You can compete and I think you should

**Jeff Bergosh**: Feeble minds

**Steve Stroberger**: Your letting your emotions make a bad decision Jeff. And your making me an unwitting ally of Underhill’s. Not where I want to be.

**Jeff Bergosh**: Absolutely not. You made yourself an ally of Underhill when you said another commissioner called you when I called you as a courtesy and told you the facts and the truth and you’re falling for Underhill’s lies and snake oil that’s what’s going on here Steve

### CONVERSATION ON 12-04-2021

**Jeff Bergosh**: it will be at the intersection of Rossi way and Dowdy drive.  2:00 PM

**Steve Stroberger**: Thanks Jeff, but I won’t be attending. I’m out of the District 2 election and I wouldn’t want to grandstand in Mel Pino fashion. I’ll let the District 2 candidates listen and learn. I hope they do listen.

