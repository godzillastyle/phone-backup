

## CONVERSATIONS WITH SBERGOSH@YAHOO.COM

### CONVERSATION ON 04-13-2021

**Jeff Bergosh**: Yes.  He is the legal assistant to the county attorney

**Jeff Bergosh**: And at work he comes across very very docile although I know he is a Marine Corps veteran

**Jeff Bergosh**: I don’t know that he does or doesn’t have any accounting background but I know he has paralegal training.

**Jeff Bergosh**: Getting ready to hit the sack-- big day tomorrow.  Love u!!❤️❤️

