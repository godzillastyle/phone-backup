

## CONVERSATIONS WITH CODY

### CONVERSATION ON 08-15-2021

**Jeff Bergosh**: Complex  is Tristan towers 

### CONVERSATION ON 08-16-2021

**Jeff Bergosh**: Hey Cody that sounds great I just tried to give you a call left you a message so when you get a minute take a listen and then give me a call back and will get this thing moving forward thanks a lot!

**Jeff Bergosh**: Cody-- I just forwarded the lease documents to you.  Let me know if you have any questions, comments, or concerns.  Thanks!   Jeff B

