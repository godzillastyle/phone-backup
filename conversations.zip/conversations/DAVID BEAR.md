

## CONVERSATIONS WITH DAVID BEAR

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello David- we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**David bear**: Glad to help. See you tomorrow.

**Jeff Bergosh**: Thanks very much!!  BTW I heard today from Scott Miller that they will be appealing their ruling—so that’s good news seeing as Doug will be requesting reimbursement on the 7th....if it is indeed appealed, he’ll have to wait for reimbursement until after the appeals are completed.....who knows how long that could take?

**David bear**: That’s good. I hope he prevails. 

### CONVERSATION ON 11-06-2019

**David bear**: Good morning. Why do you think the County is defending Doug in my suit against him?  Did they ask the commissioners if this was ok?

**Jeff Bergosh**: Nobody asked me, the only thing I think might have led to this is the fact that we’re named as well—but this was not discussed

**Jeff Bergosh**: Do you have a quick minute to chat?

**David bear**: I understand the County is checking with the new Chubb insurance policy to see if they’ll defend it but I don’t think it’s going to cover it.

**David bear**: sure

### CONVERSATION ON 11-07-2019

**David bear**: The appeal is because the plaintiff believes the trial court erred in its opinion that the commissioner was acting in his duties.

**Jeff Bergosh**: Exactly

**David bear**: Until the court finishes its opinion, you shouldn’t pay

**Jeff Bergosh**: Right

**David bear**: Another orchestrated set of questions

**Jeff Bergosh**: Yep

**David bear**: Fuck this guy

**Jeff Bergosh**: I have a substitute motion

**Jeff Bergosh**: Doug won’t like it

**David bear**: He got that term “chill” from my response to his his attempt to charge me so much for a public records request it would make it prohibited to get.

**David bear**: Good!

**David bear**: Steven is the fucking man!

**Jeff Bergosh**: That’s what I needed earlier

**David bear**: Don’t make a motion or second one, if it’s made.

**Jeff Bergosh**: ........better late than never

**David bear**: If there is no motion, it dies.

**Jeff Bergosh**: Absolutely

**David bear**: WTF is he talking about, Adam Shiff?

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: He’s losing it

**David bear**: Tell him you find him offensive

**David bear**: lol

**Jeff Bergosh**: 😂👍

**David bear**: I think he’s about to cry

**David bear**: Just let it die. Just let the attorney bring it back when/if it gets affirmed. 

**Jeff Bergosh**: Having him pay would have been better, but I’m good either way

**Jeff Bergosh**: Good outcome just the same 

**David bear**: Thank him for the opportunity to be on the right side and let his motion die

**David bear**: Great job

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 11-14-2019

**David bear**: Here are the comments. 

**Jeff Bergosh**: Wow—unhinged

**David bear**: Yep! They need to be taught a lesson in humility. 

**Jeff Bergosh**: I agree

**David bear**: I wish you guys would censure him, remove him from every committee, and just take away all of his power. Render him useless like the legislature has done to Mike Hill. 

### CONVERSATION ON 11-15-2019

**Jeff Bergosh**: That could happen.  I think his comments and those from his wife have really passed the current chairman off..... and the incoming chairman hates him more so far as I can tell..

**David bear**: It would be nice if someone brought it up a the next meeting or whenever committee assignments are being made. 

### CONVERSATION ON 11-17-2019

**David bear**: Collusion?!!

**Jeff Bergosh**: What a liar he is

**Jeff Bergosh**: Passed

**David bear**: Censure him

**David bear**: Not only does he insult, he undermines. 

**Jeff Bergosh**: Luckily he is unsuccessful 

**Jeff Bergosh**: For the most part

**David bear**: Liked “Luckily he is unsuccessful ”

### CONVERSATION ON 11-18-2019

**David bear**: 5th cent

**Jeff Bergosh**: Yes!

**David bear**: If Underhill supports it, he should support 5th cent

**David bear**: $3MM per year

**Jeff Bergosh**: Yes—but he won’t 

**Jeff Bergosh**: I want the 5th cent

**David bear**: In case you haven’t seen this yet.

**Jeff Bergosh**: Oh yeah I saw it.  What a bunch of tools 

**David bear**: Yep.  That’s why I mentioned it to you previously.  They all believe you are limiting comments based on viewpoint and threaten to expose it.

**David bear**: They threaten to expose it

**Jeff Bergosh**: But I don’t though.  

**David bear**: Good

**David bear**: Nothing to worry about

**David bear**: I say, bring it on...

**David bear**: It shuts them up when they prove themselves wrong.

**Jeff Bergosh**: I’m with you—bring it on!

**Jeff Bergosh**: Nothing to hide 

**David bear**: Unlike Underpants

**Jeff Bergosh**: 😆

### CONVERSATION ON 11-21-2019

**David bear**: He’s not going to stop attacking all of us.  He’s undermining the efforts of the Commission.

### CONVERSATION ON 11-25-2019

**David bear**: He’s such a thug!

**Jeff Bergosh**: Ha ha ha what a cry baby!  Hey, I made a motion to set aside funding to reimburse his legal fees once (and if) he was victorious after appeals.  He didn’t even second it, so if he wants to Bitch and cry and blame someone he ought to just go look in the mirror and yell at that guy!!😂😂😂😂😂😂😂😂😂

**David bear**: 😂

**David bear**: The poor victim. 

**Jeff Bergosh**: LOL right?!?

**David bear**: Jacqueline just shared his post on ECW too. Trying to throw me under the bus. 

**Jeff Bergosh**: What a tragic existence she leads.  Sad.  Just attacking people and trying to make it look intellectual.  Passive aggressive, black-hearted, sad.  I feel almost sorry for her and her family.

**David bear**: She’s in love with him. 

**Jeff Bergosh**: Yes.  She and Jim Little

**Jeff Bergosh**: They take turns

**David bear**: I think Jim is different. Jim knows there’s an open well of information (regardless of facts) available when he gives DU opportunity to talk. 

**David bear**: I like him allowing DU to open the flood gate and run off at the mouth. It gives people the opportunity to see what a fool he is when shit doesn’t go his way. How long can he keep calling everyone else corrupt before people start noticing he’s always alone...with Jacqueline. 

**Jeff Bergosh**: I wouldn’t call it a well I’d call it a ruptured sewage pipe.  And Jim sits there with a twinkle in his eye lapping it up like a shop vac.  

**Jeff Bergosh**: I think most rational folks now understand Doug is just an absolute tool.  He calls me and Steve corrupt... shit, he’s the one that’s corrupt.  Went bankrupt and beat a lot of people out of money and then when he turned it around and got back up on his feet—— he never paid them back.  I guess that’s perfectly acceptable behavior if you use Underhill logic. People like me that never went bankrupt but fight through it were somehow corrupt? His logic is whack

**David bear**: Laughed at “I wouldn’t call it a well I’d call it a ruptured sewage pipe.  And Jim sits there with a twinkle in his eye lapping it up like a shop vac.  ”

**David bear**: He’s a douchebag. 

**Jeff Bergosh**: Douchnozzle 

### CONVERSATION ON 11-26-2019

**David bear**: Haha. Let me know when you guys have to report your next quarterly gift report to the county. Please don’t mention it. I want to trap his ass. 

**Jeff Bergosh**: Will do

**David bear**: Do you have the AG’s opinion about it?

**Jeff Bergosh**: No—is there one?

**David bear**: I remember when he originally tried to do one years ago, the BOCC sled Alison to get an AG opinion. She’s got it. 

**Jeff Bergosh**: I don’t know that she ever did it though.  But I think you are onto something about the reporting on the gifts form that’s what my brother said when I asked him about it he thinks he can do it but he hast to report it quarterly as a gift

**Jeff Bergosh**: So I wonder if Joe mirabile is just going to bankroll all his legal fees?

**David bear**: We’ll see...

### CONVERSATION ON 11-27-2019

**Jeff Bergosh**: Ha ha ha I saw you donated $5 to his cause!  What a swell guy!!!😂😂😂😂😂😂😂😂😂😂😂😂😂😂

**David bear**: 😂

**David bear**: I think it’s one of my favorite things I’ve done to him.

**Jeff Bergosh**: 😂😂😂😂😂

**Jeff Bergosh**: Living in his head

**David bear**: It was worth the $5 donation to get that.

**David bear**: Do you know how old he is?

**Jeff Bergosh**: 49 or 50 I think 

**Jeff Bergosh**: Acts like he’s 9 though

**David bear**: He tries to demean me by calling me baby bear and referring to my dad as “your daddy” when he talks to me about him like I’m some little kid.  He’s basically my age.

**Jeff Bergosh**: Exactly

**David bear**: On one of the thumb drives he gave me with public records I requested, he named the folder Baby Bear

**Jeff Bergosh**: He’s just miserable

**Jeff Bergosh**: What a miserable guy

**David bear**: I guess you saw the email he sent out yesterday?

**David bear**: Mel sent it to all of you

**Jeff Bergosh**: Yes

**David bear**: Shirley Cronley just sent it to me to make sure I saw it

**Jeff Bergosh**: He’s really triggered by Steve and I

**Jeff Bergosh**: That Combined with the Pnj article that showed my tremendous warchest I’m sure has left him and Johnny really really out of sorts

**David bear**: I wonder if Karen Sindel saw it yet.  She’s the President of Florida West’s board

**Jeff Bergosh**: Imagine Thanksgiving day at his house what a joyous occasion not

**David bear**: lol

**Jeff Bergosh**: Not sure what Karen’s up to these days.  

**Jeff Bergosh**: Just know she’s not going for a rematch of 2016–which was/is prudent on her part

**David bear**: She may want to run against Doug

**Jeff Bergosh**: Now that I could get behind — I mean that’s at least her district that she lives in

**Jeff Bergosh**: Could be a great race

**David bear**: Marty can’t win and he’s really only a little better than DU (between us).

**Jeff Bergosh**: Oh, okay.  Who then?

**Jeff Bergosh**: Will McMillan come off the bench?

**David bear**: IDK

**David bear**: No.  McMillan already proved he’s not a good candidate

**Jeff Bergosh**: I guess we will have to see.  Maybe Johnathan? And Doug will be his aide?  They will just switch positions?  Like they do already😂

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Doug will say “I can’t quit you”

**Jeff Bergosh**: 😂😂😂😂😂😂😂😂

**Jeff Bergosh**: Who is that? The D2 Office intern?

**David bear**: Laughed at “Who is that? The D2 Office intern?”

### CONVERSATION ON 11-28-2019

**David bear**: Your Facebook post is fucking hilarious! Good for you!

I hope you and your family have a beautiful Thanksgiving. Geaux Saints!

**Jeff Bergosh**: Thanks David!  Happy Thanksgiving to you and your family!

**David bear**: Thanks 

### CONVERSATION ON 11-30-2019

**David bear**: If Bender brought roundabouts up for discussion and vote, would you vote against them?

**Jeff Bergosh**: Depends on how they would be funded, But more than likely yes

**David bear**: I’m sick of those bullies beating up on Robert.  I’d like to see it get defeated so they’ll leave him alone and look for another solution. 

**Jeff Bergosh**: I agree

### CONVERSATION ON 12-04-2019

**Jeff Bergosh**: “I was feeling generous and thought I’d make a contribution to his fund....five dollars was the minimum amount that I could give that they allowed; I would’ve given $.50 if they would’ve allowed me to do it”

LOL priceless quote 😂😂😂😂😂

**David bear**: I’m here for your entertainment. 😂

**Jeff Bergosh**: LOL

### CONVERSATION ON 12-11-2019

**David bear**: Why are you guys hiring Ron Ellington to study the needs for the future of the Bay Center?  What are his qualifications?  This is on tomorrow’s COW agenda.

**Jeff Bergosh**: He made the rounds last month.  Wants $19.5K in TDC money to do a feasibility study

**David bear**: He has no qualifications. He’s a lobbyist.

**Jeff Bergosh**: Not sure what his specific qualifications are

**Jeff Bergosh**: Heading to Orlando

**David bear**: OK.  Did you hear about the TDC approving 5th cent yesterday?  5-2

**Jeff Bergosh**: No way —. Really??

**Jeff Bergosh**: What conditions?

**David bear**: 1. You guys have to approve. 2. We recommended it be reserved until guidelines for its use are approved.

**David bear**: Jim Reeves made the motion and then voted against it.  I guess he thought it would kill it but it past 5-2.  PC Wu was the other dissenting vote.

**Jeff Bergosh**: Wow—that’s pretty huge.  Does that come to us next?

**David bear**: Yes

### CONVERSATION ON 12-12-2019

**David bear**: Was Doug upstairs before the meeting?

**David bear**: Was Doug upstairs before the meeting?

**Jeff Bergosh**: Not sure, haven’t seen him and his status for today is uncertain

**David bear**: Thanks 

### CONVERSATION ON 12-15-2019

**David bear**: I hope you don’t mind, I parked in your parking spot in county parking lot. I’m going to Children’s chorus at saengar. Cool?

**David bear**: Nice blog posts, btw. 

**Jeff Bergosh**: No problem at all David, thanks!

**David bear**: Good thing. It just ended and I’m now leaving. 😂

**David bear**: Thanks again

**Jeff Bergosh**: LOL

### CONVERSATION ON 12-31-2019

**David bear**: Man, I saw your post about your dog, Rocky. I just wanted to let you know how sorry I am and I’ll keep your family in my thoughts and prayers. Pet’s are family members and it’s so hard when you lose one. 

I also want to wish you a Happy New Year and look forward to working with you to help move this county forward. Please don’t hesitate to reach out anytime if I can do anything to help you. Thanks for your friendship!

**Jeff Bergosh**: David thank you so much for those kind words. It is a devastating hole in my heart losing Rocky.  But I can only assume it’s a God thing as the timing of his passing coincided with all the kids being home from school for the holidays. Nevertheless it still hurts and I’m sure it will for a long time. I hope you and your family have a wonderful New Year’s eve as well——- I’m headed to New Orleans.  Sally is kidnapping me and taking me there to the French Quarter for a party tonight which i’m thinking I need right now to help lift my spirits. Have a safe one and we will talk soon my friend!

**David bear**: Be careful and have fun. Tonight is amateur night and you’ll be in the city of professional predators.

**Jeff Bergosh**: Thanks I’ll keep an eye peeled 😎

**David bear**: Watch out for this guy. 

### CONVERSATION ON 01-07-2020

**David bear**: Perfect timing...😕

**Jeff Bergosh**: Thx

**David bear**: I was being sarcastic about leaving the second Alison started talking about her agenda item about my case. Not much discussion but she lied to the commissioners. We’ll talk later. 

**Jeff Bergosh**: Oh

**Jeff Bergosh**: I was running late for an 11:30 mandatory QA training that I just finished.  What happened?

**David bear**: You should ask an independent attorney to tell you whether there is an ethical issue of her keeping confidential. 

**David bear**: He wouldn’t know the truth if it not him in the ass

**Jeff Bergosh**: Exactly

**David bear**: Btw, my case isn’t about what he said

**David bear**: It’s about what he’s not doing to comply with the law

**Jeff Bergosh**: Yes

**David bear**: I do not believe Alison is telling the truth about the ethical issue. The ethical issue is with her leading DU to think is was confidential and privileged. 

**Jeff Bergosh**: I agree

**Jeff Bergosh**: Which insults our intelligence frankly

### CONVERSATION ON 01-08-2020

**David bear**: I got my own cartoon.

**David bear**: Not sure what the bottom image is talking about

**Jeff Bergosh**: Yeah I saw that this morning

**Jeff Bergosh**: Welcome to the club LOL😎

**David bear**: Wanna bet how long it takes for Doug to hang it outside his office?

**Jeff Bergosh**: Ha ha ha you know he will!

**Jeff Bergosh**: I think For the most part he was put back into his box yesterday

**David bear**: I called Andy out this morning for saying false information and he immediately created this

**David bear**: I talked to your brother yesterday

**Jeff Bergosh**: Andy has very thin skin

**Jeff Bergosh**: My brother would’ve acted and Malcolm Thomas would’ve been held accountable for what he did instead of getting a pass

**David bear**: Do you think there’s a possibility that Alison’s conflict is because she has communicated with the State Attorney that Doug has told her he refuses to provide the public records I’ve requested?

**Jeff Bergosh**: I think that’s a possibility Dave

**Jeff Bergosh**: She’s really handle a couple of issues very poorly in my judgment

**David bear**: If the county is required to demand the public records from someone who is illegally possessing them (illegally refuses to provide upon request, by law), and he refuses to give them to her, his interests are adverse to the county’s and she’s obligated to to go to a higher authority (full BOCC) and ethically required to file a complaint to the SAO above a known violation of the law.

**Jeff Bergosh**: Yes.  And I believe that is why she finally got around to scheduling the shade meeting which she should’ve done prior to filing motions on December 19 that substituted counsel.  And that’s why she got her hand slapped today

**Jeff Bergosh**: Yesterday I meant

**David bear**: Do you believe he should produce the public records to the county if demanded?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I would if someone requested it of me

**David bear**: If Alison hasn’t demanded he provide them, you all can do it in the shade meeting.  If he refuses to do so, his interests are adverse to the county’s interest and he’s telling you he’s intentionally violating the law.  If he claims he already has provided them, he’s lying.  Ask him to prove it.

**David bear**: BTW, I told my attorney to agree to the extension for the county.

**Jeff Bergosh**: Okay good— this way we can sort out who is going to be representing us

**David bear**: That firm is more than likely going to represent you guys.

**David bear**: Which I have no problem with.

**Jeff Bergosh**: I think Charlie should do it

**David bear**: I don’t disagree.

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: He’s full of BS!  We are having the discussion at the march committee of the whole!!! What a liar!!!

**David bear**: Wait, Dougie lies?

**Jeff Bergosh**: LOL    Like a rug!

### CONVERSATION ON 01-11-2020

**David bear**: https://www.pnj.com/story/opinion/2020/01/11/escambia-county-commissioners-clinging-culture-chaos/2849909001/

**Jeff Bergosh**: Shitty

**Jeff Bergosh**: I guess I should just ignore the six instances where our harassment policy was blatantly violated and employees suffered

**David bear**: Right and how Alison violated FL bar rules of ethics. 

### CONVERSATION ON 01-21-2020

**David bear**: Do you have a campaign email address for me to send the map?

**David bear**: Never mind. I sent it to your gmail address 

**David bear**: Here’s something to think about: At the last BOCC meeting, Underhill said he turned over all of the public records and he also put that in his response to our request for production. Alison knows he hasn’t. If she works for the BOCC and knows he’s lying, why isn’t she speaking up and telling you all?

**Jeff Bergosh**: That’s a very good question

**David bear**: She’s not acting like she works for the BOCC. 

### CONVERSATION ON 01-22-2020

**David bear**: ???? When did this meeting happen?

**Jeff Bergosh**: He’s referring to the shade session 

**Jeff Bergosh**: No other meetings since then

**David bear**: Ok. I didn’t know that was part of that meeting. 

**Jeff Bergosh**: Yes-he was desperately clinging to the “Bears” are evil narrative.  He wasn’t persuasive

**David bear**: Lol

**David bear**: But but but...he’s just telling the truth. 

**Jeff Bergosh**: He is delusional

**Jeff Bergosh**: Psychotic

**David bear**: Emphasized “He is delusional”

**David bear**: Emphasized “Psychotic”

**David bear**: My wife has voice her concern about our physical safety

**Jeff Bergosh**: Always something to be concerned with.  Do you have a concealed carry permit?

**Jeff Bergosh**: If not, you might consider it

**David bear**: I don’t and have been thinking about getting it. 

**Jeff Bergosh**: I don’t have one either but I will be getting one

**Jeff Bergosh**: You can never be too safe in this crazy world

**David bear**: I have one of these next to my bed.

**David bear**: https://en.wikipedia.org/wiki/Taurus_Judge?wprov=sfti1

**Jeff Bergosh**: My brother has one of these.... Bad ass!

**Jeff Bergosh**: Shotgun and .45 

**David bear**: The modern day sawed-off shotgun. 

**Jeff Bergosh**: Not going to be able to conceal this bad boy David, sorry😂

**David bear**: Lol

**David bear**: First two shots are normal 410. Next shots are all triple ought buckshot. First two will slow you down, the next ones will rip you apart. 

**Jeff Bergosh**: That’s a smart strategy.  

### CONVERSATION ON 01-31-2020

**Jeff Bergosh**: I see you mixing it up in ECW with Cris Dosev.....way to go!

**David bear**: Yeah, fuck that dude. He’s as big of an ass as DU

**Jeff Bergosh**: Bigger

**David bear**: You’re probably right

**Jeff Bergosh**: That site is just so hateful and ugly

**Jeff Bergosh**: Have a great weekend!

**David bear**: Thanks man. You have a great weekend too. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**David bear**: Those are nice splits. 

**David bear**: We should declare Escambia County a 1st Amendment Sanctuary. 

**Jeff Bergosh**: Right!

**David bear**: How about a 21st Amendment Sanctuary. 

**Jeff Bergosh**: I’ll drink to that!😎

**David bear**: Laughed at “I’ll drink to that!😎”

### CONVERSATION ON 02-06-2020

**David bear**: Is what Underhill and Lois Benson hare doing to these people in Innerarity similar to what Underhill accused Scott Miller of doing?  By not applying for a grant to pay for this project, he’s trying to make it too expensive for the residence to stay and run them out of their homes?

### CONVERSATION ON 02-07-2020

**Jeff Bergosh**: Not sure David.  I’m researching this whole issue because those residents are getting shafted.

**David bear**: Liked “Not sure David.  I’m researching this whole issue because those residents are getting shafted.”

### CONVERSATION ON 02-10-2020

**David bear**: What an ass. 

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: We’re going to use the Restore Act money that’s already earmarked for public beach access

**David bear**: Liked “We’re going to use the Restore Act money that’s already earmarked for public beach access”

### CONVERSATION ON 02-18-2020

**David bear**: These are the two pages from Steve Hayes showing he budgeted $2.8MM.  If you need the full 108 page document, let me know.  Thanks

**David bear**: Also, if you look at VP’s actual request, you can see the dollar amount requested ($9.25MM) is equal to what you all appropriated to unified budget group ($6.45MM) plus the $2.8MM.  Page 4 from the link below.

**David bear**: https://myescambia.com/docs/default-source/sharepoint-administration/budget/fy-2019-2020-files/third-cent-tourist-development-fund-fy-19-20.pdf?sfvrsn=c069df6d_2

**Jeff Bergosh**: Okay got it, thanks David

**David bear**: 👍

### CONVERSATION ON 02-19-2020

**David bear**: Good morning.  Although I doubt it, there may have been a misunderstanding about the TDT.  Alison and Janice said Jack Brown told them Steve Hayes budgeted $2.1MM and that’s why they were going to appropriate $2.1MM.  Jack may have told them Steve budgeted $2.1MM but he would have meant that was the amount for VP (75% of the $2.8).  ACE was budgeted to get $700k (25%).  I want to make sure you don’t look like a jerk if there really was a misunderstanding.  As long as there is $2.8MM for the supplemental appropriation for the unified budget, as we had all agreed, we’re all good.  Are you good with that?

**Jeff Bergosh**: Sure—I’ll ask for clarification during my 4:30 conference call

**Jeff Bergosh**: ..........but I’m pretty cynical these days though

**David bear**: Cool.  I just wanted to make sure you understood it could have been a misunderstanding and give them the benefit of the doubt.  I’m pretty cynical too.  I told Melissa Pino yesterday she was an asshole for not letting me live in my bubble.

**Jeff Bergosh**: LOL😂😂

**David bear**: She tells me shit and I think she’s crazy.  Then, it all is revealed as true.

**David bear**: I had to stop doubting her

**Jeff Bergosh**: Agreed.  She’s been pretty much spot-on

**Jeff Bergosh**: (Except for the part about Chips Kirchenfeld being the anti-Christ). I never thought he was a bad guy—-Mel HATES. him

**David bear**: I know.  I’ve always liked Chips.  His wife and I grew up together and I know she wouldn’t have married him if he was so bad.

**David bear**: Did you hear about Doug making Chips sign an affidavit saying who told him about Doug’s son getting arrested?

**David bear**: BTW, brilliant move by your brother...

**Jeff Bergosh**: Yeah I heard.  I think my brother was the judge that signed a warrant.  He told me he was treating him just the way he treats any other juvenile in that circumstance.  But I guess Doug went apoplectic over it

**Jeff Bergosh**: Doug just needs to get a grip

**David bear**: He’s fucking crazy!

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: 😂😂😂

**David bear**: He’s arguing in my case that his comments and posts on FB aren’t public record and he’s posting stuff just like any other citizen may do.

**Jeff Bergosh**: What bullshit is that! Did he argue the exact opposite in Scott Miller’s case?

**David bear**: yep

**Jeff Bergosh**: This is why I hate lawyers

**Jeff Bergosh**: Except for one

**David bear**: Well, I don’t think the judge in either case is going to like it.  We’re sending a copy of it to Miller’s attorney

**David bear**: It’s fraud

**Jeff Bergosh**: That’s a great move and I agree it is fraud but then again he’s a fraud of a person

**David bear**: He filed an affidavit in Miller’s case saying his comments on social media are part of his job as a commissioner and that’s why he should be absolutely immune.  Now, he files a response to our request for admissions saying he’s not conducting business, he’s just posting stuff like any other citizen.

**Jeff Bergosh**: Yeah he’s talking out of both sides of his mouth and guess what he can’t have it both ways. He can’t have his cake and eat it too

**Jeff Bergosh**: I hope you guys nail his ass to the wall on that

**David bear**: This is the trap I wanted to set.  If it is official business, he’s violated the public records law.  If it’s not, he’s defaming people.  Which way does he want it?

**Jeff Bergosh**: Exactly!  Either choice is bad for him 😎.  It’s his choice.  1. Cyanide. 2. Ricin.     Pick your poison, Doug!

**David bear**: 😂

**David bear**: Unless of course, the judge decides to dismiss the case based on his lies.

**David bear**: You guys have hired Clark Partington Hart IT folks to go through his FB to determine if anything has been altered, deleted, etc. and download it and provide me a copy - $10,000!  They don’t want the judge to rule it’s public record and he violated the law by not providing it.  He’s hoping I will drop it after receiving the docs.  I want the judge to rule regardless of whether they give them to me in advance or not.

**David bear**: Did you know the county was paying for this?

**Jeff Bergosh**: Let’s talk

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: LOL that’s awesome!!!!

**David bear**: I think it’s his new campaign signs

**Jeff Bergosh**: It ought to be——-totally accurate

**David bear**: I want to make one with Doug lifting Jonathan into the air like Dirty Dancing.

**Jeff Bergosh**: Ha Ha that would be awesome!

### CONVERSATION ON 03-04-2020

**David bear**: Sorry about the calls yesterday. When you have a chance, will you please give me a ring? Thanks

### CONVERSATION ON 03-11-2020

**Jeff Bergosh**: David—thanks very much for your vote yesterday to approve funding Beach Access #4 at Perdido Key!!!! Greatly appreciate that!!!

Jeff B

**David bear**: Glad to do it. I believe beach access will attract more visitors to support the condos, restaurants, and shops. 

**David bear**: It’s the right thing to do. For added pleasure, Douchebag Doug is against it. 

**David bear**: Hope you saw my email yesterday.

**Jeff Bergosh**: I did and I agree with it.  He is spinning out of control.  He and his wife now have a giant public records request in at my office looking for information about my contacts with sheriffs office and corrections personnel regarding his son.  They were in tinfoil hats and they think there’s some kind of conspiracy that I’m a part of

**Jeff Bergosh**: I should make Wendy and Doug wait as long for their public records request as Doug has made Mel Larry and you wait, LOL

**David bear**: “Reasonable time”

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: (i’m not really gonna make them wait I’ll probably send something to Wendy two weeks from Friday late in the afternoon and it’ll go something like this:  “in response to your public records request please see the below email.” )

And in the below email it will say “there were no records responsive to your request have a great weekend”............Because there are no public records in existence responsive to her request

**David bear**: Hey Jeff. I know it’s late, but do you have a few minutes to talk? If not, can you talk in the morning before your shade meetings?

### CONVERSATION ON 03-12-2020

**David bear**: Thanks

**Jeff Bergosh**: Thank you David!

**David bear**: Any action?

**Jeff Bergosh**: 
Nope

**Jeff Bergosh**: I’ll call u after this mtg

**David bear**: I’m walking in there

**David bear**: Underhill is commenting on FB right now that this presser is a train wreck. 

**Jeff Bergosh**: He is a loser

**Jeff Bergosh**: ....for the community

**David bear**: Wow! I didn’t know you felt that way. 

**David bear**: 😂

**Jeff Bergosh**: LOL

**David bear**: I agree. This is good. Unfortunately, I think it’s no longer being broadcast on the website. 

**Jeff Bergosh**: I meant the press conference

**Jeff Bergosh**: It should be

**David bear**: I knew what you meant. I was addressing your comment about him being a loser. 

**David bear**: Liked “It should be”

**Jeff Bergosh**: Yes.   He is one 

**Jeff Bergosh**: 😎

**David bear**: He’s a douchebag

**Jeff Bergosh**: 👍

**David bear**: Ask if the triumph request is different from the one previously denied. Does it meet triumph’s expectation for pay levels per triumph dollar spent on the project?

**David bear**: Triumph will not fund this project because they're legally required to create jobs over a certain level of income. 

**Jeff Bergosh**: Yes I know that was a problem.  And I think he all but acknowledged this....

**David bear**: He did and is arguing they’re wrong and is planning to convince them to change their funding criteria. I wish him luck. 

**Jeff Bergosh**: That will be a heavy lift

**David bear**: I can’t support his project without a triumph grant

**Jeff Bergosh**: Me neither

**David bear**: I say that with my TDC hat

### CONVERSATION ON 03-17-2020

**Jeff Bergosh**: The governor just announced that all bars and nightclubs will be closed for the next 30 days

**David bear**: Thanks!! On call with my leadership team and just got that announcement. 

**Jeff Bergosh**: Scary times

**David bear**: Emphasized “Scary times”

### CONVERSATION ON 03-19-2020

**David bear**: Is the county considering closing the beaches and on premise consumptions in restaurants?

**Jeff Bergosh**: Not that I have heard

**Jeff Bergosh**: But we are getting a lot of pressure to do so including from senator Rick Scott

**David bear**: I would suggest it...

**Jeff Bergosh**: I did on Tuesday that we have a special meeting and it fell upon deaf ears

**Jeff Bergosh**: Seems that the leader ship is behind the curve here locally

**David bear**: Unfortunately, I agree.  People are still in denial.  Because the testing is better and faster, we’re going to see a surge in positive cases.

**David bear**: If that doesn’t open their eyes, they’ll never get it

**Jeff Bergosh**: Agreed

**Jeff Bergosh**: ........we don’t Want to be lackadaisical and end up like Italy

**David bear**: You can’t fix stupid...but Darwinism can.

**David bear**: Write that down, I just made it up.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Special meeting tomorrow, tentatively, at 11:00

**David bear**: 👍

### CONVERSATION ON 03-20-2020

**David bear**: They just took action

**David bear**: Desperate times call for desperate measures. Close the beach.  Tourism will return.  Our tourism industry has faced adversity in the past and overcame.  It will overcome again.

**Jeff Bergosh**: It’s angling that direction

**David bear**: That seems to be my read too.  Robert seems to be talking himself into it.  Underhill, somehow is too.  He feels he’s gonna be a 4-1 if not.

**David bear**: Thank you

**Jeff Bergosh**: 👍

**Jeff Bergosh**: LOL

### CONVERSATION ON 03-22-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/test-results-starting-to-trickle-in-at.html?m=1

**David bear**: Yeah, it’s probably about to blow up. 

### CONVERSATION ON 03-30-2020

**David bear**: I just sent you an email (to your commission email address) about settling my lawsuit.  Please let me know when you have time to discuss it.  The lawsuit will be discussed at your Thursday BOCC meeting. It’s on the agenda under the County Attorney’s report.

**Jeff Bergosh**: Okay will do

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: You’ve probably already seen this

**David bear**: Yes, thanks. 

### CONVERSATION ON 04-02-2020

**Jeff Bergosh**: How much did Underhill charge you for your public records request?  And did he break down the costs in staff time, salary for employees who spent time on the request, etc.?

**David bear**: Alison didn’t charge me for the first couple of requests. They were either incomplete, inaccurate, or never fulfilled. Then, he demanded Alison charge me 15 hours of his time and 1/2 hour of Jonathan’s time for one of the requests ($900 +/-).  Charlie sent us a letter about it and a copy to the State Attorney’s office. We responded saying it was illegal and Alison chose not to charge us. The next request, he demanded Alison charge us for 14 hours of his time and 1/2 hour of Jonathan’s time and Alison chose to charge us for the 14 hours but at Jonathan’s hourly rate ($450+/-). We asked for the details of his charges and Alison forwarded us an email from Doug saying he wouldn’t even know what that looked like. The request he fulfilled for that was 152 screenshots from his phone showing the time stamp from start to finish only being 47 minutes.

**Jeff Bergosh**: Okay thanks.  So you paid the $450 then?

**David bear**: Yes, for 47 minutes of screenshots. 

**Jeff Bergosh**: Wow!  Okay thanks

**David bear**: He claimed it was 14 hours but he can’t provide anything to support that. 

**David bear**: The live feed just cut off of ECG TV. Please ask them to get it going again. There is an ad running.

**David bear**: ECTV

**Jeff Bergosh**: Okay I’ll ask 

**David bear**: Oh that was a video that she has were showing. Sorry about that. We've got the live meeting back

**David bear**: It's back on.

**Jeff Bergosh**: 👍

**David bear**: Thanks!

**David bear**: Underhill has a conflict. He shouldn't be talking about that

**Jeff Bergosh**: About what?

**David bear**: When he was talking about South Palafox partners

**David bear**: Tell Doug, business interruption insurance doesn’t pay if the buildings are not damaged. If there is a sever breakout of the virus in someone’s building, they may apply for business interruption insurance. 

**Jeff Bergosh**: Oh yeah

**David bear**: He’s not getting those votes back. He should just shut up. 

**Jeff Bergosh**: I agree

**Jeff Bergosh**: This thing is running unnecessarily long.............

**David bear**: I know. I’m just waiting for the next topic...

**Jeff Bergosh**: LOL

### CONVERSATION ON 04-03-2020

**David bear**: https://www.pnj.com/story/opinion/2020/04/03/marlette-underhill-tiger-king-escambia-coronavirus-crisis/5112237002/

**Jeff Bergosh**: I saw it... funny

**David bear**: So good

**Jeff Bergosh**: Yeah- can’t wait to see the cartoon Sunday

**Jeff Bergosh**: ........ at least it won’t be me for a change😎

**David bear**: lol

**David bear**: Yesterday Marlett posted his cartoon of Matt Gaetz on Facebook and I commented there still was nothing of Underhill.

**David bear**: Now there is

**Jeff Bergosh**: LOL

### CONVERSATION ON 04-08-2020

**David bear**: Does this violate the County Ethics Policy?

### CONVERSATION ON 04-24-2020

**David bear**: Good evening Jeff.  I hope you and your family have been staying safe and are doing as well as can be under the current circumstances.  I know you guys are having your meeting on Tuesday at 10:00 AM and will discuss opening the beach.  I wanted to share my family’s feeling about it with you before you do.  Although our business is tourism dependent and the beaches being open are good for our sales, we are concerned it’s too soon to open the beaches.  We are fortunate in many ways.  Specifically, we were fortunate to be considered an essential and critical workforce during this pandemic even though having the bars and restaurants closed shut down 15-20% of our business.  People want their beverages and our team is working hard to provide them.  Because of this, we have taken every safety precaution we can to provide as safe of a working environment as we can and try to protect them from possible harm.  Unfortunately, the places we service are all essential and critical too.  Citizens have to go to these stores to buy the food and supplies they need to survive.  Every time one of our employees enters a store, he is in danger of infection.  We gave them hand sanitizer, surface sanitizer for their equipment, face masks, and we even built hand-washing stations for every truck.  Additionally, we are fully sanitizing both of our warehouses (each approximately 100,000 sq. ft.), all of our equipment, and offices every two weeks.  This has been at a great expense, but most definitely necessary.  We do not allow anyone from outside into our building unless it is necessary. We even have many employees working from home. The more we can minimize their exposure, the greater chance of helping to protect their health and the health of their families.  If we open the beaches prematurely, we run the risk of widespread infection.  People will not social distance on the beach as seen in other areas.  Many people have the virus that are asymptomatic and it will be transmitted unknowingly.  When people go home to their loved ones under these relaxed socializing rules, they will spread it to others.  All of those people will go to the stores to buy their essential and critical supplies.  Not everyone is diligent about washing their hands, etc., and not everyone has the immune system to handle infection.  This will create a more broad spread infection unnecessarily.  We have seen the major spike in cases this week and we know it will continue to increase before we actually “flatten the curve.”  I am asking you to please consider waiting a little while longer to open the beaches to ensure the safety of not only my team and their families, but the safety of all citizens.  I want nothing more than to get back to tourism and business as usual, but this is not yet the time.  Thank you for your consideration and please know I respect you for the tough decision you need to make next week.  If you need anything from me, please do not hesitate to call.  Thanks again for your thoughtful consideration. David

### CONVERSATION ON 04-26-2020

**David bear**: Look, he did a self portrait. 

**Jeff Bergosh**: That is a self portrait! But really who is it supposed to be?

**David bear**: I don’t know, but it’s in an anti Obama/pro Trump cartoon.  They’re all drinking “Dud Light” beers.

### CONVERSATION ON 04-28-2020

**David bear**: Good morning. Thanks for everything you’re doing with your blog to be transparent and share information with the citizens. As I understand it, the sentiment is leaning toward opening the beaches. I believe we’ve kept the potential impact of the pandemic at bay due to the responsible choices to enact social distancing, closure of the beach, and other activities that promote close contact. As I said in my previous text, I think we’re a little early to open but it’s gonna happen so let’s do it as cautiously as possible. Open the beaches with smart, limited access to start and see how people act. I wouldn’t open the bathrooms and other facilities yet until you see what happens from the first phase. Take baby steps. From everything I’ve read, we’re going to see another spike after the opening. The slower we do it, the better we’ll be. We really need to push the medical community and FDOH to do more testing and get faster results so we can better understand the spread and potential impact. 

Good luck in the meeting today and thanks for your leadership.

**Jeff Bergosh**: Thank you David!

**David bear**: Which part of this curve looks bent?

**David bear**: How do you feel about a phased opening?

**Jeff Bergosh**: Don’t know about that chart.  But the chart indicating the rate of new hospitalizations, new number of daily infections, and deaths—-those charts show a flattening of the curve 

**David bear**: I haven’t seen those. 

### CONVERSATION ON 05-08-2020

**David bear**: Alison and Janice had Ajit’s resume since he emailed it to them in February but they still decided to put it on the agenda. What the fuck was their motivation to embarrass Ajit like that? Was he just used as a tool to throw more shade at my dad and PEDC?

**Jeff Bergosh**: That whole thing was kind of weird

**Jeff Bergosh**: How did they just find out that he lives in Gulf Breeze and it was on his fucking resume

**David bear**: That’s my question. I would tell you it’s one of two reasons this happened. 1. It was intentional as I said or 2. Irresponsible, sloppy work by your county administrator and attorney for not reviewing for eligibility or even accuracy of their agenda. 

**Jeff Bergosh**: #2

**David bear**: I’m more inclined to believe it’s #1. They’re both very smart and calculated and I doubt very seriously they would let something sloppy get through without intention. 

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: *hello

**David bear**: That’s too bad. I was hoping Owens was in last place. 

**David bear**: 😂

**Jeff Bergosh**: Me too!  But I’m happy to be ahead of him by 30 points

**David bear**: Liked “Me too!  But I’m happy to be ahead of him by 30 points”

**Jeff Bergosh**: I will squash him like a roach on August 18th.....Then he will be relegated back to his position of fetching cokes for his boy Doug

**David bear**: “The Secretary”

**Jeff Bergosh**: Yep

**David bear**: Have you seen that movie? I bet that’s what it’s like behind closed doors.

**David bear**: https://youtu.be/AFma24S-Uvw

**Jeff Bergosh**: LOL I haven’t but I will now

**David bear**: Just watch that trailer. The movie is great but the trailer will explain it all. 

**Jeff Bergosh**: Ha ha ha Jonathan is “the secretary”. That’s awesome!! 

### CONVERSATION ON 05-21-2020

**David bear**: Who the fuck is this Jeff Love dude? 

**Jeff Bergosh**: No idea but very freaky, fake profile

**David bear**: He’s got several profiles and I don’t actually think they’re fake. He says crazy shit all the time so I looked him up on Clerk’s website. He’s spent time in jail. 

**Jeff Bergosh**: Freak show

**David bear**: You may be better off ignoring than confronting. He doesn’t seem like he’d mind going back to jail/prison. 

**David bear**: Liked “Freak show”

**Jeff Bergosh**: I ignore him

**David bear**: Do something today to poke DU in the eye over an issue. Get him flustered. That would be fun.

**Jeff Bergosh**: Think I already did LOL

**David bear**: Good. I haven’t been watching. I just like him frustrated. 

**Jeff Bergosh**: 😎👍😂

### CONVERSATION ON 05-22-2020

**Jeff Bergosh**: He released confidential information

**Jeff Bergosh**: He’s definitely frustrated now

**David bear**: Yeah, they’re taking the position that it’s only confidential if there is filed litigation. If it’s private, shade meeting discussions about ongoing legal issues, it stays confidential. 

### CONVERSATION ON 05-27-2020

**David bear**: You do have a Constitutional Right to sell alcohol in FL. It's the 21st Amendment to the US Constitution.  It allows states to create legislation and promulgate rules to regulate alcohol within their own states.

**Jeff Bergosh**: I asked him about it LOL

**David bear**: I heard, thanks.  No one said to sell alcohol without a license.  The governor’s executive order didn’t revoke licenses.  His comments were misdirected and inaccurate.

**David bear**: The 18th Amendment prohibited the manufacture, sale, or transportation of intoxicating liquors.  The 21st Amendment repealed that.  It gave the states the power to regulate the manufacture, sale, or transportation.  So, it is a constitutional right to sell alcohol.  The governor’s orders said nothing about possession and consumption.  All businesses supplying grocery stores were determined to be essential and critical workforce.  We transported and sold products to grocery stores, they sold products to customers who transported it and consumed it wherever they wanted (where legal - no county sidewalks).  The sale, transportation, and consumption of alcohol is a constitutional right and he is wrong.

**Jeff Bergosh**: That’s a great point! 

**David bear**: Duh, I made it.  😂

**Jeff Bergosh**: That’s right!  LOL

**David bear**: You got a minute?

**Jeff Bergosh**: Yes

**David bear**: https://en.m.wikipedia.org/wiki/QAnon

**David bear**: https://abcnews.go.com/Politics/republicans-wrestle-conspiracy-theory-advocate-winning-senate-primary/story?id=70829450

**David bear**: https://www.adl.org/resources/backgrounders/qanon

**David bear**: https://thehill.com/homenews/campaign/498800-oregon-gop-senate-nominee-posts-video-in-support-of-qanon-conspiracy-theory

**David bear**: Those articles should should be enough to have you hiding under your sofa. 

**David bear**: Be safe

**Jeff Bergosh**: Thanks for the heads up

**David bear**: You’re welcome.

**David bear**: Please read those. You need to know who you’re dealing with. 

**David bear**: By the way, many of these theories were originally created by people, but in the technological age, they are being created and perpetuated by bots. QAnon has no single leader like a Jimmy Jones or David Koresh. As you’ll read, some followers believe JFKJr never died and is Q. I’m sure I sound as crazy as I’m telling you these other people are, so I trust you will do your homework to be able to differentiate.  Disinformation has been propagated rampantly in the last several years by people like DU and Alex Arduini. They are benign until they have a platform. DU has more than a platform, he has a vote. 

### CONVERSATION ON 06-01-2020

**David bear**: Happy Monday!

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Nut job

**David bear**: Somebody should sue him.

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 07-02-2020

**David bear**: This next speaker is the douchebag who trolls your blog.  He’s the QAnon cult dude who is doing Doug’s bidding.

**Jeff Bergosh**: Yes I know who he is

**David bear**: Give him hell.  He trolled me today too

**David bear**: last night and today

**David bear**: 🤮🤯🔫

**David bear**: He’s reading Doug’s questions.  This guy doesn’t know shit about this subject.

**Jeff Bergosh**: 
Of course

**David bear**: Call him a sea lion

**Jeff Bergosh**: LOL

**David bear**: It costs fair market value to take the property and the condemning authority has to pay all legal fees and costs.  Ask Doug how much he thinks those costs would be per square foot/acre.

**David bear**: Our eminent domain lawsuit with ECUA was a difference between $5k and $32k and it cost ECUA $1.2MM on fees and costs because they wouldn’t pay our rate.

**Jeff Bergosh**: Doug is just being a tool

**Jeff Bergosh**: That’s my prediction

**David bear**: I hope so

**David bear**: Doug is a douchebag!

**Jeff Bergosh**: Yes he is the human douchenozzle

**David bear**: The benefit can be monetary or non monetary benefit

**Jeff Bergosh**: And we have to get these properties.  This has to happen— we need this connector road!

**David bear**: The statute says you have to pay fees and costs using a formula.  I think that’s what you’re talking about when you say 30%.  We argued the 30% benefit basis fee was unconstitutional because the constitution says we are entitled to reasonable fees and costs and the judge ruled in our favor.

**David bear**: You can take their property and finish the property before you ever finish negotiating the price of the taking.  That’s what happened in our case

**Jeff Bergosh**: I hope ours is cheaper!

**David bear**: project, not property.  sorry

**David bear**: I think it would be.  If the total purchase for the project is $300k, you’ll be way cheaper than fighting eminent domain

**David bear**: I like her too

### CONVERSATION ON 07-11-2020

**David bear**: You didn’t like my comment on your blog?

**Jeff Bergosh**: I didn’t see it yet

**David bear**: 👍

**Jeff Bergosh**: Just posted it

**David bear**: Thank you

**Jeff Bergosh**: Yeah he is not a fan!

**David bear**: Why are you letting him play on your page?

**David bear**: And why would you hide Kim’s comments about Alex?

**Jeff Bergosh**: I didn’t 

**David bear**: You have 2 of her comments hidden

**Jeff Bergosh**: Not purposefully-  Facebook didn’t like the words she used?  I’ll I hide them

**Jeff Bergosh**: Un hide

**David bear**: Facebook doesn’t hide them. If Facebook hid them, no one could see them. You may have set your page up with filtering words or hit the hide function on the specific comment, but Facebook doesn’t hide comments and let friends still see them. Trust me, since Underhill started doing it and I filed my lawsuit against him for doing it, I’ve researched and hired experts to explain it to me. I understand how it works. 

### CONVERSATION ON 07-12-2020

**Jeff Bergosh**: David—I have a huge list of words not allowed on my posts on my commissioners page, and if someone uses any one of these words it automatically hides the post.  I do not go in and hide posts— but I did add a tremendous number of filter words because I was getting spammed to death by Jeff Love and others 

**David bear**: OK.  Be careful because that is considered viewpoint discrimination.  As a public official, you may censor hate and would language, but you can’t censor something based on the content or viewpoint.

**David bear**: foul, not would

**Jeff Bergosh**: Sure- I get that

**Jeff Bergosh**: And I don’t do that

**David bear**: That’s part of my lawsuit against DU

**David bear**: If words are being used that automatically filters a viewpoint you are.

**David bear**: ...if those words aren’t hate speech or foul language.

**Jeff Bergosh**: Jeff love was saying the same things over and over about meth and gangs and other shit

**Jeff Bergosh**: That’s what necessitated the switch 

**David bear**: I would filter that

**Jeff Bergosh**: Cops and kids

**Jeff Bergosh**: But not Kim Carmichael or anyone else

**David bear**: He’s a freak. He’s got like 5 profiles and is just a scary dude who threatens people

**Jeff Bergosh**: Her comments are on my site

**David bear**: good.  She’s super smart and can be a good ally.

**Jeff Bergosh**: 👍

**David bear**: That guy Alex is a menace and is Dougie’s mule.  He is a self-proclaimed QAnon adherent and his intention is to leverage Doug and Jacqueline’s reach to figuratively blow shit up.  He’s actively working against you behind your back and is only saying shit like he said on your page to trap you.  If you like his comments, he will share with others that you believe what he believes.

**David bear**: If you don’t like his comments, he will share with others that you’re against God, freedom, liberty, etc.

**David bear**: He made a post on his page, “If God is with us, how can anyone be against us?”

**David bear**: I cannot emphasize enough how dangerous he is.

**David bear**: If you don’t think he’s dangerous...

**David bear**: https://www.facebook.com/alexanddanaarduini/posts/172302161134314

### CONVERSATION ON 07-14-2020

**David bear**: Your buddy Alex is making a big deal about Health and Hope Clinic applying outside agency funding from the County. It would be wise to state a conflict of interest up front and ask that it be considered separately from other outside agencies so you may vote for the rest of them without having to conflict out of all.

**Jeff Bergosh**: Thanks.  I will do just that.  Appreciate the heads up!

**David bear**: Ask County Administrator why this meeting is not being live streamed on the County’s website.

**Jeff Bergosh**: They fixed it just now

**David bear**: Thanks

**David bear**: Ask DU if he’ll connect his FB accounts with the county for them to have access.

**Jeff Bergosh**: 😂

**David bear**: This is such an exercise in futility.  Nothing real is going to be discussed until after August 18th.

**Jeff Bergosh**: More than likely you are right

**David bear**: Do you have any problem with ACE carrying over unspent funds from this year to use next year for Foo Foo?

**Jeff Bergosh**: I don’t — in fact that’s not a bad idea.  But VP is Probably pressuring Janice to sweep any unexpended funds to re-allocate towards advertising for the hotels

**Jeff Bergosh**: ......back to VP

**David bear**: That’s the same money

**Jeff Bergosh**: I know but instead of going to ACE they Might want unexpended ace funds to go back into direct marketing for out-of-state visitors to come to Pensacola

**Jeff Bergosh**: Area

**David bear**: That’s what Foo Foo is.  They are requesting our help with money and we gave them $150k with the anticipation of rolling these funds over to next year.

**David bear**: Foo is the cultural tourism marketing campaign for the county.  VP doesn’t do it.

**David bear**: Janice is fucking around and telling everyone commissioners are saying we can’t roll it over.

**Jeff Bergosh**: Then I think that makes sense.  Unless it’s not permitted statutorily, I think it makes sense to roll the unexpended funds forward which will have the ancillary effect of reducing budget pressures next year when we are hopefully out of the weeds with this COVID pandemic

**David bear**: We’ve done it before and VP/PSA has done it every year.

**David bear**: That was ACE’s thought.  ACE suspended Foo and looked at the anticipated reduction in TDT collections for next year to come up with a 2 year plan (this year and next).  If ACE can’t roll it over, it puts it in a bind to put together a legitimate event next year.  We’re looking at a $825k reduction without the rollover.

**David bear**: That’s about 50%

**Jeff Bergosh**: I think the two year plan is the wise course and I believe you should be able to roll your unexpended yet allocated current year funds over to next year.  

**David bear**: Thanks

### CONVERSATION ON 07-15-2020

**David bear**: Good job!

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Your good suggestion!

**David bear**: You know that pissed off DU.  He wanted to trap you and let his minions use it against you.

**Jeff Bergosh**: He’s easy to spot

**David bear**: I hope he’s crying inside

**Jeff Bergosh**: Thank God he doesn’t run military strategy

**David bear**: He is a commander in the naval reserves and trains people in cyber security.  He apparently has started working in that field again in the public sector. If our country has cyber security issues with election interference, who’s fault is it?

**David bear**: Just saying’

**Jeff Bergosh**: Good point

**David bear**: See!

**David bear**: Don’t respond.  Let the others defend the organziation

**David bear**: DU is a dirty fucking cream

**David bear**: creep

**Jeff Bergosh**: He is

**Jeff Bergosh**: I think I let him know what I thought of his bullshit

**David bear**: Ask him why he had to file for bankruptcy.

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: He just has no credibility

**David bear**: Tell him we’ll now have beach access #4 to drive e tourism to the west side.

**Jeff Bergosh**: 😂😂😂

**David bear**: This is why I was asking.  Janice is saying unified budget could not roll funds over to next year.

**David bear**: ACE rolled over funds in a previous year.  You may do whatever the fuck you want.  Pam is working DU’s angle.

**Jeff Bergosh**: She danced around the question though.  I wanted to know if there was a statutory prohibition on it, and if not, who is it that controls the unencumbered carryforward

### CONVERSATION ON 07-16-2020

**Jeff Bergosh**: David-Alex Arduini just posted on my blog and mentioned you.  You may want to respond.....

**David bear**: Thanks 

**Jeff Bergosh**: 👍

**David bear**: How’s you like my reply?

**David bear**: How’d 

**Jeff Bergosh**: Loved it!  God’s chosen people!

**Jeff Bergosh**: LOL

### CONVERSATION ON 07-17-2020

**Jeff Bergosh**: He’s a liar

**David bear**: Wait, What?!

**Jeff Bergosh**: He pulled funding for that project the minute he was elected and redirected funding elsewhere then wanted the rest of us to put new money into Sorrento Road 

**Jeff Bergosh**: Lying fraud

**David bear**: Hahaha.

**David bear**: He’s a douchebag

**Jeff Bergosh**: Yep

**David bear**: Got a minute to talk?

**Jeff Bergosh**: I notice his tendency to talk a lot of shit online when we don’t have meetings for a few weeks

**Jeff Bergosh**: Sure

### CONVERSATION ON 07-23-2020

**David bear**: ECW

**Jeff Bergosh**: Ha ha ha LOL

**Jeff Bergosh**: Of course he wants debates-  his boy has now slipped 20 points behind Casey for 2nd Place LOL

**David bear**: 3rd place...just sayin’

**David bear**: 2nd place loser

**David bear**: I thought you offered to debate him

**Jeff Bergosh**: In my race— the closest thing to watch is the battle for third place;  Trotter moving up to 10% and Doug’s Secretary down to 14%

**David bear**: Laughed at “In my race— the closest thing to watch is the battle for third place;  Trotter moving up to 10% and Doug’s Secretary down to 14%”

**Jeff Bergosh**: I wouldn’t back away from it- but why would I do it?  It only helps him

**Jeff Bergosh**: Better idea: the third-place championship debate between Doug’s secretary and Jimmy Trotter

**David bear**: Laughed at “Better idea: the third-place championship debate between Doug’s secretary and Jimmy Trotter”

**David bear**: This was a text between your attorney Greg Rettig and me.  Greg is a neighbor and friend of mine.

### CONVERSATION ON 08-06-2020

**David bear**: At the end of this morning’s meeting, Robert said there weren’t any available TDT funds sitting anywhere, but here is the spreadsheet from last year’s audit.  What is the $5.3MM???

**Jeff Bergosh**: That’s a great question— where did it go?

**David bear**: Worst case scenario, $2.8MM was supposed to be supplemental appropriation to unified that Janice cut in half.  

### CONVERSATION ON 08-07-2020

**Jeff Bergosh**: Got the invite from you to join Willie Kirkland’s fanboy site to promote Jesse Casey.  Thanks, but no thanks.  Got off that site fast last week when I saw it being conscripted by ECW into an ECW “light” fan site for my opponents.  11 days to go then all this “noise” gets shut off like a light switch being pressed to the off position.  Have a good weekend David— and BTW there’s a Marlette cartoon in today’s paper you should see—-the use the Budweiser logo prominently. 😎👍

**David bear**: I saw it.

**David bear**: I have been getting the ECW crazies kicked off Willie’s page.  I’m working on Jackie now.

**David bear**: I wish you had seconded Lumon’s motion last night

**Jeff Bergosh**: It didn’t have three votes and I knew it going in.  I would have considered something if he had brought something— but he didn’t.  It was poorly conceived and he was trying to build it on the fly like assembling a go-cart while it was going down the hill

**Jeff Bergosh**: Thus defeated 4-1

**David bear**: Sometimes you have to lose a vote to do the right thing.

**David bear**: Lumon knew that

**Jeff Bergosh**: Yes— he did well and scored big points with his constituency last night

### CONVERSATION ON 08-17-2020

**David bear**: Just checking in.  Do you need anything before tomorrow?

**Jeff Bergosh**: Nope good to go thanks David!! I’m just out putting signs up at precincts👍👍

**David bear**: Cool.  Good luck!!

**David bear**: BTW...

**David bear**: It was worth it

**Jeff Bergosh**: LOL. That’s great!  At ECW??

**David bear**: No, Tracy McAdams made some stupid post on her own wall and tagged Arduini.  He started talking shit about me and I responded.  I’m in timeout from all of FB

**David bear**: Not just a group page

**David bear**: Here’s my full post.  LDC Property is the LLC we formed to buy the old SPC property to build a new warehouse.  He was acting like I was fighting for all of the incumbents because I needed y’all help to protect my investment for a development.

### CONVERSATION ON 08-18-2020

**David bear**: Congratulations. Secretary ended up as third place. 

**Jeff Bergosh**: Yes he did!!! Bronze medalist just as I predicted!!  Thanks is for all your support David!!! Greatly appreciate it!!

**David bear**: All precincts reporting

**David bear**: Liked “Yes he did!!! Bronze medalist just as I predicted!!  Thanks is for all your support David!!! Greatly appreciate it!!”

### CONVERSATION ON 08-28-2020

**Jeff Bergosh**: My take on Andy’s cartoon from 2018

**David bear**: lol

**David bear**: Oh, I’ve seen the original

**David bear**: You need to hang it outside your office like DU has the original Marlette

**Jeff Bergosh**: Oh yeah , in the works

**David bear**: I want a Miller Lite can that has all of DU’s failed campaign signs falling out of it

**Jeff Bergosh**: LOL that would be funny!!!  It would include Jonathan, Megan Walters, LuTimothy, Cris Dosev, and Mike Hill.   It could say “less fulfilling, tastes FAKE!”

**Jeff Bergosh**: ......and instead of “Miller Lite” on the can, we could call it “Shiller-Lite” and put Doug’s cartoon face on the can!

**David bear**: Put his angry face from the PAC flyer

**Jeff Bergosh**: Marlette did one I could swipe— from during sheriff’s budget talks

**Jeff Bergosh**: Could be quite amusing!!

**David bear**: How about “Shiller Low Life Beer, the Perdido Bay of Beers.” (Miller High Life, the Champaign of Beers).

**Jeff Bergosh**: LOL I like it except for the reference to Perdido Bay because that’s in my district.   How about as pure as Bayou Chico!”

**David bear**: The Bayou Chico of Beers

**David bear**: Superfund site

**Jeff Bergosh**: LOL right!  And in Dildo Doug’s district

**David bear**: I forgot it was in your district because he did that video and pretended to drink the brackish water

**Jeff Bergosh**: I think I’ll call Andy and give him this great cartoon idea!  What do you think?

**Jeff Bergosh**: And when he says no I’ll say it doesn’t matter I’ll just do it for you using your old cartoons as the base material LOL

**David bear**: I’m sure he’ll jump right on it

**Jeff Bergosh**: LOL he’ll jump alright!

**David bear**: Do a picture of Marlette blowing Dosev

**Jeff Bergosh**: He’s such a fucking tool

**Jeff Bergosh**: Ha ha that would be great!!!

**David bear**: Oh wait, that’s what his articles displayed

**Jeff Bergosh**: I could manipulate his cartoon of Trump kissing Putin’s Ass— make Andy Trump and Putin Dosev!!

**Jeff Bergosh**: Now that would be funny!!

**David bear**: lol.  I’d probably leave that one alone.  I’m going to create the Swiller Low Life though

**David bear**: shille

**Jeff Bergosh**: I love that idea!!

**David bear**: Auto correct doesn’t want me to write iot

**Jeff Bergosh**: Shiller Low Life!! 

**Jeff Bergosh**: “The Campaign of Tears”. And have Doug crying

**David bear**: Oh, that’s good

**Jeff Bergosh**: ❤️👍

**Jeff Bergosh**: LOL

**David bear**: Thanks

**Jeff Bergosh**: 😂😂😂😂😂

### CONVERSATION ON 09-01-2020

**David bear**: Both emails sent to your D1 address. 

**Jeff Bergosh**: Thank u David!

**David bear**: 👍

**David bear**: BTW, I’m ripping up Pam and Janice about TDT. We have TDC meeting today. I’m tired of their lying about the money

**Jeff Bergosh**: Good!!

**David bear**: What was the document Alison wrote about your brother?

### CONVERSATION ON 09-02-2020

**Jeff Bergosh**: It was a response to a habeas Corpus for a prisoner our jail is holding.  One of her attorneys wrote it and Alison rubber-stamped it even though it was filled with errors and very harsh toward the trial court judge, my brother.  It was horrible David. 

**David bear**: This was my conversation with Greg Rettig. If Alison is telling you she doesn’t know what’s going on, she’s lying. 

**Jeff Bergosh**: Wow!!

**Jeff Bergosh**: Thank you

**David bear**: No problem. If you don’t mind, wait a few days to call him since I was just talking to him about Alison. 

**David bear**: If you already did, it’s no big deal. 

**Jeff Bergosh**: I’ll wait

**Jeff Bergosh**: Thx

**David bear**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-08-2020

**David bear**: What is the shade meeting topic?  The topic was not posted on County website.

**David bear**: BTW, TDC took official action last week to recommend to BOCC to appropriate 65% of all TDT to Unified Budget group like it has been done over the past 5+ years. Janice has proposed approximately 52% go to Unified Budget so she can increase county’s portion.  No where on the agenda does it mention the TDC’s recommendation.  Did Janice tell you about it?  She was present at our meeting.  Robert voted against it at the TDC meeting and stated publicly that he will not support it at BOCC meeting.  Who gave them the authority to withhold the TDC’s official action just because they don’t support it?  Call them out for it if they don’t bring it up at the beginning of the discussion.

**David bear**: I know you’re about to start your meeting but I thought I could catch you for a quick second.  Somebody (you!!) really needs to hammer Janice on why the fuck she didn’t put the TDC’s recommendation on the agenda and why she didn’t inform the TDC she was using TDT to buy a truck when she was specifically asked how she was spending the Marine Resources budget.

**Jeff Bergosh**: Hi David— just got this

**David bear**: 👍

**Jeff Bergosh**: Shade meeting was  a settlement offer

**David bear**: Make sense?

**Jeff Bergosh**: I think so it’s going to continue with negotiations 

**David bear**: Ask Janice why the TDC recommendation wasn’t on the agenda.  Was she trying to withhold it from the board?

**David bear**: Ask if the Naval Museum is open and accepting tourists.

**Jeff Bergosh**: Good point.  It’s closed

**David bear**: They have been all year (since December) and got $100k this year and another $100k budgeted for next year

**Jeff Bergosh**: When are they reopening?

**David bear**: They’re indefinitely closed.

**David bear**: They have not addressed it with the public

**David bear**: Beach landscaping is only $125k.  Ask Robert what the additional $250k is in beach maintenance.

**Jeff Bergosh**: Never reopening?? I find that hard to believe

**David bear**: I’m sorry, I didn’t mean to imply that.  I mean, they have not said anything about when they’re reopening.  I think the issue is allowing civilians on base to visit it.

**David bear**: It’s been closed since the terrorist attack

**Jeff Bergosh**: Yes that’s what I thought

**Jeff Bergosh**: They got the double whammy of 12-6-19 attack then COVID-19

**David bear**: He didn’t say this shit when he was bragging about Sunbelt using TDT

**Jeff Bergosh**: LOL

**Jeff Bergosh**: His position is “evolving”

**David bear**: Even a broken clock is right twice a day

**Jeff Bergosh**: 👍

**David bear**: Tell him to shut up

**Jeff Bergosh**: Nobody’s listening to him

**David bear**: Unless you’re scared

**David bear**: lol

**Jeff Bergosh**: He’s talking to himself 

**Jeff Bergosh**: LOL

**David bear**: It was so much nicer when he left the dais.

**Jeff Bergosh**: Yes it was

**David bear**: Is someone scratching their fingernails on a chalkboard?  That’s all I hear right now

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: Screeching

**David bear**: He saved up his time to talk until now

**David bear**: Fuck yeah, take it from Marine Resources.

**David bear**: For tonight, I can support Steven’s proposal

**David bear**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-24-2020

**David bear**: Tell him you’re sorry to hear he’s lost his house but surprised how damaged it got so high up on pilings.

**Jeff Bergosh**: Was his house in pilings though?

**Jeff Bergosh**: -*on

**David bear**: I think so but trying to find out. 

### CONVERSATION ON 10-01-2020

**David bear**: Apparently, it’s not our tax money when it supports basketball. 

**Jeff Bergosh**: Or jet ski tournaments LOL

**David bear**: Or trips to Canada

**David bear**: Laughed at “Or jet ski tournaments LOL”

**Jeff Bergosh**: Right!

**David bear**: Option B includes both sports facility and marketing for tourism. It can be used for advertising only or sports complex only. Any combination of options. 

Option A is only marketing. 

**David bear**: I don’t see Pensacola on Jeff Shusterman’s report as a top visitor origin. 

**Jeff Bergosh**: Me neither

**David bear**: Remind him of his sun belt comment

**Jeff Bergosh**: Yes

**David bear**: Robert teed it up for you to remind everyone of Doug’s support for TDT for sun belt. 

**David bear**: No!!!

**David bear**: That’s ok I guess. Just vote to do it tonight to start collecting in March/April

**David bear**: Make the motion to move Option B and begin collecting March 1.

**David bear**: That would be supported, I sense. 

**Jeff Bergosh**: Lumon is all over the place....

**David bear**: I know. I’m not sure what he’s doing. 

**David bear**: Thank you!

**Jeff Bergosh**: Absolutely!

**Jeff Bergosh**: LOL

**David bear**: I hope he enjoyed drinking brackish water. 

**Jeff Bergosh**: He probably got Montezuma’s. Revenge!

**David bear**: I hope so

**David bear**: I hope he got parasites

**Jeff Bergosh**: Both, and a tapeworm in his guts!

### CONVERSATION ON 10-21-2020

**David bear**: Does Escambia County School District have a required sealed bids for procurement?

**Jeff Bergosh**: Yes-- unless they are using the CCNA

**David bear**: Can you talk?

**Jeff Bergosh**: Sure

### CONVERSATION ON 11-05-2020

**David bear**: Have fun!

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 11-17-2020

**David bear**: Congratulations on another installation ceremony. Thank you for your leadership and continued friendship.

**Jeff Bergosh**: Thank you for your support and friendship David!!  Let’s kick some ass over the next 4 years and get this economy booming again!!  I’m ready!!

**David bear**: Emphasized “Thank you for your support and friendship David!!  Let’s kick some ass over the next 4 years and get this economy booming again!!  I’m ready!!”

**David bear**: I’m all in!

### CONVERSATION ON 12-10-2020

**David bear**: Janice was lying about how the 15 recommendations are made to the governor.
They could all together recommend all 15 to the governor.  The statute just requires the 3 recommendations be made for each vacancy.

**David bear**: Sorry, Y’all, not they.

**David bear**: Pay compression is a real problem.  A bigger problem is if the county staff gets the authority to unilaterally make pay changes

**David bear**: You should ask Janice how the Constitutional Amendment #2 minimum wage increase is going to effect the county’s budget moving forward and how the administrator plans to address it.

**David bear**: If Janice begins to increase pay for employees, it’s going to require you to have to consider tax increases.  She will throw you under the bus as soon as she can and as often as possible because tax increases are “not her fault.”

**David bear**: Hey, would you consider supporting Mary Hoxing to replace Nan Harper on the TDC in January when Nan’s term expires?  I’m sure Nan would like to stay on but I think Mary would better represent the county on that board.  Nan never seems prepared (She could very well be though) and hasn’t added much to the dialogue.

**David bear**: Statute says no more than 3%, not exactly 3%

**David bear**: Ask where in the statute allows that

**Jeff Bergosh**: Sure I’d look at that.  I really do not know either of them.  Are you supportive of my appointment to the Child Service Committee over Lumon....I’ve been nominated by the Chairman but Lumon seems very slighted and is pushing back even though he already serves on 6 committees. 

**Jeff Bergosh**: I’d like to know your stance on that David

**David bear**: Sorry, listening to Pam and Janice lie.  Yes, I support you but would like you to hold it until January.  I heard Lumon say you should be on it.

**Jeff Bergosh**: Thanks.  That will be the chairman’s call.  If it goes to January Lumon will have three votes for himself to be voted into that board upon Doug’s return.  Saying he would vote NO tonight signals that.  You see this, right??

**Jeff Bergosh**: Seems odd, childish to push back like he did.  Very very poor form and

**David bear**: Ask Pam why she’s apposed to an audit.

**David bear**: opposed

**David bear**: The State Auditor General will determine what is allowed by law.

**Jeff Bergosh**: I don’t want to alienate he and Steven but it’s not Burger King— have it your way

**David bear**: Laughed at “I don’t want to alienate he and Steven but it’s not Burger King— have it your way”

**Jeff Bergosh**: .......or maybe it is

**David bear**: https://www.pnj.com/story/news/2020/12/10/santa-rosa-county-fires-board-attorney-roy-andrews-after-waste-pro-issue/3882684001/

**David bear**: It can be done. 

**Jeff Bergosh**: Wow

### CONVERSATION ON 12-16-2020

**David bear**: Hey Jeff.  Circling back about Mary Hoxing for TDC.  She’s going to submit her resume/bio and I’d like your support for her to replace Nan Harper.  Can you support her? Thanks

### CONVERSATION ON 12-17-2020

**Jeff Bergosh**: Sure

**David bear**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-27-2020

**David bear**: Who is this?

**Jeff Bergosh**: Anonymous poster.   I don’t know who it is

**David bear**: Ok. Interesting how I got dragged into it. 

### CONVERSATION ON 12-28-2020

**Jeff Bergosh**: Yes it was— and of course I did as well.  

**David bear**: Well, of course. However, it’s your blog so it makes more sense than me being randomly included. No matter. Have a great day. 

**Jeff Bergosh**: That’s a fact.  Have a great one David!

### CONVERSATION ON 01-16-2021

**David bear**: Are you going to vote to pay Underhill’s legal fees?  it’s on your 1/21/21 agenda.

**Jeff Bergosh**: Not planning on it.... I don’t think he’s got three votes.  It will be a Judge making that decision, forcing us to do it

**David bear**: Good. He didn’t comply with the policy by notifying Alison within 10 days. It’s also over $250/hr. Plus, Underhill intentionally defamed Miller and violated his rights. There’s an exception in the policy and law that says you don’t have to pay if he does that.

### CONVERSATION ON 01-21-2021

**David bear**: I just watched the portion of you November 7, 2019 BOCC meeting discussion about Underhill’s fees.  You made a motion to pay his fees once he prevailed in his lawsuits AND provided evidence he paid his fees.  Not only did he (or anyone) not second your motion, he still hasn’t paid the fees.  It’s in the backup.  He’s paid less than half and has paid nothing since 12/12/19.

**Jeff Bergosh**: Thanks for that David

**David bear**: Yes sir.  Have fun!

**Jeff Bergosh**: 👍

**David bear**: If Underhill plans to vote again, ask why he was previously conflicted from voting due to the measure inuring to his special private gain but now is not when it pertains to the same subject.  This screenshot is from Form 8B.

### CONVERSATION ON 01-26-2021

**David bear**: Will you share the complaint filed by DU against you guys?  It will be up on Clerk’s site soon enough but I’d like to read it.

**Jeff Bergosh**: Here it is.  We will see what the judge does with it

**David bear**: By the way, I informed the investigator at the commission on ethics that DU made the motion for the county to pay his fees and did not file a Form 8B conflict of interest.  He did it in November 2019 too.  That’s a big no no...

**David bear**: Thanks

**Jeff Bergosh**: I confirmed yesterday that we won’t simply bow down... we will appeal it if he issues a writ of mandamus

**David bear**: Good.  PNJ did another hack job

**David bear**: I liked your quote

**Jeff Bergosh**: Yep.  They always do.  “ when EF Hutton talks people listen” LOL

**Jeff Bergosh**: Thanks!

**David bear**: Laughed at “Yep.  They always do.  “ when EF Hutton talks people listen” LOL”

**David bear**: FYI, where Ed quotes the board’s policy, “It is the Board’s policy that for cases involving current...County employees...personally named in any civil...action for any action within the scope of their duties and responsibilities, the County will prospectively provide legal representation or pay reasonable attorney’s fees and costs if the procedures in this policy are followed and if allowed by Florida law. (emphasis supplied),” he highlighted sections that meet their argument.  However, he neglected to highlight the section of the policy that says, “...if the procedures in this policy are followed...”  I did a public records request to Alison for DU’s compliance with this policy to send notice to the county through its attorney that he would be requesting the county pay his legal fees.  I specifically copied the policy language and asked her for his notice.  She said there wasn’t one.  He did not follow the policy, therefore, you shouldn’t be obligated to pay his fees.  This language says you will pay the fees IF the policy has been followed.

**David bear**: The policy also states you don’t have to pay these fees if, “...it appears clear from the relevant materials that the person...acted in bad faith, with malicious purpose or wanton disregard of human rights...”

**David bear**: Check email when you can

**Jeff Bergosh**: Just got them.  I don’t see where he followed our policy and specifically made the request in writing as the policy requires.  Did I miss that somewhere?

**David bear**: You didn’t miss it.  That’s the point of those emails.  He didn’t follow the policy.  The policy says you shall pay his fees if the policy was followed.  No requirement to pay fees.  They certainly can’t argue he’s not required to follow the policy but you are.

**Jeff Bergosh**: I don’t disagree— but as I read the policy I believe it gives us even greater latitude than what you describe——even if he had followed the policy.  It says we “May” take one of five actions upon receiving a request for repayment by the county attorney.....one of those options is for the board to “deny the  request and make alternate findings....”

**David bear**: Yep. Support for your denial can be:
1. He didn’t follow policy
2. Policy doesn’t allow you to pay if he didn’t follow it. 
3. He acted in bad faith, with malicious purpose or wanton disregard of human rights. 

**Jeff Bergosh**: I’m looking at the Thurber case as well.  Two prong test before fees can be paid.  1.  Was the act at issue in conjunction with the official’s official duties (in Underhill’s case here- the court says Yes.)
And 2. Did the conduct at issue “serve a public purpose?”   Here I believe underhill’s online attacks and rants Did NOT serve a public purpose.

**David bear**: I don’t disagree with you, but I think that 2nd point may be difficult to argue.  Playing devil’s advocate: If the act was in conjunction with his official duties, don’t his duties serve a public purpose?  I don’t believe it serves a public purpose to allegedly defame citizens, but the court says he’s immune from prosecution of that.  If you can’t argue the merits of whether it’s defamation, how do you prove it didn’t serve a public purpose.  I would simply argue he did it in bad faith and with malicious purpose.  He keeps saying he’s never going to stop talking to citizens the way he does.  He intends to defame and hide behind the immunity protection.  He’s like a man who hides behind a child or woman during a robbery or something.

**David bear**: Are you aware we have a hearing in our lawsuit on Monday?

**Jeff Bergosh**: I didn’t know that David.  Is the hearing on Zoom?

**David bear**: Unfortunately no

**Jeff Bergosh**: Forwarding you a document

**David bear**: Emphasized “Most, but not all, instances of doing something in the course of one’s duty also lead to the conduct being considered “in the public interest.”  But not all.”

**David bear**: https://ricksblog.biz/is-gilley-a-professional-confidential-informant/

**David bear**: Who’s spreadsheet?

**David bear**: Whose

**David bear**: I wonder if fees were requested in Albritton v. Handy

**David bear**: Gandy 

**Jeff Bergosh**: Alison

**Jeff Bergosh**: But it’s not a slam dunk

**David bear**: Nope. Not for either party but I have confidence you guys can prevail. 

**Jeff Bergosh**: Doug is getting savaged by the comments on the PNJ Facebook site.  Ouch!

**David bear**: good.  I’ll check it out.  Thanks

**Jeff Bergosh**: It’s like a UFC ground and pound beat down 

**David bear**: hahaha

**Jeff Bergosh**: 👍😎

**Jeff Bergosh**: Yo Adrian we won!!!!

**David bear**: Wait.  The judge already ruled?

**Jeff Bergosh**: No

**David bear**: oh.

**David bear**: I got so excited I just wet my pants

**Jeff Bergosh**: LOL

**Jeff Bergosh**: That’s him explaining how his beat down is actually him “winning!”

**David bear**: I guess he’s like Fred Levin.  As long as they spell his name right, any publicity is good publicity.

**Jeff Bergosh**: Maybe

**Jeff Bergosh**: Wendy is NOT going to like it!

**David bear**: hahaha

**David bear**: Poor Wendy

**David bear**: Always the victim

**Jeff Bergosh**: Yep

**Jeff Bergosh**: ⛄️

**David bear**: You know they’re suing their insurance company for denying their hurricane claim?

**Jeff Bergosh**: I heard

**Jeff Bergosh**: Maybe he wants to be one when he grows up?

**David bear**: They made a claim to FEMA for the flooding completely destroying their house.  Apparently FEMA denied their claim so then they filed a claim against windstorm.  That was denied so they’re suing.

**David bear**: He’s too stupid

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Wow! Suing the company?

**David bear**: Suing the underwriter

**Jeff Bergosh**: What genius  lawyer took that case??  He/she must realize they’ll be working for free.......

**Jeff Bergosh**: Doug don’t pay

**David bear**: Green.  Same guy representing Edler

**Jeff Bergosh**: Wow. Maybe he’s independently wealthy

**David bear**: If Doug hasn’t paid Fleming for Miller’s case, you think he’s paid anything to Fleming for my case?

**Jeff Bergosh**: I’ve got Doug’s next election slogan!!!


Doug don’t play, Doug Don’t PAY!

**Jeff Bergosh**: No nada

**David bear**: Why does Tim Tolbert like Doug?

**David bear**: Laughed at “I’ve got Doug’s next election slogan!!!


Doug don’t play, Doug Don’t PAY!”

**Jeff Bergosh**: No idea

**Jeff Bergosh**: 💰💰Doug Don’t Pay💰💰

**David bear**: Doug’s done all of the remodel work at his house without any permits.  He was flooded in 2014 and remodeled it.  He claims this is the 5th claim against FEMA (his couple of claims and previous owners’ claims), but he’s never pulled construction permits since he moved in there.

**Jeff Bergosh**: Rules don’t apply to Doug

**David bear**: We’ll see about that.

**Jeff Bergosh**: Doug’s mantra “following rules is for losers!”

**David bear**: Unless he expects others to follow them

**Jeff Bergosh**: Well of course he wants the rest of us to follow them

**Jeff Bergosh**: Rules don’t apply to Doug

**David bear**: His mantra is “You’re corrupt and I’m the only person who will stand up to the corruption,” while violating gift reporting laws, disclosure of conflict of interest laws, public records laws, county policies, 1st Amendment rights, insurance fraud, construction fraud, filing for bankruptcy to avoid paying creditors, and never paying his debts.

**Jeff Bergosh**: Yes but because he is wrapped in the flag he feels like that stuff is beneath him.  He’s thinks he’s “Homelander” from “The Boys”

**David bear**: Oh yeah, he also accepted 2 jet skis on behalf of the tax-exempt jet ski school and never filed a tax return so they inured to his own special private gain.

**Jeff Bergosh**: Did he??

**Jeff Bergosh**: D’oh!

**David bear**: I watched that show and thought the same thing.  He reminded me exactly of Doug.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I want Doug to be in the transparent box like “translucent”. LOL

**David bear**: Laughed at “I want Doug to be in the transparent box like “translucent”. LOL”

**Jeff Bergosh**: (Metaphorically Speaking)

**David bear**: and I want to be the kid who sticks the bomb up his ass...metaphorically speaking.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Metaphorically speaking

**David bear**: lol

**Jeff Bergosh**: (then will let Bender clean up the mess all over the floor)

**David bear**: hahaha

**Jeff Bergosh**: *we’ll

**David bear**: Janice will make him

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Who the heck is Shaunna Leslie?  I like her style on the comments section regarding Doug!

**David bear**: I thought the exact thing. I even checked out her page for a second after reading her comment. Hahaha

**Jeff Bergosh**: She obviously has a dislike for Doug......

**David bear**: Or Wendy. 

**Jeff Bergosh**: Probably both

**David bear**: Shocker. They’re such pleasant people. 

### CONVERSATION ON 01-30-2021

**David bear**: WOW!  The editorial board at PNJ is so misinformed and misguided.  Unbelievable!

**Jeff Bergosh**: Yeah it’s another hatchet job.  Why do they continuously ride Underhill’s nuts?

**Jeff Bergosh**: Now, I’m getting out of my truck to play tennis with Ed Fleming LOL

**David bear**: I didn’t read where any of those judges said it was not defamation. I also didn’t read any of those opinions say he didn’t make those comments in bad faith or maliciously. I also didn’t hear Ed say Underhill followed the same policy he expects you to follow. 

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: Plus I still don’t think it passes the 2-prong Thurber test “did it serve a public purpose?”  NO

**David bear**: The complaint is on the docket now and Judge Coleman Robinson has been assigned.

**David bear**: Who is going to defend the county?  Rogers or Peppler?

**David bear**: Since the suit is against the BOCC, does Doug have the right to participate in your discussions?

**David bear**: Don’t let Alison hire Joe Hammons.  He’s not going to win your case.

**David bear**: I asked my attorney if DU could participate in your legal strategy meetings and he said, “My gut is that it’s up to the Board - if they tell him he can’t participate in discussions about the case he’d have a hard time compelling them to include him.  But they’re probably free to include him if they want to.”

**David bear**: That’s the $23k question

**Jeff Bergosh**: Yes it is

### CONVERSATION ON 01-31-2021

**Jeff Bergosh**: PNJ wrote a garbage editorial today.  I’m working a cartoon response.  What should this rat’s caption say?

**David bear**: “Where’s Quint?”

**Jeff Bergosh**: LOL I’d have to enter witness protection

**David bear**: lol

**David bear**: Maybe write “uint” next to the Q but in really small letters.

**David bear**: on the garbage stand

**Jeff Bergosh**: It’d have to be microscopic

**David bear**: “Well, no has ever accused the PNJ Editorial Board of being journalists.”

**Jeff Bergosh**: I like that!

**Jeff Bergosh**: Winner!

**David bear**: Ha

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Thanks for sending that memo.  That’s powerful stuff.  All cards now on the table😎👍

**Jeff Bergosh**: I just requested it from staff

**David bear**: Did you get a copy of the full memo?

**David bear**: Good

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I also asked if they’re going to use those arguments and Charlie says yes

**David bear**: There ain’t no way he can get a court to force you to pay unless Alison fucks it up on purpose. 

**David bear**: Charlie doesn’t like DU

**Jeff Bergosh**: Exactly.  And you’ve now successfully cockblocked  that from happening LOL 

**David bear**: That was what I intended by sending you her response to my attorney’s email. 

**David bear**: I’m sure she’s pissed from last Monday’s hearing. JJ broke her on the stand.

**Jeff Bergosh**: She needs to remember who her client is———it ain’t “Doug” individually

**David bear**: Btw, your attorney argued in his closing brief that Underhill’s comments and posts on social media about County business are not public records because the BOCC didn’t take action to authorize his communication. They never argued that at the hearing or in the briefs but adopted Fleming/Underhill’s argument for the brief. I bet Hammons never consulted the 4 of you on that strategy and only relied on DU and Alison for it. 

**Jeff Bergosh**: What???!!??

**Jeff Bergosh**: That’s bullshit

**David bear**: I’ll forward it to you

**Jeff Bergosh**: What’s he doing in there — taking a fucking Dive???

**Jeff Bergosh**: Can I publish Figlio’s memo on my blog?  I’d like to get that out there

**David bear**: I emailed it to your D1 email account too. 

**Jeff Bergosh**: Thanks David 

**David bear**: Sure. We sent it to your attorney. You can do whatever you want. 

**David bear**: Liked “Thanks David ”

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Outstanding

**David bear**: If it makes you feel any better about Hammons’s stupid argument, you were gonna lose anyway. 😂

**Jeff Bergosh**: LOL 

**David bear**: Sorry, I couldn’t help myself. 

**Jeff Bergosh**: 😂😂

**Jeff Bergosh**: Just read Figlio’s 12-pager....Wow!  That’s a fucking masterpiece!  Thanks for giving Charlie and Alison the “go-by” for them to get a win for the board on this!  With this document as their template— I believe the only way this gets fucked up is if it’s done on purpose

**David bear**: Exactly.

**David bear**: Figlio is a smart MFer.

**Jeff Bergosh**: .....but that option is out the window now as I’ve got eyes on it

**Jeff Bergosh**: Wish we had him on our team!

**David bear**: I sent that email to all 4 of you guys.

**Jeff Bergosh**: 😎👍

**David bear**: Laughed at “Wish we had him on our team!”

**Jeff Bergosh**: That’s beautiful

**Jeff Bergosh**: Nicely done David

**David bear**: Thanks.  That douchebag has gotten away with too much already.  I’m not letting anything slide.

**Jeff Bergosh**: I’m sure this will send him to the liquor store for a Sailor Jerry Tuesday🍺

**Jeff Bergosh**: Bottom’s up!

**David bear**: Hahahahaha

**Jeff Bergosh**: Wait -  I got that wrong— “Bottom’s Up!” Is what he tells Jonathan when they are on their special camping trips together

**Jeff Bergosh**: “I can’t quit you Boss” (instead of Hoss) 

**David bear**: Hahahaha

**David bear**: Laughed at “Wait -  I got that wrong— “Bottom’s Up!” Is what he tells Jonathan when they are on their special camping trips together”

**Jeff Bergosh**: They go on every out of town trip together—Jonathan goes on the taxpayers’ dime.  Nobody else brings their aid on these trips.  It’s weird

**David bear**: Laughed at an image

### CONVERSATION ON 02-10-2021

**David bear**: Do you still support appointing Mary Hoxeng to the TDC to replace Nan Harper? I would like Ronnie Rivera reappointed since we just voted him as vice chairman and to appoint Mary to the TDC. I like Nan but she never adds anything to the discussion.

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Who brings it forward?

**David bear**: I don’t know. It may come from Gilley? It’s a county appointment. Who normally brings those forward? Y’all have 5 names for the 2 spots. 

**Jeff Bergosh**: Janice or Robert Bender

**David bear**: Did you find out if Jonathan Owens is on the SRIA director short list?

**Jeff Bergosh**: Haven’t got the list

**Jeff Bergosh**: He’s not qualified

**David bear**: He’s not on it. I asked Liz Callahan. Is there though

**Jeff Bergosh**: Good!

**David bear**: He is at the meeting is what I meant to type

**David bear**: I told Bender to send me a pic of Jonathan if he starts crying. 

**Jeff Bergosh**: Maybe he doesn’t know yet

**Jeff Bergosh**: LOL

**David bear**: I think Ed Spears it’s going to get the job.

**Jeff Bergosh**: Is he well qualified?

**David bear**: I told Rick Outzen to go to your blog post with my memo

**David bear**: I think Ed probably is. They’ve got a park and Rec director from Tally and DOH director from Palm beach

**Jeff Bergosh**: That would be great.  He has an exceptional peace today about the OLF eight debacle

**Jeff Bergosh**: Well I hope he gets it if he’s a good guy and he’s qualified

**David bear**: Almost anything is better than Paolo 

**David bear**: Not Jonathan or Doug

**Jeff Bergosh**: Yes.  Jonathan is lucky he is employed—- Even if it is just to be Doug’s Fluffer boy

**David bear**: Laughed at “Yes.  Jonathan is lucky he is employed—- Even if it is just to be Doug’s Fluffer boy”

**Jeff Bergosh**: Ha ha ha

**David bear**: Karen is trying to derail their vote and asking for all applications. You may want to text your appointee and tell her not to let Karen undermine the board’s action of hiring the consultants to help refine the list b

**Jeff Bergosh**: I’ll do it

**David bear**: She’s only doing it for Jonathan 

### CONVERSATION ON 02-11-2021

**David bear**: Jesus.  Doug is shilling hard for Hemmer and Studer

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: Chugging their kool aid

**David bear**: Even your consultant is quoting Underhill on the future population there.  That’s a red flag on who they’re listening to.

**Jeff Bergosh**: Yep

**David bear**: What is Teresa saying about what Doug said?  I had to get on another call and missed a lot

**Jeff Bergosh**: She should not be able to speak

**David bear**: I agree.  She should go away.  Underhill read a previously written soliloquy.  Ask Teresa if she thinks Scott Miller is a political pollster, what does she think Travis does?

**Jeff Bergosh**: Exactly

### CONVERSATION ON 02-12-2021

**David bear**: At your upcoming BOCC meeting, I think you will be asked to support either Ronnie Rivera or Nan Harper for TDC.  After that, you will be asked to support the one of them who lost that first vote vs. one of the other applicants (Mary Hoxeng, Jason Nicholson, and Pat McClellan).  I hope you will support Ronnie in the first vote and Mary in the second vote.  Thanks

**David bear**: I believe Janice will be bringing it to the board

**Jeff Bergosh**: Thx

**David bear**: yes sir

**David bear**: Fuck Derrek Cosson

**Jeff Bergosh**: Yeah he’s a human walking piece of shit

**Jeff Bergosh**: You really should tell that fat fuck to go clean the house he sits around all day playing video games stroking his monkey while his wife brings home the bacon working at the bank he’s just a little househusband bitch

**David bear**: Did you see what he did yesterday?  He went to Studio 850’s post and went to every instance where it was shared and made that comment.

**Jeff Bergosh**: No

**David bear**: Laughed at “You really should tell that fat fuck to go clean the house he sits around all day playing video games stroking his monkey while his wife brings home the bacon working at the bank he’s just a little househusband bitch”

**Jeff Bergosh**: I just looked briefly when you tagged me

**Jeff Bergosh**: I try not to look at too much social media it helps me control my blood pressure if I don’t

**David bear**: I commented on the other posts too.  Each post, I commented differently.

**Jeff Bergosh**: Thank you I should probably go look now :-)

**Jeff Bergosh**: But yeah that redheaded fat fuck he sits at home on Nintendo while his wife works what a fucking loser

**David bear**: Don’t waste your time.  I just basically told him he had no redeeming qualities

**Jeff Bergosh**: That’s too kind

**Jeff Bergosh**: He has less than that

**David bear**: I called him out for Dick’s Blog and said he must have been really embarrassed of himself for doing it and getting caught

**Jeff Bergosh**: He’s nothing but a want to be player he couldn’t do what we do he couldn’t do what I do he would be lost in the fucking sauce. So he sits around thinking about what he wishes he could do as he sits around Denver in the snow and his wife brings home the bacon

**Jeff Bergosh**: He’s just a fucking loser

**David bear**: Emphasized “He’s just a fucking loser”

**Jeff Bergosh**: Yeah that dicks blog episode Was probably one of the most embarrassing things that ever happened to him right up there with when his sister walked in on him when he was jacking off to the underwear models in the newspaper

**David bear**: lol

**Jeff Bergosh**: The world a better place since he moved to Denver

**David bear**: 👍

**David bear**: I called him out for using the Underhill approach to telling the truth

**Jeff Bergosh**: Underhill is a little bitch. I took his ass to school yesterday when he tried to talk shit about economic development. He sat there and listened like a little bitch

**David bear**: I had to get off the meeting for a conference call and miss a large part of that.  Everything DU knows about economic development starts at Bankruptcy court.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: A fucking simpleton

**David bear**: His biggest lender in that deal was Gulf Coast Community Bank.  My siblings and I were the largest stockholder in that bank and we lost our ass because of souchebags like him.

**David bear**: douchegogs

**David bear**: You know what I mean

**Jeff Bergosh**: Souchebags

**Jeff Bergosh**: Yeah I know what you meant because in the Oxford dictionary of Termanology next to douche bag there’s a giant picture of Doug Underhill

**David bear**: Hey, have you picked your choice for recommendation for the Childrens Trust?

**Jeff Bergosh**: Tori woods, David Peaden

**David bear**: Dang. Ok. I was going to recommend Stephanie White. She works so hard for kids and she would make a great choice. 

**Jeff Bergosh**: I think I can add her

**David bear**: Peaden told me he hates kids. 

**Jeff Bergosh**: She called me too

**Jeff Bergosh**: LOl

**David bear**: 😂

**David bear**: Oh she did? My sister just called me and asked me to call. 

**David bear**: I just checked my Oxford dictionary. You’re right!

**Jeff Bergosh**: LOL

### CONVERSATION ON 02-15-2021

**David bear**: I just saw the fuck up pam made with the CARES Act grants and the 1099’s. 

**Jeff Bergosh**: What did she do?

**Jeff Bergosh**: D’oh

**David bear**: LOL

**Jeff Bergosh**: Where’d that letter come from

**David bear**: I don’t know why she doesn’t want her work on TDT being audited?? 🤷‍♂️🤦‍♂️

**David bear**: I believe it was sent to all of the commissioners. I got it from another

**Jeff Bergosh**: It wasn’t sent to me

**Jeff Bergosh**: It got by me

### CONVERSATION ON 02-17-2021

**David bear**: Why doesn’t the county have a lobbyist right now?  Does Janice think she can do it herself or is she telling you guys you have a lobbyist?

**Jeff Bergosh**: Gentry gave notice.  I believe we’re negotiating with another firm to replace him

**David bear**: Gentry is now the inspector general for the public service commission

**David bear**: Senate appointed him last week.

**Jeff Bergosh**: Yeah I believe that’s the reason he left.  Too bad he couldn’t still lobby AND hold that new high-power job LOL

**Jeff Bergosh**: He’s be “Super-Lobbyist!”

**David bear**: I don’t think it’s paying him what he’s used to making

**David bear**: He ran FL HBA for years

**Jeff Bergosh**: Power is his payment

**David bear**: Word

**Jeff Bergosh**: Why do people run for the $29K state Republican jobs

**Jeff Bergosh**: 👍😎

**David bear**: https://www.flooddefenders.org/your-county

**David bear**: Have you seen this shit yet?

**Jeff Bergosh**: Nope

**Jeff Bergosh**: Smells like Doug

**David bear**: It looks like another DU propaganda maachine

**David bear**: Yeah, the only picture of a house flooding is his

**Jeff Bergosh**: Yep

**David bear**: Just like flood trends.org

**Jeff Bergosh**: How is he monetizing this sudden “activism” about of all things—- floods??

**David bear**: It will begin to aggregate other articles soon

**Jeff Bergosh**: That’s the real question

**Jeff Bergosh**: He must have loved Geometry

**David bear**: I think he loved Germany more

**David bear**: Questioned “How is he monetizing this sudden “activism” about of all things—- floods??”

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I think he loves camping trips with Jonathan, his personal valet, MOST

**Jeff Bergosh**: LOL

**David bear**: Bye, rumor has it that gentry left the county because of Janice. 

**David bear**: Btw,

**Jeff Bergosh**: Wow

**David bear**: I don’t know any facts but that’s what I’ve heard. She’s a cancer and is killing the county from the inside. 

### CONVERSATION ON 02-18-2021

**David bear**: Aren’t you supposed to submit 15 names to the governor for the children’s trust?

**David bear**: Tell Robert, by adding an additional library location, it will take demand off other locations and should allow them to reallocate staff to the new location. 

**David bear**: They can measure staff need by counting visitors. 

**David bear**: He’s being directed by staff...

**David bear**: Tail wags the dog

**David bear**: Robert is doing what Janice told him. Why the fuck would he care about this and wait to sabotage it at the last minute? Yeah, Pam needs another fucking building. 

**David bear**: Fuck Doug

**David bear**: What was that final vote count?

**Jeff Bergosh**: 5-0

**Jeff Bergosh**: 😎👍

**David bear**: Good deal. Robert’s such a pussy and let’s Janice direct him. Fuck Doug for his stupid fucking comment about budget overruns. He’s such a douche bag. 

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: From me

**David bear**: When TDC appointment comes up, will you immediately make a motion to reappoint Ronnie, please?

**David bear**: Liked “Because they voted for it after the fact doesn’t excuse their bs”

**David bear**: Emphasized “And doesn’t buy back good will”

**Jeff Bergosh**: I plan to 

**David bear**: I imagine Doug is going to quickly move to reappoint Nan and I’d like you to beat him to the punch. 

**David bear**: Thank you

**Jeff Bergosh**: And then to add Mary Hoxeng

**Jeff Bergosh**: 👍

**David bear**: Yes!!!

**Jeff Bergosh**: I’ll do my best

**Jeff Bergosh**: Ronnies doing a good job right

**David bear**: Yes. He’s doing well. He was just voted in as vice chairman at our December meeting. 

**Jeff Bergosh**: 👍

**David bear**: Fuck Pam

**David bear**: What the fuck is complicated?

**Jeff Bergosh**: Right

**Jeff Bergosh**: It’s made to appear that way for no reason

**David bear**: She’s not correct. Pat McClellan is not a hotelier/lodge owner

**David bear**: Thank you

**Jeff Bergosh**: 👍

**David bear**: Glad Stephanie White and Carol Sekhon are going to governor 

**Jeff Bergosh**: Me too

### CONVERSATION ON 02-20-2021

**David bear**: https://www.pnj.com/story/opinion/2021/02/20/hold-escambia-county-commissioners-accountable-guestview/6787966002/

**David bear**: 
This is Studer hit job.  Peacock doesn’t know shit about economic development (clearly from the details in this article) and this is a long play for consolidation.  Peacock is trying to beat down BOCC so citizens will support city/county merger.

**Jeff Bergosh**: Just saw it

**Jeff Bergosh**: Frankly, looked like he was on coke

**David bear**: Yep.  He’s been trying to help Studer with Consolidation for over a year now.  I’ve had debates with him about it.

**David bear**: Laughed at “Frankly, looked like he was on coke”

**Jeff Bergosh**: I dealt with guys kike him a lot when I bar tended

**Jeff Bergosh**: All talk wannabes

**David bear**: He is incapable of hiding his allegiance to Quint.  I think this is also damage control for Travis (directed by Quint).  More blame on BOCC takes focus off Travis and DPZ.  Travis lives here and needs to continue to have trust so he can still make a living.  DPZ goes home and has clients all over the world.

**David bear**: He’s a shill.  Just like his previous comments about the roundabout at the beach.

**David bear**: BTW, your appointee to SRIA should censure Karen for violating the law by abstaining from the vote last week.  Unfortunately, there is no legislative penalty for violating the law but their board can act to punish her.

**Jeff Bergosh**: Travis has shown himself to be untrustworthy 

**Jeff Bergosh**: How could he be so stupid and careless?  He surely didn’t think we could request his emails.  I guarantee he didn’t know I could request his text messages, which I’ve done now.  Wonder what those will show?  I know that DPZ “team” will have a great and fun weekend agonizing over my records requests.  Meanwhile, I’m going to have a great weekend playing tennis, getting some rest and relaxation, having some great meals, and sleeping like a baby.  😎👍

**David bear**: Yeah, but you’ll have Ed Flewming as part of that and he’s representing a client who is trying to fuck you over every chance he gets...

**Jeff Bergosh**: I know— that’s a real issue that’s there.  He has a sort of weird soft spot for Doug that I don’t understand; he’s got a shithead for a client.  Sadly, I think Ed has got to realize at some point he’s working pro bono on this....Doug won’t pay

**Jeff Bergosh**: I frankly hope at some point Ed will fire him

**David bear**: Especially after I get the court to order him to pay me.

### CONVERSATION ON 02-21-2021

**David bear**: He didn’t like what I said
🤷‍♂️

**Jeff Bergosh**: God bless you for saying it to him!

**Jeff Bergosh**: And let the men who are engaged do the economic development

**David bear**: That’s pretty much what I told him. 
Our words weren’t as nice though. 

**Jeff Bergosh**: Wow!  What a volatile guy.  You definitely hit a nerve with him.  Thanks for setting him straight!

**David bear**: He’s a shill for Studer. 

**Jeff Bergosh**: No question about it

**David bear**: He really thought he could say what he said in that article and there wouldn’t be people upset about it. 

**Jeff Bergosh**: Glad he got called out.  And to start out the way he did back to you just shows how weak his position was.  Thank you for putting him in his place....which you’ve done!

**David bear**: The tech park is obviously something my dad has spent an unbelievable amount of time trying to work. You know how the grant terms have screwed them. John knows that too and he called out the tech park as a failure. That’s an attack on my dad. I don’t take that shit lightly. 

**Jeff Bergosh**: Nobody wants to take the time to understand the story of the tech park. that’s why it’s low hanging fruit for people that want to attack economic development but when the whole story is told about it people will understand clearly that we’re hamstrung in our efforts on that park.  But we’re trying trying.  Peacock knows better and yet he attacks anyway.  Weak.

**David bear**: Liked “Nobody wants to take the time to understand the story of the tech park. that’s why it’s low hanging fruit for people that want to attack economic development but when the whole story is told about it people will understand clearly that we’re hamstrung in our efforts on that park.  But we’re trying trying.  Peacock knows better and yet he attacks anyway.  Weak.”

### CONVERSATION ON 03-02-2021

**David bear**: You should have this for the next discussion  of the new library in your district.  If Robert (as Janice’s proxy) says you’re pulling funds away from other library staff, tell him the county had more than $1.2MM in revenues that exceeded expenses last year, which was more than $4.8MM more than anticipated in the budget.

**Jeff Bergosh**: In the library fund?

**David bear**: yep

**Jeff Bergosh**: Awesome!

**David bear**: Did you get the attachment?

**Jeff Bergosh**: Yes, just opened

**Jeff Bergosh**: Perfect!! 

**David bear**: I’m going through the county audit.  There are lots of questions...

**Jeff Bergosh**: Yes

**Jeff Bergosh**: We will be discussing it Thursday

### CONVERSATION ON 03-03-2021

**David bear**: Jump to page 281 of the transcript, line 6.

**David bear**: Starting on page 304, line 3 through page 308, line 18.

**Jeff Bergosh**: Thanks for the shortcut!

**David bear**: That’s where she tell Fleming she’s never heard his crazy argument before.

### CONVERSATION ON 03-04-2021

**David bear**: Hey, Marcus Pointe apartments were built next door to my warehouse after we built and began operating. There were Marcus Pointe residence concerned about us building there but none have complained about our operations disturbing them and their houses are literally 40-50 feet away.

**David bear**: residents

**David bear**: Tell that bitch to sit down

**David bear**: Karen didn't tell anyone she was coming to read that letter and resign. Scott Luth had no idea nor did Rick Byars. 

**Jeff Bergosh**: Maybe her residents in Nature Trail presses her.

**Jeff Bergosh**: Switzerland

**David bear**: What a chicken shit thing to do. Doug probably made her after the thing he tried blowing up over Salzman’s bill for underserved workforce development appropriation. 

**David bear**: No one authorized her to speak on behalf of FLWest

**Jeff Bergosh**: Yeah it was really weak

**David bear**: Y’all need to shut Underhill the fuck up when he starts talking about SOAR for Restore tonight. He’s just gonna act like a baby.

### CONVERSATION ON 03-06-2021

**David bear**: You playing tennis with Ed this morning?

**Jeff Bergosh**: Yes, at 8:30

**David bear**: check your email.

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Holy shit no wonder about yesterday’s “announcement”

**David bear**: It came out after his announcement

**David bear**: My ethics complaint should be going to the commission board at their April 16th meeting too.

**Jeff Bergosh**: Yeah well he must’ve seen the handwriting on the wall someone must’ve tipped him that was not going to go his way

**Jeff Bergosh**: Time to buy a 1.75 handle of sailor Jerry

**David bear**: Laughed at “Time to buy a 1.75 handle of sailor Jerry”

**David bear**: He is about to file a motion for summary judgment to dismiss the 1st amendment claim for qualified immunity, but we’re dropping the claim for damages.  Without my claim for damages, he’s not entitled to qualified immunity.  He’s fucked

**Jeff Bergosh**: Couldn’t happen to a nicer guy

**Jeff Bergosh**: The chickens are coming home to roost

**David bear**: That’s exactly how I feel.  I want him in jail, not just out of the seat

**Jeff Bergosh**: Someone should send this order directly to Ginger Bowden-Madden. It’s evidence that he violated Florida law. Let’s see if she Will act——unlike her predecessor bill Eddins 

**David bear**: So, this order specifically says it is not a determination of the 119 violation - she put it in footnote #2.  However, that will be coming soon and that’s precisely what I plan to do with it.

**David bear**: You think Alison is working for you?

**Jeff Bergosh**: I think she’s working for herself. But in all fairness to her and Charlie as weak as they are this is probably not due to their laziness which they also are. This is probably due to the fact that dildo Doug Underhill would never give it to them nor would he give it to Ed or any of his other attorneys

**Jeff Bergosh**: Is all about Doug

**David bear**: They all got it from ProLegal after they Bates stamped the pages. They said at the hearing they all had it and none of them looked at it. Ed said he randomly looked at a few of them and Alison said they looked at none of it. She either believed Underhill or didn’t want to interfere in his plan to withhold them. Either way, she lost this part of the case for you. 

**Jeff Bergosh**: Wow—So Allison had access to the records that Doug withheld but you and your attorney didn’t?

**Jeff Bergosh**: Because if that’s the case then yes I do have a significant problem with that

**David bear**: Correct. You paid Clark Partington Hart to download it and Pro Legal to Bate stamp it. I’ll double check to be sure, but I think they then went to the county and Underhill. 

**Jeff Bergosh**: Wow-they should have gone through them

**Jeff Bergosh**: I’ll find out

**David bear**: I may be wrong. JJ said he thinks he recalls Underhill picking them up directly from Prolegal. 

**David bear**: That, to me, is another problem. The county paid for CPH to download and Prolegal to bate stamp. Why does Doug pick them up? Why didn’t the county get them first since it paid for the download. It was their consultant performing the duties contracted to perform for the county, not Underhill. 

**Jeff Bergosh**: I think it’s because they are afraid of Doug

### CONVERSATION ON 03-09-2021

**David bear**: Jacqueline Rogers filed a JQC hearing against your brother. He may want to know

**David bear**: I think you knew about this but Underhill filed a PRR on you.  Weird how these things he asks for are public records but when he creates them, they’re not.

**Jeff Bergosh**: Yeah and he got a big donut from it. There was nothing there he thought I had orchestrated his sons arrest because my brother was the judge that signed the warrant

**Jeff Bergosh**: He’s got a mental condition and I believe his wife does as well

**David bear**: Yep

### CONVERSATION ON 03-13-2021

**Jeff Bergosh**: FWIW—take a look at the PNJ Facebook post of Andy Marlette’s hatchet job directed at me and Florida West/Scott Luth.  It backfired on them spectacularly and the commenters are beating the crap out of Andy and the PNJ.  It happened because like dummies, they mixed up the messages, talked crap about MATT Gaetz, put my picture up, and threw in the hashtag #freeBrittney.  Then, in their final act of stupidity, they locked the post for “subscribers only” so nobody could get the real context which was a hit on me.  A spectacular failure on their part which elicited a bashing to PNJ which they deserve.  A real, complete failure on their part here!👍😎

**David bear**: Hahaha. I’ll check it out. 

**Jeff Bergosh**: It’s golden.  What an epic fail

**David bear**: Laughed at an image

### CONVERSATION ON 03-15-2021

**David bear**: Here’s the one he did about me

**David bear**: It didn’t even make sense.

**Jeff Bergosh**: It’s stupid. Doesn’t even make sense.

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Thanks for letting me know about that, and thanks for any additional info you might be able to send me on it.  What a truly despicable human she is to go after Gary—-to get to me who she hates—when my Brother has done nothing to Jacqueline Rogers.  What a despicable, disgusting creature she is.....And those are the nicest characterizations I can make about her

**David bear**: Good morning. I got that as part of my public records request. That’s one of the documents the court ordered Underhill to release and gave to us on March 9th

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: .... I mean the date of Jacqueline’s threat 

**David bear**: No, I was just trying to figure it out but it’s not listed. 

**David bear**: What’s interesting, she addresses the last comment on the screenshot to Doug about Doug. I wonder if she thought she was talking to someone else, like Wendy or Jonathan. 

**Jeff Bergosh**: Yeah, I thought that was strange as well

**David bear**: It also shows JAR saw her own comment (profile pic in bottom right corner). 

**David bear**: Wait, that’s how it works. I just checked

**Jeff Bergosh**: Thanks for letting us know about it.  Any other nuggets in the documents this far?

**David bear**: All we’ve gotten so far were the documents the magistrate said needed to be released immediately.  It was only 189 pages and not really juicy other than that screenshot about your brother.  We’re still waiting on the section they needed to redact.  I’m sure it will be filled with gold.

**David bear**: If he didn’t previously delete stuff prior to the download.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Maybe this will contain the other shoes that are going to drop which are the reason why he announced he won’t run again?

**David bear**: My guess on timing of her complaint about your brother was when Avery Underhill got arrested.

**Jeff Bergosh**: That’s what Gary and I think as well

**Jeff Bergosh**: But what a conniving creep dog is to go after my brother for simply doing his job. What a creep. His son was the cause of that not my brother

**David bear**: Tell your brother to do a public records request to the JQC for the complaint about him.  Since he’s the subject of the complaint, there should be no reason to withhold it for privilege or an exception under statute.

**David bear**: I understand, Avery’s attorney negotiated a good deal for him to admit he did it and they would drop the charges. Doug and Wendy refused and Avery was found guilty in court.

**Jeff Bergosh**: 
Wow I feel sorry for their kid what a dumb decision

**Jeff Bergosh**: I like how he stands on principle using his son

**David bear**: They’re so fucking sick, they are punishing their kids and teaching them to be idiots

**Jeff Bergosh**: Yep I feel sorry for him, the son that is...Maybe he’ll figure it all out like Doug’s daughter did

**David bear**: Nope.  This kid is just like them.  That’s why he did what he did to get charged.

**David bear**: Underhill blocks his own daughter on FB

**Jeff Bergosh**: Dysfunction Junction

**David bear**: Emphasized “Dysfunction Junction”

**Jeff Bergosh**: And now Doug is going to follow Avery’s footsteps and be charged and convicted of violating the public records act. Yay go team!

**David bear**: Laughed at “And now Doug is going to follow Avery’s footsteps and be charged and convicted of violating the public records act. Yay go team!”

**Jeff Bergosh**: By the way did the judge sanction them for not finishing the tasks that have been ordered? Just curious if she just allowed Ed to continue it....

**David bear**: We haven’t asked and she didn’t directly decide to sanction. I’ve discussed making the request to the judge with my attorneys though 

**Jeff Bergosh**: David— would you have an issue if I put this exchange on my blog?

**David bear**: No, I don’t care.  It’s a public record

**Jeff Bergosh**: 👍

**David bear**: Sorry

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Thx for the heads up

**David bear**: PNJ just sent an alert

**Jeff Bergosh**: Not surprised

**David bear**: I thought it would be difficult for the governor to appoint another BOCC member

**David bear**: That complaint to JQC is right justified, not left justified. That means Doug posted it in their PM discussion. I think Wendy is using Doug’s page and having this conversation with Jacqueline. Doug and Wendy filed that complaint. Your brother definitely needs to PRR that shit. 

**Jeff Bergosh**: I’ll definitely tell him to do that

### CONVERSATION ON 03-20-2021

**David bear**: Impact fees??!! Where is Jacqueline’s post on this?

**Jeff Bergosh**: Exactly

### CONVERSATION ON 03-22-2021

**David bear**: Good morning.  Are you aware of the item on this week’s BOCC agenda for an increase in the allocation of $350k TDT to Pensacola Bay Center?  They say it’s because, “The Fiscal Year 2021 Pensacola Bay Center Budget was prepared before the impact of COVID was understood.” How is that even possible?  We were in the height of the pandemic and everyone around the world knew how the COVID was affecting us financially.  ASM Global knew they weren’t having events.  If they budgeted for more events, then shame on them for not properly preparing.  Why should we (the county) give them more money for their own mistakes, if they really poorly planned to begin with.  I’m not sure I believe they did.  This is not a small local company , hence their name.  They have been been well aware of how COVID was going to affect them financially.  They’re just looking for an additional supplement.  Please don’t agree to this increase.

**Jeff Bergosh**: Yes I saw this.  I’m going to ask if they received ANY federal relief funds and also why they didn’t reduce staffing if they were holding no events.

**David bear**: In the backup, it says they lost more than 50% of their revenue and they reduced full-time staffing by 33%, and furloughed the remaining full time staff during non-event periods, working part time staff to support revenue generating events.  Revenue isn’t just ticket sales, it’s also concessions.  If they reduced their revenue there too, the had no cost of goods, further reducing their expenses.  We picked up all untapped kegs and refunded them for the purchase when the governor shut down all on premise events.

**David bear**: If I were a commissioner, I would want to see their full financial statement before consideration of this.  The backup says it will be paid in monthly installments, not a lump sum, so the county has time to push this to the next meeting.

**David bear**: I’m telling you, this is bullshit and staff should have told them no.  No one has mentioned it to TDC because Pam and Janice don’t listen to TDC.  They don’t care.

**Jeff Bergosh**: They knew it would be hot potato.  Janice mentioned it to me in our last teleconference a week ago Wednesday.  It’s kryptonite

**Jeff Bergosh**: Maybe rescue plan money could be utilized instead?

**David bear**: They’re under contract.  They won’t walk.  They have a sweetheart deal here even without this additional money.  You still gave them $1.5MM this year even though they’re not doing the events.

**David bear**: Yeah, that’s what it’s for.  The new money the county is getting from the recent $1.9T stimulus is to be used for areas that lost revenue.  I want $3MM of it to go to TDT Fund 108 to make up for the loss of TDT collections.  THAT IS WHAT IT’S SUPPOSED TO BE USED FOR.

**David bear**: The county didn’t lose ad valorem taxes, they lost LOST and TDT

**Jeff Bergosh**: Makes sense to me—

**David bear**: Gas tax

**David bear**: Emphasized “Makes sense to me—”

**David bear**: If Janice brought it up to you a week ago, why didn’t she discuss it with the TDC chair?  I’m sure (but don’t know) she talked to Robert about it since he’s chair of BOCC and sits the TDC.  That was probably her way of saying she discussed it with TDC.

**David bear**: If it’s kryptonite, hang it around Janice’s neck as just another failure to do due diligence (if ASM Global’s finances look sound enough - every on premise and events business is hurting from COVID.) and her failure to communicate with the statutorily-created board charged with oversight of TDT.

**Jeff Bergosh**: It’s going to be one hell of a discussion.  The hits keep on coming

**David bear**: She’s a cancer

### CONVERSATION ON 03-25-2021

**David bear**: During the Bay Center discussion today, don’t forget all of the arts organizations, sports organizations, and Visit Pensacola was hurt badly during COVID and not only did they not get additional funding, their funding was cut by millions.  The Tourist Promotion Fund needs to be left alone for reserves at the onset of a catastrophe, not the backside.  ASM Global should have applied for CARES Act Funds and other federal stimulus funds like every other business who needed it.  Maybe some of the CARES Act funds Janice has been squandering could be used instead of TDT.

**Jeff Bergosh**: Do u have5 min?

**David bear**: Sure

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: We ended up doing 100 grand out of TDT with the caveat that it was to be immediately reimbursed upon receipt of the rescue plan funds. I also asked for all financials and did ask some very poignant questions which made him very uncomfortable I’m sure. Hope you have a great weekend David

**David bear**: Thanks Jeff.  I watched that portion of the meeting online this morning.  I appreciate your commitment to holding them accountable.  We all want the Bay Center and the county’s partner to be successful, but more due diligence should have been done and presented to you guys from admin.  Janice is out of her league.  That insurance add-on you missed at the end of the meeting was BS too.  Janice’s staff should have had that shit wrapped up before they dropped it on you guys at the last minute.  JANICE IS OUT OF HER LEAGUE!

**Jeff Bergosh**: I agree with you 100% that’s why I didn’t vote for her I voted for the guy from Cincinnati who nobody knew locally but who had tremendous experience and would’ve walked in here and clean shit up without the nepotism factor

**Jeff Bergosh**: Everyone else just lined up behind Janice like obedient lemmings

**David bear**: I don’t think anyone knew how incompetent she was.  I certainly didn’t know and unfortunately made recommendations in support of her.  Now, I whole-heartedly recommend terminating her asap.

**Jeff Bergosh**: She’s on a ticking clock based upon what she did to Matt Selover and when that bill comes due there could be two high-level staff members packing their bags

**Jeff Bergosh**: The first sign of arrogance and ignorance is doubling down no quadrupling down on bad decisions which she and Jerry Maygarden did instead of fixing something that they could have fixed and in the process they will cost this county hundreds of thousands of dollars in penalties fines in legal fees and I told her to fix it and she looked me in the eye and said you were wrong. She was wrong

**David bear**: Remove them both for being the cancer they are. 

**Jeff Bergosh**: Winter is coming

**David bear**: Loved “Winter is coming”

### CONVERSATION ON 03-29-2021

**David bear**: Update from my lobbyist. 

**Jeff Bergosh**: Thank you so much David!! That would be great news!

**David bear**: If anyone can make it happen, this is the guy. 

**Jeff Bergosh**: That’s fantastic—- because all other signs seem to be pointing to this thing moving forward.  I hope it doesn’t 

**David bear**: Senate still doesn’t have companion language. As I understand it, this is a representative who has an issue with his/her county commissioners. 
Not a statewide issue that really needs to be changed

**David bear**: I’m told, there may be a fix for that representative so we can avoid this statewide issue. 

**Jeff Bergosh**: Wow that would be amazing!!

**Jeff Bergosh**: To me it’s just common sense that this creates too much chaos if the target is one or two commissioners

**David bear**: I agree

### CONVERSATION ON 04-09-2021

**David bear**: check your email

**Jeff Bergosh**: Will do

### CONVERSATION ON 04-15-2021

**David bear**: I was at that Krokus/Kiss concert.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: It was great

**David bear**: Yep

**David bear**: I was in 7th or 8th grade

**Jeff Bergosh**: I was a sophomore in HS

**David bear**: You’re so much older than I am

**David bear**: 😎

**Jeff Bergosh**: Yes LOL

**Jeff Bergosh**: Remember it like it was yesterday

**David bear**: Laughed at “The singer for Krokus, Mark Storache, said “I think we’re at the Pensacola Fucking Zoo!”

### CONVERSATION ON 04-16-2021

**David bear**: Update:

**David bear**: Little has changed.
 
The longer version is the Senate Rules Committee Wednesday descended into a bit of chaos and weren’t able to move the bill out yesterday.  It will be back up in the committee on Tuesday.  They seem to be mitigating some of the more politically charged issues, but there is plenty of time for them to change their minds.
 
Because the Senate didn’t act, the House has not put out a new version of their bill yet that will be heard State Affairs Committee on Monday.
 
Things should become clearer early next week, though elections bills are usually one of those issues that pass in the final hours of session.

No real sense on your issue yet.

**Jeff Bergosh**: Thank you for the update David yeah I’ve been watching it as well it’s up in the Senate on the 20th and I’ll be watching that committee hearing as well in the rules committee

**David bear**: I’m concerned if this is a House leadership priority, it will be used to negotiate in conference.

**David bear**: Hopefully, it’s not

**Jeff Bergosh**: I hope it’s not I noted that Senator Baxley incorporated a lot of the houses version into his bill which was originally only 12 pages his version is now 37 pages but it specifically does not have that language about county commissioners in it

**Jeff Bergosh**: 
Hopefully it doesn’t come to that and Senator Baxley’s language wins the day because his bill is the better

**David bear**: I think the legislature is trying to do election reform and something will come out of the process, but I think the commissioner issue is a separate issue of one of the senators.  Hopefully, the senator can find a different solution to his problem and leave everyone else alone.

**Jeff Bergosh**: Exactly

### CONVERSATION ON 04-18-2021

**David bear**: This seems to be the root issue of his bill language.

**David bear**: https://www.tampabay.com/news/hernando/2020/03/11/hernando-commissioners-rezone-lots-for-state-rep-blaise-ingoglias-home-building-company/

**Jeff Bergosh**: I thought this might be the case as well but apparently it’s not.  This language wouldn’t impact the Hernandez commissioners— as they are already voted “at large”.

**David bear**: Hmm...interesting 

**Jeff Bergosh**: I’m hearing it is the Pinellas commissioners

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: Good Afternoon David— the house State Affairs Committee will be hearing this bill in about an hour.  This bill will impact Jackson County Commissioners as well.  Brad Drake represents this area and he’s sitting on this committee.  Do you have a rapport with Rep. Drake?

**David bear**: Yep

**Jeff Bergosh**: I’ve texted him but didn’t get a response 

**Jeff Bergosh**: Just trying to slow this down 

**David bear**: Their meeting started at 2:30

**Jeff Bergosh**: Yes I’m watching

**Jeff Bergosh**: Coming up on the bill in about 30 min

**David bear**: No response from him

**Jeff Bergosh**: He just responded to me said he would ask about the intent of that language

**David bear**: I tried calling him and he put me in GM and texted he was in committee. He said he’d call later

**David bear**: Liked “He just responded to me said he would ask about the intent of that language”

**David bear**: Interesting discussion about appointed vs elected school superintendent. 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: This guy isn’t going to budge on it.  Had a question on it and he said “I’ll get with you after to explain it...”. After they vote to approve it.  This is a sham, it’ll be ram riddled through on party line vote

**David bear**: Man, I had a call scheduled at 3:00 and had to stop watching. Assume it passed committee?

**David bear**: Oh, I see they’re still discussing. 

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Looks like it will go through as is, party line.  No Republican questioning it

**David bear**: My video just stopped and now I can’t rejoin it. 

**David bear**: 🤦‍♂️

**Jeff Bergosh**: D’oh!

### CONVERSATION ON 04-21-2021

**Jeff Bergosh**: Good afternoon David I am hearing the house will adopt the Senate version of the bill on elections. The Senate Bill does not have the provision about county commissioners running all together next year. Do your sources corroborate what I am hearing? Thanks David

**David bear**: As of this morning, it was still up in the air. I’ll check back in to see if they’ve heard that.

**Jeff Bergosh**: Thx

**David bear**: 👍

### CONVERSATION ON 04-26-2021

**David bear**: Checked the status of the election bill. It passed the senate floor this morning without BOCC language. Apparently, the governor doesn’t like the bill either and it could all fall apart.

**Jeff Bergosh**: Thanks for the heads up David!

**David bear**: I’ll let you know if I hear more

**Jeff Bergosh**: Thx David!

### CONVERSATION ON 04-27-2021

**David bear**: Over night a new strike all was filed in the house that does not include the bocc language 

**Jeff Bergosh**: That’s fantastic news David!!!!

**Jeff Bergosh**: I’m looking now.  Wondering if it was a strike all and Insert of the precise senate bill language? My guess is that’s what it was

**David bear**: https://flsenate.gov/Session/Bill/2021/90/Amendment/107453/PDF

**Jeff Bergosh**: It’s not reflected on the house site yet

**Jeff Bergosh**: Which means he’s going with the Senate version which is fantastic

**David bear**: Yep. 

**Jeff Bergosh**: Looks like some dummies in the house are trying to add amendments to Ingnolia’s strike all amendment which will serve to kill this bill this year if they don’t knock it off.....running out of time and Senate may not look kindly on any alterations of their passed bill

**Jeff Bergosh**: Just glad that language is gone 😎👍

**David bear**: I think it’s a stupid bill and hope that actually happens. 

**David bear**: Emphasized “Just glad that language is gone 😎👍”

**Jeff Bergosh**: they lost one Republican supporter already....if they ramrod that commissioner election language I believe they would’ve lost another three whose constituent commissioners would’ve been negatively impacted ——which would’ve led to a 2020 tie which means the bill goes nowhere

**Jeff Bergosh**: That’s why the house should just take the clean senate bill if they have any hopes of passing it this year

**David bear**: Yeah, I don’t think the senate wants to play, certainly not with Ingnolia’s stupid personal issue. 

**Jeff Bergosh**: Exactly.  Thanks for all your assistance

**David bear**: Of course. You got a second to talk?

**Jeff Bergosh**: Yes

### CONVERSATION ON 04-30-2021

**David bear**: The bill passed without the BOCC language

**Jeff Bergosh**: So the senate passed it and the house did as well?

**Jeff Bergosh**: Glad it passed and glad that language came out!!

**David bear**: Yes, the senate bill passed and the house had laid the senate bill on the table (I'm told that means they accepted the senate bill).

**Jeff Bergosh**: Glad it over.  Thanks for your assistance David— greatly appreciated!

**David bear**: Me too. Glad to do it.

### CONVERSATION ON 05-04-2021

**Jeff Bergosh**: Thanks for the invite to your Party David.  50 is a big one!  I inadvertently RSVP’d for one, but it should be two as of course Sally will be coming along as well.  See you on the 15th!

**David bear**: Awesome!  Thanks

### CONVERSATION ON 05-12-2021

**David bear**: Don’t forget about Underhill calling 911 about 90 times to complain about his neighbors and daughter.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: That’s right!

### CONVERSATION ON 05-16-2021

**David bear**: Thanks for coming last night. 

**Jeff Bergosh**: Wouldn’t have missed it— thanks for the invite it was a great party!  Happy 50th!

**David bear**: Thanks

### CONVERSATION ON 05-18-2021

**Jeff Bergosh**: I got that issue handled it’ll be there Thursday

**David bear**: Thank you. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-20-2021

**David bear**: Thanka for doing that. I can’t believe Sharon tried to pull that shit. For the clerk to want transparency so much, they sure are fighting it.

**Jeff Bergosh**: No problem at all. Now we will know, full transparency 😎👍

**David bear**: Yep. By the way, WTF were Janice and Jana thinking by writing a policy without getting legal review? Alison said they never brought it to her for legal review. They obviously thought they could pull the wool over the commissioners’ eyes and get something accomplished that wasn’t being addressed. 

**Jeff Bergosh**: I have no idea.  That’s why it got scrutinized the way it did.  

### CONVERSATION ON 05-28-2021

**David bear**: Your county attorney’s office needs to respond to Underhill’s writ of Mandamus with my attorney’s memo (or their version of it). The judge will deny him with that document.  Don’t let Alison blow this.

**Jeff Bergosh**: Thx for the heads up

**David bear**: I just talked to Alison. She said they’ve had it pretty much prepared and just waiting to see if they were going to be required to file. She was going to call her staff to give her a copy of it before they filed it so she can give it a final review. She says she told them to incorporate a lot of what Rick Figlio wrote because it is very helpful.

**David bear**: Can I call you in about 15 minutes?

**Jeff Bergosh**: Yes please

**David bear**: Don’t say anything about Robert Bender. His father in law is sitting at the table next to you. 

**Jeff Bergosh**: Thx for that

**Jeff Bergosh**: Wouldn’t have known that!

**David bear**: 👍

### CONVERSATION ON 06-02-2021

**Jeff Bergosh**: There it is

### CONVERSATION ON 06-09-2021

**David bear**: I saw it. I would expect nothing less from that uninformed hack. 

**David bear**: He gets his information from Doug Underhill and we all know how reliable that is. 

**Jeff Bergosh**: Yeah a real piece of work

**David bear**: If you ignore him, he will have failed.  He’s looking to elicit a reaction.

### CONVERSATION ON 06-17-2021

**David bear**: Good morning 

**Jeff Bergosh**: Morning

**David bear**: Gun blazing!!!

**David bear**: Not literally, figuratively of course…sorry. 😳

**Jeff Bergosh**: Yes

**David bear**: Regarding the 401(a): My attorney said they haven’t researched in detail but don’t think the clerk can refuse to spend money in the manner and amount the board appropriates.  
Remind her it’s your office that sets rates and approves budgets and she has a separate constitutional office. 

**Jeff Bergosh**: Already planning that discussion

**David bear**: Emphasized “Already planning that discussion”

**David bear**: I’m not sure the county should be following Underhill’s moral compass. 

**David bear**: Good work. Thanks

**David bear**: This is the same thing she did to the TDC. She overstepped her authority. 

**Jeff Bergosh**: Thx

**David bear**: Ask Doug how his ethics complaint is going

**David bear**: Pam’s comment to the PNJ that she didn’t put much time into this issue because there were so few participants shows how she selectively does her job. It’s not only a hot topic, it’s potentially a very expensive issue she should have addressed when she got elected rather than ignoring it. 

**Jeff Bergosh**: Yes

**David bear**: Ask the bailiff to silence these assholes in the back. 

**David bear**: There is an error in it

**David bear**: On item CAR II-9, the document 6-8-21 TDT Financial Support has a mistake by the Clerk’s office on page numbered page 16.  She showed you guys making a budget amendment of $450k ($100k in March and $350 in April) for the bay center.  I addressed it at TDC and pointed it out to them.  It is still incorrect in your packet and needs to be corrected before approval.
That may be why it was pulled.

**David bear**: The money already went to them and needs to be reimbursed. 

**David bear**: By ARPA

**David bear**: That’s not true. Watch the TDC meeting

**David bear**: I’ll cue it up for you

**Jeff Bergosh**: Thx

**David bear**: Thank you for saying it. 

**Jeff Bergosh**: 👍

**David bear**: The law is clear. If there is a public record, it must be turned over upon request. The law doesn’t require one to be created. 

**David bear**: This is perfect timing to tell Doug there doesn’t exist a public record of who verbally requested the IP address and one doesn’t have to be created. 

**David bear**: Boom!!

**David bear**: That was awesome!!

**David bear**: If Mel speaking can get Doug to leave the dais, you ought to call her up for every topic. 

**Jeff Bergosh**: Thx

**Jeff Bergosh**: LOL

**David bear**: Is her communication with your insurance company tortious interference?

**Jeff Bergosh**: Good question, I’ll ask?

**David bear**: 👍

**David bear**: FYI - Doug is a douchebag. 

**Jeff Bergosh**: Oh yeah he is

**David bear**: Loved “Oh yeah he is”

**David bear**: There seems to be an unsafe and hostile working environment under the management of the administrator. 

**David bear**: You need to address her creating a hostile work environment 

**David bear**: Does he have a job?

**Jeff Bergosh**: Babysitter

**David bear**: And this is Q

**David bear**: Bad policies that existed prior to her employment, like having multiple personnel files per employee, were never corrected. 

### CONVERSATION ON 06-20-2021

**David bear**: Happy Father’s Day. I hope you have a great day today and get a chance to connect with your kids. 

The comments got off subject on your blog’s post about the clerk’s office saying the 401(a) contributions were illegal. My opinion of her initial soft-pedaling is because the clerk is personally liable for making illegal and unauthorized expenditures. If she willingly or knowingly made them, it’s a misdemeanor of the 2nd degree.

**David bear**: http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&Search_String=&URL=0100-0199/0129/Sections/0129.09.html

**David bear**: I think she would like it to go quietly and probably didn’t expect Alison to give a different opinion. I think Pam has kicked another hornets nest and there’s no good outcome for her. If she is right and the payments were illegal, she’s personally liable and possibly faces criminal charges. If she’s wrong, she faces the backlash for picking a fight against the county for no reason other than trying to exert her dominance and interfere with County business. She wanted to undermine the BOCC and county attorney’s authority for political gain. 

**Jeff Bergosh**: My thoughts exactly

**Jeff Bergosh**: And when in our chambers make sure to watch your back to make sure people aren’t taking pictures of your shit!😫😫

**David bear**: Seriously. Those dudes are terrorists. 

### CONVERSATION ON 06-26-2021

**David bear**: I see where Peacock wrote a letter demanding a redistricting committee.  Give him what he asks for and appoint Mel to chair it. 

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Did you see the bullshit editorial today?

**David bear**: You wouldn’t be giving him power.  You’d be doing just the opposite.  You’d show him how his attempt at influence and leverage means so little to you guys that you’d appoint someone who got his fucking number. 

**Jeff Bergosh**: Yeah but the problem is I saw the list of people he wants on the committee no chance I’m giving Jerry Maygarden any play whatsoever on anything I don’t trust that guy —he’s a has been and he fucked up with the way Matt Selover got treated that was all on Maygarden

**Jeff Bergosh**: I prefer to be in charge of that process just like we were in 2011

**David bear**: Yes.  Fuck the PNJ.  They are no different than QAnon adherents.  They are so disconnected from reality and misinformed by propaganda, they spew hot, wet garbage with the confidence of a lion.  It’s really sickening.

**Jeff Bergosh**: That way we can set the boundaries

**Jeff Bergosh**: Yes it is sickening

**David bear**: You create the board, not him.  Those were just supporters of his letter.

**David bear**: Fuck Maygarden, et al.

**David bear**: I can promise you two things.  If you create this committee and appoint Mel as the chair, 1. it will be done right, and 2. You will piss on their corn flakes

**David bear**: I know you’re going to make a blog post about the PNJ editorial. You should consider saying that they are no different than QAnon adherents. That will get Marlette’s attention.

**Jeff Bergosh**: I’ll definitely say that!

**David bear**: Make the analogy

**Jeff Bergosh**: 👍

**David bear**: You could use all of the recent cartoons and articles to thread the needle of how misinformed and maligned they are.  Believing everything they read on the internet and detached from reality

### CONVERSATION ON 07-07-2021

**David bear**: I’m in a Foo Foo meeting now. Can I call you back in about 30 minutes?

**Jeff Bergosh**: Absolutely

**David bear**: FL Statute ch. 125.0104(5)6. To acquire, construct, extend, enlarge, remodel, repair, improve, maintain, operate, or finance public facilities within the boundaries of the county or subcounty special taxing district in which the tax is levied, if the public facilities are needed to increase tourist-related business activities in the county or subcounty special district and are recommended by the county tourist development council created pursuant to paragraph (4)(e). Tax revenues may be used for any related land acquisition, land improvement, design and engineering costs, and all other professional and related costs required to bring the public facilities into service. As used in this subparagraph, the term “public facilities” means major capital improvements that have a life expectancy of 5 or more years, including, but not limited to, transportation, sanitary sewer, solid waste, drainage, potable water, and pedestrian facilities. Tax revenues may be used for these purposes only if the following conditions are satisfied:
a. In the county fiscal year immediately preceding the fiscal year in which the tax revenues were initially used for such purposes, at least $10 million in tourist development tax revenue was received;
b. The county governing board approves the use for the proposed public facilities by a vote of at least two-thirds of its membership;
c. No more than 70 percent of the cost of the proposed public facilities will be paid for with tourist development tax revenues, and sources of funding for the remaining cost are identified and confirmed by the county governing board;
d. At least 40 percent of all tourist development tax revenues collected in the county are spent to promote and advertise tourism as provided by this subsection; and
e. An independent professional analysis, performed at the expense of the county tourist development council, demonstrates the positive impact of the infrastructure project on tourist-related businesses in the county.

**Jeff Bergosh**: Thanks that’s pretty succinct

**David bear**: I’m on a conference cal but need to chat with you about impact fees before tomorrow’s meeting.  Do you have time this afternoon or evening to talk briefly?

**David bear**: Liked “Thanks that’s pretty succinct”

**Jeff Bergosh**: Sure David I can call you on my way home at 4:30 if that works

**Jeff Bergosh**: David— forgot About my weekly call with Alison and Admin at 4:30– I’ll call u after

**David bear**: Sounds great. Thanks 

### CONVERSATION ON 07-08-2021

**David bear**: I don’t see your mobility fees issue on the agenda.  Am I missing it?

**Jeff Bergosh**: Next week COW

**David bear**: oh, gotcha

**David bear**: Mike Davis is her son in law

**Jeff Bergosh**: Good to know thank you

**David bear**: I thought the county had an anti-nepotism policy.  Does the Clerk not have to follow the same rules?

**Jeff Bergosh**: Good question!!

**David bear**: I think maybe his brother is married to Pam’s daughter.  I was told he was married to her but I just looked it up on FB and it may be his brother.  Don’t know how far the policy extends.  Stacy Taylor couldn’t serve on FLWest because his wife is sisters with Bender’s wife.

**Jeff Bergosh**: Interesting

**David bear**: Upon further research, he is married to her daughter, Christa.

**Jeff Bergosh**: Good to know

**Jeff Bergosh**: Thanks for the intel

**David bear**: Yes sir. 

**David bear**: I sent to Alison but haven’t heard back yet. 

Hey Alison. Does the Clerk’s office follow the same set of policies as the county?

**David bear**: Video went out for me

**David bear**: I got it back’

### CONVERSATION ON 07-15-2021

**David bear**: Any chance you’ll pull the concurrency discussion this morning?

**Jeff Bergosh**: No I don’t intend to— again just seeing if the concept can be explored.  And if it is viewed favorably it would be phased in and would require a study first.  Nothing that would happen quickly.  I’ve also met with HBA President and they’ll have a voice in anything that eventually gets crafted

**David bear**: Understood.  Thanks.

**David bear**: You good?

**Jeff Bergosh**: Yes — why?  Is something going on I don’t know about yet ?

**David bear**: hahahaha.  No.  I was just checking in

**Jeff Bergosh**: Right on LOL.... you had me worried for a minute there 😂👍

**Jeff Bergosh**: I predict this meeting will be short today one hour or less two items only

**David bear**: Nah man.  I’ll tell you if something’s up.

**David bear**: We’ve got a special meeting of the TDC today too.  Discussion is also 2 topics: the budget and creating a restricted reserve fund.  I think I’m going to appoint a committee to come back with a recommendation for the reserve fund so we don’t waste time hashing out an issue during  policy meeting

**Jeff Bergosh**: I like that plan.  Very prudent

### CONVERSATION ON 07-21-2021

**David bear**: Is this prepared food or packaged? They’re either duplicating Manna or Loaves and Fishes. 

**David bear**: Let’s see if Doug grandstands…

**Jeff Bergosh**: He made a good decision

**David bear**: Yep

**David bear**: Even a broken clock is right twice a day. 

**Jeff Bergosh**: 😂👌

**David bear**: Lean over and tell him I said hello. 😎

**Jeff Bergosh**: LOL

**David bear**: They don’t want marketing dollars, they want dollars to cover payroll. 

**Jeff Bergosh**: Right

**David bear**: Are they open to citizens or only military?

**David bear**: Ask if the new requested funds are to be used to market toward tourists or locals?  Does this new program attract tourists? (the answer is no).

**David bear**: Before you say it’s a tourism related item, ask how they plan to measure the impact on tourism.

**David bear**: Why is PEDC/FLWest not on this page?

**David bear**: The TDT received the full cost allocation plan on 7/7/21.

**David bear**: TDC not TDT

### CONVERSATION ON 07-22-2021

**David bear**: Escambia hate watch!!  Hahaha

**Jeff Bergosh**: LoL

### CONVERSATION ON 07-23-2021

**Jeff Bergosh**: Careful their heads might explode up there!!

**David bear**: Laughed at “Careful their heads might explode up there!!”

**David bear**: Did you see Marlette’s garbage this morning about Gaetz?  He tried to slam my family again.

**Jeff Bergosh**: I did.  I saw that.  He also——get this——mentioned Quint Studer!!!

**Jeff Bergosh**: I’m sure Lisa is going to ream his ass for that one!!

**David bear**: Right but qualified it by saying some donors are already regretting it

**Jeff Bergosh**: But still.... Studer’s agreement with PNJ is that he shall never be mentioned in any negative context ever no matter what. Even if he’s caught fucking a horse

**Jeff Bergosh**: Never!!!!!!!

**David bear**: Well, I guess he got caught fucking a horse and they reneged that agreement

**Jeff Bergosh**: 😂😂😂😂

**Jeff Bergosh**: I feel very sorry for them actually

**David bear**: Maybe he’s interviewing Amber since she’s now unemployed

**Jeff Bergosh**: Maybe

**Jeff Bergosh**: More money better retirement less pressure and personalities to coddle

**David bear**: Y’all should tell Wes to let her go and just pay out her notice

**Jeff Bergosh**: I need her for some calculations over the next couple weeks though for the fire service otherwise I would do that

**Jeff Bergosh**: 
It’s a quick switch out job

**David bear**: I’m sure.  I’m going to look into it, but I think we should send the TDT back to the DOR to collect for the 3% fee rather than the clerk’s office and let Pam figure out who needs to let go without the funds to pay for their jobs.

**Jeff Bergosh**: She would probably say “that’s illegal” With no proof to back it up

**Jeff Bergosh**: *pay for it if I’ve allowed

**David bear**: haha

### CONVERSATION ON 07-26-2021

**David bear**: Under the FL statute regulating the TDT, the tax is to be remitted to the FL DOR for administration unless the county passes an ordinance to administer it locally.  Escambia County passed an ordinance to administer it locally and empowered the clerk to set rules and be an enforcer.  I’d like to repeal that ordinance and have it administered by the FL DOR.  It will cost the county no more than the Clerk is already charging and we will get the money in the same amount of time.  I’ve asked Alison to look into what all needs to happen to repeal the ordinance and have the FL DOR administer the program.  The action will result in the Clerk being removed from the process and receiving nearly $500k less in her budget next year. 

**David bear**: Can you support that?

**Jeff Bergosh**: In theory yes—The only thing is she will just make up that half 1 million out of our general fund by increasing her budget

**Jeff Bergosh**: On a regular basis

**David bear**: You’re not required to fund her completely. Negotiate just like everyone else. She likes to ask for more than she needs and take credit for saving/sending unspent back. If she asks for more and doesn’t send it back, she doesn’t get to brag and you guys get to point out her inefficiency. 

**David bear**: Emphasized “But I’m willing to look at it given her proclivity for jumping into our lane”

**Jeff Bergosh**: It would definitely send her a message.  A zinger 

**David bear**: That’s what I want to do. Tell her we don’t need to put up with her shit. She lies and that’s not ok. 

**David bear**: She’s a fucking bully

**Jeff Bergosh**: How does this action come to pass— through the TDT?

**Jeff Bergosh**: Or us first

**David bear**: Did you see where Gary Sammons referred to her as Lonnie on one of Mel’s posts? He was referring to Loni Anderson. 😂

**David bear**: That’s what I’m asking Alison to tell me

**Jeff Bergosh**: I was wondering what that meant for a minute there I thought it was Lonnie Wesley

**Jeff Bergosh**: *hymen’s

**David bear**: Laughed at “*hymen’s”

**Jeff Bergosh**: ——autocorrect

**David bear**: Queen of Conflation

**Jeff Bergosh**: Jaqueline “hymen” Rogers

### CONVERSATION ON 07-27-2021

**Jeff Bergosh**: LOL. “September 10th”.  That’s cool his jets and shut him down real quick!

**David bear**: I’m sure he’ll reply about my “daddy’s” influence and how he’s a victim. 

**Jeff Bergosh**: Oh yeah sure.... that’s all he’s got

**David bear**: Or how I was born with a silver spoon and has never done anything for myself. 

**Jeff Bergosh**: He is such a prick 

**Jeff Bergosh**: Calling for Stephan to be investigated criminally what a fucking lunatic

**David bear**: Tall Poppy Syndrome

**Jeff Bergosh**: LOL

**David bear**: It’s how he gets those assholes to ignore his indiscretions. Simple misdirection. 

**Jeff Bergosh**: It’s interesting to watch them get so worked up —the same bunch of about 10 of them on Escambia hate watch . They must think they’re leading some kind of revolution or something. Actually they’re just walking by themselves.....alone..... like the losers they all are

**Jeff Bergosh**: Losers

**David bear**: Yep and people like Doug and Pam are empowered by it to act the way they do.

**David bear**: Emphasized “Losers”

**Jeff Bergosh**: Dysfunctional, unsuccessful, and sad

**Jeff Bergosh**: Yes they are

**Jeff Bergosh**: KaBoom!!!💥💥💥💥💥💥

**Jeff Bergosh**: Maybe you’ll get a two-fer——and both shit heads Dildo Doug and Joel  Cotton with both finally shut the fuck up?

**David bear**: Of course they won’t. They can’t.

**David bear**: I may drop this if they respond.

**Jeff Bergosh**: Don’t these fuckers ever work?? Or do they sit in a dark room and play on computers all day long?

**Jeff Bergosh**: What’s that check for?

**David bear**: Sanctions

**Jeff Bergosh**: Cool!  Right on!

**David bear**: fees and cost for the all day hearing for the motion to compel the public records

**David bear**: We negotiated a settlement amount just to get them to write a check.  I requested the check from Underhill directly to me but obviously they didn’t want to do that.

**Jeff Bergosh**: That’s awesome!!

**Jeff Bergosh**: Can’t stand either of those guys Joe lcotton just a piece of shit

### CONVERSATION ON 07-30-2021

**David bear**: https://www.pnj.com/story/opinion/columnists/2021/07/30/andy-marlette-column-could-escambia-county-florida-commissioners-end-up-wheel-fugitives/5415964001/

**Jeff Bergosh**: What a shitbird that guy is

**David bear**: Y’all need to keep the pressure on Alison to remember that Pam and Doug are doing this to her.

**Jeff Bergosh**: What I find troubling is this paper consistently engages in actual malice by putting me in a false light. How do they do that? Well I don’t take this plan I never have and yet there’s my fucking picture. Doug doesn’t take the plan yet they don’t put his fucking picture in the paper. Actual malice false light Sullivan versus New York Times needs to be over turned

**Jeff Bergosh**: And everyone knows it

**David bear**: Yeah, All Robert did was check a box on his HR paperwork and now he’s a fucking criminal.

**David bear**: This is about consolidation

**David bear**: The people behind the consolidation effort are ruthless and will do everything they can to get what they want and they don’t care who they hurt to get it.

**Jeff Bergosh**: Interesting you mention that.  I had a meeting with John Peacock yesterday and that’s what he wanted to discuss

**David bear**: Yep

**Jeff Bergosh**: I told him No way I’d support a strong, elected county executive.  At large districts yes, elected county mayor— no way

**David bear**: Why do you think he’s gone on the offense on FB against you guys?

**Jeff Bergosh**: Yeah I called him out on that too

**Jeff Bergosh**: About my fatherless families comment

**David bear**: When he follows up with you, ask him why it was so important to have the best appointed school super and how the county is different…

**Jeff Bergosh**: I saw his bs spin on that on ECW 

**Jeff Bergosh**: He had some gibberish differentiation that made no sense

**David bear**: Because his handlers need 3 votes on the BOCC and can’t get it so we need to change the BOCC

**Jeff Bergosh**: I think primarily they’re disappointed in Grover and the new city Council not getting their shit done

**Jeff Bergosh**: That’s probably part of it or all of it

**David bear**: It’s all of that.  John has had sour grapes since Grover beat his friend Brian and they can’t get three votes on BOCC so blow them both up and consolidate

**Jeff Bergosh**: Good to know their angle

**David bear**: When you see it, you can guard against it. 

**Jeff Bergosh**: Yes

**David bear**: Or at least be prepared and better understand their attacks

**Jeff Bergosh**: I think the idea may come as a discussion item———if Bender brings it

**Jeff Bergosh**: That’s where it will die

**David bear**: I hope he doesn’t bring it

**Jeff Bergosh**: I think that’s where Peacock is going next

**David bear**: This is the art of war.  You all need to take the fight to them by taking out their soldiers and leave the generals exposed.

**Jeff Bergosh**: Who wants this? Studer?

**Jeff Bergosh**: What changed there?

**David bear**: I think Studer still has Grover but not the council.  Don’t forget, they had Underhill find candidates to run against all three of you, including his secretary and Lumon’s brother.  When that failed, they engaged John to get involved in the County business on social media.  Peacock has never been involved in BOCC business, why did he all of a sudden start doing it now??? That’s why I smashed Peacock on FB when he started shit on ECW about OLF8 and Bluffs.  he doesn’t know what they fuck he’s talking about.  The have been told to devalue the BOCC by ruining their reputation and credibility so they’re so weak that the public will demand a change. They’re leveraging ECW and the PNJ to publicly shame you guys.  Once enough people think all the problems are the fault of the BOCC and not Janice’s incompetence and mal-intent, Doug’s corruption, and Pam’s interference and lies, they will demand change.  There is no doubt what is happening here and what needs to happen to make it stop.

**Jeff Bergosh**: Thanks

**Jeff Bergosh**: My personal opinion I have no problem discussing it and I told John that but I also told him I will never support a strong executive elected county wide I think that would be a fucking disaster but we could have the conversation and it will die right there like a ship sinking after a torpedo hit it

**David bear**: Alison has been part of the problem but is now a target because she’s so good at bureaucracy that they can’t get her to help them. I’m not suggesting they’ve talked to her, they are just trying to manipulate her.

**Jeff Bergosh**: I have a call into her right now.  I think it’s time for us to release our opinion and tell our side of the story on this fucking 401 a

**Jeff Bergosh**: For reasons I don’t understand she wants the record embargoed in case of litigation which is stupid and makes no sense to me

**David bear**: If the topic is brought up, it doesn’t need to just die.  It’s needs to take casualties with it.

**Jeff Bergosh**: Whether we go to trial or not this information stands on its own merits it is what it is and it puts us in frames us in a very very positive light

**Jeff Bergosh**: I think that’s possible

**David bear**: The captain of that ship needs to go down with the ship.

**Jeff Bergosh**: That would be great.  

**Jeff Bergosh**: Phony baloney

**David bear**: I think Alison’s right about the 401(a) and I want you guys to have your retirement benefits you’re entitled to have (I know you’re not in 401(a)). But, it would be nice if Pam is right so she is personally liable for paying it all back and possibly guilty of a 2nd degree Misdemeanor.

**Jeff Bergosh**: And people lap up his bullshit like sheep

**Jeff Bergosh**: It’s a fucked up strategy that’s not working

**David bear**: Did Mel send you the article about Studer group BS?

**Jeff Bergosh**: No

**Jeff Bergosh**: What was it

**David bear**: It’s long but good.  You can read the first couple of pages to understand the direction and then the last couple of pages to see what they think about Studer.

**David bear**: Give me a sec to find it

**Jeff Bergosh**: Okay thx

**David bear**: https://docs.google.com/document/d/16eBjlJIv6JJ0PbDtn34uO2AnPJXBjnPNItUI2mSKyZg/edit?fbclid=IwAR12kLkFzlS7yyRSyGxYKyi0FS1FDhnMCFLMHdL4DBwLZJqJ4kk--tUrNFg

**David bear**: I think it’s a chapter from a book

**Jeff Bergosh**: I’ll check it out

**David bear**: At least that’s how it reads to me

**Jeff Bergosh**: Wow!  Not a very flattering review of  “rounding and scripting”

**David bear**: I know, right!!!

**Jeff Bergosh**: Some very sharp jabs at Studer too!

**Jeff Bergosh**: Amazing he has allowed this to even exist on the Internet amazing it has not been scrubbed yet or that the author has not been sued

**David bear**: They basically call him a veneer and snake oil salesman.  

**Jeff Bergosh**: “This cannot stand!” I could envision him screaming

**Jeff Bergosh**: I wanna know more though who is the author and what year did this come out and was it published and where

**David bear**: Yep

**Jeff Bergosh**: Maybe he killed it already and this is just the remnant DNA

**Jeff Bergosh**: Kind of like that lawsuit in Indiana that never got reported that he had to settle for what he purported to be proprietary software

**David bear**: Trying to find that out. 

**Jeff Bergosh**: That was actually lifted from another company

**Jeff Bergosh**: In front of the bodacious sandwich shop

**David bear**: Is that wrong?

**David bear**: 😂

**Jeff Bergosh**: Ask Lisa smellesin Savage and dandy Marlette

**Jeff Bergosh**: Those two would’ve been first in line to drink the Kool-Aid in Jonestown

**David bear**: If you do it, it’s wrong. If he does it, it doesn’t exist. 

**Jeff Bergosh**: In fact I’m probably now on a watchlist for even reading what you sent me lol

**David bear**: Laughed at “Those two would’ve been first in line to drink the Kool-Aid in Jonestown”

**Jeff Bergosh**: 🤪

**Jeff Bergosh**: Emphasized “If you do it, it’s wrong. If he does it, it doesn’t exist. ”

**Jeff Bergosh**: Yes— that’s the PNJ!!!!

**Jeff Bergosh**: Doesn’t appear in Google Scholar search—-so perhaps This is nothing more than someone’s quasi- scientific rant in draft form I mean it’s not even signed by the author

**David bear**: Mel thinks it’s been scrubbed from the internet but exists in a book somewhere.

**David bear**: I wouldn’t share this studer thing or post about it.  If you think he’s attacking you now, think about how he will act when it gets personal.

**Jeff Bergosh**: I’m not going to.  

**Jeff Bergosh**: And I’m getting more and more motivated for 2024 it’s gonna be a fucking bloodbath

**David bear**: https://www.washingtonpost.com/health/2021/07/30/provincetown-covid-outbreak-vaccinated/

**David bear**: Do you have Scott Lunsford’s cell?  I can’t find his contact info.  I have Hope’s but not his.

**David bear**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: What is #44?

**David bear**: The number of exceptions DEO denied in their ruling

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Right

**David bear**: JAR knows what it means

**Jeff Bergosh**: Yeah she got her ass kicked

**David bear**: I can’t find the post she made.  Is it still up and she blocked me from it or did she delete it?

**David bear**: I even went into my activity log and it shows I made the comment but it doesn’t link me to it.

**Jeff Bergosh**: It was up there earlier this morning and less she pulled it down I’ll double check when I get to my office. Wouldn’t surprise me if she pulled it she got her ass kicked so bad I love to see it

**David bear**: Me too.  I understand the Westmark’s are going to ask the court for fees and costs

**Jeff Bergosh**: That would be awesome!!

**Jeff Bergosh**: So they probably just blocked you out — don’t want voices of dissent

### CONVERSATION ON 08-11-2021

**David bear**: Enjoy

### CONVERSATION ON 08-12-2021

**David bear**: Did you read it?

**Jeff Bergosh**: Not the whole thing yet, but I’m assuming it’s good for us, bad for Doug





**David bear**: Uhhhhh, yeah.  In his amended complaint, Underhill claims there’s a common law duty of the BOCC to pay his fees.  Figlio says Underhill would have to prove he didn’t defame Miller to be entitled to the fees.  Rather than arguing the merits of the case to defend he didn’t defame, he argued immunity (Miller had the burden to prove DU defamed him).  Now, Underhill would have the burden to prove he didn’t defame and I’m pretty sure he doesn’t want to open that can of worms.

**Jeff Bergosh**: Can or will you share this with Alison/Charlie?  I think it could help them

**David bear**: Figlio is going to share it with her this morning.

**Jeff Bergosh**: That’s outstanding.  Thanks for doing this David!

**David bear**: I don’t want to give her the opportunity to fuck it up, intentional or not

**David bear**: Put it on your blog

**Jeff Bergosh**: Very good point

**Jeff Bergosh**: I’ll do it immediately if that’s cool with you

**David bear**: Yes

**Jeff Bergosh**: 👍

**David bear**: The more people that know he’s not eligible for his fees and why, the better.

**Jeff Bergosh**: Amen to that!!

**Jeff Bergosh**: Thanks💥💥💥💥💥

**David bear**: Thank you.  It’s all part of my campaign to expose his lies and corruption.

**Jeff Bergosh**: 👍👍

**David bear**: It shouldn’t be this hard for a county to legislate.  He’s worse than dragging an anchor.

**Jeff Bergosh**: Ain’t that the truth!!

**David bear**: Sometimes I just have to poke him in the eye and bring him back down to earth.

**Jeff Bergosh**: Bang!! 💥💥

**Jeff Bergosh**: Love it!!

**David bear**: Thank you

### CONVERSATION ON 08-18-2021

**David bear**: You saw this shit, right?

**Jeff Bergosh**: Yeah— What a shit bird

**David bear**: My friend is the chief revenue officer for Gannett and I sent it to him asking how it helps improve the community but I’ve gotten no response. 

**David bear**: Laughed at an image

**Jeff Bergosh**: He makes too much money for them to get cancelled for using the N-Word I guess.... ho hum

**Jeff Bergosh**: They attack me I attack them

**David bear**: That’s exactly what he wants you to do. 

**Jeff Bergosh**: I don’t know David it’s it’s playing with fire because he’s white

**Jeff Bergosh**: All it takes is for the right guy to see that and he’ll get canceled just like Chris Harrison off of the bachelor

**David bear**: Then let’s figure out who that person is and give it directly to him/her. 

**Jeff Bergosh**: I’d love to 

**Jeff Bergosh**: Also Andy threw Lumon into his last rant in Sunday’s paper very unflatteringly

**David bear**: The one about Ed Grey?

**Jeff Bergosh**: Yes

**David bear**: https://ricksblog.biz/underhill-received-most-contributions-from-ed-gray/

**David bear**: Unrelated to all of this. The Naval Aviation Museum has asked for an additional $100k from TDT this year for a new program they’re creating. They presented to the TDC at our budget workshop. They originally asked for $200k and Bender asked if we could separate the two $100k requests on our proposed budget to the BOCC. We did. During their presentation to us, they said the program is directed at local school children and will not bring in tourists. I don’t believe we can find this per the authorized uses in the statute. It does nothing at all, per their own admission, to develop tourism. I’d like y’all to vote against it during budget hearing. 

**Jeff Bergosh**: As much as I would like to support it I agree with you if it’s not a qualified use. I have actually had constituents reach to me and say we should cut them off from funding because they have closed the base to tourists. I don’t know if I can go that far but that is a problem

**Jeff Bergosh**: But I do understand the circumstances with Covid and the terrorist attack. But if it’s not open to tourists why are we funding it with TDT money?

**David bear**: I agree. They still allow visitors with guests who have a DoD credential but this new request has nothing to do with tourists. 

**Jeff Bergosh**: Yes and maybe we can support it with rescue plan money or something else

**David bear**: Military folks can still visit from out of town. 

**David bear**: Maybe we don’t have to support every program requesting funds. Maybe the school district can support it or find private donors to sponsor it. 

### CONVERSATION ON 08-19-2021

**David bear**: Jana Still’s transcript links aren’t active links.

**Jeff Bergosh**: Thx I’ll fix it

**David bear**: Yes sir

**David bear**: FYI - forcing the Clerk to pay the retirement is the reason for a Writ of Mandamus.  Tell Doug

**David bear**: Don’t avoid it!  File a WRIT OF MANDAMUS!

**Jeff Bergosh**: LOL

**David bear**: Ask him if it was legal, moral, and ethical for him to take action on his legal fees reimbursement against state law.

**David bear**: Keep your focus on Pam.  I’ll take down Doug

**Jeff Bergosh**: She capitulated

**Jeff Bergosh**: We will request an opinion

**David bear**: Of course.  She’s back walking her opinion because she would be personally liable for reimbursement

**David bear**: and guilty of 2nd degree misdemeanor 

**David bear**: No judge said he didn’t break the law on what he said.  They said he was protected and they never argued the merits

**David bear**: reiterate what Steven just said.  Doug could have signed the agreement to opt out, but instead, he chose to play another game to deny his enrollment in the program.

**David bear**: Just ask Alison to take action to prove Pam wrong.  Lumon just publicly said he’s there.  Obviously Doug is too

**David bear**: He's never worried about right or wrong

**David bear**: Tell her everyone’s brother is a judge

**David bear**: Pam’s current position…

**Jeff Bergosh**: LOL

**Jeff Bergosh**: She’s doubling down on a losing point

**David bear**: She’s talking in circles.

**Jeff Bergosh**: Yes

**Jeff Bergosh**: And I’m not impressed with Alison

**David bear**: She’s right.  You don’t want her explaining this in front of Pam and her attorney.  She’s also not a litigator.  That’s what Charlie Peppler did

**Jeff Bergosh**: Saying the request for mandamus requires outside counsel and is some super top secret strategy we need to guard was feckless bullshit

**David bear**: BTW, I got Figlio to ask FRS to give an opinion and they refused.

**David bear**: Maybe, but you’re better off keeping your cards closer to your chest

**Jeff Bergosh**: It’s cut and dried question.  Pay the contract amount

**Jeff Bergosh**: Ministerial

**David bear**: yep

**Jeff Bergosh**: So no need for kabuki theater

**Jeff Bergosh**: ............but no

**David bear**: Who wrote the check?  Pam or Morgan??

**Jeff Bergosh**: Morgan

**David bear**: Too bad.  I would love to see Pam get tied to this issue.

**Jeff Bergosh**: Yeah she’s conveniently distanced herself from that

**David bear**: of course

### CONVERSATION ON 08-25-2021

**David bear**: You may want to check with Alison to see why they haven’t responded to Underhill’s amended complaint filed 26 days ago.  Hopefully, it because they’ve agreed to an extension that wasn’t placed on the docket and it’s not because she missed the deadline (although, I doubt the state court will default you) or she’s trying to negotiate a settlement.  

**Jeff Bergosh**: I will.  Thanks for the heads up.  When is the deadline?

**David bear**: The response was due 20 days after he filed his amended complaint. 

**Jeff Bergosh**: So it’s late already?

**David bear**: I think but I’m verifying. I sent Alison an email about it last night asking if she has requested an extension but she’s kind of quit replying to me after DU tore into her at the BOCC meeting last week about my PRR of his permits and shit at his house. 

**Jeff Bergosh**: I’ve got a call into her rn

**Jeff Bergosh**: If they’ve missed a deadline on this and jeopardized our case it could lead to her dismissal

**David bear**: I’m sure she’s on top of it but it makes me nervous that something could tank this “no-lose” case. 

**Jeff Bergosh**: She has a $200,000 a year job at stake

**David bear**: If she takes this thing, she should go to the guillotine. 

**David bear**: Tanks

**Jeff Bergosh**: Agreed

**Jeff Bergosh**: Was Charlie handling this?  He gave notice

**David bear**: Yes but that doesn’t mean it just goes away. 

**Jeff Bergosh**: Absolutely

**Jeff Bergosh**: Just thinking of possible lame excuses

**David bear**: She probably got an extension due to Charlie’s resignation but she had plenty of time to sign Figlio’s memo and submit. 

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: And if they do not do a carbon copy of Figlio’s masterpiece reply it better be something very damn similar

**David bear**: Figlio just told me response was due 10 days after service of an amended complaint. It’s 20 days from service of the original complaint. 

**David bear**: We good -
Peppler emailed me that the parties agreed the county’s response would be due 10/18

**David bear**: Sorry I stirred it up unnecessarily 

**Jeff Bergosh**: No worries better to be safe than sorry especially with all the shenanigans that are going on these days

**Jeff Bergosh**: I still have two or three other things I can talk to her about when she calls me back

**David bear**: Those shenanigans aren’t new. 

**David bear**: Liked “I still have two or three other things I can talk to her about when she calls me back”

**Jeff Bergosh**: No it’s like a cyclical pattern

**David bear**: Daily

### CONVERSATION ON 09-02-2021

**David bear**: Recommend he be censured!! He’s a fucking liar and he needs to be censured.

**David bear**: He needs to be punished

**David bear**: The video feed went out right when Robert called for the vote.  What happened?  Thanks for taking the action!!!

**David bear**: What happened?  

**David bear**: 4-1.  I heard from Mel.  Thanks for your leadership in doing that.  He’s such an evil person.

**David bear**: https://www.mcsweeneys.net/articles/oh-my-fucking-god-get-the-fucking-vaccine-already-you-fucking-fucks

**Jeff Bergosh**: 4-1

**David bear**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-07-2021

**David bear**: I'm on another call. I'll call you back soon. 

### CONVERSATION ON 09-09-2021

**David bear**: https://www.pnj.com/story/news/local/pensacola/2021/09/09/pensacola-help-fund-chappie-james-statue-and-womens-veteran-monument/5776042001/

**David bear**: So much for those guys paying for this with private funds.

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: Knew this was coming

**David bear**: Yeah, they gave them $250k.  They’ve asked TDC for $300k but we said no to that.  Robert wanted to put $100k in the budget for it and we have it there as a place holder.  That’s what I wanted to talk to you about before the budget hearing the other night but didn’t since you weren’t feeling well.  I want to see them raise private money before we put more public money into this project.  I support using TDT for it but not until after Dosev and Hansen do some private fundraising like they promised.

**Jeff Bergosh**: I agree

**Jeff Bergosh**: BTW— if Underhill has a bad day tomorrow, and if he’s subsequently removed, do you think DeSantis would quickly appoint a successor?  That would knock Jonathan and the office boy Conor our simultaneously— which would be great. 👍

**David bear**: As I understand it, The governor has the authority to suspend him from office but it takes the Senate to actually remove him. While he’s suspended, he cannot act as a commissioner and therefore, his office should be vacated. I don’t believe his aids can be there either.

**Jeff Bergosh**: Okay, great.  That would be almost perfect!

**Jeff Bergosh**: Suspended

**David bear**: Yep, with no idea if he’s been removed until the Senate is back in session. I imagine, if the ethics commission finds probable cause, he is not going to settle. He will die on his sword thinking he is innocent and fight to the bitter end. In the end, it won’t work out well for him if he fights it. It will only get worse, I suspect. If they find probable cause, I would love the County commission to do another censure of him. Additionally, I want another censure as part of a settlement of the lawsuit with the county. We’re still working on that on our end.

**Jeff Bergosh**: I’m ready to go!  Let’s do it!

**David bear**: Emphasized “I’m ready to go!  Let’s do it!”

### CONVERSATION ON 09-10-2021

**David bear**: A broken clock is right twice a day. 

**Jeff Bergosh**: Yep

**David bear**: Btw, he’s not here at the ethics hearing. I guess FB is more important to him than his ethics complaint. 

**Jeff Bergosh**: Wow!! That won’t reflect well I don’t believe

**Jeff Bergosh**: Do you think he submitted written exceptions or a written statement?

**David bear**: Who knows. We’re still in public session and he could be waiting for private session to begin to show up. I doubt it though. 

**David bear**: He has such low regard for the law and this process, he failed to fulfill his obligations to report gifts and abstain from taking action that would inure to his own private gain. Now it looks like he has an even lower regard for this process and quasi-judicial body by not showing up to defend himself against or admit guilt to the complaint. He’s a dirty rotten scoundrel. 

**Jeff Bergosh**: Yes he is.  Can they find him guilty without him being there?

**David bear**: They either do or don’t find probable cause today. Guilt is found by him agreeing to a settlement or not agreeing and going before an administrative judicial hearing. Even if he agrees to a settlement, the ethics commission may reject it.

**Jeff Bergosh**: So by not showing up he delays the process, is that his game?

**David bear**: No delay. Today was only probable cause hearing. If they find pc, the staff offers settlement outside of the meeting and then it goes from there.

**Jeff Bergosh**: I hope it’s publicized what his infraction is.  He has apparently worked with the news journal to do another hit piece on me and Steven ——were Doug is portrayed as the victim.  Why does the downtown patron coddle and protect this piece of shit Underhill?

**Jeff Bergosh**: https://www.pnj.com/story/opinion/2021/09/10/marlette-barry-bergosh-star-censure-musical/5775013001/

**David bear**: I saw it. Pathetic. Andy will wake up on the wrong side of history and there will be shame cast on that paper. Readers know what’s happening. They will spin this outcome though. It’s Richie Rich vs. the humble man…just another attempt to distract from Underhill’s shiny crown and the other four commissioner’s corruption. 

**Jeff Bergosh**: Exactly.  This guy’s pathetic.  So is the Patron.

**David bear**: Liked “Exactly.  This guy’s pathetic.  So is the Patron.”

**Jeff Bergosh**: Any news?

### CONVERSATION ON 09-14-2021

**David bear**: I didn’t realize you guys had a budget workshop this morning to discuss the outside agencies and TDT.  The Naval Aviation Museum’s additional $100k is for a program they told us was only for local students, not tourists.  That doesn’t qualify for TDT.  If they’re there, ask them.  Chappie James request is not for the museum.  It’s Dosev and Hansen asking for their statue.  In 2 years, they have not raised $1 from private sources.  Tell them to raise private money and come back for more public money.

**Jeff Bergosh**: Yes I agree.  It was always supposed to be privately funded

**David bear**: Emphasized “Yes I agree.  It was always supposed to be privately funded”

**David bear**: Exactly

**David bear**: Doug was talking about the need for inmates to have private conversations with their attorneys. I guess he's preparing for his visit. 

**Jeff Bergosh**: LOL yes I was thinking the same thing

**David bear**: Laughed at “LOL yes I was thinking the same thing”

**David bear**: He’s such a douche

**Jeff Bergosh**: Yes he is

**Jeff Bergosh**: Do u think I’ll get it?

**David bear**: Tomorrow at noon is when the information will become available. I had a good weekend.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I had a great weekend

**David bear**: Liked “I had a great weekend”

**David bear**: Studer institute doesn’t need shit. They can cut what they pay Janice if they need money. 

**Jeff Bergosh**: LOL that’s right

**David bear**: Ask Vinnie how many employees they have to provide this service?

**David bear**: I’m fairly certain this program was one of the main reasons Studer wanted to create the children’s trust

**Jeff Bergosh**: I still see a zero in that column

**David bear**: 👍

**David bear**: Fuck him

**David bear**: Tell them you already invest through FloridaWest into the CoLab partnership with PSC. 

**Jeff Bergosh**: That’s a good point

**David bear**: They should charge a small admission for participants. 

**David bear**: Ask him if his drug rehab program is a 12 step program or some other type.

**David bear**: Connie Bookman is DC Reeves’s mother

**David bear**: The TDC placed those on the recommended budget as place holders for your discussion. 

**David bear**: Ask them if their program is for tourists or locals

**David bear**: Visit should spend it, not Navy museum

**David bear**: Robert’s trying to figure out how to fund these programs

**David bear**: They are limiting visitation to DOD credentialed people

**David bear**: The broken clock has been been right twice today.  Don't expect it again.

**Jeff Bergosh**: LOL

**David bear**: Insult Dosev and see if he loses his shit.

**Jeff Bergosh**: LOL

**David bear**: Ask how much private money they’ve raised

**Jeff Bergosh**: I don’t want a stalker

**Jeff Bergosh**: I’ll let Doug carry my water

**David bear**: Laughed at “I don’t want a stalker”

**Jeff Bergosh**: As he’s doing now

**David bear**: Emphasized “I’ll let Doug carry my water”

**David bear**: Be careful letting him do that.

**David bear**: So this project is a moving target

**David bear**: D Tell them raise the money from private groups to show it has community support.  That’s what it means to show community support, not government funds.

**David bear**: They seriously have no fucking idea what they’re doing

**David bear**: Keep pushing him.  He’s about to break

**David bear**: Private funding is the community, not government

**David bear**: Keep pushing!!!!

**David bear**: Come back with $150k

**David bear**: of private funds

**David bear**: NO!

**Jeff Bergosh**: I wanted to have him answer on the record.  If he misrepresented, it will be difficult to support

**David bear**: Emphasized “I wanted to have him answer on the record.  If he misrepresented, it will be difficult to support”

### CONVERSATION ON 09-15-2021

**Jeff Bergosh**: No I’m gonna issue my own press release when the real press release comes out from Tallahassee. I’m going to reply all and I’m gonna say disregard the fake news release from Doug that should’ve been sent to the onion. This one however is legitimate it’s from the ethics commission and they found probable cause that he violated state law.

**David bear**: Lol. Still waiting

**David bear**: http://www.ethics.state.fl.us/Documents/Ethics/PressReleases/Sep21pres.pdf?cp=2021915

**Jeff Bergosh**: Wow!

### CONVERSATION ON 09-20-2021

**David bear**: Quick question: Did Underhill advocate to the commission to accept Fred Hemmer's offer to purchase OLF8?

**Jeff Bergosh**: I don’t specifically remember that he did that :   I do remember that he strongly advocated for Fred Hemmer’s vision of a suburban utopia with shopping centers and malls and bowling alleys and hotels and all that crap that we were never supposed to do with that property……he strongly advocated for that vision

**David bear**: That’s just as good.  Thanks.  I’m making notes regarding the investigation report in case we can communicate with the advocate so she fully understands what was going on during these actions in the allegations.  She needs to know how much he lied to investigators

**Jeff Bergosh**: Right on.  He’s a liar

**Jeff Bergosh**: …….and needs to be held accountable

**David bear**: Didn’t he also try to claim the appraisals were too high and tried to reduce the value?

**Jeff Bergosh**: Yes he did

**Jeff Bergosh**: He was trying to drive down the value

**David bear**: lol

**David bear**: Emphasized “He was trying to drive down the value”

### CONVERSATION ON 09-21-2021

**David bear**: Set Doug up to run his mouth about outside agencies and discretionary funds by talking about them in a positive way. It’ll drive him to say something negative about it. 

**Jeff Bergosh**: I just did

**David bear**: I know. That was great. 

**David bear**: I’m here in the back

**David bear**: He just can’t help himself. 

**David bear**: Keep saying you support using discretionary funds for this program and how it’s an appropriate use. 

**David bear**: There’s $850k in special projects that are unencumbered in the county’s TDT budget. 

**David bear**: There are no identified projects for that money. This is a great source for these funds. 

**David bear**: Fund it from the BOCC “special projects” money and ask VP to do surveying at the event to get the data to evaluate ROI. 

**Jeff Bergosh**: We can look at that too

**David bear**: Tell Doug you have no problem with the discretionary funds. He’s the only one against them. Give them up Doug. 

### CONVERSATION ON 09-24-2021

**Jeff Bergosh**: You might find this mildly amusing for a Friday morning…..

**Jeff Bergosh**: …..of course I’m not going to publish it on my blog though….

**David bear**: lol

**David bear**: I talked to Mary and Dave Hoxeng about Andrew McKay’s interview and told them I was disappointed in how he handles Doug with kid gloves, which is diametrically opposed to his normal style of interviews with everyone else.

**Jeff Bergosh**: That was the weakest interview I’ve ever heard in my life he might as well have just pulled out the kneepads

**Jeff Bergosh**: He lets no one off the hook like that so he must have a major man crush

**David bear**: He does.  That’s what Dave told me. Their radio show personalities are also their own producers of their shows.  Mary and Dave give them as much freedom as the FCC allows them to have.  They are asking Andrew if he will interview me about the ethics stuff.  If he doesn’t, we know his knee pads are worn…

**Jeff Bergosh**: Yeah and if he does he will try to contradict every point you make and play the “I’m smarter than you game”. It’s really condescending and it’s offputting and I think Rick Outzen will probably end up stealing market share from Andrew because he’s smug conceited and condescending

**Jeff Bergosh**: And he’s overly opinionated for someone who’s purported to be a new guy he’s no different than MSNBC or CNN

**David bear**: and Fox…They all suck

**Jeff Bergosh**: I only watch ABC with David Muir

**Jeff Bergosh**: 😂

**David bear**: I like that guy.  He featured The Lewis Bear Company after Hurricane Michael in Panama City.  We gave away about 4500 cases of water.

**Jeff Bergosh**: He’s a likable guy that’s probably why his show is number one in the world

**David bear**: And he’s got great hair

**Jeff Bergosh**: But he’s obviously very biased to the left

**David bear**: lol

**Jeff Bergosh**: Yes he does

**Jeff Bergosh**: And I’m jealous dammit

**David bear**: He probably has an ugly head, unlike us.

**Jeff Bergosh**: That’s right!

**David bear**: got a sec to chat?

**Jeff Bergosh**: Sure

### CONVERSATION ON 09-28-2021

**David bear**: The $350k allocation to the Bay Center from TDT has not been reimbursed with ARPA funds as you guys told them to do. The Clerk has continued to lie about it and said it was reimbursed. There is no transaction to support her lie. 

**Jeff Bergosh**: Okay we will get it sorted out and replaced.  Thanks for bringing it to my attention

**David bear**: Yes sir. I heard you were on fire on WCOA this morning. I can’t wait to listen.

**Jeff Bergosh**: Thanks— yes it was a good interview.  So glad these folks are getting their lives back.  Really sad it happened to them.

**David bear**: Janice, Jana, and Edler need to pay

**Jeff Bergosh**: Absolutely they do!

### CONVERSATION ON 09-30-2021

**David bear**: This needs to get to Fleming. 

### CONVERSATION ON 10-01-2021

**Jeff Bergosh**: I’ll see him at tennis tomorrow— I’ll make sure he gets it— thanks for sharing

**David bear**: This one too. 

**Jeff Bergosh**: 👍

**David bear**: Seriously! How can he afford these two loans but not pay his legal fees in my case?? He’ll certainly be obligated for the fees in Miller’s case after he loses the lawsuit against you guys. I hope Ed understands he’s aboard a sinking ship. 

**David bear**: Btw, if the county agrees to not pay Underhill’s fees and costs (in his individual capacity) in my case, I’ll waive my right to ask the county to pay my fees and costs it could be on the hook for paying. 

**Jeff Bergosh**: That sounds great to me!!

**Jeff Bergosh**: I think we have a shade session scheduled on the 14th to discuss that

**David bear**: You do. 

**David bear**: I hope y’all talk about the redistributing before you talk about my case. I’d like DU all pissed before y’all discuss my case. 

**Jeff Bergosh**: We have that meeting in the 5th

**Jeff Bergosh**: I hope they don’t give into any of Doug’s bullshit at all

**David bear**: Oh, the 5th is the shade meeting to discuss our lawsuit too, not the 14th. The 14th is your board meeting. 

**David bear**: Laughed at “He ain’t going to like my proposal, LOL”

**Jeff Bergosh**: Oh- okay.  Well, we’ll be doing that one right before redistributing

**David bear**: Is the redistributing discussion shade or public?

**Jeff Bergosh**: Autocorrect keeps changing the word redistricting 

**Jeff Bergosh**: Should be a hoot if we stick together and if Robert will keep his fucking trap shut

**David bear**: Laughed at “Should be a hoot if we stick together and if Robert will keep his fucking trap shut”

**David bear**: I haven’t seen your plan but Perdido should go back to D1

**Jeff Bergosh**: That’s what I’m planning

**David bear**: Good. Push hard for it. 

**Jeff Bergosh**: I will

**David bear**: They need your leadership

**Jeff Bergosh**: I just hope that Lumon and Stephan will see the value in what I’m proposing it makes a lot of sense. Meanwhile Doug is going to try to dump a precinct into Lumon’s district that isn’t necessary. I’ve done the math if Stephen and Lumon swap that one precinct south of 9 mile road Lumon’s district balances Roberts District balances in Stephen’s district balances

**Jeff Bergosh**: If we do my plan for District one and two both Doug and I will be balanced at right around 64,500 voters which is the ideal district size he picks up parts of several precincts on the west side south of Highway 98 and I pick up Perdido Key and Innerarity west of Sorrento

**David bear**: Does it keep Lumon’s district majority minority?

**Jeff Bergosh**: Absolutely he would have nearly 30,000 African-American and 26,900 white

**Jeff Bergosh**: If Doug tries to assert his will and give Mayfair to Lumon that would be an additional 4500 voters it would take the balance and the numbers out of whack

**David bear**: Mayfair needs a new commissioner, not necessarily a new district. 

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: Although it is tough to see on this picture this is my proposed new district 1 I pick up perdido key Innerarity and I give away half of precinct 61 all of precinct 99 1/2 of precinct 75

### CONVERSATION ON 10-06-2021

**David bear**: I'm on another call. I'll call you back soon. 

**Jeff Bergosh**: 👍

**David bear**: Hahaha

**Jeff Bergosh**: Laughed at an image

**Jeff Bergosh**: LOL

**David bear**: 😂

**David bear**: Tell Sally, we’re food for $5k but she still needs to fill out our application.

**David bear**: Thanks

**Jeff Bergosh**: Awesome!!!!!   Thank you David!!Right on will do on the  application.  Does she have a copy of it —or where can I find it?

**David bear**: Bearfamilyfoundation.org

**Jeff Bergosh**: Got it.  Thanks!!

**David bear**: Yes sir. There’s a link to download it. It’s not an online form. 

**Jeff Bergosh**: Okay we will get it turned around quick!

**David bear**: Thanks. 

### CONVERSATION ON 10-14-2021

**David bear**: Did you hear about JLAC’s vote in support of doing the TDT audit?

**Jeff Bergosh**: I did!  Congratulations!

**David bear**: Thanks.  During the Clerk’s report, ask Pam if she has been informed.

**Jeff Bergosh**: Empty chair

**David bear**: lol

**David bear**: He doesn’t have wetlands on his property because he pushed them onto his neighbors yard.

**Jeff Bergosh**: Yep

**David bear**: Remember all of that unpermitted work to move dirt around “fixing his driveway.”

**David bear**: Glad he had the foresight not to buy property that floods.  hahahahaha

**Jeff Bergosh**: LOL

**Jeff Bergosh**: How did that work out for him?

**David bear**: I’d say, not so good.

**Jeff Bergosh**: Yeah that looks like a wreck job

**David bear**: Hey, but he’s suing his windstorm insurer because his house was totaled due to windstorm.

**David bear**: https://www.pnj.com/story/news/2021/10/14/ups-st-engineering-program-draw-aviation-mechanics-pensacola/8442995002/

**David bear**: Ask Doug if he saw this.

**Jeff Bergosh**: LOL he’s suing his insurance company for wind when it was blown out with a flood

**David bear**: Emphasized “LOL he’s suing his insurance company for wind when it was blown out with a flood”

### CONVERSATION ON 10-21-2021

**David bear**: Hey, ARPA funds were going to reimburse TDT for the revenue losses from last year.  $3MM

**David bear**: Ask Chris Curb if he’s read the ARPA agreement.

**Jeff Bergosh**: He’s clueless

**David bear**: I hope you’re going to say something about BA#4 opening just to poke DU in the eye.Beer is good

**Jeff Bergosh**: Absolutely

**Jeff Bergosh**: It’s coming

**David bear**: The beer is good was in response to Dianne’s comment

**Jeff Bergosh**: LOL

**David bear**: I don’t support the county paying for the tennis courts

**David bear**: I know you do because you play tennis.  I think improvement of the tennis courts is good, but the city has money to do it

**Jeff Bergosh**: They will lower the rates for county membership and this facility does bring in a lot of county members

**David bear**: The city has $750k allocated for a new park community center that will not be enough to pay to build one.

**David bear**: That’s the one with the $750k

**David bear**: The County needs to show the evidence through an economic impact study to prove this is a tourist development to justify.

**Jeff Bergosh**: I know, it’s something that could be done any time going forward 

**David bear**: If Bender thinks this is a good expense of TDT, he should support it coming out of repainting the beach ball water tower.  It doesn’t even look bad so I’m not sure why he wants to repaint it.

**Jeff Bergosh**: That’s a good point.  It looks fine!

**David bear**: The City has $750k for Tippen Park Community Center that will not be enough to do the project.  That money will sit parked for years.  They also have $150k for Baars Park to create a kayak launch that no one in the neighborhood wants.  The Neighborhood Association doesn’t support it.  It may actually be impossible to do because of seagrasses blocking the access to build it.

**David bear**: I understand the design for Roger Scott doesn’t help tourism and Grover has been told that.

**David bear**: hahahaha

**David bear**: "They lie because they're liars and they lie."

**Jeff Bergosh**: LOL

### CONVERSATION ON 10-23-2021

**Jeff Bergosh**: Very nice editorial coming from PNJ tomorrow honoring your family’s generosity.  Glad Marlette and Savage are recognizing that.  I’m sure it’s tough for Andy to do, as he’s such a spiteful tool LOL

**David bear**: It is very nice.  Thank you.  Of course, it would seem they only did it to have an opportunity to bring up Studer’s generosity. 

**Jeff Bergosh**: I saw that

**David bear**: 🤷‍♂️

**Jeff Bergosh**: Before I even read it I knew they were also going to draw the parallel to him

**David bear**: I’ll take a victory lap anyway

**Jeff Bergosh**: And of course they did

**Jeff Bergosh**: As you should!

**David bear**: Thank you

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Have a great weekend

**David bear**: Thanks.  Please tell Ed when you see him, I said I hope he’s getting paid since Underhill just keeps spending money like he prints it…

**Jeff Bergosh**: LOL I will!  I’m not playing tennis with him today because it’s our homeowners association annual meeting but I’ll see him next Saturday and you know I will bring that up to him

**Jeff Bergosh**: My standard lying to him is Doug should be paying him first!

**David bear**: 😂

**Jeff Bergosh**: *saying

**Jeff Bergosh**: Yeah it’s not real happy with that whole situation I can tell

**David bear**: Salt in the wound

**David bear**: He’s an asshole for taking on the case.  

**Jeff Bergosh**: Well that’s what they do though isn’t it? I think he’s got an asshole for a client! I’m not just Doug I think he also represents some guy downtown who flips big apartments for huge profits and always seems to make it like a bandit on the backend

**David bear**: That was Ed’s text to Alison

**Jeff Bergosh**: That’s why I always tell people theres only one lawyer I like and trust

**Jeff Bergosh**: Wow

**Jeff Bergosh**: LOL

**David bear**: Nope.  That was voluntarily given to me

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Insightful

**David bear**: Alison told me that Ed reached out to her because he wanted to represent Doug.

**Jeff Bergosh**: I think that backfired on him pretty spectacularly at least if he wants to get paid that is

**David bear**: So, Ed gets what he asked for.

**Jeff Bergosh**: Yeah you got to be careful what you wish for you might get it right?

**Jeff Bergosh**: LOL

**David bear**: Liked “Yeah you got to be careful what you wish for you might get it right?”

**Jeff Bergosh**: Can you please pay my invoice is please?

**Jeff Bergosh**: Pretty please?

**David bear**: 😎

**Jeff Bergosh**: 😂

**Jeff Bergosh**: I’m not paying his check

**David bear**: Hey, let’s incur more fees and sue the county and lose.  I hope the county has the ability to get fees when you beat him in that suit.

**Jeff Bergosh**: And I don’t think any of the board will

**Jeff Bergosh**: We might I’d be all for it after I beat the shit out of him on the redistricting

**David bear**: 😂

**Jeff Bergosh**: It’s going to be an exercise of raw power

**Jeff Bergosh**: Him Jonathan and the intern

**David bear**: To make it happen, just remember, you'll need to be willing to give up something you’d rather not.

**Jeff Bergosh**: I know that

**Jeff Bergosh**: *doug will hate

**David bear**: Is that Paul’s map on your blog?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: But if Paul’s map happens I could live with it

**David bear**: Got it.  I’ll read your post.  I haven’t read it yet

**David bear**: Liked “But if Paul’s map happens I could live with it”

**Jeff Bergosh**: One thing to note Paul’s map takes chance Walsh and Kevin Brown out of the equation so that’s why I have to try to get my compromise adopted

**Jeff Bergosh**: I don’t wanna throw the race into turmoil

**David bear**: Good. I don’t want to see it all blow up and Doug somehow get something he wants.

**Jeff Bergosh**: But Paul is not political. His map and the way he articulated it was completely a political which I find to be refreshing

**Jeff Bergosh**: Robert won’t go for my map and of course Doug won’t either

**David bear**: I think redistricting should take into consideration elected officials, but not candidates.

**David bear**: I would prefer to see D4 come across downtown and take D2 out of it, but that would draw Lois out of her district.  D2 shouldn’t be there, it’s stupid.

**Jeff Bergosh**: I agree

**Jeff Bergosh**: At this point that’s the only rationale to keep it that far east

**David bear**: Put her in jail for fraud and perjury and problem solved

**Jeff Bergosh**: So our proposal the compromise keeps chance Walsh and Kevin Brown in the D2 race it also adds Jonathan Owens into D2. But it does take Steve Stroberger out of the two which I don’t believe will impact the race at all he had no chance to win

**Jeff Bergosh**: Maybe someone will make the move and take her out of the district? I don’t know funny things happen right?

**David bear**: Let’s hope.  I like Paul’s map

**Jeff Bergosh**: Me too!

**David bear**: Which of those assholes on ECW will post that editorial and defame us first?

**Jeff Bergosh**: LOL 

**Jeff Bergosh**: Hymen Rogers will

**David bear**: Liked “Me too!”

**David bear**: She blocks me.  She knows she can’t kick me off her board so she just blocked me personally so I don’t see her comments and posts.

**Jeff Bergosh**: She’s a piece of shit

**David bear**: yup

**David bear**: I took a good jab at her after she lost that hearing.  All I did was write the number 45 in a comment.  It was the number of findings against her in the order and she blocked me.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: She has surprisingly thin skin

**David bear**: I have 675 pages of private messages between her and Doug

**Jeff Bergosh**: Imagine having all this time and dedicating at all to banging away the keyboard instead of living a life with her large family. It’s weirdo Ville

**Jeff Bergosh**: I think they’re all mentally defective. I think they live in La La Land where they are portraying themselves as Dragon slayers and monster hunters and they’re going to rid the world of corruption! And then they snap out of it and realize they’re in a trailer with windows covered in tinfoil their heads covered in tinfoil with empty lives of meaninglessness

**David bear**: It’s really gross.  He manipulates her and she idolizes him.  It’s weird.  Although she’s a fucking cunt (excuse my French) in her public comments and posts, she is often encouraging Doug to be nicer.

**Jeff Bergosh**: She is a fucking country and there is no excuse for her whatsoever

**Jeff Bergosh**: *cunt

**David bear**: Yup

**David bear**: I think those people spend more of their time in believing they’re slaying dragons than they do realizing they live in the trailer with tinfoil windows.

**David bear**: Doug is their idol and will become their martyr when all of this shit against him comes to a head..  

**Jeff Bergosh**: A bunch of losers

**David bear**: A whole bunch

### CONVERSATION ON 10-24-2021

**Jeff Bergosh**: Good Morning David— 

I’ve spent a good bit of time looking at multiple variations of the potential redistricting maps.  I think there’s an opportunity to consolidate all of western city/downtown into Lumon’s district— all portions east of Bayou Chico all the way over to 9th avenue this could work and we could make up the difference with an additional five to D2 in Bellview and a take away from Lumon in Pine forest area which would help his minority/majority percentage.  Would love to discuss with you at some point to get your opinion.

Jeff

**Jeff Bergosh**: *give to D2

**David bear**: Hey Jeff.  Yes, I’d like to discuss.  I stayed out way too late last night and am just moving around so give me a little while to call you.  Are you available a little later this morning?

**Jeff Bergosh**: Yes absolutely.  I have a really, really good plan for D3 to make it essentially THE downtown power district AND maintain minority majority status.  Bender and Underhill will hate it

**David bear**: I’m all ears. Lumon needs more African Americans. If this helps him get that, I will like it. 

**Jeff Bergosh**: Crunching numbers now

**Jeff Bergosh**: It makes him the most powerful—controlling key real estate downtown 

**David bear**: Does it take Lois out of her district?

**Jeff Bergosh**: Again— some areas are high percentage white but no matter— it’s low numbers

**Jeff Bergosh**: So sorry

**David bear**: I’m ok with that. Fuck her

**Jeff Bergosh**: I’m agnostic 

**Jeff Bergosh**: But it’s time

**David bear**: I’d love to redistricting her out but I’m concerned it will blow up your plans

**Jeff Bergosh**: Yes— that’s why it can’t be my idea; otherwise I look like a hypocrite

**Jeff Bergosh**: Time for a brief call?

**David bear**: Sure but my brain’s not fully functioning 

**Jeff Bergosh**: LOL

**David bear**: I'm on another call. I'll call you back soon. 

**Jeff Bergosh**: K

**Jeff Bergosh**: Got the numbers— looks good

**David bear**: OK, I’ll call in a little bit.  On the phone with Papa Bear.

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-25-2021

**Jeff Bergosh**: OK I managed to solve the mystery of the Wedgewood precinct this morning. It wasn’t Robert Bender that dumped it in District one it was Paul Fetsko who did it by accident I confirm that today. So if nothing else at least that she was Robert wasn’t being vindictive. But I still think there’s some great opportunities for November 2 and I look forward to speaking with you about it all tomorrow afternoon at four

**David bear**: Great. I look forward to speaking with you tomorrow too. I’m in Ocala until late tonight.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Safe travels

**David bear**: Thanks 

### CONVERSATION ON 10-26-2021

**David bear**: Text me when you get here

**Jeff Bergosh**: Will do

**Jeff Bergosh**: At W and Beverly rn

**David bear**: 👍

**Jeff Bergosh**: Here

**David bear**: Ok. 

**David bear**: http://www.pbadvocates.org/resources/Documents/Ord%202021-____%20-%20Regulating%20Short%20Term%20Rentals%20v4.pdf?fbclid=IwAR0t4LeFtDarlDic7n_oeUzcL1GLtDbok0-8p8_wbkwAhlZEtxdQKXytiOE

### CONVERSATION ON 10-27-2021

**Jeff Bergosh**: Do u have 5 min for a quick issue and follow up from our discussion yesterday?

### CONVERSATION ON 11-01-2021

**Jeff Bergosh**: David:  I did not know Connie Bockman and the homeless task force was planning on dumping a homeless camp right in the Middle of that one precinct that I think Lumon should have that news popped on Tuesday and I wasn’t aware of it until Wednesday. I’m certainly not gonna support it downtown need to sell solve their problem downtown but I didn’t want you to think I knew that was a plan and therefore that was the reason I wanted to get rid of that district if you have a minute to discuss I’d appreciate that

### CONVERSATION ON 11-02-2021

**David bear**: Ignore him

**David bear**: Go ahead and tell him to shut up and no one is listening to his nonsense. 

**Jeff Bergosh**: LOL

**David bear**: Ahhhh. He's so cute with his passion for the people. 

**David bear**: Just tell Doug you appreciate his opinion and then disregard it. 

**David bear**: Let’s see if Doug still feels like current seat holder’s residence matter when you recommend taking downtown out of D2 and putting it into D3 where it belongs. 

**David bear**: The net of those two exchanges would give Lumon an additional 322 VAP Black and take 487 VAP White from him.

**David bear**: It puts him at 45.49% VAP African Americans

**Jeff Bergosh**: Better than previous

**David bear**: Ask him about Whitewater

**Jeff Bergosh**: LOL

**David bear**: Don’t give more downtown to D2!  It needs to go to D3

**Jeff Bergosh**: I agree

**Jeff Bergosh**: Just a conversation

**David bear**: Perfect segue into giving downtown to Lumon

**David bear**: Doug doesn’t want it so no one will fight with it.

**David bear**: Ask Robert if Southtown is affordable housing like it was promised to be…

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Cock blocked

**David bear**: Doug is trying to use reverse psychology. Thank him for making the point

**David bear**: Quit talking about Lois. Let it fall how it falls

**David bear**: 😇

**David bear**: D2 is currently the dummy district. 

**Jeff Bergosh**: Yep

**David bear**: Is Robert and Doug want this, kill it

**David bear**: Btw, you know I’m not actually telling you want to do, right?

**David bear**: PC Wu last by 1

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Yes

**David bear**: Robert is the only person who wants this. Doug doesn’t want to do it and neither does Lumon. 

**Jeff Bergosh**: Lumon likes the numbers +1400 Black

**David bear**: Doug’s comments right now are right

**Jeff Bergosh**: Stopped clock

**David bear**: Yep

**Jeff Bergosh**: I agree with him too

**Jeff Bergosh**: But Lumon doesn’t

**David bear**: “Broken”. He’s broken

**Jeff Bergosh**: He’s saying what I said

**David bear**: Liked “He’s saying what I said”

**David bear**: Does this map have those two territory exchanges you made with Lumon earlier? The two we discussed previously. 

**Jeff Bergosh**: Yes

**David bear**: Ok. 

**David bear**: I’d love to get Lumon back downtown

**Jeff Bergosh**: Probably not going to happen

**David bear**: Tell him those white people living downtown are all democrats. 

**David bear**: Tell Robert to give up Cordova Park to Lumon

**David bear**: He wants downtown…

**David bear**: Larry has truly lost his mind. 

### CONVERSATION ON 11-09-2021

**David bear**: He told me she was not going to be his aide.  This states otherwise.

**Jeff Bergosh**: I think he’s making a mistake with her.  We know what happened here in the county with her….

**David bear**: Yep.  As a friend, I shared my concerns.  I guess he wants to fuck around and find out.

**Jeff Bergosh**: I wish he would have selected anyone but her.  She might pull some vindictive shit on the county

**Jeff Bergosh**: I hope she doesn’t try that

**David bear**: We’re gonna find out pretty quickly.  There are several appropriation requests for county economic development and UWF.  If they don’t happen, she fucked them up.

**Jeff Bergosh**: She’d better not do that

**David bear**: I assure, Papa Bear will not be happy since both of those items are close to his heart. 

### CONVERSATION ON 11-12-2021

**David bear**: Meeting with Alison Rogers now. I’ll call you later b

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-19-2021

**David bear**: Give me a call when you can please. Thanks 

**Jeff Bergosh**: Will do

**Jeff Bergosh**: On conf call will call u right after

**David bear**: Thanks 

**David bear**: Hahahaha

**David bear**: I want one

**Jeff Bergosh**: Isn’t that awesome!

**David bear**: I hope those were made from melting his statue

**Jeff Bergosh**: LOL that’s the first question I asked

**David bear**: Do you have one?

**Jeff Bergosh**: Not yet

**David bear**: I’m working on getting me one 

**Jeff Bergosh**: But I’ll ask my source where to get one

**David bear**: I love the, “End of an ‘Error’”

**Jeff Bergosh**: Yeah that’s a great line

**David bear**: When I first read it, I read era not error and still thought it was great. Error takes it to a whole ‘nother level. 

**Jeff Bergosh**: Yes it does!

### CONVERSATION ON 11-26-2021

**Jeff Bergosh**: Hey David!  Hope you had a great Thanksgiving!  Just making sure we’re still on for lunch today at IPC @ 11:30?  See you there!

Jeff B

**David bear**: Thanks Jeff. Thanksgiving was great and I hope you had a great one too. Yes, I’ve got a table reserved for us in IPC. Look forward to seeing you shortly. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-10-2021

**David bear**: https://www.pnj.com/story/opinion/2021/12/10/marlette-feed-kids-starve-commissioners/6437074001/?itm_medium=recirc&itm_source=taboola&itm_campaign=internal&itm_content=RightRailArticleThumbnails-Redesign

**David bear**: Did you see this shit yet?

**Jeff Bergosh**: Not yet.  What a POS

**David bear**: I heard Pam sent another letter yesterday.  Y’all need to take immediate action against her.  The longer you wait, the more effective Marlette’s messaging will be. Troy needs to PR this as her overreach and unauthorized actions.  I believe there is case law that prohibits her from not doing her job.  If everything Pam does wrong is addressed, the public perception of her action in this will be changed.  She allowed Matt Posner to double dip.  She allowed Janice to spend TDT on unauthorized expenditures.  She doesn’t justify her cash grab on the TDT for her administration of the program.  She hasn’t filed completed/accurate financial disclosures.  She hasn’t fulfilled public records requests about how much she makes and participates in the retirement program.  Those are the things we know about.  What else has she done wrong?

**David bear**: Fuck Marlette.  Ignore him and make him irrelevant.  Any response to his articles and cartoons makes him valuable to the PNJ.

**David bear**: The more he’s wrong, the more liability he is to the PNJ

**Jeff Bergosh**: I wasn’t aware of a second letter that’s good information and I will asked to see it. And I agree the problem is Troy Rafferty is in a federal trial in Tallahassee. But something needs to be filed right away this isn’t right for Bender Barry and May to be lashed this way in the public press. I think Andy’s really upset with deprive them of some revenue and that’s part of the reason he’s coming after us. But Pam is his willing accomplice so we got to get that issue sorted out

**David bear**: Liked “I wasn’t aware of a second letter that’s good information and I will asked to see it. And I agree the problem is Troy Rafferty is in a federal trial in Tallahassee. But something needs to be filed right away this isn’t right for Bender Barry and May to be lashed this way in the public press. I think Andy’s really upset with deprive them of some revenue and that’s part of the reason he’s coming after us. But Pam is his willing accomplice so we got to get that issue sorted out”

### CONVERSATION ON 12-15-2021

**David bear**: Hahaha

**Jeff Bergosh**: LOL

**Jeff Bergosh**: You like?  It’s truth

**David bear**: That was awesome.

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Not as smart as he thinks he is

**David bear**: I know it's truth. It's awesome how it makes it look like Doug wants to raise taxes. I know the context when he says that but the article is written well.

**Jeff Bergosh**: That’s why he’s been getting his ass kicked aince I showed up

**Jeff Bergosh**: Since

**Jeff Bergosh**: Yeah for in weekly it wasn’t too bad LOL

**David bear**: Did you see this too?

**Jeff Bergosh**: No I didn’t 

**Jeff Bergosh**: It should have been a stand-alone loser

**David bear**: Rick took a jab. He will

**Jeff Bergosh**: Good—— he needs to! I

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-17-2021

**Jeff Bergosh**: Early to mid February—— time to face the music!

**David bear**: Apparently, those aren’t the real dates.  They may end up being on of those but the judge just loads dates in and then they agree to a date certain.

**Jeff Bergosh**: Oh, okay.  Hopefully it will be in February though!

**David bear**: Me too.  I’m glad those aren’t the dates.  I’m only available 9th-11th and that’s the only time Figlio isn’t available.

**David bear**: Did you see his stupid post?

**David bear**: I like my reply

**Jeff Bergosh**: No- where was it posted?

**David bear**: On his FB Commission page.

**Jeff Bergosh**: That’s a funny meme— he’s the ultimate hypocrite 

**David bear**: Liked “That’s a funny meme— he’s the ultimate hypocrite ”

**David bear**: I mean, break it down.  He makes that post and there are 12 comments, including mine, but I can only see 6 of them.

**Jeff Bergosh**: He’s still playing blocking games

**David bear**: Yep.  He banking on the judge not finding FB comment section a public forum.

**David bear**: Make sure the county’s not paying Mark Herron’s fees for Doug’s ethics hearings

**Jeff Bergosh**: I will

### CONVERSATION ON 12-21-2021

**Jeff Bergosh**: “Merry Christmas from the GoatKillers”. LOL

**David bear**: So, I didn’t know.  I just looked it up on the docket at DOAH.  That’s great.  I just blocked the two days on my calendar.  MERRY FUCKING CHRISTMAS!

**Jeff Bergosh**: LOL!!!

**Jeff Bergosh**: LOL

**David bear**: Laughed at “BTW— that sounds like a great greeting card to the farm.  And or neatly decorated envelope with beautifully stenciled letters to the family. Inside a copy of that notice.

Followed by:

MERRY FUCKING CHRISTMAS!”

**Jeff Bergosh**: Perfect

**Jeff Bergosh**: I’m gonna block those two days off my calendar too, damn it!!

**David bear**: Laughed at “I’m gonna block those two days off my calendar too, damn it!!”

**Jeff Bergosh**: BTW— I confirmed today— we aren’t paying any of his fees for this.

**Jeff Bergosh**: He’s paying

**David bear**: Alison called me and asked if I knew who was paying Mark Herron's fees. I told her I talk to you about it and then I wasn't sure. I asked her if she thought it was possible that Pam Childers would do it without discussing it with the county commission. She said she thinks it's highly unlikely because it's so egregious.

**Jeff Bergosh**: That would piss me off if that was happening

**Jeff Bergosh**: House of cards = collapsing

**David bear**: I'm trying to find out if the AG advocate can subpoena those payment records from Mark Herron since this complaint also includes not reporting gifts of free legal services.

**Jeff Bergosh**: That would be great information to know David!

**Jeff Bergosh**: I bet Doug is slow paying that son of a gun

**David bear**: If at all. I bet he’s using SBA loan proceeds for repairing his house to pay for the attorney. 

**Jeff Bergosh**: He probably is but he’s doing that he’s going to fix the house?

**Jeff Bergosh**: With what $

**David bear**: He got an SBA loan around March for $180k presumably to repair his house damage. 

### CONVERSATION ON 12-25-2021

**David bear**: Merry Christmas Jeff. I hope you and your family have a beautiful day. 

**Jeff Bergosh**: Thank you David!  Happy Holidays to you and your family as well!  2022 is going to be a great year!!!

**David bear**: Loved “Thank you David!  Happy Holidays to you and your family as well!  2022 is going to be a great year!!!”

### CONVERSATION ON 01-06-2022

**David bear**: Alison is saying Peppler did not send his own letter to Marcille, but instead, sent JJ’s letter in response to Peppler’s letter to Marcille.  That is not true.  I sat down with Marcille before JJ responded and Marcille had the letter.  I remember because it was the first time I saw it.  She either did not know Peppler sent it or he’s told her otherwise, but I am certain Marcille had that letter before I did.

**Jeff Bergosh**: Okay thanks for that info

**David bear**: Yes sir.  The final version was just sent to Alison and Joe.  She can read it during public forum.

**Jeff Bergosh**: Got it! Thanks!

**David bear**: Liked “Got it! Thanks!”

**David bear**: Thanks!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: We got it done!!

**David bear**: Underhill is such a douchebag. You handled that whole process masterfully. 

**David bear**: I really appreciate your insistence on getting it done. 

**Jeff Bergosh**: Thank you.  It had to happen it was way past due I’m glad you guys were able to move quickly on it today thank you for that!

**David bear**: Of course. Like I’ve said from the beginning, I never wanted to sue the county. This should have been done two years ago and I wouldn’t have sued the county. 

**Jeff Bergosh**: I’m just glad it’s all coming too a head now

**Jeff Bergosh**: It’s time

**David bear**: This document helps immensely. We will now send it to the judge for her consideration while she is reviewing the magistrate’s report and recommendation.

**Jeff Bergosh**: Fantastic you should get it first thing in the morning I just got done signing it along with all the other paperwork from the meeting

**Jeff Bergosh**: LOL

**David bear**: Liked “Fantastic you should get it first thing in the morning I just got done signing it along with all the other paperwork from the meeting”

**David bear**: Laughed at “I signed the document with a large signature I pulled a John Hancock on it”

### CONVERSATION ON 01-07-2022

**David bear**: Good morning and thanks again for pushing forward last night.  Any chance you can get Alison to send Figlio the signed documents this morning?  Thanks

**Jeff Bergosh**: I’ll direct her to do so.  Operation Warp speed——engage LOL

**David bear**: Laughed at “I’ll direct her to do so.  Operation Warp speed——engage LOL”

**David bear**: Thanks 

**Jeff Bergosh**: 👍

**David bear**: Just read your blog post.  I believe you were attempting to make Doug look bad for causing the lawsuit, but he is not why I sued the county and that makes me look bad for doing it.  I sued the county because the county did nothing about Doug’s failure to fulfill my requests.  He was violating the county policy and publicly stated he would not comply.  The policy required the county to retain all posts on social media about county business. The county has an obligation, under ch. 119 to demand the public records. The county neither demanded the public records from Underhill nor took any action against him for failure to comply with the policy.  In fact, the county rescinded the policy 6+ months into the litigation.  All of my public records requests went to both Underhill and the county.  The county never fulfilled any of them and refused to confirm any of the documents we did receive from Underhill completed the fulfillment of my requests. The county attorney’s office never even reviewed them (something Alison testified to at the hearing and you guys stipulated to last night). Under case law, the county’s inaction was its culpability. I did not want to put anything in the settlement agreement/stipulation that made the county confirm its fault because it doesn’t matter if we are settling.  I’m releasing you from liability and really wanted to make sure the stipulations only made Underhill look terrible.  I’m not asking you to admit the county was at fault in your post, but it shouldn’t say the county did nothing wrong and the lawsuit was never right.  Had something like this stipulation (e.g., censure) happened two years ago, the county would not have been a party to my suit.  You could easily say, Underhill created the lawsuit because of his actions and now the county has settled its part of the suit. 

**Jeff Bergosh**: Thanks I can see that— and I agree with that and that’s what I’m trying to say in the post—-I’ll go back and re-read that 

**David bear**: Thanks.  I didn’t think you were trying to point the finger at me but that’s how it reads.

**Jeff Bergosh**: Definitely not!

**Jeff Bergosh**: It’s Eddins’ fault if we’re being completely honest

**David bear**: Liked “Definitely not!”

**David bear**: Emphasized “It’s Eddins’ fault if we’re being completely honest”

**David bear**: 100%

**David bear**: Did you happen to sign 2 copies of the agreement last night?

**Jeff Bergosh**: I signed one

**David bear**: Yeah, that’s what Alison just told me.  I’m heading down there shortly to sign it.  I was hoping for an original too.  I’m going to sign two copies and the second will need your signature later.  Alison said she can give me a copy today and send me an original once the second one is signed.

**Jeff Bergosh**: I can swing by on the way home from work and sign it

**David bear**: Shit.  You think anyone in that office will still be around that late on a Friday? 😂

**Jeff Bergosh**: LOL— probably not 

**Jeff Bergosh**: BTW— I added some language to the post to make it much clearer that it’s A lot of people not doing anything, including state attorney, that led to the lawsuit

**David bear**: Thanks.  I saw you updated the vote count too

**Jeff Bergosh**: Yeah I screwed that up Doug didn’t vote he abstained

**David bear**: lol - That was the best part of last night. At the end of his conflict statement, he tried to grasp at straws to save face by saying he was never going to stop saying the truth to the powers that be.  He’s so twisted, he forgets people know this lawsuit was about his violation of PRR and 1st Amendment rights and not about anything he said.  He looked like a gut-shot deer looking around trying to find a way out of his situation.

**Jeff Bergosh**: Absolutely

**Jeff Bergosh**: ?

**David bear**: humiliated, not humbled.  He has no humility

**David bear**: yup

**David bear**: Is the county going to demand the Clerk reimburse the county for making the unauthorized payments to Posner under Florida Statute ch. 129.09?

**David bear**: She’s personally liable

**Jeff Bergosh**: Not sure what status is of that yet

**David bear**: Take that bitch down. 

**Jeff Bergosh**: She’s actually doing it to herself……

**Jeff Bergosh**: ……but can’t see it

**David bear**: Yep. She’s imploding. She’s a bully

### CONVERSATION ON 01-24-2022

**David bear**: Just read your blog post about clerk lawsuit.  I’d like to see her dispute items #50 & #51 in the complaint. hahaha

**Jeff Bergosh**: Yeah— it’s going to be tough for her

**Jeff Bergosh**: She’s hosed herself

**David bear**: Yep.  I heard the auditor general basically ignored her during the meetings when she was defending her position on the TDT stuff.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: She was trying to blow it up at a meeting into an audit of our entire operation which the paperwork on the back of does not support. This is an audit of the TDT funds and nothing more

**David bear**: Wonder Woman is getting the lasso of truth wrapped around her throat.

**Jeff Bergosh**: But she wanted it to be a monster that we were going to have to face which I do not believe it it is I believe it’s a monster she’ll have to face

**Jeff Bergosh**: Exactly

**David bear**: FYI - When Broxson got the auditor general to perform the audit of the gulf breeze water system and purchase of the Tiger Hills golf course, he convinced them to dig further and it turned into an audit of the entire city.

**Jeff Bergosh**: Where we’ll see if that happens here I just don’t believe that it will based upon our initial conference that I was privy to last week

**Jeff Bergosh**: Hey but if it is something more I welcome it and I have nothing to hide and we’ll see what happens

**David bear**: If it does and they find unauthorized expenditures, guess who is personally liable.  If they find Janice made illegal procurement actions or fucked around with federal funds, Janice and Pam should be in trouble.

**David bear**: I don’t know of other issues, I’ve only heard rumors.  I know they made unauthorized payments with the TDT.

**David bear**: Different topic. Will you ask Alison if Doug followed the policy to get his legal fees reimbursed in my lawsuit?  I don’t recall it ever coming before the BOCC at a meeting. 

**Jeff Bergosh**: Will do

**David bear**: Thanks 

**David bear**: Did you happen to talk to Alison today?

**Jeff Bergosh**: I have not yet—- been buried all day long

**David bear**: Ok, thanks

**Jeff Bergosh**: BTW— I do not believe he is getting reimbursed I do believe that Allison’s office unilaterally made the decision to provide coverage under an insurance policy that we had. The problem is it’s a high deductible which means essentially we are paying which kind of pisses me off

**David bear**: I think that’s just in the state case but not in the federal case.  I don’t think there is any insurance in the federal case.

**Jeff Bergosh**: That’s a Robert Bender special

**David bear**: Emphasized “That’s a Robert Bender special”

**Jeff Bergosh**: I’ll find out for sure

**Jeff Bergosh**: On my way out today I’ll call her on her cell

**David bear**: I believe the insurance underwriter denied coverage in the federal case.

**David bear**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-25-2022

**David bear**: Check county email

**Jeff Bergosh**: Will do

**David bear**: Hammons is not representing the BOCC’s intention because he doesn’t agree with the settlement.  He’s playing fuck around just like he did when he filed the brief agreeing with Underhill that FB posts are not public record.

**Jeff Bergosh**: I think he’s going to have to be pulled from the mound we need a different relief pitcher

**Jeff Bergosh**: I’ve got a call into Allison right now I’m gonna speak with her about it

**David bear**: Greg Rettig is representing the county in the state case. He’s up-to-date on the lawsuit.

**Jeff Bergosh**: He’d be a logical choice

### CONVERSATION ON 01-26-2022

**David bear**: What is your brother saying about the case being kicked to Okaloosa and probably Panama City?

**Jeff Bergosh**: He predicted it.  

**David bear**: I assume it’s because they all want to avoid retaliation from her office when she loses.

**Jeff Bergosh**: Exactly

### CONVERSATION ON 01-28-2022

**David bear**: https://www.pnj.com/story/opinion/columnists/2022/01/28/escambia-county-commissioners-sue-people-personal-profit-andy-marlette/9234965002/

**Jeff Bergosh**: Well, well.  We knew this was coming………

**Jeff Bergosh**: Thankfully— few listen to this tool bag 

**David bear**: Emphasized “Thankfully— few listen to this tool bag ”

