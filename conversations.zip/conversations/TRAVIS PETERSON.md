

## CONVERSATIONS WITH TRAVIS PETERSON

### CONVERSATION ON 11-30-2020

**Travis Peterson**: Commissioner - Thanks for your time tonight! Very helpful meeting. I recall that the last time we chatted at length we were discussing appointed superintendent!

**Travis Peterson**: - Travis Peterson

**Jeff Bergosh**: Thanks Travis!  Yes I remember that.  Glad that happened.  Thanks for the time tonight!

### CONVERSATION ON 12-03-2020

**Travis Peterson**: Hi commissioner, working on your data request. If you get five minutes could you give me a call? Want to make sure we are on the same page

### CONVERSATION ON 01-26-2021

**Travis Peterson**: Thanks for the talk today. As always, appreciate your candor.

**Jeff Bergosh**: Thanks Travis

### CONVERSATION ON 01-28-2021

**Travis Peterson**: Well done on WEAR story this morning!

**Jeff Bergosh**: Thanks Travis

### CONVERSATION ON 02-01-2021

**Jeff Bergosh**: https://ricksblog.biz/poll-voters-want-jobs-at-olf-8/

**Travis Peterson**: Just saw. To me it’s a false choice to pit jobs vs housing/retail. It doesn’t have to be either/or, although it can be. The tougher question is more about allocation and time value of money. 

**Travis Peterson**: Also, we finally have Haas center data coming. I think you will be pleased! 

**Jeff Bergosh**: I don’t disagree.  However there are some all or nothing groupies saying “no commerce park” which really means “no jobs!”   They are a vocal, tiny minority.

**Jeff Bergosh**: Good— looking forward to that data

**Travis Peterson**: Agreed. And my team should also note that many charrette participants did express a desire for more jobs diversity in Beulah. Here’s to us all surviving the sausage grinder!! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-04-2021

**Travis Peterson**: Great response to the comments.

**Jeff Bergosh**: Thx

### CONVERSATION ON 03-02-2021

**Jeff Bergosh**: Thanks for asking that question

**Travis Peterson**: Sorry I’m trying to get to them all. 

**Jeff Bergosh**: 👍

**Travis Peterson**: I’m trying to get in your questions along with others who have some residential vs. commerce use questions. If I summarize wrongly let me know.

### CONVERSATION ON 03-03-2021

**Jeff Bergosh**: .......I do get the fact that at least politically it's akin to a concoction of ricin and hemlock

