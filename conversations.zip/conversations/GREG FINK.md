

## CONVERSATIONS WITH GREG FINK

### CONVERSATION ON 08-25-2020

**Jeff Bergosh**: I’ll call u back

**Greg Fink**: Can I call you right after meeting? Had a couple of questions about OLF8

**Jeff Bergosh**: Sure

### CONVERSATION ON 10-29-2020

**Greg Fink**: http://thelistenergroup.com/wp-content/uploads/2020/10/Trump-Leads-Biden-by-4.pdf

**Jeff Bergosh**: Wow!  Good news!

### CONVERSATION ON 11-04-2020

**Greg Fink**: https://ricksblog.biz/listener-group-political-matrix-poll-nails-florida-results/

**Greg Fink**: Listener Group/Political Matrix poll nails Florida results – Rick’s Blog

**Jeff Bergosh**: Congrats

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Greg Fink**: Great job at the meeting tonight

**Greg Fink**: Give me a call in between your very busy schedule tomorrow

### CONVERSATION ON 03-14-2021

**Greg Fink**: http://thelistenergroup.com/florida-voters-want-safer-churches/

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: Can I call you later?

### CONVERSATION ON 08-16-2021

**Jeff Bergosh**: In mtg will call u back later

### CONVERSATION ON 12-02-2021

**Greg Fink**: I stopped by your office last minute downtown

**Greg Fink**: Call me later when you get a chance

### CONVERSATION ON 12-14-2021

**Greg Fink**: You read that hit piece on our guy?

