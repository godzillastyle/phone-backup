

## CONVERSATIONS WITH DANNY HOLMAN

### CONVERSATION ON 12-21-2020

**Danny Holman**: What ya think?

**Jeff Bergosh**: Wow!  You all made a lot of progress today!!

**Danny Holman**: I guess since I put your kitchen in the land fill today that pretty much commits me to rebuilding it huh?

**Jeff Bergosh**: Yep! 😎👍

### CONVERSATION ON 12-22-2020

**Danny Holman**: Well damnnnnnnnn..

**Jeff Bergosh**: WOW!  It's coming along nicely!!  Any unforeseen issues?

**Jeff Bergosh**: You guys are doing fantastic!

**Danny Holman**: Nope no surprises yet.

**Danny Holman**: Thanks

**Jeff Bergosh**: That's great news!!

### CONVERSATION ON 12-23-2020

**Danny Holman**: Gone with the wind..

**Jeff Bergosh**: Nice!!

**Jeff Bergosh**: Wow-- got the slab cut already!! You all are making some fast progress!!!

**Danny Holman**: Your cabinets in work..

**Jeff Bergosh**: Right on!

### CONVERSATION ON 12-28-2020

**Danny Holman**: When are you guys due back?

**Jeff Bergosh**: On January 5th

**Jeff Bergosh**: How's it going so far?

**Danny Holman**: 👍

**Danny Holman**: Going good,  I have selectricity coming in the morning to look at the project and give estimate. 

**Jeff Bergosh**: Okay great!  Also-- my doorbell lost contact with the router.  Was power cut off by chance?

**Danny Holman**: Gary was here today to do a fit check for sink base.

**Danny Holman**: Maybe due to breakers being turn on and off.

### CONVERSATION ON 12-29-2020

**Danny Holman**: Led lighting by selectricity. 

### CONVERSATION ON 12-30-2020

**Jeff Bergosh**: Good Morning Danny-- the vent hood is going to be delivered this morning to our house-- any chance you will be around and can bring it inside?

**Jeff Bergosh**: Wow that looks incredible Dan!!

### CONVERSATION ON 01-02-2021

**Jeff Bergosh**: Hope you have a great weekend!

**Danny Holman**: That's great news, what is their schedule or did they give one yet?

**Jeff Bergosh**: Didn't give one yet.  As soon as they send the invoice I'll pay the deposit

**Jeff Bergosh**: Regardless-- to keep forward progress going I've approved it😎👍

**Danny Holman**: Ok, I do want to be there when they are working to insure we get what we need. They are proud of their work but they are very good and leave no doubt about any what if's and your safety is good.

### CONVERSATION ON 01-04-2021

**Danny Holman**: What time should I have the champagne  and balloons ready for your arrival tomorrow.?

**Jeff Bergosh**: 6:30

**Danny Holman**: Thats to early for champagne..

**Jeff Bergosh**: PM LOL

**Jeff Bergosh**: 6:30 AM would be too early

**Danny Holman**: Lol, ok then..

### CONVERSATION ON 01-05-2021

**Jeff Bergosh**: Hi Danny I just touched down in Houston.  Got your message.  Can I just pay their down payment over the phone?  If so I'll get that taken care of today!  Thanks!

**Danny Holman**: I'm sure you can..

**Jeff Bergosh**: Danny-- I just paid Selectricity's down payment over the phone.  The young lady I paid said to have you call her back now to get the work scheduled.  Thanks!

**Danny Holman**: Home yet?

**Danny Holman**: We will be at the house around 9am to continue work unless you want us to hold off tomorrow. 

**Jeff Bergosh**: Just got home---yes let's for sure work tomorrow.  Sally and I will be at work all day long

**Jeff Bergosh**: Progress looks great-- my internet is down though-- router appears to be fried

**Danny Holman**: Might be the circuit breakers that are tripped you can reset them to see , all disconnected wires are capped.

### CONVERSATION ON 01-06-2021

**Danny Holman**: When you have a chance and a couple of minutes give me a call please.

**Danny Holman**: Rodgers Electrical is on the way here now.

**Jeff Bergosh**: Outstanding!  Thanks Danny!

**Danny Holman**: 👍

**Danny Holman**: I called Selectricity and canceled,  they are waiting for you to call to refund your money 

**Jeff Bergosh**: Thanks I'm calling right now

**Danny Holman**: 👍

### CONVERSATION ON 01-07-2021

**Danny Holman**: Would you like a preview picture of your new sink cabinet?

**Jeff Bergosh**: Yes!

**Jeff Bergosh**: Thank you!!

**Danny Holman**: Coming at you.

**Jeff Bergosh**: Wow!!

**Jeff Bergosh**: That looks great!

**Danny Holman**: Going to install it tomorrow..

**Jeff Bergosh**: Fantastic!

**Danny Holman**: Just a reminder electrical folks will be there at 0900 tomorrow. 

**Jeff Bergosh**: Fantastic.

**Jeff Bergosh**: Will you be there?  I will be at work and Sally will as well.

**Danny Holman**: Yep as always untill job completion. 

**Danny Holman**: How do you like floor?

**Jeff Bergosh**: Just got home-- Floor looks great!!

### CONVERSATION ON 01-09-2021

**Danny Holman**: The one other thing I forgot to mention to you is the electrician that was in the attic told me that he did see mouse / rat feces in the attic. 

**Jeff Bergosh**: Oh great

**Jeff Bergosh**: Thanks.  I'll have our service set some traps

**Danny Holman**: 👍

### CONVERSATION ON 01-10-2021

**Danny Holman**: Had to move drywall schedule to Tuesday morning due to drywallers work load.

**Jeff Bergosh**: Okay no worries thx for heads up

### CONVERSATION ON 01-12-2021

**Danny Holman**: Shower

**Jeff Bergosh**: That looks great thanks Danny!

**Danny Holman**: 👍

### CONVERSATION ON 01-13-2021

**Danny Holman**: Looks as if your leaking shower issue is solved, no leaks from everyone's shower this morning. 😁

**Jeff Bergosh**: That's great news!!!!  Problem solved-- thank you!!!

**Danny Holman**: 👍

### CONVERSATION ON 01-14-2021

**Jeff Bergosh**: Ah-ha--- was that the culprit?

### CONVERSATION ON 01-15-2021

**Danny Holman**: AT&T is here now.

**Jeff Bergosh**: 👍

**Danny Holman**: Your modem and internet is in service.

**Jeff Bergosh**: Awesome!!!! That's such a relief!!

**Danny Holman**: 👍

**Danny Holman**: How is the shower acting?

**Jeff Bergosh**: I see a little moisture seeping through still, unfortunately.  It's so damn frustrating.  What should I do?

**Danny Holman**: Give it a couple of days to dry out in the meantime I'll pick up a new seal for the door.

**Jeff Bergosh**: Okay thanks Danny!

**Danny Holman**: At least your not seeing rynning puddles.

**Danny Holman**: Running not rynning

**Jeff Bergosh**: Nope

**Jeff Bergosh**: So that's a win

**Danny Holman**: Did you see the dent in the mini fridge?

### CONVERSATION ON 01-16-2021

**Jeff Bergosh**: Yes-- but once the cabinets are in it will be covered up and it's working so....

**Danny Holman**: 😁

### CONVERSATION ON 01-19-2021

**Danny Holman**: You home?

**Jeff Bergosh**: No, still at office.  Everything okay?

**Danny Holman**: All good when you get away from work give me a call.

**Jeff Bergosh**: Will do

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: Wow Guys!! I just got home and I really like the looks of this Island as it is coming together!!  Thanks!!

**Danny Holman**: 👍. More tomorrow..

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-29-2021

**Danny Holman**: Just talked to Mark (Electrical) he said he will try and have the guys back out on Monday, Tuesday for sure to finish Electrical work on the Island and the ceiling box's for the chandeliers.

**Jeff Bergosh**: Awesome!

### CONVERSATION ON 02-02-2021

**Danny Holman**: Island electrical is in place , dish washer going thru cycle right now rewashing dishes. 

**Danny Holman**: 👍

**Danny Holman**: Should have chandeliers operational soon.

**Jeff Bergosh**: Nice!!!

**Jeff Bergosh**: Thanks!

**Danny Holman**: Welcome

### CONVERSATION ON 02-03-2021

**Jeff Bergosh**: Your check is on the beverage cooler under the two candles.  Thanks Danny!

**Danny Holman**: No thank you Jeff..

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: In a BCC meeting I'll call u after

**Danny Holman**: 👍

### CONVERSATION ON 02-05-2021

**Jeff Bergosh**: Okay thanks for the update

**Danny Holman**: ✔

### CONVERSATION ON 02-12-2021

**Danny Holman**: Call me when your free.😁

**Jeff Bergosh**: Looking fantastic Danny.  I'm in a mtg. Right now but I'll call u when I break out.  Looks amazing!!

**Danny Holman**: 👍

**Danny Holman**: You home yet?

**Danny Holman**: Talked to Mark he said to drop the extra line would be around 50 to 75 dollars extra, I told him to go ahead and do it.

**Jeff Bergosh**: Right on!  Great news!!

**Jeff Bergosh**: Thanks Danny!

**Danny Holman**: 👍

### CONVERSATION ON 02-17-2021

**Danny Holman**: Are you home?

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Like the base molding!

### CONVERSATION ON 02-20-2021

**Danny Holman**: If your going to be at home around noon I like to come by and discuss the crown molding with you guys.

**Jeff Bergosh**: Danny we will be in and out all day, Sally has a tennis match downtown at noon

**Jeff Bergosh**: Tomorrow?

**Danny Holman**: Tomorrow is good for noon, I need to get you guy's to see and approve before I install.

**Danny Holman**: Tell her it's to cold for tennis..lol

**Jeff Bergosh**: LOL will tell her!  Tomorrow at noon it is!  Thanks Danny!

**Danny Holman**: Only Yankees play tennis in the winter..😆. See ya tomorrow. 

**Jeff Bergosh**: LOL!

### CONVERSATION ON 02-21-2021

**Danny Holman**: [Name] Guy Sprinklers
[Mobile] +1 850-860-5727

**Danny Holman**: Call me when you have a chance ,(no speaker phone) I have a solution  for the crown. 😁

### CONVERSATION ON 02-22-2021

**Danny Holman**: Well how are you liking the lighting?

### CONVERSATION ON 02-23-2021

**Jeff Bergosh**: I like it a lot!  It's fantastic!

**Danny Holman**: All attic work is done, exhaust ducting in place and all insulation back in place.😁😁

**Jeff Bergosh**: Outstanding!  Thank you Danny!

### CONVERSATION ON 02-24-2021

**Jeff Bergosh**: 👍👍 thanks Gary!

**Danny Holman**: 😁😁😁😁😁😁😁

### CONVERSATION ON 03-01-2021

**Jeff Bergosh**: Love that dimmer switch Danny!  Thank you!!

**Danny Holman**: 👍

### CONVERSATION ON 03-02-2021

**Danny Holman**: Well ??

**Jeff Bergosh**: I love it!  Looks fantastic.  On a zoom call about OLF-8 or I would have texted earlier.

**Danny Holman**: 👍

**Jeff Bergosh**: You guys are crushing it!!! Love the way it is coming together!

**Danny Holman**: We're trying,  thanks..

**Jeff Bergosh**: 👍👍👍👍

### CONVERSATION ON 03-04-2021

**Jeff Bergosh**: Hey Good Morning Danny.  A guy from ADT is coming by this morning to change out the cell backup in the box in the laundry room.  If you wouldn't mind letting him in I'd greatly appreciate it--thanks!

### CONVERSATION ON 03-08-2021

**Danny Holman**: Morning Jeff, when you go on your lunch give me a call if you can please sir.😁

**Danny Holman**: Found out that the proper definition of a conservative is a liberal that has been mugged by reality..🤔🤔

**Jeff Bergosh**: LOL---right!

### CONVERSATION ON 03-10-2021

**Jeff Bergosh**: Wow!  That came out looking fantastic!

**Danny Holman**: 👍

**Danny Holman**: Thoughts?

**Jeff Bergosh**: Looks great!!

### CONVERSATION ON 03-11-2021

**Jeff Bergosh**: 👍

**Danny Holman**: When you get home and unwind a bit give  me a call please sir.

**Jeff Bergosh**: Will do Danny!

### CONVERSATION ON 04-09-2021

**Danny Holman**: We have 2 weeks and will be starting flooring,  have you pick up flooring yet and made a battle plan for clearing rooms?

**Jeff Bergosh**: Yep.  Flooring is stacked in Garage and we're ready when u are 👍

**Danny Holman**: Damn , be still my beating 💓 

**Danny Holman**: Lol, 😅😅

### CONVERSATION ON 04-25-2021

**Jeff Bergosh**: Ready to go!  See you tomorrow!

Jeff B

**Danny Holman**: Holy Molly, awsome.😁😁😁😁 

**Jeff Bergosh**: 👍👍

### CONVERSATION ON 04-27-2021

**Danny Holman**: Well is it starting to look like what you want?

**Jeff Bergosh**: Yes it is--looks good!

**Danny Holman**: Good deal..😁

### CONVERSATION ON 04-28-2021

**Danny Holman**: I had a short day today, I had a eye appointment to go to and Gary was down with back issues but got dining  room floor down up to trim. The door transitions are in place but not permanent just in case someone doesn't like them.

**Jeff Bergosh**: Thanks for the update Danny.  If possible we may want a different color for those transitions.  Are there many choices?  I'll touch base tomorrow to discuss.  Thanks!

**Danny Holman**: Lol, I did spend some time looking but I do have one more source to look at and that is why they are not permanently installed.

### CONVERSATION ON 04-29-2021

**Danny Holman**: This is bare wood , what ya think?

**Jeff Bergosh**: I think that might work.  I'll ask Sally as well.  

**Danny Holman**: Same ones ,I removed the finish.

**Jeff Bergosh**: I think what we're looking for is something that matches the new flooring going away from the warm color that we had before to something that matches at least some part of the new flooring color scheme is that something that Home Depot might sell? Or Lowe's?

**Danny Holman**: Have already looked at both of them but you can have a look and you may find a look your good with .

**Jeff Bergosh**: Okay will do--thx Danny

**Danny Holman**: There is one other source that may be of help, try Pro Source of Pensacola, ask for Keith Quackenbush tell him I sent you ,if he has what you need you can get it at wholesale. He is kind of expecting to talk to you anyway in regards to your bathroom needs.

**Jeff Bergosh**: Ok I'll touch base with him

**Jeff Bergosh**: Do u have a good number for him?

**Danny Holman**: 850-449-0121

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I'm in a meeting I'll call u back after

**Danny Holman**: 👍

**Danny Holman**: Killed this hornet in your kitchen this morning. 

### CONVERSATION ON 04-30-2021

**Danny Holman**: Whats the verdict?

**Jeff Bergosh**: Jury still out LOL

**Jeff Bergosh**: But that sure was one hell of a big hornet though!

**Danny Holman**: I don't know what your kids schedule is or was but there is going to be a lot of noise in the hallway very soon.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-01-2021

**Danny Holman**: I will be back at your house again tomorrow at 7am to get finalized before you guys get back.

### CONVERSATION ON 05-02-2021

**Jeff Bergosh**: Right on Danny

**Danny Holman**: 😁, was kinda worried about you guys when I saw the news this morning about the shootings in the French Quarter last night glad to hear from you.

**Jeff Bergosh**: Luckily we weren't involved in that!

**Danny Holman**: 👍

### CONVERSATION ON 05-03-2021

**Jeff Bergosh**: Got it

**Danny Holman**: 👍

### CONVERSATION ON 05-05-2021

**Jeff Bergosh**: Danny I left the check on my dining room table also while you're here can you please take a look at the sliding door in the front door? It looks as though we still need to add the quarter round to those locations thank you!

**Danny Holman**: Oops,  will do.

**Jeff Bergosh**: Thx Danny!

**Danny Holman**: 😁 welcome...

### CONVERSATION ON 05-08-2021

**Danny Holman**: I will come by on Tuesday afternoon and take care of my omission to the quarter round.

**Jeff Bergosh**: Sounds good thanks Danny

### CONVERSATION ON 05-14-2021

**Danny Holman**: You happy?

**Jeff Bergosh**: Thanks Danny it looks great!  I like the sweep on the front door!

**Danny Holman**: 👍

### CONVERSATION ON 05-16-2021

**Danny Holman**: I just placed your house key under the sand dollar on outside table at front door.

**Jeff Bergosh**: Thanks Danny!

**Danny Holman**: Welcome. Are you guys good?

**Jeff Bergosh**: Absolutely! Thanks Danny

### CONVERSATION ON 05-20-2021

**Danny Holman**: Ok everything has had time to settle, is there anything that myself or Gary need to do to make you whole or is all good?

### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Danny it has been fantastic!  We love the kitchen and flooring-- you all did a great job.  We're actively saving up now so you all can do our bathroom!

**Danny Holman**: Good to hear, call me with any issues.😁

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-03-2021

**Danny Holman**: If your son is still serious and his schooling is done for now I can use him for sure, I have a bathroom remodel and other projects . Have him call me when he is ready.

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: Thx Danny

**Danny Holman**: Welcome sir

### CONVERSATION ON 06-24-2021

**Danny Holman**: Hope all is well with your new kitchen and home flooring,  let know if you have any issues.😄

### CONVERSATION ON 06-25-2021

**Jeff Bergosh**: Hey Danny everything is fantastic we love the kitchen it's just been amazing. Sorry I missed your call I've just been in and out of meetings all day and I have a funeral at 10 AM. Hope all is well with you.  I did pass along to Brandon the message about working with you. But Brandon's job has really dumped a lot of extra shifts on him due to a lack of waiters at the restaurant. So he's working a bunch of extra shifts and making about 25 bucks an hour on average and that's probably why he can't commit To anything extra right now. I'll call you later today I look forward to catching up with you and I have some more work for you but I know you're super busy right now!

**Danny Holman**: That's good to hear about Brandon glad he's doing good. Good news is I have caught up on all major jobs and schedules are flexible now so if you need just give me a yell.

**Jeff Bergosh**: Will do Danny! Thank you!!

**Danny Holman**: 😁

### CONVERSATION ON 12-31-2021

**Danny Holman**: HAPPY NEW YEAR 🎉

**Jeff Bergosh**: Happy New Year Danny!

**Danny Holman**: 🍸🍹🍺, be safe..

### CONVERSATION ON 01-01-2022

**Jeff Bergosh**: Happy New Year!

