

## CONVERSATIONS WITH GARY HOLT

### CONVERSATION ON 12-10-2019

**Gary holt**: Do you have Jerry Maygardeners number?

**Jeff Bergosh**: Yes who is this?

**Gary holt**: Gary Holt 

**Gary holt**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-25-2019

**Gary holt**: Merry Christmas!

**Jeff Bergosh**: Merry Christmas Gary!  I rode by Los Suenos this morning on my way to Perdido Key

### CONVERSATION ON 12-26-2019

**Gary holt**: Great, the weather  is perfect for a few days off!

I have another really nice subdivision, 25 lots, on the BBC agenda for the January 7th meeting. I will get you more information the 1st of the year.  Thanks, Gary 

### CONVERSATION ON 01-06-2020

**Gary holt**: Hey Jeff, Beulah Garden Estates in on the agenda Tuesday to record the Final plat.  Please look out for it. Thanks 

**Jeff Bergosh**: Already saw it.  Thanks and Happy New Year Gary

### CONVERSATION ON 01-07-2020

**Gary holt**: Thank you Jeff!

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-22-2020

**Gary holt**: Hey Jeff,  Would you have time for lunch next week on  Pine Forest Road? I can show you where to put your sign at our office and we have some checks for your campaign. Gary Holt 

**Jeff Bergosh**: Absolutely and thanks very much Gary!  Monday, Tuesday, and/or Thursday would work well--just let me know what works best for you and thanks!

**Gary holt**: My wife is having some minor surgery Monday. So I guess we better try for Thursday the 30th@ 11:30 Ruby Tuesdays on Pine Forest Road?

**Jeff Bergosh**: Hopefully all goes well with your wife's procedure... and yes, Thursday the 30th works very well.  It's on the calendar and I will see you there.  Thanks Again!!

### CONVERSATION ON 01-30-2020

**Gary holt**: Ruby Tuesdays 11:30 today still good?

**Jeff Bergosh**: Absolutely- looking forward to it Gary!

### CONVERSATION ON 02-05-2020

**Gary holt**: In your meeting last week with Scott and Joy, Did they give any indication about the Untreiner Regional holding pond being permitted?

**Jeff Bergosh**: They didn't because Scott is out and the meeting got rescheduled for this coming Monday--at which point I'll ask them about that pond.   I'll let you know what they say.

**Gary holt**: 10-4, Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-23-2020

**Gary holt**: My real estate partner David Wu said  You can put a sign on his parents property at the corner of Bauer and Sorento. his real  estate sign is there and it looks like Chip just put a sign up there.

**Gary holt**: At the Los Suenos holding pond on Bauer Road might be a good spot?

**Gary holt**: My construction partner Ryan Chaver with Chaver Construction said you can put a sign on his old office property on Detroit Blvd.

**Gary holt**: He and I are Airotide Investments LLC. That was one of the check.$ 

**Jeff Bergosh**: Thank you Gary!!

**Gary holt**: I just talk to Renee Barnes her family own the properties I have listed in Beulah on 9 mile Road. They said they are supporting you no problem putting a sign in front of their house across from the school and the lot next to the fire station. You will see my real estate signs there.

**Jeff Bergosh**: That's Awesome Gary thank you very much I'll plant signs there!!

### CONVERSATION ON 03-02-2020

**Gary holt**: Please let me know when you have time to meet in the next week or two? I have a real  problem with Escambia county Engineering. Thanks

**Jeff Bergosh**: Will do Gary.  Is this about Untrainer pond?

**Gary holt**: No, the Klondike Road project 


**Jeff Bergosh**: Ok I'll call u

**Gary holt**: 10-4

**Gary holt**: Sorry I missed your call. 

Just let me know when we can meet in the Pine Forest area? End of the week or next week is fine. thanks

### CONVERSATION ON 03-04-2020

**Gary holt**: 10800 Lillian Hwy

My friend Bob Marietta, I talked to  Him today he said it was fine to put a sign in front of his house as long as he never sees any pictures  of you with Bernie Sanders!😄

### CONVERSATION ON 03-05-2020

**Jeff Bergosh**: LOL that's great Gary--thanks very much!   And no--he will never see a picture of me and Bernie!   

Thanks very much!

### CONVERSATION ON 04-29-2020

**Gary holt**: Thank you for all the work yesterday. I know it was flustrating  getting everything worked out so we could open the beaches back up.

 Barbara & I are looking forward to Friday!🌞 Thanks again

**Jeff Bergosh**: Thanks Gary!  

### CONVERSATION ON 05-08-2020

**Gary holt**: I have 2 projects ready to go, financing, ECUA permit, contracts signed. All I need are 2 signatures from Engineering.  From the same person on each project. 

I can put 200 people to work next week if signed! Some day soon we are going to need 200 jobs. 

Who is County Engineering protecting? We can not help ourselves!

**Jeff Bergosh**: Who is holding this up?  

**Jeff Bergosh**: Let me know and I'll see what can be done to break the logjam

### CONVERSATION ON 05-18-2020

**Gary holt**: Let me know if you have time to meet in Pine Forest this week for an hour to look at a few things? Thanks, Gary Holt 

### CONVERSATION ON 05-19-2020

**Gary holt**: Is next week better?

**Jeff Bergosh**: Hey Gary-- sorry just have been insanely busy at my day job--down a critical employee who went out on FMLA for 12 weeks and so I'm covering.......  yes, next week works.  Can we say Thursday the 28th at 11:30?

**Gary holt**: Sure, that's fine

**Gary holt**: I have a wealthy  friend that wants to have lunch with us. He hates Underhill and Owens. He wants to donate to your campaign. 

**Jeff Bergosh**: That's fantastic!  Thank you Gary.  I have it on my calendar.  Ruby Tuesday like last time?

**Gary holt**: 10-4

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-21-2020

**Gary holt**: My friend cannot make lunch next week but he wants to mail you a check. What address?

**Jeff Bergosh**: That's fantastic Gary!!  Awesome!!

The Jeff Bergosh Campaign
5905 Forest Ridge Circle
Pensacola, Fl
32526

Thanks very much and have a great Memorial Day Weekend Gary!

### CONVERSATION ON 05-27-2020

**Gary holt**: Please bring me some yard signs tomorrow. 

11:30 Ruby Tuesdays,  Pine Forest Road 

**Jeff Bergosh**: Will Do Gary- thanks!  Will see you there!

### CONVERSATION ON 05-28-2020

**Gary holt**: Jeff, I have so much to show you. Do you mind if we pick up a sandwich at Sonnys and eat in the car on the tour? 

**Gary holt**: Can I pick you up in Sonnys parking lot?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: I'm on way there

**Gary holt**: Great

**Gary holt**: I am parked on left in an Lexus SUV

**Gary holt**: David Wu called the owner and He said it was fine to put a sign there on Wilde Lake 

**Jeff Bergosh**: That's Outstanding News!!! Thank you Gary!!!

**Gary holt**: No problem! Thanks for lunch is enjoy it.

Tom Bizell sent $500 to you on the 26th, so you should get it tomorrow. Let me know if you don't have it by Monday.  He might have got the wrong address.  Thanks

**Jeff Bergosh**: That's fantastic Gary--I just got that check in the mail today!

**Gary holt**: Cool!

### CONVERSATION ON 06-04-2020

**Gary holt**: Jeff, I mailed you that hold harmless agreement from the county website. When you see your legal staff can you ask them about that paragraph 4?

It is shutting us down! Thanks 

**Jeff Bergosh**: Okay I will.  

**Gary holt**: Great

### CONVERSATION ON 06-11-2020

**Jeff Bergosh**: Gary--  I received the document and will be discussing it with Alison Rogers this afternoon.

**Gary holt**: Thank you so much. This is the second property owners attorney that will not let their client sign it.  Paragraph 4 is a problem!

### CONVERSATION ON 06-17-2020

**Jeff Bergosh**: Gary-- here is Alison Rogers' number--so you can speak to her directly about that form.  I spoke with her again this morning she will be expecting your call. 

Jeff Bergosh 

### CONVERSATION ON 06-24-2020

**Gary holt**: I talk to Allison yesterday, she said she would help any way she could. I hope to  have something to her next week. 
Thanks  

I hope everything is going well?

### CONVERSATION ON 07-05-2020

**Gary holt**: My oldest daughter Samantha got married yesterday!❤

**Jeff Bergosh**: Congratulations Gary!

### CONVERSATION ON 08-11-2020

**Gary holt**: I hope everything is going well? I am hearing good things.  Let me know what I can do?

The Timber Company Attorney is finally getting with Alison Purdue this week on the Hold Harmless Agreement for the Klondike Road project. 

Could you please follow up with Alison Thursday or Friday?  Thanks 

**Jeff Bergosh**: Sure will Gary-- glad to hear they is moving forward!  And so far so good on the election-- I'll be glad when it's over in 7 days and I can get back to working!

### CONVERSATION ON 08-19-2020

**Gary holt**: Congratulations!!🎉🌞🎉

When I ran for School Board after the election I slept for 2 day!😄
Take it easy a few day!

**Gary holt**: I can pick up your signs at Jim Bailey middle school this afternoon if you need me to?

**Jeff Bergosh**: Thanks Gary!!!! I just picked them up-- going to get them all picked up today before I leave on a trip to Milwaukee tomorrow.  Thanks for all your help and support!!

**Gary holt**: 10-4, Have a good trip!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-21-2020

**Gary holt**: Alison's office has asked Joy Jones office about the wording of the Release of Liability agreements the land owner behind the Klondike Road project have signed. 

Can we have a big prayer meeting Monday with all parties involved? Thanks,  Gary Holt 

This is all I need for Rosa to sign my stormwater permit. 

**Gary holt**: Would it be beneficial for to get Janice involved?

**Jeff Bergosh**: Gary I'm out of town until Wednesday in Milwaukee and it looks like a hurricane might be coming through so next week is going to be tough

**Jeff Bergosh**: But you know I'm going to try and do whatever I can to help

**Gary holt**: Thanks, I left a message on Joy's cell phone.  I will follow up with her Monday and let you know how it goes.  

### CONVERSATION ON 08-26-2020

**Gary holt**: Joy Jones and Rosa called me this morning. It sounds like they are willing to accept what we have given them. I am going to the Tom Hammonds office right now. It looks like we're going in the right direction. Thank you so much!

**Jeff Bergosh**: No problem.  Do you want me to hold off on pressing Janice further?  Just let me know thanks!

**Gary holt**: Allison just left me a message she talked to engineering it sounds like they have it worked out. So let's see how things shake out next week. Thanks 

**Jeff Bergosh**: Okay got it.  

### CONVERSATION ON 09-11-2020

**Gary holt**: We got the development order for the SweetBarb  Estates the Klondike Road project yesterday. Thanks again for everything! Have a great weekend!🌞

**Jeff Bergosh**: Right on!!  Glad that issue got resolved!

### CONVERSATION ON 10-09-2020

**Gary holt**: Happy Friday!🌞

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-14-2020

**Gary holt**: Jeff,  I have a little 5ac subdivision in Ensley  on the agenda for tomorrow.  Avellanas Estates. If you could watch out for it I would appreciate it. Thanks  Have a Great Day! Gary Holt

**Gary holt**: Avellanas means chestnut in Spanish.  The L's are silent ??

### CONVERSATION ON 10-15-2020

**Gary holt**: Thank you for the help today.  Thanks again for your leadership.  Gary Holt 

**Jeff Bergosh**: Absolutely Gary.  Hope all is well!

### CONVERSATION ON 10-24-2020

**Gary holt**: 🎃🎃🎃

### CONVERSATION ON 10-27-2020

**Gary holt**: Thank God!💓

**Gary holt**: Thank God!💓

**Jeff Bergosh**: Yes!

### CONVERSATION ON 11-05-2020

**Gary holt**: Thank you for letting Chris Curb go. That we improve the attitude at the Engineering Department tremendously! Thanks again!

### CONVERSATION ON 11-26-2020

**Jeff Bergosh**: Happy Thanksgiving!

### CONVERSATION ON 02-06-2021

**Gary holt**: Hey Jeff, I hope you and you family are well. 
As you know I live off Bauer Road. We believe the Bay Bridge will not be available this summer and Perdido Key is not prepared for the influx of our citizen much less more tourist. Please Help! Thanks 

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Hey Gary-  hope all is well.  I think Sorrento Road is an issue as well.  Really do need to get that area upgraded.  

### CONVERSATION ON 03-15-2021

**Gary holt**: Jeff, I think the Beulah plan is a good compromise too. Thanks for your work on it. Gary Holt 

**Jeff Bergosh**: Thanks Gary

### CONVERSATION ON 05-13-2021

**Gary holt**: Jeff, I hope you and your family are well. I don't think I told you. Adams Homes has hired me to consult on their developments. Is there an opportunity for Adams  Homes to develop something residential at the Beulah helicopter  field?

**Jeff Bergosh**: Thanks Gary- congrats on the new consulting job. The residential component of the OLF-8 site has not yet been fully decided.  We will know more after the board receives its final master planning presentation at the end of this month.

**Gary holt**: Great, who would be the contract to make sure we get to bid on it? 

**Jeff Bergosh**: Not sure yet, we're not at that stage yet Gary

**Gary holt**: 10-4, thanks 
Have a Great Day!🌞

### CONVERSATION ON 07-04-2021

**Gary holt**: Happy 4th of July!🇺🇸

### CONVERSATION ON 09-16-2021

**Gary holt**: Jeff, I hope you and your crew are doing good? Would you mind touching base with Horase Jones & Joy Jones about SweetBarb Estates Final Plat on Klondike  Road. I really need to get it on the 1st board  meeting in October's agenda. Thanks, Gary Holt 

### CONVERSATION ON 09-21-2021

**Gary holt**: Jeff, please call me when you get a chance. Thanks 

**Jeff Bergosh**: Okay will do.  In a mtg at the moment will call u after

### CONVERSATION ON 09-27-2021

**Gary holt**: Hoarse came through,  SweetBarb Estates is on the October 14th agenda.  😀😀

**Gary holt**: Horace 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-13-2021

**Gary holt**: Please call me when you get a chance. SweetBarb Estates is on the agenda for next Thursday. Rosa & Keven want the Holding holds ponds completely Dry! It is supposed to rain again Friday night. This has been a terrible summer! I don't know how they can expect Holding ponds to be completely dry!

**Gary holt**: If you get a chance please drive by  them on Klondike road. Thanks 

**Jeff Bergosh**: I will.  Are they designed to be wet ponds or dry ponds Gary?

**Gary holt**: Dry

**Gary holt**: They are dry today and tomorrow but they'll be wet Friday!

### CONVERSATION ON 10-14-2021

**Gary holt**: Jeff, please help me on this one. I promise I will never do another one in Escambia county again! Thanks 

**Jeff Bergosh**: I'll do the best I can Gary-- I agree That they can't hold you to it being dry when it's raining that's an unfair standard to have to meet.

**Gary holt**: 10-4, Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-19-2021

**Gary holt**: Friday pics

**Gary holt**: Dry today

**Gary holt**: NWFWM just told me that the approval letter will be to Horace by noon.

**Gary holt**: Horace has the letter

**Gary holt**: Kevin Blanchard wants 2 things done to the pond and he says he will sign off. We are get them done 

**Jeff Bergosh**: Okay great

**Jeff Bergosh**: I'm calling Horace in 5 minutes if you think this will be helpful

**Gary holt**: Yes, thank you!

### CONVERSATION ON 10-21-2021

**Jeff Bergosh**: Sweet barb just passed unanimously

**Gary holt**: Thank you so much! and I appreciate you and Steven  mentioning how affordable housing works!

Have a Great Day!🌞

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-17-2021

**Gary holt**: Sorry I cannot be at the Innerarity church tomorrow night. I will be out of town a few days. Please let me know if I can help in any way? 

**Jeff Bergosh**: Thanks Gary!  I think several folks will show up tomorrow to give him a piece of their mind

### CONVERSATION ON 11-25-2021

**Jeff Bergosh**: LOL Merry Christmas!!

### CONVERSATION ON 12-06-2021

**Gary holt**: We are so excited about the new redistricting. I loved the article in the paper Sunday! I talk to Tom Dennison last night at Sunset Grill. He loves it too! Thanks for getting that worked out.

**Jeff Bergosh**: Absolutely-- and thanks Gary for the kind words.  

### CONVERSATION ON 12-07-2021

**Gary holt**: Do you think you might have time next week to have lunch with Tom and I at the Sunset Grill to discuss Perdido Key? 

**Jeff Bergosh**: Hey Gary I'll check my calendar call you tomorrow-- would like to do it!

### CONVERSATION ON 12-09-2021

**Jeff Bergosh**: Gary-- I can do Friday the 17th at 11:30?  Does that work?

**Gary holt**: Yes, see you at The Sunset Grill 🌞

Have a Great Day!

**Jeff Bergosh**: Right on.  Have a great Thursday Gary!

### CONVERSATION ON 12-16-2021

**Gary holt**: See you at Sunset Grill tomorrow. 11:30 or 12:00?

**Jeff Bergosh**: 11:30

**Jeff Bergosh**: Look forward to it!

**Gary holt**: 10-4

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-17-2021

**Gary holt**: Thanks for Lunch!

**Gary holt**: Across from 167850 Perdido Key Drive 

**Jeff Bergosh**: Absolutely Gary-- it was great catching up!

### CONVERSATION ON 12-20-2021

**Gary holt**: Did you have any side effects from your booster?

My second shot effect me for about 24 hr.

Barbara & I are scheduled for Thursday. 

**Jeff Bergosh**: Nope-- just a sore arm.  Second one took me out for 24 hours but 3rd one wasn't a problem at all thankfully!  Merry Christmas Gary!

**Gary holt**: Good news! Thanks

**Gary holt**: Merry Christmas to you & your family too!🎄🎊🎁

### CONVERSATION ON 01-08-2022

**Gary holt**: Miranda is getting married today in Destin!💓

