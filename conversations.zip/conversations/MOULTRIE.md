

## CONVERSATIONS WITH MOULTRIE

### CONVERSATION ON 11-12-2020

**Jeff Bergosh**: I'm on the other line I'll call u back

### CONVERSATION ON 02-08-2021

**Jeff Bergosh**: Sure thing Linda!  Hope all is well!

### CONVERSATION ON 08-03-2021

**Jeff Bergosh**: Hi Linda-I'll call you today after I come up for air with all these back to back meetings!  Hope all is well!

