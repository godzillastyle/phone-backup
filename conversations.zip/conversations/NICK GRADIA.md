

## CONVERSATIONS WITH NICK GRADIA

### CONVERSATION ON 11-06-2019

**Jeff Bergosh**: Yes I have thank you Nick.  I’m sick over this.  Prayers for all of the families.  Just a horrible tragedy.  Deepest sympathies to all the men

