

## CONVERSATIONS WITH RHONDA WOOD

### CONVERSATION ON 09-16-2021

**Rhonda Wood**: I understand there is a meeting this morning however, I can't get out my front door. 2 inches of rain. I called after Ida, several people came no one has an answer. The five acres (commercial prop) next to me is flooding me out. Superior Granite/Glass own it. THEIR water is flooding me. School owns acres behind me...they built a ballfield in the back. They burmed up so it wouldn't flood now the 5 acre water can't go that way and it's flooding me. Also Bellview ballpark was paved and they did NOT put a ditch/swale, down the road.
I need immediate assistance I can't wait a year or more for relief. It get worse with every storm. I had  8" yesterday. I can't let my animals out because I have to keep my gate open for water to drain. We cannot use bathrooms (one toilet has overflowed) because septic tank is full. Please   help me.

**Rhonda Wood**: And now it's thundering...more rain on the way. I will definitely get water in my house.

**Rhonda Wood**: Ronda Wood
7030 Nathan Rd
32526
850-712-8237
Thank you

### CONVERSATION ON 09-17-2021

**Rhonda Wood**: Good morning
I have now found out WHO is in charge ballpark land. The school board leases it to the COUNTY. I would like to know who approved the new ballpark in the back, where can I see permits, who approved rearranging the dirt so the ballfield wouldn't flood, who approved the truck loads of dirt to be moved. As I see it the COUNTY is responsible. 
So while I spend my days on 2-4 inches of water and riding. I've had a pump going for days... my septic doesn't work, no bathrooms, I have to keep my gate open for water to flow so I can't let my dogs out, NOW my pool liner is floating...it's only 2 years old. I do not have the funds to replace it. I had to purchase flood insurance which doesn't go into affect for 30 days. ALL OF THESE EXPENSES ARE BECAUSE THE business that owns the five acres next me is not being made to contain their water. Who approved plans for that development???? Can you tell me what their schedule is??

All I need us for a ditch, hole or something to redirect water from dumping MY back yard.

Thank you for your time.

**Jeff Bergosh**: Staff is looking into this matter right now

**Rhonda Wood**: I appreciate that. so for the immediate relief I'm sure county has a tractor that can run all along the 5 acres on ballpark side and flatten out the mounds so the water can maybe drain that way.
There's acres of sand there where they can dig holes for water to go into for now until they come up with solution.
If I thought I could run tractor I would be on it.

**Rhonda Wood**: Can county provide a porta pot... their are several other neighbors can't use bathrooms because septic are back up

**Rhonda Wood**: Oh great now I've been informed UPS or Amazon will not deliver to me because of the water 

**Jeff Bergosh**: I'll have that looked into

**Rhonda Wood**: 9,000 gallons an hour. Its been running 5 hours.

### CONVERSATION ON 09-20-2021

**Rhonda Wood**: Well all I can say is morning... because it's not Good. Can you have your assistant call me. On Friday she said she'd have someone call me and nobody has.
We've now pumped 225,000 gallons of water from my back yard  onto ballpark road. Neighbor is having  to pump water out from under his house down the road from me. The water is NOT stopping coming.
We need county provided pumps. My neighbor has spent over $600 trying to keep water that is not ours moving away.
6 days no bathrooms, renting equipment etc... did I tell you my pool liner is floating. Not covered by insurance. I do not live in flood zone but I had to pay $550 for flood insurance that does not go into affect for 30 days.
This water is draining me financially. Please I beg for help.
Equipment to dig ditches, holes, would help.

**Jeff Bergosh**: Will do

**Rhonda Wood**: One more thing after paying Packer Parkway all they've done is create a parking lot drag strip. I have video and pictures.

### CONVERSATION ON 09-21-2021

**Rhonda Wood**: Just wanted to say THANK you. I appreciate all the returned calls. I thank all their efforts is finding a temp as well as perm solution. The woods draining on me is down to a trickle.

**Jeff Bergosh**: Okay great-- glad to hear this and I'll certainly pass on your appreciation to staff!!👋👋

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: Thx Todd!

**Rhonda Wood**: Well Mr. Bergosh it's been 2 1/2 weeks and I had to return home today because I'm flooded AGAIN. All I asked for was a ditch, hole dug, something to stop the property next to me from flooding me.

