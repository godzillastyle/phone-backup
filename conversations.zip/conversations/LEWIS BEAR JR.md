

## CONVERSATIONS WITH LEWIS BEAR JR

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: I don’t see it on the agenda-

