

## CONVERSATIONS WITH MIKE WEAVER

### CONVERSATION ON 12-17-2019

**Mike Weaver**: Commissioner thanks for not letting this stuff simply move by. 

**Jeff Bergosh**: Absolutely!  Thanks for the kind words!

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: Do you happen to have a moment to talk?

**Mike Weaver**: Most certainly 

### CONVERSATION ON 01-14-2020

**Mike Weaver**: Stay strong Commissioner. I’m sorry your getting bad press from the local mullet wrapper, but glad you can see through to the two who make up their editorial board.

It’s hard to understand why this happens when someone simply wants the truth and seeks fairness. I’ll be praying for you. 

**Jeff Bergosh**: Thanks Mike!

**Jeff Bergosh**: If you’re talking about that editorial on Sunday that was a piece of garbage! I actually sent in a rebuttal and they totally ignored it didn’t even acknowledge it so that’s who I’m  dealing with with a weak media monopoly locally!

**Mike Weaver**: Yes that’s what I’m referring to. I refuse to read their dribble anymore, but a friend told me about it today. Glad to see your not sucked into their game. It’s sad to see freedom of the press turned into this

### CONVERSATION ON 04-02-2020

**Mike Weaver**: Happy Birthday Commissioner. Hope you have a chance to celebrate 

**Jeff Bergosh**: Thank you Mike!!

### CONVERSATION ON 07-11-2020

**Mike Weaver**: Happy Saturday. I apologize for sending on the weekend but a friend just asked me about a conversation he’s been watching on social media to do with station 20.

He related the information and wanted to know my thoughts. Since this is your area I thought I’d share it with you.

An additional option was to relocate two stations that were needing to be rebuilt in the near future, Myrtle Grove and Pleasant Grove.

Part of Myrtle Grove’s historical coverage area is now being covered by Osceola. Pleasant Grove lacks in coverage area due to it being almost up against the fence for NAS.

Just a thought that the GIS analyst in Public Safety was generating maps for.

**Jeff Bergosh**: Thank you for that.  Was the new Myrtle Grove location going to provide coverage for the areas where station 20 previously provided such coverage?

**Mike Weaver**: What we were researching was having both Myrtle Grove and Pleasant Grove absorb parts of the areas. If I remember correctly most could be taken by Myrtle Grove.

### CONVERSATION ON 07-12-2020

**Jeff Bergosh**: Thx

**Mike Weaver**: One final thing, Paradise Beach is not the only area in Escambia County over 10 miles from a fire station.

**Jeff Bergosh**: Yep

**Jeff Bergosh**: They blame me

**Mike Weaver**: I agree. It shouldn’t have  happened. It wasn’t your fault. I’m just disappointed in what I heard and how it was being portrayed. Especially since Jonathan was who got looped in to look for property and I believe that’s where progress ended.

**Jeff Bergosh**: Jack knew there would be a boomerang coming back to hit me in the face when the residents got their ISO ratings after the closure.  He knew that, I didn’t.  I was green.  He should have told me and I would have pushed it  a different way.  He let this happen to me and I blame this on his weakness.  Not happy.

Why do you think he purposely didn’t tell me about these consequences?

Unethical and lacking in integrity

**Jeff Bergosh**: That’s 2 issues now I’m finding where he was purposely deceptive to me specifically for political expediency.

It was not right Mike

**Mike Weaver**: I learned a lot on that end too and was a key element to why I had to leave. I was being left with the consequences of something I was not allowed to make the decisions on. It wasn’t until recently I learned others saw this in Jack. I just thought I was a lone target.

But thinking about this fire station over the last 24 hours I see the same things your stating. I just never would have believed folks could sink this low. 



### CONVERSATION ON 08-18-2020

**Mike Weaver**: Congratulations, well-deserved

### CONVERSATION ON 02-21-2021

**Mike Weaver**: Good afternoon Commissioner, would it be ok to list you as a job reference?

**Jeff Bergosh**: Absolutely Mike good luck

**Jeff Bergosh**: 👍

**Mike Weaver**: Thanks 

**Jeff Bergosh**: 👍absolutely.  Good luck!

### CONVERSATION ON 04-02-2021

**Mike Weaver**: Happy birthday Commissioner, hope you enjoy your day.

### CONVERSATION ON 04-03-2021

**Jeff Bergosh**: Thanks very much Mike!

### CONVERSATION ON 09-15-2021

**Mike Weaver**: So glad to see your positive outlook for Public Safety. Your steadfast work is paying off

**Jeff Bergosh**: Thanks Mike we’re trying hard!

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: ???

**Mike Weaver**: Sorry Commissioner I didn’t realize so many were watching. I got bombarded with texts and just saw yours.  

He absolutely refused to answer the question, if he did it would have illustrated his true motives. 

He truly showed who he is tonight and I’m wanting all to see it.

**Jeff Bergosh**: Mike I understand I get it I’m sure you had a lot of people texting you I’m just glad you went there and ask him the questions that you did because you asked great questions and he had no answer because he’s a fraud and a fake fake

**Mike Weaver**: That he is. Just saying what’s important to the people of the west side, what beaches we went to etc. After 7 years this is the 1st time he’s held a “town hall” and it wasn’t to get our thoughts or opinions. He wanted to use us to get his way.

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: That’s why it was a total flop

**Mike Weaver**: I can truly say the map the 4 of you are presenting is the best option for those of us on the Westside.

Our commissioner’s vote will count the same as the commissioner representing the interests of Beulah and Perdido Key.

Currently my Commissioner is only concerned with Perdido Key. That’s why all of his D2 Facebook posts after Sally were the needs of PK.  Kind of like if he’s so concerned about the minorities, why are all of his town halls at predominantly white churches 


### CONVERSATION ON 11-17-2021

**Jeff Bergosh**: Nice comment!!  A scorcher!!

**Mike Weaver**: Ugh he’s such a clown. His having that seat another year is a year too long.

