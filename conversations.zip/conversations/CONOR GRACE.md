

## CONVERSATIONS WITH CONOR GRACE

### CONVERSATION ON 04-14-2020

**Jeff Bergosh**: Hey Conor Mike NMCI machine is down so I believe that was canceled I believe

**Jeff Bergosh**: But I’m available to do one over the phone if you’d like

**Jeff Bergosh**: Will do

### CONVERSATION ON 11-05-2020

**Jeff Bergosh**: Sure will.

### CONVERSATION ON 04-29-2021

**Jeff Bergosh**: Good morning Conor I wanted to double back with you about the drawings and the search functionality do you have a minute for a call?

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-03-2021

**Jeff Bergosh**: Hey Conor are we a go for today?

**Jeff Bergosh**: I am too can’t hear me?

**Jeff Bergosh**: I’ll try again

