

## CONVERSATIONS WITH FRED HEMMER

### CONVERSATION ON 12-05-2019

**Fred Hemmer**: Watching the Navy Fed discussion was painful. I felt your embarrassment and thought you contained your frustrations well. 

**Jeff Bergosh**: Embarrassing and ridiculous. If we’re not going to ask for changes to the contract what was the point of making them jump through hoops of fire and wait a week? It was absolutely ridiculous we had the back up we knew what was in the agreement and we just ran those guys ragged and made them sit through a long meeting for no good reason.  extremely embarrassed is how I feel at the moment.  Thanks for tuning in for the agony of it LOL

**Fred Hemmer**: I am glad you stuck up for them. They should have been treated better. 

**Jeff Bergosh**: I agree!  Thanks FRED!

### CONVERSATION ON 04-07-2020

**Fred Hemmer**: Hi Jeff, just wanted to confirm that the lift station lawsuit with Twin Spires has been fully settled and the suit terminated.                                                          Thank you for your service during this trying time.  Take care. 

**Jeff Bergosh**: Thanks for the heads up and congrats

**Fred Hemmer**: 👍

### CONVERSATION ON 04-28-2020

**Fred Hemmer**: I thought the meeting went very well today. Good to see everyone discuss their thoughts and  work on a well thought out decision. Thank you.

**Jeff Bergosh**: Thanks!

### CONVERSATION ON 08-18-2020

**Fred Hemmer**: Congratulations, Jeff. 

**Jeff Bergosh**: Thx FRED!

**Fred Hemmer**: 👍

### CONVERSATION ON 10-03-2020

**Fred Hemmer**: Thank you for fighting for the gated communities debris pick-up. As you say, they are tax payers too. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-08-2020

**Fred Hemmer**: Thank you for bringing up the panhandling issue. Living downtown I see it all the time and you are exactly right, there are confrontations at times. Let’s try to help these people so they don’t have to do this. 

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: Lots of need out there

**Fred Hemmer**: I agree. We need both enforcement of ordinances and treatment for them. Again, thank you for bringing it up. 

### CONVERSATION ON 12-18-2020

**Fred Hemmer**: Good morning, Jeff. Do you have time to talk today? Or I would come to your office if you are available. I would like to talk to you about some OLF8 thoughts which I would like to keep private for now. I am contacting you since it is your district and I am also going to talk to Bender since he is Chairman.

**Jeff Bergosh**: I’ll give u a call on my lunch break

**Fred Hemmer**: 👍

### CONVERSATION ON 12-21-2020

**Fred Hemmer**: I was just reading through the Men Who Cook recipe book that I bought from John Peacock over the weekend. My wife and I think your dessert sounds great and we will have to try making it. Chambord also goes well in Champaign. But thank you for supporting the group. We were impressed with what Peacock told us about what the cause was for and we were glad to support it. 

**Jeff Bergosh**: That’s a great organization and they really step up to help young people in the community that’s why I support them.  Really great people!

**Fred Hemmer**: We just ordered three more books. Thank you for helping them out. 

**Jeff Bergosh**: Thank you Fred!!

### CONVERSATION ON 01-23-2021

**Fred Hemmer**: Call me at your convenience. It is about OLF8. 

### CONVERSATION ON 01-26-2021

**Fred Hemmer**: Do you have time for a quick call?

**Jeff Bergosh**: In mtg will call u back

**Fred Hemmer**: 👍

**Fred Hemmer**: I posted this on ECW.

**Fred Hemmer**: Fred Hemmer <https://www.facebook.com/groups/446794355356335/user/1539280132/?__cft__%5B0%5D=AZX8_D4nd8u1rkFxZ124ESbiQ0ej8pivSExlKRa21cKd6me9M8fgqB2PylMCL3_px2VQDeDB6OP0-Bv7T25AyEIt-CnemsrlLs0E0NNirl0_LVHSHhCXs1Pj3YKPDGo2kOsP1yS51xoCIhgmwvBlpuye3XEpSa8f4BtEOnyKLg9rkdkOHWbIQLxBApD0MGbjE-g&__tn__=R%5D-R>
 <https://www.facebook.com/groups/446794355356335/user/1539280132/?__cft__%5B0%5D=AZX8_D4nd8u1rkFxZ124ESbiQ0ej8pivSExlKRa21cKd6me9M8fgqB2PylMCL3_px2VQDeDB6OP0-Bv7T25AyEIt-CnemsrlLs0E0NNirl0_LVHSHhCXs1Pj3YKPDGo2kOsP1yS51xoCIhgmwvBlpuye3XEpSa8f4BtEOnyKLg9rkdkOHWbIQLxBApD0MGbjE-g&__tn__=R%5D-R>I am the individual that called Commissioner Bergosh on Saturday and now that our offer has been made public I want to make sure it is clear the Jeff did not negotiate anything with me. My call to him was simply a courtesy since he is the commissioner in the area and I have long done that with him when I had issues in his district. And our offer includes executing what the BCC and DPZ decides and not a plan that we are proposing. I look forward to having open discussions to figure out a plan that works in the best interest of the county.

**Jeff Bergosh**: Thanks for setting the record straight on that site Fred!

**Fred Hemmer**: It is hard enough to get things done when you are dealing with facts. It is so much harder when you are dealing with inaccuracies. You know that well! I just hope we have a platform to have a healthy discussion to deal with this. I would love to help steer the OLF8 project but just as important is to see the county get in a better financial position. My group is the largest owner of residentially zoned property (I think) in Cantonment and we have more than 20 years before our projects are completed so we have a strong interest in helping the county to better secure its financial position.  And I totally agree with the balance between short term cash, long term jobs, and quality of life. 

At my age I am not interested in a fight. I want to be a mediator and try do what is right for all concerned. 

Again, I appreciate your responsiveness and willing to engage in the discussion. 

Have a good evening. 

**Jeff Bergosh**: Thank you Fred

### CONVERSATION ON 02-10-2021

**Fred Hemmer**: I saw your post about the homeless. Three years ago  on Christmas Eve my wife and I bought dozens of sandwiches and drove around Pensacola trying to hand them out. Half the people refused them. I decided my contributions are best directly to the shelters themselves. 

**Jeff Bergosh**: That’s interesting Fred. I would always think of a guy who is homeless would at least want a bottle water and something to eat from a can.  But maybe it’s all about money drugs and booze I hate to be that cynical but for a lot of them that appears to be what it is

**Fred Hemmer**: It is frustrating when you think you are trying to help but in fact we may be hurting them long term. 

### CONVERSATION ON 06-03-2021

**Fred Hemmer**: I appreciate the difficult position you were in tonight and I totally agree with you being careful to get a strong legal position. Either way, best to be very careful in situations like this.

### CONVERSATION ON 06-04-2021

**Jeff Bergosh**: Thx

### CONVERSATION ON 08-05-2021

**Fred Hemmer**: Congrats on getting the OLF8 proposal passed. I thought you showed great patience with the Frank Reeder lady and as a result you got her to understand the diff between zoning and land use. You diffused it well. 

**Jeff Bergosh**: Thanks Fred

### CONVERSATION ON 12-08-2021

**Fred Hemmer**: Hi Jeff, I would like to talk to you about the bill in Tallahassee where you may have to run again next year. Please call me at your convenience. 

**Fred Hemmer**: I will Call back in two

