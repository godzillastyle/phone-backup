

## CONVERSATIONS WITH CHRIS JENSEN

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: Thank you Chris!!!

### CONVERSATION ON 07-08-2021

**Jeff Bergosh**: Hi Chris— I’m in a BCC meeting I’ll call you back

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: Absolutely Meredith— thank you

