

## CONVERSATIONS WITH WARREN KIRKLAND

### CONVERSATION ON 11-08-2019

**Jeff Bergosh**: Hey guys—We won’t be having our 7:30 meeting this morning; I’ll be coming in a little late this morning and I will get with you both individually once I get there.

**Warren Kirkland**: Ok Thanks 

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: All there is an active shooter on the base right now this is not a drill. If you were at building 458 Ira Miller is on scene he is locking down the building. If you have not made it to the base yet do not come to the base. I repeat do not come to the base. This is not a drill there is an active shooter and the base is locked down and you will not be able to get here call me if you have any questions

**Warren Kirkland**: Got it covered 

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: Warren—I don’t see an email extending the soundproofing job?  Did you get approval for this extension?

### CONVERSATION ON 09-15-2020

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-16-2020

**Warren Kirkland**:  House is ok we have trees down around the yard and no power other than a generator. Have not been out there was a coast guard helicopter flying near the creek on nine mile. Bristol creek is flooded again 

**Warren Kirkland**: Let me know on additional updates. Be safe 

**Jeff Bergosh**: OK thanks for the update Warren that’s about the same as my house I don’t think we’re going to work tomorrow but I’m gonna verify with Tony

**Warren Kirkland**: Base safety has to clear the facilities before letting personnel back into the buildings. Roof could. Be gone on 458. This storm was terrible as a rain event

**Jeff Bergosh**: Who did u hear that from Warren?

### CONVERSATION ON 09-17-2020

**Warren Kirkland**: Thanks Jeff 

### CONVERSATION ON 10-02-2020

**Warren Kirkland**: Jeff I have to leave for the day. Back fence got tore up by tree removal company. Have to seal up the opening. Will submit electronic and paper time sheet. Time out to be 1:00. Call me if you need to

**Jeff Bergosh**: Alright no problem

### CONVERSATION ON 11-04-2020

**Jeff Bergosh**: Warren we will not be having our 7:30 AM meeting I’ll be coming in at 8 o’clock this morning please let Gary and Jon know as well no 730

**Warren Kirkland**: Will do

### CONVERSATION ON 11-19-2020

**Jeff Bergosh**: Warren— I need you to email me the binder for your job you just turned in.  I can’t access it via the shared drive

### CONVERSATION ON 12-02-2020

**Jeff Bergosh**: All-  we will not be having our 0730 meeting this morning--I'll be coming into the office a little later and I will get with you all individually

Jeff

**Warren Kirkland**:  Ok 

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: Hey Warren I’m just checking in on you to see how you’re doing and how you’re feeling. I also need to know if you took a COVID-19 test. Just let me know, because if so there’s certain paperwork and protocols I have to follow. So please just text me back and let me know one way or the other. I hope you’re feeling better

**Warren Kirkland**: I had the covid test this morning and awaiting the result. Feel drained

**Jeff Bergosh**: Okay I hope you’re feeling better and that you’re negative. here’s the thing though: Once you’ve taken a COVID test—-you have to remain out until you get a negative test result back—-or longer if you’re positive.  So unless you get a negative result back today—- DON’T come in to work tomorrow.  You won’t have to take PTO for tomorrow or Friday— we added a separate line on your timesheet to account for absence due to COVID.  Let me know you’ve received this and understand.  Thanks Warren.

**Warren Kirkland**:   Thanks for your concern hope I don't have this. I understand your message about not coming in unless the test comes back negative 

**Jeff Bergosh**: Okay now get well soon!  We’ve got John on your project so don’t worry about anything other than getting well soon.

**Warren Kirkland**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-18-2020

**Warren Kirkland**: Good morning Jeff I still have not gotten test results. Just checking in with you. Will call when I get the call. Thanks and have a good day 

**Jeff Bergosh**: Thanks Warren.  Are you feeling any better?

**Warren Kirkland**: Belly queasy but feeling better then the other day 

**Jeff Bergosh**: I’m glad to hear that Warren!  Hey, can you do me a favor and go ahead and complete your timesheet for this week as quickly as possible?  Remember to NOT use your PTO for these days you’re out waiting in the test result but rather use the new line that’s been added (Cares Act Leave).  Thanks Warren!

**Warren Kirkland**: Sure 

**Jeff Bergosh**: Thanks!

**Warren Kirkland**: Test returned negative. Do I come in on Monday morning

**Jeff Bergosh**: Yes if you’re feeling better.  I’m really happy to hear that Warren!!

**Warren Kirkland**: Do I need the test results for confirmation 

**Jeff Bergosh**: Yes please bring a copy and give it to Jaron.  I’ll be out on PTO—but I’ll file it when I get back.

**Warren Kirkland**: Sure thing 

### CONVERSATION ON 12-31-2020

**Jeff Bergosh**: Hey Warren— can you please fill out your time sheet on the electronic site so that I can approve it thanks and happy new year

**Warren Kirkland**: Timesheet Done

**Jeff Bergosh**: Thx Warren

### CONVERSATION ON 01-04-2021

**Jeff Bergosh**: Hey Warren— you put PTO for the one day timesheet for 1/1/21—but it should have been HOL as New Year’s Day is a Holiday.  Please correct it and resubmit.  Thanks!

Jeff

**Warren Kirkland**: Done it this morning. Got locked out last week

**Jeff Bergosh**: I see that— but don’t use PTO though, it was a Holiday so use HOL and save 8 hrs PTO and I’ll approve it.  Thanks!

**Warren Kirkland**: Sorry my bad

**Jeff Bergosh**: No worries!

**Warren Kirkland**: I am at Corey station right now will get it corrected when I get back 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-08-2021

**Warren Kirkland**: Timesheet done

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Have a good weekend

**Warren Kirkland**: Thanks 

**Warren Kirkland**: You too

### CONVERSATION ON 02-10-2021

**Warren Kirkland**: Good morning Jeff. I will be on site visit with Smitty at 07:30. Will get with you later. My sheet is in your drop box

**Jeff Bergosh**: Okay

### CONVERSATION ON 02-22-2021

**Warren Kirkland**: Good morning Jeff. Just wanted to remind you of my dr.  Visit today. Will be in later this morning

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Warren Kirkland**: Ok thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-12-2021

**Jeff Bergosh**: Warren/Dave— I need for you to submit your electronic timesheets please.

Thanks 

**Warren Kirkland**: Sorry to hear. That. Should come home

**Warren Kirkland**: Wrong message sorry

**Jeff Bergosh**: 👍

**Warren Kirkland**: Thanks 

### CONVERSATION ON 05-21-2021

**Warren Kirkland**: Jeff I am about to complete this work order for turn in. Do you mind if I leave for the day

**Jeff Bergosh**: No problem

**Jeff Bergosh**: Need u to submit your electronic timesheet

### CONVERSATION ON 06-17-2021

**Warren Kirkland**: Sounds good. 😁🤐

### CONVERSATION ON 07-01-2021

**Jeff Bergosh**: All--please go ahead and enter your time electronically in the online time sheet. Please do this through June 30 and if you could do it right away that would be greatly appreciated. Huntsville is trying to do the end of month labor report and we need all the hours in through the 30th.  Thanks,

Jeff

**Warren Kirkland**:  Will do

### CONVERSATION ON 08-20-2021

**Warren Kirkland**: I have to leave for the day. Got online time sheet completed 

**Jeff Bergosh**: Okay thanks!

### CONVERSATION ON 09-09-2021

**Warren Kirkland**: Jeff I need to flex time tomorrow. I plan to be in your and start at 5:30. You ok with this

**Jeff Bergosh**: Of course

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: In mtg.  Is everything okay?

**Warren Kirkland**: All is ok. Didn't know who was calling. Expecting call from doctors office 

**Jeff Bergosh**: Oh, okay.  I had called you earlier this morning

### CONVERSATION ON 09-20-2021

**Warren Kirkland**: Jeff I am going home for today. Back hurts can't sit

**Jeff Bergosh**: Okay

### CONVERSATION ON 10-06-2021

**Warren Kirkland**: Jeff can you call me when you have time. Would like to take Friday off if you don't mind. Have only two work orders at this point

### CONVERSATION ON 11-12-2021

**Warren Kirkland**: Jeff I attempted to complete online timesheet. Internet is down here I will try again later

**Jeff Bergosh**: Okay thanks Warren

### CONVERSATION ON 11-15-2021

**Jeff Bergosh**: Hey Warren-  shoot me a text or email or call to let me know what your status is.  No rush— just want to know how you’re doing and how your recovery is going

Thanks

Jeff

**Warren Kirkland**: Postoperative doctor visit today at 3:00. Should get back to
Work tomorrow I hope. Tired of being off like this

**Jeff Bergosh**: Right on thx for update hope the visit goes well Warren!

**Warren Kirkland**: Thanks 

### CONVERSATION ON 12-01-2021

**Warren Kirkland**: Jeff I just got a reminder for doctor visit tomorrow morning  will be back

**Jeff Bergosh**: Okay. Thx for heads up

**Warren Kirkland**: Will be leaving at 8:15. Will see Jaron in the morning before I leave and return

**Jeff Bergosh**: Right on.  I’ll be here too  until 8:30 so no big deal

### CONVERSATION ON 12-15-2021

**Jeff Bergosh**: I'll get with you individually

**Warren Kirkland**: Back gate is closed

### CONVERSATION ON 01-14-2022

**Jeff Bergosh**: Warren give me a call 

Jeff

### CONVERSATION ON 01-17-2022

**Warren Kirkland**: Jeff. I will be at work in the morning taking care of this issue. See you tomorrow

**Jeff Bergosh**: Warren you don’t have to do that I can take care of it

**Warren Kirkland**: I can't do that. Feeling bad last couple of
Weeks. Blood sugar too high lately got me down

**Jeff Bergosh**: Only if you want to Warren.  I don’t want to wreck your day off.  If you want to and are able that’s fine.  I’ll be in early then I’ll be out till lunchtime.  My meeting with Conor and the SHOPS is at 1:00

**Warren Kirkland**: I will start on it when I get there and ask Gary for some assistance 

**Jeff Bergosh**: Thanks very much Warren!

