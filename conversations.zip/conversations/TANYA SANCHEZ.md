

## CONVERSATIONS WITH TANYA SANCHEZ

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: We’re all good thank you Tanya unfortunately though a lot of guys got shot so keep them in your prayers please

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: Thank you Tanya!

