

## CONVERSATIONS WITH GENE VALENTINO

### CONVERSATION ON 02-05-2020

**Jeff Bergosh**: Good morning Gene—-I thought this might be of interest to you:

Got my most recent poll results back from Gravis.  among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race against Greg Marcile:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)


**Jeff Bergosh**: 👍

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: Please pass along to the residents that I am committed to helping solve that issue at innerarity 

### CONVERSATION ON 05-26-2020

**Jeff Bergosh**: 👍yes it is!  Thanks Gene!

