

## CONVERSATIONS WITH MARCUS MICHLES

### CONVERSATION ON 01-30-2020

**Jeff Bergosh**: Good morning Marcus hope all is well. I’m looking to order some signs ——large ones and yard signs —-and I’m wondering if Ryan Maxwell is still working with you and making signs?  Thanks!

Jeff Bergosh

**Jeff Bergosh**: Hi Marcus!  Sorry to hear Ryan is not doing the signs anymore—I hope all is well with him.  I actually have 3 opponents this time around so it will definitely be a battle for the ages!  If you are willing to help financially I’d greatly appreciate that Marcus!  

### CONVERSATION ON 04-21-2020

**Jeff Bergosh**: What are your thoughts on opening the beach Marcus?  Should we do it May 1st or would you recommend holding off?

**Jeff Bergosh**: Thank you Marcus

### CONVERSATION ON 06-30-2021

**Jeff Bergosh**: His name is Ira Miller

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-07-2021

**Jeff Bergosh**: Marcus— great catching up!  Thanks for your help!

