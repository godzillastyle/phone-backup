

## CONVERSATIONS WITH CHRISTINA PUSHAW

### CONVERSATION ON 08-26-2021

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Hi Christina— I just tried to call you.  I’d love to chat with you about that guy—-I have a long history with him and he’s a sack of garbage.  

If ever there was a guy who needed to have his wings clipped— it’s that guy!

Jeff Bergosh

