

## CONVERSATIONS WITH ROB CHELICO

### CONVERSATION ON 01-15-2021

**Jeff Bergosh**: In a mtg will call u back

### CONVERSATION ON 03-11-2021

**Jeff Bergosh**: Rob I intend to support increasing the rates for you all

