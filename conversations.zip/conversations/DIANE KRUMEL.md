

## CONVERSATIONS WITH DIANE KRUMEL

### CONVERSATION ON 12-03-2019

**Diane Krumel**: Good morning Jeff, Can you call me ASAP this morning to discuss the toll issue on the beach?? Very important that we talk. Ty Dianne

**Jeff Bergosh**: I’ll call after my morning meetings.

**Diane Krumel**: Great. Ty

### CONVERSATION ON 02-20-2020

**Diane Krumel**: Great job today. 👏👏

**Jeff Bergosh**: Thank you!

**Diane Krumel**: 🤗🤗Can’t wait fir the ribbon cutting celebration to open public beach access 🏖 

**Jeff Bergosh**: Me neither!  It’s going to be great!  Thanks for showing up today with the team!

**Diane Krumel**: Happy to be part of this victory for the people and proud of your leadership in this battle.  You are a hero and people will remember that 🤗🤗🏖💪

**Jeff Bergosh**: You are too kind Diane!!  Thank you!!

### CONVERSATION ON 02-22-2020

**Diane Krumel**: So where were you??) 🤣🤣go Jeff!!! 

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Ha ha Diane I was there—I was probably behind the truck somewhere

**Diane Krumel**: 🤗glad to see you out there!!! 

**Jeff Bergosh**: Thanks Diane!!

### CONVERSATION ON 03-20-2020

**Diane Krumel**: Check out this article from Pensacola News Journal:

Navarre Beach to close starting at midnight; all Santa Rosa restaurants to go pick-up only

**Diane Krumel**: https://www.pnj.com/story/news/2020/03/20/navarre-beach-close-midnight-santa-rosa-county-restaurants-go-pick-up-only/2883409001/

**Diane Krumel**: You kick ass. Thank you. Close the beach temporarily 

**Jeff Bergosh**: Thx

**Diane Krumel**: 🤗🤗

### CONVERSATION ON 03-27-2020

**Diane Krumel**: You still pushing to open beaches 😡😡😡

**Diane Krumel**: https://www.tallahassee.com/story/news/local/state/2020/03/27/coronavirus-florida-caseload-soars-officials-struggle-accuracy/2924114001/

### CONVERSATION ON 04-01-2020

**Diane Krumel**: Please, if possible start Skyping meetings tomorrow night. It's just not worth the risk of you and our commissioners and staff to jeopardize your health and safety or the safety of their families in the face of these unprecedented times. We cannot afford to put any of our elected officials as well as others at needless risk when a meeting can be Skyped from the comfort and safety of their homes.
Be safe and thank you, 
Dianne Krumel

**Jeff Bergosh**: Diane I think this is a great idea but I would use zoom it’s a much better program I’ll see if we can get it done stay safe meanwhile we will meet tomorrow but after that perhaps maybe we can do these all virtually

**Diane Krumel**: Use zoom whatever works. But please start tomorrow. We need you and the other commissioners and staff  to be safe and your families, too. We need leaders like you to lead!! 
Dianne

**Jeff Bergosh**: Thanks Diane!

### CONVERSATION ON 04-02-2020

**Diane Krumel**: Good job. My speech I submitted tonight thanks you. Hope it is read.

**Jeff Bergosh**: Thx

**Diane Krumel**: 👏👏you did good job on your opening remarks. Thank you !!!! 

**Jeff Bergosh**: Thx

**Diane Krumel**: Go Jeff. 

**Diane Krumel**: Until further action by BCC - thank you 

**Diane Krumel**: Throw down time. 

**Diane Krumel**: You got this. Thank you. 

**Diane Krumel**: Way to go!!! 

### CONVERSATION ON 04-11-2020

**Diane Krumel**: Good job 🔨🔨 on getting coronavirus reports released 👏👏👏

### CONVERSATION ON 04-12-2020

**Jeff Bergosh**: Thanks Diane!  Glad the staff walked back their bad decision to withhold the report

**Diane Krumel**: All thanks to you 👏👏👏

**Jeff Bergosh**: Thanks Diane.  Funny that some in the media won’t acknowledge what you correctly point out to be factual.  I called for the special meeting Friday morning at 5:30 AM in a blog post. I got in front of the camera Friday evening at the 6 o’clock news demanding the report be released. Now suddenly others in the media claim credit that’s fine they can have the credit I’m just glad the report is once again public. And if I’m being very honest had I not publicly asked for it on the 6 o’clock news and demanded a special meeting I don’t believe the decision would’ve been made

**Diane Krumel**: Liked “Thanks Diane.  Funny that some in the media won’t acknowledge what you correctly point out to be factual.  I called for the special meeting Friday morning at 5:30 AM in a blog post. I got in front of the camera Friday evening at the 6 o’clock news demanding the report be released. Now suddenly others in the media claim credit that’s fine they can have the credit I’m just glad the report is once again public. And if I’m being very honest had I not publicly asked for it on the 6 o’clock news and demanded a special meeting I don’t believe the decision would’ve been made”

**Diane Krumel**: I  couldn’t agree with you more!!! YOU did this !!! YOU and you alone. 

**Diane Krumel**: The community owes you big time. You took the “risk” and rattled a bunch of cages. You exposed it. 
Thank you is the least I can say. Real leaders lead !!! 

**Jeff Bergosh**: Thanks Diane.  I only wish the media could be honest.  But they can’t help themselves I guess.  Anyhow—I appreciate you Diane.  I hope you and your family have a wonderful Easter Sunday🙂

**Diane Krumel**: Stay safe and enjoy the day. 
You are my hero. And a hero to the rest of the community - unfortunately many just don’t know it. 

**Jeff Bergosh**: You are too kind!

### CONVERSATION ON 04-22-2020

**Diane Krumel**: Hey Jeff. Please give me a call when you have a minute. Ty. Dianne Krumel 

**Jeff Bergosh**: Conference call will call u after

**Diane Krumel**: 👍ty

### CONVERSATION ON 04-28-2020

**Diane Krumel**: Larry Downs holding on to podium. Idiot 

**Diane Krumel**: If you care about citizens go by the facts and data to prove it is safe. Where is that data? Real peoples lives at stake. Suffering. If data shows reopen then so be it. 

**Diane Krumel**: Who are these experts. Hospitals losing $ because not doing elective surgery. Who wouldn’t want to open beaches. Opinion doesn’t matter. Facts matter 

**Diane Krumel**: The curve not bending. See front page PNJ 

**Diane Krumel**: Just wait a little longer to see what Covid test reveal. We need more testing that doesn’t require prescreening. Only testing with (exception of recent testing that doesn’t have to be prescreened) those that have symptoms 

**Diane Krumel**: Leadership decisions based on what data?? 

**Diane Krumel**: How can this be when we have the largest outbreak of Covid in state in our nursing home? Need more testing. 

**Diane Krumel**: Doing target testing?? We don’t know general population Covid results. 

**Diane Krumel**: Open at same time as other counties to spread out Covid spread. Really??? That’s what other panhandle counties said so no one county gets overwhelmed. We are # 4 beach in world. They will come here, not other counties so much and bring Covid and take Covid back to there home states. 

**Diane Krumel**: People go out to the beach to party and have fun. That’s why they go to beach 

**Diane Krumel**: Breaking news 

Escambia, Santa Rosa coronavirus cases top 600 on Tuesday

**Diane Krumel**: https://www.pnj.com/story/news/2020/04/28/coronavirus-escambia-santa-rosa-covid-19-cases-top-600-tuesday/3040041001/

**Diane Krumel**: Less than 2% tested in Escambia County 

**Diane Krumel**: So where is Dr Lanza now?  What does he say 

**Diane Krumel**: So why didn’t you wait until Governor statement before having meeting. What are his guidelines 

**Diane Krumel**: Our community is different from other communities. We are one of the most popular beaches in the US. Base decision to reopen on facts for our area , not what other areas are doing. Look at the numbers. Test, test test. 

**Diane Krumel**: Don't forget the large number of military we have. Sources have told me the beach trolley from the base is usually standing room only.

**Diane Krumel**: Not everyone abides by restrictions 

**Diane Krumel**: Beach is goose that lays golden egg. That’s why people come here. #4 most popular beach. Morgan right. How to enforce and keep down spread of Covid 

**Diane Krumel**: We hope people follow restrictions and we hope Covid doesn’t kill people. 

**Diane Krumel**: The governor would approve reopening 😡😡😡what is Lanza opinion 

### CONVERSATION ON 07-01-2020

**Jeff Bergosh**: Hi Diane I’m in a meeting can I call u back?

**Diane Krumel**: Yes. Please. You can be the hero for our county and the people. 

**Diane Krumel**: Look at these stats. It is bad. Dated today. Wearing mask will save lives and save our economy too. It’s always the bottom line:  $$ before lives. But need to appeal to $$$ in hopes that people will wear mask. Whatever it takes. Please put this on the agenda. Show this slide. Dianne.

### CONVERSATION ON 07-02-2020

**Diane Krumel**: Updated today

### CONVERSATION ON 07-30-2020

**Diane Krumel**: Good job👏👏👏 

**Jeff Bergosh**: Thank you Diane!

**Diane Krumel**: That last guy 😱😱😱🤣🤣🤣

**Jeff Bergosh**: LOL

**Diane Krumel**: Jonathan . 🤣🤣🤣

**Diane Krumel**: Duh

### CONVERSATION ON 12-12-2020

**Diane Krumel**: Hey Jeff,
Thank you for stepping aside to allow Lumon to serve on The Children’s Council. You are a man of integrity and I appreciate you. 
🤗Dianne 

### CONVERSATION ON 05-07-2021

**Diane Krumel**: Hey Jeff,
Dianne Krumel here. Thanks again for taking a stand on demanding that beach access 4 be opened! Hammer 🔨 down!!! We couldn’t have done it without you!!!! 
What can we do to speed things up and get that additional funding necessary? 
🤗🤗Dianne 

### CONVERSATION ON 06-03-2021

**Jeff Bergosh**: I'm in a meeting I'll call u back

**Diane Krumel**: Hey Jeff. 
Time for Janice to go. I am In Alaska on vacation. I told everyone not to contact me until I return June 10th but this is soooo important. It is past time for Janice Gilley to go for so many reasons. There are many people I know who believe it is time for her to be let go. 
Thank you for doing the right thing. This is best for our county!!
Dianne Krumel

**Jeff Bergosh**: Thx Dianne!  Have a safe trip

**Diane Krumel**: 🤗 and get rid of Janice

