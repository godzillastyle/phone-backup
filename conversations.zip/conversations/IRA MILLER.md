

## CONVERSATIONS WITH IRA MILLER

### CONVERSATION ON 12-06-2019

**Ira Miller**: All. The shooter is located in the vicinity of Bldg. 633. There is a large-scale response by various law enforcement agencies. We will keep you informed as more information is available.

**Ira Miller**: I did it.

**Ira Miller**: We are good to go on that front.

**Ira Miller**: From EMT on the scene: 15 wounded. 5 dead including the shooter. One died on the table at Baptist and one was found in another building after fleeing the initial scene. SFs are conducting another sweep of the API Building, and surrounding structures now.

**Ira Miller**: Per the Giant Voice and Mass Notification System; we are still confined to the facility and under Active Shooter protocols.

**Ira Miller**: According to Mass Notification we are still on lockdown as of two minutes ago.

**Ira Miller**: I know there are some reports that the Active shooter has been lifted, but that has not been confirmed through official channels to us.

**Ira Miller**: We don't know. As soon as it is I will let everyone know. DoD has strict protocols and procedures on these types of situations. I have been told that ECSO will be conducting a news conference at 0930. I don't know if any NASP personnel will be involved in that briefing. Again, I will reach out via this thread as more information becomes available.

**Ira Miller**: Per the latest advisory. We are under Shelter-In-Place protocols. The base is still locked down.

### CONVERSATION ON 01-27-2020

**Ira Miller**: I am sick and not coming in today. I will call  later to speak with you.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I’ll call u back

### CONVERSATION ON 02-27-2020

**Ira Miller**: I won’t be in today. I’m not sure about tomorrow yet. Should know more by this afternoon. Thanks for the understanding.

**Jeff Bergosh**: Okay thx for the heads up

### CONVERSATION ON 04-03-2020

**Jeff Bergosh**: Ira, need you to submit your online timesheet.  It is saved but not submitted.  Thanks,

Jeff

**Ira Miller**: Sorry Jeff. I forgot there was two for the week. I just submitted the one I missed. Still waiting on the letter from the doctor. It is supposed to be ready by COB today.

**Jeff Bergosh**: Thanks Ira!

### CONVERSATION ON 05-31-2020

**Jeff Bergosh**: Hey Ira-

I’m going to be a little late tomorrow morning coming in.  Can you please send an email to the group when you come in tomorrow morning, letting them know that our weekly staff meeting will be at 8:45 instead of 7:30?

Thanks very much!

Jeff B

**Ira Miller**: Sure thing. I’ll handle it.

**Jeff Bergosh**: Thanks Ira!

### CONVERSATION ON 06-23-2020

**Jeff Bergosh**: Ira:  I’ve been trying to call Pedro but his phone is busy.  Been trying to let him know my computer is in your cubicle.  Can you please email him and let him know this?

**Ira Miller**: I will. Oddly, I can’t seem to dial out either.

**Jeff Bergosh**: Thx

**Ira Miller**: He won’t need it today.

**Jeff Bergosh**: 👌

### CONVERSATION ON 09-02-2020

**Ira Miller**: Jeff; I won’t be in today. My blood sugar bottomed out last night and I am just exhausted. I’ll call later to make it official, I just need some sleep.

**Jeff Bergosh**: Okay hope you’re feeling better

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: Hey Ira just checking in....R u okay?

### CONVERSATION ON 09-15-2020

**Ira Miller**: Hey Jeff; what’s the word on tomorrow? Are we out of the office or business as usual?

**Jeff Bergosh**: Ira— since the storm is coming in right at 7 AM I’m more than likely will not going to be in in the morning right at opening. It will be a decision of each employee whether or not to come in but I will say NMCI and PBSS networks are both down. Let me know if you’re gonna be going in though please.

**Jeff Bergosh**: Plus the 3 mile bridge is closed as is Garson point

**Ira Miller**: Okay. I figured as much but I wanted to reach out. I’ll take PTO for tomorrow.

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-16-2020

**Ira Miller**: We are okay. We have electricity but a couple of circuits got knocked out because of water getting into outside outlets. Three trees down but none hit the house. Lots of missing shingles. Biggest concern is route to work after reaching Pcola with all the flooding. Standing by for information as necessary.

### CONVERSATION ON 09-18-2020

**Ira Miller**: Hey Jeff. I made it in. It’s pretty damn bad. The smell of sour carpets and mildew is already pretty bad.

**Jeff Bergosh**: That was my impression as well. Give me a call when you get a minute I’d like for you to check on a couple things while you’re there because it’ll be a couple hours before I get I get down there

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: We are having our meeting

### CONVERSATION ON 11-03-2020

**Ira Miller**: Jeff, I am under the weather a bit and I don’t want to be in the office coughing and sneezing. I’m not running a fever so I’m not worried about it being COVID, I just don’t want to make everyone nervous. I’ll officially call in later this morning.

**Jeff Bergosh**: Okay hope you’re feeling better

### CONVERSATION ON 11-04-2020

**Jeff Bergosh**: Do you have a PBSS cell phone?  Need to know yes or no ASAP.  If yes— text me the number

**Ira Miller**: No I don’t.

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 12-09-2020

**Jeff Bergosh**: Ira this gentleman needs a dig permit he needs the process started. He called me about five minutes after Tim and Heather walked out the door and right as everyone is at lunch. I met him out front of the building and he wants to remove several stops doesn’t know what to do didn’t know there was a dig permit required really not really aware of what’s needed. So please call him and help him out to get him started on the paperwork required thanks

### CONVERSATION ON 12-14-2020

**Ira Miller**: Give me a call ASAP please

### CONVERSATION ON 12-16-2020

**Ira Miller**: Dana’s test was negative.

**Jeff Bergosh**: That’s great news!

**Ira Miller**: Yeah it is. One bullet dodged. Warren feels like his is a stomach virus, but is awaiting results. Have a good evening Jeff. See you tomorrow.

**Jeff Bergosh**: Thanks Ira— that’s great news.  See you in the morning

### CONVERSATION ON 01-08-2021

**Ira Miller**: Jeff, I’m having some labs ran this morning I might be a few minutes late.

**Jeff Bergosh**: Got it.  Thx

### CONVERSATION ON 02-22-2021

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

### CONVERSATION ON 03-31-2021

**Ira Miller**: Jeff, I won’t be in today. I’ll official call in later this morning.

**Jeff Bergosh**: Okay ——are u alright Ira?

**Ira Miller**: Yeah. Stomach issues that I can’t get under control enough to risk an hour car ride. Been up half the night. Thai food didn’t agree with me I think.

**Jeff Bergosh**: Sorry about that hope you’re feeling better

### CONVERSATION ON 04-07-2021

**Ira Miller**: I have some new information that should help us make our case against being involved in this locate.

### CONVERSATION ON 04-09-2021

**Jeff Bergosh**: Ira I need you to fill out the electronic timesheet so I can approve them all

### CONVERSATION ON 07-29-2021

**Ira Miller**: Jeff, I’m at the ER with my daughter. She has a bad ear infection. My wife is out of town on business so I won’t be in tomorrow. I’ll officially call in tomorrow morning.

**Jeff Bergosh**: Okay thx for the heads up— sorry to hear this but hopefully the doctors can get her some relief.  No need to call In the morning, I got it.  See y Monday

### CONVERSATION ON 07-30-2021

**Jeff Bergosh**: Huntsville needs it

**Ira Miller**: Sent it. I did it earlier but I think it just saved it. Sorry Jeff, I was doing it off my phone. Have a good weekend.

**Jeff Bergosh**: Thx Ira , I as well.  Hope all is well

**Jeff Bergosh**: U put 8 hrs for today

**Ira Miller**: Damn. Yes. Today. Let me correct it.

**Jeff Bergosh**: Okay I’ll send it for correction

**Jeff Bergosh**: Okay I just it for correction

**Ira Miller**: Done.

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-10-2021

**Jeff Bergosh**: I returned your timesheet for correction— Monday was a holiday

### CONVERSATION ON 09-11-2021

**Ira Miller**: Hey man; I got a call from you just a few minutes ago, but I think it was an accidental dial. Ignore my call back unless it was something you needed me for. Have a great weekend.

**Jeff Bergosh**: Sorry Ira— pocket dialed you.  Have a great weekend!

### CONVERSATION ON 09-13-2021

**Ira Miller**: Jeff, I won’t be in today. My blood sugar has tanked and I’ve got to get it back to normal ranges. I’ll call in later this morning. Sorry for the short notice, but I woke up with my levels in the 60s.

**Jeff Bergosh**: Okay got it.  Thanks and I hope you can get the level right!

### CONVERSATION ON 10-20-2021

**Ira Miller**: Jeff, I won’t be in today. I have to go to the hospital and get multiple tests run. I will be in tomorrow morning.

**Ira Miller**: I will call later to official check in.

**Jeff Bergosh**: Okay Ira.  Hope you will be alright!

### CONVERSATION ON 11-01-2021

**Ira Miller**: Jeff. I won’t be in today. I am sick. Not COVID, just plain old allergies and sinus infection. Coughing so I don’t want to make everyone uncomfortable.

**Jeff Bergosh**: Understood— thanks for heads up— hope you’re feeling better

**Ira Miller**: Jeff, I won’t be in tomorrow either. I have a double ear infection. a massive sinus infection, and a slight case of bronchitis. The doc wants me on antibiotics for the next 24 hours . I’ll be in Wednesday morning.

**Jeff Bergosh**: OK Ira—thank you for the heads up sorry you’re not feeling well —we will see you Wednesday morning.

### CONVERSATION ON 01-20-2022

**Jeff Bergosh**: Are you making the safety training Ira?

**Ira Miller**: I’m not. I’m on the phone with the kidney doctor. He was supposed to call at 1230, but called early.

**Jeff Bergosh**: Okay call Gerald Flint for an alternative time to complete this training

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Oh I need you to correct your time sheet you had Monday as regular hours it should be a holiday

**Ira Miller**: Made the changes and resubmitted.

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-27-2022

**Ira Miller**: Hey man; I’m just letting you know I am now symptomatic. I’m getting tested in the morning, but I imagine I’ll be positive. I’ll let you know tomorrow.

