

## CONVERSATIONS WITH BRIAN MCCOMBS

### CONVERSATION ON 06-24-2020

**Brian mcCombs**: Hey Jeff this is Brian McCombs. Do you have some time this afternoon or tomorrow morning to talk? It’s regarding high school choices for our son Parker.

**Jeff Bergosh**: Of course Brian just give me a ring in the morning sometime between nine and 11 it’s good for me

**Brian mcCombs**: Will do

### CONVERSATION ON 11-27-2020

**Brian mcCombs**: Hey Jeff this is Brian McCombs. I hope things are going well for you. I need a recommendation on an attorney to help me with a power of attorney for my elderly mom who is having major medical problems and It’s getting harder for us to help her. I need someone to educate me on power of attorney and help me draw one up. Any thoughts?

**Jeff Bergosh**: Hi Brian- hope you all had a great Thanksgiving!  I’ll ask my brother who works with a lot of these guys and is very familiar with their work.  I’ll get a couple of names for you.  Sorry to hear of your mother’s declining health.  Hope you all have a great weekend!

**Brian mcCombs**: Thanks Jeff I appreciate it. I hope you had a happy Thanksgiving as well. I know you gave us the name of a Bo Harper last time for a real estate attorney. I just need somebody to walk me through this whole process. Thanks.

**Jeff Bergosh**: Sure thing.  No problem!

### CONVERSATION ON 07-19-2021

**Brian mcCombs**: Hey Jeff this is Brian McCombs. Would you have a few minutes today to talk to me about school?

**Jeff Bergosh**: Check your voicemail Brian and then give Kevin a call when you have time let me know how it turns out thanks man bye

**Brian mcCombs**: I got your message Jeff. Thanks for the information. Could you give me a call back?

**Jeff Bergosh**: In mtgs at moment will call u back after

**Brian mcCombs**: Tks

### CONVERSATION ON 07-20-2021

**Brian mcCombs**: Hey Jeff I have not called Kevin Adams yet. I wanted to ask you something first before I went down that road. Call me when you have a chance.

**Jeff Bergosh**: Okay I will.  In BCC budget workshop at the moment

**Brian mcCombs**: No worries whenever you have a chance.

**Jeff Bergosh**: In mtg will call I back

**Brian mcCombs**: Ok

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: 👍

**Brian mcCombs**: Good morning Jeff. I hope things are going well with you. Do you have any recommendations on a good employment attorney?

**Jeff Bergosh**: Hi Brian-  I don’t but I’ll ask my brother and I’m sure he will have a few that he can recommend.  Hope all is well!

**Brian mcCombs**: Thanks Jeff I really appreciate it. Let me know what he says. I’d like to reach out to someone today. Things are going well here. We’re looking forward to the holidays.

**Jeff Bergosh**: Jeremy Branning @ Clark Partington

**Brian mcCombs**: Thanks Jeff I appreciate you getting that for me.

**Jeff Bergosh**: He’s really good but unfortunately they’re very expensive but here’s an area where you don’t want to scrimp because he wins cases

**Brian mcCombs**: Understood thanks

