

## CONVERSATIONS WITH MIKE WOOD

### CONVERSATION ON 12-22-2021

**Jeff Bergosh**: Hey Mike it’s Jeff from Bible study I just had a quick question for you if you could give me a ring back about T-Mobile thanks!

### CONVERSATION ON 01-01-2022

**Jeff Bergosh**: Mike the manager was amazing he was so incredibly helpful. He took the phones and said he would return them and he worked with Sally through the T-Mobile customer care line. I believe they do have it resolved however we had to file a police report because the folks who committed this fraud in Connecticut are still running up the bill they actually opened a line of credit in Sally‘s name so it’s a complex issue but the manager was fantastic thank you so much for hooking us up with him! And happy new year to you Mike!

