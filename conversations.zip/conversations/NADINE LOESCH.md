

## CONVERSATIONS WITH NADINE LOESCH

### CONVERSATION ON 05-13-2020

**Nadine Loesch**: Thus is a copy if a memo I sent to D R Horton...

Dear DD Brown,

Hello. Caroline gave me your information, saying you are our “contact person” at D R Horton. I have written you to several times and have not yet received a response.  I hope all is well with you. I also understand you are a busy person and understand given these difficult times.  

I am asking you to please find the time to communicate with me as an owner at Deer Run. Proper communication breeds understanding, a better working relationship and respect. My attempts to achieve this dialogue have all been ignored so far. 

We all understand Nicki and Caroline are employees of Virtuous Management and do as D R Horton personnel, including yourself, tell them to do. All information that has come from them has been incomplete and evasive. This is why I reached out to you for clarification and understanding. As I have stated to you before, our county, state and federal governments have all given us a plan on how we will forward. 

I have asked you, as contact person for D R Horton to please communicate to me your plan. I have shared with you a plan for our owners to use all common areas while also practically social distancing for health & safety. Again, you have not responded at all. 

Last week we saw Caroline remove the signs off the gates. I think most people took this as a sign the pool was getting ready to open. Three days ago, while walking the neighborhood and pulling weeds in the open common areas, I noticed the chains on the gates were  removed.  An owner was alone and tanning at poolside. Later, we went in, social distancing, unaware that Virtuous Management had not removed the locks. Two of my neighbors have cameras on the exterior of their homes. I could not leave my home to cut locks without being seen on their cameras. Proof I did not do this. 

So apparently someone cut the locks. That was news to me. Who did this?  I do not know. I expect, given the chaos here, they are choosing to remain low key and appear to not get involved. 

All this behavior, in my opinion, stems from a lack of communication. I think you will find, most people, to be patient, understanding and supportive when you simply address the matter in a more respectful way. I simply do not understand why we cannot get a more compassionate answer from D R Horton in these very difficult times. So please, I implore you to please communicate with us better. Please show some compassion for the owners that believed in D R Horton’s professionalism enough to invest in a home from you. I sincerely look forward to hearing from you. 

Have a good day,
Nadine Loesch

**Nadine Loesch**: Hello. A couple questions for you please. 1) are you part of an HOA?  2) Does your HOA have a pool? 3). If yes, is your pool open?  Thank you in advance for the info - for comparison purposes

**Jeff Bergosh**: I do belong to an HOA— no pool though

**Nadine Loesch**: Finally talked with DD Brown. She was very combative. She is claiming that the HOA is a corporation and pool cannot open until phase 2 with full time monitoring and daily cleaning services - according to their lawyers who claim they can be sued if someone contracts COVID19 at the common area

Of course, we are a Corporation but we are not for profit and different laws apply. 
If this is true, Of course, there are very easy ways around this one of course being a signed release form for example

**Jeff Bergosh**: Sounds like a bunch of gobbledegook to me.  They need to open the pool!

**Nadine Loesch**: Thank you so very much for your support. 
Researching. The Villages in FL are an HOA. Their pools opened May 1.

### CONVERSATION ON 05-14-2020

**Nadine Loesch**: Caroline from the management company came again yesterday to lock the gates and kick everyone out of pool. 
I said we have rights to and are not leaving. She threatened to call police. I said please do. When she called the police she made a false report stating that there were altercations in the pool of a physical nature. Completely false. Police told her they were not coming. This is a civil matter. It is a crime to falsely report to police. I also have word that Caroline filed a false report within her company saying a male resident threatened her 2 days ago. We have witnesses. The man took a picture if her car tags. That is all. He wanted to know who is this lady that is threatening us - that is all. She has Virginia tags.

### CONVERSATION ON 06-05-2020

**Nadine Loesch**: 👋 our pool is open with restrictions. Dina Brown from DRHorton called me and asked me to be full time pool monitor, which i agreed to. She also asked me to form a committee of volunteers to disinfect surfaces every 60-90 minutes. Cannot use chairs, patio furniture or grill. Pool max capacity 17. 

Thank you for all your help!

**Jeff Bergosh**: Nadine— glad they finally opened the pool!!  Have a great summer!

**Jeff Bergosh**: ......just wish we could have made it happen sooner 

**Nadine Loesch**: Thx. You have a great summer too!

### CONVERSATION ON 07-13-2020

**Nadine Loesch**: Just read ... and shared ... your “WHEN EXCEPTIONS SWALLOW RULES...”. 
Totally agree in out home. No science to back up the mask 😷. 
The lack of guidelines to use them is embarrassing. 
I am a medical exception (severe asthma - 15 to 20 minutes wearing mask I get light headed, dizzy and feel faint. My pulmonologist says i have reduced air intake without mask. Add mask and i get less air. Plus i breathe in my carbon dioxide which gets me sick.)
I cannot go into a store without being “shamed” by store employees and customers. But hey when they call the ambulance and rush me to hospital, maybe then they will see the errors of judgment. 

THANK YOU
THANK YOU
THANK YOU

We ALL have rights. Ignorance doesn’t justify anyone taking my rights away. 

I applaud you for firmly speaking the “other” side and shining a light 💡 on the flawed desperate reactions of so many. 

Can we focus on washing our hands?
Why do we hear about all the positive test results but NOT -
- The number/% of new cases in hospital
- the ever declining death rate
- 1% of US has COVID19

GO JEFF❗️


**Jeff Bergosh**: Thank you Nadine!! I am getting to a point where I cannot take the stupidity LOL.  I am getting to a point where I can no longer bite my tongue anymore—I have to speak out.  I greatly appreciate your kind words and your support!  Thank you Nadine!

PS did they ever get around to opening the pool???  I hope so!

Jeff B

**Nadine Loesch**: Pool is openDR Horton and I have reached agreement. They have asked me to monitor pool and firm cleaning committee. I still have neighbors that believe i was “inappropriate” to speak out against Horton. They are entitled to their opinion. I am just happy that DRHorton had FINALLY agreed that we have a right to use our pool (safely) and fear does not give anyone the right to trample our rights. Standing on principle is not easy, but it is the RIGHT thing to do. 

Concerning the masks - 
It should be our constitutional right to CHOOSE to wear mask. Shaming is not only inappropriate buy very disrespectful of our way of life. CHOICE❗️

**Jeff Bergosh**: Agreed!

### CONVERSATION ON 08-20-2020

**Nadine Loesch**: Congratulations! 🎈

**Jeff Bergosh**: Thank you Nadine!!

**Nadine Loesch**: You got all 3 votes from our home

### CONVERSATION ON 08-21-2020

**Jeff Bergosh**: Thank you Nadine!!!!

### CONVERSATION ON 04-06-2021

**Nadine Loesch**: Hi. This is Nadine. 
Hope you had a great Easter. 
We were wondering if you knew the tentative opening date for the Beulah Publix on 9 mile rd?

**Jeff Bergosh**: Hi Nadine!  Last I heard it was mid April— so coming up next week.  

**Nadine Loesch**: Gotcha. Thank you so much

### CONVERSATION ON 08-30-2021

**Nadine Loesch**: Hi Jeff. I hope all is well with you. 
Thus is Nadine Loesch in Deer Run. My HOA has been harassing us about our fencing material. They want only 6’ wood fences, per their fence application form. Our CCRs stipulate metal, pvc, wood or masonry p13 (l). We installed 4’ black metal. They are saying we have to rip it out. 

Our CCRs stipulate application must be received in writing. We completed written application form with plat and fencing location. 
We also cited CCR p13 (l)
Application was sent USPS on 9/8/20. CCR do NOT stipulate certified mail, signature required etc. 
We waited for reply. 
CCRs stipulate, if ARC has not responded within 30 with approval or denied, then approval is assumed. We did not receive a reply. 
We installed the black metal 4’ fence 2/2/21. 
HOA mgmt company says they do weekly community inspections. The fence has been up for 7 months. 
Now HOA says we have 30 days to rip out an very expensive black metal fence to put in a 6’ wood fence that will rot. 
I am not putting in an ugly wood fence in place of my beautiful metal fence. What are we to do?

