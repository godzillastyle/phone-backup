

## CONVERSATIONS WITH JIM REEVES

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Jim—we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your continued support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Jim Reeves**: You are welcome 

### CONVERSATION ON 10-22-2019

**Jim Reeves**: Tell me all the people that are going to kick in for paying for the function tonight, and the amounts. I’m going to talk to McGuire today.

**Jeff Bergosh**: Okay will do.  Thus far it is Danny zimmern, you, Fred Donovan, and David Peaden for $250 each.  If McGuire will do a little that would be great—and I intend to cover the balance

### CONVERSATION ON 10-23-2019

**Jim Reeves**: Jeff, Wanted to remind you.. you received $500 from Patty and Alan. And just reminding you Aimee Dumas raised $6450 for you (on behalf of my name) But it would be nice to send her a note. Contact info is attached.

**Jeff Bergosh**: Thank you Jim I will definitely send her a thank you!!  It was a very good event—-thank you so much for all your help!!!

**Jeff Bergosh**: I spoke to Danny Z and Freddy Donovan JR earlier this morning.  Fred SR has maxed out so he can’t contribute toward the food expense, so Freddy JR is going to use his IPC number to cover a portion of the food, whatever is needed, to square away last night’s bill.  I think the grand total with tax and tip was $2,000–I paid $322 of it (tips for waiters—so they could get their tips and not wait) so I believe there is a balance of $1700–and after Danny, you, David Peaden, and McGuire do $250 each—the balance can be charged to Freddy Donovan JR.  ( back story is he wrote a $1,000 contribution for me from the company so I had to return it to him because FRED SR already wrote me a $1000 check from that same company account at my last fundraiser.  So Freddy JR agreed to do the food instead as his contribution.  Sorry for the long text and thanks again Jim!!!

**Jim Reeves**: Patti **Cantavespre and I haven’t gotten ok from McGuires contribution. But I did ask him to do 300. I’ll let to you know what he says.

**Jeff Bergosh**: Thanks Jim—and I’ll pay for whatever balance remains either way — sorry to put you through the headache.

**Jim Reeves**: I am sending over a $250 check through the accounting department, how much did you raise in total last night?

**Jeff Bergosh**: $22,750.00

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

### CONVERSATION ON 02-05-2020

**Jim Reeves**: Thanks for sharing 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-20-2020

**Jim Reeves**: Jeff
If the BCC vote to close down 
The beach today , how do the
Homeowners at Santa Island 
Come & go?

**Jeff Bergosh**: Jim I don’t think this is going to happen

**Jim Reeves**: Jeff, to further my earlier text. Today is pay day and I have 27 employees - of that, 4 are African American, and 4 are convicted felons (we are a second chance company), and I need to keep that RV Resort open for their sake.

**Jeff Bergosh**: Thank you for that Jim

**Jim Reeves**: Thank you 

**Jeff Bergosh**: 👍

**Jim Reeves**: Please exclude RV’s! 

### CONVERSATION ON 04-19-2020

**Jim Reeves**: Jeff, did you get my email about that tiny house ordinance.  If so do you have any comments

**Jeff Bergosh**: Good morning Jim.  I did get it, and I don’t anticipate any resistance to it, do you?

**Jim Reeves**: I don’t either, my only concern is will lumon follow through-on. Being ‘all in’ when it comes time to vote. Has Janice talked to you about the ordinance at all?

**Jim Reeves**: JJR

**Jeff Bergosh**: No she hadn’t yet.  Everyone has been consumed with the Chinese Coronavirus

**Jeff Bergosh**: Are the home builders good with it? Peaden?

**Jim Reeves**: I’ll agree to that

**Jeff Bergosh**: Dunaway

**Jim Reeves**: Absolutely.. absolutely. NAIOP and HBA support the ordinance. Dunaways firm prepare d the  ordinance. All it does is define the tiny home as a residence.

**Jeff Bergosh**: I don’t see any problems at all Jim.  

**Jeff Bergosh**: Hope all is well— 

**Jim Reeves**: Thank you very much for your support. How is your race going considering the ‘Chinese’ virus ? 

**Jeff Bergosh**: I’m polling well ahead of my opponents thus far.  I am confident, but not over-confident.  I have some intangible advantages in that I raised my funds early and before my opponents, I’m getting lots of media and my opponents are not, so I feel that the pandemic actually helps me as an incumbent.  One thing I can say with absolute certainty:  Underhill’s secretary will not win.  He has no money and no name recognition.  It is, in reality, a two-man race:  me vs Jesse Casey.  Jesse is a nice man, but unqualified to do the job, very unsophisticated and he’d be way out of his depth.  But he is well liked by many so it’s really between he and I.  I believe, like last time, I will dispatch him. Probably by 6-12 points or better

**Jim Reeves**: Great to hear

### CONVERSATION ON 04-23-2020

**Jim Reeves**: Sooner or later - we will need your help! 

**Jeff Bergosh**: Absolutely— I completely support the tiny home concept I think it’s great idea

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good afternoon Jim.  As a person that has helped me in my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Jim—and I thought the tiny house presentation went well-looking forward to seeing how it develops going forward!

**Jim Reeves**: Great for you
Thank you

### CONVERSATION ON 06-25-2020

**Jim Reeves**: 
Jeff, thanks to the virus, I have not bugged you for any political contributions in months. However, I have been tasked with selling 50 raffle tickets for Victoria, the sailboat. Checks are made to Pensacola Yacht Club Satori Foundation (PYC Satori Foundation). They’re $50 each, and I would like you to consider buying four tickets. Keep in mind, $200 is the least I have ever asked you for. I have the tickets at MY OFFICE. I am including the flyer on Victoria, the information on what the PYC Satori foundation does for disadvantaged kids, and a picture of Victoria.

**Jeff Bergosh**: Thanks Jim.  Will definitely participate!

**Jim Reeves**: Great, you can drop off a check or mail it to my office at 730 Bayfront Parkway suite 4b

**Jeff Bergosh**: Will do Jim!

**Jim Reeves**: Thank you 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-01-2020

**Jim Reeves**: Following up on check for tickets, do I need to arrange to have it picked up?

**Jeff Bergosh**: Not necessary Jim I’m mailing it today.

**Jim Reeves**: Thanks

**Jeff Bergosh**: No problem—Just let me know once you’ve received it when I can get the tickets 😎👍

**Jim Reeves**: I can mail them back or have them dropped off, up to you

**Jeff Bergosh**: I’ll probably just have you mail them  if it’s OK

**Jim Reeves**: Sounds great 

### CONVERSATION ON 08-19-2020

**Jim Reeves**: Congratulations well deserved win! My best JJR

**Jeff Bergosh**: Thanks Jim!!

### CONVERSATION ON 08-30-2020

**Jim Reeves**: Jeff, I hope you can come to this. Michelle will do a great job for us 

### CONVERSATION ON 08-31-2020

**Jeff Bergosh**: Thanks Jim- it’s scheduled during a BCC meeting but Sally will come to it

**Jim Reeves**: Great thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-24-2021

**Jim Reeves**: Jeff, do you have any time this week for about 30 minutes concerning the tiny homes ordinance that is coming up for second reading on February 4?

