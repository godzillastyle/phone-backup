

## CONVERSATIONS WITH SCOTT LUNSFORD

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Congratulations on your re-election Scott!

Jeff Bergosh 

