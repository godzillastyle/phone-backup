

## CONVERSATIONS WITH ANTHONY SUMMERS’ NEW

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: 
Anthony--I wanted to let you know that I just got my latest poll results back from Gravis.  I’m ahead of Jesse by 16 points, and I’m crushing Underhill’s Secretary by 30 points!  Thought you might like to know that 

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Thanks for your continued friendship, help, and support Anthony!!

**Anthony Summers’ New**: 👍

### CONVERSATION ON 10-27-2020

**Anthony Summers’ New**: Got em

**Jeff Bergosh**: 👍

**Anthony Summers’ New**: Lol..... they sent you crap..... times and response

**Jeff Bergosh**: Not a surprise

**Anthony Summers’ New**: Call me me.... many issues

**Jeff Bergosh**: Anthony I will .  Can I call u in the AM?

**Anthony Summers’ New**: Sure

### CONVERSATION ON 10-28-2020

**Anthony Summers’ New**: view from tower7

**Jeff Bergosh**: Wow!  Thanks

### CONVERSATION ON 12-17-2020

**Anthony Summers’ New**: its Summers.......buzz me when you can.... thanks

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Anthony Summers’ New**: buzz me later

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-01-2021

**Anthony Summers’ New**: it's getting close to your bedtime.....lol.... buzz me

### CONVERSATION ON 03-03-2021

**Jeff Bergosh**: In a meeting will call you after

**Anthony Summers’ New**: np.... buzz me when you get a chance

### CONVERSATION ON 04-15-2021

**Jeff Bergosh**: Do you know anything about a fire at 5:00AM today in Beulah?

### CONVERSATION ON 04-30-2021

**Jeff Bergosh**: In mtg will call u back

**Anthony Summers’ New**: Np.... was just getting a weird recording 

### CONVERSATION ON 06-15-2021

**Jeff Bergosh**: Hey Anthony--I hope all is going well. So I just wanna give you some warning I got hit with a gigantic very very expansive public records request for all my social media text messages emails phone records everything the whole kitten caboodle for a five month. Regarding fire and public safety. So some correspondence between you and I will have to be turned over just wanted to give you a heads up this is a wonderful request coming from the lawyer for the fire Union

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: Hey Anthony I'm in a BCC meeting I'll call u back

**Anthony Summers’ New**: OMG!.... how do you deal with this!...lol... watching the meeting

**Jeff Bergosh**: Fun right?!?

**Anthony Summers’ New**: I would just GONE OFF about 30 mins ago.... you my hero!

**Jeff Bergosh**: Is hard not to sometimes

**Anthony Summers’ New**: Oh my goodness... Pam is going to be destroyed.... she needs to shut up

**Jeff Bergosh**: She's high on power

**Anthony Summers’ New**: Lord!... Underhill needs to shut his face.... 75 grand could have gone to training..... he is Fing clueless

**Jeff Bergosh**: Yes he is

**Anthony Summers’ New**: Had to dump off the vid...... dude... i literally do not know how you hold your shit together.... I couldnt..... buzz me when you get a sec

**Jeff Bergosh**: Ok

### CONVERSATION ON 11-04-2021

**Jeff Bergosh**: Will call you after

**Anthony Summers’ New**: Sounds good

### CONVERSATION ON 01-06-2022

**Anthony Summers’ New**: Ugh... roundabout at that intersection would massive traffic accidents 

