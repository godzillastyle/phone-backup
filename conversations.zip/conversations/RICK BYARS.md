

## CONVERSATIONS WITH RICK BYARS

### CONVERSATION ON 08-03-2020

**Jeff Bergosh**: Rick-  absolutely.  Would love to know more about that.  I’ll be in Milwaukee from the 19th-25th of August-  but I can meet with you on the 26th, 27th, or 28th of August at my office downtown at either 4:30 or 11:30 on any of those three days.  Just reply which date/time works and I’ll put that in my calendar.  Thanks Rick!

**Jeff Bergosh**: Thanks Rick- I greatly appreciate your support and and the appointment is on the calendar.  See you on the 26th!

**Jeff Bergosh**: Thanks Rick!  Will do!!

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: Thanks Rick for all your support!!

