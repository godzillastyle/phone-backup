

## CONVERSATIONS WITH DAVID BERGOSH

### CONVERSATION ON 11-10-2019

**David Bergosh**: Hi Jeff. I hope things are going well for everyone. I was wondering if you could send me a photo of Dad. The only one I have is probably 50 years old.

### CONVERSATION ON 11-11-2019

**Jeff Bergosh**: Hello David-hope all is well with you too.  Please send me a good email address to where I can send the pictures

**David Bergosh**: Hi Jeff, things are going good. I am getting ready for another crazy holiday season in retail. My email is davetheflame57@gmail.com. Thanks for sending the pictures.

### CONVERSATION ON 11-14-2019

**David Bergosh**: Jeff,I just saw the pictures. Thank you for sending them.

**Jeff Bergosh**: Absolutely.  No problem at all David

### CONVERSATION ON 12-06-2019

**David Bergosh**: Hi Jeff. I just read about the shooting at the base. Is everyone ok? 

**Jeff Bergosh**: Unfortunately there were some casualties but all the team that I work with are OK it was a tough day here hope all is well with you

**David Bergosh**: I am glad you and your team are OK. I'll be praying for everyone down there. Take care!

**Jeff Bergosh**: Thanks David!

### CONVERSATION ON 08-21-2020

**David Bergosh**: Just looking online, and it looks like you might have a hurricane headed your way. You and everyone else stay safe.

**Jeff Bergosh**: Thanks David!  We're actually up in Milwaukee right now but we're watching!  Hopefully it goes a different direction

**David Bergosh**: Hopefully so. Looking at the path of the storm, reminds me about hurricane Frederick back in 1979. Take care.

**Jeff Bergosh**: Thanks David you as well

**David Bergosh**: Could you pass my number on to Gary, and have him send me a message? I would just like to communicate with both of you.

**Jeff Bergosh**: Will do it!

**David Bergosh**: Thanks Bro!

**Jeff Bergosh**: Absolutely!!

### CONVERSATION ON 09-16-2020

**David Bergosh**: How is everyone doing? It looks like that hurricane is hitting the city hard. Praying for everyone's safety.

**Jeff Bergosh**: Thanks David-- we are okay thankfully.  Lots of trees down and flooding - but we are alright. Thanks for checking in!

**David Bergosh**: No problem Jeff. Stay safe.

**David Bergosh**: Jeff, I wonder if the bridge that collapsed, was the one where Dad took me fishing a few times.

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: It's the same location, but that bridge got demolished after hurricane Ivan in 2004

**David Bergosh**: Ok, thanks for the information Jeff.

