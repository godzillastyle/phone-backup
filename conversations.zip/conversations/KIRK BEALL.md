

## CONVERSATIONS WITH KIRK BEALL

### CONVERSATION ON 01-05-2020

**Jeff Bergosh**: Happy New Year Kirke!

