

## CONVERSATIONS WITH GERALD FLINT

### CONVERSATION ON 04-03-2020

**Gerald Flint**: Thanks Mr. Bergosh.

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-19-2020

**Gerald Flint**: Good Morning Sir, local news didn’t cover the local election, did you win?

**Jeff Bergosh**: Yep— sure did by 8 points and more than 1000 votes!  Thanks Gerald!!

**Gerald Flint**: Awesome!  Congratulations bud.  4 of those were from me and mine.  I’m happy for you!

**Jeff Bergosh**: Right on Gerald!!!i greatly appreciate that!!thanks for the support!!

**Gerald Flint**: You got it!

### CONVERSATION ON 09-14-2020

**Jeff Bergosh**: Gerry I got your message thank you very much for looking into that and I’ll just keep my ears open and I’ll anticipate working tomorrow unless I hear otherwise. Thank you again for asking the question and passing the information along.

**Gerald Flint**: More to follow I’m sure.

### CONVERSATION ON 09-15-2020

**Gerald Flint**: Please send word to all of your people that if they do not feel comfortable coming to work  in the current windspeed or they have to travel through areas that will be flooded, then they need to stay at home.  (Forwarded from Mark Powell)

**Jeff Bergosh**: Will do Gerald—thanks 

**Gerald Flint**: He also said for those coming in, consider pushing back your arrival time and if you observe bad road conditions on your way in, please pass that word to your folks.

**Jeff Bergosh**: Got it—thanks

**Gerald Flint**: As this storm draws near, Mark is not expecting folks at work tomorrow.  Emergency issues will be dealt with case by case.

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: Thanks Gerald. 

### CONVERSATION ON 09-21-2020

**Jeff Bergosh**: Gerry— I just wanted to say thank you very much for sending the structures personnel over here. They secured the side door for us and now they are extracting the water and have installed dryer fans on the floors so we are greatly appreciative!

### CONVERSATION ON 12-11-2020

**Gerald Flint**: Side note to this possible near miss at 3783, our electrician said the wires were not energized, his opinion was that they were abandoned.

**Gerald Flint**: I'm not writing this up.  I think you can disregard the whole thing.

**Jeff Bergosh**: Okay-- Thanks for the heads up. This said ---I'm still going to request that Tim address it and explain it so that we can learn from it.

**Jeff Bergosh**: I copied you on the email I sent to him requesting a brief upon his return next week

**Gerald Flint**: Thanks Sir.

### CONVERSATION ON 02-02-2021

**Jeff Bergosh**: Thank you Gerald I just reported in

### CONVERSATION ON 08-17-2021

**Gerald Flint**: In case you need it.  See attached Work Order for the Duncan / Moffet job.

**Jeff Bergosh**: Okay, got it.  Ira from our office is making the diagram.

**Gerald Flint**: Thanks Sir.  I'm going to draw all over it so it doesn't need to be super extravagant!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: I'll call u right back

**Gerald Flint**: None of your folks are at training?

### CONVERSATION ON 09-08-2021

**Jeff Bergosh**: Just to be on the safe side I took a COVID home test last night before I went to bed.  It was negative.  I'm 100% today--The only thing I can think is that I must've over exerted myself over the holiday weekend with a long bike ride on Monday which took it out of me.....

V/R,

Jeff Bergosh

**Gerald Flint**: Ok, thanks Jeff.  GTG.

