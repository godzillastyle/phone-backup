

## CONVERSATIONS WITH SCOTT MCCARTNEY

### CONVERSATION ON 06-03-2020

**Jeff Bergosh**: Hello Scott!  Thanks for your support!

Jeff Bergosh Campaign

I look forward to meeting you Monday

### CONVERSATION ON 06-08-2020

**Jeff Bergosh**: Scott— it was great meeting you and your staff!  Thanks for the hospitality and the support!

### CONVERSATION ON 08-12-2020

**Jeff Bergosh**: Right on thanks Scott!

