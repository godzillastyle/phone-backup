

## CONVERSATIONS WITH BRAD CRAGER

### CONVERSATION ON 12-24-2019

**Brad Crager**: Merry Christmas! 🎄 

**Brad Crager**: Merry Christmas! 🎄 

**Jeff Bergosh**: Merry Christmas

**Brad Crager**: You coming to SD? Here, now?

**Brad Crager**: You coming to SD? Here, now?

**Jeff Bergosh**: No we didn’t make it out this time we’re still here in Florida

### CONVERSATION ON 12-25-2019

**Jeff Bergosh**: Merry Christmas from the Beach!  We’re having an unusual weather day today it is 73° sunny and beautiful!

**Brad Crager**: Awesome!

### CONVERSATION ON 12-31-2019

**Brad Crager**: Happy New Year! 🎆 

**Jeff Bergosh**: Happy New Year Brad!!!!  Make 2020 a great year— you have an open invitation to come visit us this summer when you’re out of school we keep waiting for you to come visit Pensacola!

**Brad Crager**: I’ll be there! I promise! 

### CONVERSATION ON 01-26-2020

**Brad Crager**: Such sad news! 

**Jeff Bergosh**: Beware of helicopter rides!

**Brad Crager**: I mean really.

**Brad Crager**: I’ll take you flying in a plane.

**Jeff Bergosh**: Do you have a pilot license?

**Jeff Bergosh**: https://m.youtube.com/watch?v=m82IiPD9leI

**Brad Crager**: Good one!

**Brad Crager**: Going back to finish the course. 

**Brad Crager**: I’m still a little bumpy on the landing but you should be fine.

**Jeff Bergosh**: Just don’t pull a Kobe

**Jeff Bergosh**: 😂

### CONVERSATION ON 02-02-2020

**Brad Crager**: Niners by 14

**Jeff Bergosh**: Alright I'm going with the Chiefs by 7 and Jager!

**Brad Crager**: Jeff, don't you owe me $ from an old bet?

**Jeff Bergosh**: I think u got that backwards

**Jeff Bergosh**: You're on!

**Brad Crager**: Oh, your right! 

**Brad Crager**: You're

**Jeff Bergosh**: Enjoy the game guys-- one day soon we'll all get together for a frosty!

**Brad Crager**: His foot was out!

**Jeff Bergosh**: Uh, nope

**Brad Crager**: Shut up!

**Jeff Bergosh**: Not overturned

### CONVERSATION ON 03-14-2020

**Brad Crager**: Stay safe! I’m off for a month.

**Jeff Bergosh**: Thanks you too!  Don’t catch the Coronavirus!

**Brad Crager**: You too!

### CONVERSATION ON 03-29-2020

**Brad Crager**: https://www.foxla.com/news/12-residents-at-nursing-facility-in-yucaipa-test-positive-for-covid-19

**Brad Crager**: Close by, now. 🙁

**Jeff Bergosh**: Stay safe don’t catch coronavirus

### CONVERSATION ON 04-02-2020

**Brad Crager**: Three cruise ships are trying to dock in Florida. 🙁

### CONVERSATION ON 04-12-2020

**Brad Crager**: Happy Easter!!!🐇🐣🐰 

**Jeff Bergosh**: Happy Easter Brad!

### CONVERSATION ON 05-21-2020

**Brad Crager**: Another Naval shooting!?

**Jeff Bergosh**: Yep——. Crazy right!!

### CONVERSATION ON 05-27-2020

**Brad Crager**: Are you watching?

**Jeff Bergosh**: No but I’m going to.  Is it 3:00 ET?

**Brad Crager**: It might be earlier

**Jeff Bergosh**: I’m watching it now— view from crew capsule

**Brad Crager**: I think I saw one of the astronauts carrying a bottle of Jagermeister! 

**Jeff Bergosh**: Yeah right!

**Jeff Bergosh**: I would be carrying one though!

**Brad Crager**: Lol

**Jeff Bergosh**: Launch scrubbed due to weather

**Brad Crager**: Yep

### CONVERSATION ON 06-21-2020

**Brad Crager**: Happy Father’s Day, Jeff!

**Jeff Bergosh**: Thanks Brad!! Hope all is well!!

### CONVERSATION ON 06-25-2020

**Brad Crager**: Are you in SD?

**Jeff Bergosh**: Nope not this year— it’s a campaign year wish I was!!

**Brad Crager**: Ok, I saw pics from last year, I guess. 

### CONVERSATION ON 08-19-2020

**Brad Crager**: Congratulations!!!

**Jeff Bergosh**: Thanks Brad!!!!

### CONVERSATION ON 09-09-2020

**Jeff Bergosh**: Brad— I saw ABC National News reported live from Yucaipa yesterday covering the wildfires.  Are you and your properties safe?  Hoping for the best Brad!

**Brad Crager**: Hey, Jeff. I believe they survived but the fires came so close that most of the town was evacuated. Thanks for checking. I’m in Maine, now. It is a lot cooler here. I see a lot of Florida plates. 🙂

**Jeff Bergosh**: LOL.  Do u live in Maine now full time?

**Brad Crager**: Looking for a house to but. I love it here! 

**Brad Crager**: I’ll need a boat, too. 

**Brad Crager**: Oh, notice the Florida license plate. It says, BB Maine, as in Boothbay. Where I am, now. 

**Jeff Bergosh**: That’s awesome Brad.  How long are you up there?

**Brad Crager**: About a week and a half. Then, maybe going to Michigan.

**Brad Crager**: I teach on line, now, from anywhere. 

**Jeff Bergosh**: That’s pretty awesome Brad!  Do you still own the house on Medlar?  Who is watching out for it for you?

**Brad Crager**: Yes, but the area might be evacuated. Neighbors are keeping me posted. The fire is getting closer. Santa Ana winds picking up. My other house to the north is in a risky area too. Double nightmare! 

**Jeff Bergosh**: Well at least you are safe.  That’s what insurance is for!

**Jeff Bergosh**: Thanks Austin— I just want them to finish in 9-Mile.  It’s time!

**Brad Crager**: Wrong person?

**Jeff Bergosh**: Yeah- sorry

**Jeff Bergosh**: 👍

**Jeff Bergosh**: .........Just don’t let this guy win!

**Brad Crager**: Lol

### CONVERSATION ON 09-12-2020

**Brad Crager**: Governor Paul Lepage is my bartender!

**Brad Crager**: You are missing out! 

**Brad Crager**: He lives in Florida, too.

### CONVERSATION ON 09-15-2020

**Brad Crager**: Nice name!

**Jeff Bergosh**: Sally is getting a kick out of this LOL

**Brad Crager**: Great!

**Brad Crager**: FYI: I was going to put you on speakerphone with the former Gov. of Maine. 

**Jeff Bergosh**: Cool.  Tell him I said hello from the hurricane zone!

**Brad Crager**: I’m back from Maine, but I’ll see him again, when I go back. He is running again in two years, as a Republican. He also lives in Florida. 

**Jeff Bergosh**: How did your house fare in the fire?  Is it okay?

**Brad Crager**: Still standing, the other one, too. The air quality is hazy and very unhealthy. Maine’s air was amazingly clear and fresh. 

**Jeff Bergosh**: Glad to hear that Brad.  They’ll go up in value now due to supply and demand.  Glad you didn’t lose them 

**Brad Crager**: I might be buying a summer home in Maine. 

**Jeff Bergosh**: Nice!!

**Brad Crager**: I like being in the East! 

**Brad Crager**: My power just went out!

**Jeff Bergosh**: Uh-oh— break out the generator

**Brad Crager**: I wish

### CONVERSATION ON 09-25-2020

**Jeff Bergosh**: Brad watch this video this is what liberals think about Trump appointing another conservative justice to the court

**Jeff Bergosh**: https://wdtprs.com/2020/09/video-unhinged-karens-spittle-flecked-obscenity-laced-nutty-on-hearing-that-justice-ginsberg-died-language-warning/

### CONVERSATION ON 11-26-2020

**Brad Crager**: Happy Thanksgiving! 🍽🦃🍁 

### CONVERSATION ON 11-28-2020

**Jeff Bergosh**: Hope you had a great one Brad!

### CONVERSATION ON 12-23-2020

**Brad Crager**: Hey, Jeff! Are you in SD? If so, how long?

**Jeff Bergosh**: Yes!  Are u in west coast??

**Jeff Bergosh**: We will meet up I’m here through the 4th

**Brad Crager**: I’m here in Yucaipa. Yes, let’s do it! 

**Jeff Bergosh**: For sure!  Merry Christmas Brad!

**Brad Crager**: Merry Christmas!

### CONVERSATION ON 01-04-2021

**Brad Crager**: Hey Jeff, recently I tested positive for covid. I road in an ambulance to the hospital on Saturday. I am on oxygen, now. Taking many drugs. Remdesivir is the main one now. It’s been a hard time Jeff

**Jeff Bergosh**: Brad I’m sorry to hear that man I will keep you in my prayers I knew when you didn’t answer something must be going on so hang in there and fight as hard as you can!

**Jeff Bergosh**: Can u talk?

**Brad Crager**: No on oxygen 

**Jeff Bergosh**: Okay well I’ll call u when u are able.

We’re all praying for you Brad!

