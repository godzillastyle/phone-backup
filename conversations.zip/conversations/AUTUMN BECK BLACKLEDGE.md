

## CONVERSATIONS WITH AUTUMN BECK BLACKLEDGE

### CONVERSATION ON 04-13-2020

**Jeff Bergosh**: No I haven’t — I heard they did a good job of locking it down ahead of time. 

### CONVERSATION ON 12-25-2020

**Jeff Bergosh**: Photo 

