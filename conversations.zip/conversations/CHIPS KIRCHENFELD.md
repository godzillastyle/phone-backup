

## CONVERSATIONS WITH CHIPS KIRCHENFELD

### CONVERSATION ON 12-27-2019

**Jeff Bergosh**: This is the Facebook post

**Chips Kirchenfeld**: Hi Commissioner.  Tamika is working on the data and the answers to questions for response.  Obviously she wants the data to be accurate so it will take her and staff time.  She hopes to have it this afternoon.  I’ll forward it to you as soon as I receive it.  And I will talk to Janice Monday morning about potential employee insubordination.  Thank you.

**Jeff Bergosh**: Thanks very much Chips!

**Chips Kirchenfeld**: You’re welcome Commissioner. 

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Hey Janice and Chips--We have discovered a 5 to 6 foot alligator in our retention pond here in Bell Ridge Forest subdivision off of 9 mile road. I'm wondering does the county have a animal wrangler that we contract with still who can capture this alligator and then relocate him?

**Chips Kirchenfeld**: Hi Commissioner Bergosh.  I will make a few phone calls and let you know.  Don't go swimming in there!

**Jeff Bergosh**: No worries there Chips!

**Chips Kirchenfeld**: https://myfwc.com/wildlifehabitats/wildlife/alligator/snap/

### CONVERSATION ON 03-17-2020

**Chips Kirchenfeld**: Press conference today at EOC at 1:00 PM.  Please be here by 12:45 for coordination.

**Jeff Bergosh**: Thanks, I’ll be there

### CONVERSATION ON 08-18-2020

**Chips Kirchenfeld**: Congratulations!

**Jeff Bergosh**: Thank you Chips!

### CONVERSATION ON 08-26-2020

**Chips Kirchenfeld**: Hi Commissioner, when you get a chance, please call me to discuss the CARES Act and our consultant, the Integrity Group’s proposal.  Anytime this afternoon or evening is fine.  Thanks!
Chips

### CONVERSATION ON 09-01-2020

**Chips Kirchenfeld**: Hi Commissioner.  We are finalizing the application and requirements for the CARES Family Assistance Grant program that will begin Sept 18th.  Because of the multi-layers of validation required by our staff and the Clerk’s Office, and the staff review time involved, we are requesting that the amount of the Family Grant be $2000 per household instead of $1500 for 1-5 members and $2500 for 6 or more household members.  We can discuss this at this Thursday’s BCC Meeting, but I wanted to see if this seems reasonable to you?

**Jeff Bergosh**: Seems reasonable to me Chips- thanks for the heads up

### CONVERSATION ON 12-28-2020

**Chips Kirchenfeld**: Hi Commissioner.  The Rapid Testing for Sacred Heart is proposed for $500,000.  Rapid Testing for Community Health is $750,000.  Vaccinations for Sacred Heart is $3,500,000.   Thanks. 

**Jeff Bergosh**: Thanks Chips

### CONVERSATION ON 12-29-2020

**Jeff Bergosh**: Chips thank you very much for sending me the agreement with Sacred Heart and also with community health northwest Florida. I do have some additional questions about these agreements if you have a moment to call me back I would greatly appreciate it it’s about 940 thank you

### CONVERSATION ON 01-26-2021

**Chips Kirchenfeld**: Hi Commissioner,
I know you are upset about the DPZ fact sheet.  Matt Posner and I would like to meet with you this week at your convenience to discuss.  Maybe lunch one day?

**Jeff Bergosh**: Hey Chips that sounds great I’ll call you at some point tomorrow we can set it up appreciate it

**Chips Kirchenfeld**: Thanks!

### CONVERSATION ON 11-16-2021

**Chips Kirchenfeld**: Great job on your first day as Chairman!  You wrestled the Beach Haven Project through!  The quality of life for over 100 families will be greatly improved.  Thank you!

**Jeff Bergosh**: Thanks Chips!  It was agonizing

### CONVERSATION ON 12-02-2021

**Chips Kirchenfeld**: Hi Commissioner, there is an issue with a proposed Budget Amendment for the USEPA Estuary Program Grant.  As Chairman, you are authorized to sign and approve certain grant-related documents.  If you are asked by Estuary Program staff to approve a proposed grant Budget Amendment, please decline and refer it to the full BCC for further discussion and action.  Thank you!

**Jeff Bergosh**: Will do Chips

**Chips Kirchenfeld**: Thank you

