

## CONVERSATIONS WITH DEAN KIRSHNER

### CONVERSATION ON 04-02-2020

**Jeff Bergosh**: Thanks Dean!  Tip one back for me!!

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: No problem Julia!  Glad to help— thank you for bringing it to my attention or else I would not have known hope you guys recover and that everyone is OK!!

**Jeff Bergosh**: Hey Dean-- just checking in hoping everything went okay for you and Estelle in this hurricane.  Is your house okay, and how did lake Carlene fare?

