

## CONVERSATIONS WITH DON FRENKEL

### CONVERSATION ON 01-17-2021

**Jeff Bergosh**: Good morning Don. I’m forwarding you the name and telephone number of a constituent who lives right next to the Fairground. They are sending multiple complaints about noise and have indicated that two of your security employees are the culprits. If you could have your staff reach out to this citizen, I would greatly appreciate it.  perhaps we can get to the bottom of the noise —thank you Don.

Jeff Bergosh


Citizen who complained:

Maria Wilhite
850-450-7426

