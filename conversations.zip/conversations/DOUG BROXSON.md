

## CONVERSATIONS WITH DOUG BROXSON

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Congratulations on your victory tonight Senator Broxson!

Jeff Bergosh 

### CONVERSATION ON 07-19-2021

**Jeff Bergosh**: I think it will be pretty neat

