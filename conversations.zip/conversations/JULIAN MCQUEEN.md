

## CONVERSATIONS WITH JULIAN MCQUEEN

### CONVERSATION ON 03-22-2020

**Julian McQueen**: Gentlemen,
1015 souls plus their families were forever changed this week as we began our layoffs. More to come next week. The most vulnerable unfortunately are the first to go, followed next week with more of the salaried staff.  The end result is the same for all. We are all not sleeping well these nights. Come April 3rd if there is the same lack of appreciable facts to support the closure of the sand on the beach behind the hotels and condos, I hope a measured response can be found to bring our families at Innisfree back to work.  Julian

### CONVERSATION ON 03-25-2020

**Jeff Bergosh**: Where in the settings would this change have to happen?

**Julian McQueen**: Today we have decided to retract commitments of $804,000 to charities for 2020 due to the closure of beaches. While we will not be making money if the beaches are open, we will be able to bring back employees furloughed. 

### CONVERSATION ON 04-27-2020

**Julian McQueen**: Gentlemen, Earlier Innisfree offered a 50% occupancy limit as an incentive to reopen the beaches. Now that all the hotels on Pensacola Beach are closed except Innisfree's and we are giving free rooms to medical workers, our offer to limit occupancy isn't pertinent. With the limited room inventory we would effectively be 50% occupancy for the total beach hotel Inventory even if we ran 100%. Since Portofino is not a hotel but a condo rental business it has also been taken out of the available rooms to rent. 

**Julian McQueen**: After a lengthy call with Com. Bender, we have decided to return to the original commitment to remove 50% of our inventory for sale of our 750 rooms on Pensacola Beach. The  free rooms we are giving to the medical heros is not counted against us. Currently we have booked over 800 free rooms nights for medical workers. At an average of $200 a night retail that is $160,000 consumed of Innisfree's $1.2 million commitment to that program. Innisfree will keep the 50% occupancy limit through May 7th for a phased approach to reopening. Since we are the only lodging open on all of Escambia County's beaches, that will limit hotel occupancy to approximately 30% of all the normally available condos,houses and hotel short term rentals on Pensacola Beach and zero  percent occupancy on Perdido Key beaches. 

### CONVERSATION ON 04-28-2020

**Julian McQueen**: Alabama opened its beaches May 30th with social distance restriction only 

### CONVERSATION ON 05-30-2020

**Jeff Bergosh**: Thanks Julian—we will be out at your place tomorrow!!

**Julian McQueen**: Got it

**Julian McQueen**: See u soon

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-31-2020

**Julian McQueen**: Your room is ready to check in early when ever you get here. Enjoy!

**Jeff Bergosh**: Thank you Julian—greatly appreciate it!

**Julian McQueen**: No brunch. Breakfast rolls right into lunch.  You have to make a choice. Let me know when you want a visit and I’ll come down for a cuppa. 

**Jeff Bergosh**: Okay sounds great.  We’re headed that way—thanks Julian!

**Julian McQueen**: Roger that

**Jeff Bergosh**: Julian the room is spectacular!!! thank you so much and thank you so much for the nice dessert tray and bottle of wine!!

**Julian McQueen**: Did they tell you about the Cabana we set up for you at the pool?  Unit number 6 has you name on it. It is best in the afternoon but it’s your all day. 

**Jeff Bergosh**: You are too kind!!!! We didn’t know but now we do!! Headed that way now!

### CONVERSATION ON 06-01-2020

**Jeff Bergosh**: Julian:  you succeeded in making our 26th anniversary truly a special day. The food and beverages in the restaurant and out at the pool were fantastic, the bungalow was amazing and of course the room had a breath taking view and was incredible.  We truly enjoyed the entire day and night and all the extra touches you provided that made it extra special.  You have a beautiful property out there——and a really great staff—we had a blast!!  Thank you from the bottom of my heart!

**Julian McQueen**: Mission accomplished. So glad to hear we hit the mark

**Jeff Bergosh**: You all crushed it!!  🙂👍

### CONVERSATION ON 06-09-2020

**Julian McQueen**: Do you have time this week to talk about the referendum for the Escambia Children’s Trust ( children’s Service Council) that I Chair?  Coming up on the CoW agenda in the 16th. I would love to buy you a cuppa coffee and review the benefits and stats at other counties in FL. 

**Jeff Bergosh**: Sure Julian.  Afternoons work best for me this week though.  I could meet with you today, Thursday, or Friday afternoon downtown at 4:30 on any of those days.  Would that work?

**Julian McQueen**: Today or Thursday works. Probably today is best but I’m open either day

**Jeff Bergosh**: Sounds good-I’ll put it on my calendar for 4:30 this afternoon.  We can meet at my office downtown if that works for you.  Just let me know—thanks!

**Julian McQueen**: Great. See you at you office at 4:30 today. Text if anything changes.  I’m flexible

**Jeff Bergosh**: Will do see you then!

### CONVERSATION ON 06-16-2020

**Julian McQueen**: Great questions and driving the point home

**Jeff Bergosh**: Thx

