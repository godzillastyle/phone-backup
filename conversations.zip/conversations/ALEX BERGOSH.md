

## CONVERSATIONS WITH ALEX BERGOSH

### CONVERSATION ON 03-25-2020

**Jeff Bergosh**: Yep 😎

**Jeff Bergosh**: Probably should not be playing basketball because there’s too much close contact

