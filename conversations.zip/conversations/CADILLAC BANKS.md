

## CONVERSATIONS WITH CADILLAC BANKS

### CONVERSATION ON 04-02-2020

**Cadillac Banks**: Commissioner this is Cadillac. I cannot make it to the 5:30 meeting today because I'm keeping my social distances. I am trying to do a fireworks in September at the festival. I need ¿1500 more to make it happen. Commissioner May is giving me ¿4500. Thanks for your help. 

**Jeff Bergosh**: I'll chip in for it.  We will add it to the May or June agenda.  Please do me a favor and just email the request to District1@myescambia.com

Stay safe Cadillac!

**Cadillac Banks**: Thanks will do. 

**Cadillac Banks**: Just sent you the email with the backup. Thanks

### CONVERSATION ON 05-03-2020

**Cadillac Banks**: Good evening Commissioner. Thanks for the funds for the fireworks. Sir I have another small problem. I really need ECUA to take a look at my front yard by the mailbox and why is this oil looking water is coming out the ground. My meter does not have a leak. Could you please have someone from ECUA to take a look at. Photos attached. Thanks

**Jeff Bergosh**: No problem Cadillac.  I'll talk to our ECUA D1 Rep Vicki Campbell.  We'll get it sorted out 

**Cadillac Banks**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-08-2020

**Cadillac Banks**: Jeff drop me off 2 iron rods for your signs. Thanks

**Jeff Bergosh**: Okay will do Cadillac 

**Cadillac Banks**: Thanks

### CONVERSATION ON 05-11-2020

**Cadillac Banks**: Jeff good evening. The lady from ECUA never called. 

### CONVERSATION ON 06-02-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Cadillac Banks**: Ok

### CONVERSATION ON 06-10-2020

**Cadillac Banks**: Jeff have you seen all these big signs Casey got up. 

**Jeff Bergosh**: No-- where r they?

**Jeff Bergosh**: Billboards?

**Cadillac Banks**: Blue Angel and Lillian Hwy.  One is on the side of Tom Thumb facing Blue Angel and the other one is across the street facing Lillian Hwy. 

**Jeff Bergosh**: Oh yes,  I've seen those.  He has a lot of signs out, just as he did last time.  I have about 75 spread out around the district and I'm about to unleash 18 full billboards soon...

**Cadillac Banks**: Great!

**Jeff Bergosh**: Thanks for all your support Cadillac!

**Cadillac Banks**: Anytime. 

### CONVERSATION ON 07-15-2020

**Cadillac Banks**: Billboards looks good. 

**Jeff Bergosh**: Thanks!! I have then going up all over!

**Cadillac Banks**: That's what I'm talking about. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-20-2020

**Cadillac Banks**: Congrats. 

### CONVERSATION ON 08-21-2020

**Jeff Bergosh**: Thanks Cadillac!!

**Cadillac Banks**: You're welcome!

### CONVERSATION ON 07-14-2021

**Cadillac Banks**: Good morning. Thanks for the funds. See you soon at the festival. 

**Jeff Bergosh**: Absolutely!!  Looking forward to it

**Cadillac Banks**: Thanks.

### CONVERSATION ON 09-07-2021

**Cadillac Banks**: Jeff good evening. Do I need to come to the budget meeting to see if visit Pensacola have the jazz festival in it's unified Budget for 2022 because I need to start booking my talents for 2022 next month. 

**Jeff Bergosh**: Hey Cadillac this is the first budget hearing it's not the final so I don't necessarily know that it would be productive to be there.

**Jeff Bergosh**: By the way congratulations for a great festival we had a blast!

**Cadillac Banks**: Ok thanks

### CONVERSATION ON 09-14-2021

**Cadillac Banks**: Good morning. Can you ask Visit Pensacola if I am included in their unified budget for $150K that Steve Hayes and I agreed to before he left.  


**Jeff Bergosh**: I will

**Cadillac Banks**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-17-2021

**Cadillac Banks**: Good morning. Lumon told me that you spoke up for me at the workshop. Thanks. Visit Pensacola is saying that they cannot do anything regarding funding unless it comes from the board because my event is outside the grant program. I will be at the budget meeting next Tuesday. Again, thanks for your support. 

**Jeff Bergosh**: Got it.  I'm going to speak to Darrien Schaeffer too

**Cadillac Banks**: 👍

**Cadillac Banks**: I have already added Eric Darius for 2022. 😁

**Jeff Bergosh**: Right on!  He's a great Saxophonist!

**Cadillac Banks**: Yep!

### CONVERSATION ON 09-21-2021

**Cadillac Banks**: Good evening Commissioner. I'm here at the budget hearing if you need me to speak. Spoke with Darian today and he told me that he couldn't do anything without the Boards permission. 

### CONVERSATION ON 11-06-2021

**Cadillac Banks**: Good morning. Just want to say thanks for your support even if the board vote against me Tuesday. 

**Jeff Bergosh**: Absolutely-- I hated that you had to sit through that mess

**Cadillac Banks**: I'm ok with that. I hope and pray that we could put the festival in the unified budget for the next two years.   $2.2 million is not a bad return on bed tax dollars. 

**Cadillac Banks**: Here is the lineup for 2022 if I get funded. For your eyes only. 

