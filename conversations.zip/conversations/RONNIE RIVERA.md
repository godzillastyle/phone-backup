

## CONVERSATIONS WITH RONNIE RIVERA

### CONVERSATION ON 11-15-2019

**Ronnie Rivera**: Are you going to EHS this morning?

**Jeff Bergosh**: Unfortunately I’ll be unable to attend

**Ronnie Rivera**: No problem brother! Let's catch up soon for lunch. 

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 09-05-2020

**Ronnie Rivera**: Can you text us those locations? Thank you sir. We are doing blue angel and mobile Hwy. then the boat launch. What are the other 2 locations? Thank you sir 

**Jeff Bergosh**: Sorry Ronnie— didn’t get this till just right now.  I have several signs still out that might work for you all— just let me know if you want them and if so I won’t pick them up.

—-Mobile Hwy between the Mexican restaurant and the kidney dialysis place

—-open field on Mobile Hwy just west of Marlane 

—-Mobile Hwy just East of Marlane

—-Pine Forest Road on northbound side north of blue angel

—-Michigan Ave Dollar General

—-Marlane ave next to big field 

If u want these locations I’ll leave the signs just let me know


Thanks!!

**Ronnie Rivera**: Yes sir, thank you. I’ll let chip know. 

**Jeff Bergosh**: Okay— take the ones you all want and I’ll pick up the rest next Sat.

Have a great weekend Ronnie

**Ronnie Rivera**: Yes sir! You as well. 

### CONVERSATION ON 09-09-2020

**Ronnie Rivera**: On Chip said he believes we have all the locations we need. We only have a few more skins so we should be good. We also wanted me to tell you thank you. 

**Jeff Bergosh**: Absolutely!  Good luck!!

**Ronnie Rivera**: Loved “Absolutely!  Good luck!!”

### CONVERSATION ON 10-08-2020

**Ronnie Rivera**: Our last event for the next sheriff of Escambia County! We would love to see you and Sally! 

### CONVERSATION ON 04-02-2021

**Ronnie Rivera**: Happy Happy Birthday 

**Jeff Bergosh**: Thanks Ronnie!

### CONVERSATION ON 06-30-2021

**Ronnie Rivera**: Hey it’s Ronnie, call me when you have an opportunity, please and thank your 

**Ronnie Rivera**: You 

**Jeff Bergosh**: Will do Ronnie.  In a meeting at the moment but will call u after

**Ronnie Rivera**: Thanks 

### CONVERSATION ON 12-06-2021

**Ronnie Rivera**: Let me when you get here I’ll come down and get you. Thanks 

**Jeff Bergosh**: Will do.  Event starts at 11:00AM, right?

**Ronnie Rivera**: Yes sir we’re gonna be doing a presentation at 11

**Jeff Bergosh**: Okay I’ll get there a few minutes before

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Thanks Ronnie!

**Jeff Bergosh**: Awesome thanks Ronnie!

### CONVERSATION ON 12-25-2021

**Ronnie Rivera**: Merry Christmas brother 🎄🎁! I’m so thankful for our friendship, God has blessed me with amazing people in my life. 

**Jeff Bergosh**: Merry Christmas to you and yours as well Ronnie!  Let’s make 2022 the best year ever!!!

### CONVERSATION ON 01-27-2022

**Ronnie Rivera**: I’m on the board for AMIkids and was wondering have you ever taken a tour of the boys base? Thanks and hope you are having a wonderful day. 

**Jeff Bergosh**: I have Ronnie— although it was a number of years ago when I was on the school board and at that time Boys Base was on Corey.  I’ve been to the current AMI Kids facility when it was Escambia Bay Marine Academy charter School.  Hope all is well with you, too!

**Ronnie Rivera**: The boys base is still on Corey station and it has been a while. We are reaching out to key difference makers in our community for tours. We’d love to have you over so you can take a peek at what’s been going on since you last checked in. 

**Jeff Bergosh**: Would love to do that!

**Ronnie Rivera**: Thank you sir! I will produce some dates that are available. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-31-2022

**Ronnie Rivera**: Could you do a morning tour sometime after the 16th or 17th of February?

**Jeff Bergosh**: How about the afternoon of the 18th— 4:30ish——would that work?

**Ronnie Rivera**: Let me work on it. Thank you. 

