

## CONVERSATIONS WITH WILSON ROBERTSON

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Wilson- we’re just about 24 hours away from my fundraiser tomorrow form 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Wilson Robertson**: Gave invitations to:
Mike Morrette 
David Delgallo 
Jimmy White 
Jimmy white Jr
David Meeks
Joe Meeks
Lamar Brazwell 

Look forward to seeing you Tomorrow

**Jeff Bergosh**: Thanks very much Wilson—I greatly appreciate it and I’ll see you there!

### CONVERSATION ON 10-28-2019

**Wilson Robertson**: Please give me a call at your convenience 

### CONVERSATION ON 01-08-2020

**Wilson Robertson**: Please call me at your convenience 
Wilson 

**Wilson Robertson**: Thanks I passed that along to Eric
Eric said Scott Miller does not represent him, he has never met him. He thinks he may be representing to buyer. I told Eric I believe Scott hurt his case.

### CONVERSATION ON 01-13-2020

**Wilson Robertson**: Please call me at your convenience 

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Walking into the Value adjustment board meeting

**Wilson Robertson**: 👍 

**Wilson Robertson**: Men’s Barn Meeting 
Contact person is Jim Porter 850-232-8518

**Jeff Bergosh**: Got it!  Thanks!

**Wilson Robertson**: Something has come up and I can’t attend the meeting tonight. 
We have some signed forms of yours and some blank forms. When I get them completed I’ll turn these in and get some more. Something funny happened today,  Randy Cudd called me soliciting my support for you, he also said He’s working on Larry Downs. Randy said they like Casey but these are his words “that bunch down there would eat him alive “

**Jeff Bergosh**: LOL he’s right about that Wilson! 

**Jeff Bergosh**: Thanks very much and by the way I found out there will not be a REC meeting tonight—they have rescheduled them for the 4th Monday of the month for the next 4 months—so our next one will be the 27th of this month.

**Wilson Robertson**: Thanks 

### CONVERSATION ON 01-23-2020

**Wilson Robertson**: Please call me at your convenience 

### CONVERSATION ON 01-27-2020

**Wilson Robertson**: Sorry to constantly bother you but will you please call me at your convenience 

### CONVERSATION ON 02-05-2020

**Jeff Bergosh**: Good morning Wilson—I thought this might be of interest to you:

Got my most recent poll results back from Gravis.  among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race against Greg Marcile:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)


**Wilson Robertson**: I was a part of that poll
I was also asked if I would support an increase in fire tax. How did that poll go? Thanks 

**Jeff Bergosh**: 51% oppose 49% support raising tax rates.  Closer than I thought it would have been

**Jeff Bergosh**: Among Republicans only it was 55% oppose and 45% support—-still a lot closer than I thought it would be

**Wilson Robertson**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-14-2020

**Wilson Robertson**: Call me when you can 
Monday will be OK

**Jeff Bergosh**: Will do Wilson

### CONVERSATION ON 05-11-2020

**Wilson Robertson**: Call me at your convenience please 

**Wilson Robertson**: Ron Gibbs
850 380 6279

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good Morning Wilson— I spoke with  Mr. Gibbs and he is going to let me put a couple of signs up at his property—thanks for assisting with that!

Also-  I wanted to let you know that I just got my latest poll results back from Gravis.  I’m ahead of Jesse by 16 points, and I’m crushing Underhill’s Secretary by 30 points!  Thought you might like to know that 

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

**Wilson Robertson**: Great news 
It’s obvious they are splitting up the votes that are not going for you. If necessary to could win this election with 35% of the total votes. When this election is over send the other two a thank you card. Good Luck 

**Jeff Bergosh**: LOL that’s true.  I’ll do it, send them thank you cards

### CONVERSATION ON 06-08-2020

**Wilson Robertson**: Jeff 
I’ve answered two surveys in the last three days about your race. Did you order them, if so let me know the results when their in.
Thanks 

**Jeff Bergosh**: It wasn’t me— which means it is probably Greg Fink running one for Jesse and Rick Outzen or its Jonathan Owens 

**Jeff Bergosh**: Thank you for the heads up

**Wilson Robertson**: If you hear results from someone please let me know. As I’ve said before you only need about 35 % with that many in the race.

**Jeff Bergosh**: Thanks Wilson— I will.  I’m planning to do one toward the end of this month once we know if it’s a closed primary or if it’s open.  I’ll definitely let you know.

### CONVERSATION ON 06-16-2020

**Wilson Robertson**: Please call when you can 

### CONVERSATION ON 06-23-2020

**Wilson Robertson**: Call me when you get a minute 

### CONVERSATION ON 06-25-2020

**Jeff Bergosh**: Good afternoon Wilson—

I got my latest poll results back this afternoon—here are the latest numbers among the voters who are decided as of today:

Bergosh. 45%
Casey.      33%
Owens.     17%
Trotter.      5%

I’m beating Doug’s Secretary by 28 points.  Can’t wait for August 18th!

**Wilson Robertson**: Good  
Glad there’s two other candidates, it helps you.
Can you tell me the results of the others in the poll

**Jeff Bergosh**: Yes

Chip’s race:  76-24 Simmons
Vicki Campbell:  65-35. Campbell
Mike Hill/Salzman:  57-43 Hill

### CONVERSATION ON 07-13-2020

**Wilson Robertson**: Thanks for your comments on TV
Please don’t let that bunch on city Council dictate what the Commission does. They have put a motion on their agenda to try to get y’all to change your minds. How arrogant, please stand your ground and let it be optional 

**Jeff Bergosh**: Thanks Wilson-you can count on that!  Grover needs to stay in his own lane!

### CONVERSATION ON 07-18-2020

**Wilson Robertson**: I responded to a poll last night
It had your race, Sheriff and mike Hill 
It also asked what you rate Burgosh job performance
If you find out the results would you please let me know thanks 

**Jeff Bergosh**: Will do Wilson!

### CONVERSATION ON 07-20-2020

**Jeff Bergosh**: Wilson—got the poll results back today— and as of right now- among those voters who have made up their minds in my race, the numbers are as follows:

Jeff Bergosh.        42%
Jesse Casey.         34%
Jonathan Owens.  14%
Jimmie Trotter.       10%


8 point lead over Jesse
28 point lead over Doug’s Secretary 
32 point lead over Trotter

It’s noteworthy to point out that at this point in the race 4-years ago, Jesse and I were in a virtual dead heat in my final, 30 days before the vote poll——so I feel good about where we are as votes are being cast right now as we speak—but I’m going to continue to run as if I am 20 points behind!

**Wilson Robertson**: Me and Ann just cast early mail in votes so those 2 are in for you, by the way can you give me the numbers on Mike Hill. Thanks 

**Jeff Bergosh**: Thanks Wilson!

**Jeff Bergosh**: Yes—it is 52-48 Hill

**Wilson Robertson**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-28-2020

**Wilson Robertson**: Sorry to bother you but call me when you can 

### CONVERSATION ON 08-05-2020

**Wilson Robertson**: Headed to my office 
Let me know about what time y’all be there 

**Jeff Bergosh**: Will do— and thanks again. Wilson!!

**Jeff Bergosh**: Wilson I’m heading that way right now, leaving my office right now

**Wilson Robertson**:  Thanks 

**Jeff Bergosh**: Thank you very much for recording the Robocalls Wilson!!!  Greatly appreciate it!!

**Wilson Robertson**: 👍 

### CONVERSATION ON 08-18-2020

**Wilson Robertson**: Are you having a victory party 

**Jeff Bergosh**: I was going to but I couldn’t find a venue that would book it so we’re just gonna hang out at the house and watch the results from the house thank you for all your help Wilson!!

**Wilson Robertson**: Good luck 

**Wilson Robertson**: Congratulations 

**Jeff Bergosh**: Thank you Wilson!!

**Wilson Robertson**: I predicted 40% would be enough to win. 

**Jeff Bergosh**: You called it Wilson!!!!  Thanks for your robocalls calls that pushed me over the top!!

### CONVERSATION ON 08-20-2020

**Wilson Robertson**: Please call me when you can, this evening or in the morning 
Thanks

### CONVERSATION ON 08-21-2020

**Jeff Bergosh**: Will do

**Wilson Robertson**: David Tau
850-324-7264

### CONVERSATION ON 09-19-2020

**Jeff Bergosh**: Hey Wilson what’s that address again is it 8712 Lawton St.?

**Wilson Robertson**: 8127

**Jeff Bergosh**: 👍

**Wilson Robertson**: I was wrong it’s 
Jonathan Lawson Elect

### CONVERSATION ON 10-15-2020

**Wilson Robertson**: Please call me when you can 

**Jeff Bergosh**: Will do

### CONVERSATION ON 10-22-2020

**Wilson Robertson**: Jeff 
Sorry to bother you but they only pick up part of the trash at the 3057 Knotty Pine Dr. 
They may be coming back but that was several days ago.
Thanks

**Jeff Bergosh**: I’ll check on that Wilson

**Wilson Robertson**: Thanks 

### CONVERSATION ON 11-04-2020

**Wilson Robertson**: Please call me when you can 
Wilson 

**Wilson Robertson**: Subject property 
6227 Dallas Ave
Owner 
Mrs Brewer &
Daughter Mrs Farias
Lien on subject property because of another property 
County’s attorney handling case is
Matthew Shaun.
Thanks

**Jeff Bergosh**: Got it.  Will be in the lookout

**Wilson Robertson**: Sorry to bother you again, having served in the same office some of our constituents call me occasionally and I hat to just say call the Commissioner 
Call me at your convenience 
Thanks 

### CONVERSATION ON 11-06-2020

**Wilson Robertson**: Jeff
Watched the meeting last night.
You done a great job standing up for your constituents yet not standing in the way of progress.
Thanks 

**Jeff Bergosh**: Thanks!  I was trying to be fair to Eric Gleaton and be fair to the residents at the same time—- but very few residents showed up so that made it much easier for me

**Wilson Robertson**: I agree 

**Jeff Bergosh**: Thanks Wilson.  Hope you all have a great weekend!

### CONVERSATION ON 12-10-2020

**Wilson Robertson**: Jeff
Please give me a quick call before tonight’s meeting thanks

**Jeff Bergosh**: Sure

**Wilson Robertson**: The  case I spoke with you about several weeks ago is coming up tonight. It’s a code enforcement lien in the mother (Pam Brewer) and daughter (ginger
Daria’s) on Dallas Ave. in our district. Her daughter had paid 5000.00 to clear up all but one. County staff said the board would have to forgive this one. If you will please see what you can do, my son-in-law Bill Farrington is representing them.
Thanks

**Wilson Robertson**: Unless you have questions you do not need to call me

### CONVERSATION ON 01-27-2021

**Wilson Robertson**: Please call me at your convenience 

**Jeff Bergosh**: Will do

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: Wilson, I just now heard of the tragic loss your family suffered.  Sally and I are keeping you and your family in our prayers.  My condolences to you.

**Wilson Robertson**: Thanks for your prayers 

### CONVERSATION ON 06-02-2021

**Wilson Robertson**: Please call me when you can 

**Jeff Bergosh**: Just called

### CONVERSATION ON 08-16-2021

**Wilson Robertson**: Please call me when you can 

**Jeff Bergosh**: Will do— in a meeting right now will call u after

**Wilson Robertson**: T

### CONVERSATION ON 08-27-2021

**Jeff Bergosh**: Wilson:  I have a call into the director of permits and inspections and when he calls me back I’ll check on that schedule and call u back

### CONVERSATION ON 09-20-2021

**Wilson Robertson**: Please call me when you can 

### CONVERSATION ON 09-29-2021

**Wilson Robertson**: Jeff 
Sorry to bother you after hours but if you will call me this evening or in the morning 
Thanks

### CONVERSATION ON 10-22-2021

**Wilson Robertson**: Jeff
Nash Patel asked me to remind you they haven’t worked on his holding pond 
Thanks 

**Jeff Bergosh**: Ok sorry about that I’ll check on that.

**Wilson Robertson**: 👍

### CONVERSATION ON 12-16-2021

**Wilson Robertson**: Please call me when you can 

