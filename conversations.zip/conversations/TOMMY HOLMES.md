

## CONVERSATIONS WITH TOMMY HOLMES

### CONVERSATION ON 11-03-2019

**Jeff Bergosh**: Hey Tommy good morning. Thank you so very much for the generous contribution of products from your store that we can auction at our fundraiser later this month. We want to include you in the program ——can you please email me a graphic for your store, the logo, in a high-resolution format for the program if you have it? Your logo would be great if you could send that thanks. We will get you some tickets to the event which is going to be fantastic it’s on Tuesday, November 19.  

Jeff and Sally Bergosh 
Jeffbergosh@gmail.com

### CONVERSATION ON 03-20-2020

**Tommy Holmes**: Can you talk?

**Jeff Bergosh**: Sure

### CONVERSATION ON 03-23-2020

**Tommy Holmes**: I heard the pier got shut down today.

**Jeff Bergosh**: Did it?  By who?

**Tommy Holmes**: I heard the county or the Island Authority. 

**Jeff Bergosh**: It wasn’t us. I wonder if the vendor who leases that from us would’ve shut it down himself?

**Jeff Bergosh**: I’ll see what I can find out

**Tommy Holmes**: Ok. Thanks. 

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: Tommy:  it’s my understanding that the pier operator, Michael Pinzone, made the individual decision to close that pier; he wasn’t forced to do it.  But it is closed as of last night

**Tommy Holmes**: Ok. Thank you. 

**Jeff Bergosh**: I wonder if he was pressured to do so??

**Tommy Holmes**: Not sure. 

### CONVERSATION ON 04-01-2020

**Tommy Holmes**: Call me when you can please. 

**Tommy Holmes**: Supposedly West Marine is able to stay open because they sell marine supplies. We sell marine supplies. We sell supplies to Metson marine out on base. 

**Jeff Bergosh**: Here’s the executive order from today.  Read the attached essential services addendum

**Tommy Holmes**: I wish there was a way to open up the beaches just for fishing or maybe pick specific areas that will be able to open for fishing provided people spread out. 

**Tommy Holmes**: I guess you guys are meeting tonight to get some clarity on what needs to happen. I hope the boat ramps can be left open along with the marinas since fishing is considered an essential activity according to the Governor's executive order.

### CONVERSATION ON 04-09-2020

**Tommy Holmes**: Volusia county (Daytona) has opened up its beaches to walking, swimming, and fishing. No lawn chairs or umbrellas. No sun bathing. The same officers that patrolled the beaches to keep people off are now just making sure the folks are doing the fishing or swimming or walking. Just a thought now that the precedent has been met. Is this something we can do here. 

**Jeff Bergosh**: I believe when we open it up it will be phased-in with initial rules like what Daytona is doing.  It will be discussed on May 7th—I just don’t know if the full board is ready to do this yet....

**Tommy Holmes**: Oh. Ok. That’s still a ways off. 

### CONVERSATION ON 05-20-2020

**Tommy Holmes**: Do you have a minute to talk. 

**Jeff Bergosh**: Sure

### CONVERSATION ON 08-18-2020

**Tommy Holmes**: Did we win. 

**Jeff Bergosh**: Damn right we did!! Thanks for all your help!!!!!!

**Tommy Holmes**: Awesome. Congratulations. 

**Tommy Holmes**: Do you have to face an opponent in November. 

**Jeff Bergosh**: Nope.  I’m in for the next 51 months!!!

**Tommy Holmes**: Awesome. 

