

## CONVERSATIONS WITH JIMMY STALEY

### CONVERSATION ON 12-16-2019

**Jimmy Staley**: Good guys-0

**Jimmy Staley**: Bad guys-1

**Jeff Bergosh**: What happened?

**Jimmy Staley**: Janice

**Jimmy Staley**: Your latest blog.  Total reversal on what you previously posted. 

**Jeff Bergosh**: Yes—but I’m still working on it.  Stay tuned

**Jimmy Staley**: Somebody benefits from edler staying in place. 

### CONVERSATION ON 12-25-2019

**Jeff Bergosh**: Merry Christmas!

### CONVERSATION ON 01-07-2020

**Jeff Bergosh**: Exactly!  You get caught in the middle asking both sides for the same information but neither side is doing the work

**Jimmy Staley**: In the end someone (I thought it would be the comptroller) should be auditing this. Pam Childers told Mel the SAO said this ok way to handle it.  But it isn’t legal

**Jimmy Staley**: I sent this to Steven and Lumon

### CONVERSATION ON 01-08-2020

**Jimmy Staley**: Just got intel that deputy’s haven’t received bulk back raises as of today

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: Uh oh

**Jimmy Staley**: I believe it’s the compression that wasn’t fixed.  Will have more info later today

**Jimmy Staley**: Call me when u can I have some confidential info to talk to you about regarding let.  

**Jeff Bergosh**: In mtg will call u after

**Jimmy Staley**: Read the email I sent first

**Jimmy Staley**: This needs to stay confidential because since this is the case, I don’t want them trying to cover up or the opportunity to change public records

**Jeff Bergosh**: K

**Jimmy Staley**: Did you read the email yet

**Jeff Bergosh**: Not yet Buried at work

### CONVERSATION ON 01-10-2020

**Jimmy Staley**: Did you look at that email?

**Jeff Bergosh**: Yes I did.  Interesting.  Super-slammed at work.  Will call later this afternoon once I come up for air to discuss

**Jimmy Staley**: 👌🏻 

### CONVERSATION ON 01-11-2020

**Jimmy Staley**: How did you like those texts?

### CONVERSATION ON 01-12-2020

**Jeff Bergosh**: Lots of redaction

**Jimmy Staley**: In the PBA ones,I am referenced 7 times glad to know im in their heads

**Jeff Bergosh**: 👍

**Jimmy Staley**: Any other thoughts on texts?  Do you see them colluding?

### CONVERSATION ON 01-13-2020

**Jeff Bergosh**: I really can’t tell.  So many redactions—-interesting reading nonetheless

**Jimmy Staley**: Did you read the first set?

**Jimmy Staley**: Less redacted

**Jeff Bergosh**: Yeah.  Saw my name in one.  Not flattering portrayal

**Jeff Bergosh**: LOL

**Jimmy Staley**: According to zarzaur the one he just got which is not red acted in my understanding, it is far worse than he anticipated.  They all sound like high school girls.  My question was if they are doing all these texts, when do they really work?

### CONVERSATION ON 01-14-2020

**Jimmy Staley**: Is there gonna be any follow up on LET this week?

**Jeff Bergosh**: Waiting on staff to get with ECSO

**Jimmy Staley**: Good luck with that 

**Jimmy Staley**: That's good 


### CONVERSATION ON 01-16-2020

**Jimmy Staley**: Where can I find Pam childers disagreeing with you on LET?

**Jimmy Staley**: Did you see my latest blog?

**Jeff Bergosh**: I did

**Jeff Bergosh**: Read the texts too

### CONVERSATION ON 01-17-2020

**Jimmy Staley**: So talked to a deputy. Raises were paid according to a convoluted formula and when they question the process they get another reason why their pay doesn't match the formula.  Told that next year they will get the big money.  Of course Morgan will be gone.   What recourse will they have then?

**Jeff Bergosh**: PBA

**Jimmy Staley**: Dont worry that is in the works.  Just sayin these guys are shady AF. did you see this ?

**Jimmy Staley**: This may overturn Pat Gonzalez 's conviction according to his legal team

**Jimmy Staley**: There is so much more.  Ask Mel 

### CONVERSATION ON 02-07-2020

**Jimmy Staley**: https://www.pnj.com/story/news/2020/02/07/ginger-bowden-madden-prosecutor-daughter-bobby-bowden-runs-state-attorney/4690949002/

### CONVERSATION ON 02-21-2020

**Jimmy Staley**: Y’all know he has paid out LET funds.  He’s getting reimbursement from you.  Contrary to statute

**Jimmy Staley**: The check is his general fund

### CONVERSATION ON 04-05-2020

**Jimmy Staley**: I’m so over this non-pandemic!

**Jimmy Staley**: So I talked Ginger Bowden-Madden 

### CONVERSATION ON 04-19-2020

**Jimmy Staley**: https://share.icloud.com/photos/0SNXwQF2FvcNgp9_YHL8PlTPQ#Bowling_Green

### CONVERSATION ON 06-21-2020

**Jeff Bergosh**: Thank you Jimmie!

### CONVERSATION ON 07-12-2020

**Jimmy Staley**: Good morning Jeff!  Is there such a thing as an approved vendor list for the county? Is that a thing?

**Jeff Bergosh**: I believe there is for some purchases under the competitive bidding threshold and again for small purchases

**Jimmy Staley**: Is that at my Escambia.com

### CONVERSATION ON 07-13-2020

**Jeff Bergosh**: Myescambia.com

### CONVERSATION ON 07-31-2020

**Jimmy Staley**: This is bullshit

### CONVERSATION ON 08-08-2020

**Jimmy Staley**: This should be the LET FUND.  

Check out this article from Pensacola News Journal:

Florida Board of Governors tells UWF to immediately repay $2.4M to Complete Florida Plus

**Jimmy Staley**: https://www.pnj.com/story/news/2020/08/07/florida-board-governors-tells-uwf-repay-2-4-m-complete-florida-plus/3321010001/

### CONVERSATION ON 08-18-2020

**Jimmy Staley**: Hey commissioner. Can you tell who I can request LET Expenditures from specifically?  I used to get them from Stephan hall. Then Chris Childs. Now I’m being told let is only aid to private organizations. There are no other Subcategories. Shawn hunter is the super genius who said this 

**Jimmy Staley**: Congratulations!!!🎉🎈 

**Jeff Bergosh**: Thank you Jimmie!!!!

### CONVERSATION ON 08-19-2020

**Jimmy Staley**: Give me a call when you can please

### CONVERSATION ON 08-20-2020

**Jimmy Staley**: Did y’all do away with the subcategories like equipment, investigations, all the other uses besides political capital even the costs of doing forfeitures?

**Jeff Bergosh**: No, I’ll look into it when I get back to town on Wednesday

### CONVERSATION ON 08-28-2020

**Jimmy Staley**: Hey.  You heard about Morgan running for mayor, right?

### CONVERSATION ON 09-16-2020

**Jimmy Staley**: How are y’all doing?

**Jimmy Staley**: How are y’all doing?

**Jeff Bergosh**: We came through it okay-  power out and trees down but overall we are good

**Jimmy Staley**: Is it true the bridge has a piece missing?

**Jeff Bergosh**: Yes

### CONVERSATION ON 01-09-2022

**Jimmy Staley**: Hey Jeff. I was wondering if the jail has jail has reverted back to Chip

**Jeff Bergosh**: No

**Jimmy Staley**: Is there any plan to currently

**Jimmy Staley**: I hope you had happy holidays. 

**Jeff Bergosh**: U too

### CONVERSATION ON 01-26-2022

**Jeff Bergosh**: 👍

**Jimmy Staley**: https://www.justice.gov/usao-ndfl/pr/former-santa-rosa-county-deputy-sheriff-faces-federal-and-state-charges-fraud-related

**Jimmy Staley**: A case Ive been working on a few years. 

**Jeff Bergosh**: I heard

**Jeff Bergosh**: Crazy

**Jimmy Staley**: I brought the grandson to Marie Mattox. Worked with her and FBI for a while.  When this guy came to me no one believed him 

