

## CONVERSATIONS WITH COUSIN SALLY

### CONVERSATION ON 12-06-2019

**Cousin Sally**: Are you at home or at the base?
Please let me know you are alright

**Jeff Bergosh**: I’m good, I was on the way to the base and got locked down in traffic when they shut it down but I’m good and all the guys that work for me are good.  Lots of victims, keep them in your prayers

**Cousin Sally**: I definitely will.😢

### CONVERSATION ON 02-05-2020

**Cousin Sally**: Hey Gang! 
Mom and I are going to be in town next week to check out a piece of property.
Wanted to know if there would be an opportunity to get together next Thursday or Friday.
We are driving in Thursday and driving back early Saturday morning. We know it’s last minute, a tight schedule and Valentine’s weekend.

If it’s doable, fantastic! If it is not, we more than understand.....late notice and short window 

Thanks!😘

**Cousin Sally**: That sounds awesome!!!

**Cousin Sally**: The usual?😜 
...or wherever y’all say. We’re easy!

**Cousin Sally**: Y’all are probably sick of McGuires 😂,
talk amongst yourselves and choose wherever, truly!
we’ll reconnect on Wednesday. We are leaving then and overnighting in Birmingham so I can go on a couple of work appointments.

### CONVERSATION ON 02-06-2020

**Cousin Sally**: Oh my goodness I’m so excited! We’re getting there right in the nick of time :-)

### CONVERSATION ON 02-13-2020

**Cousin Sally**: Hi gang! We are just leaving Birmingham GPS puts us at hotel approx 4:45pm.

Let us know what you’re thinking about tonight. We are good with absolutely anything!

**Cousin Sally**: She turned 75 on 2/7 ! 
We’ve been having a great week!

**Cousin Sally**: Surprise us!! Whatever works for y’all works for us and going back I don’t mind Maguires at all I just always feel that you guys are spending a fortune when we go LOL

**Cousin Sally**: I’m talking into my phone while driving Not sure all that came out rightWe are good with whatever truly. Don’t wanna make this hard LOL we will be staying at Hyatt Place at airport...

**Cousin Sally**: YAYYY!!!😘

**Cousin Sally**: Laughed at “Who’s on first? LOL”

**Cousin Sally**: Beware! We were unable to go to the hotel before so we are more casual than usual 😂 

ETA- 5:21pm

**Cousin Sally**: Awwww!!! She sends A big warm Thank You!!! 
Thank y’all so much!❤️

### CONVERSATION ON 02-22-2020

**Cousin Sally**: Hey Babe!
I want to find out what a property is zoned for for mom to possibly put her little home on.
How can I find that out?

Do they allow modular? Etc.
Beach Haven Neighborhood out Gulf Beach Hwy


405 Winton Ave.
Zip 32507

**Jeff Bergosh**: I’ll get staff to answer it and I’ll get u the info. 😎

**Jeff Bergosh**: Monday or Tuesday

**Cousin Sally**: Luuuuuuv youuuuu!😍😍👍 
THANK YOU!!

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Love u too and no problem at all!

### CONVERSATION ON 02-27-2020

**Cousin Sally**: Hey there, any luck? I’m so sorry to bother you with this!

**Jeff Bergosh**: Hey Sally—sorry for the delay I do have some information to pass.  What email should I send it to?

**Cousin Sally**: MLBlock7@aol.com
Sally.edwards3@gmail.com

No worries on delay. Totally get it. Thanks so much again!

**Jeff Bergosh**: 👍👍

### CONVERSATION ON 05-18-2020

**Cousin Sally**: Hey Gang!
I wanted to say hello while I’m in P’cola, even though we may miss each other. Last week last minute my dad told me about his CT Scan, Nuclear Test, and Echocardiogram that he was having to take!😳🤦🏻‍♀️

Uhhh... I’m thinking that’s kind of important stuff their dad, don’t you think?!🙄 He actually has like 7 different appts between today and tomorrow. We’ll be living up at Sacred Heart.

Anyhow, I grabbed Chase and we all drove down. Dropped Chase off yesterday afternoon to hang with Ben and then he’ll go to a friend of ours from Atlanta that now live  in Santa Rosa this evening and we head back to Nashville on Wednesday.

We’ll be back in June though.

When do y’all go to San Diego for your usual summer trip? I want to all get together.

Love and miss y’all! ❤️

**Cousin Sally**: Thank you and I will!

What. A. Treat! - such a special time to have everyone back under one roof for an extended period of time. I know you are just loving it!!

Great news about San Diego.... well, you know what I mean.... for me at least. 😬😂

I will stay in touch. Please tell all the kids hello! Man o man, I hope they’ll all be close by in June so Chase can see them again😊

### CONVERSATION ON 07-04-2020

**Cousin Sally**: Hey Y’all! Happy 4th!
Just tried to leave Jeff a voicemail but his mailbox is full.
Okay, I’m so bummed!!!

Mike Chase and I are in the truck headed to Pensacola and I just read that they canceled the fireworks at Seville or the blue Wahoos stadium event.😭😭😭😡

Some friends invited us over to their condo in Panama City so we last minute decided to come to Pensacola and then just drive over Monday to meet them.

I text Gary yesterday that we were coming in tomorrow so Chase and Ben could get together and he said we could grill out.

Has the Gulf Coast pretty much shut down??

Why r y’all up to? Kids and everyone doing well?

**Cousin Sally**: ❤️🤍💙

**Cousin Sally**: WOW!!! Great Recap! .... so you can drink but not eat? ....I lasted about 4 days with this total juicing thing I tried. I can’t stand Ginger 😝

When you say drinks, are you talking water Or is it straight Vodka🤣🤣

**Cousin Sally**: Sounds great! I’ll ping you later! YAY

**Cousin Sally**: Omg! I typed that earlier and just realized I never sent it! LOL

**Cousin Sally**: We just pulled into my Dad’s about a half hour ago 

### CONVERSATION ON 07-05-2020

**Cousin Sally**: Hey there!

Where can I take Mike right now for  an awesome best in town shrimp basket?!

I dropped Chase off at Ben’s earlier this morning. Mike and I are headed out the door in search of a good shrimp basket for him and then we were going to head over to Gary’s around 330-4pm-ish. Ben has to work from 5-7:30pm, so I think they’re gonna cook burgers etc.

Thoughts on a good place?😃

**Cousin Sally**: If it was more convenient for y’all to meet us out and have a drink there instead of over at Gary’s that’s cool too. Whatever is best for y’all!

**Cousin Sally**: I only say Gary’s because when I dropped him off they mentioned that y’all may be coming over

**Jeff Bergosh**: Hey Sally that sounds great —my Sally and I will definitely swing by and say hello later this afternoon when you all get back to Gary’s. I suggest the shrimp basket restaurant there are several locations throughout the area there is one on Navy Boulevard there is one on 9 mile road and I believe there is one on Davis highway by T.J. Maxx.  Looking forward to seeing you all!!

**Cousin Sally**: Perfect!!! 👍😘

**Cousin Sally**: Sweet! It 3 miles from my Dad’s!

**Cousin Sally**: Liked “We are on our way!!👍”

**Cousin Sally**: So great seeing y’all! Thank you so much for working us into your holiday weekend so last minute! I sent the pics from Gary’s phone to y’all!
We might need to crop my legs out!!😂
Mom wanted me to tell y’all she missed you and wished she could’ve been with us.
Love you guys!❤️

**Jeff Bergosh**: Love you too Sally!!! Great seeing you all and next time I hope we can spend more time together!  Time flies— can’t believe how big Chase is getting!! You all have a safe trip to Panama City—and have fun!

**Cousin Sally**: Thanks so much! We will! And maybe we hit Beulah for a night on our way into town next time!😃😘

### CONVERSATION ON 08-17-2020

**Cousin Sally**: Hey Cuz!
I am with mom in St. Louis and we briefly spoke with Gary earlier when he was on his way to help you put out signs. We are praying big time for your win!!! 🙏🙌❤️

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thank you Sally!!  I’m feeling confident, but we will know for sure tomorrow at 7:00😎👍thanks for keeping us in your prayers!

**Cousin Sally**: Big big huge Congratutions Jeff!!! 
MUWAHH 

**Jeff Bergosh**: Thank you Cousin Sally!!!!

**Cousin Sally**: So so excited for you!!! Dying to come down and y’all give us the play by play of the days and hours leading up to the final breaking news that you won!!!
Woo Hoooo!!! ENJOY THE EVENING

**Jeff Bergosh**: Thanks we will do that!  It was something else!!

**Cousin Sally**: Emphasized “Thanks we will do that!  It was something else!!”

### CONVERSATION ON 09-16-2020

**Cousin Sally**: How is everyone doing?!

**Jeff Bergosh**: Hey SALLY Gary —-his house is OK my house is OK I got a few trees down but overall I’m good structurally no problems, no flooding no problems.  but Gary lost his brand new boat and his dock and so he’s pretty bummed out ——but everyone’s healthy and safe And that’s what’s most important

**Cousin Sally**: Praise God no one was hurt and I saw the pics that you posted on Facebook. What a mess!!
I’m so bummed for him! .... I know he has to be so disappointed.... please tell me it was insured, right?

What did it finally come in as a Cat 2 or 3? My dad told me it was a 1.

**Cousin Sally**: Mom and I are sitting here just flabbergasted ....we would not have waited this long but we literally have not been doing anything but buried in moving her for the last 72 hours from St Louis to Nashville. Didn’t have a clue. ... we love you both and both of your family so much❤️❤️

**Jeff Bergosh**: Thank you SALLY it came in as a cat to but when everyone went to bed it was us it was a week category one and everyone thought it was a losing strength but then again Stranch and yes he does have insurance thank God

**Cousin Sally**: Liked “Thank you SALLY it came in as a cat to but when everyone went to bed it was us it was a week category one and everyone thought it was a losing strength but then again Stranch and yes he does have insurance thank God”

**Cousin Sally**: 🙌🙌that it’s wasn’t worse.... although Gary‘s video was unbelievable🥴

### CONVERSATION ON 10-25-2020

**Cousin Sally**: Going through boxes and consolidating and ran into this sweet gem!!😘

**Jeff Bergosh**: Wow that was a long time ago LOL!

**Cousin Sally**: Crazy long time ago!!

### CONVERSATION ON 03-17-2021

**Cousin Sally**: Had an absolute blast!!
Tori is an absolute DOLL!!
Love y’all much😘

### CONVERSATION ON 03-18-2021

**Cousin Sally**: Problem Solvers Caucus,
No Labels

**Jeff Bergosh**: It was great to see you and Aunt Mary last night!!  Hope you all can come back soon!

**Cousin Sally**: Loved “Thank you for coming by last night- always a great time!!❤️”

**Cousin Sally**: Loved “It was great to see you and Aunt Mary last night!!  Hope you all can come back soon!”

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Yes Ma'am-- just double checking.  Have a great weekend!

### CONVERSATION ON 05-17-2021

**Cousin Sally**: Can either of you recommend a nice public course to play golf at in Pensacola? That Chase and my mom could go play.😊

**Cousin Sally**: Gotcha!I thought Pensacola country club was private.

**Jeff Bergosh**: Osceola is a really good public course.  Scenic Hills is a good one as well— they have a lot of specials.

**Cousin Sally**: Which do you think offers the wow factor more as far as aesthetically pleasing? LOL and I’ll quit asking questions. 
I think I’m going to have to break it to him that he’s not gonna get a Pebble Beach experience LOL

**Jeff Bergosh**: Neither one will have the Wow factor LOL

**Jeff Bergosh**: But they are both decent public courses

**Cousin Sally**: 🤣😂🤣

**Cousin Sally**: Oooh! Jeff could you spare a few hours one day for 18 holes LOL

**Jeff Bergosh**: I’d love too— but running a million miles per hour rn

**Cousin Sally**: I totally get it!!

**Cousin Sally**: Chase and I are flying in late Thursday night and flying home Sunday. 
Mom and Dad just got down there. (I drove them down and flew home as we had a tournament in Gatlinburg.)

And then all three  of us (Mike, me and chase) will be coming down on 6/23 because about 20 of the Block cousins are doing a full Beach Week in P’cola because one of the girls has a Cheer Competition that week,  but we can only catch a couple days on the tail end because of Chase’s sports schedule.

Was gonna touch base when we got there. Dad and mom planning stuff with Chase kinda like a “Grandparents weekend” since he’s never had one with them.
I have to take dad to Sacred Heart for three scans regarding his aneurysm and other stuff and then meet with his doctor in person this trip. I know that was a lot but that’s where we are at🤪🥴

Plus last week we moved out of one house and into our new house. I am dead. Ass. Exhausted!

Also, Our tournament got switched from Atlanta to Gatlinburg so I didn’t catch up with Jonathan like I had planned, so I’m gonna call Nick tomorrow to reconnect and coordinate a conversation with Jonathan to explore his options.

Jeff, what dates will y’all be going to San Diego this summer? 

Tell the ladies hello!😘

**Cousin Sally**: WOW!!!😳😳😃😃
What fun!!

I had to cram this grandparents weekend in because he literally has travel basketball all through end of July excluding this weekend and one other and then he’s playing football and they have summer practices as well🤦🏻‍♀️
It’s just all too much🙄

**Cousin Sally**: ABSOLUTELY!!

**Cousin Sally**: Just putting a little thought out there....Mom and I were chatting about the possibility of celebrating Christmas down in Pensacola with y’all maybe the weekend before Christmas or two weekends before Christmas or Christmas Eve Eve..... we would just totally love to celebrate when all y’all’s kids are in town. I would love for Chase to have that experience..... even if we’re only able to squeeze a few hours in one day.

In lieu of my dad’s health, I’m telling Mike that I am putting the Block/Bergosh/Edwards Christmas a priority over the grands.😬😬😁

**Cousin Sally**: Loved “I love that idea. I know we can make that work. Let’s discuss dates for all of us. ”

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-01-2021

**Cousin Sally**: Hey Y’all,
Just wanted to let you know my Uncle Vince (dad’s brother) passed last week and I had to plan the whole funeral and arrangements and just got home yesterday.
Have not forgotten about Nick.

**Jeff Bergosh**: I’m really sorry to hear that Sally I’ll keep you all in my prayers

**Cousin Sally**: Thanks Jeff. He suffered for so long. It was time. 93 
We are grateful

**Jeff Bergosh**: How is Ray taking it?  I’m sure it’s tough.....

**Cousin Sally**: It was long overdue. Together we put him in the nursing home on December 16, 2020. That was a hard day. But he could no longer care for him. And then he got Covid pneumonia at Christmas, so i guess it was all part of God‘s divine plan.

Dad himself is doing well. Needs a new back though. 🥴
On oxygen at night and whenever he is at full exertion, but doing well. We go back to the pulmonologist June 17🙏

**Cousin Sally**: Thanks and thanks!I crammed everything I could in that 48 hours we were  in Pensacola 😬😂

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Awesome!!

**Cousin Sally**: OH WOWWW!!
Those are awesome pics!!!
Thanks so much for sending 

**Cousin Sally**: Loved an image

### CONVERSATION ON 08-10-2021

**Cousin Sally**: Hey Cuz!

I just went to work for a media company and I cover one of the counties in middle Tennessee. Quick question – is it illegal if the mayor of a city sells his home in Tennessee and moves to Florida? And the city administrator tells him that he will run things for the next 18 months but just for him to show up at the monthly meetings??🤔

**Jeff Bergosh**: That would be a little in Florida but I don’t know Tennessee law but that sounds sketchy!!

**Cousin Sally**: Verrrry!

I am just the ad sales gal, but when people hear that I’m with the Robertson connection they feel like they need to throw up on me. We don’t have a reporter right now. Our last reporter moved to one of our other newspapers so people are desperate to tell anyone related to the Connection the  dirty laundry!

**Cousin Sally**: You would love us we’re a conservative newspaper we cover things all hyper local. Lots of local sports, too!

**Jeff Bergosh**: 
That’s awesome I’m jealous I would love that kind of work!

**Cousin Sally**: Chase goes to school with them and we go to church with them and they’ve been after me for a few years I’ll fill you in when I see you but oh my gosh I’m drinking water out of a firehose. I told mom I feel like I’m in the kitchen with you and Gary!!! Lol

**Cousin Sally**: Loved “
That’s awesome I’m jealous I would love that kind of work!”

**Cousin Sally**: LOTS OF GROWTH And new commercial construction in the county and my source that wants to remain Unnamed and off the record thinks the city administrator is getting kickbacks and that’s why he is like “sure sure you can move to Florida and I’ll run the county for the next 18 months”🤔🤔

**Cousin Sally**: I’m like damn! All I wanted to do was reserve some space for you in our fall football preview LMAO😂🤣😂

### CONVERSATION ON 11-25-2021

**Cousin Sally**: She’s standing right over my shoulder right now!! Happy happy Thanksgiving to y’all too! We hope y’all had a wonderful day!!
Can’t wait to see everybody soon!

### CONVERSATION ON 11-27-2021

**Jeff Bergosh**: Thanks guys-- great day out there!! See you all next Saturday!

### CONVERSATION ON 12-02-2021

**Cousin Sally**: Hey Jeff!

Are y’all going back to San Diego over Christmas? I heard Sally‘s mom is not doing too well.




**Jeff Bergosh**: Hey Sally!  Happy Belated Thanksgiving— sorry I didn’t see this until just now— was in a marathon BCC meeting this morning where I am now chair of the board.  Yes— we are headed out to SD for Christmas- Sally’s mom has Parkinson’s and is really fading.  Please keep her in your prayers🙏

### CONVERSATION ON 12-03-2021

**Cousin Sally**: Hey there, now I have to apologize for the delay. One of Chase’s best friends unexpectedly died yesterday. Yesterday was a blur ….Absolutely devastating.

Meanwhile, I am heartbroken for Sally. There is nothing like feeling so helpless when you can do nothing for a parent to help them feel better.
I  so sorry Jeff.
We will absolutely keep her in our prayers. I hope you guys have a very special time with her and her family this Christmas. ❤️

**Cousin Sally**: * I am so sorry

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas Greg!

**Jeff Bergosh**: Merry Christmas Sally!!

**Cousin Sally**: Merry Merry Christmas, Jeff!!
I hope the trip is a super special one for all of you and especially Sally and her mom.

