

## CONVERSATIONS WITH ALAN MILLER

### CONVERSATION ON 07-14-2020

**Jeff Bergosh**: Thanks Alan!

**Alan Miller**: Ur welcome sir

### CONVERSATION ON 07-21-2020

**Jeff Bergosh**: Thank you very much Alan!!

**Alan Miller**: Thank in

### CONVERSATION ON 08-17-2020

**Alan Miller**: Good luck Jeff 

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thank you Alan!!

**Alan Miller**: Is the coffee making yet

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: In BCC Meeting

**Alan Miller**: Oh sorry I for got did they hold the exec session 

### CONVERSATION ON 09-10-2020

**Alan Miller**: Still have not heard from billy on our contract proposal 

### CONVERSATION ON 10-06-2020

**Alan Miller**: Another shot across the bow

### CONVERSATION ON 10-29-2020

**Alan Miller**: Did the county decalre a state of emergency
For
A
Just in case hit. 

**Alan Miller**: I am
In a class in key erst will call u next breK

**Jeff Bergosh**: Ok

### CONVERSATION ON 11-19-2020

**Alan Miller**: I cant believe their offer u got a second

**Jeff Bergosh**: In a mtg will call u back

**Alan Miller**: K thanx

### CONVERSATION ON 01-14-2021

**Alan Miller**: Call me when you can sir

**Jeff Bergosh**: I’m in meetings all day but I’ll call you this afternoon

**Alan Miller**: 10-4

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-26-2021

**Jeff Bergosh**: I spoke with Wes.  He told me he will call u this afternoon.

**Alan Miller**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-07-2021

**Alan Miller**: I know ur not there what is the cola

### CONVERSATION ON 09-08-2021

**Jeff Bergosh**: I was out I’ll find out though

**Alan Miller**: Thank you sir we did ratify both contracts last night

**Jeff Bergosh**: 👍congrats!

**Alan Miller**: I had a couple supervisors that are not real happy but will be back in October to try to make things right

**Jeff Bergosh**: Understand completely

### CONVERSATION ON 09-10-2021

**Alan Miller**: All have left since powell arrived 

**Alan Miller**: They have a  collage in the supervisors office

**Jeff Bergosh**: Holy Shit!  Are those former employees, or released prisoners?!?

**Jeff Bergosh**: That’s a lot!!

**Alan Miller**: Former employees

**Jeff Bergosh**: That’s unbelievable Alan!

**Alan Miller**:  Ut he calls that normal 

**Alan Miller**: Thought gou would find it interesting 

**Jeff Bergosh**: I do.  I find it troubling

**Alan Miller**: I find it totally unacceptable. He has failed all goals and objectives to include reporting the issues with leaks and possible mold forming 

### CONVERSATION ON 09-21-2021

**Alan Miller**: State DOC budget request Fot starting salaries is 41600 we are at 35500

**Alan Miller**: Just an interesting fyi

**Jeff Bergosh**: Wow!  We’ve got some catching up to do

**Alan Miller**: Yes we do 

**Alan Miller**: Cola

**Alan Miller**: Sheriffs 6% is approved leave buy back money was removed but will be given later when all happen if done 

### CONVERSATION ON 09-22-2021

**Alan Miller**: Sent that lasr one to wrong j in my directory sorry

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: In mtg rn will call u after Alan

**Alan Miller**: 10-4

### CONVERSATION ON 11-16-2021

**Alan Miller**: Congratulations chairman and we have not heard a word on a negoitiatons date . It appears they are ignoreinf us . And as of dec 31
Your corrections will be the lowest paid in the area

**Jeff Bergosh**: Thanks for the update Allen I’ll double check that for you and see if we can get a date firmed up

**Alan Miller**: Thanks

**Alan Miller**: You would think powell would be pushing the issue

**Jeff Bergosh**: It would be smart for him to do so to help his staffing

**Alan Miller**: I agree but they are steady leaving 

### CONVERSATION ON 11-19-2021

**Alan Miller**: Call me sir please

**Jeff Bergosh**: In mtg will call after

**Alan Miller**: Thanks 

**Jeff Bergosh**: I have a call into Wes he didn’t answer I left him a message so I’ll call you back as soon as I speak to him

**Alan Miller**: Thanks

**Jeff Bergosh**: He’s going to call u

**Alan Miller**: Thanks

### CONVERSATION ON 12-13-2021

**Alan Miller**: This officer was in the er for hours last night.

**Jeff Bergosh**: I heard — hope he’s going to be alright

**Alan Miller**: This is why unndertrained personnel have no business in thise towers. 

**Alan Miller**: He was released last i heard . 

**Alan Miller**: Sorry for the typo's i am not happy

**Jeff Bergosh**: No problem.  This is being looked into

**Alan Miller**: Thank you i hate to be a negative person this is partially result if understaffing

**Jeff Bergosh**: I appreciate the insight 

**Alan Miller**: ￼i try t be realistic

