

## CONVERSATIONS WITH LARRY DOWNS JR

### CONVERSATION ON 01-27-2020

**Larry Downs Jr**: Good morning Jeff, if you would give me a call when you get a chance. Nothing urgent was just wanting to get an update on beach access number four

**Jeff Bergosh**: Sure will Larry.  I’m in a meeting right now but after that I’ll call you

**Larry Downs Jr**: Cool thanks 

### CONVERSATION ON 02-18-2020

**Larry Downs Jr**: This is the post on my Personal Facebook page

### CONVERSATION ON 04-23-2020

**Larry Downs Jr**: Good afternoon Jeff

**Larry Downs Jr**: Just checking to see what’s up

**Jeff Bergosh**: Hey Larry!  Just finishing up a meeting can I call u in 10?

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good afternoon Larry—as a person that has expressed support for my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Larry— thanks for your support and please keep this information confidential.  I want my opponents to remain blissfully unaware of this.........😎👍

**Larry Downs Jr**: Liked “Good afternoon Larry—as a person that has expressed support for my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Larry— thanks for your support and please keep this information confidential.  I want my opponents to remain blissfully unaware of this.........😎👍”

### CONVERSATION ON 05-18-2020

**Larry Downs Jr**: Would you just look at that hypocrisy😜

### CONVERSATION ON 05-21-2020

**Larry Downs Jr**: https://youtu.be/AKAi_4HfPg0

### CONVERSATION ON 06-16-2020

**Larry Downs Jr**: Good morning Jeff

**Larry Downs Jr**: What is this children’s trust hand out?

**Jeff Bergosh**: It’s a ballot initiative we are being asked to add to the ballot so citizens can vote it up or down

**Jeff Bergosh**: It will be up to the voters

**Larry Downs Jr**: Is this going to be put on the regular BLCC meeting before y’all vote to put it on the ballot

**Jeff Bergosh**: Yes

**Larry Downs Jr**: BOCC Cool, thanks a lot I will be there

**Larry Downs Jr**: I’m guessing Quinton Studer Office pushing this LOL

**Larry Downs Jr**: This over taxation never seems to end, just more and more and more Big daddy government

### CONVERSATION ON 07-09-2020

**Larry Downs Jr**: Good evening Jeff, I’m trying to figure out the date of the commission meeting where Cris Dosev spoke about shutting down the abortion clinic

**Larry Downs Jr**: I spoke on the same issue, I just can’t remember the date

**Larry Downs Jr**: Just if you happen to remember

**Jeff Bergosh**: Larry I do remember that as well but I can’t for the life of me remember when that was or what meeting that was—-sorry!

**Jeff Bergosh**: Hey — I forgot to tell you this though-Great News- I was just endorsed officially by the police union, the PBA!!  Can u believe it?  Will miracles never cease?!?  Jonathan thought he had it in the bag.  Wrong again

**Larry Downs Jr**: Cool 

**Larry Downs Jr**: Congratulations my man

**Jeff Bergosh**: 👍👍

**Larry Downs Jr**: The meeting I think was April 2, I found it

**Larry Downs Jr**: 😊

### CONVERSATION ON 08-13-2020

**Jeff Bergosh**: Hey Larry— It’s Jeff Bergosh.  I know you’re busy and I know I am too.  But can we set up a time to get this robocall recorded?  I need to get it to my guy in Orlando so he can set it up to go out tomorrow night.  Just let me know when you’re available.  I can meet you anywhere anytime in the next 24 hours.  Thanks for your support Larry— greatly appreciated!!

### CONVERSATION ON 08-14-2020

**Jeff Bergosh**: Did you get it Larry?

### CONVERSATION ON 08-17-2020

**Larry Downs Jr**: Good evening Jeff, I guess you see I got tied up and couldn’t get back with you till yesterday evening.

Just as well though, I think I am burned out on the campaign trail.

I don’t think I can take much more of it! It really is a sad state of affairs we are in, unreal!

**Jeff Bergosh**: I totally get it!  Thanks Larry!

**Larry Downs Jr**: Yes sir 

### CONVERSATION ON 08-18-2020

**Larry Downs Jr**: Congratulations Jeff😊❤️💯

**Jeff Bergosh**: Thanks Larry

**Larry Downs Jr**: Bad ass, if I wasn’t working I would find out where your celebration party is. Sweating my balls off

**Larry Downs Jr**: Lol

**Jeff Bergosh**: Ha ha no parties I’m going to bed it’s past my bed time!!

**Larry Downs Jr**: Yes sir, grown ups 😊

### CONVERSATION ON 10-05-2020

**Larry Downs Jr**: Hey Jeff when you get a chance, please give me a call.

**Larry Downs Jr**: Nothing pressing just wanted to run something by you.

**Jeff Bergosh**: Okay will do Larry

**Larry Downs Jr**: Thanks man

**Larry Downs Jr**: Here’s you some comedy

**Larry Downs Jr**: https://youtu.be/-C8_cFVv2_o

### CONVERSATION ON 10-15-2020

**Larry Downs Jr**: Good morning Jeff, I hear the pop-up car sales Prohibition ordinance is back on the agenda?

This nothing more than a protectionism overreach law
and it completely goes against free trade/commerce.

**Larry Downs Jr**: I’m too busy to show up there however, I believe this is the third time it’s been put before the commissioners.

**Jeff Bergosh**: It’s not on the agenda

**Larry Downs Jr**: Great 

**Larry Downs Jr**: Please let me know if it gets on the agenda for the next one.

### CONVERSATION ON 03-01-2021

**Larry Downs Jr**: +1 (850) 281-5228 Michael Bearden’s new cell #

**Larry Downs Jr**: He said yes

**Jeff Bergosh**: Awesome!  Thanks Larry

**Larry Downs Jr**: Yes sir, anytime Jeff

### CONVERSATION ON 03-16-2021

**Larry Downs Jr**: My dad is thinking of selling the Parker? If you’re interested? I haven’t told anyone yet.

**Jeff Bergosh**: What’s the Parker Larry?

**Larry Downs Jr**: Shit, wrong Jeff

**Larry Downs Jr**: Lol

**Larry Downs Jr**: It’s a boat

**Larry Downs Jr**: Lol

**Jeff Bergosh**: Oh, okay LOL

**Jeff Bergosh**: Looks nice 

**Larry Downs Jr**: Yes sir, how are you doing Jeff

**Jeff Bergosh**: One of these Days I’ll have time to have a boat again LOL

**Jeff Bergosh**: 
And Doug’s boyfriend lost LOL

**Larry Downs Jr**: 😊❤️💯

**Jeff Bergosh**: 👍👍

**Larry Downs Jr**: That was real good news

**Larry Downs Jr**: You need to get you a boat and come out here to the cove

**Larry Downs Jr**: I’m out here this morning. Spring break week from the fifth graders she teaches for my wife so, I’m playing hooky from work today. She stays out here the whole week and I go into work every other day.😉

I still can’t help but to wake up early LOL

**Jeff Bergosh**: I agree— I need to do it!  One of these days!  Hey, how is it being able to buy beer on Sunday Mornings? 😎👍

**Larry Downs Jr**: My mother went to Publix Sunday morning before coming out here to the cove, she said I was able to buy beer this Sunday morning! She loves it. I’ve had shit loads of people send me messages telling me they love not having to go to the key or to Alabama on Sunday morning before going on the boat

**Jeff Bergosh**: 🍺🍺🍺

**Larry Downs Jr**: ❤️🇺🇸💯

### CONVERSATION ON 06-28-2021

**Larry Downs Jr**: Good evening Jeff, just checking to see if you have I started back with in person coffee Day yet?

**Jeff Bergosh**: I haven’t yet but will be soon.  Hope all is well

**Larry Downs Jr**: Still out here surviving Covid without a vaccine, without a mask LOL

**Jeff Bergosh**: Me too——except I did get the vaccine

**Larry Downs Jr**: Holy shit, well, we need people to be part of the experiment for sure… LOL

**Larry Downs Jr**: Isn’t it nice of us to pay big crooked Pharma billions and billions of dollars for other countries, we are so generous…🤪

**Larry Downs Jr**: It’s probably trillions 👍🏻

**Jeff Bergosh**: We are too generous

**Larry Downs Jr**: maybe it’s the Trojan horse so to speak.🤔😳💉

**Larry Downs Jr**: Liked “We are too generous”

**Jeff Bergosh**: I hope not

**Larry Downs Jr**: 40% of Escambia county citizens 12 years old and up I’ve been vaccinated, but only 12% of our local black citizens have been vaccinated. If it does have long-term consequences, at least it will be good for the black community, even the numbers so to speak.😊

**Larry Downs Jr**: have been vaccinated, not me😉

**Larry Downs Jr**: i’ll be doing a video on that soon, it’s going to be pretty funny I think, of course, others may not think so😂

**Larry Downs Jr**: i’m headed to Barry’s Townhall, can’t wait to see what is discussed

**Larry Downs Jr**: I’ve held true to my word, I haven’t messed with y’all at all for a good while😊❤️💯

**Jeff Bergosh**: True 

### CONVERSATION ON 08-29-2021

**Larry Downs Jr**: Good morning Jeff, somebody just sent me this. What happens if y’all are recommending a vaccine that has severe long lasting side effects in two years from now or four years from now? 
Do the people get who did as they were told, well, Will they get an apology?🤔

### CONVERSATION ON 11-03-2021

**Larry Downs Jr**: Holy shit Jeff, what a beautiful fucking day

**Jeff Bergosh**: Yes it is

**Larry Downs Jr**: You got time for a two minute phone call?

**Jeff Bergosh**: Sure

**Larry Downs Jr**: Thanks 

**Jeff Bergosh**: 👍

**Larry Downs Jr**: Masked time in front of the camera, then just like magic off with a mask lol

### CONVERSATION ON 12-10-2021

**Larry Downs Jr**: I’m going to do the interview with her this week and I will get the real paper work right in front of me. I will take good pictures of it

**Larry Downs Jr**: This is going to be an interesting one because this lady was there 10 days and her daughter is a nurse

**Larry Downs Jr**: I have been communicating with today

**Larry Downs Jr**: Can you send me the video where are you had the doctors on your with Commissioner forum

### CONVERSATION ON 12-11-2021

**Jeff Bergosh**: Absolutely Larry

**Jeff Bergosh**: https://m.youtube.com/watch?v=4CcJ5lS3erA

**Larry Downs Jr**: If I can help just one see-through the idiocy of the masking, and the idiocy of the mRNA freeee vaccine salesmen, well, that’s why I care.

**Jeff Bergosh**: I don’t like the lies

**Jeff Bergosh**: But they are secretly using it

**Larry Downs Jr**: Yes sir, The lies, the hypocrisy, the deception, the propaganda, I’ve seen it since day one. It’s off the chain

**Larry Downs Jr**: Liked “But they are secretly using it”

**Jeff Bergosh**: I’m going to talk to channel 3

**Larry Downs Jr**: Please do, this shit is sickening. 

**Jeff Bergosh**: 👍

**Larry Downs Jr**: Do you have an android phone

**Jeff Bergosh**: iPhone

**Larry Downs Jr**: Just ask anyone with an android phone to do this, this is sick shit.

**Larry Downs Jr**: Yesterday at clubs crawfish

**Jeff Bergosh**: That’s weird

**Larry Downs Jr**: It’s more than weird 🤔

**Larry Downs Jr**: Holy shit that was a good show

**Jeff Bergosh**: Thanks Larry!  Share it on your Facebook !

**Larry Downs Jr**: I’m going to share it on my back up account, I’m about seven days into a 30 day suspension on my primary account LOL

**Jeff Bergosh**: LOL thx!

### CONVERSATION ON 12-15-2021

**Larry Downs Jr**: https://youtu.be/4FY0neu443c

### CONVERSATION ON 12-27-2021

**Larry Downs Jr**: Jeff, can you send me The name of the doctor and contact info for the one who was fired from Sacred Heart

**Larry Downs Jr**: The woman doctor 

**Jeff Bergosh**: Sure will

**Jeff Bergosh**: Dr. Muhuong Nguyen

**Larry Downs Jr**: You wouldn’t happen to have a number for her would you or an email address?

**Larry Downs Jr**: I’ve been trying to find one online however, it’s not looking good.

**Larry Downs Jr**: Please let me know if you have a phone number for her I want to hire her

**Jeff Bergosh**: I have it but it’s on my other phone

**Jeff Bergosh**: I’ll get it to you

**Larry Downs Jr**: Thank you much Jeff

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-28-2021

**Larry Downs Jr**: Good morning Jeff, any word on the number?

**Jeff Bergosh**: Hey Larry.  Her email address is 

Phumh02@gmail.com

**Jeff Bergosh**: Her phone number is

850-525-4196

**Larry Downs Jr**: Holy shit Jeff, thank you so much my man

**Jeff Bergosh**: No problem Larry!

**Larry Downs Jr**: ❤️🇺🇸💯

### CONVERSATION ON 01-04-2022

**Larry Downs Jr**: Holy Shit Jeff

**Jeff Bergosh**: What?

**Jeff Bergosh**: What happened?

**Larry Downs Jr**: I forgot to send this to you last week

**Larry Downs Jr**: https://youtu.be/MgH39jIQWGo

**Jeff Bergosh**: Dr Nguyen wrote the script?

**Jeff Bergosh**: So glad to hear they’ve recovered Larry!!!

**Larry Downs Jr**: Fast recovery and she was pretty sick

**Larry Downs Jr**: I, Lieutenant Colonel Theresa Long, MD, MPH, FS being duly sworn, depose and state as follows:

**Larry Downs Jr**: https://www.deepcapture.com/2021/09/affidavit-of-ltc-theresa-long-m-d-in-support-of-a-motion-for-a-preliminary-injunction-order/

