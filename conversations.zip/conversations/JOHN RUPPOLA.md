

## CONVERSATIONS WITH JOHN RUPPOLA

### CONVERSATION ON 06-16-2021

**Jeff Bergosh**: Yes

### CONVERSATION ON 12-29-2021

**Jeff Bergosh**: Sorry John I missed this I was traveling in California

