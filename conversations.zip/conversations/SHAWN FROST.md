

## CONVERSATIONS WITH SHAWN FROST

### CONVERSATION ON 01-20-2022

**Jeff Bergosh**: Hey Shawn I just got this message my apologies I’ve been running from meeting to meeting to event to event and just came up for air and saw your text I look forward to calling you tomorrow and catching up and we can talk about all the school board races!

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Just stepped into a mtg will call I back

### CONVERSATION ON 01-22-2022

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Will do!

