

## CONVERSATIONS WITH CHANDRA SMILEY

### CONVERSATION ON 04-10-2020

**Jeff Bergosh**: Hi Chandra, I have a patient of yours that reached out to me for some assistance with getting seen.  She’s called multiple times and left messages for the doctor (George Smith) but nobody has called her back.  She ran out of medicine in February.  Can you help her out?  

Her name is Lucille Lynch-Hinkley 

850-712-7191 is her number.  I was going to leave you a voicemail but your mailbox is full.

Thanks very much!

Jeff Bergosh

**Jeff Bergosh**: 👍

**Jeff Bergosh**: No problem.  Thanks for helping her out 🙂

