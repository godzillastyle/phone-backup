

## CONVERSATIONS WITH ROBERT BENDER

### CONVERSATION ON 12-11-2019

**Robert Bender**: Morning

**Jeff Bergosh**: LOL. Good morning Robert!

**Robert Bender**: We need 1 more at TPO to have enough to vote if you can make it. At Tiger Point. 

**Jeff Bergosh**: Unfortunately I can’t.  We sent notification on Monday

**Robert Bender**: Apparently one called in sick today, so we ended up being short

**Jeff Bergosh**: I’m at NAS there’s a lot going on here.  Sorry Robert

**Robert Bender**: No worries. Thanks. 

**Robert Bender**: Of course. Understand. 

### CONVERSATION ON 12-20-2019

**Robert Bender**: Not much, but it is a start...

**Jeff Bergosh**: Yeah I drove it this morning when they were fixing it it will help a little but in March of this year when they go all the way to Beulah Road that will be the best and final fix for now

**Robert Bender**: Liked “Yeah I drove it this morning when they were fixing it it will help a little but in March of this year when they go all the way to Beulah Road that will be the best and final fix for now”

### CONVERSATION ON 07-29-2021

**Robert Bender**: Jeff, I’m in Orlando for MPOAC if they need anyone to do a press conference re: plane crash Laura just sent out. Letting you know I am not available. 

**Jeff Bergosh**: Okay thanks I’ll take it if it comes to that.  Probably Wes or Eric would be better though

**Robert Bender**: Liked “Okay thanks I’ll take it if it comes to that.  Probably Wes or Eric would be better though”

**Robert Bender**: Hopefully we have positive outcomes. 3 being treated. 

**Jeff Bergosh**: 🙏🙏🙏

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: Good Morning Robert:  I heard the devastating news about your father and I want you to know you have our sincerest condolences— we’re so sorry for your loss.  Sally and I are keeping you and your family in our prayers. 🙏🙏

**Robert Bender**: Thank you Jeff. I appreciate you thinking of us and your prayers. Thank you. 

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 12-14-2021

**Robert Bender**: Jeff, just letting you know I am doing lunch for PW guys at the garage tomorrow at 11:30. They weren’t going to have their normal holiday party.

**Jeff Bergosh**: Thanks for doing that Robert!

**Robert Bender**: Feel free to stop by if you can make it. 

**Robert Bender**: Wes is smoking turkey

**Jeff Bergosh**: Thanks for the invite Robert!

### CONVERSATION ON 01-26-2022

**Jeff Bergosh**: Robert:
I nominated you to be chairman of the estuaries policy board for 2022.  The board voted unanimously for this so you are now the chair of this board.  Congrats!

Jeff B

**Robert Bender**: Thank you Jeff. Sorry I missed the meeting, down here in Orlando for MPOAC. Welcome to the estuaries board. 

