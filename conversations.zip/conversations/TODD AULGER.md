

## CONVERSATIONS WITH TODD AULGER

### CONVERSATION ON 08-15-2020

**Jeff Bergosh**: Thanks Todd!!

**Todd Aulger**: You’re welcome. Love the pic 

### CONVERSATION ON 08-18-2020

**Todd Aulger**: Congratulations!!  You da man!!!!!  Proud of you.  You don’t lose. All you do is win win win!!!!

**Todd Aulger**: 😀

**Jeff Bergosh**: Only because I have great friends like you!!!  Thank you Todd!!

### CONVERSATION ON 09-19-2020

**Todd Aulger**: I don’t have FB but this is my comment. Terry wouldn’t let me say other stuff. That’s why I don’t have a fb. I will tell them to fuck. lol. Thanks for what you do. 

**Todd Aulger**: But i wanted to say if you don’t like it move to another district. And you don’t like America and Trump then bet they fuck out.  Sorry for the language but I’m pissed. Don’t know how you do it. 

**Jeff Bergosh**: Thanks Todd!!  These guys are a-holes They have no idea how hard I’m working they just want to throw rocks at me a bunch of pricks

**Jeff Bergosh**: Thanks to you and Terry for having my back!

**Todd Aulger**: Yes sir. I will always have your back.  

**Jeff Bergosh**: I can’t tell you how much that means to me thank you so much!

### CONVERSATION ON 08-09-2021

**Todd Aulger**: https://youtu.be/3ubRqR90V2w

**Todd Aulger**: Wanted to share with you what we had to watch for today diversity training.  It was made here in Escambia county.

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: Wow.  I saw this yesterday Kevin Adams actually shared it with me also.  So we have to respect some students first before they respect the teacher and the rules.  I also didn’t know everything was twice as hard for some students but not for others based solely on skin color.  👌👌Wow I’m really out of it I guess

**Todd Aulger**: Yes I called Kevin yesterday. Lots of teachers not happy about that video. This is what causes racism.  Im appalled. Can’t believe we were made to watch this.  We have teachers contacting the Governor. I didn’t realize out superintendent is so far left that he would approve of this video.  We as a district are in trouble. But just my option!

**Todd Aulger**: So who do you think is the best person to contact about this video? 

**Jeff Bergosh**: Todd I would contact each member of the school board now that we have an appointed superintendent they have a lot of influence over him and I would just express your displeasure with being made and forced to watch this propaganda

**Jeff Bergosh**: While I support the appointed superintendent model this is a great example of why it is beneficial the School board can walk him back from this garbage or they can fire them and bring in a conservative they have the power now I’m like being trapped with Malcolm and his garbage for 12 years

**Todd Aulger**: Sounds good. Will we get any backlash contacting people about this video?  That’s what other teachers are afraid of 

**Jeff Bergosh**: I’d only recommend Teachers with continuing contracts do the talking because there are potential consequences toward speaking up. I’d also copy the union leader ship although they are going to be sympathetic toward the contents of the video lol

**Jeff Bergosh**: Or you could send a letter anonymously hardcopy to each board member expressing the frustration and anger and disappointment but also expressing fear of backlash

**Todd Aulger**: Ok thank you so much 

**Jeff Bergosh**: 👍

**Todd Aulger**: No luck. I have one guy calling me back but he’s in a meeting right now 

**Jeff Bergosh**: Right on.  No problem I know it’s an awkward request.  I have one teacher who’ll do it plus Kevin Adams did an interview so it will be on tonight on WEAR.

Talk to you soon Todd, it was good to talk to you today!

### CONVERSATION ON 09-05-2021

**Todd Aulger**: Hey. We are at casino beach bar and grill having drinks. Y’all come out and have some drinks. Then we are going to watch Lee play at paradise at 2:30

**Jeff Bergosh**: Right on Todd we’re laying out at the beach right now but we’re gonna head that way and see you guys over there at 2:30

**Todd Aulger**: 👍🏼

### CONVERSATION ON 09-23-2021

**Todd Aulger**: So after 30 plus years of playing softball I’m finally going to stop playing. With that said I’m looking to get in to tennis. I seen where there’s a mens clinic on Tuesday nights at Roger Scott and a league. Do you do either of those or do you know anything about them or maybe a different league??

**Jeff Bergosh**: Hey Todd there is a under the hill league every Wednesday evening and it’s 50 year old plus it’s a real popular league I think there’s over 200 players in it you might wanna look into that one

**Jeff Bergosh**: When I’m done with politics I’m gonna get in that when I have time LOL

**Todd Aulger**: Ok I seen that league.  Is it all skill levels?? 

**Todd Aulger**: Think I’m going to go to Roger Scott this coming Tuesday and do the mens clinic and then see about the league. Thank you.

