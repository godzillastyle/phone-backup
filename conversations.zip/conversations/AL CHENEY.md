

## CONVERSATIONS WITH AL CHENEY

### CONVERSATION ON 12-23-2019

**Jeff Bergosh**: Got it!  I’ll ask staff to look into this issue to see what can be done

**Jeff Bergosh**: Merry Christmas Al and Ed!

### CONVERSATION ON 05-01-2020

**Jeff Bergosh**: Me too!  Tell the Governor to let them open again!!  I’ve sent that message!

