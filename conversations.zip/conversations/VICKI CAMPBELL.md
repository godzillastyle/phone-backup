

## CONVERSATIONS WITH VICKI CAMPBELL

### CONVERSATION ON 11-07-2019

**Vicki Campbell**: Have they decided not to build the school on Sorrento?

**Jeff Bergosh**: I’m not sure.  I think they are planning to build it, they bought the land for it

### CONVERSATION ON 11-18-2019

**Jeff Bergosh**: In BCC meeting

### CONVERSATION ON 12-06-2019

**Vicki Campbell**: No need to call me back. I was just checking on you I know you work at the base I saw online that you’re OK

**Jeff Bergosh**: Thanks Vickie it was a crazy morning and lots of bad stuff happening but I appreciate you calling me in and the guys that work with me we’re all good but please keep the victims in your prayers

**Vicki Campbell**: I’m in tears!  Praying for you all!  I hear many already hitting Local hospitals. Be safe

**Jeff Bergosh**: It’s crazy

**Vicki Campbell**: I heard they shot him!  🙏🙏🙏

**Jeff Bergosh**: Yes

**Vicki Campbell**: Can you go to breakfast or lunch with me soon?

**Jeff Bergosh**: Sure

**Vicki Campbell**: Monday?

### CONVERSATION ON 12-14-2019

**Vicki Campbell**: Do you know if anyone at the base is hiring someone with degree and some experience in supply chain logistics management???

### CONVERSATION ON 01-28-2020

**Jeff Bergosh**: Hi Vicki—I’m still at work at NAS.  Let me know when you are headed to the Pine Forest Road site

**Jeff Bergosh**: ?

**Vicki Campbell**: We are just on round one of choosing the new administrator and taking a break.  I want there to be plenty of daylight left when we meet.  You want to give me a couple alternate options?

**Jeff Bergosh**: Sure

**Vicki Campbell**: Monday afternoon

**Jeff Bergosh**: I could do that.  4:30 work for you?

**Vicki Campbell**: Perfect

**Jeff Bergosh**: Right on I put it on the calendar

**Vicki Campbell**: Thank you Jeff.  We narrowed our search to 6 today

**Jeff Bergosh**: Congrats.  Did Jack Brown make the short list?

**Vicki Campbell**:  No sir.  

### CONVERSATION ON 02-03-2020

**Jeff Bergosh**: On way

**Jeff Bergosh**: On other line

**Vicki Campbell**: You want to just come over to the front of the ECUA building on Godwin and we can drive back with Keith to look at the area

**Vicki Campbell**: I’ll be waiting out front white BMW

**Vicki Campbell**: Thanks again for looking at the site today.  We should get together with our spouses one night for cocktails or dinner.

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Yay!! I got my new cans today thank you Vicki!!!

**Vicki Campbell**: LOL - very nice!  Nicer than mine for sure :).  Thanks again.  I’ll send you a map too.  Look for it.

**Jeff Bergosh**: Thx will do

### CONVERSATION ON 02-06-2020

**Vicki Campbell**: Nice poll results!

**Jeff Bergosh**: Thanks.  It’s interesting to me that In my poll that I ran the same weekend  with Gravis Marketing using the voter list from Stanford’s office——there were a lot more undecided(s) Jonathan had a higher percentage (13%)then in ricks poll—and my lead over Jesse was significantly larger in my Gravis poll.  So who knows right?  Polls are funny things but Greg thinks polls have a history of being very in accurate (not to mention the fact that I believe he is working for Jesse Casey’s campaign) ..........😗

**Jeff Bergosh**: *Fink’s

**Vicki Campbell**: Sounds about right

### CONVERSATION ON 02-13-2020

**Vicki Campbell**: Just checked out Jonathan’s first report!  $4,000 from Mark ?  WTH

**Vicki Campbell**: Call me tomorrow

### CONVERSATION ON 02-21-2020

**Vicki Campbell**: Image 

**Vicki Campbell**: Sorry image wouldn’t copy.  I’ll try again when I’m in the office but another truck tipped over at the landfill this week. Driver is OK but the truck is not. The county transfer station is closed every Thursday and Friday now because they are at capacity. This is now a crisis. Do you know where we are on your end?  Ratepayers also known as taxpayers pay for those trucks. Worse than that we can’t afford to lose another truck with all this growth in Beulah!  Call me Monday if you can.  Let’s get this ball rolling Jeff

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: Hey Vicki I just wanted to reach out and let you know that tomorrow morning at 6:30 AM at the McDonald’s on blue Angel and Highway 98 we will be having our monthly coffee with a commissioner event if you’d like to swing by and join the conversation.  I just wanted to extend the invitation to you.

Jeff B

**Vicki Campbell**: Sure thank you!  Is it ok that I come in golf clothes you think?  I’m taking half a day off

**Jeff Bergosh**: Absolutely

**Vicki Campbell**: K

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: I’m in the gulf power conference I’ll call u after this session

**Vicki Campbell**: No rush

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-27-2020

**Jeff Bergosh**: Vicki—check out this article.  Has ECUA curtailed disconnection of water for non-payment to ensure everyone has water to wash their hands through this pandemic?

**Vicki Campbell**: Yes!!

### CONVERSATION ON 04-06-2020

**Vicki Campbell**: You want update from ECUA for your coffee with commissioner?

**Jeff Bergosh**: Sure

### CONVERSATION ON 04-27-2020

**Jeff Bergosh**: Hi Vicki- we are playing phone tag.  I’m going to send you the contact information for a ECUA customer who wants to go from septic to sewer and has a lot of questions about cost and how long it would take if you could call her I would greatly appreciate it she’s a friend of the family.  Thanks Vicki!

**Vicki Campbell**: Thanks a Jeff - you need to do a coffee with commissioner and invite me 

**Jeff Bergosh**: We will do that!

**Vicki Campbell**: 😄

### CONVERSATION ON 05-11-2020

**Jeff Bergosh**: Vicki—this is the gentleman I spoke with you about—needs some assistance from ECUA.  Thanks!

**Vicki Campbell**: I’ll call him this evening

**Vicki Campbell**: I got out of my meeting too late. I will call him in the morning.  I’ve asked staff to see if we have any calls on it.  

**Vicki Campbell**: You are wrong on this Innerarity issue.  

### CONVERSATION ON 05-12-2020

**Jeff Bergosh**: Let’s discuss it today.  I believe I’m right based upon new information I just received yesterday

**Vicki Campbell**: Let’s do.  I would love to hear more.

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: I got my results from Gravis back today, I had a question on your race in there, here’s how it came out

**Vicki Campbell**: Thank you Jeff

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-14-2020

**Vicki Campbell**: Even if you do a waste to energy plant you will need this landfill cell

**Vicki Campbell**: Palm Beach has a 650mil plant and still have a landfill

### CONVERSATION ON 05-20-2020

**Vicki Campbell**: Great job and thank you for the invite

**Jeff Bergosh**: Thanks guys!

**Vicki Campbell**: Me too Janice.  I think the people appreciate them too

### CONVERSATION ON 05-21-2020

**Vicki Campbell**: Got some good news

**Jeff Bergosh**: I’ll call you in the morning—I can’t wait to hear good news!

**Vicki Campbell**: 👍

### CONVERSATION ON 05-22-2020

**Vicki Campbell**: Call when you can - more on TS

### CONVERSATION ON 06-08-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 06-25-2020

**Jeff Bergosh**: .........but there are high numbers of undecideds in your race, 72% undecided

**Vicki Campbell**: I heard from 3 people today they called people in D4?  They asked me if I did it.

**Jeff Bergosh**: I used the list of D1 absentee voters provided by the SOE plus all registered D1 voters.  Not sure if some absentees are on that list that could live in D4—-but I doubt it.

**Vicki Campbell**: Oh got ya.  Well let them wonder

**Jeff Bergosh**: 😎👍

**Vicki Campbell**: Getting crazy 

**Jeff Bergosh**: Yes.  I’m astonished about how Jesse is pulling further and further ahead of Doug’s Secretary.  For second place.......I’ve got a nice double digit lead over Jesse—and yet Jesse is now 16 points ahead of Jonathan!!  Love it!!👍👍😂😂

**Vicki Campbell**: Wow

### CONVERSATION ON 07-07-2020

**Jeff Bergosh**: Good morning Vicki- I got a call yesterday evening from a Mrs. Simpson.  She’s a D1 constituent looking to go from Septic to sewer.  I told her I’d give you the message.  850-944-6007.  Thanks!

**Vicki Campbell**: I’ll call her

**Jeff Bergosh**: Thx

**Vicki Campbell**: Thank you

**Vicki Campbell**: You doing ok?

**Vicki Campbell**: Tell Sally and Debbie hello

**Jeff Bergosh**: Yep how about you?  And yes I will tell them hello thx

**Vicki Campbell**: Doing great just trying to raise last minute money for mailing

**Jeff Bergosh**: I hear ya.  

**Vicki Campbell**: Someone is destroying signs.  Let me know if you see any that need attention and I’ll do the same.

**Jeff Bergosh**: Thank you I’ll do likewise

**Vicki Campbell**: 👍

### CONVERSATION ON 07-10-2020

**Jeff Bergosh**: Hey Vicki- I think I might need some assistance from ECUA.  Over the last several days I have noticed that there is water seeping up through my driveway and running down the driveway off and into my yard. I’m concerned it could be an EC you a water line underground that has burst. Is there anyway that someone could check my meter and check on this to see if it’s a water line break? If so who do I call?

**Vicki Campbell**: I’ll get Someone to call you - cell phone ok

**Jeff Bergosh**: Yes.  Thanks very much Vicki!

**Vicki Campbell**: Want to be a hero?  Call me

### CONVERSATION ON 08-18-2020

**Vicki Campbell**: Good Luck tonight!

**Vicki Campbell**: Congratulations!

**Jeff Bergosh**: Same to you Vicki!!  

**Vicki Campbell**: Tell Sally congrats too!  I know your family works hard too!! You worked harder than your opponents

**Jeff Bergosh**: Will do!! Thank you!!

**Vicki Campbell**: Sorry butt dial

### CONVERSATION ON 08-21-2020

**Vicki Campbell**: Hey call me when you’re back in town I know you’re on vacation. Let’s talk about this transfer station and get it done over the next year and the people will love you!  I’ll give you all the credit when it goes well and take all the blame if anything doesn’t but it will be great I promise!

### CONVERSATION ON 09-11-2020

**Vicki Campbell**: Can I call you later?

**Jeff Bergosh**: Sure

**Vicki Campbell**: I’m free when you can call

**Jeff Bergosh**: R u still calling today?  I had 11:15 on the calendar?

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: Hi Vicki-- I hope you and Mike are doing okay and that you got through the storm okay.  Some residents are asking if ECUA trucks are running today, picking up trash.  Are they?

**Vicki Campbell**: Always know we are running when you have the landfill open - the two go hand in hand - so yes we will both begin services on Thursday Today.  We won't be doing recycle as that facility was damaged.   I just asked Woody if people can use the recycle can for a second garbage can until the facilities back up. I'll let you know the answer soon as I have it. I'll start sending you my updates. I send them to many.

**Vicki Campbell**: PS As you can imagine Perdido Bay country club was hit pretty hard. We had a tree on the roof but the tree man was here yesterday and took it off. No damage to the roof. My office in Perdido is gone.  But we were renting and we got pretty much everything important out before the storm.  Running out of a friends office for the interim. 

**Vicki Campbell**: How did you and Sally do?  Tell her hello for me.  Scary night for sure out here.  Lots of damage in our subdivision 

**Vicki Campbell**: Everyones pressure will be low because we are running all the live stations with generators. Once got power restores the power we will switch to lift stations to power and they will resume normal pressure. I hope this help.  If you have Internet please share as I do no.

**Jeff Bergosh**: Vicki thanks for the update will share

**Vicki Campbell**: Power should be back everywhere within 7 days per gulf power 

**Vicki Campbell**: Boil water county wide until further notice.  There were several maim breaks but staff is working on all so notices will be via phone

**Vicki Campbell**: Important we have correct phone numbers - Those who do are getting phone calls. My neighbors are all getting them. They have my home line which I don't answer but of course I'm getting emails

**Vicki Campbell**: The things we learned during storms

**Jeff Bergosh**: Wow 7 days until power is back on???  Lots of folks will be bummed out

**Jeff Bergosh**: Thanks for info

**Vicki Campbell**: 7 before all will be back 

**Vicki Campbell**: Some sooner I'm sure

**Vicki Campbell**: Main line down

**Jeff Bergosh**: I hope so-- thanks for the info

**Vicki Campbell**: I'll keep sending you my updates 

**Jeff Bergosh**: Thx Vicki

**Vicki Campbell**: All lift stations now on generators so water pressure will be low but running

**Vicki Campbell**: Boil water for one minute before drinking

**Vicki Campbell**: Or 8 Drops of bleach per gallon of water

**Jeff Bergosh**: Thanks-- I'm just using bottled at the moment.  I've got both cans full -- do u think they'll pick them both up?

**Vicki Campbell**: ECUA Issues System-Wide Precautionary Boil Water Notice -PBWN-¿¿ ¿¿Effective immediately, the Emerald Coast Utilities Authority is issuing a system-wide Precautionary Boil Water Notice -PBWN- to its water system customers.  This notice is in response to the significant and wide-spread damages sustained from Hurricane Sally.  ECUA crews are already out in the field working to locate, isolate, and repair main breaks in order to restore service as quickly as possible. 

**Vicki Campbell**: Although the majority of our customers remain in service, there are too many main breaks that require a PBWN for it to be practical to issue separate notices during this initial emergency response.  Once the number of pending repairs is significantly reduced, the ECUA will revert to issuing separate notices for individual areas. We ask for our customers’ patience and understanding as we work to repair hundreds of breaks, giving priority to our hospitals, dialysis centers, and other critical care facilities.

Residents are advised to boil water for one minute at a rolling boil or to use 8 drops of regular unscented household bleach per gallon of water, for water to be used for drinking or cooking purposes.  

**Jeff Bergosh**: Hey Vicki I have a quick question for you and it's really important can you please call me when you get a second?

**Jeff Bergosh**: It's about an ECUA lift station at NASP that's overflowing-- very important

**Vicki Campbell**: Text no cell

**Jeff Bergosh**: Vicky who at ECUA Can we contact to assist with an overflowing lift station aboard NAS Pensacola

**Vicki Campbell**: (850) 426-3224 Bruce Woody

**Vicki Campbell**: New admin 

**Vicki Campbell**: My phone not working

**Vicki Campbell**: All BOCC and ECU A boards need to invest in a satellite radios before next hurricane season

**Vicki Campbell**: I can text so send me any questions you need Jeff - give all BOCC mine and WOODY's cells

**Vicki Campbell**: Thank you for all your hard work sir!!!

**Jeff Bergosh**: Thank you Vicki!

**Vicki Campbell**: 👍👍

**Vicki Campbell**: I think we are pumping as much as we can - they have taken on a lot of water inflow so may take some time.  

**Vicki Campbell**: Need your help

**Vicki Campbell**: I have an elderly lady in need - son is here in town.  We need someone to help her - who should we call - she is not coherent 

**Vicki Campbell**: Who do we contact for that

**Jeff Bergosh**: She needs to be Baker Acted and brought to Lakeview Center.  Call ECSO and have a deputy come by to assess the situation

**Jeff Bergosh**: This will keep her from hurting herself or anyone else

**Vicki Campbell**: To

**Vicki Campbell**: Thanks

**Vicki Campbell**: We called ESCO and they called and gave her son a choice and he said he's coming to get her

### CONVERSATION ON 09-24-2020

**Vicki Campbell**: Residents asking if there is a place they can take debris if the want to move it themselves?

**Jeff Bergosh**: I think the contractors have to pick it up themselves that's the only way they get paid 😑

**Vicki Campbell**: Ok - Thank you someone needs to tell Johnathan

**Jeff Bergosh**: I mean folks can always take it out to the landfill and pay the tipping fee ----but a lot of them are breaking the rules already and just picking up and dumping it on streets which is uncool.  but yeah these guys from the state only get paid based on the tonnage that they move and pick up

### CONVERSATION ON 10-09-2020

**Jeff Bergosh**: I don't have a cell phone number for her but she is on Facebook I would recommend that you reach out to her and maybe private message her

**Vicki Campbell**: Where is she on Facebook

**Jeff Bergosh**: Not sure.  Her name is Amy Smart

**Vicki Campbell**: I don't see it on any sites that Im on and She hasn't contacted me

**Vicki Campbell**: OK I just found it on Escambia citizens watch. I informed her several times to email me her address and I gave her my phone number. She has never called she has never emailed. She did talk to someone at ECUA they did come out I do think the problem was not an ECUA issue But again she never emailed or called me

**Vicki Campbell**: No one at ECUA has heard from her

### CONVERSATION ON 10-11-2020

**Vicki Campbell**: I sent a claims guy out to see she lives next to the stormwater pond 

**Vicki Campbell**: And across from lift station

### CONVERSATION ON 10-12-2020

**Jeff Bergosh**: Hi Vicki-- the ECUA crew came out and fixed their pipe under my driveway--however it appears it is leaking once again. It's leaking under my driveway so I'm hoping that they can come back out and repair it soon before it undermines the foundation of my driveway. Can you please forward this to your maintenance department to see if they can get this fixed? Thanks Vicki

**Vicki Campbell**: Address?

**Jeff Bergosh**: 5905 Forest Ridge Circle Pensacola, FL 32526

### CONVERSATION ON 01-06-2021

**Vicki Campbell**: Jeff

Have you met with Tim Pyle yet?  Will you?  

**Jeff Bergosh**: Hi Vicki- Happy New Year.  I was out in San Diego for the holidays and got back late last night.  I'm going to call Tim back when I come up for air-- walked back into a tornado of work

### CONVERSATION ON 03-23-2021

**Vicki Campbell**: Can you call me this week? 

### CONVERSATION ON 03-26-2021

**Vicki Campbell**: Can I call you later?

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-23-2021

**Vicki Campbell**: What company do you work for on Base?

**Jeff Bergosh**: Pensacola Base Support Services in the prime contract I work under.  It’s the BOS (Base Operating Support) contract.  My annex is under a different, out of state firm we are a sub to the prime.  Why?

**Vicki Campbell**: I have a young good A&P licensed mechanic that is interested in being out there.  He’s at ST engineering now.

**Jeff Bergosh**: Oh okay

### CONVERSATION ON 06-03-2021

**Vicki Campbell**: Jeff I think the citizens trust Janice and want her to work out her contract.  No one is perfect for that job but citizen trust is hard to find 

**Jeff Bergosh**: Thanks Vicki

**Vicki Campbell**: I’m worried this looks bad for our BOCC and I know you will do the right thing

**Jeff Bergosh**: Thank you— I always try as best as I can 🙂

**Vicki Campbell**: I know you do.  Being a leader in this county is not a cake walk.  

### CONVERSATION ON 06-10-2021

**Vicki Campbell**: I would like to join you for a town hall if you do another!

**Jeff Bergosh**: Okay will do!

**Vicki Campbell**: Thank you - just like to answer any questions about the yard waste pick up us and the city are experiencing but answer any other questions 

### CONVERSATION ON 06-14-2021

**Jeff Bergosh**: Hey good morning Vickie I know there was that line break on 9 mile road this morning however I noticed water coming out kind of milky white is that because of any chemicals you guys are treating the lines with?

**Vicki Campbell**: I don’t think so but I’ll get the answer for you

**Jeff Bergosh**: Thx Vicki!

**Vicki Campbell**: Might be lime

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Safe?

### CONVERSATION ON 06-17-2021

**Vicki Campbell**: I’m an insurance person 45 years - if I tell you to settle it’s because I can’t win or it’s cheaper than going to court for me and you. I agreed with that vote  regardless of outcome of the case which could go either way.  I don’t know those facts.  Meeting has been interesting 

**Jeff Bergosh**: Yes these meetings get interesting from time to time 😎thanks for being here

**Vicki Campbell**: I would like to keep Janice - at least through end of her contract - no admin is perfect but she cares about the county 

### CONVERSATION ON 06-22-2021

**Vicki Campbell**: Are you changing Perdido Beach to D1

### CONVERSATION ON 09-17-2021

**Vicki Campbell**: I would love to work together with you on flood prevention I think we need to look at the entire region and identify the sources upstream.  Hillary Bauer at Baskerville is an expert in this field.  Let’s set up a meeting

**Jeff Bergosh**: Sure, let’s do that

**Vicki Campbell**: Ok I’ll see what I can set up - give me a couple days snd times good for you?

**Jeff Bergosh**: Okay

### CONVERSATION ON 09-28-2021

**Vicki Campbell**: Let me know if I can do anything to help you on redistrict and let’s sit down on an idea I have for you on flooding

**Jeff Bergosh**: Okay

### CONVERSATION ON 09-29-2021

**Jeff Bergosh**: Kevin/Vicki:

I just forwarded you both a proposed map of what I believe would be a good post redistricting district 1. Please take a look and give me your thoughts ahead of next Tuesday's meeting. Thanks!

Jeff B

**Vicki Campbell**: Which email Jeff?

**Jeff Bergosh**: ECUA

**Jeff Bergosh**: Vicki.campbell@ecua.Fl.gov 

### CONVERSATION ON 10-06-2021

**Vicki Campbell**: Just Watched the full meeting for redistrict.  Appreciate both of you working on those numbers.  Can't believe D2 Commissioner didn't show?

### CONVERSATION ON 10-07-2021

**Jeff Bergosh**: Thanks Vicki.  I thought it well also-- can't believe Doug blew it off.  He's obviously checked out.....

**Vicki Campbell**: One can only pray.  I just want to be done with all that drama and start work on issues 

**Vicki Campbell**: Let's meet soon - I have some ideas on stormwater drainage

**Vicki Campbell**: Thanks for taking time out to pop in and help.  Keep me posted 

### CONVERSATION ON 10-28-2021

**Vicki Campbell**: Are you still good for tomorrow at 11:15 - any chance we could make it 11:30??

**Jeff Bergosh**: Good to go.  11:30 works well for me too, so see u then

### CONVERSATION ON 10-29-2021

**Vicki Campbell**: What email address do you want me to send these maps to?

**Jeff Bergosh**: District1@myescambia.com

**Vicki Campbell**: Maps sent and thank you again

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-01-2021

**Vicki Campbell**: Nice talk with Joy this morning - she totally understands the issue and agrees no more homes can be built here

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-11-2021

**Vicki Campbell**: Do you think your board is going to approve the Beach Haven project completion?  This is so important.  Our board approved more funding.  I certainly understand cost overruns these days and appreciate anything you and your board can do to make this happen so that we don’t have to forgo the matching grant funds.  

**Jeff Bergosh**: I think it will pass however the funding might come from several sources including Doug’s discretionary LOST funds 😎

**Vicki Campbell**: That’s great news!  Thank you Jeff.  I heard from other board members too!  I appreciate your boards work to make this project happen. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-16-2021

**Vicki Campbell**: Thank you for passing Beach Haven!

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-02-2021

**Vicki Campbell**: If you want to talk to me after you read that email call me.  I’m trying to settle the roars

### CONVERSATION ON 12-05-2021

**Vicki Campbell**: Water out in your sub?  A major pipe at NFCU blew out.  T where an 8” ties into a 16”.  They are working on it and things should be restored quickly.

**Jeff Bergosh**: Yes it is.   Here and nature trail.  Thx for the heads up.

**Vicki Campbell**: I let nature trail know - does your sub have a Facebook page?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Do you have an eta for restoration of service?

**Vicki Campbell**: Might be a couple hours with a major pipe like that

**Jeff Bergosh**: Any updates Vicki?  We’re still without water at Bell Ridge Forest 

Thanks!

**Vicki Campbell**: They just turned water back on and are flushing the pipes

**Vicki Campbell**: Big pipe

**Jeff Bergosh**: Wow!!

**Jeff Bergosh**: Thanks Vicki

**Vicki Campbell**: Boil for 48 hours

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: Hey Vicki— just wanted to send thanks to you and the crews at ECUA for getting the water back on yesterday!

**Vicki Campbell**: You are welcome Jeff.  It was a large break and they worked hard.  I’m always thankful for these essential employees in difficult times.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: How did it blow out Vicki?  Were they working on it at the time?  Another project?  It just seems odd it blew out like that in the picture if there was not something that hit that pipe???

**Vicki Campbell**: PVC pipe failure.  Hard to say.  Could have been installed in a bind.  I’m sure they will get to the bottom of it.  Shouldn’t be age as it appears to be a fairly newer pipe.  

**Jeff Bergosh**: That’s really weird.  It’s newer pipe from the NFCU build out era—- should not have blown out like that so soon after installation.  It’ll be interesting to learn more

**Jeff Bergosh**: Thanks again Vicki!

**Vicki Campbell**: I’ll keep you up on it.  Probably just pipe failure.  I’m more a fan of ductile iron on pipes this size.  

**Vicki Campbell**: Should still be under warranty from FDOT’s contractor.

**Vicki Campbell**: This was what went out


Effective immediately, a Precautionary Boil Water Notice -PBWN- has been issued by the Emerald Coast Utilities Authority to customers located in the following area:
    •    Bell Ridge Dr.,
    •    Forest Ridge Dr.,
    •    Bell Ridge Trail,
    •    Patrick Ln.
This notice is being issued after repairs were made to a broken valve connected to a 16-inch main. Precautionary Boil Water Notices are issued as a part of the standard protocol following any loss of water pressure, whether as a result of planned maintenance activities or unscheduled repairs.
Residents located in the specified PBWN area are advised to boil water for one minute at a rolling boil or to use 8 drops of regular unscented household bleach per gallon of water, for water to be used for drinking or cooking purposes. Two independent bacteriological samples have been initiated and the advisory will be lifted as soon as possible. This process routinely takes 48 hours and the notice will be rescinded at that time.
ECUA crews have completed the repairs and flushed out the lines. Residents within the PBWN area and nearby are advised that there is a possibility of discolored water as a result of the utility work, and to flush their home’s plumbing by running their taps for a few minutes. If problems persist, customers are asked to contact ECUA Customer Service at 850-476-0480 for assistance.
Precautionary boil water notice guidelines are available on the ECUA website at ecua.fl.gov/live-green/our-water-supply

### CONVERSATION ON 12-10-2021

**Vicki Campbell**: Let’s have a pow wow breakfast or lunch about our new areas prior to the town halls .  I want to talk about a basin study, shovel ready Stormwater and Septic the sewer project

**Vicki Campbell**: We can make you a hero

**Jeff Bergosh**: Okay, we can do that.  After first of year

**Vicki Campbell**: K

### CONVERSATION ON 01-04-2022

**Jeff Bergosh**: In meeting will call u back

**Vicki Campbell**: No rush

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Hello Vicki— I am getting numerous angry emails about the proposed ECUA Transfer Station at Pine Forest Road.  Although we are not approving the Transfer Station tonight— a lot of folks believe we will be.  I would appreciate it if you, Bruce and your project manager could attend our meeting this evening to answer these folks that will be coming to speak.  Let me know who from ECUA will be here at our meeting tonight to handle this

**Jeff Bergosh**: Thanks!

**Vicki Campbell**: I will find out who will be there.  I’m getting emails too.  I think you and I need to drive home that this is just a zoning meeting and until we see all the plans to address all concerns we won’t be voting on the transfer station itself just the zoning

**Jeff Bergosh**: It’s what I’m telling them but they’re looking forward to the next steps…..naturally

**Vicki Campbell**: When we did the Palafox tank we had a lot more calls and people not wanting it in that location.  They said stuff about Rodents and smells which were not true.   We haven’t had one complaint since it’s been built. And the district 3 representative was reelected even with all of that going on.  This is not going to hurt you at all.  It’s a handful of people.   This is a much needed infrastructure as Beulah grows and it is going to grow!  I know it is a tough one for you to get behind with this small handful of opponents but keep trying to think of the big picture and all the people you are going to help in your district.   This transfer station will benefit all of the west side of Pensacola greatly!  

**Vicki Campbell**: So myself, Bruce, Robert Beasley and Dewitt Clark will be in attendance.  It’s 5:30 correct?

**Vicki Campbell**: PS I’ve been asked to speak at the Perdido Chamber breakfast in February

**Jeff Bergosh**: Yes 5:30– thanks!

### CONVERSATION ON 01-20-2022

**Vicki Campbell**: Town halls?

**Jeff Bergosh**: Yes— going to invite you and Kevin to speak as well

**Vicki Campbell**: How long do we speak?  10 minutes?

**Jeff Bergosh**: Yes I think 10 minutes is perfect

**Vicki Campbell**: Thank you.  I’ll bring Bruce too

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: 😀

**Vicki Campbell**: If we get questions about the transfer station when we are in Beulah we’ll be ready with nice big pictures etc.  I suggest “if” they ask about it we can say if you are interested in that stay after and staff will discuss it with you.  That way they don’t tie up your meeting.  If it’s not brought up we can just move on.  My talk will briefly explain why it’s so important to Beulah and the entire West side of Pensacola.  

**Jeff Bergosh**: Sure thing- sounds like a great plan

**Vicki Campbell**: I was a Girl Scout - always be ready 😆😁🤣

