

## CONVERSATIONS WITH ANDY HUFFMAN

### CONVERSATION ON 01-12-2022

**Jeff Bergosh**: Hey I’ll probably take you up on that!!😀

**Jeff Bergosh**: Absolutely.  Thanks for the information!

