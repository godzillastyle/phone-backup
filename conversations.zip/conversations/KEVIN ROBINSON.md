

## CONVERSATIONS WITH KEVIN ROBINSON

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Absolutely.  I’m at Precinct 43 Beulah free will Baptist Church

**Jeff Bergosh**: Yes

### CONVERSATION ON 08-21-2020

**Jeff Bergosh**: Sure— can I call u a bit later I’m out on a boat at the moment

### CONVERSATION ON 10-26-2020

**Jeff Bergosh**: Are Kevin

