

## CONVERSATIONS WITH KYLE MCCULLOUGH

### CONVERSATION ON 02-28-2020

**Jeff Bergosh**: Thank you and I look forward to the conversation tomorrow

### CONVERSATION ON 02-29-2020

**Jeff Bergosh**: Good morning Kyle.  How about we meet at the Ruby Tuesday on Pine Forest road at I-10.  Say 12:15.  Does that work?

**Jeff Bergosh**: Okay great I’ll see you when you get there

**Jeff Bergosh**: Hey Kyle—I’m here I’ve got us a table just text me when you get here

### CONVERSATION ON 12-14-2020

**Jeff Bergosh**: Hi Kyle!  Yes that would be great.  It’s  jeffbergosh@gmail.com

