

## CONVERSATIONS WITH ALAN GRAY

### CONVERSATION ON 12-31-2019

**Jeff Bergosh**: Thank you very much for the kind words Alan—-and happy new year to you

