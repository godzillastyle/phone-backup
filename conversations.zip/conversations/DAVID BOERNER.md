

## CONVERSATIONS WITH DAVID BOERNER

### CONVERSATION ON 04-02-2021

**Jeff Bergosh**: Hi David!!! Absolutely yes-- can't wait to hear how you're doing.  I'm sorry as well that we've not got together-- but yes let's do that.  Are you in Pensacola still?

**Jeff Bergosh**: Right on David.  When you are free let's definitely get caught up and have lunch.  Thanks for the birthday wishes.  Yes, Sally and Tori, Nick, and Brandon all doing well- thx for asking.  And your sister?  She still in Nursing?

**Jeff Bergosh**: That's great to hear! I look forward to catching up!

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: This Friday works great!  Looking forward to catching up!  Can we meet at Chic Fil A on Navy Blvd at 11:30?

**Jeff Bergosh**: Right on see u then!

### CONVERSATION ON 05-28-2021

**Jeff Bergosh**: Yep, see you there!  Looking forward to it!

