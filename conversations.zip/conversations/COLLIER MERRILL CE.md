

## CONVERSATIONS WITH COLLIER MERRILL CE

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good afternoon Collier—-as a person that has helped me in my campaign and supports my candidacy for County Commission—-I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Collier—hope all is well!

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: Awesome thanks Collier will send you the info.  Thanks!

### CONVERSATION ON 05-29-2020

**Jeff Bergosh**: Collier— hope you had a great week.  We will have our online video conference this Wednesday morning , June 3rd,  from 6:30-7:30 AM with you, Dr. Rick Harper, Administrator Janice Gilley, and myself discussing the regional economic impacts of COVID-19 on local businesses and the broader economy. Thanks for participating and I look forward to it.  I will forward the ZOOM meeting invitation to your email.  Have a great weekend!!

### CONVERSATION ON 06-03-2020

**Jeff Bergosh**: Collier:  thanks very much for joining and participating in our coffee this morning—I greatly appreciate it!!

