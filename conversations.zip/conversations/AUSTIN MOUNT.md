

## CONVERSATIONS WITH AUSTIN MOUNT

### CONVERSATION ON 12-05-2019

**Austin mount**: Good morning. I know you’re in the meeting but can I ask when you all hit our item that maybe our agency could be moved to the other list or have county staff develop an MOA with us to move us off outside agency list ? 

**Jeff Bergosh**: Sure Austin 

**Austin mount**: Thank you so much. Comm May appears to be supportive of this as well 

**Austin mount**: Thank you!  

### CONVERSATION ON 12-11-2019

**Austin mount**: You able to make tpo mtg?  We are one short of a quorum 

**Austin mount**: Our quorum just let us know he was sick and can’t make it 

**Jeff Bergosh**: Unfortunately I can’t.  We sent notification on Monday

**Austin mount**: Ok just drawing straws... thank you! 

**Jeff Bergosh**: I’m at NAS where I work and there’s a lot going on here.  Sorry Austin

**Austin mount**: I believe that!  Ok have a good day 

**Jeff Bergosh**: U too Austin

### CONVERSATION ON 02-27-2020

**Austin mount**: I see you!  Much of what he’s talking about we plan to incorporate into our ATMS project and bring the vehicle for big data collection and technology integration 

**Jeff Bergosh**: That’s awesome Austin.  This is a great presentation

### CONVERSATION ON 04-08-2020

**Jeff Bergosh**: Hey Austin here’s an off-the-wall question for you: is the Florida welcome Center/ rest stop right at the border of I 10 is that funded by the state or by the federal government? The reason I ask there is a report that federally funded rest stops are allowing food trucks to operate to feed truckers. Do you know the answer to that question?

Thanks very much and I hope all is well with you.

Jeff Bergosh 

**Austin mount**: I will find out 

**Jeff Bergosh**: Thx

**Austin mount**: I’ll go ahead and tell ya, I started chemo yesterday. I found a lump and ended up being testicle cancer. Luckily it hasn’t spread so chemo is preventative just in case

**Jeff Bergosh**: Oh my gosh Austin!! I’m so sorry to hear this!! I’ll keep you in my prayers!!

**Austin mount**: Thanks. I haven’t told many people but I consider you a friend

**Jeff Bergosh**: Absolutely and I will keep this in close confidence

**Austin mount**: Do you have time for a quick chat I have some info 

**Jeff Bergosh**: Sure

### CONVERSATION ON 06-04-2020

**Austin mount**: This isn’t public but flyover on 9mile is dead 

**Austin mount**: DOA/do not pass go/RIP 

**Jeff Bergosh**: Right on!!!! Great news!!!  I’ll keep it on the down low but can I call u to discuss tomorrow—I want the details!!😎😎👍👍

**Austin mount**: Sure feel free. All I know is PD&E says the geometry isn’t there and will be an accident nightmare. They instead proposing some version of 6 lane 

**Jeff Bergosh**: Good

**Austin mount**: Thank you for approving our interlocal agreement! 

**Jeff Bergosh**: Sure!

### CONVERSATION ON 07-08-2020

**Jeff Bergosh**: Austin I am trying to call In but I was not given an access code just the phone number when I called the phone number it asks for the access code can you please text me the access code thank you

**Austin mount**: Yes sir 

**Jeff Bergosh**: Mary Beth’s email did not provide one

**Austin mount**: Access code is 115187253

**Jeff Bergosh**: Thx

**Austin mount**: Let me know when you’re in 

**Jeff Bergosh**: In

**Austin mount**: Great 

### CONVERSATION ON 08-20-2020

**Austin mount**: Big congrats on a much deserved win!!! 

**Jeff Bergosh**: Thanks Austin!

### CONVERSATION ON 09-08-2020

**Austin mount**: Flyover is dead, it became public last week 

**Jeff Bergosh**: Thx for the heads up Austin

**Austin mount**: Would you be interested in a meeting with FDOT in lieu of a formal audit request?  I know they are putting information together still but something I thought of offering up. They are ok with an audit because they can produce what is asked but it may be better received if we have a meeting and see what we get?  

**Jeff Bergosh**: Sure We can do that and see what kind of explanations they offer— but I would certainly maintain the prerogative to request a formal audit as well 

**Austin mount**: Absolutely. If you’ll let me try a meeting first, it may work.  If not, by all means full steam ahead 

**Austin mount**: Thanks! 

**Jeff Bergosh**: Okay perfect let’s do this

### CONVERSATION ON 09-09-2020

**Austin mount**: If the tpo moves forward with this project it will compete with all the other projects out there. So one has to ask “is there significant gain by moving this project forward” 

**Jeff Bergosh**: Thanks for this info Austin

**Jeff Bergosh**: Good to know

**Austin mount**: Heard from Tim, he’s very appreciative of how meeting went and very agreeable to visiting with you!  

**Austin mount**: I’m happy to help coordinate if you’d like 

**Jeff Bergosh**: That sounds great thanks Austin

**Jeff Bergosh**: Just let me know if he can come over here or do we have to have it remotely on Zoom?

**Austin mount**: Ok likely will be a teams meeting 

**Austin mount**: Is that ok ?

**Jeff Bergosh**: Yes that’s fine

**Austin mount**: Ok I’ll get with your EA and set something up for you 

**Jeff Bergosh**: Thanks very much Austin I greatly appreciate it

**Austin mount**: We will get you the answers you’re looking for! One way or another 

**Jeff Bergosh**: Thanks Austin— I just want them to finish in 9-Mile.  It’s time!

### CONVERSATION ON 09-16-2020

**Austin mount**: Not sure this is public yet but wow 

**Jeff Bergosh**: Wow Austin!!

**Jeff Bergosh**: How long will that take to fix?!?

**Austin mount**: Who knows man

**Jeff Bergosh**: Wow!!  Gulf Breeze folks are trapped!

### CONVERSATION ON 10-13-2020

**Austin mount**: Hey have a minute ?

**Austin mount**: Got a hot item for TPO tomorrow

**Jeff Bergosh**: Sure

### CONVERSATION ON 10-14-2020

**Austin mount**: Just got a message from Tim saying he really appreciates your questions and Bryant will be putting the information together for you. I also spoke with him last night I’ll catch up this afternoon

**Jeff Bergosh**: Thanks Austin!

### CONVERSATION ON 10-19-2020

**Austin mount**: FDOT is going to fix the rutting issues this week on beulah you mentioned 

**Jeff Bergosh**: Thx very much Austin!

**Austin mount**: I relayed your position of reestablishing a relationship. Tim said he was happy to have a weekly call or however often you want to discuss any FDOT matters. Maintenance, construction, etc. he even said “heck he can yell at me that’s ok, we want to make it work with the county and make it work too” 

**Jeff Bergosh**: Thanks Austin I greatly appreciate that!!

### CONVERSATION ON 01-07-2021

**Austin mount**: Just forwarded you an email. Nothing big just thought you should know...

**Jeff Bergosh**: Thanks Austin

**Jeff Bergosh**: Running crazy ever since I hit the ground back from vacation

**Austin mount**: Welcome back! 

**Jeff Bergosh**: Thanks!

**Austin mount**: Hey just got a call from Tim he said to pass you his cell phone and to call at your convenience. He wants to talk about partnerships and maybe answer some of your concerns.   His cell is 850-849-3194

**Austin mount**: They got a copy of this mornings meeting 

**Jeff Bergosh**: And I’ll certainly look forward to meeting with him I’m just constantly consistently getting my ass kicked over FDOT issues and I really am sick of it.  My constituents would think I run that department

**Austin mount**: Hahaha 

**Austin mount**: Sorry I don’t mean to laugh 

**Austin mount**: It’s not a funny situation, I realize that 

**Austin mount**: You’re their hero tho 

**Austin mount**: Did you get a chance to chat with Tim?  I spoke with him again saying we gotta do something to help you with your constituents. He said he would think of something to help out, not sure what that will be but he’s thinking. 

**Jeff Bergosh**: Not yet but I will.  I’m in a BCC meeting but I’ll call him tomorrow, can you forward his cell number?

**Austin mount**: Sorry I forgot meeting was tonight

### CONVERSATION ON 01-12-2021

**Austin mount**: Sent you an email 

**Jeff Bergosh**: Okay I’ll check it thanks Austin

### CONVERSATION ON 01-13-2021

**Austin mount**: You’re welcome. There will be discussion today.

**Jeff Bergosh**: Okay great

**Austin mount**: Hey I know you're busy do you have a minute to chat

**Jeff Bergosh**: Yes

**Austin mount**: Tim sent a message saying “perfect!!”

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-27-2021

**Jeff Bergosh**: Good morning Austin— Is there some sort of planning meeting today regional planning anything involving the TPO?

**Austin mount**: Good morning!  The bay county TPO is meeting I’m not sure of anything else but let me check 

**Austin mount**: Has the secretary been in contact with you. I was told he will be once he’s off covid quarantine 

**Jeff Bergosh**: Not yet but I have a meeting set up with them next week on zoom

**Jeff Bergosh**: Carter Johnson set it up

**Austin mount**: Excellent! 

**Jeff Bergosh**: 👍

**Austin mount**: I’m still double checking on today.  We don’t think there’s anything but let me make sure to ask everyone

**Jeff Bergosh**: Thx

**Austin mount**: Ok no meetings today

**Austin mount**: Did you hear there was from somewhere ?

**Jeff Bergosh**: CH.3 called me to ask

**Austin mount**: Ok. Yep nope 

**Austin mount**: Hey heads up, we need you to appoint a person to the CAC 

**Jeff Bergosh**: Okay I’ll see if I can get someone

**Jeff Bergosh**: When do I need this by?

**Austin mount**: Soon before everyone hits you up 

**Austin mount**: Or you can tell them you have someone identified already 

### CONVERSATION ON 02-08-2021

**Jeff Bergosh**: Hi Austin that meeting never happened with Carter Johnson.  Can you forward me his cell Number?  Thanks!

**Austin mount**: Ok let me look into it. Probably should just go straight to Tim 

**Austin mount**: You good calling him ?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Thx I’m going to call him

**Austin mount**: He sent a message saying he’s at a dr appointment this morning but available this afternoon

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-10-2021

**Austin mount**: Hey when you get a second can you give me a shout

**Jeff Bergosh**: 👍

**Austin mount**: You’re a rock star!  Sorry that was more of a 💩 show than expected but you definitely have a lot of fans, especially when they see what we can do with that money!

**Jeff Bergosh**: Thanks Austin!

### CONVERSATION ON 02-25-2021

**Jeff Bergosh**: Hey Austin, who is Eric Saggars?  And is his timeline accurate above, do you think?

Thanks,

Jeff Bergosh 

**Austin mount**: Let me run it down 

**Austin mount**: I’ll be back in touch 

**Jeff Bergosh**: Okay thx

**Austin mount**: When do you need a response by?  Tim is on it 

**Jeff Bergosh**: No rush

**Jeff Bergosh**: Thx

**Austin mount**: Ok here’s the response I received:

Eric is FDOT general engineering consultant. 
Interchange:
Design for design build is underway. 
ROW is funded in 25 to 27. 
Maps are being produced now. 
Interchange is now on APP list (Advanced Production Project) meaning if surplus or returned SIS funds become available its top of the list across state to receive those and advance the project up to ROW (year 25/26) or thereafter. As is, the project is in the second 5 years of SIS work program, tentatively. Because it has possibility to move forward. 

**Austin mount**: Project = construction 

**Jeff Bergosh**: Thank you Austin.  So, in layman’s terms— when do we anticipate dirt turning. 10 years?  2031??

**Austin mount**: They aren’t committing to a date “because it’s fluid”. That second 5 year SIS moves around a lot. They keep telling me if they were to give a date, it could move tomorrow. 2031 is the last year and would be worst case scenario. Best case is 26 timeframe.

**Jeff Bergosh**: Okay thank you for that Austin!!  Greatly appreciate that!!!

**Austin mount**: They won’t even give me a date 

**Austin mount**: Tentative date 

**Jeff Bergosh**: They gave staff the 2031 date.  Then staff gave that to DPZ, and DPZ is presenting that as gospel

**Austin mount**: Well it is worst case 

**Austin mount**: So from there anything moved up is a win 

**Austin mount**: On another note I heard Phillip and Tim have recovered from COVID so they’ll be reaching out to you in the near future 

**Jeff Bergosh**: Cool-  looking forward to that

### CONVERSATION ON 04-08-2021

**Jeff Bergosh**: Hey Austin— I had my meeting with Sec. Gainer and Tim from FDOT yesterday and it went very well.  Thanks for your help in facilitating that!

**Austin mount**: Absolutely!  Glad you all were able to connect. Will you be able to make the TPO meeting next week? 

**Jeff Bergosh**: Yes I’ll be there

**Austin mount**: Great. If you want me to run through the agenda with you ahead of time I’m happy to. There’s some confusing items in it. Shouldn’t be controversial but just confusing. 

**Jeff Bergosh**: Okay I’ll touch base tomorrow if that’s cool

**Austin mount**: Sounds good! 

### CONVERSATION ON 04-13-2021

**Austin mount**: In your notes from Christine Fanchi this evening it mentions moving around funding in the coronavirus spending plan from the ATMS project to fund two transportation alternative projects that haven’t been funded for years. The department doesn’t support that recommendation. Everything else should be straight forward.

**Jeff Bergosh**: Thanks for the heads up

**Jeff Bergosh**: Your recommendation we should go with the T cc recommendations?

**Austin mount**: The TCC recommendation isn’t good. We really need to stick with the original plan. I’m so close to delivering this ATMS project 

**Austin mount**: Barry wants to know if that project is important to you. He says he can find funding for you

**Jeff Bergosh**: Can I call u before mtg to discuss?

**Jeff Bergosh**: At around 0800

**Austin mount**: Help find funding 

**Austin mount**: Yes 

**Austin mount**: Absolutely 

**Jeff Bergosh**: Okay great I really appreciate it.  I have a mtg from 0630-0730 so I’ll call u after that

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: Do you got a quick minute to talk?

**Austin mount**: I do 

**Austin mount**: Sorry about that. Was on with Fdot 

**Austin mount**: I’m free now 

**Jeff Bergosh**: Thx Austin

**Austin mount**: Oh that project is in Lumon’s district 

**Jeff Bergosh**: Yep

**Austin mount**: Thanks for getting me back on track with that first item 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: It looks like it could’ve turned out much worse

**Austin mount**: Oh my gosh yea 

**Austin mount**: Thank you for your support. It means so much

**Jeff Bergosh**: Absolutely Austin!

### CONVERSATION ON 04-15-2021

**Austin mount**: Hey do you have a quick second

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Just called u

### CONVERSATION ON 06-09-2021

**Austin mount**: Good luck on your contract/bid!  Rooting for ya 

**Jeff Bergosh**: Thanks Austin

### CONVERSATION ON 06-28-2021

**Austin mount**: Checked on our S. Sorrento request. It’s headed to Mike Lewis at fdot for him to inspect. Will keep following up on it 

**Jeff Bergosh**: Thank you Austin!

### CONVERSATION ON 07-13-2021

**Jeff Bergosh**: Thanks for any update you can provide and I appreciate your help!

**Austin mount**: Hello!  Just checked, supposed to have an update tomorrow morning

**Jeff Bergosh**: Right on thank you Austin!

### CONVERSATION ON 07-14-2021

**Austin mount**: Here’s what I uncovered:

Fdot has a resurfacing projected scheduled for February 2022. In that project the intersection will be addressed. There will be added paved shoulders to allow for a wider turning radius. Also the slope on travel lanes will be adjusted to make for a smoother transition across southbound lanes and onto Doug Ford dr.  

Does this adequately address the concerns brought to you? 

**Jeff Bergosh**: I appreciate this and I think it will.  Is there any way I could get a look at the design drawings for that intersection?  That would really answer the question definitively.  Thanks for all your assistance with this Austin!

**Austin mount**: Let me see what I can get 😊 

**Jeff Bergosh**: 👍

**Austin mount**: hx-core://attachment?aoid=00006a0100000000000000008cb1350000000000670100008bab3200000000008cb13500000000008bab320000000000&moid=0000c900000000000000000085b1350000000000d40000006eac32000000000085b13500000000006eac320000000000

**Austin mount**: Whoops. Let me try again…



**Jeff Bergosh**: Thanks Austin— got it!

**Austin mount**: Sure! If you need more info I’m happy to get you to the design engineer on it. 

**Jeff Bergosh**: Thanks Austin— greatly appreciate it!

### CONVERSATION ON 11-05-2021

**Austin mount**: Got your message. I’m on it 

**Jeff Bergosh**: Thanks very much Austin

**Jeff Bergosh**: That’s the part of the tressle that’s unstable

**Austin mount**: Do you have a map showing exact location?

**Austin mount**: I have FDOT with me now 

**Jeff Bergosh**: No but pretty close.  It’s about 50 yards north of the tracks adjacent to 6470 Rosaflora lane in Pensacola off of scenic

**Austin mount**: Ok… spoke to Ray Corbin who’s over rail. They’re going to contact the “Pensacola yard guy” to go take a look at it. I passed on your brothers contact info and they should be in contact soon. If he doesn’t hear anything soon let me know 

**Jeff Bergosh**: Will do!  Thanks very much Austin!

**Austin mount**: Happy to help 

### CONVERSATION ON 11-23-2021

**Jeff Bergosh**: Hey Austin I hope you’re doing well and I hope you have a very happy Thanksgiving. I had a quick question for you I got a call from the media and they’re asking about federal money that’s going to come for Florida roadways for safe safety enhancements and improvements do you have any talking points on that you could share with me or any insight? Thanks

Jeff B

**Jeff Bergosh**: At the federal level

**Austin mount**: I have some information but it may be old and subject to change 

**Austin mount**: I’ll email it to you now 

**Jeff Bergosh**: Thx Austin

**Austin mount**: It’s from USDOT 

**Jeff Bergosh**: Do you think they’re going to run most of it through the TPO’s or will they give some directly to counties?

**Austin mount**: Much of it will run through the TPO and FDOT processes however there are some competitive cycles and new pots we’re not sure yet how that will be handled 

**Jeff Bergosh**: Okay thx for that—greatly appreciate your info!!

**Austin mount**: Ok sent! 

**Jeff Bergosh**: Thx!!

**Austin mount**: I also need to get with you before the 2nd BCC meeting. I’ll be presenting information on the TMC. We have confirmed the county EOC as the location 

**Austin mount**: Need to discuss space/lease details etc 

**Jeff Bergosh**: Okay perfect.  Let’s discuss next week Monday or Tuesday.  If that works for you

**Austin mount**: It certainly does 

**Austin mount**: Happy Thanksgiving 

**Jeff Bergosh**: Same to you Austin!

### CONVERSATION ON 11-30-2021

**Austin mount**: Do you have any time this afternoon for a quick phone call ?

**Jeff Bergosh**: Sure thing. 

**Jeff Bergosh**: I’ll call u in 5

### CONVERSATION ON 12-02-2021

**Austin mount**: Talked to Alison. She feels I don’t need to be there tonight that there was good discussion this morning. She’s going to ask for a vote to proceed with drafting a lease and doing research on the space needs for public safety to ensure they’re good with it. Is that what you think too ?

**Jeff Bergosh**: Yes.  Plus tonight’s gonna be kind of a long meeting no need for you to get wrapped up in all that. Have a great afternoon!

**Austin mount**: Ok cool. Thanks! 

### CONVERSATION ON 12-07-2021

**Austin mount**: FYI. Bob Cole is asking if you’ll be at the tpo meeting tomorrow. Not sure why

**Jeff Bergosh**: I’ll be there Austin

**Jeff Bergosh**: I looked at the agenda I didn’t see anything that major should be a short meeting right?

**Austin mount**: Yeah should be short 45 min or so 

There will be public comment from people supporting road diet on Cervantes but everything should be good. #2 is RSVP’d

**Jeff Bergosh**: Thanks for update— wish #2 would just go away LOL

**Jeff Bergosh**: 😎👍👌

**Austin mount**: Yep! So close 

**Jeff Bergosh**: Lots of celebration on that last night

**Jeff Bergosh**: Next November

**Austin mount**: Will you be at the delegation tonight

**Jeff Bergosh**: No— I’ve committed to attending the Navy League Christmas Social

**Austin mount**: Ok. See you in the am

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-05-2022

**Austin mount**: Hey do you have a minute this morning?

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: Good morning Austin— do you have a quick minute to talk this morning— I wanted to ask you a couple questions about some upcoming road projects

**Austin mount**: Sent you one email. Another one will be coming your way soon 

**Austin mount**: The first outlines past efforts the second will be where the project segments are in the priorities 

**Jeff Bergosh**: Awesome thank you very much Austin I’ll take a look at it when I get back to the office and I really appreciate you putting that together for me thank you!

**Austin mount**: No worries! Happy to help 

**Austin mount**: Just sent other emails as to where the segments fall in the tpo priories. 

**Austin mount**: When is your meeting 

