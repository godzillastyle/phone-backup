

## CONVERSATIONS WITH KENDRICK DOIDGE

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Got it

**Jeff Bergosh**: *but also

**Jeff Bergosh**: Thanks Kendrick!

### CONVERSATION ON 05-18-2021

**Jeff Bergosh**: Sounds great what time?

**Jeff Bergosh**: That works!  Thanks for putting that together we will see you all at the Health and Hope clinic on the 7th at 1:00PM!

### CONVERSATION ON 06-07-2021

**Jeff Bergosh**: Kendrick— just checking in to make sure the visit this afternoon with you and Gay is still a go for 1:00 PM.  Representative Michelle Salzman is going to be attending as well!

**Jeff Bergosh**: 👍

