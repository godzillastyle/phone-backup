

## CONVERSATIONS WITH THERESA HILL

### CONVERSATION ON 10-20-2019

**Theresa Hill**: Hey I’m back looking at this upcoming week or next weekend to maybe do the interview by bay with you? Hoping we are still friends! 

I have been doing so much research on this issue we are not scientists but John and I have read about 10,000 pages of studies and have been in a three month dialogue with both FDEP, EPA, ADEM, FW, County, USACE, etc etc etc so we have a good handle on the studies. Just didn’t want you NOT to know of the Alabama side advisories. Thanks

**Jeff Bergosh**: Thanks Teresa!  Thanks for the update that sounds great and I’m looking forward to it.

**Theresa Hill**: Ok what days next week/weekend work for you?

**Jeff Bergosh**: Saturday afternoon any time after 2:00

**Theresa Hill**: Works for us! If you are doing the crab trap, do we need a dock? We can probably find one 

### CONVERSATION ON 10-25-2019

**Theresa Hill**: Are you avail in a few for a call? John would like to touch base about tomorrow I will be with him for the next couple hours

**Jeff Bergosh**: Sure

**Theresa Hill**: Ok we will call in about 20

**Jeff Bergosh**: K

### CONVERSATION ON 10-27-2019

**Jeff Bergosh**: But I found a couple locations where we can film including a county owned parcel of land so I will forward you that address

**Theresa Hill**: Ok I’m leaving my house downtown now. I’ll let John know too

**Jeff Bergosh**: All right Theresa let me know when you’re headed this way I’ll give you directions to where were at we’ve got the bait out in the water on strings and were set up in a good location

**Theresa Hill**: We are here

**Jeff Bergosh**: Theresa turn on your map and follow the path to the bay my brother and I are here we just pulled in another crab

**Theresa Hill**: We don’t see you lol

**Jeff Bergosh**: Just follow the path all the way out to the bay not the bayou the bay we’re out here and catching crabs

**Theresa Hill**: Ok we are at bayou

**Jeff Bergosh**: I’ll send u our location

**Theresa Hill**: Thank you! It was our pleasure. I enjoyed talking with your brother very much. I’d love to know more about the veterans he is working with too. I really appreciate your perspective and we will be respectful. I may have to include one or two jokes you said at Andy Marlette though. If that’s ok.

**Jeff Bergosh**: Of course!  Thanks for coming out!

### CONVERSATION ON 10-29-2019

**Theresa Hill**: Hey the 3 minute trailer should be out but it might be kinda late tonight. You’d be surprised how long it takes to get an hour down to 3 min. I didn’t use much of your brother since it was so short, but he will definitely be in the movie. I hope I gathered your views well in the 1.5 minutes. The other half of the trailer is featuring Wesley Reeves of the Poarch Creek tribe. Hope it’s ok for you! Don’t forget I’ll include much more for the movie.

**Jeff Bergosh**: Thank you Teresa!

### CONVERSATION ON 11-17-2019

**Jeff Bergosh**: On a hike and I accidentally packet dialed you sorry 

**Theresa Hill**: It’s ok must be the universe. I’ve been getting texts all day about your recent blog. I haven’t read it yet but very close friends of mine are very impressed with it. I’m always here to help get whatever message you want out re upper bay.

**Jeff Bergosh**: 👍

**Theresa Hill**: Just read it. I know Jackie so well I could tell it was her lol. Thanks for meeting with her and listening and at least giving voice to those who have studied the situation for a long time. Something is very wrong up there and we need to work to figure it out. Thanks.

### CONVERSATION ON 11-26-2021

**Theresa Hill**: Hi Commissioner! It’s Teresa Hill. Mom is wanting to talk to you about the homeless. When is a good time?

**Theresa Hill**: Sorry to bother you I know it’s a holiday. I hope you had a good thanksgiving! The homeless special meeting on the $3M is Wed. Dec 1. I told her about your coffee talks that I watched on YouTube, and she didn’t have your number. 

I said I would text you bc she wants to be very open to working on a countywide solution since half the residents under the bridge are EC evictions. In no way is she trying to move the problem, the bridge is her district and she doesn’t want to just send them back to the woods. She also doesn’t want to just move the problem. 

We really want to learn more about 1221 W Fairfield, owned by county.

Thanks please forgive the long text, just need to connect you two.

**Jeff Bergosh**: Hi Teresa!  I’d love to speak with her anytime about this issue. And congratulations on her being selected council president! Please pass my number along to her and just tell her she can call me anytime on this number —-this is my personal cell and I’ll pick up. Hope y’all have a great holiday season!

Jeff B

**Theresa Hill**: Loved “Hi Teresa!  I’d love to speak with her anytime about this issue. And congratulations on her being selected council president! Please pass my number along to her and just tell her she can call me anytime on this number —-this is my personal cell and I’ll pick up. Hope y’all have a great holiday season!

Jeff B”

**Theresa Hill**: Thank you so much I really learned a lot from your coffee‘s on YouTube. Keep them up it takes me a while to catch up to everything but I learned a lot about your perspective and I’m really glad I watched it thanks to you. And congratulations on chair as well

**Theresa Hill**: This is the one. 

**Jeff Bergosh**: Thanks Teresa!

### CONVERSATION ON 11-27-2021

**Theresa Hill**: Mom said she sent you an email with some information and will call you tomorrow or monday

### CONVERSATION ON 11-29-2021

**Jeff Bergosh**: Absolutely!

