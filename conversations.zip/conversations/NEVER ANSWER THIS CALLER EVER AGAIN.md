

## CONVERSATIONS WITH NEVER ANSWER THIS CALLER EVER AGAIN

### CONVERSATION ON 06-24-2020

**Jeff Bergosh**: I'm in a meeting I will call u back

### CONVERSATION ON 06-30-2020

**Never Answer This Caller Ever Again**: We are against mamdatory FACE MASKS.  WE ARE FOR OUR INDIVIDUAL RIGHTS!!!  They need to remember we VOTE!  We all are responsible for our own actions

**Never Answer This Caller Ever Again**: We are not Miami, nor Tampa

**Never Answer This Caller Ever Again**: ABE and CBS are publically anouncing that there is a $50.00 Fine for not wearing mask. That is rubbing the public wrong. Nobody died and left them BOSS!

### CONVERSATION ON 07-17-2020

**Never Answer This Caller Ever Again**: Mr.Bergosh, I feel that you blew me off,especially when you told me that you were at work. But please remember, you work for US. The word of mouth goes very far. It can make you or break you.I may be a commercial fishermen. But I do have a college degree also! I will not contact you NO MORE!!!

**Jeff Bergosh**: I'm still on the phone I'll call u back

**Jeff Bergosh**: Dealing with an emergency situation

**Never Answer This Caller Ever Again**: They want to shut us Panhandle people down. Because they know our votes are the ones for the state of Fl that put Trump in office. We have alot of Dems and far left that has recently moved to Fl. It makes me nervous!

### CONVERSATION ON 07-27-2020

**Never Answer This Caller Ever Again**: Seen on the News last night, that ya'll are taking a vote on pressing Mask Fines. Please don't make our Police MASK COPS. I Beleive that could hurt ur election

**Jeff Bergosh**: I agree we don't want this-- a lot of doctors are begging us to do it.  I think what will happen is we will discuss but not pass

**Jeff Bergosh**: I don't want cops making it a criminal issue!

**Never Answer This Caller Ever Again**: We trust our law enforcement. That would cause big disruption. I'm sorry I trust Law more than Doctors.

**Never Answer This Caller Ever Again**: I have seen people wearing mask more in the last 2 weeks than the last 2 months.. Especially in Walmart. I haven't seen maskless people in the 2 walmarts on Mobile hwy

**Never Answer This Caller Ever Again**: Everyone I know will be Voting in Person. Not by mail in Ballots. Including my 83 year old mother- in- law

**Jeff Bergosh**: I know me too!  I always vote on Election Day.  Anything else just doesn't seem right!

**Never Answer This Caller Ever Again**: My husband and I will be voting early. Never know where we will be election day

**Never Answer This Caller Ever Again**: My mother- in- law said that she received mail in ballot yesterday. She said she didn't request it. She will be going to vote early. She has no health issues. She said they will not take that from her

**Never Answer This Caller Ever Again**: My son-in-law is a super intentant for a major construction company here in Fl. My grandchild is grown. They have never voted. As of now they are registered Conservative voters. We are making our STAND 

### CONVERSATION ON 07-29-2020

**Never Answer This Caller Ever Again**: Did Gov.Ron DeSantez get the stock pile of Hydroxychoroquine from New York that he requested over a week ago?

**Jeff Bergosh**: I think he got that 2 Months ago.  But I think he got the remdesivir last week that he'd been waiting for

**Never Answer This Caller Ever Again**: Cool. We are taking this Virus serious. We just don't want to be treded on, though. Thankyou. Sorry don't want to pester you sir

**Jeff Bergosh**: You're not pestering me- this is my job LOL-- And I'm taking this virus serious to try to find the best solution for safety and preservation of liberty!

**Never Answer This Caller Ever Again**: Exactley. This is Great America! Some family members have gotten citizenship. Some are still working on it

**Never Answer This Caller Ever Again**: Oh. My Family are all born and bred Americans. Just some are joining us. Lol

**Never Answer This Caller Ever Again**: I have a question. I know u do make sure that ECUA keep up their part?

**Never Answer This Caller Ever Again**: Sorry. That wasn't meant to be sent tonight. It wasn't worded right either. Have a nice peaceful evening!

### CONVERSATION ON 08-05-2020

**Never Answer This Caller Ever Again**: When u get a minute can u please give me a call. I have a question for you. I would u input

### CONVERSATION ON 08-07-2020

**Never Answer This Caller Ever Again**: All election sign I see in the Navy point area. Sunset' are Owens

**Never Answer This Caller Ever Again**: Drom Gulf beach Hwy to Patricaa a few

**Jeff Bergosh**: Yeah I saw it.  It does not help him, he will be the 3rd place finisher in this race!

**Never Answer This Caller Ever Again**: Well u better be 1st Sir

**Jeff Bergosh**: I will be!!  

