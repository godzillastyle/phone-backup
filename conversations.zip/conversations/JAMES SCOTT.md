

## CONVERSATIONS WITH JAMES SCOTT

### CONVERSATION ON 06-19-2020

**James Scott**: Jeff, I apologize for not calling you at 5:00 like I told you earlier. Could I please call you tomorrow?

**James Scott**: Thank’s James

### CONVERSATION ON 06-20-2020

**Jeff Bergosh**: Sure

### CONVERSATION ON 06-29-2020

**James Scott**: See you at 4:30 sir. Thanks and God Bless, James

**Jeff Bergosh**: James I’ll be there- I just may be a few minutes late -like 4:40 ish

**James Scott**: Yes sir, your fine not a problem sir 

### CONVERSATION ON 07-24-2020

**James Scott**: Sorry for the late text Jeff. At ECAT Maintenance Department Jeff is a very serious Hostile work please due to Management and Supervisors and 2 night shift employees Jeff, if I can Schedule a meeting with you I would greatly appreciate it. I would love to set up a meeting with you and Lumon May,Justin Pittman another employee on nights with me. I just wondering if you reviewed my investigation paperwork from ED Spanthower, all I want is a True and fair investigation Jeff. We have Serious Problem’s at ECAT. Thanks and God Bless, James Scott 

**Jeff Bergosh**: James I have not forgotten about your issues over there and I have that material that you left with me and I have gone through it however we have major major issues with this COVID-19 pandemic that are consuming every minute of my time I am going to continue to follow the issues there but they may not be solved in the near term you may have to continue to ride it out until we can come up for air and start looking at the issue. Because right now it’s all hands on deck for COVID-19

**James Scott**: Yes sir, I do understand this COVID-19 is very serious but we need someone that will fix this serious issues Jeff and not continue to be covered up. This is a very serious Hostile work place. I just want to be left alone and do my job and not be put in the position that I’m being put in Jeff I don’t bother anyone and we have 2 people on night the lies on me and everybody to try to get them fired and our Maintenance Manager and Supervisors goes along with them because they have filed several complaints on them as well to try to get them fired. Just wondering if anyway to get Robert Transferred to another Facility like out at The shop at Camp 5. Everyone is just feed up with this guy Jeff, all i am asking is you to seriously look into this situation. You can ask anyone on days about these 2 guys and it’s sad Jeff. I wish y’all could interview the Technicians at ECAT on day shift. It’s SAD, It’s now a very Hostile Work Place. Thanks for your response this morning, I wish you luck on this COVID-19 and most of all, be safe and God Bless

**Jeff Bergosh**: Thank you James I promise you I will work your issue.  But our HR department is now all but shut down...we are putting off collective bargaining until September

**James Scott**: Just to let you know, we have a guy on nights that his wife tested positive for the COVID-19 virus and he went and got tested, no results yet that I’m aware of, they making him work with us, but anyway Jeff, we seriously need a change in the Maintenance Department at ECAT, we had not problems like this until Robert Roy,Nick Michaud, David Bullock got there Jeff. It’s serious and Bad.

### CONVERSATION ON 06-21-2021

**James Scott**: Jeff, I need your input on a situation on changing departments with the county, but at the same workplace. Could I please give you a call this evening? Thanks James S.

**Jeff Bergosh**: Of course

**James Scott**: When would be a good time to call you sir?

**Jeff Bergosh**: 4:30

**James Scott**: Thank you I’ll be calling you sir

**Jeff Bergosh**: 👍

**James Scott**: It’s sad the way I’m treated and penalized for willing to change position. I’ll explain to you when I speak with you 

**Jeff Bergosh**: Okay I look forward to it

**James Scott**: Thank you sir 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-23-2021

**James Scott**: Looking forward speaking to you this Monday, Thanks Jeff for all you do for our County! God Bless

### CONVERSATION ON 06-24-2021

**Jeff Bergosh**: Thanks James!

**James Scott**: Yes sir, your welcome. Hope you have a Bless Day!

**Jeff Bergosh**: U too

**James Scott**: I’m afraid Jeff, who ever you talk to is going to give you a sad story, we are down on employees on nights. We down on a Fueler, Cleaner and Technicians. That’s not my fault Jeff, I shouldn’t get penalized and held back for that. I’m sorry for all the text messages, it’s worrying me to death to go back nights and get the treatment I got for 16 years. Thank you sir, in advance.

### CONVERSATION ON 06-28-2021

**James Scott**: Good morning Jeff, please. When you speak with Mrs. Tonya Ellis or Mr. Kimbrough please get them to put me back on my shift 4:30am til 1:00 out of harms way, Mrs. Ellis and Me.Kimbrough knows what I’ve been going through with the Night Shift crew and The Supervisor of night shift. I’ve still not heard anything from HR on my Application for driver, I really don’t want to drive, but if it keeps me from going back to night shift I’ll do it. I don’t want to go through the treatment Jeff that I’ve been through with night shift and This unfair night shift Supervisor. Thank you sir in advance. James Scott...God Bless

**Jeff Bergosh**: Working on it 

**James Scott**: Thank you sir, Jeff you don’t understand how much I and my family appreciates is and appreciate your help and service with the county. My prayers are with you today and forever.

**Jeff Bergosh**: Thank you James!

**James Scott**: Your welcome sir!

**James Scott**: Please sir, tell me some Good News?

**Jeff Bergosh**: Sorry James still awaiting a response

**Jeff Bergosh**: Hang in there

**James Scott**: Mike said he was waiting on a response for 2 weeks Jeff, I hope it doesn’t take that long. It’s got me to we’re I don’t know what to do but go drive buses, I’ve still not heard anything on my Application for HR Jeff this is why they can’t hire anyone. That’s for ever and a day. Like I said Jeff I’ll run a tractor or zero turn and cut grass. 

**Jeff Bergosh**: Understood.  

**James Scott**: You waiting on Tonya or Mr. Kimbrough  ?

**Jeff Bergosh**: Higher up the chain James

**Jeff Bergosh**: I’m working it from the top down

**James Scott**: Awesome that’s the way to get somewhere. They madd with me because I want a change or my early shift back. I get along with all the drivers and operations supervisors very good Jeff just can reach out to them and they will all tell you, I go about beyond my job to take care of them and make pull out.

**James Scott**:  A good thing Jeff, the tractor or zero turn breaks down I can fix it

**James Scott**: How long You thank it will take Jeff, I’m sorry. It’s about to drive me crazy. Nobody knows the treatment I have received from these night shift people Jeff Mike Lowery knows everyone on 1st shift knows to what I went through. I worked 16 years on nights and treated like a dog and stuck it out and finally Mr.Kimbrough can to work at ECAT and several on days explain the treatment I was getting and he made the discussion to move me early morning man. Things were fantastic the whole time I was on it, when I got the news  I was being forced back night by Glenn King and Ron Cooper my nerves and Migraines took me over Jeff. This is the Gods honest truth. 

**James Scott**: I’m so sorry for the spelling, spell check on my phone is crazy. I apologize 

### CONVERSATION ON 06-30-2021

**James Scott**: I’m a firm believer in prayers, I’m hoping and praying I will get good news soon. Thank you Jeff and God Bless!!

### CONVERSATION ON 07-01-2021

**James Scott**: Wow, I wasn’t expecting and phone call from County Administrator Wes Monroe. But I explain my situation to him Jeff, I hope and pray he will help me with your help. Thank you sir and God Bless

**Jeff Bergosh**: I’m working to try.  Thanks for your continued patience

**Jeff Bergosh**: 👍

**James Scott**: Thank you Jeff, I apologize for any inconvenience. I told Wes I’ll do anything to keep from going back nights in the shop because on how I have been treated the pass 16 year  and it really got worse the pass 5 to 6 years. But I was doing really good on early morning man when Mr. Kimbrough put me on it. That was the best I felt sense October 1st 2005 my hire date. Nobody deserves to be treated like I’ve been treated Jeff. You just don’t know much I appreciate you taking your time and helping me out with this situation, if it comes to me going to a different department, I promise I will never let you down. I will and always be faithful to my job. Always. Thank you Jeff

**James Scott**: I’m sorry to bug you and I really apologize for it to sir.

**Jeff Bergosh**: You are never bugging me James! Let’s get this fixed together and get you back to work where we need you! God bless you have a great and safe Fourth of July with your family!

**James Scott**: Thank you sir, I’m ready.  You and your family have a happy and safe 4th of July as well. God Bless

**James Scott**: Good Night and God Bless!!

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-04-2021

**James Scott**: Happy 4th of July, hope you and your family have a Bless and Safe Day.

### CONVERSATION ON 07-05-2021

**Jeff Bergosh**: You too James!

### CONVERSATION ON 07-06-2021

**James Scott**: Just wondering Jeff if you received any response yet ? I’ve still not heard anything from HR on my Application for driver, ECAT is 20 drivers down in operations. This is the worst I’ve seen in sense my 17 years at ECAT. The Maintenance Department is also Jeff in really bad shape due to like of employees. Thanks James, God Bless

**Jeff Bergosh**: I’ve turned it over to the administrator he’s working on it I wasn’t aware that you were out on leave and also I was not aware that there was a union seniority issue and you being the least senior meant that the other tax had the seniority to go to dayshift ahead of you. But again I’ve turned it over to the top dog in the county and he’s working the issue.

**James Scott**: Yes sir, I am and doing much better as we speak. I was told that Tech was leaving ECAT and he had another job. I had no choice, I was worrying myself sick, I seen a doctor and Jeff my blood pressure had me at Stroke and Heart attack level, so he pulled me out for a while so I can get it back together and I’m doing really well right now and I have to go back Tuesday. That’s why I reached out to you for help or a change of job, I really want to apologize to you for not explaining everything to you. I really from the bottom of my heart want to apologize to you sir.

**James Scott**: It’s not a union seniority Jeff, it’s company seniority. Sorry for the misunderstanding 

**James Scott**: Wes said he was going to be speaking back to me, but not sure when sometime this week. I pray soon. 

**Jeff Bergosh**: Got it. Thanks for the additional detail and again Wes is working it

**James Scott**: Your welcome, I apologize for the miscommunication on my part. But I’m doing good and not all stressed out and ready to come back. Full force, I hope and pray to get my schedule back or days that’s fine with me Jeff, I just can’t go through the treatment I went through for 16 years with the night time supervisor, he is unfair and alone with the night shift guys, the treatment and lies are unbelievable, I’ll just leave it at that. Everyone on days will vouch for that I promise you sir. 

**Jeff Bergosh**: Right on James

**James Scott**: Like I told you sir on the phone, I’ll cut grass, or what ever to stay working for the county, I would like to stay with the county until I’m at least 70 and not all stressed out. 

### CONVERSATION ON 07-08-2021

**James Scott**: Just to let you know Jeff, I’m returning to duty early on July 15 th 2021 as I reported it today to my Daytime Supervisor. We also had a very unfair Master Technician turned his notice in last night at 9:50pm and wrote some nasty emails to Management. The one I had spoken to you a while back about. Prayers does wonders Jeff.

**James Scott**: Sorry to be a pest Jeff, but I just wanted to let you know. 

**Jeff Bergosh**: Thanks for heads up!

**James Scott**: Your welcome sir, I have to give Wes for a job well done Jeff. I want say no more on that. I really and truly appreciate what you do for  our county, I can’t even reach out to my commissioner in my district because we lower class people, I really need help in my neighborhood Jeff the ditches are grown so bad it’s unbelievable, I took my tractor and tried to bush hog it but my wife made me stop because she was scared I was going to turn my tractor over on me. 

### CONVERSATION ON 07-09-2021

**Jeff Bergosh**: Gary-- check this out.  This is the program Sally and I have been using.  First part of the week is tough but it's doable and it works.  You may want to consider giving it---or something very similar--- a try for a couple of weeks and watch the pounds come off.  This morning I weighed 183.6 pounds as I stepped into the shower

