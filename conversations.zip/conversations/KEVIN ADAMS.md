

## CONVERSATIONS WITH KEVIN ADAMS

### CONVERSATION ON 11-20-2019

**Kevin Adams**: BOA honored our request for a 60 day continuation. The request was communicated to JG.  This was done to allow district & county staff time to work on any issues.

Anyway, appreciate your support for the new school for this area.  If you want to discuss more give me a call.

### CONVERSATION ON 12-16-2019

**Kevin Adams**: Jeff, Unfortunately, burned my hand during a cook out over the weekend.

I will be missing the meeting this morning.  Ryan is going to help me attend two school events this morning and then I have to go back to the hospital for more wound care.

**Jeff Bergosh**: Oh my God!!  Wow--sorry to hear that and I hope you'll fully recover Kevin.  

**Kevin Adams**: Thank you

**Jeff Bergosh**: Kevin is there an alternate school board member that can make it to this mornings meeting we're here and we apparently cannot have a quorum without a member of the School board

### CONVERSATION ON 01-13-2020

**Jeff Bergosh**: Hey Kevin- glad to see your hand is healing and good luck in Tallahassee.  

I'm looking to make contact with the baseball booster programs at West Florida, Pine Forest, and Escambia High Schools to help each of these with some county funding.  Who at the district would have appropriate POC information for these entities?

Thanks!

### CONVERSATION ON 03-10-2020

**Kevin Adams**: Jeff I just sent you a email that provides a solution for the thru traffic congestion problem on Rebel Rd, which provides an excellent opportunity to show our constituents that we are working as a team to find solutions.

Let's get our first win!

**Jeff Bergosh**: Thanks Kevin I just read the email and the picture.  The concern I have is there is very little ROW on the east side of Rebel Road, so where would this queuing lane go?

**Kevin Adams**: On the same side that has the new 100 subdivision being surveyed.

County could have this built, along with sidewalks into the plans for the subdivision.

I would also believe you could utilize the fund that contains the sidewalk fees paid into by developers.

Malcolm also stated he would work with the county on the school right of way.

Rebel Rd right of way is going to have to fix, better to fix this little section before the new subdivision makes it much worse.

**Jeff Bergosh**: I'll ask the county engineer to investigate this as a possibility

**Jeff Bergosh**: Thanks for bringing it forward

**Kevin Adams**: Thanks Jeff

I am assuming that the county is going to require the developer to have a correct ROW and sidewalks.

Our Beulah folks would have an aneurysm if that new subdivision go into that location without sidewalks and correct set back for ROW.

Let me know if you want to meet at the location to discuss.

**Jeff Bergosh**: Okay will do Kevin

### CONVERSATION ON 03-13-2020

**Jeff Bergosh**: Have a good weekend

**Kevin Adams**: Thank you!

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-19-2020

**Kevin Adams**: Just checking if you are sending the link for the zoom meeting tonight or in the morning?

**Jeff Bergosh**: Hey Kevin, I sent it to you earlier to your school district email.  Did u not get it?

**Jeff Bergosh**: Just re sent the link

**Kevin Adams**: Nope!  I did get the one that you sent to my personal email.

**Kevin Adams**: You were using my old email address for the school board.  Update your contact to the  new school board email address.

KAdams2@ecsdfl.us

**Kevin Adams**: See you in the morning.

### CONVERSATION ON 05-20-2020

**Jeff Bergosh**: Got it

### CONVERSATION ON 05-23-2020

**Kevin Adams**: Notice one of your questions for your next coffee is "social distancing on buses".

If you are referring to the new federal CDC policy on opening schools, this would be a non starter for Florida school districts.

1 student per bus seat skipping every other row is not attainable for Florida larger school districts, perhaps it may work in Wisconsin, which has hundreds of school districts, but not Florida, nor Escambia County.

I do not believe Corcoran & our Gov will NOT follow the federal CDC guidance on this issue.

Even If the state could double the transportation budget you would not have sufficient number of buses nor drivers.

Just my 2 cents

**Kevin Adams**: One option would be for students to wear masks on the bus, but I believe the Governor will move the schools districts back to pre-closure policy.

If you have a school with an active case, the school will close several days, testing and tracing, deep cleaning and then the school would reopen.

This policy was working well before the closure of school districts.

**Kevin Adams**: The 800 pound gorrilla is whether our local delegation is going to support cuts in our local school district and local county budget.

**Jeff Bergosh**: Thanks for the input Kevin-- I will ask

**Kevin Adams**: Thanks, Meant to say the Governor will not follow the illogical parts of the CDC proposals for opening schools, realized I muffed that in the above comment.

Hope you have a great Holiday weekend.

**Jeff Bergosh**: You too Kevin

### CONVERSATION ON 08-18-2020

**Kevin Adams**: Congratulations on your win!

**Jeff Bergosh**: Thanks Kevin!

### CONVERSATION ON 10-01-2020

**Jeff Bergosh**: In a BCC meeting will call u back

**Kevin Adams**: Okay

**Kevin Adams**: Okay, nothing urgent.  A bunch of judges and amendments on the ballot.  Wanted to know your thoughts.

**Jeff Bergosh**: Oh okay.  I'll talk to my brother who knows all those judges and get his take and I'll call you back.  Hope all's well Kevin

**Kevin Adams**: Thanks!

### CONVERSATION ON 10-16-2020

**Jeff Bergosh**: I'm in a meeting I'll call you when I get out

**Kevin Adams**: Okay

### CONVERSATION ON 10-19-2020

**Kevin Adams**: Malcolm's last board meeting as a Superintendent is Tuesday @ 5:30 PM.

**Jeff Bergosh**: Okay thx for heads up

**Kevin Adams**: Also thank you for expediting the replacement of the lighted school zone sign at Beulah ES.

**Jeff Bergosh**: Absolutely-- no problem.  I'm also getting that washed out section of Beulah Road fixed by FDOT this week.  It's dangerous.

### CONVERSATION ON 12-02-2020

**Jeff Bergosh**: In a mtg

**Kevin Adams**: No worries

### CONVERSATION ON 12-08-2020

**Kevin Adams**: That was my airfield.  The southwest section of site 8 has plenty of high ground.  We have our calzones in that area for pilots to practice landing in a cleared area surrounded by trees.

It has wetlands, but nothing like they are showing on the proposals.

**Jeff Bergosh**: That's what I was thinking too!

**Kevin Adams**: I was shocked how much of the 9 mile frontage they were not going to utilize.

Anyway that was my field and you are correct to challenge what is truly wetland.

**Jeff Bergosh**: Thanks Kevin!

**Kevin Adams**: You're welcome!

**Kevin Adams**: I do need to give you a heads up on a possible issue.  Call when you have time available.

### CONVERSATION ON 01-25-2021

**Kevin Adams**: 
https://colab.dpz.com/olf8/myths-facts/

### CONVERSATION ON 01-26-2021

**Jeff Bergosh**: Yeah I saw this...they're actively working against the BCC now

**Kevin Adams**: 😟

**Kevin Adams**: It was sent to my board email and just making sure you were aware.

**Jeff Bergosh**: Thx-- yes I am.  Check out Ricks Blog.  He's all over it, he sees it for what it is

**Kevin Adams**: Thanks, I'll check it out.

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-13-2021

**Kevin Adams**: I caught part of the BOCC discussions on OLF 8.

Much appreciated your defense of our great educators and students.

Who were you responding too?  What did he/she say?

**Jeff Bergosh**: Doug Underhill

**Jeff Bergosh**: He is just incredible harmful and toxic.  I constantly have to correct his BS on that dais

**Kevin Adams**: Geez!  I will see if I can find it on the video and send him a proper  response.

Thank you for the support.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-16-2021

**Kevin Adams**: Call me when you have a couple of minutes to spare

### CONVERSATION ON 07-06-2021

**Kevin Adams**: Call me

### CONVERSATION ON 07-23-2021

**Kevin Adams**: Hypothetical

Subtract: 62, 86, 99, 102

Add: 67, 105

Call me when you can spare a few minutes.

**Jeff Bergosh**: I'll look at that

**Jeff Bergosh**: Will call you this morning after meetings

**Kevin Adams**: Thanks

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I like the looks of that map

**Kevin Adams**: 😊

**Jeff Bergosh**: Is 105 the last precinct in the SW part of Escambia County?

**Kevin Adams**: Yes

**Kevin Adams**: Perdido key

**Jeff Bergosh**: I like

**Jeff Bergosh**: Lots of folks' heads would explode though, LOL

**Kevin Adams**: Yep

**Jeff Bergosh**: 🔥🔥🔥🔥

**Kevin Adams**: Haha

**Jeff Bergosh**: Heck, I'd be happy keeping 105 only and leaving 67 with D2

**Kevin Adams**: Yep

**Kevin Adams**: 67 does make the district more vertical.

**Jeff Bergosh**: Yes.

**Kevin Adams**: We could always ask for more......lol

**Jeff Bergosh**: Yes!

**Jeff Bergosh**: D 1 Motto:  "we're liberating Perdido Key!  We're taking back the beach!"

**Kevin Adams**: Nice

**Jeff Bergosh**: 😎👍

**Kevin Adams**: We could drop 61 if required to keep 105

**Kevin Adams**: The reason for 67 it would include the new pleasant Grove and is a red precinct.

**Jeff Bergosh**: Oh, okay.  Good-- let's keep that in D1 then!

**Kevin Adams**: 👍

**Jeff Bergosh**: We're building a new fire station down that way too

**Jeff Bergosh**: 👍

**Kevin Adams**: Excellent!

**Kevin Adams**: Look at the second resolution and supporting cnn report.

https://floridapta.org/resolutions-bylaws-lc2021/

**Kevin Adams**: Perfect CRT example

**Jeff Bergosh**: Wow that is radical!!! Thx for sharing I had no idea

**Kevin Adams**: 👍

**Kevin Adams**: I bet 99 percent does not know, at least in the panhandle!  Lol

### CONVERSATION ON 08-05-2021

**Kevin Adams**: Can we have a short meeting in your office after the VAB meeting?

**Jeff Bergosh**: Sure

**Kevin Adams**: Thanks!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-09-2021

**Kevin Adams**: Michelle, Jeff (cc in this text group) is all in for a proposed pedestrian bridge and sidewalks project.  He told me he would have some money available to go with the state funding.

I told Jeff it would be a great idea, when we are ready, for a joint press conference in front of the school with the D1 Representative, Commissioner and School Board Member.

I will not disclose outside of our circle, until the 3 of us are good with the details.

Thank you both for your support for safe pathways to schools.

**Kevin Adams**: Excellent!  Now the devil is in the details and projected cost.

### CONVERSATION ON 08-10-2021

**Kevin Adams**: I just finished a phone interview with WEAR.

**Kevin Adams**: Call me when you can.

**Kevin Adams**: I am receiving many, many messages of gratitude from employees and constituents across the county.  So all is good for now.  Brent did a great job with his news report.

I saw you had a couple of critics on your blog.

### CONVERSATION ON 08-12-2021

**Jeff Bergosh**: In BCC meeting will call u back

**Kevin Adams**: No worries, I got feedback BS has no issue with the video.  I guess 3-2 who have no problem with the video.  This should be a very interesting meeting at 3 pm.

**Jeff Bergosh**: I'll be tuning in.  Good luck-- been there before....

**Kevin Adams**: Thanks, I believe we will have speakers at the public forum.

**Kevin Adams**: Mike Hill told me he would be there

**Kevin Adams**: Good meeting tonight, superintendent apologize and pulled the video.  Thank you for your help on this issue.

**Jeff Bergosh**: Congrats Kevin!!

**Jeff Bergosh**: That was his best and smartest move.  I wonder if someone spoke to him?

**Kevin Adams**: I know the governor and Corcoran were involved.  I was told the gov was proud of my stand on this issue.

However it happen I am greatful for the support I received.

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-16-2021

**Kevin Adams**: At the end of our regular business meeting the chair always asks the board members for anything for the good of the order.  I plan to make the following short comment at our meeting tomorrow night.  Please respond with any suggested edits or thoughts.  Hopefully we can follow up next week or two with the press conference.  Thank you!


“Mr. Chair, I am happy to provide notification that Representative Salzman, Commissioner Bergosh and I had conversations on the importance of resolving the hazardous pathway situation for students attending Beulah Middle School.

As the Superintendent and board knows, we are currently using school buses to transport students across the road to the other side of the road in order for students to safely cross Nine Mile rd.  This situation will only grow worse as more subdivisions and commercial businesses are constructed.

I believe we will hear an announcement soon on the details of a plan to eliminate the hazardous pathways conditions around Beulah Middle School.   The eliminations of these pedestrian hazards would also provide relief for our current critical bus driver shortage.

We appreciate and welcome any assistance that Representative Salzman and Commissioner Bergosh can provide to improve the safety of our students.”

**Jeff Bergosh**: Sounds good to me too

**Kevin Adams**: Excellent!

**Kevin Adams**: Nice teaser!

### CONVERSATION ON 08-18-2021

**Kevin Adams**: I provided my board with the notification as discussed.  All went well.

Next step is deciding on a date and time for the announcement.  I would believe the best location is in front of the school.  Jeff you have a great public relations department and I will follow your lead for the next step.  Thank you!

**Jeff Bergosh**: Okay sounds good.  I'll also make a statement tomorrow at our meeting-- then the three of us can jointly announce!

**Kevin Adams**: Yea

### CONVERSATION ON 08-20-2021

**Jeff Bergosh**: In a meeting-  will call I after

**Kevin Adams**: Okay, attending a funeral 10 to 11

**Kevin Adams**: Email sent as requested

**Jeff Bergosh**: Got it!

**Kevin Adams**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-23-2021

**Kevin Adams**: Northescambia has an article posted on our calculated grades, I also posted on my timeline with comment.

**Jeff Bergosh**: Is NE article correct??

**Kevin Adams**: Yes

**Kevin Adams**: As for the grades

**Jeff Bergosh**: Holy Shit!!

**Jeff Bergosh**: Bellview middle school an F??

**Kevin Adams**: Yep

**Kevin Adams**: 11 F
7 D
21 C

**Jeff Bergosh**: Horror Show

**Jeff Bergosh**: Weis Elementary a D

**Kevin Adams**: I know a board member in South Florida who knows his district has 30 D & F's, and the superintendent will not release to the public

**Jeff Bergosh**: How sad--- So much money spent on those schools that all have F's

**Jeff Bergosh**: Devastating

**Kevin Adams**: Agree.

**Kevin Adams**: It is important for all superintendents to release the grades.  This should be part of the discussion of the impact of covid for students across the state of Florida.

**Jeff Bergosh**: I agree and I think it is a mistake to not release them.

**Jeff Bergosh**: And it creates a trust deficit

**Kevin Adams**: Transparency is the best medicine

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: I just sent over a draft press release for the joint press conference this coming Monday at 4:30 at my office Regarding the pedestrian overpass at Beulah. Take a look at it feel free to chop it or revise it and let's try and finalize it so we can get it out by tomorrow thanks

Jeff

**Jeff Bergosh**: To your email boxes

**Kevin Adams**: Jeff, Fantastic job with the public announcement ! I am available on Monday.

**Jeff Bergosh**: 👍

**Kevin Adams**: Great! 🙌

### CONVERSATION ON 08-26-2021

**Kevin Adams**: I hate to be a party pooper but the 55 mph sign before you enter Buelah MS is still there :(

**Jeff Bergosh**: I'll check on it

**Kevin Adams**: Thanks

### CONVERSATION ON 08-27-2021

**Kevin Adams**: Michelle I see you are having fun with the disciples of Underhill on the  Northescambia.com.  My constituents are happy that we are trying to do something to make it safer around the schools.

**Kevin Adams**: 😊

**Kevin Adams**: Good grief! An elected county commissioner would compare a bar on the beach to a school with a thousand students.  What a nut case!

**Kevin Adams**: We need to remember that the pedestrian crossing and sidewalks will serve 2 schools, Beulah Middle & Beulah Academy of Science.

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Hey guys with the county offices being closed in the hurricane let's reschedule our press conference I'll get with you tomorrow and we'll figure out a date that works. Unless you have major heartburn with it ----call me tomorrow and let's figure it out but doing it at 4:30 at the county won't work because we're closed tomorrow

**Kevin Adams**: Agree on reschedule.

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: Okay great.  I'll be on Rick Outzen's show at 0815 and I'll explain the event for today is called off and we will reschedule it.  Be safe driving today 

Jeff B

**Kevin Adams**: Jeff, are you going to have the county to list our press conference as cancelled?  I sent a  message my media contacts.

**Jeff Bergosh**: Yes-- rescheduled to a date to be determined

**Kevin Adams**: Thanks

### CONVERSATION ON 09-10-2021

**Kevin Adams**: Hi Michelle, Can you contact the Chancellor Jacob and ask him if "Miss Kendra Advance Social Justice" contains CRT.

If it does then the material, by commissioners order, should be removed from all 67 school districts.

I know the core curriculum courses all have to be purchased from the approved list on the state depository.  I do not know if this is an approved item or not.  Thank you!

**Jeff Bergosh**: Is this a "work around" attempt at injecting CRT into schools Kevin?

**Kevin Adams**: I agree Jeff, I asked Michelle to forward to the Chancellor, if it is CRT then it needs to removed or banned from all 67 school districts.

**Kevin Adams**: Thanks

### CONVERSATION ON 09-14-2021

**Kevin Adams**: I was on the phone with the supt.  I am available if you have the time.

**Jeff Bergosh**: Okay I'll call you once I'm off this call

**Kevin Adams**: Okay

**Kevin Adams**: Jim little Called me, we can discuss when you call me.

**Kevin Adams**: Please remember to send the district map.  Thank you!

**Jeff Bergosh**: Okay will do

**Kevin Adams**: Thanks!

### CONVERSATION ON 09-20-2021

**Kevin Adams**: Michelle, I talked to Jeff and he will have staff provide a rough estimate.

Thank you, Jeff!

**Kevin Adams**: https://www.pnj.com/story/news/education/2021/09/20/escambia-parents-keep-pushing-school-board-consider-mask-order/8419261002/

**Kevin Adams**: Looks like it will be an interesting tomorrow night!

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: How about we take 105 and give 99 and 61 to Doug?  What would that do?

**Kevin Adams**: I just sent a link to Peter pan spreadsheet to your Gmail.  Look at the tabs at the bottom, drama, no drama, precincts.

**Jeff Bergosh**: Thanks Kevin I'll check it out!

### CONVERSATION ON 09-30-2021

**Jeff Bergosh**: In mtg I’ll call I right back

**Kevin Adams**: Thanks

### CONVERSATION ON 10-01-2021

**Kevin Adams**: Call me when you have a chance.

**Jeff Bergosh**: In mtg right now will call u after

**Kevin Adams**: 👍

**Kevin Adams**: What was the name of the federal order to maintain a minority district?

**Jeff Bergosh**: McMillan V Escambia

**Jeff Bergosh**: Actually

Escambia County V McMillan

**Kevin Adams**: Thanks! 🙂

### CONVERSATION ON 10-05-2021

**Kevin Adams**: Called and gave my viewpoints unfortunately he had to you got interrupted had to get off the phone so it went a long conversation.

**Kevin Adams**: Voice recognition software stinks at times

**Kevin Adams**: Lpl

**Kevin Adams**: Lol

**Jeff Bergosh**: Thx Kevin

**Kevin Adams**: The hotel has a real week wifi, but it worked good creating a hotspot off my phone.

See you tonight

**Kevin Adams**: Your IT guys have me connected and all seems to work.

**Kevin Adams**: State statute says school board has to do it in an odd year.

**Jeff Bergosh**: Us too

**Kevin Adams**: Sounds like both attorneys are pushing for the same thing

**Kevin Adams**: Let's get r done!

**Jeff Bergosh**: Yes!

**Kevin Adams**: Thank you Barry

**Kevin Adams**: I think you need to get your plan out first. 

**Jeff Bergosh**: I'm going to try to

**Kevin Adams**: Yay!

**Kevin Adams**: Barry wants to get it going too!

**Kevin Adams**: Dang! That's big proposing for it to go to d4

**Kevin Adams**: 88 going to D4

**Kevin Adams**: Here we go

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Now we have to work out what D4 wants

**Kevin Adams**: We need to know what Binder wants to offload.

**Jeff Bergosh**: Exactly

**Kevin Adams**: This may stop Doug from offloading Mayfair.  This may still work.

**Jeff Bergosh**: Yes

**Jeff Bergosh**: And he's not here

**Kevin Adams**: I would put your plan up after patty

**Kevin Adams**: It fixes D1 and d2

**Kevin Adams**: That leaves Luman and binder to swap some land.

**Jeff Bergosh**: Yes I will

**Kevin Adams**: I think it is a good plan

**Jeff Bergosh**: Not enough minorities

**Kevin Adams**: Yep

**Jeff Bergosh**: What's our strategy if he takes a part of Mayfair?

**Kevin Adams**: All of 61, 99 and perhaps some of those minority areas by Marcus point.

**Kevin Adams**: Have them put up your original plan.  We may just have to give all of 61 yo D2

**Jeff Bergosh**: Roberts going for d 2 area in Mayfair

**Kevin Adams**: Binder is still going to be heavy with Mayfair going D3

**Jeff Bergosh**: So how do we keep 105?

**Kevin Adams**: That is now a tough one.

**Kevin Adams**: Binder is going to grab some land from doug

**Jeff Bergosh**: Yes

**Jeff Bergosh**: So we can perhaps give all of 61 to Doug

**Kevin Adams**: That screws you on the beach.

**Jeff Bergosh**: No, we still keep the beach

**Kevin Adams**: Yep, give Doug all of 61.and.99

**Jeff Bergosh**: And perhaps all of 75 east of blue Angel 

**Kevin Adams**: Yep

**Jeff Bergosh**: You good with that?

**Kevin Adams**: Yep 👍

**Kevin Adams**: Does not seem to do anything with the schools assigned.

**Jeff Bergosh**: No schools then we are good

**Kevin Adams**: Try half of 75  and see if 61 and 99 gets us within 3 percent

**Kevin Adams**: Perhaps Luman wants Marcus pointe lol

**Jeff Bergosh**: What about 62?

**Jeff Bergosh**: Michigan/char bar

**Kevin Adams**: I believe 62 is clear of schools and has a lot of minorities

**Jeff Bergosh**: Okay we can give that to Doug and keep 105.  Depending on what else these filly's do

**Jeff Bergosh**: *guys

**Kevin Adams**: Yes it looks good for schools.  Luman may like to have that precinct

**Jeff Bergosh**: He's loaded up now though

**Kevin Adams**: 62 does not join d2

**Kevin Adams**: It joins d3

**Jeff Bergosh**: You're right

**Jeff Bergosh**: Darn it

**Kevin Adams**: Go for it tiger!  Give paul some land

**Jeff Bergosh**: Yep

**Kevin Adams**: You could still offer Luman 62 and keep your original plan

**Kevin Adams**: Let's look at it

**Jeff Bergosh**: He needs to give 

**Kevin Adams**: Yep

**Kevin Adams**: Robert needs to take a break and let you put you plan out

**Jeff Bergosh**: Yes

**Kevin Adams**: Assigned it

**Jeff Bergosh**: I'm going to make a 

**Kevin Adams**: It yes assign it

**Kevin Adams**: Okay now east of Fairfield for 61

**Kevin Adams**: Back off binder

**Jeff Bergosh**: Exactly

**Kevin Adams**: Back off chair

**Kevin Adams**: Go a head yes assign it

**Kevin Adams**: You can use 75 for the finishing adjustments if required.

**Jeff Bergosh**: Yes

**Kevin Adams**: Yes assign it

**Jeff Bergosh**: Got to give back more to Doug

**Kevin Adams**: You did good my friend

**Jeff Bergosh**: Thanks

**Jeff Bergosh**: We might get there

**Kevin Adams**: Yep!  I like it

**Jeff Bergosh**: I do too

**Kevin Adams**: Luman had to drop a hand grenade

**Kevin Adams**: Here we go!

**Jeff Bergosh**: He did

**Kevin Adams**: At least we got our job done!

**Jeff Bergosh**: So far so good

**Jeff Bergosh**: Bender trying to cock block us

**Kevin Adams**: They have 2 high schools, I have one! Lol

**Kevin Adams**: Yep! Bender was working it.

**Kevin Adams**: I believe I help stopped him on 95!

**Jeff Bergosh**: You sure did

**Kevin Adams**: Call me when you get in the car.

### CONVERSATION ON 10-07-2021

**Jeff Bergosh**: We will

**Kevin Adams**: Jeff did a great job!

Having lots of fun ;) at the FSBA Leadership meeting in Ft. Myers

### CONVERSATION ON 10-11-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Kevin Adams**: Why?

**Kevin Adams**: Sorry my phone decided to automatically send you that why? No worries buddy

**Jeff Bergosh**: No problem-- in Denmark 

**Kevin Adams**: FYI the redistricting is on the school board agenda for Thursday. I'm going to try to bring this across the finish line with no changes to the maps.

**Jeff Bergosh**: Ok great! Good luck and I'm rooting for you!!

**Kevin Adams**: 😊

**Jeff Bergosh**: 😎😎😎👍👍👍🙏🙏🙏

**Kevin Adams**: Can you send me a PDF of the final version of the map for our Thursday workshop.  Thank you!

**Jeff Bergosh**: I will.  Been out of town but will be back Wednesday and will get it to you

**Kevin Adams**: Thanks!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-13-2021

**Kevin Adams**: Andrew McKay has Bender option 1 (no beach) and your option 2 (with beach) posted on his radio Facebook site.

### CONVERSATION ON 10-14-2021

**Jeff Bergosh**: LOL

**Jeff Bergosh**: He and Doug really, really don't want the map to go our way.  But they can't stop it and they know it.  They're not in the "acceptance" phase of their grief yet.....

**Kevin Adams**: Paul pulled a big surprise! Please call me

**Jeff Bergosh**: In meeting at BCC

**Jeff Bergosh**: Good surprise or bad one??

**Kevin Adams**: Paul proposal

**Kevin Adams**: Interesting proposal.  I have not found a reason to not like it so far.

**Jeff Bergosh**: I like what I see.  Does it impact the other districts?  If not I like it too!

**Kevin Adams**: Not sure, I would imagine bender would not like it, but if it is within 3 percent, I'm good.

### CONVERSATION ON 10-18-2021

**Kevin Adams**: I plan to park in your D1 visitor parking spot if available.  Thanks

**Jeff Bergosh**: Sure

**Kevin Adams**: 😊

**Kevin Adams**: I have arrived

### CONVERSATION ON 10-19-2021

**Kevin Adams**: Very odd how that D3 precinct was moved over into D1.

Paul was only concerned with D1 and D2.

**Jeff Bergosh**: I think the latest map does the trick

**Jeff Bergosh**: I don't remember 63 getting slid into our district either so glad we figured that one out

**Kevin Adams**: Yep! But D3 and D4 numbers are high.


**Jeff Bergosh**: That's OK there within the tolerance level although District Fort probably needs to give about 3 to 400 votes back to D5 or to D3

**Kevin Adams**: I'm glad you caught it! Thank you!

**Jeff Bergosh**: No problem at all now we just got to do the meeting November 2 and make sure no one gets killed LOL

**Kevin Adams**: It will be an interesting night! Game on!

**Jeff Bergosh**: Game on!

### CONVERSATION ON 10-22-2021

**Kevin Adams**: Call you in about 5 minutes

**Jeff Bergosh**: Thx

**Kevin Adams**: Connor trying to get some sympathy on Beulah Forum.

**Jeff Bergosh**: Thanks for sharing this Kevin

**Kevin Adams**: Conner is posting on every group trying to look for more support.  This one is on Escambia County Politics Issues.

Alex Arduini is upset that he is going to be in district 2 and opposes Owens going to DO.

**Kevin Adams**: Connor post on Beulah Forum recieved zero attention, no likes, dislikes or comments.

### CONVERSATION ON 10-25-2021

**Jeff Bergosh**: I’ll
Call u in 5 min

**Kevin Adams**: Let me call you back, I'm next in line for my flu shot.

**Kevin Adams**: They just told the guy after me it's a 30 minute wait.  So call when you can spare a minute or two.

**Kevin Adams**: I have an executive session Monday morning at 8 am.

We can meet Sunday afternoon or Monday after noon.  Your call.

Yes, I am in Town for the joint meeting on the 2nd.

**Jeff Bergosh**: Monday afternoon sounds good

**Jeff Bergosh**: Also-- can you do 4:00 Monday to go over the redistricting?  We could meet in my office downtown.  Let me know, thanks!

**Kevin Adams**: That will work.  I'll ask Elisabeth to put it on the calendar.

**Jeff Bergosh**: Okay great see u then!

### CONVERSATION ON 10-27-2021

**Kevin Adams**: Fyi, not going to the event to night.  I believe it  is best to wait until after we complete our task next week.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: People are saying Paul's map gave D1 Pensacola Beach as well???  Is that part of his proposal that you remembered??

**Kevin Adams**: Yep, but his fellow school board, including me told him that it was a no go.  He told us he was good not including Pensacola beach.

**Kevin Adams**: I may change my change my mind if RB gets involved with our D1 stuff! LOL

**Jeff Bergosh**: LOL

### CONVERSATION ON 11-02-2021

**Kevin Adams**: Do you have any suggested edits to the benefits of our proposal?



Our proposal

keeps precinct 63 in District 3 as a majority-minority precinct. 

Keeps the D1 Library in D1, Keeps D2 Library in D2

Keeps Bellview Middle and Elementary schools in district 1

Keeps the new Pleasant Grove Elementary in District 2

Keeps district boundaries to primary and secondary roads

Transfer D1 precincts in Myrtle Grove to D2

Allows for adequate room for future high growth by lower general population numbers for District 1

**Jeff Bergosh**: Those are perfect talking points the only thing I would add is this plan also puts the various neighborhoods of Perdido back together as well. Right now after the gerrymandered map of 2000 Perdido Bay country club is cut in half with our proposal they are put back together along with many other neighborhoods in West Pensacola in the Myrtle Grove area

**Kevin Adams**: Call me

**Kevin Adams**: Fyi Connor posted on Beulah Scoop about us.

**Jeff Bergosh**: What a tool

**Jeff Bergosh**: What's his problem?

**Kevin Adams**: No idea

**Kevin Adams**: He is trying to be a good soldier for Doug

**Kevin Adams**: Admin turned off comments for Connors post.  It has one thumbs up and one sad face.  Big thud!

### CONVERSATION ON 11-03-2021

**Jeff Bergosh**: Glad it died off

**Kevin Adams**: Beulah folks happy the redistricting did not impact them.  The only flack we may get is from some of the Perdido key folks.

**Kevin Adams**: EHS has the annual memorial service for fallen gators who served at 9 am this morning.

**Kevin Adams**: Oops!  It is tomorrow!  Lol

**Jeff Bergosh**: Yeah I agree.  For most folks these changes will not impact them at all-- 

**Kevin Adams**: Exactly!

**Jeff Bergosh**: That's a great and somber ceremony

**Jeff Bergosh**: Been many times

**Kevin Adams**: Yep, it is a heart thumper

**Kevin Adams**: Brent says he's shooting for 4:00 or 5:00 on the new cycle. I think the interview went well and they had somebody else from the community they interviewed too.

**Kevin Adams**: The 6 pm news report had good coverage with my concerns, your concerns and the superintendents.

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-04-2021

**Kevin Adams**: Big surprise with the redistricting moved to Tuesday.

**Jeff Bergosh**: Yeah kind of blindsided me

**Jeff Bergosh**: I believe we're okay--- Lumon just wanted some more time and tonight he has to leave early

**Kevin Adams**: Good!  I was wondering if the Mayfair deal was causing him some grief.

**Jeff Bergosh**: Not sure.  He may just need some more time

**Kevin Adams**: DU new plan knocks D1 and D2 ECUA out of office.

Gives D1 more land east on 9 mile rd

Gives D3 downtown

**Jeff Bergosh**: Does it??

**Jeff Bergosh**: Non-starter

**Kevin Adams**: You may need to be careful of a new coalition of DU, LM & RB.  It may be nothing, but it needs to be watched.

If they knock out the 2 ECUA reps I would push the board for us to do our own map.

### CONVERSATION ON 11-05-2021

**Jeff Bergosh**: I agree.  Doug's new map goes nowhere

### CONVERSATION ON 11-09-2021

**Kevin Adams**: Interesting PH is attending your meeting.  Watching the live stream.

**Jeff Bergosh**: Yes.  Ellen Odom is here as well

**Kevin Adams**: Yes, She told me she was going to attend the meeting.  I did not know about PH. 

**Kevin Adams**: Nice to get an honorable mention!  Lol

**Jeff Bergosh**: LOL

**Kevin Adams**: Chris still has a crosshatched in D3 Mayfair

**Kevin Adams**: Double check to make sure I'm correct.

**Kevin Adams**: It is a very small area

**Kevin Adams**: Congratulations!

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: In BCC mtg

**Kevin Adams**: 👍

**Kevin Adams**: We had no discussion on the redistricting map at our workshop.

It is on the agenda tonight for approval.

### CONVERSATION ON 11-18-2021

**Jeff Bergosh**: Fetsko is at Underhill's Town Hall.  They are downplaying the importance of the number of schools per district 

**Kevin Adams**: That is a mistake by Paul.

**Jeff Bergosh**: I'm watching him now. 

**Jeff Bergosh**: He's saying they'll change the map if the county does

**Kevin Adams**: Paul is not political savy, hopefully he will not stir up additional drama.

**Kevin Adams**: Vickey and I are at the National Summit on Education conference.  We are at the reception now.

**Jeff Bergosh**: Have fun!

**Kevin Adams**: How did the rest of the town hall go.? Was this the Beulah Town hall?

More folks attending?

**Jeff Bergosh**: No this is the one in Innerarity

**Jeff Bergosh**: He's a Chamaeleon

**Kevin Adams**: Yep!  I want you guys to your vote done and let's move on! ;)

**Jeff Bergosh**: He's getting some traction in this meeting tonight it's kind of pissing me off

### CONVERSATION ON 11-19-2021

**Jeff Bergosh**: Paul Fetsko is at Doug's Beulah town hall tonight.....

**Kevin Adams**: What...........

**Kevin Adams**: That is sad

**Jeff Bergosh**: Yeah-- not sure why 

**Kevin Adams**: That pisses me off!

**Jeff Bergosh**: He didn't mention you so that's good

**Kevin Adams**: I sent him a message telling him I'm having a hard time understanding why he was at the Underhill Beulah Town hall.  I will let that sink in for a week or two before I talk with him again.

Getting a little tired of the I'm abuse stuff.

**Kevin Adams**: He sent me a message back that he knew I was out of town and wanted to be their to answer any school question.

Very weak answer.

I told him that people called saying they were stunned that he would be part of the Underhill/Owen/Connor Carnival show in Beulah.  I told him that I was also stunned he would do something like that.

Perhaps he need some lessons in politics.  Lol

### CONVERSATION ON 11-20-2021

**Jeff Bergosh**: I think he'll get the message after reading that text Kevin!!

### CONVERSATION ON 11-22-2021

**Kevin Adams**: Can you give me a call?  I watched both Town Halls and have some concerns.

### CONVERSATION ON 12-02-2021

**Kevin Adams**: Congratulations on approving the map.  Now it is my turn to bring it across the finish line.

**Jeff Bergosh**: Thanks Kevin!!  You're up next!

**Kevin Adams**: 😊

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-06-2021

**Kevin Adams**: That is on the table for tomorrow morning planning board rezoning meeting.

### CONVERSATION ON 12-09-2021

**Jeff Bergosh**: I’ll call u right back

### CONVERSATION ON 12-14-2021

**Kevin Adams**: Read this redistricting past the board 4-0 with fetsko absent

**Kevin Adams**: No public speakers

**Jeff Bergosh**: Right on Kevin!! Way to go, congrats!! 

**Kevin Adams**: 😊

**Kevin Adams**: Boy!  My voice recognition software while driving sucks! Lol

**Jeff Bergosh**: LOL

**Kevin Adams**: Vote on redistricting tonight pass on a 4-0 vote!  No discussion by the board, no public speakers.

**Jeff Bergosh**: That's awesome.  No speakers

**Kevin Adams**: We had speakers, but they were all speaking against the city plan to put a homeless shelter 925 feet from the school.

**Jeff Bergosh**: Nobody wants that except for Grover!

**Kevin Adams**: Exactly!

**Kevin Adams**: Anne Hill showed up tonight and we discussed it after the meeting.

Feel sorry for her that district 1, 2, 3,and 4 voted to do a number on her district.

The city has a superintendent and 5 board members telling them that this facility should not be located this close to the school.

Something happens they will own it.

**Jeff Bergosh**: Yep

**Kevin Adams**: I googled on this and was shocked how many school districts had similar problems with progressive left cities putting shelters and tent camps beside schools.  A lot of these schools could not even get city police to respond to homeless issues.  Never thought I would see this in Pensacola.

### CONVERSATION ON 12-15-2021

**Jeff Bergosh**: Me neither.  The last several years there's been a lot of things with this city I never thought I'd see

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas to you and your family Kevin!

**Kevin Adams**: Thank you!  Hope you and the family have a Merry Christmas and a wonderful New Year!

### CONVERSATION ON 01-07-2022

**Kevin Adams**: I have an opponent, Connor Mann the intern to Doug Underhill.

**Jeff Bergosh**: Are you kidding me???????????

**Kevin Adams**: Not at all!

**Kevin Adams**: Lives with grandma and mommy next to Vickeys mom and dad!  Lol

**Jeff Bergosh**: You'll crush him

**Kevin Adams**: I thought Doug might do something like this after my partnership with you on the redistricting.

**Jeff Bergosh**: Doug's about to get crushed soon

**Kevin Adams**: I will run like I'm down 15 points!  ;)

**Kevin Adams**: Hope so

**Kevin Adams**: Could not happen to a nicer guy.

**Jeff Bergosh**: Yep

### CONVERSATION ON 01-17-2022

**Kevin Adams**: Pastor felt better learning it was not a bar, but a restaurant.

He is not close to the area.  It appears pastors close to the restaurant are doing a call to arms.

**Jeff Bergosh**: Right on.  Thanks for the heads up

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Hey Kevin I didn't know if you saw that story last night on channel 3 about the bill in the legislature looks like they're gonna try and strip salaries away from school board members you may want to try and get ahead of it

### CONVERSATION ON 01-28-2022

**Kevin Adams**: Not sure if this is a positive or negative PR for the locals.

### CONVERSATION ON 01-31-2022

**Kevin Adams**: Thank you for the invite! I thought it went real well for you! Great job! I knew I wouldn't have too many questions about schools so it went the way I thought. 

**Jeff Bergosh**: Thanks very much Kevin-- thanks for coming out and being there!

**Kevin Adams**: 😊

### CONVERSATION ON 02-01-2022

**Jeff Bergosh**: In my will call u back

