

## CONVERSATIONS WITH FRED DONOVAN

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Fred—we’re just about 24 hours away from my fundraiser tomorrow form 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

