

## CONVERSATIONS WITH WILLIAM VAN HORN JR

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: Governor just preempted is

**Jeff Bergosh**: What’s your email address—I’ll send you his executive order

### CONVERSATION ON 05-18-2020

**Jeff Bergosh**: Hello Bill and William— just wanted to share some recent good news I got back from my polling firm on my race....I’m beating Casey by 16 points among those who’ve decided, and I’m beating Doug Underhill’s secretary by 30 points among these same voters.  I’m going to crush Owens like a roach. Not even close........

Anyway, hope all is well with you both.  

Jeff Bergosh 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-22-2021

**Jeff Bergosh**: Awesome!  Thanks Grover— see you all on the 30th!

**Jeff Bergosh**: I’ve just got his office #

8505954930

**Jeff Bergosh**: 👍

