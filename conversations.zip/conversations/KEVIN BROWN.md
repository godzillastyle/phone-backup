

## CONVERSATIONS WITH KEVIN BROWN

### CONVERSATION ON 03-29-2021

**Jeff Bergosh**: Hello Kevin— congratulations on the run for BCC!!I hope you have a productive week in Tallahassee.  Thank you so much for taking a moment to speak with me about the upcoming redistricting and more importantly---the onerous “add-on” that was hastily placed on the very end of HB 7041 while it was still a committee bill.  The Senate companion SB 90 is a very good bill and most of us statewide support it. We also support the vast majority of the provisions contained within HB 7041.As you know and as we discussed this added provision that was added at the table during a committee hearing will make every county commissioner who is elected in a single member districts state wide have to run for reelection next year. This includes those of us who just won hard fought contests last year in Escambia County.
This will cut our terms in half and many of us may very well lose our subsequent election(s).  

The justification I hear for this added provision is because after redistricting —-some voters will live in districts and be represented by county commissioners that they did not vote for for the last two years of such commissioners' terms. However that justification does not square with the reality of what has been added to the bill. If that was truly the goal then these provisions should/would apply equally to all single member district school board members and authority board members like ECUA board members here in Escambia County as well. But because it doesn’t —-it debunks the voter purity justification and again—only seems punitive toward  county commissioners. If this is the intention of the legislature and they have to have this language— enactment of this provision of this legislation should be delayed.  This is  due to the COVID-19 pandemic and the tremendous delay in redistricting this year That we are all now dealing with and will be dealing with in addition to this bill if it passes—-because the Census Bureau is so far behind many counties like Escambia more than likely will not finish the redistricting process this year.  the effective date of this provision of the bill, if this language must be included, should be pushed out to July 31, 2022 to allow all counties the opportunity not to rush redistricting which would risk litigation.  Additionally—This would allow time for all potential candidates and current office holders to plan for the reality of running three elections within four years. Yes —- we know this also impacts 20 of the 40 state senators who also must re-run 2 years early—they must re-run after the decennial redistricting—however they have always known this as this had always been the case under the Florida Constitution.  By contrast —Local office holders have never had to meet this requirement and so therefore many of us were caught flat-footed. Again—-If it’s truly about one vote one voter and fair representation--then this should apply to all single member elected county office holders state wide, however it does not and therefore just seems to be punitive toward county commissioners.  In addition: 

—-this legislation if passed with this provision will reduce the amount of available campaign contributions made to all candidates as there is a finite number of check writers in each county and this provision would require nearly 160 County commissioners state wide to run again two years ahead of time the effect of which would be a fight for campaign dollars between and among Republicans at all levels of government leading to a massive sucking of campaign contributions away from all candidates most specifically important state wide Republican candidates. 


——This legislation, if passed with this provision will be extremely burdensome on county supervisors of elections who will suddenly have to deal with all commissioners county wide running simultaneously—This could lead to a loss of institutional knowledge if a majority of commissioners lose their elections. Also this will slow the work of government significantly as additional time and effort would necessarily have to be put into campaigning and fundraising by all such candidates— which would slow tough decision making and slow down important projects.

Thank you very much in advance Kevin for any help you can give with slowing this destructive provision down——or at a minimum at least having the effective date of this section delayed-----if it must be added------until July 31 of 2022.

As we discussed— if this is going to go and there’s no stopping it I’d really appreciate knowing that as soon as possible to prepare.

Thanks very much!

Jeff Bergosh 
Escambia County Commissioner District 1

**Kevin Brown**: Thank you!! I’ll be back in touch with anything I’ve learned regarding that issue this week. 

**Jeff Bergosh**: Thx

### CONVERSATION ON 04-13-2021

**Jeff Bergosh**: Good Morning Kevin—I have a quick process question.  Do you have a minute to talk?

### CONVERSATION ON 04-26-2021

**Kevin Brown**: I’m told the senate is going to stick with their version. Wait til Wednesday though to know for sure, but it’s on track to stay the way it is.

**Jeff Bergosh**: That’s fantastic I appreciate the update Kevin.  I watched the depart and vote earlier today.  I hope the house takes the Senate version

**Kevin Brown**: They should, but we shall see... 

### CONVERSATION ON 04-27-2021

**Jeff Bergosh**: Looks like they did it.  Ingnolia’s strike all amendment does not contain the commissioner election language 

**Jeff Bergosh**: He filed it at 1:33AM

### CONVERSATION ON 10-07-2021

**Kevin Brown**: Hey, free for lunch or coffee next week?

**Jeff Bergosh**: Absolutely— I’m in Copenhagen until 

**Jeff Bergosh**: Call u when I get back

**Kevin Brown**: Sounds good. Safe travels!

**Jeff Bergosh**: Thx!

### CONVERSATION ON 10-16-2021

**Kevin Brown**: Sorry we keep missing each other. Free for lunch Monday or Tuesday?

**Jeff Bergosh**: I think I’ve got meetings this week early— I’ll call you Monday so we can set it up— have a great weekend!

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: I’ll be there!

**Kevin Brown**: Thank you!

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-04-2021

**Jeff Bergosh**: Hey Kevin I know it’s short notice but there will be a constituent meeting about drainage and stormwater issues in district 2 what will be the new district to today at 2 o’clock if you can make it I will get you the address if you’d like to come and meet the constituents.

**Kevin Brown**: I will try. I’ve got some commitments this afternoon already though. Is it the Flood Defenders? Because I’m meeting with them this week.

**Kevin Brown**: I may be a few minutes late but I will be there. What’s the address? Thank you for inviting me. 

**Jeff Bergosh**: No problem at all Kevin it will be at the intersection of Rossi way and Dowdy drive.  2:00 PM

**Kevin Brown**: Headed that way. Should be there in about 30. 

**Kevin Brown**: I just left. That was very informative. Thank you again for allowing me to be there!

**Jeff Bergosh**: No problem at all I think it was a good idea that you showed up and I think that will go along way with the folks

**Kevin Brown**: For sure. 

### CONVERSATION ON 01-08-2022

**Kevin Brown**: Free for coffee or lunch next week?

**Jeff Bergosh**: Sure Kevin, let me check my calendar and I’ll touch base Monday.  Happy New Year!

**Kevin Brown**: Sounds good. Thanks!

### CONVERSATION ON 01-11-2022

**Jeff Bergosh**: Hey Kevin I checked and Adonna’s bakery has moved locations and doesn’t open until later. So let’s just move our meeting to bodacious brew right there at Main Street and Palafox at 8 o’clock let me know if that works I’ll see you in the morning!

**Kevin Brown**: That’ll work. See you then!

