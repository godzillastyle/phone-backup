

## CONVERSATIONS WITH MR TINGLE CHEF

### CONVERSATION ON 04-28-2021

**Jeff Bergosh**: Thanks for forwarding this Mr. Tingle!

### CONVERSATION ON 05-01-2021

**Jeff Bergosh**: Will do!

