

## CONVERSATIONS WITH RICK OUTZEN

### CONVERSATION ON 03-09-2020

**Rick Outzen**: Call when convenient 

### CONVERSATION ON 03-10-2020

**Rick Outzen**: Do you have Matt Coughlin’s cell?

**Jeff Bergosh**: I only had his county issued cell #

### CONVERSATION ON 03-13-2020

**Jeff Bergosh**: Zero tests conducted in Florida yesterday?!?  That’s incredible to me! (And not in a good way...)

**Rick Outzen**: DOH wants us to trust them. How can we?

**Jeff Bergosh**: Yes— not exactly the best way to instill confidence

**Rick Outzen**: Agreed.  DOH just issued statement it will include private lab results.  Might give us a fuller picture 

**Jeff Bergosh**: That was a good decision.  Three weeks late, but good decision nonetheless.  Desantis went into this emergency with a very high approval rating—-if he doesn’t get a handle on the department of health and this apparent ineptitude it’s going to hurt him.  He’s a smart guy and I’m sure he knows this so it will be interesting to see what he does with the information

**Rick Outzen**: Media reporting Trump will declare national emergency this afternoon

**Jeff Bergosh**: Probably a good decision. What will the stock market do though? It’s up today is it gonna turn the other direction?

### CONVERSATION ON 03-14-2020

**Jeff Bergosh**: 14 of the new batch of 25 COVID cases announced this morning are not travel related.  More than half.  Concerning.........luckily none locally but with no testing yet who is to say it’s not here already?

**Rick Outzen**: Which has been my point 

**Jeff Bergosh**: And mine too.  Community spread

**Jeff Bergosh**: I wonder how they will dress this up for the next news conference? Will there be honest or will they downplayed it?

**Rick Outzen**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry— pocket dialed u

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: This is tomorrow morning.  If you have questions you would like answered, Id be happy to ask them if you forward them to me—or you can tune in on the Facebook live yourself and ask them.

**Rick Outzen**: Thx

### CONVERSATION ON 03-25-2020

**Rick Outzen**: Hear you want to reopen the beach

**Jeff Bergosh**: Yes, if it can be done safely particularly now that Spring Break is over.  Funny how that became the headline from this mornings meeting with Dr. Lanza......

**Jeff Bergosh**: *misbehavior

**Rick Outzen**: Shouldn’t wait for at least last week’s test results to cone back? Ive got people tested 3/14 still waiting.

**Rick Outzen**: Also do allow people from highly infected areas on the beach?  Desantis limited air travel but not drivers

**Jeff Bergosh**: Well of course sure. A lot can change in a week. But that comment that I made was simply in response to the idea that it’s good to be outside. Plus I’ve had constituents call me and ask about surf fishing or surfing. And so the real question is if I am a condo owner and pretty Dokey right now I can go out my back door and enjoy my beach but ordinary citizens can’t   Enjoy their own public beach. seems unfair

**Jeff Bergosh**: *perdido key

### CONVERSATION ON 04-08-2020

**Rick Outzen**: What was the answer to my question about Gilley’s next press conference?

**Jeff Bergosh**: She said she’d do one when there was new information above and beyond the sitrep and news releases to report

**Rick Outzen**: With all due respect, bullshit. 

**Rick Outzen**: We have no vehicle to ask any questions in an open forum

**Jeff Bergosh**: I think she’ll be doing one in the near future

**Jeff Bergosh**: Have you called Steven? He might nudge her as chairman? 

**Rick Outzen**: I’m on it

**Jeff Bergosh**: 👍

**Rick Outzen**: Have you gotten today’s Sitrep?

**Jeff Bergosh**: Not yet

**Rick Outzen**: Pls fwd to rick@inweekly.net when you get it. Thx

**Jeff Bergosh**: Ok

**Rick Outzen**: Strange still no report. Thought SOP required by state was to complete a report every day. 

### CONVERSATION ON 04-09-2020

**Jeff Bergosh**: I’m going to request it this morning so I can do my daily analysis.  In my conference call with Alison and Janice, there was concern that the daily Sitrep—the one with the hospital information—may have portions not releasable to the public. That was Alison’s

**Jeff Bergosh**: ...take on it.  I should have a definitive answer at some point this morning.

**Rick Outzen**: Ask her to cite statute. I will

**Jeff Bergosh**: I will

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/one-sitrep-will-be-public-other-one-is.html?m=1

**Rick Outzen**: Sad

**Jeff Bergosh**: I believe we will get it back, with any confidential information pulled.  It is a good report and I’m of the belief that the more we can share with the public the better....this will reduce the public’s anxiety/fear. 

**Rick Outzen**: Agreed. 

### CONVERSATION ON 04-10-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/i-want-information-released-im.html?m=1

**Jeff Bergosh**: I think the information should be released I think making the SITREP classified was a huge mistake.   I’m calling for the release of the daily SITREP again to the public and I’m requesting a special meeting online next week to do it!

**Rick Outzen**: Agreed. Leads to mistrust and fear.  I reached out to Andrade to ask gov about it

### CONVERSATION ON 04-12-2020

**Jeff Bergosh**: Good Morning Rick and Happy Easter.  In case you wanted to know, because they have walked back their initial bad decision to keep the report from the public, I will be sending out an email to the administrator this morning officially withdrawing my request for a public meeting of the board.  Because they’ve made this decision to make the full SITREP public—which is the correct decision —a virtual meeting the board next week won’t be necessary. So I anticipate the board will not meet again until planned on May 7.

**Rick Outzen**: I asked for reports for 4/8-4/10. None were produced. Is the EOC even monitoring the highly infected nursing home in downtown Pensacola?  ALF cases up to 28

**Jeff Bergosh**: We are monitoring that Rick—in close coordination with DOH.  It is generating a lot of questions which I’ll be asking of my panel on Wednesday morning on my Coffee.  I’ll have Gay Nord of WFHospital, Eric, and Janice as well.  If you have questions, I’m happy to ask them like last week.  Have a great Easter Rick!

**Rick Outzen**: Seems like it should be in SitRep

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/bringing-restaurants-to-beulah.html?m=1

**Jeff Bergosh**: Positive news that’s being exceptionally well received online right now.  Good news for a COVID-19 weary community.........

### CONVERSATION ON 07-02-2020

**Rick Outzen**: County 194 new cases; Florida 10,109. Local residents 174 and 19.4% positivity for July 1

**Rick Outzen**: You might enjoy.

**Rick Outzen**: https://ricksblog.biz/sds-hospital-capacity-vs-new-cases/

**Rick Outzen**: 


### CONVERSATION ON 07-03-2020

**Jeff Bergosh**: Rick-I think you will appreciate this

**Jeff Bergosh**: Have a great 4th!

**Rick Outzen**: Like the good old days

**Jeff Bergosh**: Better

### CONVERSATION ON 07-23-2020

**Rick Outzen**: I received this letter signed by 53 women. Please protect them from retaliation from the guards. It took courage for them to do this. 

**Rick Outzen**: Letter

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: Has this been reported to the appropriate staff——where the hell is our Medical Doctor Rayme Edler on this???  She is paid $200 Grand— what’s her professional opinion??

**Rick Outzen**: I sent Laura Coale asking for comments. Cc all commissioners 

**Jeff Bergosh**: Didn’t get it— when did u send it?

**Rick Outzen**: Right before text

**Jeff Bergosh**: 👍

**Jeff Bergosh**: It’s just probably working it’s way through cyberspace then

**Rick Outzen**: Check my blog

**Jeff Bergosh**: Will do

**Rick Outzen**: Really worried about retaliation 

**Jeff Bergosh**: The antidote to retaliation is fact and a spotlight Rick

**Rick Outzen**: Yep

**Jeff Bergosh**: If this is true—I hope you know I will not allow that

**Rick Outzen**: I don’t get many letters like this. Took courage to do

### CONVERSATION ON 08-18-2020

**Rick Outzen**: Good luck today

**Jeff Bergosh**: Thank you Rick!

**Rick Outzen**: Congratulations 

**Jeff Bergosh**: Thanks Rick!!

### CONVERSATION ON 12-14-2020

**Rick Outzen**: Check out my blog

**Jeff Bergosh**: Wow!  Thanks for standing up to point out their shortcoming on this! 

**Jeff Bergosh**: Much appreciated!

**Rick Outzen**: Thx

**Jeff Bergosh**: You made an excellent point about the similarities of the Langley Bell 4-H deal.  Very apropos.

### CONVERSATION ON 12-17-2020

**Jeff Bergosh**: Very good points you’ve made about the economic value of jobs compared to ad valorem taxes—thanks for doing these posts and the outtakes Rick!!

**Rick Outzen**: Thx

### CONVERSATION ON 01-27-2021

**Jeff Bergosh**: Nice posts on the DPZ propaganda and opinion link.  You’ve successfully put your finger on the jugular vein. Congrats.  BTW—You would’ve loved being a fly on the wall when I had my phone conversation with Travis Peterson yesterday LOL. He knows I’m pissed and they’re gonna walk back a lot of that crap that they put on that site!

**Jeff Bergosh**: Call dropped.  I’ll call u back

### CONVERSATION ON 01-28-2021

**Rick Outzen**: Do you have copy of letter of intent for olf8

**Jeff Bergosh**: Yes- I’ll forward it to you

**Rick Outzen**: Thx

### CONVERSATION ON 02-01-2021

**Jeff Bergosh**: Excellent post!!!

**Rick Outzen**: Thx

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: 


**Rick Outzen**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Which emails— internal ones?  I’d be interested to see those

**Rick Outzen**: Yes. They replied that I will them today.

**Jeff Bergosh**: Wow.  Wonder what’s in them to make them hold out.  Regardless— how can you know with certainty they won’t “cherry pick” and only send you the ones that put them in a positive light?

**Rick Outzen**: I can’t. We’ll see 

**Jeff Bergosh**: Will you publish a link to these?

**Rick Outzen**: Once I review them

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-10-2021

**Rick Outzen**: Check blog

**Jeff Bergosh**: Will do

**Jeff Bergosh**: I’m going through the same emails you have now too I requested them from Janice and Allison and they provided me the dropbox. There’s some very disturbing emails between Travis and Lisa Savage and Kevin Robinson and Madison Arnold were Travis is attempting to ghost write the stories. In one of these emails embarrassingly Lisa really speaks deriding Lee toward one of her reporters it’s embarrassing.

**Rick Outzen**: I’ll call you on my way home. Interesting they gave you emails too

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: WEAR smashing my blog this morning— downloading emails I posted LOL

**Jeff Bergosh**: Wonder if they’ll cover

**Rick Outzen**: She keep saying what citizens overwhelmingly support. How many Beulah residents voted on her four options?

**Jeff Bergosh**: Exactly 

**Jeff Bergosh**: 272?

**Rick Outzen**: 271 voted but don’t know how many live in 32526 zip

**Jeff Bergosh**: And a lot that live in 32526 are not in Beulah.  Lots in Bellview

### CONVERSATION ON 02-16-2021

**Jeff Bergosh**: Did u get the latest email dump yet?

**Rick Outzen**: Yes. Can I call you on my drive home?

**Rick Outzen**: About 6

**Jeff Bergosh**: Absolutely.  I got them this morning but have been slammed all day at work.  Just now going to be able to go through them

### CONVERSATION ON 02-18-2021

**Rick Outzen**: Call when up

**Rick Outzen**: Check out blog post on community input

**Jeff Bergosh**: Will do.  Incidentally— nobody, not one person from the “Beulah Coalition” came to public forum this morning.  Not one.  Interesting

**Jeff Bergosh**: Devastating stats in that post

**Rick Outzen**: Neighbors had support for commerce park

**Jeff Bergosh**: Yes

### CONVERSATION ON 02-22-2021

**Rick Outzen**: Check blog

**Jeff Bergosh**: Will do

### CONVERSATION ON 08-04-2021

**Jeff Bergosh**: 💥💥💥GREAT blog post!!! Totally 100% factual💥💥💥

### CONVERSATION ON 08-05-2021

**Rick Outzen**: Start WCOA next Monday. Can you come on the show by phone in 7:30-7:45 segment?

**Jeff Bergosh**: Yep!  Thanks!

**Rick Outzen**: Ok We will text you about 5 minutes before we call you. Thx

### CONVERSATION ON 08-09-2021

**Rick Outzen**: Jeff, have you down for 7:30. Please call at WCOA 850-542-4545 then. We will talk about Jana Still emails. Will go about 6-8 minutes

**Jeff Bergosh**: Ok, got it

**Jeff Bergosh**: On hold with Gospel music?

**Rick Outzen**: Thank you

**Jeff Bergosh**: Thanks Rick!

**Jeff Bergosh**: Is that going to be made into a podcast I can link to?  

**Rick Outzen**: Yes

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-15-2021

**Rick Outzen**: We’re doing a show on hurricane prep tomorrow. Could you come on at 7:45?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Thanks!

**Rick Outzen**: Great. Call into 850-542-4545. If busy 850-478-3116

**Jeff Bergosh**: Will do.  Talk to you then

**Rick Outzen**: 👍

### CONVERSATION ON 08-16-2021

**Rick Outzen**: It was a butt dial sorry 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I’m on the call

**Rick Outzen**: Great. Thx. Will have u soon

**Jeff Bergosh**: 👍

**Rick Outzen**: Great interview 

**Jeff Bergosh**: Thanks Rick— thanks for having me on

**Jeff Bergosh**: I broke some news on my blog this morning— you may be interested in

**Rick Outzen**: Will read

**Jeff Bergosh**: ——legal memo from 5-4-21,  Never shared with the board never brought to our shared session in June indicating we were exposed to potentially more than $800,000 in damages if we didn’t settle. Of course the news journal did not receive report this inconvenient fact

**Rick Outzen**: Let’s do radio again. Weds 7:30?

**Jeff Bergosh**: Sure.  To talk about this?

**Rick Outzen**: Yes!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I’ll be there!  Thanks!!

### CONVERSATION ON 08-17-2021

**Rick Outzen**: Have you done for 7:30 tomorrow. Call into 850-542-4545. If busy 850-478-3116

**Jeff Bergosh**: Will do- thanks!

### CONVERSATION ON 08-18-2021

**Jeff Bergosh**: Thanks Rick!

**Rick Outzen**: Great interview 

**Jeff Bergosh**: Thanks!

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-08-18T12_31_33-07_00

### CONVERSATION ON 08-30-2021

**Rick Outzen**: Can you come on radio at 7:40 or 8:15 to talk about Beulah announcement later today?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Because county is closed for Hurricane Ida-we’re postponing the news conference today. This will be perfect we can discuss and I’ll give listeners the revised date

**Rick Outzen**: Ok. Call into 850-542-4545. If busy 850-478-3116

**Jeff Bergosh**: 👍

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-08-30T14_55_25-07_00

### CONVERSATION ON 09-02-2021

**Rick Outzen**: Will u come on show tomorrow at 7:15 and talk about censure?

**Jeff Bergosh**: Sure will

**Jeff Bergosh**: I’ll call at 7:15

**Rick Outzen**: Ok. Call into 850-542-4545. If busy 850-478-3116

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-03-2021

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-03T06_55_36-07_00

**Jeff Bergosh**: Thx 👍

### CONVERSATION ON 09-06-2021

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-06T08_36_22-07_00

**Rick Outzen**: You might enjoy this one

**Jeff Bergosh**: Thx— I’ll give it a listen

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/09/clerks-attorney-provides-memo-and.html?m=1

**Rick Outzen**: Interesting that this comes out after bcc hires attorney 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I think it’s because they know they’re on the wrong side of it and I’m not gonna let it go

**Rick Outzen**: Agreed 

**Rick Outzen**: Anything to avoid court.

**Jeff Bergosh**: The whole thing was so avoidable she just wanted to pander to the press at the news Journal

**Jeff Bergosh**: Instead of working with us to fix it without the spectacle

**Rick Outzen**: Take her to court. Your attorney is free

**Jeff Bergosh**: I have a feeling that’s where we’re headed particularly if they follow through with their unilateral threat to withhold all payments if they don’t get a response within 30 days which is what they are threatening in there memo. It already appears to be ultra vires.  what would that be?

**Rick Outzen**: Take her to court. Get an injunction until resolution by judge

**Jeff Bergosh**: Yep- it’s time

**Rick Outzen**: Let’s talk about this on radio tomorrow 8?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: I’ll call u

**Rick Outzen**: Thx

### CONVERSATION ON 09-07-2021

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-07T08_00_19-07_00

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-14-2021

**Rick Outzen**: Can you do radio interview tomorrow on redistricting?  8:15?

### CONVERSATION ON 09-15-2021

**Jeff Bergosh**: Sure can!  I’ll call you then!

**Rick Outzen**: Thx

**Jeff Bergosh**: 👍

**Jeff Bergosh**: For reference when we talk at 0815

**Rick Outzen**: Thx

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-16-2021

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-16T12_35_03-07_00

### CONVERSATION ON 09-27-2021

**Rick Outzen**: How about coming on show tomorrow and talk about the outcome of EMS workers cases? 7:10?

**Jeff Bergosh**: Sure— would love to!

**Rick Outzen**: Thx Call into 850-542-4545 at 7:10. If busy 850-478-3116

**Jeff Bergosh**: Got it!

### CONVERSATION ON 09-28-2021

**Rick Outzen**: Go ahead and call

**Jeff Bergosh**: Thanks Rick!

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-28T08_20_53-07_00

**Jeff Bergosh**: Liked “https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-28T08_20_53-07_00”

### CONVERSATION ON 09-29-2021

**Jeff Bergosh**: Guess someone doesn’t want me sharing the podcasts as I have been doing.  And yes, I’ve already asked staff to unblock me.  This ain’t the school district—I’m fairly sure they’ll do it quickly

**Rick Outzen**: Lol

### CONVERSATION ON 10-06-2021

**Rick Outzen**: Could you done a phone interview for radio on yesterday’s joint meeting with school board? 7:45? Thx

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Want me to call the same number?

**Rick Outzen**: Yes.  Thx

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-10-06T07_15_46-07_00

**Rick Outzen**: Thx 

**Jeff Bergosh**: Thanks Rick!

### CONVERSATION ON 10-07-2021

**Rick Outzen**: From Peacock on my blog post: Pretty disappointing he publish that since one it is still a working draft into well I have advocated for a county mayor the whole point of a commission with that many members is for the commission to decide which form of government is better. Clearly our current system doesn’t work however there are plenty of council manager forms in a charter government that do work.

**Jeff Bergosh**: He knows I disagree with him.  We don’t need a boss hog Malcolm Thomas type “elected” mayor of the county.  Been there, done that.  Peacock doesn’t understand because he hasn’t lived under a tyrant but I have.  And oh, by the way, if that system is such a peach then why are Peacock and the others so lathered about the current system
In the city where it’s gridlock between Grover and four of the council women LOL

**Jeff Bergosh**: I happen to think that with the exception of Underhill the four of us are making a lot of progress.  Of course the press will always look for the negative no
Matter what though.  It’s their nature to do so

### CONVERSATION ON 10-11-2021

**Rick Outzen**: Are available to come on radio tomorrow at 7:30? We can figure something to discuss

### CONVERSATION ON 10-12-2021

**Jeff Bergosh**: Rick I’m traveling in Europe and missed this text.  I’d be happy to be on the show when I’m back in Pensacola

### CONVERSATION ON 10-27-2021

**Rick Outzen**: Are available to come on radio tomorrow at 7:30? We can figure something to discuss.

**Jeff Bergosh**: Sure can.  Thanks!

**Rick Outzen**: Thx

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: Thanks Rick!

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-10-28T11_18_24-07_00

### CONVERSATION ON 11-07-2021

**Rick Outzen**: Would you do radio at 7:30 tomorrow? We can discuss Underhill redistricting plan?

**Jeff Bergosh**: I would love to Rick, but I have a standing all hands staff meeting on Mondays at 0730

**Jeff Bergosh**: Any other slots open Monday?

**Rick Outzen**: 7:20 or 8

**Jeff Bergosh**: 8:00 would be perfect

**Rick Outzen**: K. Thx 

**Jeff Bergosh**: Alright I’ll call in a couple minutes before.  If we have time I would also like to take a moment or two to discuss the cities proposal to move their homeless camp out into my district on Houston Avenue. I fielded angry phone calls and emails all weekend long by residents who feel very angry about this being proposed in their neighborhood

**Rick Outzen**: Ok we can talk later in the day 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-08-2021

**Jeff Bergosh**: Lines busy

**Rick Outzen**: Finishing with Grover

**Rick Outzen**: Call now 

### CONVERSATION ON 11-09-2021

**Jeff Bergosh**: Hey Rick-  can you send me the podcast from yesterday morning’s interview with you?  I’d like to link it on my blog.  Thanks!

**Rick Outzen**: Will do 

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-11-09T13_47_19-08_00

**Jeff Bergosh**: Thx Rick!

### CONVERSATION ON 11-19-2021

**Rick Outzen**: Would you like to come a radio Monday? 8?

**Jeff Bergosh**: Sure Rick— what’s the topic?

**Rick Outzen**: Perdido, Marlette editorial and taking over chair

**Jeff Bergosh**: Perfect

**Rick Outzen**: How moving up to 7:30? That gives us more time

**Jeff Bergosh**: The only problem is 730 as I have a standing all hands safety meeting every Monday at 7:30 and so I can’t get out of that can we split the difference and do 745?

**Rick Outzen**: Yes. Thx

**Jeff Bergosh**: Okay I’ll call u at 7:45 on Monday.  Thx Rick!

### CONVERSATION ON 11-22-2021

**Jeff Bergosh**: Otherwise I’ll just call in at 7:45 as we had previously arranged

**Rick Outzen**: Let’s stick to 7:45. Have Quint at 7:30. Thx

**Jeff Bergosh**: 👍

**Rick Outzen**: Go ahead and call

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Tha is for having me on Rick!  Please send me the podcast so I can link it to my blog

**Rick Outzen**: Will do

### CONVERSATION ON 11-23-2021

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-11-23T08_57_07-08_00

### CONVERSATION ON 12-07-2021

**Rick Outzen**: How about previewing COW tomorrow? 8?

**Jeff Bergosh**: Sure Rick but we are not gonna have a cow this week

**Jeff Bergosh**: There’s plenty of other things we can discuss though👌😎

**Rick Outzen**: Ok let’s talk tomorrow at 8. Thx

**Jeff Bergosh**: Right on!  I’ll call in at 8:00

**Rick Outzen**: Liked “Right on!  I’ll call in at 8:00”

**Jeff Bergosh**: We can talk about this:  Hot off the press

**Rick Outzen**: Liked an image

### CONVERSATION ON 12-08-2021

**Jeff Bergosh**: Ric thank you very much for having me on the show this morning. I also wanted to let you know that I miss spoke. I had stated it might take two weeks for the district maps to be updated, however I have noticed that staff has already updated the online commission district maps at my escambia.com. I just wanted to make sure I corrected that what is online right now reflects the newly created districts

**Rick Outzen**: Ok. Thank you 

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-12-08T13_58_51-08_00

**Rick Outzen**: Thx

**Jeff Bergosh**: Thanks Rick!

**Jeff Bergosh**: You got a quick minute to chat?  Important!

**Rick Outzen**: Sure

### CONVERSATION ON 12-22-2021

**Rick Outzen**: Would you be able to do radio interview tomorrow at 8?

**Jeff Bergosh**: Hey Rick— Sure I can.  What’s the topic?

**Rick Outzen**: Year in review. We will have time to cover a lot

**Rick Outzen**: Thx

**Jeff Bergosh**: Fantastic

### CONVERSATION ON 01-20-2022

**Rick Outzen**: Ratings are in. WCOA had its best book in 3 years.  Finished #3 adults 25+. 250% jump. Unprecedented 

**Jeff Bergosh**: Congrats!  Glad to hear it.

**Rick Outzen**: Thanks for your help

**Jeff Bergosh**: Absolutely Rick!  Keep up the great work!

### CONVERSATION ON 01-21-2022

**Rick Outzen**: Can you do radio Monday 7:20? Recap the last BCC meeting

**Jeff Bergosh**: Sure can Rick

**Rick Outzen**: Thx new call in 850-478-3116

**Jeff Bergosh**: Got it.  Congrats again on the ratings!  Are u smashing Tallman McKay?

**Rick Outzen**: Thx

**Rick Outzen**: Yes

**Jeff Bergosh**: 👍👍👍👍

### CONVERSATION ON 01-24-2022

**Jeff Bergosh**: I just forwarded you the complaint.  Thanks for having me on the show Rick

**Rick Outzen**: Liked “I just forwarded you the complaint.  Thanks for having me on the show Rick”

### CONVERSATION ON 01-26-2022

**Rick Outzen**: Want to promote your Perdido Town Hall on Monday at 7:20?

**Jeff Bergosh**: Sure— thanks!

### CONVERSATION ON 01-27-2022

**Jeff Bergosh**: Monday morning Rick?

**Rick Outzen**: Yes

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: Got em.  5:30PM

**Rick Outzen**: Can you call in early? 850-478-3116

**Jeff Bergosh**: Sure will

**Jeff Bergosh**: Thanks Rick!

**Rick Outzen**: https://www.podomatic.com/podcasts/rick9662/episodes/2022-01-31T11_26_28-08_00

