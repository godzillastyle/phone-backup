

## CONVERSATIONS WITH CAROLYN KETCHEL

### CONVERSATION ON 01-14-2020

**Jeff Bergosh**: Great speaking with you Carolyn

### CONVERSATION ON 07-23-2020

**Jeff Bergosh**: Thank you Carolyn!!

