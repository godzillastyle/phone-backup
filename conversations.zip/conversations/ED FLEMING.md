

## CONVERSATIONS WITH ED FLEMING

### CONVERSATION ON 10-18-2019

**Ed Fleming**: Not looking promising for in the morning.   Rain is forecast, however, to diminish to 30 percent by 9 am.   So it would not take much of an acceleration of the storm to cause it to move through earlier.  If you guys are game, I suggest we make that call at 7:30 tomorrow morning.  

### CONVERSATION ON 10-19-2019

**Ed Fleming**: Courts are wet and it is still drizzling.   Rain is forecast to stop by 8 am.  Might be able to play at 10 or 11 if you guys could start that late.  Thoughts?  

**Jeff Bergosh**: I'll probably have to pass on a later start time -- unfortunately

**Jeff Bergosh**: It's raining significantly here as well

**Ed Fleming**: Enjoy your families on this cold rainy day and we will try again next Saturday.  I am fighting a head cold so just as well. 

**Ed Fleming**: Courts still wet at 10 am do delaying start would not have worked anyway.  

**Jeff Bergosh**: Yep, good call.  Still raining here in Beulah

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Ed—we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for assisting with this effort by inviting folks and helping me garner additional financial supporters.  I cannot tell you how much your previous and current support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Ed Fleming**: Looking forward to it!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-24-2019

**Ed Fleming**: We are all confirmed for 8:30 am Saturday pending the weather.  

**Jeff Bergosh**: Ed--thanks again for coming out to the fundraiser!!  It was a great night and I am so appreciative of your support!  One question I have though, for Shayne's check, what address would you like me to use?  Should I use the PO Box 12388 address?  Thanks very much!

**Ed Fleming**: Use 5773 Highland Lake Drive Milton Fl.  Thanks

**Jeff Bergosh**: Will do thx Ed!

### CONVERSATION ON 10-25-2019

**Ed Fleming**: I could do this afternoon.  And I am good with just hitting with you, John, if we cannot get four people.  You just name the time. 

**Jeff Bergosh**: I'd love to but I'm packed solid through 4:30 today.....

**Ed Fleming**: I addition to you installing the new stuff I would like for you to get Alexa back up and running for us.  

**Ed Fleming**: Wrong person!  Sorry. 

**Ed Fleming**: Talk later?

**Ed Fleming**: ????

**Ed Fleming**: Just learned that John cannot play tomorrow.  Between that news and high probability of rain I am going to make the call to cancel for tomorrow.  Thanks. Ed

**Jeff Bergosh**: Sounds like a prudent decision-- based on the forecast... we'll get back on track next weekend Ed👍

**Jeff Bergosh**: Have a great weekend!

### CONVERSATION ON 10-31-2019

**Ed Fleming**: Weather is looking good for Saturday morning.  Perhaps a little chilly.  Two questions:  Is everyone "in," and is 9 am start time good?  

**Ed Fleming**: I am good with 8:30.  

**Jeff Bergosh**: Ed I want to play but I have our once yearly HOA Board of director's meeting at 9:00--so unfortunately I'm out for this week..... sorry

### CONVERSATION ON 11-01-2019

**Jeff Bergosh**: Good morning Ed.  I am doing my report for the month of October and I need to put an occupation down for Cassie Harris and I believe she’s Todd Harris‘s wife. Do you have any idea of what her occupation might be? Thanks very much Ed!

**Ed Fleming**: 
Homemaker 

**Jeff Bergosh**: Thx Ed!  

### CONVERSATION ON 11-04-2019

**Ed Fleming**:     Are you all three available for tennis at 8:30 am Saturday?   Could start at 9 am if group prefers.  I am good with either.  

**Jeff Bergosh**: 8:30 works for me!  See u then

**Ed Fleming**: John?   Need to hear from you.   

### CONVERSATION ON 11-06-2019

**Jeff Bergosh**: Yep!

### CONVERSATION ON 11-08-2019

**Ed Fleming**:    Weather for tomorrow at 8:30 will be 50 degrees with full sun.  Wind 8-9 mph from NE (we are pretty shielded). Should be great tennis weather!  Chilly for warmup and then perfect!   Someone needs to bring tennis balls.  I cannot afford them as Jeff voter against fee reimbursement for my great legal services last night.  😋

**Jeff Bergosh**: LOL Ed I'll bring some too!!

**Ed Fleming**: Jeff -- Could you also bring a bag of rice and bag of beans?   

**Jeff Bergosh**: LOL sure thing Ed!

**Ed Fleming**:    Todd asked that he bring him some as well.  

**Jeff Bergosh**: Will do!

### CONVERSATION ON 11-09-2019

**Ed Fleming**:    Great tennis.  Great air show.  Life is good.  

**Jeff Bergosh**: Yes it is!  It was great tennis and a great air show!

**Ed Fleming**: 92.3 fm is broadcasting FSU football.  

**Jeff Bergosh**: Oh—I thought they were broadcasting it

**Jeff Bergosh**: I wonder if 101.5 FM might be?

**Ed Fleming**: Great show!  And we saw a school of dolphins on our way back.  A good day already.  Perfect if Georgia wins tonight.

### CONVERSATION ON 11-13-2019

**Ed Fleming**: Is everyone good for Saturday morning at 8:30?

**Ed Fleming**: I have a request out Phil at the moment. Let's see how Phil responds.

### CONVERSATION ON 11-16-2019

**Ed Fleming**: You played exceptionally well today!

**Jeff Bergosh**: Thank you Ed!  I think you and Willie did as well!  It was a great day—thanks!

**Jeff Bergosh**: Hey Ed—did you happen to see my Racquet on the bench—I just realized It’s not in my truck?

**Ed Fleming**: I will go look for it right now. 

**Jeff Bergosh**: Thank u Ed!

**Ed Fleming**:  Found it!  Put it in my truck.  Can get it to you when you play next.  You need no practice.  😋.  Seriously, you can get it anytime you want.  I can get it delivered to your commission office if you like. 

**Jeff Bergosh**: Ed thank You so much I was tracing my steps and that was where I thought I had left it I really appreciate you picking it up for me thank you. I’ll grab it next time we play if that’s OK

**Ed Fleming**: That is fine.  Will keep it in my tennis bag.  

**Jeff Bergosh**: Thank you and congratulations on the Georgia victory I understand it was close at the end.......

**Ed Fleming**: Georgia shut them out until it started playing “prevent” defense.  More aptly called the permit defense.  Allows opponent to score in four or five plays of 15 yards each.  Should only be used when you are two or more scores ahead with less than a minute left on clock and no time outs.  Good game between two very good teams. 

### CONVERSATION ON 11-17-2019

**Ed Fleming**: Good for me. John?

### CONVERSATION ON 11-18-2019

**Ed Fleming**: This is about right.  15 days in jail for the drink thrower.  

Check out this article from Pensacola News Journal:

Woman who threw slushie on Matt Gaetz at Pensacola event sentenced to 15 days in prison

**Ed Fleming**: https://www.pnj.com/story/news/2019/11/18/woman-who-threw-slushie-matt-gaetz-sentenced-15-days-prison-amanda-kondratyev/4227935002/

### CONVERSATION ON 11-19-2019

**Jeff Bergosh**: Good!  This will hopefully make anyone think twice about doing this to an elected official of any party.

### CONVERSATION ON 12-03-2019

**Ed Fleming**: Is everyone good for Saturday at 8:30 AM?

**Ed Fleming**: Great!!  Fabulous four back on the courts!

### CONVERSATION ON 12-06-2019

**Ed Fleming**:    Depending in which weather service you look at, chances of rain tomorrow morning vary from 0 to 30 percent.  I will check out the courts at about 7 am and text you if there are any issues.  

### CONVERSATION ON 12-07-2019

**Ed Fleming**: Overcast but otherwise looking good. 

**Ed Fleming**: 8:30.  

**Ed Fleming**: John -- Bring leaf blower.  Thanks

### CONVERSATION ON 12-12-2019

**Ed Fleming**: You guys good for 8:30 Saturday?   

**Jeff Bergosh**: Ed I'm in Orlando I cant make Saturday.  Sorry for the short notice

**Ed Fleming**: No problem.  Enjoy!  

### CONVERSATION ON 12-17-2019

**Ed Fleming**: I will be out of town Saturday.  If you guys are all available, I will try to find a fourth to take my place.  Ed 

### CONVERSATION ON 12-18-2019

**Ed Fleming**: See you guys Saturday after Christmas?  Merry Christmas to you all!! Ed

### CONVERSATION ON 12-19-2019

**Ed Fleming**: The fab-4 are all confirmed for Saturday morning next week.   Wishing all of you a Merry and Blessed Christmas! 

### CONVERSATION ON 12-23-2019

**Ed Fleming**: Amen!

### CONVERSATION ON 12-25-2019

**Ed Fleming**: And unto us a child is born.  And his name shall be called Emmanuel — God is with us! Counselor.  The mighty King!  

### CONVERSATION ON 12-27-2019

**Ed Fleming**: Weather forecast looking good. Cloudy but not rain.  And warm!   See you guys at 8:30.  

### CONVERSATION ON 01-10-2020

**Ed Fleming**: I see that Underhill’s assistant, as expected, threw his hat in the ring.   Does winner have to get 50 percent plus one vote to win, or was that changed to a mere plurality?  

**Jeff Bergosh**: Plurality

**Jeff Bergosh**: The fact that he got in the race I mean

**Ed Fleming**: I was thinking the same thing.  Your opponents will split vote and your support will stay solid.  

**Jeff Bergosh**: I hope so. is all going well with you Ed?

**Ed Fleming**: It is.  Missing you at tennis.   Doesn’t look like anyone is going to play tomorrow morning.   Can you join us next week?  Be assured that your priority slot will stay ope. However many Saturday’s you have to miss.

**Jeff Bergosh**: I agree—it’s tough because Saturday’s are prime campaign days. But I appreciate you keeping me on the priority list! I’ll play Next Saturday though.  8:30?

**Ed Fleming**: Yes.  

**Jeff Bergosh**: Right on I’ll be there!

**Jeff Bergosh**: Have a great weekend Ed!

**Ed Fleming**: You as well.  

### CONVERSATION ON 01-13-2020

**Ed Fleming**: Weather is not looking good for Saturday.  Two questions: are you all good for Saturday?   And would 2 pm Sunday work as a rain check day?  Jeff has responded yes as to both.  Ed

### CONVERSATION ON 01-14-2020

**Jeff Bergosh**: Hey Ed I just made the request for the information I gave Stephan Hall a call. I  explained what I was looking for he was trying to push me off to Chris Jones‘s office so I redirected him and asked if he could go ahead and get whatever he’s got on that showing the revenue and any amount we’ve paid out any kind of unrealized revenue data he’s got so he’s going to send it to me and I’ll forward that to you when I get it

**Ed Fleming**: Thanks!

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-17-2020

**Ed Fleming**: Weather is looking "iffy" for tomorrow morning.   But last Saturday rain that was supposed to start at 9 am and held off until mid afternoon.  If it is clear and dry tomorrow morning I say let's try to get two sets in.

**Ed Fleming**: 8:30.

### CONVERSATION ON 01-18-2020

**Ed Fleming**: Not raining and dry.  

**Ed Fleming**: You played great!   Can you join us again next Saturday at 8:30?

### CONVERSATION ON 01-20-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Ed Fleming**: Wow!  So tennis Saturday?  😋

**Jeff Bergosh**: I’d love to but I’m walking doors.  I take nothing for granted Ed

**Ed Fleming**: I knew that before I asked.  Hence the smiley face. 

**Jeff Bergosh**: See you on August 19th LOL

**Ed Fleming**: Holding your spot open. 

**Jeff Bergosh**: Thanks Ed!

### CONVERSATION ON 03-02-2020

**Ed Fleming**:   How is campaign going?  

  Did staff ever respond to your request to find out total tax revenue lost by county since 2011 forward as a result of the adverse (to county) court cases?  

    Injured my left shoulder so I have missed last two weeks of tennis.  Holding your spot open.  Ed

**Jeff Bergosh**: Hey Ed!!  Hope all is well and I’m sorry to hear about your shoulder.  Hope it gets better soon.  Looking forward to after August 19th so I can get back in the tennis rotation.  All is going well on the campaign thus far, but we have a few months to go yet.  I remain cautiously optimistic that I’ll be re-elected.  In this instance, I believe it is to my benefit to have 3 opponents in the race.  I do believe Stephan sent something a while back—but it wasn’t quite what you had requested.  I’ll find that and forward it to you.  He tried to pass the request over to Chris Jones’ office and so I didn’t press.  Talk to you soon Ed!

**Ed Fleming**: Thanks. At Dr Ostrander’s office now do should know something in about three hours. :(

**Jeff Bergosh**: Good luck Ed!

**Ed Fleming**: Not good news.  Surgery needed to reattach a complete through tear. 

**Jeff Bergosh**: Oh my God—sorry to hear that Ed. 😩

### CONVERSATION ON 04-10-2020

**Ed Fleming**: Can you play tennis at 8:30 tomorrow morning?  Typically done by 10.

**Jeff Bergosh**: Yes that sounds great!  Same location in Milton right?

**Ed Fleming**: YYYEEESSS!  Same place as usual!  Ed

**Ed Fleming**: And when your prayer-Bible study starts back, count me in. 

**Jeff Bergosh**: Will do Ed!  See you at 8:30–looking forward to it!

**Ed Fleming**: Out of abundance of precaution, I am spraying tennis balls between games with pool chlorine disinfectant. 

**Ed Fleming**:    Looking forward to seeing everyone at 8:30 tomorrow morning.  UV rays and fresh air.  My get skin cancer but not Coronavirus.  

### CONVERSATION ON 04-11-2020

**Ed Fleming**: Jeff  — PLEASE take a look at this documentary from Epoch Times when you the opportunity:  https://m.youtube.com/watch?v=XMJ0EmMfb3U

It makes a compelling case that COVID-19
was gene spliced to make it infectious to humans.  Powerful
Evidence.  Not a genetics expert, but I am an expert in evaluating evidence.  Ed

### CONVERSATION ON 04-12-2020

**Ed Fleming**: Congratulations!   You win that battle.  But I still did not see a report as to how many Coronavirus patients were hospitalized.   Only that our hospitals are almost half empty meaning there is no need to continue to refuse surgery for injuries such as my torn rotator cuff repair.  


Check out this article from Pensacola News Journal:

Escambia County reverses position, starts releasing daily coronavirus report

**Ed Fleming**: https://www.pnj.com/story/news/2020/04/11/escambia-county-reverses-position-starts-releasing-daily-coronavirus-report/2977448001/

**Jeff Bergosh**: Thanks Ed!  They made a mistake and I sure am glad they walked it back!  I’m going to read that article you referenced today- thanks for sharing.  And Happy Easter to you my friend!

**Ed Fleming**: You as well.  Great having you back on the courts!  

### CONVERSATION ON 04-15-2020

**Ed Fleming**: Everyone good for tennis Saturday at 8:30 am?  Yes.  Assuming, of course, we are all still alive.  According to the media, half of us will be dead!  You will be excised and forgiven if you are dead, or test positive for the virus.  

**Jeff Bergosh**: LOL I'll be there Ed--if I'm alive😎👍

### CONVERSATION ON 04-17-2020

**Ed Fleming**: Weather is not looking good for tomorrow morning.  What are your thoughts.  Call it now, or wait till tomorrow morning to see if forecast changes?  If forecast is correct, rain will start at about 3 am and continue all morning. 

**Ed Fleming**: Ron S.  What do you saw I make call at 7 am and send everyone by text?

**Ed Fleming**: You did not give us a name of the movie. 

**Ed Fleming**: Thanks. 

### CONVERSATION ON 04-18-2020

**Ed Fleming**: See you at  8;30,  

**Ed Fleming**: Enjoyed being your tennis partner!  After we got the unforced errors out of our system in set one, we played well. Fun!  

**Jeff Bergosh**: It was great Ed!  We held our own!!

**Jeff Bergosh**: ......I’m already looking forward to next week!

**Ed Fleming**: Me too!  We will get em all three sets next week.  Were playing as a team those last two sets.  You kept crushing the ball from the baseline until you set me up at the net.  Fun!  

**Ed Fleming**: Let's play.  No rain here and hours forecast for Milton ranges from 5-15 percent chance  between 8 and 11.  Higher for pensacola but there is different weather pattern for north of  I-10. 

**Ed Fleming**: Me too.  Only thing that has a sense of "normal" in my life.   Great tennis, guys!  Took a set for me and Jeff to warm up, bit very competitive after that. 

**Ed Fleming**: The Rons were painting those alleys today with some great shots. 

### CONVERSATION ON 04-22-2020

**Ed Fleming**: Everyone confirmed for tennis Saturday at 8:30?

### CONVERSATION ON 04-25-2020

**Ed Fleming**: Great tennis today, partner. We played as a team. Fun!

**Jeff Bergosh**: Awesome day of tennis and fellowship!!!

**Ed Fleming**: Beautiful day!  Looking forward to seeing you guys for tennis at 8:30.  

**Jeff Bergosh**: On way guys--apologies I'm running a couple of minutes late

**Ed Fleming**: Jeff -- Did you remember to bring your Racquet?

### CONVERSATION ON 04-26-2020

**Ed Fleming**: The press conference stating that UV rays kill the Coronavirus was a “duh” announcement.   Hospitals use UV light to kill virus and bacteria.  They have done that for decades.  We know that during the Spanish flu pandemic of 1918 patients in tents due to overwhelmed hospitals recovered at higher rates than those inside the hospitals.  Why?  Because they were exposed to UV rays (they penetrate tents) and were breathing UV bathed and thus purified air.  Yet our government officials have closed down parks, tennis courts, and beaches.  A father was arrested for playing catch with his daughter on a ball field.  The ability of UV to kill viruses has been known for at least  a century!

### CONVERSATION ON 04-28-2020

**Ed Fleming**: Hey report was released yesterday saying what I have been saying all along—property kills. . As a result of the shutting down of our economy, and the economy of other food exporting countries, it is estimated that 300 thousand people per day will die of starvation in Africa.

**Ed Fleming**: Per day! 

**Jeff Bergosh**: Wow

### CONVERSATION ON 05-01-2020

**Ed Fleming**: Yes. 8:30 am. 

### CONVERSATION ON 05-02-2020

**Ed Fleming**:    Enjoyed playing as your tennis partner.  We played well as a team.  That is four sets in a row now against two good players.  Ed

**Jeff Bergosh**: Me too Ed!! Great day and excellent playing

**Ed Fleming**: The beach is booming! Thank you Jeff

**Jeff Bergosh**: Right on!

### CONVERSATION ON 05-08-2020

**Ed Fleming**: Confirming for 8:30 am tomorrow morning.  Thanks. 

**Jeff Bergosh**: I'm in!

**Ed Fleming**: Love you guys!  Only normal thing in my life right now.  If I could deem you guys normal.  😋

### CONVERSATION ON 05-09-2020

**Ed Fleming**:    Is this one if yours?
   Ed we found a Wilson racquet at th courts. Black and red.  White letters. Is this one of yours. I know it is not Rons. 

**Jeff Bergosh**: Does it have a martini string calming device 

**Jeff Bergosh**: Nope, that's not mine

### CONVERSATION ON 05-11-2020

**Ed Fleming**:    Are you two in for Saturday?  John Davis is back off injured reserve, so we will be back to the "regulars."  Will miss New York Ron, but he knew he was a fill in for John.  Need to dance with the "girl" we came with, even though John would be an ugly girl.  Please confirm before I tell New York Ron he is not needed Saturday.  

**Ed Fleming**: Jeff and I had the Rons' number anyway.    I will miss MY partner, I guess, if we go back to the original pairings. And I had just learned to play as a team with Jeff.  Dang! 

**Jeff Bergosh**: I'll be there!  Looking forward to it!

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Ed—-I wanted to let you know that I just got my latest poll results back from Gravis.  I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary by 30 points!  Thought you might like to know that 

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Ed—see you Saturday

**Ed Fleming**: That is great news!   Looking forward to seeing you Saturday.

### CONVERSATION ON 05-15-2020

**Ed Fleming**: Any word re short term rentals?

**Jeff Bergosh**: Yes.  Do you have a minute to talk?

**Ed Fleming**: Yes.  Just tried to call. 

### CONVERSATION ON 05-18-2020

**Ed Fleming**: I had what they call retina migraine.  Not serious.  Usually non recurring — at least not frequently.  Everything else checked out good.  Can be sparked by bright light. I went from dark showroom out into bright sun. That is when it occurred. Lasted for less than an hour.  Eyes were thoroughly checked on Saturday morning.

**Jeff Bergosh**: Glad to hear that Ed!  I want to reiterate my standing invitation for you to come to our men’s bible study at 6:00AM this Friday morning at First Assembly at Bayou Blvd and 12th.  Hope you can make it Ed!

**Ed Fleming**: Friday will be a crazy day this week as we are closing on Shayne’s new house and coordinating the move for Saturday.  But next week works.  Keep bugging me till I am there.  You have my permission.

**Jeff Bergosh**: Will do LOL!  Have a great week Ed—missed you at tennis 

**Ed Fleming**: I will miss again Saturday as that is Shayne’s move day. Are you in for this Saturday?

**Jeff Bergosh**: Yes

### CONVERSATION ON 05-20-2020

**Ed Fleming**: We have the fantastic four back in place for tennis Saturday, weather permitting. Looking forward to seeing you guys there! 

**Ed Fleming**: Change in plans. I will be able to play Saturday. See you there!

**Jeff Bergosh**: Right on Ed!  See you then!

### CONVERSATION ON 05-29-2020

**Ed Fleming**:   Looking forward to seeing you guys for tennis on Saturday at 8:30. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-30-2020

**Ed Fleming**: It is a beautiful day in the neighborhood! 

### CONVERSATION ON 06-18-2020

**Ed Fleming**: Is the Bible study back on in person?  What is that awful time again?

**Jeff Bergosh**: Yes it is Ed!!  We meet at 6:00 sharp at First Assembly at Bayou and 12th

**Jeff Bergosh**: It would be great if you make it out tomorrow!!

**Ed Fleming**: Go in the front door?  Do I have to wear a mask? 

**Jeff Bergosh**: No mask needed— they have a fellowship hall right next door, that’s where we meet

### CONVERSATION ON 06-19-2020

**Ed Fleming**: On my way.

**Ed Fleming**: 
Pulling in now

**Ed Fleming**:    Great group.  Uplifting to be a group of right-thinking men. 

### CONVERSATION ON 06-28-2020

**Ed Fleming**: Exception in the King’s decree.  I have a medical condition. Being forced by the King to wear a useful BS mast increases my blood pressure and chances of a cardiac arrest, or psychosis (going “postal.”). I am not wearing a damn mask anywhere except a hospital where critically ill people are forced to be. 

**Jeff Bergosh**: Yes—and I’m getting squeezed to add it to the agenda for the county

**Jeff Bergosh**: It’s not on the agenda

**Ed Fleming**: Please do not!

**Jeff Bergosh**: Not happening Ed

### CONVERSATION ON 07-04-2020

**Ed Fleming**: "Freedom is never more than one generation away from extinction. We didn't pass it to our children in the bloodstream. It must be fought for, protected, and handed on for them to do the same, or one day we will spend our sunset years telling our children and our children's children what it was once like in the United States where men were free." ~ President Ronald Reagan
God bless America!  Happy Fourth of July!!🇺🇸

### CONVERSATION ON 07-14-2020

**Ed Fleming**:    Please be in prayer for me for an issue with my right leg.  Initial diagnosis is spinal stenosis that is causing an impairment of the spinal cord nerves through my L-4 and L-5 vertebrae.  Old injuries catching up to the old horse.  I have had a broken vertebrae and torn disk in that region from high school football and being rear ended in my car.  MRI being ordered.  Back surgery might be my only option. I cannot walk without a limp at the moment.  If diagnosis is correct, not subject for rehab.  Depressing!  

**Jeff Bergosh**: Ed— I am sending prayers your way my friend—so sorry to hear but praying for a full and complete recovery!!🙏🙏🙏

**Ed Fleming**: I have had some encouragement from Dr LeMay, who shares you philosophy of health, regarding alternatives to surgery, including a steroid epidural that can shrink inflation around the spinal column relieving pressure on those nerves.  He thinks that might be the issue given the fact it manifested itself overnight. 

**Ed Fleming**: It all depends on what MRI shows. It pressure caused by shifting of discs, spacers work. If by inflammation, steriod shots (or time and rest) works. Calcification within the canal is my fear.  With you re back surgery being LAST alternative 

### CONVERSATION ON 07-22-2020

**Ed Fleming**: When can you get back to tennis?  Are you good with shifting to Roger Scott?  My doctor says no more tennis for me on hard courts. 

**Jeff Bergosh**: Hey Ed!  Glad to hear you’ll be back to tennis soon!  I’ll be good to go after the 18th of August (my primary election date)—and of course —-I’m great with Roger Scott!  Looking forward to it!

**Ed Fleming**: Thanks. It will take that long to rehab my back so that is perfect time to restart. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-31-2020

**Ed Fleming**: https://www.rasmussenreports.com/public_content/politics/political_updates/prez_track_jul31

**Ed Fleming**:   This is up from 44 percent about a week ago. Trump’s new campaign manager is doing a better job of managing the message. 

### CONVERSATION ON 08-20-2020

**Ed Fleming**: Congratulations!

**Jeff Bergosh**: Thanks Ed!

### CONVERSATION ON 08-25-2020

**Ed Fleming**: You guys are welcome to play on our courts.  Let me know what time you will be there and I will show up to say hello.  

### CONVERSATION ON 08-29-2020

**Ed Fleming**: My driveway and street is dry which has always translated to dry courts. No rain here 

### CONVERSATION ON 09-04-2020

**Ed Fleming**: https://www.city-journal.org/seattle-homelessness

**Ed Fleming**: 
    I understand that the city snd county will meet soon for a workshop on dealing with the “homeless.”   The ACLU has been invited, and I suspect will dominate that discussion.  Our business community that provides jobs and pay the bulk of city taxes has not been invited.  

    Seattle is a “model” for what results from “homeless” friendly city policies.  This is the end result of the “homeless” friendly policies that the ACLU will promote at the upcoming workshop.  What participation will representatives of the men and women who
create  jobs and pay the taxes in this City be given?  How about the
People who would like to shop
and eat downtown without
being accosted by those panhandling for money to feed their drug habits?  This conference should include
lawyers who can refute the ACLU BS re “rights” of the “homeless.”  Property tights are one of the most important rights, and those
rights are being destroyed. 
I put “homeless” in quotes as most of them get government checks and could afford housing, but elect to spend their government checks on drugs and alcohol.  By facilitating that panhandling, we enable addicts, invite more, and kill our downtown — as happened in Seattle and other “homeless” friendly communities around this nation.  The executive director of Waterfront Rescue Mission, which has helped free thousands from the bondage of drugs and
Alcohol, should be invited. 
He will telling you that supporting panhandling kills these people slowly through enabling their drug addictions. 

### CONVERSATION ON 09-18-2020

**Ed Fleming**: That phone number does not work.  Would need his cell phone. 

**Jeff Bergosh**: Okay I’ll get it

**Ed Fleming**: Jeff — I just spoke with Palou and all is good.  He accepted my alternate means of assuring that only legit contractors have access to beach.  THANK YOU!  

**Jeff Bergosh**: Any time Ed— glad you got it worked out

**Ed Fleming**: I let David Peaden and my
Client, Phoenix Coatings, know that were instrumental in this.  Ed 

**Jeff Bergosh**: Thx Ed

### CONVERSATION ON 10-11-2020

**Ed Fleming**: Hit two baskets of tennis balls today practicing serves, drop ball forehands and backhands.  Even through the ball in front of me and did the side steps into the ball.  Did not trip or loose my balance!  So rehab is coming right along.  I. Fact, with the emphasis on upper body while leg was healing, I seem to have added about 10 mph to my serves and ground strokes. I was encouraged! 

Plan to be back on the court practicing within a couple of weeks.  Hitting the rehab hard. Probably not playing before end of the year, but keeping form through lessons.

**Jeff Bergosh**: WY to go Ed!  Can’t wait to see you out on the courts again!!

### CONVERSATION ON 01-17-2021

**Ed Fleming**: Excited to get back on the courts!  Plan to take a couple of lessons during the week to keep from embarrassing myself.  Or at least reducing the embarrassment.  Ed

### CONVERSATION ON 01-21-2021

**Ed Fleming**:   FYI.  

**Jeff Bergosh**: I remember this meeting Ed.  But I did stipulate that Doug would have to be successful in his case (which he apparently has been) and that he was to present proof that he had paid his counsel timely and was up to date on legal bill payment.  But he hasn’t paid since December of 2019 I’ve been told.  He hasn’t abided by the stipulations.   And he doesn’t have three votes even if I said yes.  You saw what happened today.

**Jeff Bergosh**: But he absolutely needs to pay you and he should do it promptly especially given the fact of what happened today. Then he can come back to us for reimbursement and fight that battle not you

**Ed Fleming**: Today’s action leads me no choice but to sue the county.   I took an action that benefited all five commissioners with great precedent, but have to file suit to enforce your policy.  All at expense, ultimately, of our taxpayers.  I will shut up and not bug you any further as I want to preserve our friendship.  But this “just ain’t right.”

**Jeff Bergosh**: I hate the way this played out Ed.  It’s horrible and I hate it.

Doug owns this though, 100%.
He should step up and pay his bill— he should not be throwing you into the middle of this

**Ed Fleming**: I stepped into the middle when I determined that the principle of law involved, first amendment protection for elected officials, without regarding to the speaker or the message, was worth fighting for. 

### CONVERSATION ON 01-23-2021

**Ed Fleming**: That was fun today! We have the same 3+ 'Gary lined up for 830 next Saturday. Please confirm. Thanks

**Jeff Bergosh**: It was!! I’m in!

### CONVERSATION ON 01-29-2021

**Ed Fleming**: Weather is looking good for tomorrow morning.  Little chilly (upper 40s) to start but 50 by 9 am.  Overcast but less than 3 percent chance of rain.  See you guys at 8:30 am!  Ed 

**Ed Fleming**: I will try to recruit us a fourth. But let's play 3 if need be. 

**Ed Fleming**: No luck in getting a fourth this far and it is getting late.  Jeff - Gary -- Are you good with playing Austrian?  Good exercise and practice. Ed the 

### CONVERSATION ON 01-30-2021

**Ed Fleming**: Jeff — It is down to you and me.  

Want to hit and practice serves?   

**Jeff Bergosh**: Sure let’s do that.  8:30?

**Ed Fleming**: Yes!  See you at 8:30!

**Ed Fleming**: I will bring a basket of balls. 

**Jeff Bergosh**: 👍

**Ed Fleming**:    Gary -- I was unable to get a fourth.  Enjoy your fishing.  Are you good for next week? 

### CONVERSATION ON 02-02-2021

**Ed Fleming**: Are you both good for tennis at 8:30 Saturday?  

**Jeff Bergosh**: Absolutely!

**Ed Fleming**:    Gary -- Are you good for tennis Saturday?  Jeff and Ron and I are all ready to go. Ed

### CONVERSATION ON 02-06-2021

**Ed Fleming**: No tennis.  Raining   

**Jeff Bergosh**: Bummer

### CONVERSATION ON 02-08-2021

**Ed Fleming**: I am!  Still looking forward to playing DOUBLES!

**Ed Fleming**: We are all set.  Now we just need the weather to cooperate. 

### CONVERSATION ON 02-11-2021

**Ed Fleming**: That works for me.  Would that allow us to beat the rain?

**Ed Fleming**: Me too.  I will do that. 

### CONVERSATION ON 02-13-2021

**Ed Fleming**: Not an easy call as it is not raining now.  But courts are wet as it rained much of the night.  Unlikely to be dry at 8:30 even if no further rain.  And there is a 60 percent chance of more rain.  So  I think we need to call it for this morning. ☹️

**Jeff Bergosh**: Thanks Ed.  Next week hopefully

**Ed Fleming**: I miss tennis!  

### CONVERSATION ON 02-16-2021

**Ed Fleming**: I am. 

**Ed Fleming**: Gary?  

### CONVERSATION ON 02-24-2021

**Ed Fleming**: Good for me!! (Ed)

**Jeff Bergosh**: Jeff is in!

### CONVERSATION ON 02-25-2021

**Ed Fleming**:   They we are set!  See everyone there. 

### CONVERSATION ON 02-27-2021

**Ed Fleming**: Foggy but no rain.  See you guys at 8:30 absent rain. I will text you if anything changes. 

### CONVERSATION ON 03-03-2021

**Ed Fleming**: YYYEESSS!  

### CONVERSATION ON 03-06-2021

**Jeff Bergosh**: Ed, I’m On the way just running a couple minutes behind

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-19-2021

**Ed Fleming**: Weather looking good for tomorrow.  Cloudy and 50 but no rain forecasted. See everyone there unless weather surprises us

### CONVERSATION ON 03-26-2021

**Ed Fleming**: Remember that we have an 8 am start in the morning. Weather should be good. 

### CONVERSATION ON 03-30-2021

**Jeff Bergosh**: I am!

**Ed Fleming**: I am!  Ed 

### CONVERSATION ON 04-01-2021

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-02-2021

**Ed Fleming**: Confirming everyone for 8:30 am.  Weather should be perfect. 

### CONVERSATION ON 04-07-2021

**Ed Fleming**: Will do. 

### CONVERSATION ON 04-09-2021

**Ed Fleming**: I am going to have to bail for tomorrow morning even if weather allowed -- which is unlikely.  Have to meet with a client at 8 am. 

**Ed Fleming**: I am also out next weekend. 

**Jeff Bergosh**: Unfortunately I'm out next weekend as well -- Jeff

**Ed Fleming**: Three out of four.  At least we are coordinating our outs.  

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-10-2021

**Ed Fleming**:    The courts are definitely wet this morning.  If they are still there!  Quite the storm going on out there.  Hope you are all safe and sound. 

### CONVERSATION ON 04-20-2021

**Ed Fleming**: I am in 

**Ed Fleming**: Awaiting Gary. 

**Ed Fleming**: Now we need the weather to cooperate.   

**Ed Fleming**: Dang!  Long range forecast looks horrible! 

### CONVERSATION ON 04-23-2021

**Ed Fleming**: Will do.  

### CONVERSATION ON 04-24-2021

**Ed Fleming**:    Although dry now, this storm has sped up and future radar shows rain starting here at 8:50 am.  I am game as I am only five minutes from the courts.  I just hate to see you guys drive longer distances.  Your call.  Ron --  still do not have Gary in my outlook contacts (please send his contact card) so you will need to check with him. 

**Jeff Bergosh**: I agree Ed-- probably need to push it till next week sadly

**Ed Fleming**: Hate that!  But you are right. No reason for to drive here just to get wet and turn back around. 

**Jeff Bergosh**: So next week then?

**Ed Fleming**: You guys will have to get a replacement for me. For next two Saturdays as I will be riding motorcycles in the Andes mountains in Ecuador.  Willie called me yesterday.  Want me to check with him?  

**Ed Fleming**: Courts are dry right now.  Radar projections show rain not getting here until after 10:30.  We might get in two sets of tennis before the rain gets here.  I am game to try if you guys are.   I will update you at 7:30. 

**Ed Fleming**: Pouring rain here.  We made the right call. 

**Jeff Bergosh**: 👍

**Ed Fleming**: Willie Small is willing and ready to fill in for me the next two Saturdays.  I will share his contact card with Ron to include on the strings. 

### CONVERSATION ON 05-26-2021

**Ed Fleming**: I can play.  May be somewhat impaired as to my new found mobility, but plan to wrap ankle and play. 

**Ed Fleming**: Good.  Willie and are both hobbled.  Should be offsetting disabilities.  😋

### CONVERSATION ON 05-27-2021

**Ed Fleming**: What is going on here?

Check out this article from Pensacola News Journal:

Escambia County employee using anonymous public record request to unmask anonymous citizen

**Ed Fleming**: https://www.pnj.com/story/news/2021/05/26/escambia-county-employee-using-anonymous-public-records-unmask-citizen/7458654002/

**Jeff Bergosh**: Crazy shenanigans 

### CONVERSATION ON 06-08-2021

**Ed Fleming**: 😋

### CONVERSATION ON 06-15-2021

**Ed Fleming**: Let's skip this Saturday.  I need the time to clean out my garage and move a ping pong table. 

### CONVERSATION ON 06-28-2021

**Ed Fleming**: I am in!  Come back from Colorado tomorrow. 

### CONVERSATION ON 07-03-2021

**Ed Fleming**: Ron and I are available for tennis Monday morning at 8 AM. Could you join us?

**Jeff Bergosh**: At the Moors?

**Ed Fleming**: Yes 

**Ed Fleming**: Flexible on time. 

**Jeff Bergosh**: Yes I’ll definitely play.

**Jeff Bergosh**: Or do you have a 4th already?

**Ed Fleming**: I do not have a fourth, and we would love to have Sally join us!  

**Jeff Bergosh**: Right on!  Sally is in!

**Ed Fleming**: 8 am work, or want to do later?

**Jeff Bergosh**: 8:00 works great

**Ed Fleming**: Liked “8:00 works great”

**Ed Fleming**: Courts are dry and sun shining.  Please forward to Gary.  Will let you know if anything changes.  Otherwise we are ON! 

**Ed Fleming**:    Put ice on it.  Redness in white of the eye has gone away and vision is no longer blurred.  I think it is going to be fine. Spoke with Dr John Davis, and he said eye is pretty hard to injure seriously with a tennis ball due to its size and protection of eye.  Said he would look at it tomorrow (he was in Destin) if there is persistent pain or vision issues.    So it appears the eye will be fine. Please forward to Gary. 

### CONVERSATION ON 07-05-2021

**Ed Fleming**: Fun tennis today! The Bergosh team was awesome! Remember to send me the link to the information on your condo. I am very interested. Talk to you later

**Jeff Bergosh**: Hey Ed!  Thanks very much for inviting us!  Sally and I had a blast.  We actually went downtown afterwords and rode bikes around the city until we got rained out LOL.  I’ll text you the VRBO listing for the beach condo here below.  Just let me know what you think.  I’ve got it blocked off from rental for short term stays and will be looking to rent it for the entire off season from October 1st 2021 through April 1st 2022 for $2250 month all utilities included.

**Jeff Bergosh**: 


**Ed Fleming**: So $2,250 per month is all inclusive?

**Jeff Bergosh**: Yes- that includes everything

**Ed Fleming**: Photos do not show the second bedroom.  Is unit on the north or south side? 

**Jeff Bergosh**: South side

**Jeff Bergosh**: Yes, I need to add the master bedroom picture— that one pictures is the second bedroom

**Ed Fleming**: Great.  My son Stephen typicall spends December with me as he is furloughed for a month each year from his job. 

**Jeff Bergosh**: Master bedroom

**Jeff Bergosh**: It has a balcony and sliding door/screen

**Ed Fleming**: Was there supposed to be a photo attached?

**Jeff Bergosh**: Yes

**Ed Fleming**: Nice!  Perhaps I can get by to see it between renters? 

**Jeff Bergosh**: Absolutely.  

**Jeff Bergosh**: Or next Saturday, the 17th you could  come by after 3:00 as I don’t have a check in until Sunday the 18th at 3:00

**Ed Fleming**: Next Saturday seems to have the best window.

**Jeff Bergosh**: 👍

**Ed Fleming**: Courts dry and not raining.  Let's play some tennis!  

**Jeff Bergosh**: 👍

**Ed Fleming**: We have a black cloud and some thunder -- hold off on heading over for about 15 minutes to let me see where this thunderhead is going. 

**Ed Fleming**: Thunderhead I was concerned with moved northeast of courts.  Cloudy but no rain.  I say let's try to get some tennis in!

**Jeff Bergosh**: Okay we will head that way right now.  See u all in 20

### CONVERSATION ON 07-06-2021

**Jeff Bergosh**: Jeff's in!

**Ed Fleming**: I am in. 

**Ed Fleming**: (From Ed)

### CONVERSATION ON 07-07-2021

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-10-2021

**Ed Fleming**: So far so fun. Rained early this morning but streets are dry which indicates that courts are dry. Will need you informed as morning goes on 

**Ed Fleming**: Still looking good. It's a go!

### CONVERSATION ON 07-13-2021

**Ed Fleming**: Also, John Davis is an alternative. 

### CONVERSATION ON 07-24-2021

**Ed Fleming**: Are you good for next Saturday for tennis?

**Jeff Bergosh**: Yes

**Ed Fleming**:   It is a beautiful day in the neighborhood!  Look forward to seeing you guys at 8 am for some tennis!  

**Ed Fleming**:   I had to drink pickle juice to stop cramping!  Great tennis but that heat was brutal!  

**Ed Fleming**: It works!  Almost instantly. 

### CONVERSATION ON 07-31-2021

**Ed Fleming**: Just had to drink pickle juice. 
Even my fingers are cramping! 

### CONVERSATION ON 08-01-2021

**Ed Fleming**: You guys good for Saturday?  Willie has committed so we will have four of you two are good. 

**Ed Fleming**: We have the fearsome foursome lined up for Saturday!  See you guys at 8 am absent rain.  I know the Fall does not get here until the Fair comes to town.  But perhaps we will get something less than the 115 degree heat index from last Saturday.  

**Ed Fleming**: LOL!  "What does not kill me makes me stronger."  Not sure who said that, or when.  Was it just before a tennis match with 115 degree heat index?  Did he survive?  

**Ed Fleming**: It is "only" supposed to be a high of 89 next Saturday versus upper 90s.  Virtually cold wave.  

**Ed Fleming**: I was wrong.  High was "only" 93 yesterday.  

### CONVERSATION ON 08-06-2021

**Ed Fleming**: Confirming for & am tomorrow morning!  Start hydrating now, and as soon as you get up tomorrow. 

**Ed Fleming**: My apologies, Willie.  I thought I had already confirmed with you. 

### CONVERSATION ON 08-08-2021

**Ed Fleming**: I just realized that I will be out of town this Saturday.  Potential replacement would be Tim Atkins.  He lives at beach. 

**Ed Fleming**: Ron will coordinate. 

### CONVERSATION ON 08-13-2021

**Ed Fleming**: Is your condo still available for snow bird rental?  

**Jeff Bergosh**: It is although I am showing it to some folks on Sunday.

**Jeff Bergosh**: Just let me know.  

**Ed Fleming**: Zillow link?

**Jeff Bergosh**: Www.Zillow.com/homedetails/1200-Fort-Pickens-Rd-APT-2C-Pensacola-Beach-FL-32561/80757965_zpid/?view=public

**Jeff Bergosh**: If you decide you want it I’ll adjust the price downward as we discussed before

**Ed Fleming**: No need to discount. For a wealthy friend who is selling her house. 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: I’m out there staying this weekend if she’d like to come by Sunday afternoon and take a look just let me know thanks Ed!

**Ed Fleming**: Just called her and she decided on a downtown townhouse next to Aragon. 

**Jeff Bergosh**: 👍

**Ed Fleming**: I am assuming you prefer to rent all six months and not one month at a time.  I might rent a place just for October. 

**Jeff Bergosh**: No I need it to be a six month block because otherwise I have to pay tax on the less than six months rent because it would be a transitory short termRental at that point but thanks anyways Ed!

**Ed Fleming**: Gotcha!  

### CONVERSATION ON 08-20-2021

**Ed Fleming**: Beach has its own weather system.  To predict weather. Go outside and look up.  

### CONVERSATION ON 08-21-2021

**Ed Fleming**: Liked “OK guys it's dry on the court and a little overcast but I think we're a go see y'all at eight!”

### CONVERSATION ON 08-24-2021

**Jeff Bergosh**: 👍👍

**Ed Fleming**: Liked “We are a go for Saturday Tennis. It will be Ed, Jeff, Willie, and Gary. 8:00 AM at Jeff's condo. Address is 1200 Fort Pickens Road Pensacola Beach, Fl 32561 (Tristan Towers). The gate code is:
#.  0.  9.  1.  6.  

Y'all have fun.
”

**Ed Fleming**: Good!  

**Ed Fleming**: Not that Willie has to miss but that you will be able to file in. 

### CONVERSATION ON 08-27-2021

**Jeff Bergosh**: Will do guys

**Ed Fleming**: 👍

### CONVERSATION ON 08-28-2021

**Ed Fleming**: Is everything still a go?

**Jeff Bergosh**: No rain but a little standing water on the courts-- I think we will be good

**Jeff Bergosh**: 👍

**Ed Fleming**: Me too. 

### CONVERSATION ON 08-31-2021

**Ed Fleming**: Did you ever get stats on COVID deaths in Escambia county?  

**Jeff Bergosh**: Nope— they’re stonewalling us 

**Ed Fleming**: I suspect the death rate is very low and that is why it is not being released. 

**Jeff Bergosh**: I’ve asked the health department and they just won’t release it

**Ed Fleming**: That is strange.  They released it during the initial surge. 

### CONVERSATION ON 09-13-2021

**Ed Fleming**: Is there a shower at your pool house where I can shower after tennis Saturday?

**Jeff Bergosh**: Yes there is—one outside and one in the bathroom I believe

**Ed Fleming**: Thanks.  I have to go straight from tennis to the gun range.  Did not want gross out the instructor with BO.  😋

**Jeff Bergosh**: 👍LOL

### CONVERSATION ON 09-14-2021

**Ed Fleming**: Long term forecast not looking good for Saturday.  But that can change 

### CONVERSATION ON 09-18-2021

**Ed Fleming**: Go or no go?

**Ed Fleming**: Please text me gate code

**Jeff Bergosh**: #7777

**Ed Fleming**: On ft Pickens road. 

**Jeff Bergosh**: Courts are dry and it's not raining so I think we are good to go!

**Ed Fleming**: Gotcha.   I might be up to 10 minutes late.

**Jeff Bergosh**: 👍

**Ed Fleming**: Raining here.  But on my way

### CONVERSATION ON 09-20-2021

**Ed Fleming**: Thank you for pushing for this. 

Check out this article from Pensacola News Journal:

Official COVID-19 death toll in Escambia County is 818, Santa Rosa County is 418

**Ed Fleming**: https://www.pnj.com/story/news/local/2021/09/20/covid-19-death-toll-escambia-santa-rosa-counties/8378528002/

**Jeff Bergosh**: Thx Ed

**Ed Fleming**: Jeff — You good with playing at Moors this Saturday?  This is from Gary:

GM Ron,

I hope you are well and safe. Yes, I can play tennis 8am in Pace, Friday. I can play Saturday, 8am, at Moors, UWF, or  PSC, Though a beautiful and extremely nice place to play at Tristan Towers, it is  a 1 hour drive for me across a bridge with ia lot of early morning  sleepy drivers. The other locations are a 15-25 minute drive for me.

Gary

**Jeff Bergosh**: And I’ll probably just have to go ahead and skip this week this is my last weekend at the condo I’ll be good to go starting next Saturday back at the Moore’s

**Ed Fleming**: Gotcha.  Could not get a fourth anyway.  Neither Tim or Tom available. 

**Jeff Bergosh**: Right on well let’s shoot for a week from this Saturday back at the Moore’s 👍😀

**Ed Fleming**:    Ron -- If Gary can play we have our four.  Still at beach? 

**Ed Fleming**: You three good for moors for the Saturday Oct 2nd. 

**Ed Fleming**: I am in!

**Ed Fleming**: Willie is not available, so even if gary is we would still need a fourth.  Let's see if Gary is available.   If not, I would say cancel for Saturday. 

**Ed Fleming**: Thanks. 

**Ed Fleming**: Could not find a fourth, and Jeff does not want to leave beach this weekend as it is his last weekend there. So let's cancel for this Saturday. 

### CONVERSATION ON 09-28-2021

**Ed Fleming**: You two good for tennis at Moors Saturday morning at 8 am?  Now that it is getting cooler I am good starting 8:30 or 9. 

**Jeff Bergosh**: I'm in!  Just let me know what time

**Ed Fleming**: Let's do 8:30.  Ron -- are you in?  

**Ed Fleming**: Would you ask Gary to be our fourth?

### CONVERSATION ON 09-29-2021

**Ed Fleming**: Great!  You and Jeff get rematch of the rained out set in which you were leading.  But cannot carry forward your 3-1 lead.  😋

### CONVERSATION ON 10-01-2021

**Ed Fleming**: See you guys at 8:30 am tomorrow at the Avalon tennis courts. 

### CONVERSATION ON 10-03-2021

**Ed Fleming**: Defense might be the best in the nation -- although secondary has yet to be tested.   Their rush is so good that backs have only had to defend for five seconds or so.  Auburn's scrambling QB will be a real test Saturday.  
JT Daniel's injury takes away from their offense. Bennett is a huge drop off. But Smart does not want to chance having true freshman back there, and our next three opponents are all ranked -- including a Florida team that barely lost to Bama. 

### CONVERSATION ON 10-06-2021

**Ed Fleming**:    Is everyone "in" for 8:30 am Saturday tennis?

**Jeff Bergosh**: I'll be in Copenhagen so I'm out for their week guys-- back for the following week though!

**Jeff Bergosh**: *this

**Ed Fleming**: Enjoy!  Don't bother walking the 2 miles to see the little mermaid. She's about 3 feet long. Not that impressive looking. See you next week

**Jeff Bergosh**: Thanks for the tip Ed!  See you next week

**Ed Fleming**: ROn?  Gary?  I am searching for a fourth. 

**Ed Fleming**: I have a replacement for Jeff.  So just need Gary's confirmation. 

**Ed Fleming**: I think he is copied on this string. 

**Ed Fleming**: Yes!

### CONVERSATION ON 10-14-2021

**Ed Fleming**: Are we all good for tennis Saturday at 8:30 am?

**Jeff Bergosh**: Absolutely-- at the Moors?

**Ed Fleming**: Yes. 

### CONVERSATION ON 10-15-2021

**Ed Fleming**: Bo is going to replace Gary so we have four!

**Ed Fleming**: Given Gary's decision to concentrate on singles, and Willys unreliability on being available, I think we should ask Bo to be one of our four stock players.

**Ed Fleming**: For the third time - yes we are playing at 8:30 and need you!  

**Ed Fleming**: Ron -- are you good for tennis Saturday? 
Gary -- Are you good for tennis Saturday?
Jeff and I are ready to play.  

### CONVERSATION ON 10-26-2021

**Ed Fleming**:   Is everyone in for tennis Saturday at 8:30'am?

### CONVERSATION ON 10-27-2021

**Ed Fleming**:    I found a fourth, but we will need to start at 8 am as he needs to leave at 10 am. Are you two good with 8 am start? 

**Jeff Bergosh**: Okay-- I can do 8

**Ed Fleming**: Weather is looking good for Saturday

**Jeff Bergosh**: See u all at 0830

**Ed Fleming**: I will recruit us a fourth. 
Sorry to hear about your thumb, Bo!  

### CONVERSATION ON 10-29-2021

**Ed Fleming**: Confirming tennis at 8 am tomorrow at the Moors Golf and Racquett club courts. Looking forward to seeing you guys!  

### CONVERSATION ON 10-30-2021

**Ed Fleming**: That was some great tennis!  Some well played points on both sides of the net.  Hard to be more competitive and closely matched than 7-6, 6-4. 

### CONVERSATION ON 11-08-2021

**Ed Fleming**: As I recall you are out this Saturday.  Is that correct?

**Jeff Bergosh**: Yes sir I’ll be in Orlando at a conference but I’ll be back next week!

### CONVERSATION ON 11-16-2021

**Ed Fleming**:    Please confirm for Saturday.  Also, Does 8:30 work for everyone or do we need to start at 8? 

**Ed Fleming**: Jarah?  

**Ed Fleming**: Thanks, Jarah.  I know that Ron is not available Saturday afternoon, and I suspect Jeff belongs to his beautiful wife Sally on Saturday's after 10:30.  Hope to see you next week. 
Ron -- I have a message to John Davis to see if he can fill in.  Any other ideas? 

**Ed Fleming**: They tried me as well. 

### CONVERSATION ON 11-19-2021

**Jeff Bergosh**: Ed I have to bow out tomorrow morning-- apologize for the last minute cancellation--but I'm looking forward to next week if we can play!

**Ed Fleming**: Dang!  

**Jeff Bergosh**: Sorry Ed

### CONVERSATION ON 11-22-2021

**Ed Fleming**: Is everyone good for Saturday?  

**Ed Fleming**: 8:30.  

### CONVERSATION ON 11-24-2021

**Ed Fleming**: Will be cold Saturday morning.  Goes from 46 to 50 between 8:30 and 9.  Anyone object to starting at 9?

**Ed Fleming**: 9 it is!  Father Ron just confirmed. 50 feels so much warmer than 45....  and wind is less than 5 mph.  So full sun and no wind -- we will be good! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-27-2021

**Jeff Bergosh**: Okay thanks I’ll take a look at it

**Ed Fleming**: Ron and I are here. You guys close?

**Ed Fleming**: Fun tennis on a beautiful day!  See you guys next week. 

### CONVERSATION ON 11-30-2021

**Jeff Bergosh**: Absolutely!  Thank you— I’ll send you the zoom invite/login credentials for next Wednesday— looking forward to a great discussion!

**Ed Fleming**: Jarah had to cancel for Saturday.  John Davis has agreed to fill in.  So we are still on for 9 am Saturday. 

### CONVERSATION ON 12-10-2021

**Ed Fleming**: 40 percent chance of rain tomorrow morning.  I will let everyone know by 8:15 if courts are dry.  Ed 

**Ed Fleming**: Yes. 9 am.  I thought we had all committed at the end of the match last week. 

### CONVERSATION ON 12-11-2021

**Ed Fleming**: No rain. Have done condensation on my back concrete deck so courts may be just a little damp. But I think they will be fine. See everyone at 9'unless you hear from me further. 

**Ed Fleming**: Great tennis!  Had to drink pickle juice to deal with cramping. We 

**Jeff Bergosh**: Awesome match guys!

**Ed Fleming**: Two sound so much better than one.  Three sound better than two.  Seven to five sounds great! 

### CONVERSATION ON 12-15-2021

**Ed Fleming**: Will you be able to play tennis Saturday?

**Jeff Bergosh**: Sure Ed!  9:00?

**Ed Fleming**: Yes. 9 AM

**Jeff Bergosh**: I’ll be there!

**Ed Fleming**: After winning seven straight games to come back in set two, the FLEMING-BERGOSH team will never   Surrender!  

**Jeff Bergosh**: Damn right Ed!

### CONVERSATION ON 12-17-2021

**Ed Fleming**: Forecast not looking good for tomorrow.  I will text everyone tomorrow morning to call it off if this forecast is accurate. 

### CONVERSATION ON 12-18-2021

**Ed Fleming**: Looks like rain has been delayed until this afternoon!  It is Dry and no rain!   I will let you know if that changes.  Otherwise will see you at 9 am.  

**Ed Fleming**: Still looking good.  

### CONVERSATION ON 12-25-2021

**Ed Fleming**:   Next Saturday is New Years Day.  What would you think go playing tennis Friday morning?  

**Ed Fleming**: Jeff?

**Jeff Bergosh**: I can do Friday.  9:00?

**Ed Fleming**: 9 am works for me!  Glad everyone could make the shift to Friday. Missed playing last week. 

### CONVERSATION ON 12-26-2021

**Jeff Bergosh**: See you all Friday!

### CONVERSATION ON 12-31-2021

**Ed Fleming**: Foggy like last week. Might be some condensation, like last week.  Road out front is dry.  See you guys at 9 am.  Last game if the year!

**Ed Fleming**: Having to drink pickle juice!  Cramping! 

### CONVERSATION ON 01-01-2022

**Ed Fleming**: Excellent!  See you guys the following week.  Happy New to my special tennis buddies! 

### CONVERSATION ON 01-10-2022

**Ed Fleming**: Confirming that the fantastic foursome are all in for Saturday at 9 am. 

### CONVERSATION ON 01-13-2022

**Ed Fleming**: Yep.  Sunday weather is looking better.  Want to try for Sunday after church?  

### CONVERSATION ON 01-14-2022

**Ed Fleming**: Only a 5 percent chance of rain at 8 am tomorrow, and it will be 50 degrees.  Is everyone good with starting at 8 am?  About an 80 percent chance of getting in two sets if we start at 8. 

**Jeff Bergosh**: I'm good for 8:00

**Ed Fleming**: John?  

**Ed Fleming**: Great!  We are all in for 8 am. Will text you if that weather system comes in early. 

### CONVERSATION ON 01-15-2022

**Ed Fleming**: Sorry for late note, but it is blue skies and dry courts here!

### CONVERSATION ON 01-20-2022

**Ed Fleming**:    Good news for Saturday morning is that forecast is sunny skies.   Bad thing is it will be COLD!  About 40 degrees.  9 am start good for everyone?

### CONVERSATION ON 01-22-2022

**Ed Fleming**: Just checked the tennis courts.  They are dry.  It is cold but dry courts and no rain. The court nearest the road is shielded from the worst of the northern wind. See you guys at 9.  Dress warm! 

### CONVERSATION ON 01-30-2022

**Ed Fleming**: He is my inspiration!  Down two sets in extreme heat against a younger opponent?  He just began to fight!

Rafael Nadal Beats Daniil Medvedev to Win Australian Open and 21st Major Title

**Ed Fleming**: https://www.wsj.com/articles/rafael-nadal-daniil-medvedev-australian-open-grand-slams-11643551106

### CONVERSATION ON 01-31-2022

**Ed Fleming**: I am good. 

**Ed Fleming**: I can check with Willie if you like.  

**Ed Fleming**: Willie is in. So we have a foursome. 

