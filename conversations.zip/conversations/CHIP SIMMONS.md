

## CONVERSATIONS WITH CHIP SIMMONS

### CONVERSATION ON 03-11-2020

**Chip Simmons**: I intend to be there.  Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-25-2020

**Jeff Bergosh**: Hello Chip- I Got my survey back today from Gravis Marketing and I polled a couple of other races including the sheriff’s race.  in your race in D1 you are leading 76-24 among those voters who are decided as of today.  This survey was conducted Tuesday and Wednesday of this week from a list of D1 registered voters of all parties.  Congrats!


-Jeff Bergosh

**Chip Simmons**: Great. Thanks.  You looking ok still? 

**Jeff Bergosh**: Yep-  I’ve got a 12 point lead over Jesse, And Jesse is leading Doug’s secretary by 16 points....... for 2nd!!!LOL.  Trotter is a non-factor in the race.

**Chip Simmons**: Wow.  Good job. Thank you so much. 

**Jeff Bergosh**: 👍 absolutely!  Keep up the great work Sheriff!!!

### CONVERSATION ON 08-18-2020

**Chip Simmons**: Congratulations Commissioner!!!

**Jeff Bergosh**: Thanks Chip!!  You’re turn is coming up!!!!  I look forward to working with you Sheriff!!!!!!  Great things ahead!!!!!

**Chip Simmons**: Liked “Thanks Chip!!  You’re turn is coming up!!!!  I look forward to working with you Sheriff!!!!!!  Great things ahead!!!!!”

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Congratulations Chip!!!!

### CONVERSATION ON 03-25-2021

**Chip Simmons**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-24-2021

**Jeff Bergosh**: Good afternoon Sheriff Simmons— great to see you Friday at the Mardi Gras kickoff.  In following up on our conversation, does Friday morning work- early?  Just let me know.  Thanks,

Jeff Bergosh

**Chip Simmons**: Hey Jeff, yes Friday sounds good to me. How does 8 am sound?

**Jeff Bergosh**: Works for me— can we meet somewhere near the base— perhaps the Waffle House on Navy Blvd?

**Chip Simmons**: Sounds great. See you there. 

**Jeff Bergosh**: Perfect.  See you then.

### CONVERSATION ON 07-09-2021

**Jeff Bergosh**: Good Friday afternoon Sheriff Simmons and Commander Hobbs!  I’m sending out the Zoom meeting credentials for Wednesday’s virtual coffee meeting — which email (s) should I send the login credentials to?   Thanks and have a great weekend— we’ll see you all Wednesday morning!

**Chip Simmons**: Cwsimmons@escambiaso.com

### CONVERSATION ON 07-14-2021

**Jeff Bergosh**: Sheriff Simmons—- thanks very much for taking time to join me on the coffee this morning!  Greatly appreciated!!

**Chip Simmons**: Thank you. Great job. 

**Jeff Bergosh**: Thank you Sheriff!

**Jeff Bergosh**: It’s very easy to administer, it’s like nasal spray and she gets the doses free of charge with a grant from IMPACT 100

**Chip Simmons**: Thanks I’m Gonna check with training about what that would entail. Who can I have someone call. 

**Jeff Bergosh**: Sally, my wife.  She runs the clinic as the executive director. Her number is 850-748-4456 cell 850-479-4456 office

**Chip Simmons**: Great. Thank you. 

### CONVERSATION ON 09-21-2021

**Chip Simmons**: Thanks! 

