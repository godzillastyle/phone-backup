

## CONVERSATIONS WITH GINGER DELEGAL

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Yes ma’am thanks!

**Jeff Bergosh**: Okay thank you!

