

## CONVERSATIONS WITH GARY STURDYVANT

### CONVERSATION ON 11-08-2019

**Gary Sturdyvant**: 10-4

### CONVERSATION ON 11-18-2019

**Gary Sturdyvant**: https://lottery.broadwaydirect.com/

### CONVERSATION ON 11-20-2019

**Gary Sturdyvant**: Jeff, there are good bake shops all over the city but Barb really liked this one.. If y’all are in that neighborhood take a break and check it out! Good stuff.

**Jeff Bergosh**: Thanks Gary we will check it out

**Gary Sturdyvant**: https://hamiltonmusical.com/lottery/

### CONVERSATION ON 12-06-2019

**Gary Sturdyvant**: The local news is reporting that the shooter is deceased along with one additional person. 

### CONVERSATION ON 12-11-2019

**Gary Sturdyvant**: Jeff I had to drop my truck off but I am on my way.

**Jeff Bergosh**: Okay

### CONVERSATION ON 01-22-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Gary Sturdyvant**: Hey Jeff I think I’m gonna need another day. Feeling pretty rough..

**Jeff Bergosh**: Hope you are feeling better

### CONVERSATION ON 01-23-2020

**Gary Sturdyvant**: Jeff I went ahead and submitted my time for the week. Just plan on seeing me next Monday. I feel like I’ve been run over by a train! 
I wouldn’t wanna spread this mess around the office. Wife had it for about a week and I finally ended up with it.

### CONVERSATION ON 01-28-2020

**Gary Sturdyvant**: Check out this article from Pensacola News Journal:

Former Milton administrative clerk allegedly deleted critical city files on her last day of work

**Gary Sturdyvant**: https://www.pnj.com/story/news/2020/01/28/former-milton-clerk-charged-fraud-allegedly-deleting-critical-files/4589131002/

**Gary Sturdyvant**: Does that last name ring a bell 🔔 

**Jeff Bergosh**: Eugene’s wife?

**Gary Sturdyvant**: Yep sounds like she took some bad advice!

**Jeff Bergosh**: Yep

### CONVERSATION ON 03-20-2020

**Gary Sturdyvant**: Running behind.  On my way.

### CONVERSATION ON 04-01-2020

**Gary Sturdyvant**: Jeff, I spoke with Jaron earlier but I just wanted to let you know that I am having a tire repaired and will be in shortly.

**Jeff Bergosh**: Okay thanks for the heads up

### CONVERSATION ON 04-27-2020

**Gary Sturdyvant**: Newer Guide 

### CONVERSATION ON 06-10-2020

**Gary Sturdyvant**: Look right 

### CONVERSATION ON 08-13-2020

**Gary Sturdyvant**: Jeff this is Gary. Our Air Conditioner went out last night. I am getting that taken care of but I do plan on coming in shortly.

**Jeff Bergosh**: All right Gary good luck in that fix will see you when you get in

**Gary Sturdyvant**: Thanks Jeff

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: Hey Gary I got your message I hope you feel better no problem at all if you feel better come in if you don’t feel better take the whole day off just do me a favor I need for you to go in to the online timesheet and punch in your hours for Monday, August 31 the bookkeepers in Huntsville need that to process payroll so if you can do that today from your house that would be helpful just let me know if you’re able to do it so I can go in and approve it

### CONVERSATION ON 09-08-2020

**Gary Sturdyvant**: Running a little behind. Coming through the back gate now.

### CONVERSATION ON 09-15-2020

**Jeff Bergosh**: Gary let me know your status for today as soon as you can.  Thanks!

**Gary Sturdyvant**: Hey Jeff. Any trouble getting on base?

**Jeff Bergosh**: No

**Jeff Bergosh**: Warren, Jaron and I are here

**Gary Sturdyvant**: Ok I will be heading that way soon.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Gary— just got word the back gate is closing at 1000 in case you were coming in that direction.  Front gate only

**Jeff Bergosh**: Thanks Gary

### CONVERSATION ON 09-17-2020

**Gary Sturdyvant**: Hey Jeff, I was out working in the yard when you called this afternoon. Just to make sure I understood you correctly, did you say work tomorrow was not mandatory?  (liberal leave)

**Jeff Bergosh**: Yes that is correct Gary

**Gary Sturdyvant**: Ok thanks Jeff. Keep me posted.

**Jeff Bergosh**: All-

I came to bldg 458 today to assess damage:  carpets throughout our spaces are soaked, map room has standing water, several sections of roof have been damaged and allowed for water intrusion.  Power and water are on, no visible damage  to anyone's computers, 1 of 2 ACs is functional, phones are inoperable and neither NMCI nor PBSS networks are up, and emails not working.  Two doors damaged (map room and side exit by my office) and are open but wedged shut with cinder blocks.  I'm going to see Mark Powell now about getting our spaces repaired and carpets pulled and/or vacuumed up.  I will keep you all posted with a follow on text and phone calls.  Be safe everyone.

**Gary Sturdyvant**: Thanks

**Gary Sturdyvant**: Thank Jeff

**Gary Sturdyvant**: Did you use the front gate?

**Jeff Bergosh**: Yes front gate is open

**Gary Sturdyvant**: Ok thanks 

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: Where?

**Gary Sturdyvant**: Saw them at Home Depot.

**Jeff Bergosh**: Okay good to know they are available I’ll probably get one for the office thanks for sharing

**Jeff Bergosh**: Hey Gary- if you are able to do so, I need for you to submit your online timesheet

**Gary Sturdyvant**: Jeff can you send me a pic of that password? I’m having trouble 

**Jeff Bergosh**: Okay

### CONVERSATION ON 09-22-2020

**Gary Sturdyvant**: Jeff, I gotta run by the drugstore to pick up my antibiotics on the way in. Might be a minute late but I’m on my way.

**Jeff Bergosh**: Got it, no problem 

### CONVERSATION ON 10-08-2020

**Gary Sturdyvant**: Good morning Jeff. I had that tooth removed yesterday afternoon. I think I might need to rest today if that’s ok..

**Jeff Bergosh**: Absolutely Gary— glad they got it done!  Hope you are feeling better!

**Gary Sturdyvant**: Thanks Jeff. I will plan on being back tomorrow.

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-14-2020

**Gary Sturdyvant**: Hey Jeff, I’m running a little behind. I’ll get with you as soon as I get there..

**Jeff Bergosh**: Okay got it

### CONVERSATION ON 12-02-2020

**Gary Sturdyvant**: Got it

### CONVERSATION ON 12-03-2020

**Gary Sturdyvant**: Hey Jeff I just got back from Sacred. They will call me sometime today with results. I will let you know know when they call me.

**Jeff Bergosh**: Okay great thanks for the heads up and hopefully it’s a negative 

**Gary Sturdyvant**: Sure hope so. 🤞

### CONVERSATION ON 12-08-2020

**Gary Sturdyvant**: Hey Jeff I’m run behind. I’ll be a few minutes late.

**Jeff Bergosh**: No prob— just see me when u get here

**Gary Sturdyvant**: Yes Sir. Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-11-2021

**Gary Sturdyvant**: On the way home I tried the ascension site and they had opened it for a short time. I was able to register both my mom and dad and Barb registered her mom too. I feel like we won the lottery today. It it terribly difficult the way the have it set up especially for the seniors.

**Jeff Bergosh**: That’s fantastic Gary!  Glad you got through!

### CONVERSATION ON 01-19-2021

**Gary Sturdyvant**: Running behind at the gate 

**Jeff Bergosh**: Okay just meet us in the conference room

### CONVERSATION ON 02-11-2021

**Gary Sturdyvant**: Gate is extremely backed up 

**Jeff Bergosh**: Yes

### CONVERSATION ON 02-18-2021

**Jeff Bergosh**: Hey Gary I’m just checking on your status is everything OK? Please give me an update hope all is well thank you.

Jeff Bergosh

**Gary Sturdyvant**: Hey Jeff I just got a call from sacred. Test was negative so that’s good news. I’m expecting a call from my doctor this afternoon but I would think she would have me go on back tomorrow unless she has scheduled additional test..

**Jeff Bergosh**: Okay great news Gary glad to hear it.  Just let me know if anything changes.  

**Gary Sturdyvant**: Yes Sir. Will do

### CONVERSATION ON 02-22-2021

**Gary Sturdyvant**: At the gate 

**Jeff Bergosh**: Okay meet us in the conference room

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

### CONVERSATION ON 03-11-2021

**Gary Sturdyvant**: On the bridge 

**Jeff Bergosh**: Okay 

### CONVERSATION ON 03-12-2021

**Gary Sturdyvant**: Hey Jeff I think I may stick around here for a little while to keep an eye on Barb and make sure she’s gonna be ok. I may try to come on in a little later if I’m not needed here. She’s just starting to feel the effects of her shot.

**Gary Sturdyvant**: Nothing due today

**Jeff Bergosh**: Alright thx

**Jeff Bergosh**: Hope she’s feeling better

**Gary Sturdyvant**: Thanks 

**Jeff Bergosh**: 👍

**Gary Sturdyvant**: Jeff I’ll see you in a.little bit.  Barb seems to be doing ok.

**Jeff Bergosh**: Right on Gary.  Happy to hear that!

### CONVERSATION ON 03-16-2021

**Gary Sturdyvant**: After my doctors appointment I made my way to the ER with some chest discomfort. They did determine that I was not having a heart attack but I believe they still want to keep me and check me out a little closer. I’ll probably be here overnight.

**Jeff Bergosh**: Wow!  Sorry to hear that Gary!  Hope everything is okay.  Let me know how you’re doing tomorrow.

**Gary Sturdyvant**: I will keep you posted for sure. I haven’t felt good for a couple weeks. Got to get that check engine light turned back off..

**Jeff Bergosh**: Amen!  Get well soon!!

### CONVERSATION ON 03-17-2021

**Jeff Bergosh**: Hey Gary- just checking on you.  Are you doing better?

**Gary Sturdyvant**: I am waiting to be discharged now. Feel like a pin cushion though. I am planning on being at work tomorrow. I will let you know if anything changes.

**Jeff Bergosh**: Okay.  Glad they are letting you out!

**Jeff Bergosh**: 👍🙏

### CONVERSATION ON 03-18-2021

**Gary Sturdyvant**: Hey Jeff I’m gonna get ready and try to come on in but I may be a few minutes late.

**Jeff Bergosh**: Alright but if u need more time take it.  👍

**Gary Sturdyvant**: I tried but I don’t think I’m up for it today.

**Jeff Bergosh**: 👍 totally understand.  Hope you’re feeling better

### CONVERSATION ON 03-22-2021

**Jeff Bergosh**: Hey Gary I got your voice message I’m sorry I missed your call. No problem at all take that appointment in the morning and we will see you after.  hopefully it all goes well —good luck and will see you after your appointment in the morning have a good night.

Jeff

### CONVERSATION ON 03-31-2021

**Jeff Bergosh**: Hey Gary please put this work order in to the share drive I can’t find it to do a QA check on it thanks

**Jeff Bergosh**: The building 626 project that you turned in

**Gary Sturdyvant**: My bad. Doing it now 

### CONVERSATION ON 06-03-2021

**Gary Sturdyvant**: At the gate. Backed up

**Jeff Bergosh**: Ok

### CONVERSATION ON 06-11-2021

**Gary Sturdyvant**: I’m on my way but may be a little late

**Jeff Bergosh**: I thx

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: Hey guys this is not a prank! I was just notified by PBSS that we have tomorrow off for the new holiday. I have confirmed with Tony this evening that we will honor this. So we all have a day off tomorrow! We will adjust our time sheets on Monday I hope everyone has a great three day weekend. Please do me a favor and acknowledge that you've received this thank you!

Jeff B

**Gary Sturdyvant**: 👍

### CONVERSATION ON 07-01-2021

**Gary Sturdyvant**: Jeff I didn’t think to mention it yesterday but I need to go have an ultrasound this morning. It shouldn’t take long so I would think I will be in by 9:30 or 10:00.

**Jeff Bergosh**: No worries Gary, we’ll see you when u get there.

### CONVERSATION ON 07-08-2021

**Gary Sturdyvant**: I 110 Overpass at Brent Lane.

### CONVERSATION ON 07-22-2021

**Gary Sturdyvant**: Took this pic of the north side of the I-110 overpass  on Brent Lane this AM. I heard Andrew McKay speaking with the mayor about this on the radio and he says it is in the country. Should I contact the commissioner for that district or somebody else with the country?

**Jeff Bergosh**: This is actually in the county, not the city.  I believe this is in District 3, LumonMay’s district

**Gary Sturdyvant**: Got it thanks Jeff 

### CONVERSATION ON 07-28-2021

**Jeff Bergosh**: Hey Gary— I’m at this luncheon but it’s running long.  Can u call in to the Wib and represent us if I can’t make it back to base on time?

**Gary Sturdyvant**: Yes

**Jeff Bergosh**: .....and thanks!

**Gary Sturdyvant**: No problem 

**Gary Sturdyvant**: Just to confirm, is the WIB @ 1300?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Thanks Gary

### CONVERSATION ON 08-01-2021

**Gary Sturdyvant**: Check out this article from Pensacola News Journal:

Masks now required indoors at NAS Pensacola and NAS Whiting Field as COVID-19 cases surge

https://www.pnj.com/story/news/military/2021/07/30/covid-19-masks-now-required-indoors-nas-pensacola-whiting-field/5437433001/

Just saw this. Not sure if
you had seen it.

**Jeff Bergosh**: Thanks Gary— I hadn’t seen this yet

### CONVERSATION ON 08-02-2021

**Jeff Bergosh**: U on way in— or did u have an appointment this morning?

**Gary Sturdyvant**: On my way 

### CONVERSATION ON 08-09-2021

**Jeff Bergosh**: Gary—I need your hard copy time sheet for last week.

Thanks!

### CONVERSATION ON 08-19-2021

**Gary Sturdyvant**: Got it 

### CONVERSATION ON 08-25-2021

**Gary Sturdyvant**: https://floridahealthcovid19.gov/monoclonal-antibody-therapy/

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Thanks for any advice you could give!😀

**Gary Sturdyvant**: Is that ground wire coming out of the conduit with the other wires?

**Jeff Bergosh**: Yes it is

**Jeff Bergosh**: Green wire

**Gary Sturdyvant**: Or is it attached to the box only. (Bonding jumper)

**Jeff Bergosh**: Coming out of the conduit

**Jeff Bergosh**: And BTW I have the breaker off LOL

### CONVERSATION ON 09-13-2021

**Gary Sturdyvant**: Gate traffic backed up 

**Jeff Bergosh**: Ok

**Gary Sturdyvant**: On the bridge 

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: I’ll get with you individually when u get here

### CONVERSATION ON 10-21-2021

**Gary Sturdyvant**: On the bridge .  Traffic really backed up 

**Jeff Bergosh**: Okay just meet us in the conference room when u get here

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: John Gary, the gate is totally backed up so you will both probably be late this morning. Warren is on a site visit so we won't have a 730 meeting this morning ---I'll get with you guys later this morning and get your sheets from you and an update on your work plans individually

**Gary Sturdyvant**: Yep John's right beside me see you in a few 

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: Gary John the front gate is locked up solid it's a parking lot. I've been waiting 10 minutes already barely moving haven't even got to the bridge yet. Unless something changes I anticipate you both will probably not be in by 7:30. Therefore we won't have our 730 meeting. I'll come meet with you individually once you arrive.

**Gary Sturdyvant**: 👍

**Gary Sturdyvant**: Not cool 

**Gary Sturdyvant**: My bad disregard!

**Jeff Bergosh**: What's not cool LOL?

### CONVERSATION ON 11-04-2021

**Gary Sturdyvant**: Tied up in gate traffic 

**Jeff Bergosh**: OK just bring me your sheet when you get here

### CONVERSATION ON 11-12-2021

**Jeff Bergosh**: Gary— please submit your online timesheet for me, thanks!

**Gary Sturdyvant**: Ok Jeff it’s submitted 

**Jeff Bergosh**: Thanks Gary.  Can you please ask Dave Midgorden to correct his time sheet he’s not answering his phone but he has errors on his time sheet that need to be corrected. Thanks Gary!

**Gary Sturdyvant**: I believe Dave is on PTO today

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 11-15-2021

**Gary Sturdyvant**: At the gate 

**Jeff Bergosh**: K

### CONVERSATION ON 11-18-2021

**Gary Sturdyvant**: Just made it through the gate 

### CONVERSATION ON 12-07-2021

**Gary Sturdyvant**: Jeff I forgot that I need to run by the lab to give blood this morning. I will be a few minutes late.

**Jeff Bergosh**: Ok thx for heads up

### CONVERSATION ON 12-14-2021

**Gary Sturdyvant**: On the bridge 

**Jeff Bergosh**: Okay meet us in the conference room

### CONVERSATION ON 12-29-2021

**Gary Sturdyvant**: I heard that starting January 1 mask will be required for all indoors..

**Gary Sturdyvant**: On base

**Jeff Bergosh**: …..here we go again

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Yes Bruce this is Jeff Bergosh.  Thanks very much for coming this evening-- greatly appreciated

