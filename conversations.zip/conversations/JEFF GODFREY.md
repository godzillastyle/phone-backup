

## CONVERSATIONS WITH JEFF GODFREY

### CONVERSATION ON 07-27-2020

**Jeff Bergosh**: Will do

### CONVERSATION ON 07-28-2020

**Jeff Bergosh**: Wow!  Thank you for the heads up on that! 

**Jeff Bergosh**: That’s great information to know 

