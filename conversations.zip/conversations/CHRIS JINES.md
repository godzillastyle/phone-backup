

## CONVERSATIONS WITH CHRIS JINES

### CONVERSATION ON 01-11-2020

**Chris Jines**: Good answers and straight to the point no mincing of words 👍

**Jeff Bergosh**: Thanks Chris

### CONVERSATION ON 02-19-2020

**Chris Jines**: Did you take a quick phone call

**Jeff Bergosh**: Yes and I bet I know what it’s about LOL

### CONVERSATION ON 02-28-2020

**Chris Jines**: Hi jeff just want to check back with you and get a feel for what you think your return rate on that mail out petition car drive was doing

**Jeff Bergosh**: I sent out 2000 letters and I have received back 342 envelopes containing 512 signed petitions.  I think it was a grand slam—nearly 26% return rate and I put a palm card in each envelope so it was a “touch” of these star voters to boot.    The mail out cost me $1,950 and the postage will be about $600.  But I avoided the labor of getting the petitions and won’t have to pay the $4,897.00 qualifying fees.  For me it worked really well!

**Chris Jines**: 👍

### CONVERSATION ON 08-17-2020

**Chris Jines**: Good luck tomorrow I’m sure it will turn out your way

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thank you Chris!

### CONVERSATION ON 02-08-2021

**Chris Jines**: When do you meet with them

**Jeff Bergosh**: Nature trail tomorrow

**Chris Jines**: What time in the evening 

**Chris Jines**: I want to review all this and they are still pulling info so if I get it to you in the morning will that be ok 

**Jeff Bergosh**: Sure.  Thanks Chris

**Chris Jines**: Great

**Chris Jines**: Ok got it faster than I thought you got a minute

**Jeff Bergosh**: Yep

### CONVERSATION ON 08-05-2021

**Chris Jines**: Hey Jeff you got a min for a call

**Chris Jines**: Sorry forgot about your meeting 

**Chris Jines**: Last year 2260 

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: Hi Chris, Jeff Bergosh here.  I have a Quick question on a couple SRIA leases that were recently renewed and I wanted to discuss them with you if you have a minute to talk.

Thanks,

Jeff Bergosh

### CONVERSATION ON 09-29-2021

**Chris Jines**: Are you available for a call about the lease info you sent me today

**Jeff Bergosh**: Yes

**Chris Jines**: It may be about lunch time I’m out of town in some meeting will that work

**Jeff Bergosh**: I have a lunch and starting at 11 that will go till about two anytime after 2 o’clock is perfect

**Jeff Bergosh**: Or this morning anytime before 11 works as well

**Chris Jines**: Let’s do after 2

**Chris Jines**: Thanks 

**Jeff Bergosh**: I’ve asked Allison specific questions about those leases and I’m not getting straight answers. The very basic question I’m asking is the way that language is worded is it done so in order to get those individual houses out from under paying ad valorem tax on the land

**Chris Jines**: Ok

**Jeff Bergosh**: I look forward to the conversation thanks Chris

**Chris Jines**: I also met with my attorney and have some ideas going forward I will probably have my chief deputy on with us who also is on SRIA Board if ok 

**Jeff Bergosh**: Sure thing

**Chris Jines**: Are you available now or just text when you are 

**Jeff Bergosh**: Yes

**Chris Jines**: Calling you now 

