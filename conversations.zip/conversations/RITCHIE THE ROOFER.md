

## CONVERSATIONS WITH RITCHIE THE ROOFER

### CONVERSATION ON 12-03-2019

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Who is this?

**Jeff Bergosh**: Absolutely, totally get that.  You need to speak with Doug Stewart the HOA President.  He will look at what’s planned and then forward through the architecture committee.

**Jeff Bergosh**: Not right off the bat but I’ll get it for u

