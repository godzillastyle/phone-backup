

## CONVERSATIONS WITH SHARON GODWIN

### CONVERSATION ON 11-13-2019

**Sharon Godwin**: Hey friends, I hate to send a text to you asking this but I need Jesse Casey phone number if either of you happen to have it. My old horse, buck, needs to be put down today. The vet is coming at 2. We've had him for 32 years since he was 17 months old. Just seeing if I can get ahold of him to help me bury buck. By the way I'm pretty sure that's the one that Brandon has ridden before

**Sharon Godwin**: Wish I had 20 of him he was the best!

**Jeff Bergosh**: 850-944-4444

**Sharon Godwin**: Thanks! The number I had was disconnected

**Jeff Bergosh**: Sorry about your Horse Sharon😪

**Jeff Bergosh**: I'll check one other place

**Sharon Godwin**: Oh no sorry I meant it should say the one I had

**Sharon Godwin**: So this is a landline correct

**Jeff Bergosh**: This is from his elections page--maybe try emailing him?

**Sharon Godwin**: Thanks I just left him a message at the 944 number. I had a different number that has been disconnected. Sorry I had texted you incorrectly

**Jeff Bergosh**: I just spoke to him and he's going to be calling you. Sorry about the horse I know that's a real sad situation

**Sharon Godwin**: Thank you. 

### CONVERSATION ON 12-03-2019

**Jeff Bergosh**: Hey are either one of you guys at the house?

### CONVERSATION ON 03-28-2020

**Sharon Godwin**: Good Morning! I see that u are out and about looking for TP too! We found some the other day BUT couldn't see the label bc it was at my toes! Went to check out and it was $5 more! We have a little extra if u needs some to get u by!

**Sharon Godwin**: Almost, we have some said news to share and hope maybe our friends and family can help.¿Donnie was fired last week. After 20 years at Ascend at the Foley plant he had ONE safety violation and it was sent to corporate in Houston and they fired him.¿So any jobs please let us know! I could work a part time afternoon/evening  job too.

**Jeff Bergosh**: Thank you Sharon for that I am so sorry to hear about Donna's situation on Monday I will check there could be openings at the base for a contractor there also are multiple openings at the county and the roads department I'll look into that

**Jeff Bergosh**: Stay safe

**Sharon Godwin**: Thank u! Stay safe as well

### CONVERSATION ON 06-17-2020

**Sharon Godwin**: Here we go again! How can he send out an email to all the teachers?

**Jeff Bergosh**: Someone sent him the list more than likely.  

**Jeff Bergosh**: Thx for the heads up

**Sharon Godwin**: Correct, we are told every year that groupwise now (Google email) can not be used for personal or political means! Just couldn't be....
😉

**Jeff Bergosh**: LOL he didn't follow the rules

**Sharon Godwin**: And I'm a rule follower! 😇

**Sharon Godwin**: Just left a message for good ole Norm

**Jeff Bergosh**: 👍 right on!

**Sharon Godwin**: 😉

### CONVERSATION ON 10-07-2020

**Sharon Godwin**: Good evening everyone!
Big News from the Godwin Clan....
Seth has decided to join the Army!
He leaves on the 26th! 😬😥😁
He has talked about this for awhile and he stood his ground until they made the offer he wanted! He will go into special forces. 
We will have a Sending Off party for him on Oct. 18th, Sunday,  at Evan & Katelyn's house @4! We will have Chad's amazing pulled pork and of course chicken! Come and go as you can! I know Sunday's are hard to stay late for some & plenty of the family on this text will not be here but wanted you all to know so you can give him a shout out! He is not on fb but perhaps Instagram or his cell 850-712-1309 
Love 💘  to all!
(I had a message I thought I had sent a few days ago but come to find out...I didn't hit send🙄)

**Sharon Godwin**: Oh yea! 
About 11 miles west on Muscogee/hwy 112
33903 Lee road 
Robertsdale , Alabama 36567

### CONVERSATION ON 10-08-2020

**Jeff Bergosh**: 😎

### CONVERSATION ON 10-16-2020

**Sharon Godwin**: Hey Everyone!
This is is going to be a blast plus beautiful weather 😍 
Come with a hardy appetite and if u have a yard game bring it! We will have corn hole & horse shoes! If you have a Bow 🎯 you can bring that as well! Plenty of land to romp and stomp on!
Dress very casual too!
If you have RSVP on FB please do or text me here or separately! 😁
🕓Starts at 4 til ??
🍽 Eat @ 5:30!
*come and go as you please 😘  Eat early or late!

**Sharon Godwin**: [Name] Katelyn My Baby Girl
[Mobile] (850) 712-3721
[Home] 33903 Lee road 
Robertsdale , Alabama 36567

**Sharon Godwin**: It's about 15-18 minutes from our house! Beautiful drive!

### CONVERSATION ON 10-18-2020

**Sharon Godwin**: Hello friends and family today's the day! It's gorgeous beautiful weather great food and great friends and family gathering at Katelyn's from 4 clock on! Or drop in as you can, Food served at 5:30 or anytime!

### CONVERSATION ON 10-25-2020

**Sharon Godwin**: Hello! Didn't know if you were interested in the originals but here are the 2 you saw at the party. He has one more you didn't see I could get from him as well. Not sure of price but here is his etsy acct for prints
Eveantaylorfineart

**Sharon Godwin**: Here's the other one he has the original. It was in his Art studio.
https://www.etsy.com/listing/853356535/fish-art-decor-canyon-cruiser

### CONVERSATION ON 12-15-2020

**Sharon Godwin**: Coming home and we're going to get him. Do you know anyone that does signs fairly cheap or has like a sign I can write on the back of

**Sharon Godwin**: Kind of like one you would hang up on a fence. 

**Sharon Godwin**: I priced one today and it was $80 for a 3' by 6' kind of ridiculous

**Sharon Godwin**: O by the way can you marry Seth and his  Fiance😯😅🙄😁

**Sharon Godwin**: Oh yes really

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: Wow Sharon!  I'll call you later today I didn't see this until just this morning.  How exciting!

**Sharon Godwin**: Np 🙂 Sally and I caught up quite a bit last night! We shared our boys stories and wow, they both have struggled in similar ways🥲
I would love to borrow some of ur larger signs this afternoon if possible?

**Jeff Bergosh**: Sharon I would love to help but I tossed out all my large signs after the election.  I still have a bunch of yard signs though, they are 2-sided-  but you're welcome to as many as you want you'd just have to spray paint over them LOL

**Sharon Godwin**: I'm Driving

- Sent from My Car

**Sharon Godwin**: Oh yea! We could do that!  I have one more place and going to check for prices and then I would still love to do some of your signs. I make it Chad to run around there and help out because we're leaving around 5 to go get him.

**Jeff Bergosh**: Okay sounds good!

**Sharon Godwin**: Hey! Sally forwarded ur text. I'm leaving to drive to GA to get Seth so I'll get Donnie to get with you.  We may just do balloons this time.  I had no idea how expensive they were or I would have done this way before now🙄😄
THANKS SO MUCH! Y'all are the best!

**Jeff Bergosh**: No problem at all!!  Congratulations Sharon!

**Jeff Bergosh**: Gary Bergosh 

**Sharon Godwin**: I'm Driving

- Sent from My Car

**Sharon Godwin**: Awesome! And yes,  they are on it About license as soon as his feet hit the floor tomorrow.  It's supposed to only take 3 days. We hope🤞

### CONVERSATION ON 09-26-2021

**Sharon Godwin**: https://youtu.be/imbGdfzckrI

**Sharon Godwin**: Sorry for bleeps 🤷‍♀️

**Sharon Godwin**: Any ideas 💡??

**Sharon Godwin**: Oh yes,  sorry.  
Silas Malachi 
8.06 lb
20"

**Sharon Godwin**: Thank you and yes they are!!

### CONVERSATION ON 01-11-2022

**Sharon Godwin**: Ok, mums the word I promise 🤫
What else is going in the 9 mile rd crossing? Is there a cure m chic fil a? 🤞

**Jeff Bergosh**: Hi Sharon!  There was supposed to be a Chic Fil A in the last development on the southside of 9 mile road before exit 5 but that deal fell apart. I honestly don't know what else is going in at 9 mile crossing other than the McDonald's but I'm hoping we get something quality like Chick-fil-A! I'll let you know when I find out happy new year and tell Donnie I said hello!

**Sharon Godwin**: Awe ok  Good to know though because someone knew at 1 time they had gotten the go ahead. Definitely need something better than McDonald's lol However I do love those little hamburgers with extra pickles haha

**Sharon Godwin**: Happy New Year as well we need to get together for dinner sometime! and we keep saying that but we've got to do it!  Before we're too much older and grayer! 👵🧓

**Jeff Bergosh**: I agree!  Let's do that!  

