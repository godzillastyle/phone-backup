

## CONVERSATIONS WITH LISA FOURNIER

### CONVERSATION ON 05-01-2020

**Lisa Fournier**: Sent you a Facebook messenger. Have a question/request. 

### CONVERSATION ON 06-21-2020

**Lisa Fournier**: Happy Fathers Day! 

**Jeff Bergosh**: Thank you Lisa!!

### CONVERSATION ON 07-02-2020

**Lisa Fournier**: Hey. I have sent you a question- a problem I am trying to solve- on messenger. I know you are working now. Please read on your own time and let me know who, how, what I should contact. 

**Jeff Bergosh**: Okay will do Lisa

### CONVERSATION ON 07-07-2020

**Lisa Fournier**: Still haven’t found who to complain to. Caitlin was tested at UWF on June 27 at 9am. She just now got an email saying she was negative! 10 days!

### CONVERSATION ON 07-09-2020

**Lisa Fournier**: The Escambia tracker is fabulous. Couple of questions. On # hospitalized, what is that little plus number mean? It would really be helpful to have previous day hospitalized, # of admissions, and # of discharges. When it goes up by one, it could mean 30 was discharged and 31 admitted. Secondly, does this data include tests done at the navy base? 

**Jeff Bergosh**: Not sure but I’ll find out Lisa.  We’re still working out the bugs but it is important to have good, reliable data so folks are not spooked by the out-of-control media on this.....

**Lisa Fournier**: That’s why I think it’s important to know how many admissions today or yesterday. Some of those people could have been there awhile. I also wish we knew how many came to the hospital due to CoVid symptoms and how many came to the hospital due to heart attack and tested positive for CoVid after they got there. It’s information like that which will talk people off the ledge.

**Jeff Bergosh**: Exactly.  We are working to incorporate that sort of data into the dashboard

### CONVERSATION ON 07-10-2020

**Lisa Fournier**: This is from Kuwait. This is what I want to know. How many active cases? How many receiving treatment? How many recovered. Look how great this is. 

### CONVERSATION ON 07-14-2020

**Lisa Fournier**: I’m sure you’ve seen that Florida data is all screwed because labs are reporting the negative tests? Well here’s something from Texas. We can’t come out of our houses again, ever. Seasonal flu is far deadlier than CoVid.

### CONVERSATION ON 07-23-2020

**Lisa Fournier**: True story. I contacted the director of Harvard’s Global Institute for Health because he was quoted in the USAToday saying, “people who aren’t wearing masks kill people”. I asked him for his data to back up that statement. He said, “well, there isn’t any but it gives people something to do. It’s not a bad idea.” I refuse to wear a mask on someone’s opinion it’s a good idea. Do I wear a mask when I can’t social distance? Sure. Do I wear one at the Sunset Grill when it’s 1000 degrees in the shade, no I don’t. Believe it or not, masks are NOT required at the Navy hospital because people quit coming to the doctor if they were forced to wear them. I will mask when I feel it necessary, not when someone tells me to. I will just quit frequenting that place or business. I have not stepped foot in Pensacola city limits since their mask rule and will not. I’ll pay more, but in Perdido or order before I go there. 

**Jeff Bergosh**: Thanks Lisa.  I agree— however I’m listening to all the stakeholders too— even those with differing opinions

**Jeff Bergosh**: I’m trying to find something that strikes a balance

**Lisa Fournier**: I get the differing opinions, however, it’s not really a difference of opinion. It is opinion against medical facts- the fact there is nothing that says it works.  I still ask them for proof. I am tired of people’s opinions. We didn’t require seat belts until there was proof it made a difference. And then how do you police it? You can’t. Nor are the police going to. If you do require masks I insist you require people to wear them correctly and fine them if they touch the mask without washing their hands before they touch anything else cause there is medical proof that spreads the virus. Again, stopped in a Walmart. The check out worker touched her mask 7 times while ringing up my 10 items. I would have been safer is she would have taken the mask off. I got home wondering what she rubbed off her mask onto my purchases. You gotta do your thing. The government needs to quit trying to make decisions for people. My 96 year old aunt doesn’t wear a mask. Why? Because she is 96 years old- in her words, “my last breath won’t be through a piece of cloth”. You got to respect that. 

**Jeff Bergosh**: I do respect that. 

**Jeff Bergosh**: That’s how I’ve been

### CONVERSATION ON 07-24-2020

**Lisa Fournier**: What. A. Joke.

**Jeff Bergosh**: What a hypocrite—-no social distancing and no proper mask wearing!!

**Lisa Fournier**: And you want the American public - particularly escambia county residents to mask. Good luck with that. This picture has been shared in the internet 2.7 million times. 

**Lisa Fournier**: Another example. This is from the announcement where this city commissioner whoever he is was announcing the face mask requirements. The gaps at the nose and ears masks the mask completely worthless. 100% worthless. It’s all for show. 

On another topic, the severity of the illnesses of the patients hospitalized has dropped, and most of the recent 10 deaths were from Jul 1-3 and just now reported. How can you believe numbers when they get reported as a group so they make the most impact on the panic.

**Jeff Bergosh**: I know— I went to red alert about ten deaths.  But come to find out it was a multi day backlog just now being reported.   Which actually points to other problems

**Lisa Fournier**: Which is also true on days we have hundreds of positives. Another problem....We had a Navy corpsman test positive. In contact tracing when they called, he gave them the names of 19 people. Most of them he hadn’t been close enough to transmit CoVid. Only 3 agreed to be tested. They told them that if they refused testing, they would be counted positive. So there you go. 1 plus 16 positives for one person. 

**Jeff Bergosh**: That’s the kind of problem I worry about and nobody is reporting it!!!!  Which leaves us policy makers at the mercy of poor/incomplete data

**Lisa Fournier**: So we don’t have a freak out over the 17 deaths in Escambia in the month of July. In addition, 7 of these were in the hospital over 20 days, meaning they were sick in June, maybe mid June. 

**Jeff Bergosh**: Thanks Lisa— where did this cone from?

**Lisa Fournier**: I just wrote down the numbers- date age and sex off of the Florida website and organized it by date. You can find it there. I was curious of “who” was dying and when. No deaths are good but who matters. 

**Lisa Fournier**: And then who
Knows if they died OF CoVid or WITH Covid. When you are 99, anything could have killed you. 

**Lisa Fournier**: The list from Florida’s website. The hospitals say the average death is in the hospital 8-15 days before death. You don’t get sick the minute you are infected. These deaths were likely infected 3-5 weeks ago. 

**Lisa Fournier**: Sorry here’s escambia. Didn’t mean to send you Lee county

### CONVERSATION ON 07-29-2020

**Lisa Fournier**: This is a scatter chart of deaths. If you look, deaths have not increased or decreased. They are nearly the same as March/April. The only decrease was when we all hid inside, which can’t happen again. What I don’t know is how many died WITH Covid and how many died OF covid. And, how many of these were from nursing homes because masking in the community won’t change that at all. Data from Florida.gov

**Lisa Fournier**: Time across the bottom, in 20 day increments, age going up. 

**Jeff Bergosh**: Thank you Lisa!  I’m working on getting a spreadsheet with all of the deaths in Escambia County complete with the cause and any associated co-morbidities.  I’ll share that with you when I get it

**Lisa Fournier**: Great. I already have some graphs that can better define who is at risk- and how to protect those people. At least one was a motorcycle accident that tested positive AFTER the accident and died of internal injuries. 

### CONVERSATION ON 08-01-2020

**Lisa Fournier**: He did! Lol. 

### CONVERSATION ON 08-18-2020

**Lisa Fournier**: CONGRATULATIONS! So glad I can continue to harass you, and push you for a few more years. Seriously, your people are lucky to have you to fight for them. All of us in Escambia County are lucky to have you to ask questions -- when you know no one has the answer to. So, Mr. Newly Elected Commissioner - wear a mask until WHEN?

