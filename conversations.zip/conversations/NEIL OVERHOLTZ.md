

## CONVERSATIONS WITH NEIL OVERHOLTZ

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: Governor just closed on premise restaurants and on premise alcohol consumption

**Jeff Bergosh**: Send me your email

**Jeff Bergosh**: I’ll forward it

### CONVERSATION ON 03-21-2020

**Jeff Bergosh**: Thanks and I don’t disagree Neil about the number system.  Not a bad idea!

