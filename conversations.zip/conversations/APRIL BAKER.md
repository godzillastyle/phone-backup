

## CONVERSATIONS WITH APRIL BAKER

### CONVERSATION ON 05-11-2020

**Jeff Bergosh**: Yes that will work.  Just let me know where you’d like to meet and I’ll see you there.  Thanks!

**Jeff Bergosh**: Okay there are three, one on Bridlewood, one on Frank Reeder, and one on Tower Ridge.

**Jeff Bergosh**: And then send them to you

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Hey April-the sign on Frank Reeder is just East of Bridlewood on the westbound shoulder.  We can meet there if that works.  I’ll need to make it 1:30 though— had a last minute schedule conflict with 1:00.  Let me know and I’ll see you then!

**Jeff Bergosh**: ?

**Jeff Bergosh**: LOL

**Jeff Bergosh**: 🙂

**Jeff Bergosh**: On way there running just a few minutes late sorry

### CONVERSATION ON 05-12-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/05/burn-ban-now.html?m=1




I've emailed the attorney and administrator requesting a burn ban

