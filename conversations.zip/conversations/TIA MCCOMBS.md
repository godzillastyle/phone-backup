

## CONVERSATIONS WITH TIA MCCOMBS

### CONVERSATION ON 10-19-2019

**Tia Mccombs**: Hey this is Tia  McCombs, Brian’s wife. We were sitting here talking and wondering if you had a few minutes to answer a question or two about schools. If it’s not a good time now maybe one afternoon next week.

**Tia Mccombs**: Hey this is Tia  McCombs, Brian’s wife. We were sitting here talking and wondering if you had a few minutes to answer a question or two about schools. If it’s not a good time now maybe one afternoon next week.

**Jeff Bergosh**: Hi Tia, I’m at a wedding right now but I can call you all after church tomorrow if that works-just let me know.

**Tia Mccombs**: Great thanks. Only need few mins. We get out of church at 12. 

### CONVERSATION ON 10-20-2019

**Jeff Bergosh**: Jeffbergosh@gmail.com

### CONVERSATION ON 07-09-2020

**Tia Mccombs**: Hey this is Tia McCombs. Brian and I need to get some advice from a real estate attorney. Who do you recommend? By the way your billboard looks great on 9 Mile. 😄

**Jeff Bergosh**: Hi Tia— I’m going to ask my brother to get me the names of some good RE attorneys that he has seen in court—I’ll forward the names to you all as soon as I get them.  

Thanks for the kind words about the billboards!  Hope they do the trick!

**Tia Mccombs**: You have our vote 🗳 

### CONVERSATION ON 07-11-2020

**Tia Mccombs**: Any word on real estate attorneys?

**Jeff Bergosh**: I’m going to get the names today when I see my brother

### CONVERSATION ON 07-13-2020

**Jeff Bergosh**: Hi Tia— I’m speaking with my brother he highly recommends Mr. Harper in the real estate law field.  Good luck!!

Jeff Bergosh 

**Tia Mccombs**: Thanks!  

**Jeff Bergosh**: 👍

**Tia Mccombs**: Anything we can do to make masks mandatory for kids returning to school?  Spoke to Wil Taylor principal Beulah Middle. Best they can do for desk spacing is 4 ft. with desk in semi circle. No masks required. But strongly encouraged, plan to talk it up to encourage students to wear masks. We plan to do remote learning option until CDC guidelines can be followed. Masks worn by all if under 6 ft apart. 

**Jeff Bergosh**: That’s gonna have to be a call that the school board makes. I think they’re really in a rough spot because they don’t have funding to do the appropriate social distancing on school buses and in some classroom settings in the district. I have a feeling a lot of parents will be opting for the distance learning. Frankly if my kids were in school I’d be looking seriously at that until we get this virus under control

**Tia Mccombs**: I’ll be open to helping solicit mass donations are helping coordinate mask making. To ensure all kids had masks. Is there anything a parent can do to help keep these kids safe? Many parents won’t have option to do remote options and those kids won’t be protected. So the principal can’t decide to make school mandatory masks? Who can I contact at school board to voice my opinion?

**Jeff Bergosh**: I would start with your school board member Kevin Adams I will forward you his contact information

**Tia Mccombs**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-18-2020

**Jeff Bergosh**: Thanks!!

**Tia Mccombs**: I’m a little confused I thought we were district 5.?!

**Jeff Bergosh**: Nope— District 1 😎👍

**Tia Mccombs**: Ok!

### CONVERSATION ON 05-04-2021

**Tia Mccombs**: Hey I’m looking for a CPA do you have any recommendations? Small business start up  questions

**Jeff Bergosh**: Hi Tia I recommend my friend Dan Roberts. He has been my CPA for the last 16 years and is an outstanding guy. I will forward you his contact number and he may just want to give him a call and chat.

**Tia Mccombs**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-18-2021

**Tia Mccombs**: Hey this is Tia give me a call I need to talk about Karen Sindell

### CONVERSATION ON 10-19-2021

**Tia Mccombs**: I finally spoke to Karen Sindell one on one today. She was respectful and apologetic. But, at board meeting, the rude tone was back.

**Jeff Bergosh**: https://www.healthandhopeclinic.org

### CONVERSATION ON 10-20-2021

**Jeff Bergosh**: 👍

