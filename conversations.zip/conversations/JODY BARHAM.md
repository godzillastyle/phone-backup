

## CONVERSATIONS WITH JODY BARHAM

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Hi Jody—I think it’s going incredibly well—I appreciate the words of encouragement. I think by 7 o’clock or 715 we will know exactly how it went.  As far as the ECUA goes I believe it will be Vicki Campbell

**Jeff Bergosh**: Thank you very much Jody I appreciate that vote of confidence😎👍

