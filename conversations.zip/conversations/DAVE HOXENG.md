

## CONVERSATIONS WITH DAVE HOXENG

### CONVERSATION ON 02-02-2021

**Jeff Bergosh**: Hi Dave-  I'm going to be doing the introduction/interview for the pace award with vivid bridge studio tomorrow-- can you send me a one or two pager with career, industry, and professional  highlights for you and Mary so I can do a proper introduction?  It will help a lot!  Thanks!

Jeffbergosh@gmail.com

**Jeff Bergosh**: Thx

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Thx

### CONVERSATION ON 11-17-2021

**Jeff Bergosh**: Dave-- thanks very much for the invite but I have a prior commitment that I can't get out of that same day and time.  Hope it goes well for you all!

