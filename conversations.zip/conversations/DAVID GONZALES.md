

## CONVERSATIONS WITH DAVID GONZALES

### CONVERSATION ON 11-09-2021

**Jeff Bergosh**: Thank you Larry— glad to help get that project over the starting line!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: The one that failed, the one Doug Underhill brought, would have.  The existing one we moved forward today doesn’t

**Jeff Bergosh**: Correct.  That was the one small revision to allow the city boundaries and precincts to sync up with the county’s District 2 and District 3 boundary

