

## CONVERSATIONS WITH MICHAEL CARRO

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Michael—-we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Michael Carro**: Jeff, you are very welcome and unfortunately, I am in Las Vegas at a conference until Wednesday and will not be there. Take photos and let me know how it goes. Michael

**Jeff Bergosh**: Sorry to hear that Michael—Have a safe trip and I’ll let you know how it went.  

### CONVERSATION ON 12-06-2019

**Michael Carro**: Good morning Jeff, I’m in Atlanta today but I understand that you were on base during the situation this morning. Do you have any insight and updates? Thank you Michael

**Jeff Bergosh**: Yeah Mike our annex on the base got locked down the entire base got locked down at about 10 till seven there was an active shooter we’ve gotten multiple victims the shooter is down upwards of 10 victims

**Jeff Bergosh**: Please keep them in your prayers

**Michael Carro**: Will do an Thank you 

### CONVERSATION ON 01-24-2020

**Jeff Bergosh**: Got it

**Michael Carro**: Thank you 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-26-2020

**Jeff Bergosh**: Are we having bible study tomorrow?

**Michael Carro**: Yes

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-05-2020

**Michael Carro**: I'm with a client. Can I call you back? 

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 09-17-2020

**Michael Carro**: Thank you Gary. Michael Carro 

### CONVERSATION ON 04-12-2021

**Jeff Bergosh**: Thx

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: I’m asking what staff believe it would cost to permit the adjacent parcel for overflow parking

**Michael Carro**: Thank you 

### CONVERSATION ON 09-23-2021

**Michael Carro**: Bright Bridges has a location at 2600 Strong St. and oddly enough half the building lies in the city and the other half lives in the county. They want to take homeless people off the street in the city is OK with the building but the county unfortunately is not. This can reduce homeless by 48 people and all are required to have jobs and they’ve got solutions and the money to take care of all this. I believe the county is saying they want a fire suppression system. They are willing to put that in, then the county came back also requiring a fire wall in the staircase. City has approved the fire rating of the door but the county rejected it. on their half of the building which is preventing 48 people from getting off the streets. Anything you can do to help would be of great assistance. Thank you Michael Carro

**Jeff Bergosh**: Thank you for bringing this to my attention Michael I will look into it and find out and I’ll touch base with you tomorrow

**Michael Carro**: Thank you 

### CONVERSATION ON 12-30-2021

**Jeff Bergosh**: Hello Michael— I hope you had a very merry Christmas and I’m wishing you in advance a happy new year. I am looking to invest some proceeds of a 1031 exchange into apartments in the Pensacola area and I’m wondering who you would refer me to for such a purchase? I know your specialty is the commercial real estate restaurant market but I’m wondering if someone in your office specializes in apartment complexes specifically? Please let me know and again happy holidays to you and your family Michael!

**Michael Carro**: Jeff, great to hear from you. How much is the 1031? Multifamily is in hot demand right now but deals under 20 units can still be found 

**Jeff Bergosh**: $750K

**Jeff Bergosh**: And what we’re looking for like everyone else more than likely our units that are currently under management not fixer-upper’s with a bit of a history and in a good neighborhood

**Michael Carro**: Do you already have a 1031 exchange intermediary

**Jeff Bergosh**: Got it.  Apparently I was off on the timing he is not going  be able to close it until January 20 —-there’s some things he’s got to fix in the escrow.  He does have a 1031 intermediary in La Mesa California that he’s working with— but he wants to speak with you.  I’ve given him your number and I’m going to forward you his information so you can connect. He will be in the office Monday —he’s down with a cold right now but he’s very interested in looking at what’s available here in Pensacola.  Thanks Michael and again— happy new year

**Michael Carro**: Sounds good, I’m in Phoenix returning Monday night and be back in the office Tuesday

**Jeff Bergosh**: Have a great trip Michael!

