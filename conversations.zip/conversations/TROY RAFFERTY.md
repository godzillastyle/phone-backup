

## CONVERSATIONS WITH TROY RAFFERTY

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: Troy— thank you so much for taking time to speak with me today! Greatly appreciate your consideration and anything you could do to help the clinic.  Have a great afternoon,

Jeff Bergosh

