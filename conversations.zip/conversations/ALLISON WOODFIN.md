

## CONVERSATIONS WITH ALLISON WOODFIN

### CONVERSATION ON 12-16-2019

**Allison Woodfin**: Hey Commissioner Bergosh, Karin is setting up the parking garage hangers for 2020. At your convenience if you’ll text me the make, model, tag #, state (assuming Florida), and year of all the vehicles you’d like to have a parking hanger for I’ll get those set up with Karin! Thanks! 

**Jeff Bergosh**: Will do

### CONVERSATION ON 12-17-2019

**Allison Woodfin**: I’ve got it down and will put the info on Karin’s desk for her to process it! 

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: Thx

### CONVERSATION ON 02-22-2020

**Allison Woodfin**: Debbie was just curious as to how close you were. That’s why I called

### CONVERSATION ON 03-11-2020

**Allison Woodfin**: Hey Commissioner Bergosh, Sharon and I were just wanting to make sure that you were still wanting to have your 4:30 weekly teleconference today. If so would you like for me to go down the hall and sit with Sharon and Janice, like Mrs. Debbie does?

**Jeff Bergosh**: Hey Allison no you don’t have to do that just have Sharon set up the call on Skype I believe and I’ll call in and you can call in remotely as well

**Jeff Bergosh**: And just forward me the number and the access code please which Sharon will provide you

**Allison Woodfin**: Sounds like a plan! I’ll email her asking for the number and code, and copy you on it.

**Allison Woodfin**: 8633335817 

Conf id 714060738

### CONVERSATION ON 03-12-2020

**Allison Woodfin**: Will you call me when you get a quick minute please? It’s nothing urgent just a quick Q&A session on some things 

### CONVERSATION ON 03-13-2020

**Allison Woodfin**: Perfect! I’ll get it to Karin Monday

**Allison Woodfin**: 👍🏻

### CONVERSATION ON 03-16-2020

**Allison Woodfin**: Hey, a man named John Horton has repeatedly called about Panhandling. He has talk to Debbie before and she has told him that he has to contact the governor, as his issue is that the sheriffs department will not do anything when the panhandler’s are harassing him in the parking lots of places such as Lowe’s. I told him today the same exact thing and he got very upset. He has made it clear that he would like to speak with you on it and pretty much will not be happy until he does. He is asking that you go to the governor on his behalf as he feels like him calling the governor will do nothing. His number is 356-7312. If you would like to contact him.

### CONVERSATION ON 03-17-2020

**Allison Woodfin**: Joe Meeks 572-2694 from live Oak plantation the wedding venue called wanting to know if he could speak to you regarding closing live oak due to the coronavirus. He wants you to give him a yes or no answer. 

Debbie told me to give you these points from the Governor’s Press Conference this morning: 
1. Restaurants can only be at 50% capacity with each person being 6 foot or more staggered
2. All restaurant employees will be screened for the coronavirus in case they have it or are a carrier
3. Bars and nightclubs will be closed for 30 days after today.

President Trump’s recommendation’s/ 15 day plan:
1. Avoid gatherings of 10 or more people
2. Avoid restaurant bars and food courts use the drive-through pick up or delivery methods

**Allison Woodfin**: Just calling to see if you ever spoke with Joe. And to discuss if what we should say/do if we receive anymore calls of such nature. 

**Jeff Bergosh**: Yes I spoke to Joe.  If you get any other calls like that just please shoot me a text with your number and I will call them sorry I couldn’t take your call I was in the middle of a press conference

**Allison Woodfin**: That is what I will do in the future. No worries, let me know if you need anything from me! 

**Jeff Bergosh**: Thank you Allison!

### CONVERSATION ON 03-19-2020

**Allison Woodfin**: Gay Nord - CEO of West Florida Healthcare 
850-494-4102

### CONVERSATION ON 03-20-2020

**Allison Woodfin**: Pizza is coming they wanted me to give you a heads up! 

**Jeff Bergosh**: Thanks Allison!

### CONVERSATION ON 06-23-2020

**Allison Woodfin**: Laura from CMR called asking for the Zoom codes to get in to download tomorrow’s coffee. David is out of town with very limited internet. You can call me at the office and I’ll pass the codes along, if you’d like

**Jeff Bergosh**: I’ll email them to you and her

**Jeff Bergosh**: Thanks Allison!

**Allison Woodfin**: Thank you! 

### CONVERSATION ON 07-01-2020

**Allison Woodfin**: Buddy Stromberg 206-5308 would like to have a few of your yard signs, I told him I’d have you give him a call!

**Jeff Bergosh**: Cool thanks! I’ll call him

### CONVERSATION ON 07-08-2020

**Allison Woodfin**: I will be there in 10mins. I’m in the WHataburger drive thru and I’m about to have to jump the curve I ordered at 5:41

**Jeff Bergosh**: Okay no problem

### CONVERSATION ON 07-15-2020

**Allison Woodfin**: Are you still wanting to have your weekly 4:30 today? I will confirm or cancel for you with all involved parties

**Jeff Bergosh**: Thanks Allison we went ahead and canceled it

**Allison Woodfin**: Perfect I’ll let legal know then! 

**Jeff Bergosh**: Thx

**Allison Woodfin**: Your book for in the morning is downstairs along with the copies we talked about earlier sitting in the front of the book. Sam will put any more add ons or backups on top of your book in the morning. So no need to head to the office to look for anything! It should all be down there, if not ask Sam. 

**Jeff Bergosh**: Thank you Allison!!

**Allison Woodfin**: It’s been a pleasure! Thank you for always being so gracious and grateful, it sets you apart from the others! Best employer/boss goes to you and Debbie, hands down! Please let me know if I can ever be of any help! 

**Jeff Bergosh**: Will do Allison!  Best of luck to you— and stay in touch with us!!

### CONVERSATION ON 12-03-2020

**Allison Woodfin**: Hi Commissioner Bergosh, I was wondering if you would be okay with me listing you as a reference (with this phone number) on my resume, for a Public Information Officer position with South Walton Fire District? I hope you are doing well, I miss being in the office with you and Debbie! 

**Jeff Bergosh**: Hi Allison!!  Absolutely use me as a reference , no problem!  We miss you too and hope all is well!

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: And thanks

**Allison Woodfin**: Hey Commissioner Bergosh! I hope you are well! I just wanted to give you a heads up that I used you as a reference once again, with Pen Air Federal Credit Union. In case they call you I didn’t want you to be caught off guard! 

**Jeff Bergosh**: Thanks for the heads up and no problem at all!! Good luck!

