

## CONVERSATIONS WITH KEITH HOSKINS

### CONVERSATION ON 01-03-2020

**Jeff Bergosh**: I didn’t get any advance notice of this————did you?

**Keith Hoskins**: Good morning Jeff.  I did not get notice.  Can I call you a bit later?

**Jeff Bergosh**: Yes

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Good afternoon Keith.  It was good to see you and the folks from NFCU at the symposium.  And I thought they did a great job with it as usual.  I wanted to touch base per our conversation and see if we can arrange good time to meet.  Looking forward to it!

Jeff Bergosh 

**Keith Hoskins**: Good evening Jeff.  Sorry for delay.  It was great seeing you as well at symposium.  Always a great event.  Are you available next Tuesday in the morning?  Appreciate you reaching out.  All the best.

### CONVERSATION ON 03-05-2020

**Jeff Bergosh**: Sure Tuesday morning works.  Just let me know what time is good and hopefully we can meet somewhere close to NAS if possible

**Keith Hoskins**: Thank you Jeff.  What is the earliest time you can meet? 

**Jeff Bergosh**: I’m typically at work by 6:15

**Jeff Bergosh**: So if we want to meet closer to the campus up in Beulah perhaps we could just meet early maybe at the Starbucks on Pine Forest Road?

**Keith Hoskins**: 6:00 at Starbucks?

**Jeff Bergosh**: Perfect.  See you then!

**Keith Hoskins**: Thank you 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-09-2020

**Keith Hoskins**: Good evening Jeff.  I’m sorry but I have to cancel tomorrow mornings meeting due to urgent matter.  Let’s try to reschedule in the next couple of weeks.  Thank you.

**Jeff Bergosh**: Hey Keith- no problem just let me know when.  Hope all is well

**Keith Hoskins**: Thank you for understanding Jeff.  So sorry.  

**Jeff Bergosh**: No worries at all!

### CONVERSATION ON 07-14-2020

**Keith Hoskins**: Good morning Jeff.  Are you available around 11:15 today for a call?

**Jeff Bergosh**: I am currently in the BCC budget workshop downtown which is slated to go all day.  Can I call you after?  At say 3:30 or so?

**Keith Hoskins**: That’s fine Jeff.  Want to discuss mask push again. 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Keith we actually finished early so we can talk at 11:15 if you would like.

**Keith Hoskins**: On a call.  Noon?

**Jeff Bergosh**: Sure Noon works great.   Talk to you then.

### CONVERSATION ON 09-11-2020

**Keith Hoskins**: Jeff are you available for a call at 9:30?  It is a matter of high importance.

