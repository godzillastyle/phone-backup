

## CONVERSATIONS WITH LEON SALTER

### CONVERSATION ON 01-10-2020

**Leon Salter**: This is Leon. Just wanted to be sure you received my email with the attachment. Thanks in advance. 

**Jeff Bergosh**: Hey Leon--No I haven't. Did you send it to district1@myescambia.com ?

**Leon Salter**: Yes sir. Its from popmedic1@att.net

**Jeff Bergosh**: Can u re-send?  Did not receive

**Leon Salter**: Yes sir

**Leon Salter**: I have resent the email. Attached is a copy as well.

**Jeff Bergosh**: Still not getting it... weird.  Let's try sending it to jeffbergosh@gmail.com

**Leon Salter**: Ok

**Leon Salter**: Forwarded it just now. 

### CONVERSATION ON 01-20-2020

**Leon Salter**: Good afternoon sir. Just following up with you to see if you have any new information since i emailed you that letter and we spoke. Thanks in advance. 

**Jeff Bergosh**: Hello Leon--I had a conversation with Janice on Friday afternoon and asked her about it and also about your pay for the position that you didn't receive.  I mentioned the CMR severance and asked Why are you were treated differently. She did tell me that Joy from CMR was sent home with work to do from home for her last 90 days on the job. But I expressed to her my great interest in seeing your 30 day pay being provided and also the differential that you should've earned for the temporary supervisor position that you held. I will speak again with her this Wednesday afternoon and I will again bring it up

**Leon Salter**: Thank you sir. 

**Jeff Bergosh**: No problem at all I'll keep you posted as I hear more

### CONVERSATION ON 02-05-2020

**Leon Salter**: Jeff this is leon. I was just checking to see if you had any update after speaking with Janice. Thanks in advance. 

**Jeff Bergosh**: Hi Leon--yes I have spoken to Janice about your case in particular and she assured me she would take another look at that.  I will again remind her today on my conference call with her at 4:30.  I hope all is well.

**Leon Salter**: Yes sir. Thank you for your time and effort. 

**Jeff Bergosh**: 👍

