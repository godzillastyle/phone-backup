

## CONVERSATIONS WITH VIC BINDI

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: Probably tonight at 6:00 Vic.  Thanks for coming down

**Jeff Bergosh**: Thanks Vic!

### CONVERSATION ON 03-22-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

