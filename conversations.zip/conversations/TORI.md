

## CONVERSATIONS WITH TORI

### CONVERSATION ON 10-19-2019

**Tori**: I have Tuesday off I’ll go in to the navy federal then

**Jeff Bergosh**: Call them today Tori

**Jeff Bergosh**: U don’t have to wait till Tuesday
Find out why they keep hitting u with that fee!!!!

**Tori**: I’m at work

**Tori**: I’m going to close my account with them. They aren’t necessary. 

**Jeff Bergosh**: I’d keep the savings account open Tori

### CONVERSATION ON 10-22-2019

**Jeff Bergosh**: Hey Tori we’re having a big party at McGuire’s from five until seven this afternoon. We’re going to have an open bar and appetizers. It’s for my reelection campaign :-). Anyway you’re welcome to come and if you get a ride down I’ll give you a ride back mom and I on the way home. Love you Tori!

**Tori**: Love you too! I’ll meet you guys down there (: 

### CONVERSATION ON 10-23-2019

**Jeff Bergosh**: LOL—enjoy the snow!!

**Tori**: Oh yikes 😂😂

### CONVERSATION ON 10-29-2019

**Jeff Bergosh**: Close it 

### CONVERSATION ON 10-30-2019

**Tori**: I will

### CONVERSATION ON 11-05-2019

**Tori**: Hey dad what’s your IPC number? 

**Jeff Bergosh**: Why Tori???

**Jeff Bergosh**: 294

**Tori**: Thank you (: 

**Tori**: Also can you tell mom for me when you see her that my patient saw her on TV yesterday and thought she did a very nice job ☺️

### CONVERSATION ON 11-06-2019

**Tori**: Someone just got BUSTED 😂😂😂💀

**Jeff Bergosh**: Use Pandora or something else for an hour

### CONVERSATION ON 11-10-2019

**Tori**: I’m at work. Mom and dad are probably at church- mom sings in choir. 

### CONVERSATION ON 11-11-2019

**Tori**: 😂😂😂

**Jeff Bergosh**: I rent space in this cartoonist’s head LOL

**Tori**: You pelt already wrong but I like it a lot 😂😂 This guy has too much time on his hand. 

**Tori**: Spelled * lol

**Jeff Bergosh**: What did I spell wrong?

**Tori**: Already in the cartoon 

### CONVERSATION ON 11-15-2019

**Tori**: Pensacola grand hotel? 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Room 1107

**Tori**: Alright says I’ll get there at 4:30

**Jeff Bergosh**: 👍

**Tori**: 4:34

**Jeff Bergosh**: Come up to the Room and drop off the champagne and then we’ll go

**Tori**: Perfect! 

**Jeff Bergosh**: Hurry

**Tori**: I am 😩 she is super slow 

### CONVERSATION ON 11-20-2019

**Tori**: Laughed at “Get off My Napster I’m on my lunch break trying to get a workout in I want to be able to listen to music y’all can have it back at 12:15”

**Tori**: Laughed at “I got off, chimp lol”

### CONVERSATION ON 11-25-2019

**Tori**: Alright clearly some people are jealous 😂😂😂

**Tori**: Aww thanks Nick (: 

### CONVERSATION ON 11-27-2019

**Tori**: Loved “Saint Nicholas phoned us last night before dark about 3:45 and we talked for an hour😁👏”

### CONVERSATION ON 11-28-2019

**Tori**: What we are missing this Christmas 😂😂😂

**Jeff Bergosh**: I need one of these—-where can I get one???

**Tori**: I think through auction they were saying 

**Jeff Bergosh**: Very funny

### CONVERSATION ON 11-30-2019

**Tori**: Hey let’s move it up to 1:30 please

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Just call me when all the boxes are packed and you need me to come help pick up

**Tori**: Ok I will! You may want to do grocery run first 

**Tori**: When you come by can you bring your bag of tools to take down the bed ? 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Running a little bit behind I ran into a former School board member at Walmart and we started talking

**Tori**: No worries I still have quite a bit to do 

**Jeff Bergosh**: 👍

**Tori**: Laughed at “Is Your family going to watch the Civil War game between the University of Oregon ducks and the Oregon State beavers today at 3 o’clock your time 1 o’clock our time today Saturday love you bye”

### CONVERSATION ON 12-01-2019

**Jeff Bergosh**: Hey Tori we’re cooking steak tonight for dinner I’ll make one for you so don’t spend money on food after work will see you when your done love you!

Dad

### CONVERSATION ON 12-06-2019

**Tori**: Hey are you ok?? I just heard about the shooting on NAS

**Jeff Bergosh**: I’m good Tori thanks for asking unfortunately the several people were shot and several people were killed so just keep them all in your prayers love you

**Tori**: Love you too! Where did that happen on base? 

**Jeff Bergosh**: Bldg 633 Schools Command

**Tori**: For flight personnel? 

**Jeff Bergosh**: Yes I believe so

### CONVERSATION ON 12-07-2019

**Tori**: What’s your size jacket like 40L or 38S? 

**Jeff Bergosh**: 42 R

**Tori**: Thank you (: 

### CONVERSATION ON 12-09-2019

**Jeff Bergosh**: Hey Tori we’re going to bed please be sure to lock the door when you go to bed after you get in tonight make sure it’s locked and set the alarm please love you

**Tori**: Ok I’m still at dance in Milton with patient. I will lock up when I get home 

### CONVERSATION ON 12-16-2019

**Tori**: Look mom you made the magazine again 💕

**Tori**: Yes ma’am 

**Tori**: They also got Gary and Carissa 

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: Ski mask time!

**Tori**: Disliked an image

**Tori**: Eww that looks absolutely awful 💕

**Tori**: Oh Nick I’m sorry 🥶 when are you heading back here? 

**Tori**: Oh nice! (: 

### CONVERSATION ON 12-19-2019

**Jeff Bergosh**: 2017 tax return address

**Tori**: Thank you (: 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-29-2019

**Jeff Bergosh**: R u at work Tori?

### CONVERSATION ON 12-30-2019

**Tori**: Can it please be later? I have work all day. 😢

**Tori**: 5!

**Jeff Bergosh**: Okay I’ll see if I can get a 5:30 time

**Tori**: Thank you

### CONVERSATION ON 01-02-2020

**Jeff Bergosh**: Tori call me it is about your car

**Jeff Bergosh**: After you get your car situated Tori go inside and ask for Mr. Neil Patel. He will be expecting you and I am on my way there

**Tori**: I’m inside I like the forte 

**Jeff Bergosh**: That may not be within the available budget... on way

**Tori**: It is it’s same price as soul and has better mileage plus there is a bonus back on this car

### CONVERSATION ON 01-03-2020

**Tori**: Just saw this that works, thank you 😘😋

### CONVERSATION ON 01-04-2020

**Jeff Bergosh**: Tori we’re at Beulah Park playing tennis grab a racket at the house and meet us over here :-)

**Tori**: Ooh I ended up going to the beach to meet up with some friends/: 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-05-2020

**Jeff Bergosh**: R u home Tori?

**Tori**: Coming home now

**Tori**: You made the paper! I’m sure you already saw haha

**Jeff Bergosh**: Yep!  Great stories and quotes for me in today’s PNJ

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 01-06-2020

**Tori**: Hey what kind of gas does my car take? 

**Jeff Bergosh**: Unleaded—you don’t have to put premium in there, just regular unleaded

**Jeff Bergosh**: $2.59 a gallon

**Tori**: Ok thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-07-2020

**Tori**: Yes

### CONVERSATION ON 01-08-2020

**Tori**: Please be respectful I have 15 mins left of class

### CONVERSATION ON 01-09-2020

**Tori**: Not going to make it! Enjoy the movie though

### CONVERSATION ON 01-11-2020

**Tori**: Hey have you already gone shopping? If not can you grab Honey Nut Cheerios 

**Jeff Bergosh**: Good timing

**Tori**: Thank you 😋😋💕💕

### CONVERSATION ON 01-29-2020

**Tori**: They are out so just grabbing a head of lettuce

### CONVERSATION ON 01-31-2020

**Tori**: Hey landed ok! Driving out of Denver to Breckinridge (: love you guys 

**Jeff Bergosh**: Love u too Tori!  Have fun and be safe!!

**Tori**: Yes sir! 

### CONVERSATION ON 02-01-2020

**Tori**: From last night and yesterday exploring Breckinridge. This town is straight out of a hallmark movie

**Tori**: Haha it really is though. I’m pretty bundled for today, we’re about to get brunch and then ski/snowboard all day 😊🥂⛷

**Tori**: What’s hot toddies? Haha

**Tori**: Huh 🤔 I’ll think on that haha 

**Tori**: Laughed at “Make sure to wear a mask on the plane back. Don’t want to get that corona virus ”

### CONVERSATION ON 02-02-2020

**Tori**: Hey dad may need to ask a pretty huge favor from you if I can? 

**Tori**: I’m going to end up missing this flight out and I may need to borrow from you to rearrange a different flight out of Denver 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: What happened??

**Tori**: No it’s fine I’m sorry I actually was put on standby for the next flight. 

**Tori**: I’m on the plane now. And on the drive over there was a wreck and we were 2 hours away basically so it was just a mess of a morning getting here lol

**Jeff Bergosh**: OK glad you made it to the airport glad you’re on the plane are you still making it to Pensacola today?

**Tori**: Yeah I’m pretty fortunate that I can make the second flight still so we should be good 

**Jeff Bergosh**: Okay that’s great Tori

**Jeff Bergosh**: Have a safe flight love u

**Tori**: Yeah sorry I meant to text you when I knew I’d make it but I have been sprinting to get here 

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Tori**: Very good dad! How did you find the people to poll? 

**Jeff Bergosh**: I have a company that I use out of Orlando and they acquire the lists from publicly available databases and conduct the surveys

**Jeff Bergosh**: I’ve used them in previous campaigns 

**Tori**: Is it over the phone or through social media? 

**Jeff Bergosh**: Over the phone IVR

**Jeff Bergosh**: Interactive voice response

**Tori**: Oh ok that’s pretty neat! 

### CONVERSATION ON 02-26-2020

**Tori**: Safe from what?? 

**Tori**: Oh my gosh where in Milwaukee was that?? 

**Tori**: Very glad you are safe nick! Much love 💕 

**Tori**: Oh my gosh that’s really scary 😳😅 how many people affected? 

**Tori**: Oh my gosh! Are they saying why?? 

**Tori**: Dang that’s crazy 

### CONVERSATION ON 03-03-2020

**Tori**: Loved “Classic!! We get to see Nicky next week for Spring Break- woohoo!!”

### CONVERSATION ON 03-07-2020

**Tori**: Laughed at an image

### CONVERSATION ON 03-08-2020

**Tori**: Loved an image

**Tori**: That looks pretty nice! 

### CONVERSATION ON 03-09-2020

**Tori**: Loved “You’ll have to come up next time, Tori. ”

**Tori**: I’m hoping so! 

**Jeff Bergosh**: Who’s on my Napster?? I’m trying to join music during my lunch break walk

**Jeff Bergosh**: Coronavirus scare

**Tori**: When do you get in? 

**Jeff Bergosh**: Cold snob!

**Tori**: Lol

### CONVERSATION ON 03-10-2020

**Tori**: Oh nice! I just got off for the day (: 

### CONVERSATION ON 03-21-2020

**Jeff Bergosh**: Hey we’re going to bed and we set the alarm... if you get off before 7:00 in the morning call me and I’ll unchain the door and turn off the alarm

**Tori**: Ok I will. 

### CONVERSATION ON 03-25-2020

**Tori**: Hey don’t put the alarm on. The lady overslept and should be relieving me around 10

**Tori**: I was going to originally but they were able to finally get ahold of her. 

### CONVERSATION ON 03-30-2020

**Tori**: Laughed at “& nope just trying to “contribute” to the family cuz apparently i’m a POS :)”

### CONVERSATION ON 04-08-2020

**Jeff Bergosh**: Hey Brandon and Tori— I’m bringing a special dinner home for Mom’s birthday!  I’ll be walking in the door right at 6:00 with the food 😎

**Tori**: Oh very nice! Thanks dad (: 

**Tori**: I’m at work you guys 😅

### CONVERSATION ON 04-11-2020

**Tori**: Can you pretty please get me Aloe Water 😋 when you are at the store. It should be in the Hispanic section 

**Jeff Bergosh**: K

### CONVERSATION ON 04-13-2020

**Jeff Bergosh**: Looks like you are getting an IRS Stimulus Check for 1,200 dollars on Wednesday 🙂👍

**Tori**: Thank god 👏🏼

**Tori**: Is that going to navy fed though? I thought I closed those accounts down 

**Jeff Bergosh**: No it’s still open

**Tori**: 😂😂

### CONVERSATION ON 04-14-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-18-2020

**Tori**: 😬😳😳

### CONVERSATION ON 04-21-2020

**Tori**: Hey what’s my account number and routing number for navy federal? 

**Tori**: Trying to get with my pay online need info ASAP 

**Jeff Bergosh**: Routing

256074974

Checking

7030055524

**Tori**: Thank you I appreciate it! 

**Tori**: I’m going to pick up the one for home instead today after car is finished being serviced and I was able to get mypay info set up so I can print off my w2 today

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Awesome— now we can do your taxes!

**Tori**: Finally 🙃 what a nightmare. And I guess Home Instead sent them to my downtown address so no wonder I never got that 

### CONVERSATION ON 04-27-2020

**Tori**: 😂

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Are u at home?

**Tori**: No sir I’m at work. Why? 

**Jeff Bergosh**: No prob just seeing if you could grab a package for me.  I’ll get Brandon to do it

**Tori**: Alright sorry! Brandon should be home though he hasn’t left the house in like months 

**Jeff Bergosh**: 👍

**Tori**: Just got off if you need help lmk

**Jeff Bergosh**: Mom got it— thanks though Tori!!

### CONVERSATION ON 05-01-2020

**Jeff Bergosh**: R u working rn?

**Tori**: Just got off

**Jeff Bergosh**: Okay just checking on you— There was a real bad wreck in Cantonment and several people died

### CONVERSATION ON 05-05-2020

**Jeff Bergosh**: Outstanding!! Awesome.  So I’ll start my diet Wednesday LOL

**Tori**: Loved “In honor of Cinco De Mayo, Taco Tuesday And Corona Virus reprieve......I’m bringing home Taco’s for the family & a gallon of margaritas! My pick up time is 6:30 pm so dinner will be served at 7!”

**Tori**: Thanks mom 😋💕

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: Got my latest poll numbers back today.  😎👍

**Tori**: Liked an image

### CONVERSATION ON 05-23-2020

**Tori**: Booo ok that’s fine thanks for looking. Did they have the Yasso bars? 

**Jeff Bergosh**: Yes

### CONVERSATION ON 05-24-2020

**Jeff Bergosh**: Tori--are u coming home?  Don't u work 7-7 tomorrow?   Anyway don't drink and drive--call us if u need a ride or take an Uber,  let us know though

**Tori**: Yeah I work 7-7 but ended up drinking so staying here will come home in the morning before work 

**Jeff Bergosh**: Okay love you 

### CONVERSATION ON 05-29-2020

**Jeff Bergosh**: Hey Tori remember I need to make your car payment for the month—

**Tori**: Yes the bank was backed up but I have cash in my room I’ll just give you later today when I get off

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-18-2020

**Tori**: Tonight?

**Tori**: Aww ok 

**Tori**: I was thinking you would make it tomorrow or Saturday night since we all work Sunday

### CONVERSATION ON 06-21-2020

**Tori**: Happy Father’s Day 💕

**Jeff Bergosh**: Thank you Tori!! Love u!

**Tori**: Love you too (: 

**Jeff Bergosh**: Hey tori we are bribing you a dinner home don’t waste money on food!

**Tori**: Bribing me haha 😂 thanks dad 

### CONVERSATION ON 06-22-2020

**Tori**: Loved an image

### CONVERSATION ON 06-27-2020

**Jeff Bergosh**: Hey all—I just wanted to report that Grant Bridges called me today and we spoke at length. He apologized profusely and I accepted his apology. He took responsibility for what he said and told me he felt remorseful. Furthermore, he took down the post and told me he felt really badly and that he had made a mistake. I just wanted you all to have that data point and know that he in fact realized what he did was wrong.

**Tori**: Loved “Hey all—I just wanted to report that Grant Bridges called me today and we spoke at length. He apologized profusely and I accepted his apology. He took responsibility for what he said and told me he felt remorseful. Furthermore, he took down the post and told me he felt really badly and that he had made a mistake. I just wanted you all to have that data point and know that he in fact realized what he did was wrong.”

### CONVERSATION ON 07-04-2020

**Jeff Bergosh**: What’s Brandon’s status

**Tori**: He is fine they will release him in a couple of minutes. The nurse just wants to make sure he is good enough to be on his own 

**Jeff Bergosh**: Okay is he awake now and talking?

**Tori**: Yeah 

**Tori**: You want to talk to him? 

**Jeff Bergosh**: Not sleeping and twitching?

**Tori**: No more twitching 

**Jeff Bergosh**: And gasping for air

**Tori**: No he is good 

**Jeff Bergosh**: His mouth was open and he was gasping like a fish on the dock

**Jeff Bergosh**: Gasping for air

**Tori**: No that isn’t happening anymore 

**Tori**: He went and used the restroom and is doing alright 

**Jeff Bergosh**: Twitchmeister

**Tori**: Lol

**Jeff Bergosh**: ‘Twitch

**Jeff Bergosh**: We r out in the parking lot watching the fireworks

**Tori**: Ok well I talked to the desk he is good to go we will fill out what is needed and then he can go 

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: 🙏

**Tori**: Good I hope you test negative nick and stay safe 💕

### CONVERSATION ON 07-18-2020

**Tori**: Hey told work Aug 28-31 is that what we are thinking for visiting nick?

**Jeff Bergosh**: Maybe a few days before and after

**Jeff Bergosh**: What day is Labor Day this year?

**Tori**: September 7th

**Tori**: And ok 

**Jeff Bergosh**: Not sure yet but it looks like it will be before Labor Day

**Jeff Bergosh**: It all revolves around Nick’s schedule but we finalize the itinerary this week more than likely 

**Tori**: Ok perfect 👌🏼 thanks 

### CONVERSATION ON 07-19-2020

**Tori**: Loved “I took the political compass test”

**Tori**: Republican lol 

**Tori**: It shows he is on the right side

### CONVERSATION ON 07-23-2020

**Tori**: I can’t wait 😊 

### CONVERSATION ON 07-24-2020

**Tori**: Hey did you mean the 20th-24th of August?

**Jeff Bergosh**: Yes

**Tori**: Ok I’ll tell work 

**Jeff Bergosh**: We may, potentially, leave in the afternoon of Wednesday the 19th so try not to work late on the 19th

**Tori**: Ok I’ll just tell them the 19th haha 

**Jeff Bergosh**: LOL

### CONVERSATION ON 07-26-2020

**Jeff Bergosh**: Hey Tori we’re going to bed.  We left you your steak in the fridge.  Love you!

**Tori**: Love you too just now getting off and heading home 

### CONVERSATION ON 07-31-2020

**Tori**: They are going to look at it but if it’s just a repair where the nail is then it’s only 22.50 

**Jeff Bergosh**: Okay great.  If u just go ahead and pay it— just take it out of the $220 you’re giving me later.

**Jeff Bergosh**: Does that work?

**Tori**: Yeah that’s perfect 

**Jeff Bergosh**: 👍

**Tori**: Because of the position of the nail in the tire I guess they have to replace the whole tire /: 

**Jeff Bergosh**: Really??

**Jeff Bergosh**: What’s the cost on that?? Or do u have roadside warranty with the lease??

**Tori**: Yeah I guess it hit the drywall or something like that. 😩

**Tori**: We didn’t purchase it and I’m about to find out. They are quoting it now

**Jeff Bergosh**: Okay let me know

**Tori**: 103.78 so I’m just going to take that out of what I owe you so I’ll give you 120. 

**Jeff Bergosh**: Okay perfect.  Thx Tori!!

**Tori**: No prob!

**Jeff Bergosh**: Hey Tori while you’re there you might just double check to make sure you’re not due for a oil change or some other service it’s been a few months you should check that before you leave since you’re there anyway

**Tori**: I still have close to 2000 miles left before I need oil changed. I’m getting the software looked at for free as apart of our warranty because apparently there was a recall on that. 

**Jeff Bergosh**: Okay cool

### CONVERSATION ON 08-01-2020

**Tori**: Wow that’s nice Kelsey went to go visit you! Looks nice out

**Tori**: Looks really nice! (: very jealous haha 

**Tori**: That would be pretty sweet! I’ve never been!

### CONVERSATION ON 08-02-2020

**Tori**: Loved “Hey, family!! Your last chance to support your dad before Election Day will be on Saturday, August 15, 11-2 pm in front of KFC on Michigan & Mobile HWY. please invite friends to participate. We will supply tshirts, cold drinks & lunch for everyone that joins us to wave signs that day!!”

### CONVERSATION ON 08-04-2020

**Tori**: Hey you said we have 1700 right? I’m about to call the company 


**Jeff Bergosh**: Yep

**Jeff Bergosh**: $1700

**Tori**: Apparently that is the lowest they can go. He said I can do the 1700 as a down payment and they can split the remaining 203.87 into monthly payments 

**Jeff Bergosh**: OK here’s how you play it you tell them OK will do this need about a week to get it all together and we will pay the whole thing off

**Jeff Bergosh**: What’s the grand total like 1900 something

**Tori**: Yeah 1903.87

**Jeff Bergosh**: OK you call them back and say will do it in a week or two but we can do it today if you’ll take 1800 to pay off the whole thing

**Tori**: I said I’ll have to try and figure something out thanks. 

**Jeff Bergosh**: Just call him back and say listen will do it in two weeks or so or we can do it today for 1800

**Tori**: They said they can’t go any lower and that amount is absolute 

**Jeff Bergosh**: The’ll work with u

**Jeff Bergosh**: That’s their standard bullshit line you’ve seen they’ve already gone lower

**Tori**: It’s already 45% reduction from the balance 

**Jeff Bergosh**: Just trust me on this call him back and say I can scrape together 1800 bucks to get it settled today ask your manager

**Jeff Bergosh**: They’ll do it

**Tori**: I’m just going to wait them out we have until August 16

**Jeff Bergosh**: Yeah and on August 17 they’ll lower it again LOL

**Tori**: Yeah they have recorded conversation showing them I would go to 1700 so I’ll wait them out 

**Jeff Bergosh**: 👍👌

**Tori**: Liked “👍👌”

**Jeff Bergosh**: One way or the other— this is on a path to being settled within 30 days from now

**Jeff Bergosh**: And the longer u make them wait, the less they’ll take to settle it

**Tori**: Definitely happy with that

**Jeff Bergosh**: 👍

**Tori**: Those revenue companies are all losing money right now, I’m sure they will budge 

**Tori**: You’re doing great! 👏🏼👏🏼

**Jeff Bergosh**: Thank you

**Jeff Bergosh**: Are u here

**Tori**: So here’s the real question, why is this guy running against you if he agrees with everything you say?! Lol 

### CONVERSATION ON 08-05-2020

**Jeff Bergosh**: On the other line on a conference

**Tori**: So I was stuck walking holding izzys poop and I ended up leaving it in the Owens supporters front yard lmao 😂 

**Jeff Bergosh**: LOL

### CONVERSATION ON 08-06-2020

**Tori**: Would it be so terrible if I posted this on that voters group by Willie? 

**Tori**: I see a lot of misinformation being spread around and I would like to invite all individuals who will be voting in Escambia County to take the time and research all candidates and make an informed decision. Look at the minutes that are public record. Look at the facts and use critical thinking to form your own decision. Listen in on a debate. 

Major misconceptions that are being spread by competitors are appalling. Don’t let people make decisions for you, make them for yourselves. 

https://www.wuwf.org/post/mask-debate-continues-between-pensacola-escambia-county#stream/0 

https://www.escambiaclerk.com/AgendaCenter/ViewFile/Minutes/_02062020-117

### CONVERSATION ON 08-08-2020

**Jeff Bergosh**: Hey before I went to Wal Mart I took Izzy out and she did her business both #1 and #2.  She is in the guest room.

**Tori**: Ok perfect thanks 😊 and also they are getting back today around 5

### CONVERSATION ON 08-09-2020

**Tori**: Yeah I’m missing him I’m still at work 

**Tori**: She had BM so it’s been a night after a long day lol I’m heading home now

### CONVERSATION ON 08-14-2020

**Tori**: Went out and voted for dad today 💕

**Jeff Bergosh**: 👍👍thanks Tori!!

**Tori**: Loved “👍👍thanks Tori!!”

### CONVERSATION ON 08-15-2020

**Tori**: Can you not be so loud I’m trying to sleep

### CONVERSATION ON 08-17-2020

**Tori**: Wow I haven’t received one of those yet. Good idea on his part though 

**Tori**: Loved “Mine goes out tomorrow morning!”

**Tori**: Hey forgot to tell you last night but the Kwasin’s saw your advertisement and said it looked very nice. Chuck said he liked your smile lol 😂 

**Jeff Bergosh**: Thanks Tori 

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 08-18-2020

**Tori**: Loved an image

**Tori**: Sorry Nick dad was freaking out lol 

**Tori**: Loved “Congrats, DAD!!”

**Tori**: Just got off heading home now! 

### CONVERSATION ON 08-20-2020

**Tori**: I’d love that! What’s the name of it? 

**Tori**: Ok sweet! We’ll come see you when we get into town 😋

**Tori**: It’s saying we’ll get there at 4:30PM so probably around 6

**Tori**: Ok good deal 

**Tori**: Lol I was going to say the hours said they don’t open till 3

### CONVERSATION ON 08-21-2020

**Tori**: Delete that pic dad I look fat as hell

**Jeff Bergosh**: I will

**Jeff Bergosh**: 👍

**Tori**: Nick and mom catch of the day 💕

### CONVERSATION ON 08-22-2020

**Jeff Bergosh**: ??

**Tori**: Sorry just saw this I finished my taco, nick said he can take me back. Thank you though (: 

### CONVERSATION ON 08-26-2020

**Tori**: Can one of you please bring home food. I’m starving and we have nothing healthy 

**Tori**: Ok thanks 

**Tori**: At least one of you loves me 🙄

### CONVERSATION ON 08-30-2020

**Jeff Bergosh**: Remember to wake up

**Tori**: I’m up thank you

### CONVERSATION ON 09-07-2020

**Tori**: Hey are you guys grilling steaks at the house after?

**Jeff Bergosh**: Sorry Tori- we’re doing that tomorrow.  Today we went out boating and it ran late

**Tori**: All good 

**Tori**: Also I was mad at you and mom for not answering so I used your IPC membership privileges at Crabs on The Beach since they are dog friendly 

**Tori**: 😅😅💕 sorry and thanks 

### CONVERSATION ON 09-08-2020

**Jeff Bergosh**: Hi Tori I’m in a meeting are u okay?

**Tori**: Yeah it’s fine! 

**Jeff Bergosh**: Okay.  Mom is here too!

**Jeff Bergosh**: Looks like Steaks tomorrow night!

**Tori**: Ok

### CONVERSATION ON 09-12-2020

**Tori**: Hey mom wanted to make sure she has money

**Tori**: Hey also ribeyes at publix are $6.99 a pound. My patient reminded me to tell you

**Jeff Bergosh**: Thanks Tori! Maybe I’ll go get some for Sunday dinner

**Tori**: No problem! (:

### CONVERSATION ON 09-14-2020

**Tori**: Liked “Are you guys going to be okay with that hurricane coming in? ”

**Tori**: Yeah we should be fine

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: We are okay— I’ll send some pictures

**Tori**: Yeah there’s a huge tree down across the street but so far so good over here

**Tori**: Emphasized “https://www.facebook.com/1620723319/posts/10221732769541406/?d=n”

**Tori**: That’s ridiculous 

**Tori**: Is that Milwaukee?!

**Tori**: Emphasized “The video from Facebook is the marina by Jacos... it’s gone ”

**Tori**: Oh jeez that’s wild 😬 is Kelsey ok?

### CONVERSATION ON 09-18-2020

**Tori**: I’m sorry B /: 

**Tori**: That’s really sad /:

### CONVERSATION ON 09-22-2020

**Jeff Bergosh**: In a meeting-- everything okay?

**Tori**: Hey nvm disregard that message 

**Tori**: Yeah tree people just finished up taking those down 

**Jeff Bergosh**: Just the one big one right?

**Jeff Bergosh**: And did they haul it out to the street?

**Tori**: Yeah the one with the roots showing and I guess this other small one that was in the back. And yeah they took care of it

**Jeff Bergosh**: Outstanding!  Okay thanks for letting me know

**Tori**: No problem 

### CONVERSATION ON 09-23-2020

**Tori**: Hey I’m going to give them your info for billing. It’s just an oil change and tire rotation 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Have them call me and I’ll pay them

**Tori**: Thanks dad (: 

**Jeff Bergosh**: Okay

### CONVERSATION ON 09-29-2020

**Tori**: I’ve had to speak with the priest after my friend committed suicide. We weren’t that close but it’s normal to talk to someone and get help after losing someone. Don’t be embarrassed it’s natural to feel this way B

**Tori**: Loved “Your dad & I just left our jobs & will be taking him to Baptist Hospital for evaluation- ”

**Tori**: How did everything go? 

**Jeff Bergosh**: We’re at Baptist Hispital

**Jeff Bergosh**: *Hospital

**Tori**: Can you let me know how it goes? I thought they were meeting at Brandon’s apartment at 3?

**Jeff Bergosh**: Mom is in the back room with him.  I’m waiting outside because it’s one at a time.  I’m waiting for an update

**Tori**: Ok thank you 

**Tori**: What’s going on? Is it because he’s older than 18? I’m surprised they aren’t baker acting him

**Tori**: Oh hell ): 

**Tori**: I love you guys I’m glad we caught this early and Brandon is getting help. 

### CONVERSATION ON 09-30-2020

**Tori**: Loved “I told him to call me when he’s released and I’ll get him.  I told him how much we love him and how concerned we are about him”

**Tori**: Loved “Brandon just called me.  He sounded much better and had very little memory of the previous 48 hrs.”

### CONVERSATION ON 10-01-2020

**Jeff Bergosh**: The bug guys are there

**Tori**: Yes and yeah they gave me a receipt. Sorry I left my phone in the charger

**Tori**: Questioned “?!!?”

**Tori**: What’s going on 

**Tori**: Liked “He’s still there, sounded alright. Went to talk to a doctor and told me he’d call me after. ”

### CONVERSATION ON 10-05-2020

**Tori**: Did you call me? 

**Jeff Bergosh**: Yes—I’m at the house and we are looking for Brandon’s wallet—have you seen it?

**Tori**: No sir 

**Tori**: Have him check mom’s car to be sure 

**Tori**: Congrats Nick 👏🏼👏🏼💕

### CONVERSATION ON 10-06-2020

**Tori**: Natürlich 👏🏼💪🏼

**Tori**: Means of course haha 

**Tori**: Laughed at “What?”

**Tori**: Laughed at “Dah”

### CONVERSATION ON 10-10-2020

**Jeff Bergosh**: I’m leaving the clinic headed home and I’m stopping at McDonalds.  Do u want me to bring you anything?

**Tori**: Hash brown and strawberry banana smoothie please (: thanks dad!

**Jeff Bergosh**: Ok no prob

### CONVERSATION ON 10-12-2020

**Tori**: Godzilla the original is on right now on TCM lol

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Maybe I’ll watch it if I get bored of the Senate Hearing LOL

**Tori**: Lol alright 😂

### CONVERSATION ON 10-14-2020

**Jeff Bergosh**: Hey Tori— can we meet at UWF for tennis at 5:00 instead of Beulah park?  I think Brandon wants to play as well but he prefers to play at UWF as it’s closer to his apartment

**Tori**: Ok I can try! It’s going to depend on my patient load and what’s going on with Kwasin. I’ll bring my stuff with me at work

**Jeff Bergosh**: Okay perfect.  Just let me know.  And I’ll let Brandon know.

**Tori**: Ok got it cleared with work heading to Kwasin now and I’ll see you guys at uwf around 5

**Jeff Bergosh**: Right on Tori— see you then!

### CONVERSATION ON 10-20-2020

**Jeff Bergosh**: Tori— great news today when I did my annual benefits enrollment—-I found out you will be covered for the full year you turn 26 under our health plan— meaning you are covered through December 31st 2021😎👍

**Tori**: Oh perfect! I also put feelers out for jobs through sacred heart and West Florida so I should have better options by then 

**Jeff Bergosh**: 👍

**Tori**: Loved “Tori— great news today when I did my annual benefits enrollment—-I found out you will be covered for the full year you turn 26 under our health plan— meaning you are covered through December 31st 2021😎👍”

### CONVERSATION ON 10-21-2020

**Tori**: Just now heading home 

**Tori**: How long are you guys staying out there for?

### CONVERSATION ON 10-26-2020

**Tori**: Hey when are we leaving for SD? Is it the 21st or 15th?

**Jeff Bergosh**: Leaving 21st of December coming back on the 5th of January

**Tori**: Alright thanks 😊 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-28-2020

**Jeff Bergosh**: Steak dinner tonight right at 6:00.  Brandon’s coming too, and he’ll eat with us before church at Marcus Pointe

**Tori**: Loved “Steak dinner tonight right at 6:00.  Brandon’s coming too, and he’ll eat with us before church at Marcus Pointe”

### CONVERSATION ON 10-31-2020

**Tori**: 😩😩😩

**Tori**: Not him too ):

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Don’t get a sunburn!

**Tori**: Emphasized an image

**Tori**: In Milwaukee?!?! That’s crazy!

**Tori**: That’s pretty cool B!!

**Jeff Bergosh**: Congratulations Michelle!!!  From the Bergosh family!!

**Tori**: Loved an image

### CONVERSATION ON 11-07-2020

**Jeff Bergosh**: Tori are you all good- taking Uber home?

**Tori**: I will be yes 

**Tori**: I’m downtown 

**Jeff Bergosh**: Okay be safe.  Love u!

**Jeff Bergosh**: Are you still with Jordyn?

**Tori**: Yes 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-09-2020

**Tori**: Alright guys nobody eat the cheesecake in the fridge it’s for a going away party tomorrow for a coworker. Thank you (:

**Jeff Bergosh**: Ok—we won’t 👍

### CONVERSATION ON 11-30-2020

**Tori**: At work rn

**Jeff Bergosh**: Ok

**Tori**: I get off at 9pm

**Jeff Bergosh**: Just checking to make sure you’re alright

**Jeff Bergosh**: Love you

**Tori**: Love you too. And all good thought I text mom back 

### CONVERSATION ON 12-04-2020

**Jeff Bergosh**: Tori- We’re locking up the house and setting the alarm. We’re assuming you are working overnight?

**Tori**: Yes thought mom or Brandon would pass that on. I get off at 6:30 am

**Jeff Bergosh**: Hey Tori are u working?

**Tori**: Yeah I get off at 9

### CONVERSATION ON 12-05-2020

**Tori**: Hey can you please grab me the crest revitalized whitening toothpaste and gorgeous hair, skin,and nails gummies

**Jeff Bergosh**: Yep😎

**Tori**: Thank you 😊 

### CONVERSATION ON 12-06-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-07-2020

**Jeff Bergosh**: Hey Tori we’re going to bed so just go ahead and lock up and set the alarm when you come home we love you!

**Tori**: Love you too! And alright I will 

**Tori**: Emphasized an image

**Tori**: Here comes winter haha 🥶 

### CONVERSATION ON 12-12-2020

**Tori**: You made the paper today

**Jeff Bergosh**: Yep

**Jeff Bergosh**: And tomorrow too.... but Tomorrow’s editorial will not be quite so nice LOL

**Tori**: Hahaha :P sorry dad 

**Jeff Bergosh**: Sold out of the cappuccino and mocha sorry😑

### CONVERSATION ON 12-13-2020

**Tori**: Yeah today’s news article on you and the OLF8 project was not nice 😂 whoever wrote it was such a coward, they never even left who wrote it 😂😬

**Tori**: That is terrible 😯😯 

### CONVERSATION ON 12-15-2020

**Tori**: Hey what was Cameron’s last name? Brandon’s friend 

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: Newton

**Tori**: Loved “Make sure you guys lock your cars each night because we’ve got vehicle thieves in Bell Ridge forest according to Cindy Barrington’s email that I sent you a screenshot of always lock cars all the time”

**Tori**: Laughed at “B & I will catch them because we are up at night standing guard!! Lol😂”

### CONVERSATION ON 12-20-2020

**Jeff Bergosh**: Go online and check in for your flight—- it’s exactly 24 hours away from rn

**Tori**: Ok send me the info so I can complete check in

**Jeff Bergosh**: Tori— I went ahead and checked you in and printed your boarding pass you are good to go!  Love you!

**Tori**: Loved “Tori— I went ahead and checked you in and printed your boarding pass you are good to go!  Love you!”

**Tori**: Thank you ☺️ 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Tori we are ordering you a French 75 to get started

### CONVERSATION ON 12-21-2020

**Tori**: Loved “I’m landing in San Diego soon ”

**Tori**: This airline stewardess sucks lmao 😂 she was like do you need help with your bag? And then just stood and watched me before finally helping . 

**Jeff Bergosh**: Did u get it stowed above?

**Tori**: Yes finally 

### CONVERSATION ON 12-22-2020

**Jeff Bergosh**: I am placing an order at La Posta de Acapulco for burritos do you guys want me to get something for you?

**Tori**: Rolled tacos all the way please 

**Jeff Bergosh**: Okay

**Tori**: Can you get mom a soft grilled chicken taco?

### CONVERSATION ON 12-24-2020

**Tori**: Thanks 😊 

### CONVERSATION ON 12-26-2020

**Tori**: Hey just finished at Tiffany’s 

**Jeff Bergosh**: Okay head over to Bloomingdales

**Jeff Bergosh**: I’m looking for something for mom

**Tori**: Ok I might look at Swarovski real quick then head that way! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-29-2020

**Tori**: Very nice job Nick!!

### CONVERSATION ON 01-04-2021

**Tori**: Hey just got to my gate. It was like one of the first ones. Thanks for the ride to the airport! (: love ya!

**Jeff Bergosh**: Love you too!!  Have a safe flight!

**Tori**: Loved “Love you too!!  Have a safe flight!”

**Tori**: Just logged in and it looks normal until you go to type in a search. I’m running a diagnostic on the network right now 

**Jeff Bergosh**: Thanks Tori it just looks like I’ll have to fix this when I get there tomorrow thanks for trying though I appreciate it

**Tori**: No problem. Love ya dad. See you guys when you get back (: 

**Tori**: Guess who just got her official offer letter for the ER?! 👏🏼👏🏼🥰

**Jeff Bergosh**: Are you serious??!!  That’s awesome!!!!!!!!!!

**Jeff Bergosh**: Congratulations!!!!!!

**Tori**: Thank you 😊 I’m so excited to get out of home health work 💕😍🥰

**Jeff Bergosh**: ——that’s awesome.  Is it full time Tori?

**Jeff Bergosh**: Also—- I’d keep a relationship with NurseSpring so you can get extra side work and supplement your income.... just sayin

**Tori**: I’m keeping NurseSpring for irc and stuff. Just cutting back or getting rid of Kwasins. And yeah it’s full time (: with benefits 👏🏼👏🏼

**Jeff Bergosh**: That’s awesome and a smart decision!  Also— I just put $50 into your NFCU Checking account for your UBER ride from the airport in Pensacola.👍👌😁

**Tori**: Thanks dad I appreciate it (: 

**Tori**: West Florida (: 

**Tori**: Thanks 🥰

**Jeff Bergosh**: Uncle Gary is in court all day today doing jury selection and violation of probations.  Plus— I don’t want him seeing our home construction project... I’d prefer to unveil that once it’s completed 😎👍

**Tori**: My flight out of Dallas is so delayed that instead of arriving at 4:30 pm to Pensacola I am now leaving Dallas at 4:53 pm 😩😩

**Tori**: Lol it’s moved again not leaving until 5:30 now 😬

**Tori**: Yup at least they have a spa open here 😬😂💕👌🏼

### CONVERSATION ON 01-06-2021

**Tori**: Hey money came through today so I’ll be able to take cash out and pay you tonight

**Jeff Bergosh**: For what?

**Tori**: The car insurance and payment 

**Jeff Bergosh**: Oh- thanks Tori!

### CONVERSATION ON 01-08-2021

**Tori**: Hey is there a $600 deposit in my account?

**Jeff Bergosh**: I didn’t see one, why?

**Tori**: One of my patients received it by Mail just wanted to check and see if one is or had come in yet 

**Jeff Bergosh**: No I haven’t seen one yet.  Do you think you’ll be getting a stimulus check?

**Tori**: I think so since I did earlier this year. 

**Jeff Bergosh**: 👍

**Tori**: Liked “👍”

**Jeff Bergosh**: Guess what came in today’s mail for u Tori?

**Tori**: Oh nice! Also I’m at work until 6:30 am tonight. Forgot to remind you guys

**Jeff Bergosh**: Okay we’ll see you in the morning

**Tori**: Sounds good (: thanks 

**Tori**: Loved a movie

### CONVERSATION ON 01-09-2021

**Jeff Bergosh**: Tori we’re going to bed but we’re locking the door be safe tonight do not drink and drive call us if you need us

**Tori**: I just finished watching a movie. I’m heading home in a few 

### CONVERSATION ON 01-11-2021

**Tori**: Hey dad do you know if there is a back side to the insurance card? 

**Tori**: I’m taking my employment drug test today

**Jeff Bergosh**: Yes I’ll send it to you when I get to my office

**Tori**: Ok no problem! Thank you (: 

**Jeff Bergosh**: 👍

**Tori**: Thank you 😊 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-12-2021

**Tori**: I’m at work till 9

**Jeff Bergosh**: Okay I was wondering if u knew where Brandon is.  His car is here but he’s not around

**Jeff Bergosh**: He just texted me back he’s at Tyler’s

**Tori**: Yeah he is sorry! The people were taking quite a while today.

**Tori**: Loved an image

### CONVERSATION ON 01-20-2021

**Tori**: Wow he’s pretty young to retire isn’t he? 

**Tori**: Laughed at “For most jobs, yes. In terms of football, he’s an old man lol ”

**Jeff Bergosh**: LOL I hope not

**Tori**: Awe so happy you guys got the vaccine (: now I don’t have to LOL

**Tori**: LOL well I won’t be with my regular patients starting Feb 1st

### CONVERSATION ON 01-22-2021

**Tori**: Hey a relatively positive article in the paper haha 😂 

**Jeff Bergosh**: LOL thanks!

### CONVERSATION ON 01-26-2021

**Jeff Bergosh**: Nice.  Well at least you don’t have to drive in that 🌨!

**Tori**: Emphasized an image

**Tori**: Oh yikes Nick 🥶 

### CONVERSATION ON 01-27-2021

**Tori**: Look what finally came in 😂😂😂😭

**Tori**: Lol thanks 😂 maybe in another 5 years I’ll get my bachelors 😂😂💀😬

**Tori**: Laughed at “Nope- we are going to get u go take that nurse test & get u in the RN PSC program- Seriously!! ”

**Tori**: Loved “Congrats, Tori! ”

**Jeff Bergosh**: 👍👍

**Tori**: Thanks 😊 

### CONVERSATION ON 01-28-2021

**Jeff Bergosh**: About your service on the Kia

**Tori**: I already scheduled it it’s in like February. 

**Jeff Bergosh**: 👍

**Tori**: Hey actually just looked and I have a match at that time and they are booked out too far so I’m just going to get the oil change at East Hill Automotive instead or PebBoys haven’t decided yet 

**Jeff Bergosh**: Okay

**Tori**: 1:00pm this Saturday at East Hill Automotive

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-29-2021

**Tori**: Apparently they aren’t giving the first dose at sacred anymore until they can give everyone the second dose first 🤔🙄🙄 Literally so dumb 

**Tori**: No and apparently I can’t get it. I’ll just have to wait until after starting and get it from west Florida hospital 

**Tori**: Laughed at “strange. I haven’t received one yet either. I’m surprised you weren’t one of the first people to get it... because you work with old people but also enjoy taco Tuesdays”

**Tori**: Haha very funny nick. 😂

**Tori**: Loved “Hey everyone— I’m going to order papa johns stuffed crust pizza for dinner tonight for everyone!!😁😁😁.           Love,  Dad!”

**Tori**: Thanks dad 😋😋

### CONVERSATION ON 01-30-2021

**Tori**: This is more expensive than East Hill Automotive 🙄

### CONVERSATION ON 01-31-2021

**Tori**: Hey is there any way I can get you to send me a picture of the IRC timesheet on the table in the dining room?

**Tori**: Thank you!! ☺️

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-13-2021

**Tori**: This one please 

### CONVERSATION ON 02-14-2021

**Jeff Bergosh**: Hey Tori it’s me and mom and we’re just calling to check on you. Hopefully you are not going to drink and then try to drive. If you need a ride call us do not drink and drive We love you let us know if you’re not gonna be coming home if you’re gonna be crashing where you’re at love you.

**Tori**: Love you too and yeah I’m staying the night here. Thank you for the VDay card and chocolates it was very nice 💕💕

### CONVERSATION ON 02-15-2021

**Jeff Bergosh**: Hi Tori— mom and I are just checking in— are you at work or?

Anyway just text us and let us know you’re alright.  Roads will be slick on your drive home due to the freezing temperatures.  We’re worried- we love u!

**Tori**: Yes ER I get off in like 10

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-17-2021

**Tori**: Yeah 340M$ 

**Tori**: 😵😵

**Tori**: The player for San Diego Padres signed a 14year $340M contract. I don’t understand how we aren’t winning more with that kind of money lol 😂 

**Tori**: Liked “I think we have a good shot at a World Series in the next 3 years ”

**Tori**: I hope so! We need a W

### CONVERSATION ON 02-25-2021

**Jeff Bergosh**: If u can’t make Friday, call the number anyway and they can work you in on Saturday at Brownsville Community Center

**Tori**: Ok cuz I work 7a-7p tomorrow/:

**Jeff Bergosh**: Call the number and reserve a place for Saturday then

**Tori**: So apparently it’s only 65+ I told her to put me on the list anyways 

**Jeff Bergosh**: No it is supposed to be 65 + and healthcare workers

**Tori**: And yeah that’s what I told them 

**Tori**: She said the sheet only said 65+

**Jeff Bergosh**: Okay let me check.  Can u do Saturday morning if I get u a spot?

**Tori**: Anyway I’m playing a match but they said they’ll call back

**Tori**: Yes before 10am

**Jeff Bergosh**: K

### CONVERSATION ON 02-26-2021

**Tori**: Did you ever get ahold of them by chance? 

**Jeff Bergosh**: Waiting for a call back.  Plan on tomorrow morning though

**Tori**: Ok thanks 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Tori you are all set for tomorrow morning at the Brownsville community Center. Just have your ID and show up between 8 and 10 AM and explain to them that you’re on the list and you are a front line healthcare worker and you will be given the vaccine.

**Tori**: Loved “Tori you are all set for tomorrow morning at the Brownsville community Center. Just have your ID and show up between 8 and 10 AM and explain to them that you’re on the list and you are a front line healthcare worker and you will be given the vaccine.”

**Tori**: Thanks dad appreciate it! 

**Jeff Bergosh**: No problem!

### CONVERSATION ON 03-01-2021

**Jeff Bergosh**: Hey Tori did u forward that W-2 so I can print it?

**Tori**: I’m having trouble finding it so I’m getting them to resend that email to me 

**Jeff Bergosh**: Ok

### CONVERSATION ON 03-02-2021

**Tori**: Came out looking good!! 

**Jeff Bergosh**: Hey guys— as it relates to our brand new, $8,000 countertops——Remember— nothing hot on there— it will scorch so NO Hot pans on the surfaces. Everything has to be on a hot pad or it will damage the Quartz. Also no bleach-based cleaning products no bleach no harsh chemicals I will purchase special cleaning solution design for Quartz.  In the meantime warm water and a clean cloth and mild dish soap only for cleaning it

**Tori**: Liked “Hey guys— as it relates to our brand new, $8,000 countertops——Remember— nothing hot on there— it will scorch so NO Hot pans on the surfaces. Everything has to be on a hot pad or it will damage the Quartz. Also no bleach-based cleaning products no bleach no harsh chemicals I will purchase special cleaning solution design for Quartz.  In the meantime warm water and a clean cloth and mild dish soap only for cleaning it”

### CONVERSATION ON 03-04-2021

**Jeff Bergosh**: Hey Tori we’re going to bed just checking to see if you got to work the overnight because if so we Will lock up and set the alarm. But if you’re going to come home let us know and we won’t set the alarm love you.

### CONVERSATION ON 03-05-2021

**Tori**: Sorry just saw this yeah I’m working tonight again and then probably going to go straight to tennis in the morning since I have to be in GB around 9am

**Jeff Bergosh**: Okay thx Tori.  Love u!

**Tori**: Love you too! 

**Jeff Bergosh**: Good luck in tennis

**Tori**: Thank you 😊 won the match yesterday after going through three sets 😬😬

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-06-2021

**Tori**: Want to go to brunch with mom and I? 

**Jeff Bergosh**: I just got done eating a massive lunch I’m going to Walmart right now to shop

**Jeff Bergosh**: And no drinking and driving

### CONVERSATION ON 03-11-2021

**Jeff Bergosh**: Great movie by the way

**Tori**: Oh that’s really nice of her! That’s pretty sweet Nick (: 

### CONVERSATION ON 03-20-2021

**Tori**: Hey are you going to meet up with mom and I at Agapi for brunch at 11:30?

**Jeff Bergosh**: No I’m eating leftovers just saw this

**Jeff Bergosh**: Text me what to add on list

**Tori**: Salads and sparkling waters, roast beef and mocha lattes from Gavalia koffee 😋 and fresh sliced watermelon that looks good. 

### CONVERSATION ON 03-31-2021

**Tori**: Hey did my stimulus check come in yesterday?

**Tori**: Should I be worried? 

**Jeff Bergosh**: Not yet

**Jeff Bergosh**: It’s coming

**Tori**: Very good nick! I got my second one last Saturday and had no reactions so you shouldn’t have to worry

**Tori**: Yeah I think we all did!

### CONVERSATION ON 04-01-2021

**Tori**: Laughed at “Dad I get a call like that every 5 minutes. I’m numb to them at this point ”

### CONVERSATION ON 04-02-2021

**Tori**: Hey how far are you from the house? 

### CONVERSATION ON 04-08-2021

**Tori**: Hey do you know when my tax return is coming in? 

**Jeff Bergosh**: Not sure.  It’s been filed electronically so probably a couple of weeks.  You’re getting like $500 back

**Tori**: Ok cool thanks 

**Jeff Bergosh**: 👍

**Tori**: Don’t forget today is mom’s birthday

**Jeff Bergosh**: Got it covered already but thx!

**Jeff Bergosh**: .... for the reminder

**Tori**: No problem! I picked up nice flower arrangement from Fiore 

**Jeff Bergosh**: Thanks Tori!!

### CONVERSATION ON 04-13-2021

**Tori**: I saw that

### CONVERSATION ON 04-26-2021

**Jeff Bergosh**: Tori are u home?

**Tori**: No I just finished eating in orange beach about to head home now 

**Jeff Bergosh**: No worries.  Just seeing if you could grab my amazon package it says it was left in the mailbox.  Thanks!

**Tori**: No worries I’ll do it when I get home (: 

**Jeff Bergosh**: Did u win?

**Tori**: Yeah 6-2 and 6-4 (: 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-28-2021

**Jeff Bergosh**: Miller Park?  Did u go to a Brewers Game?

**Tori**: Loved an image

**Tori**: Laughed at “The ticket was $5. I couldn’t not say yes haha”

### CONVERSATION ON 05-01-2021

**Tori**: Dickie Brennan’s lmao * and yeah it’s pretty good! Kentucky derby week here 

**Jeff Bergosh**: Awesome

### CONVERSATION ON 05-03-2021

**Tori**: Loved an image

**Tori**: Laughed at “Capt. Ken must really be hurting to have to resort to texting me lol ”

### CONVERSATION ON 05-04-2021

**Jeff Bergosh**: Also- are you working Sunday day time?

**Tori**: District Seville and 1800

**Tori**: I don’t go into work Sunday until 2:45

**Jeff Bergosh**: Okay thx— thought we were going to Jackson’s??

**Tori**: The times open there were 5pm or 8pm on

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Hey Tori—let mom know I’m inside at the table 

**Tori**: Yes sir we are pulling in now 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-06-2021

**Tori**: Thank you for my bday present 🥰💕

### CONVERSATION ON 05-09-2021

**Tori**: Loved an image

**Tori**: Laughed at “Long term winter renter at that point. End of September should be cooled down”

### CONVERSATION ON 05-16-2021

**Tori**: Loved an image

**Tori**: Loved an image

### CONVERSATION ON 05-17-2021

**Jeff Bergosh**: This is why I always harp on everyone about NEVER drinking and driving.  No previous record, and yet one bad decision on her part and she’ll be spending up to 20 years wearing an orange jump suit in state prison.  One night, one decision. Think and NEVER drink and drive EVER.  

### CONVERSATION ON 05-24-2021

**Tori**: Liked “Everyone bring your passports. The Canadian borden is currently closed, but it might open back up in July. Vancouver is only 2 hours from Seattle.”

### CONVERSATION ON 05-25-2021

**Tori**: Who took the pic?! Lol

**Tori**: Liked “A friend from law school who is at the game happened to snag a pic ”

**Tori**: That’s pretty cool! 

### CONVERSATION ON 05-26-2021

**Jeff Bergosh**: Tori— looks like Fed Ex just brought a package.  Can you grab it from the porch?  Thanks!

**Tori**: DO NOT WAKE ME UP AGAIN TODAY

### CONVERSATION ON 05-27-2021

**Jeff Bergosh**: Right on!  Drive safe!

**Tori**: Oh nice! 

### CONVERSATION ON 05-28-2021

**Jeff Bergosh**: Tori— UPS guy is at front door

**Jeff Bergosh**: Can u grab package?

**Tori**: I already did 

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-30-2021

**Jeff Bergosh**: *7:30 ish

**Tori**: Just now getting off meet you guys there in a few 

**Jeff Bergosh**: Okay great we’re just now being seated 

### CONVERSATION ON 06-17-2021

**Tori**: Can someone grab watermelon on the way home! Brandon ate mine and I was going to make a smoothie for at work 😩🙃

**Jeff Bergosh**: I will!

**Tori**: Thank you 🙏🏼 

**Jeff Bergosh**:  I got the watermelon and I’m heading home with it!

**Tori**: Thank you 😊 

### CONVERSATION ON 06-25-2021

**Jeff Bergosh**: Thanks Tori!  Got it!

**Tori**: No problem (: 

### CONVERSATION ON 06-29-2021

**Tori**: Hey! Thought you should know a patient I wheeled down just told me how much he loves you and what you’re doing for him and his subdivision 

**Jeff Bergosh**: That’s awesome!  Thanks for sharing that Tori!

**Tori**: Yeah I figured I’d share some good news lol

### CONVERSATION ON 06-30-2021

**Tori**: Loved “I’ll be in Gulfport, MS for the navy from Aug 1-13th if you guys wanted to meet or something while I’m down there.”

**Tori**: Oh very nice! 

### CONVERSATION ON 07-20-2021

**Jeff Bergosh**: Oops! I screwed up and am just realizing that our next guest comes in on Saturday—-not Sunday!  So we won’t have the condo this Saturday to Sunday like I thought we would....sorry for the mixup.  I’ll get down there right after tennis and get the changeout done prior to these next guests’ arrival!

**Tori**: It’s fine! 

### CONVERSATION ON 07-31-2021

**Jeff Bergosh**: Hey Tori we’re about to go to bed for the night and lock up just checking on your status should we set the alarm are you coming home tonight or are you coming home tomorrow?

**Jeff Bergosh**: ?

**Tori**: I’m on my way home it was lightning so I pulled aside. 

**Tori**: It’s going to be closer to midnight probably since this line for coffee is so long. 

### CONVERSATION ON 08-03-2021

**Tori**: Hey should I link my Bank of America accounts with my Merrill Lynch account? 

**Jeff Bergosh**: Where?  And can u stay the night?

**Tori**: Awesome I have the weekend off! 

**Tori**: Yeah maybe Friday night since I’m off that night

**Jeff Bergosh**: So Friday?

**Tori**: Loved “So Friday?”

**Jeff Bergosh**: But u r staying at the house right?

**Tori**: Ok good because I’m working all week and have Fri-Sun off

**Tori**: What time are you flying in? 

**Jeff Bergosh**: Awesome!

**Tori**: Oh ok sweet!

### CONVERSATION ON 08-07-2021

**Jeff Bergosh**: What’s going on with Brandon? He tried to call but he’s not answering? I’m at tennis but call me back and let me know love you

**Tori**: Love you too he thinks he has COVID he can’t taste now. I said just wear your mask and work this weekend then get tested again after the weekend 

**Jeff Bergosh**: Okay can he breathe okay??

**Tori**: Yeah it’s just loss of taste 

**Tori**: If it gets worse then I’ll take you in later tonight.

### CONVERSATION ON 08-09-2021

**Tori**: Oh nice! (: I work tonight and all day/night tomorrow but I’m off this weekend again.

**Tori**: Oh ok well I’ll try to make it work for Wednesday some before going back in

**Tori**: Loved “Okay. I just have to be at the base by 12:45 on Wednesday. I should be done after 2pm.”

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: Tori give me a call please

### CONVERSATION ON 08-15-2021

**Jeff Bergosh**: 1200 Fort Pickens road past peg leg Pete’s on right

**Tori**: It looks nice! ☺️ thanks dad (:

**Tori**: I’m heading back already because I have to do laundry and take a nap before work tonight!

### CONVERSATION ON 08-22-2021

**Jeff Bergosh**: Tori—we’re back from the condo and we’re making dinner tonight if your party is over and you’re back in Pensacola.  food will be ready at 6:30!

Love,

Dad & Mom

**Tori**: Ok thanks I’m heading back slowly. Love you both see you tonight

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Where in Iceland are u?

**Tori**: Loved an image

**Tori**: That’s cool nick! 

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: Hey Tori— please give me a call when you wake up before your shift tonight.  I need your help on something since mom and I are not at the house tonight—thanks!  It’s important.

### CONVERSATION ON 08-31-2021

**Jeff Bergosh**: R u on way to airport?

**Tori**: Just got here in tsa line now 

**Jeff Bergosh**: Okay have a safe trip.  Did u Uber there or bring your car?

**Tori**: Uber 

**Jeff Bergosh**: Okay.  We’ll have fun, be safe, and stay in a group.  Chicago is dangerous.  

**Jeff Bergosh**: Love u

**Tori**: Love you too (: and I’ll try to stay with a group as much as possible 

**Jeff Bergosh**: You have to— it’s not safe otherwise

**Tori**: Ok! 

**Jeff Bergosh**: Tori:  did u grab the spare key I had for your brother’s Kia vehicle?  I’m missing two spare keys:  one for a Kia and one for the Mom’s BMW— they’re not in my bag in my room where I keep them but were there two weeks ago.  Need to know where they are??

**Tori**: Definitely not me. I keep mine on that bracelet keychain. 

**Jeff Bergosh**: Brandon says he didn’t take them you didn’t grab the spare to move mom’s car or to move your brothers car Fink because those are very expensive to replace I had them in a baggie with all the spares and mom’s spare is gone and Brandon’s spare is gone think

**Jeff Bergosh**: **think

**Tori**: Why would I grab those? I didn’t. I only worry about my car and work. I don’t touch things that aren’t mine. You should retrace your steps 

**Jeff Bergosh**: Mom’s BMW spare is missing

**Jeff Bergosh**: I’m not accusing you I’m just asking because they’re not where we had them

**Tori**: It’s not me

**Jeff Bergosh**: K

**Tori**: I have been working and sleeping. Or trying to 

**Jeff Bergosh**: Okay have a safe trip

**Jeff Bergosh**: Sleep on plane

**Tori**: I can’t because I booked with southwest and they suck

**Tori**: Doing fine! The house is good! Just windy and rainy 

**Tori**: Of the house?! 

**Tori**: I’m really comfortable rn I just got in bed and have time to nap before my flight. I’ll send some when I leave so you can get the after look 

**Tori**: Remember Chicago! 

**Tori**: Then Portland for two days 

**Jeff Bergosh**: It must be nice to be a jet-setter

**Tori**: A planned out one for sure! 

**Tori**: Loved an image

**Tori**: That’s so cool!! And thanks ☺️ 

### CONVERSATION ON 09-01-2021

**Tori**: Hey I know you’re expecting payment today but last night I was hit with a 300$ deposit I wasn’t expecting so I’ll be paying you Friday when I get paid.

**Jeff Bergosh**: No worries

### CONVERSATION ON 09-03-2021

**Jeff Bergosh**: Hey Tori— I got your Venmo payment, thanks!  But you could’ve waited till u got back from vacation!  

Anyway, thanks, have fun, and be safe!

Love,

Dad

**Tori**: Liked “Hey Tori— I got your Venmo payment, thanks!  But you could’ve waited till u got back from vacation!  

Anyway, thanks, have fun, and be safe!

Love,

Dad”

### CONVERSATION ON 09-06-2021

**Tori**: We’re at the condo! 

**Jeff Bergosh**: What do u think?

**Tori**: It’s very nice I like the new table and chairs (: 

**Jeff Bergosh**: Thx! 


### CONVERSATION ON 09-09-2021

**Jeff Bergosh**: Hey Tori-  the FedEx driver just let a package at the front door.  Can u please pull it inside the house please?  Thanks!

Love,
Dad

**Tori**: Hey no it’s too heavy so I pulled it under the awning 

**Tori**: Hey do you have Apple Pay? 

**Jeff Bergosh**: No why?

**Tori**: Nevermind I got mom to handle it

### CONVERSATION ON 09-10-2021

**Jeff Bergosh**: OK I just Venmoed 100 to you you should have it

**Tori**: Thanks 🙏🏼 🥰

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-12-2021

**Tori**: I’m working 3-3 today or I would ): I have the weekend off just some appointments and tennis. Look forward to seeing you guys (:

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: In a meeting will call I back

**Tori**: Ok no prob

**Jeff Bergosh**: U okay

**Tori**: Yeah I just found out I guess I put my name in for LPN program at some point at PSC because I just received an email of acceptance. My dilemma is should I take an LPN course knowing I can’t work as an LPN and then do a bridge program for BSN? Or should I just hold out take the HESI again and get into an RN program later in the year? 

**Jeff Bergosh**: Tori I think that is great news!  Let me talk to my contact at PSC but I think you can bridge over after

**Tori**: Ok you don’t think it would be an unnecessary cost? That’s what I’m trying to weigh here. 

**Jeff Bergosh**: How much time do u have to make this decision?

**Tori**: I think they give me 5 days to respond from Monday when they sent it. So Friday.

**Jeff Bergosh**: Okay so we will sort it out today later

**Tori**: Ok I’m going to try and sleep for a little. So just call around 3? Or between 3-5. 

**Jeff Bergosh**: Okay will do

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: Looks like she dropped something off

**Tori**: Yeah those were my groceries I was just so tired I fell asleep through it 

**Tori**: It’s ok though mom and the grandparents came through and put them in the fridge for me 

### CONVERSATION ON 09-17-2021

**Jeff Bergosh**: Hey Tori/Brandon — Mom and I are going to use our credit on Southwest Airlines (from when our cruise was cancelled) to go to San Diego from December 23rd-December 28th for Christmas.  Will you all be able to get those days off if I book a flight for you all to come, too, for Christmas?

**Tori**: I won’t be able to since I work Christmas and have my trip New Years /: 

**Jeff Bergosh**: Okay.

**Jeff Bergosh**: You can use the credit on Southwest that’s in your name.  You have to use it by May 1st

**Tori**: Ok thank you (: 

### CONVERSATION ON 09-19-2021

**Tori**: Loved “We’re here and seated”

### CONVERSATION ON 09-26-2021

**Jeff Bergosh**: Tori you got a red light ticket in Gulf breeze it mailed it to me but you were the one who went through a red light you’ve got a pay the $158 fine

**Tori**: No way in hell I was more than half way through before it turned red as is indicated from the picture itself 

**Tori**: I never run red lights 

**Jeff Bergosh**: Hey Tori and Brandon—mom and I are hanging out at the beach and it’s a great beach day— we wanted to make sure you know you’re invited to come hang out!  Love you!

Dad

**Tori**: Loved “Hey Tori and Brandon—mom and I are hanging out at the beach and it’s a great beach day— we wanted to make sure you know you’re invited to come hang out!  Love you!

Dad”

### CONVERSATION ON 09-27-2021

**Jeff Bergosh**: Call them and see if you can get out of it then but it’s in my name and I don’t wanna get screwed on this

**Tori**: I know dad I’ll handle it 

### CONVERSATION ON 09-30-2021

**Tori**: Loved “https://www.ted.com/talks/stuart_firestein_the_pursuit_of_ignorance?language=en#t-1094510”

**Tori**: Very interesting watch. Thanks ☺️ 

### CONVERSATION ON 10-03-2021

**Jeff Bergosh**: Tori—-don’t drink and drive no matter what tonight Tori. Call an Uber or call us but do not drink and drive no matter what

**Jeff Bergosh**: Cool!  Are they winning??

**Tori**: Loved a movie

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: In mtg can I call u back?

**Tori**: Yeah trying to figure out time you guys fly out in case you guys wanted a ride. 

**Jeff Bergosh**: Thanks Tori- we need to be at airport by 0730 Thursday so I’ll probably drive but thanks Tori!

**Tori**: Oh ok I figured you guys were doing an overnight flight. Ok no worries. I’m probably going to be gone today through Saturday morning. Donna’s dog isn’t eating so I told her I can stay and pet/house sit between work. Love you guys ☺️

**Jeff Bergosh**: Love you too Tori!

### CONVERSATION ON 10-07-2021

**Tori**: Wry cool! Hey did mom and dad already get there or are they coming in tomorrow?

**Tori**: Very* lol

**Tori**: Liked “Denmark is hosting Austria that day ”

**Tori**: Oh nice! Wow that’s a long day of travel 😅

**Tori**: 0700 this morning 😬

**Tori**: Liked “Hopefully they’ll get some sleep on the plane at least!”

### CONVERSATION ON 10-08-2021

**Jeff Bergosh**: LOL

**Tori**: Laughed at “We left Thursday at 10 am & we are now eating breakfast in London waiting for our flight to Denmark! Long-ass travel days! Then they had some BS rule in London that u could only have (1) sandwich plastic bag per passenger & u had to take it out of your luggage. I got it all in except hairspray & mouse. Oy Vey! We still haven’t slept but it’s an adventure! Travel now kids while you’re young!!❤️❤️”

### CONVERSATION ON 10-09-2021

**Tori**: Loved an image

**Tori**: Loved an image

### CONVERSATION ON 10-15-2021

**Tori**: Emphasized “https://www.usatoday.com/story/news/nation/2021/10/11/santee-plane-crash-california-neighborhood-ups-truck/6096028001/”

**Jeff Bergosh**: Hey I’m on the way there and just wondering what court you guys are playing on?

### CONVERSATION ON 10-16-2021

**Tori**: Hey can one of you tip the bud light people for me I forgot to get cash lol 

**Jeff Bergosh**: I’m not there

**Jeff Bergosh**: Or else I would

**Tori**: No worries! Thanks (: 

### CONVERSATION ON 10-20-2021

**Tori**: Loved an image

**Tori**: Wow so pretty nick!!

### CONVERSATION ON 10-21-2021

**Tori**: Loved an image

**Tori**: Nice B! Hope you get tipped well (: 

**Jeff Bergosh**: Bartending????

### CONVERSATION ON 10-22-2021

**Jeff Bergosh**: Hey Tori did you make it to Hawaii?

**Tori**: Yes we are racing to make the cocktail cruise and bbq now! 

**Tori**: Hey made it safe! Everything is off to a great start! 

**Tori**: From the sunset cruise in Honolulu 

**Tori**: Yeah for the weekend! 

### CONVERSATION ON 10-23-2021

**Tori**: Spam masubi(?) are you setting me up? Haha

**Tori**: Ok I’ll give it a try! (: 

### CONVERSATION ON 10-27-2021

**Tori**: 😂😂🥴

### CONVERSATION ON 10-28-2021

**Tori**: Just walk in lol

**Jeff Bergosh**: There a chick at front desk hawking

**Jeff Bergosh**: I’ll wait till she goes to the bathroom the. I’ll sneak in. 👍😎

**Tori**: Haha ok 😂

**Tori**: Just come in. Nobody will turn away a commissioner lol

### CONVERSATION ON 10-29-2021

**Jeff Bergosh**: Thanks Tori!

**Tori**: No problem! (:

### CONVERSATION ON 10-30-2021

**Tori**: Hey! I thought I’m going with you and mom to Blue Angels next Saturday?!

**Jeff Bergosh**: You can— I just won’t necessarily have a wristband for you for the VIP tent— but u can ride there and back with us

### CONVERSATION ON 11-01-2021

**Jeff Bergosh**: I scored an extra wristband for Tori

**Tori**: Thank you ☺️ 

### CONVERSATION ON 11-04-2021

**Tori**: Hey pretty sure I’m going to be staying out here at Madison’s. Just giving a heads up

**Tori**: Loved an image

### CONVERSATION ON 11-06-2021

**Tori**: Loved “We’re on the 30 minute countdown will be leaving at 11:30 sharp”

### CONVERSATION ON 11-12-2021

**Tori**: Loved an image

**Tori**: That’s pretty sweet! 

### CONVERSATION ON 11-18-2021

**Tori**: Loved “Hey, kids! We are all invited to attend this wonderful Christmas service at Marcus Point Church! They have special seating for us & are providing lunch afterwards! Sunday, December 12th at 9:30 am! Anyone that can attend needs to be at our house by 9 am so we can all ride together. Love you guys!!”

### CONVERSATION ON 11-19-2021

**Tori**: Hey I’m at the Hilton at beach still

**Tori**: Yes please thanks (: 

**Tori**: Hey actually can you pick me up? 

**Jeff Bergosh**: Where r u?

**Jeff Bergosh**: Do u need a ride?

**Tori**: Yeah probably. It would be a better idea I think. And I’m at the Hilton 

**Jeff Bergosh**: Okay I’ll ask mom to grab u 

**Jeff Bergosh**: And I’ll get u something from sonny’s 

**Tori**: Ok thank you (: 

**Jeff Bergosh**: She’s going to come get u

**Jeff Bergosh**: Answer your phone when she calls

**Tori**: I will I’m looking and I’ll look for it! 

**Jeff Bergosh**: Okay hang tight we’ll be headed that way soon

**Tori**: It’s fine take your guys time 

**Tori**: I just wanted to set it up ahead of time 

**Jeff Bergosh**: Wow!  Have fun Nick— be safe!

**Tori**: Liked “Headed to Slovakia today”

**Tori**: Slovakia is the country lol 🥴

**Tori**: Laughed at “It’s so cheap compared to Denmark; I feel like a king here! ”

**Tori**: Loved “Haha it’s the country. I’m in the capital, Bratislava!  ”

**Tori**: Laughed at an image

**Tori**: Loved “2.50 euro ”

**Tori**: Loved an image

**Tori**: That’s pretty sweet Nick! 

### CONVERSATION ON 11-20-2021

**Tori**: Hey I’m just going to stay out here tonight!

### CONVERSATION ON 11-22-2021

**Tori**: Hey has anyone brought it to your attention that there is a make-shift horse trailer turned garage sale I guess on the same side of the road as our subdivision? Over on nine mile? 

### CONVERSATION ON 11-23-2021

**Tori**: Alright I’ll take care of the in person stuff this Friday since that’s when I’m going there to get patches on my uniforms.

### CONVERSATION ON 11-29-2021

**Jeff Bergosh**: Hey Tori a delivery driver just left a package on the front porch can you please grab it and put it on the dining room table for me? Thanks Tori!

**Tori**: Yeah I’ll grab it!

**Jeff Bergosh**: Thx

### CONVERSATION ON 12-04-2021

**Tori**: Hey can you float me 40$ for gas!

**Jeff Bergosh**: Sure

**Tori**: Thank you ☺️ 

**Tori**: Can you Venmo me ? 

**Jeff Bergosh**: Just did

**Tori**: Thank you (: I had 4 miles left in the tank 😅

**Jeff Bergosh**: Don’t run out of gas

**Tori**: I won’t I’m near one! Thank you (: 

**Jeff Bergosh**: 👍

**Tori**: Came in 2nd place for my age group in the Runway 5k 👏🏼👏🏼

### CONVERSATION ON 12-07-2021

**Jeff Bergosh**: Not sure————- but there needs to be!

**Tori**: Oh yeah special needs my ass, that’s the girl who tore out a sitters weave, she spat and kicked and punched several of us. She knew exactly what she was doing. 

**Jeff Bergosh**: Interesting so you know about this girl Tori??

**Tori**: Yeah I had to watch her after we had to medicate her and restrain her.

**Jeff Bergosh**: Small world

**Tori**: That it is. Now that the mom is looking for a pay day that nurse that was watching her had to go to another briefing. 

### CONVERSATION ON 12-10-2021

**Tori**: Wow so you really think we are to blame?! 

**Tori**: I just saw the PNJ article… cool 

**Jeff Bergosh**: No—I just think there has to be a place for people like her and now there isn’t one

**Tori**: In the article it quoted you as saying the hospital is responsible and that they shouldn’t have discharged her… it’s just fun to come to work and have people ask how things are with my dad after that article came out. One I didn’t know about until I read it on my lunch break 🙃

**Jeff Bergosh**: What day did that come out?  That’s not the article I’ve seen.

**Jeff Bergosh**: I don’t know what we should do with these folks.  Jail ain’t the place though

**Tori**: Yeah I was like I don’t see how he could have said that knowing what I told him. I literally just wanted to him about the whole situation. 

**Tori**: Ranted *

**Tori**: It came out December 6th

**Jeff Bergosh**: That was a WEAR interview—- PNJ never got a quote from me

**Jeff Bergosh**: …….and I stated that we all have to wait for the coroner’s report and not rush to judgment

**Tori**: After stating you definitely wouldn’t rush to judgement on any of the correctional officers working at the jail doing what they do professionally every day. It was a little bit of a slam in our faces. A heads up would have been appreciated

**Jeff Bergosh**: I get that.  The media is looking to crucify the corrections officers as murderers :   That can’t happen

**Tori**: Right but saying we shouldn’t have discharged her and not saying we did what we do professionally every day to the best of our abilities was lame. PNJ naturally refused to set the record straight when WFH tried to send in a comment. 

**Jeff Bergosh**: The press always gets it wrong

**Jeff Bergosh**: Are u at home Tori?  Someone is ringing the bell and I can’t get mom to answer her phone

**Tori**: No but I will be shortly. 

**Tori**: Can you tell them to leave whatever it is at the door

**Jeff Bergosh**: No worries, she answered

**Tori**: Ok good deal 

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: Seriously Tori:  figure out what HCA offers for basic, catastrophic coverage for a single employee and Mom and I will help however we need to.  There are way too many things that can happen to not have coverage.  And if you were diagnosed with something it could jeopardize your ability to get affordable coverage down the line.  And if you’re injured with no insurance you’ll have medical collections following you forever.  I can’t imagine there isnt a base HSA plan for HCA employees that’s more than 75-100 monthly Tori????  Let me know 

**Jeff Bergosh**: Get signed up for the basic, lowest price employee only plan

**Tori**: NurseSpring has open enrollment through the 16th

**Jeff Bergosh**: How much for the cheapest HSA plan?

**Jeff Bergosh**: Do u still qualify??? Don’t you have to work FT for those prices?

### CONVERSATION ON 12-14-2021

**Jeff Bergosh**:  Hey, u can survive on juice for a looooong time 👌👍

**Tori**: Laughed at “Update: we got juice….. 

We have a real FEMA type situation going on here 😂😂”

**Tori**: Emphasized “Stuck in Amsterdam to fix a part on the plane. Because of the delay we have to switch out crews, so we are stopping in Minneapolis before going to Salt Lake City. I’m probably not going to make that connection to San Diego now. 

We’ve been at the gate for 4 hours. They won’t give out food or anything besides water because “they can’t when the plane is on the ground.” 

But because everyone connecting flights got absolutely wrecked… delta brought ONE representative to reschedule people’s next flights. ”

**Tori**: Disliked “Still here. Going on 5 hours at the gate ”

### CONVERSATION ON 12-16-2021

**Jeff Bergosh**: Herbert is awesome

**Tori**: Lol lucky for me one of the docs is a fan of football !! Watching the game at work lol

**Jeff Bergosh**: LOL that’s awesome!  Paid to watch football!!

**Jeff Bergosh**: ……..Just don’t forget about your patients though LOL

**Tori**: Lol I’m huc so I’m stuck at a desk at all night 

**Tori**: 😂😂😂

**Jeff Bergosh**: Young Sheldon!!

### CONVERSATION ON 12-21-2021

**Jeff Bergosh**: ?

**Tori**: Yeah I’m working tonight! Thank you though (:

**Jeff Bergosh**: Ok

### CONVERSATION ON 12-22-2021

**Jeff Bergosh**: Okay I ordered the pizza it is on the way.  Papa Johns stuffed crust cheese pizza, stuffed crust sausage pizza, plus Buffalo wings! 😊😊👍👍

**Tori**: Thanks (:

### CONVERSATION ON 12-23-2021

**Jeff Bergosh**: Touchdown

**Tori**: Glad you guys made it safe! (: 

**Jeff Bergosh**: Us too!!

**Jeff Bergosh**: Tavern

### CONVERSATION ON 12-24-2021

**Tori**: Did you change our WiFi password? I’m not being allowed to connect 

**Jeff Bergosh**: No it is the same

**Tori**: 4496750

**Jeff Bergosh**: 8509440495

**Tori**: Thanks 🙏🏼 

**Tori**: I’m in Pensacola 🙃

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas Tori!

**Tori**: Merry Christmas dad ❤️💚

**Tori**: Merry Christmas Fam 💚❤️ Love you guys!

**Tori**: Loved an image

**Tori**: Emphasized an image

**Tori**: Wow that’s terrible /: and love seeing Brandon and GlamMa 

### CONVERSATION ON 12-27-2021

**Tori**: Hey I’m sorry for the slight mess I left. I tried tidying up but it was difficult with me not being able to pack until this morning 🥴 anyways if you see a stack of forms from PSC for nursing program please put them in my room. I meant to do so but was in a chaotic state this morning trying to get over here in time for my flight.

**Jeff Bergosh**: Nikki wanted me to remind you that we hope you got your negative test result because if you don’t and you land in Europe it’s a €500 fine

**Jeff Bergosh**: So did you get your negative test?

**Tori**: Yea I got my rapid test yesterday and it was negative! Good on them for being strict about it and holding people accountable.

**Tori**: I went to pay extra to stay in the nice parking garage at the airport and I ended up on the 3rd level, not covered, and the elevators were broken. I brought the biggest suitcase I owned and immediately regretted it lol 

**Jeff Bergosh**: LOL bad break

### CONVERSATION ON 12-28-2021

**Tori**: Made it to Venice ❤️💚☺️ Air France is absolutely the best so far 🤗 love you guys see most of you soon enough (: 

**Tori**: Te amo ❤️💚 love you 😘 

### CONVERSATION ON 01-07-2022

**Tori**: My wines and oil and cookbook came in today!! 😋❤️💚

**Tori**: Free stay and wine tasting in Tuscany anyone? 

### CONVERSATION ON 01-08-2022

**Tori**: Loved “Just got out of the spider man movie. Brandon looks so much like Tom Holland! Anybody else notice that? ”

**Tori**: Lol yeah it’s weird 😂

### CONVERSATION ON 01-12-2022

**Tori**: Hey so I worked out after class and I told work I can come in till midnight. Letting you know so you don’t chain up and put the alarm on

**Jeff Bergosh**: Okay so you’re working tonight till 12:00?

**Tori**: Yeah I’ll be getting back a little after midnight! 

**Tori**: And save me some dinner please I will be starving 🙏🏼😋 Thank you again for making mom and I meals this week (: 

**Jeff Bergosh**: No problem Tori!  Trying to be healthy 😀

### CONVERSATION ON 01-13-2022

**Jeff Bergosh**: Okay we won’t set the alarm

**Tori**: I’m sorry I just saw this we are absolutely slammed

**Tori**: Very good Brandon!! 💕👏🏼

### CONVERSATION ON 01-14-2022

**Jeff Bergosh**: Hey Tori are you at school or at work?

**Tori**: School but I just stopped at clean eatz on lunch break

**Jeff Bergosh**: Oh OK I was just going to ask you about the grocery list for shopping tomorrow if you’re still going to cook something I need to know what to buy so just at some point today write down a list for me OK love you!

**Tori**: Ok no problem I could always just buy it or the stuff you can’t find too. I’ll send it in a little bit. (: thanks 

**Tori**: Laughed at “Nope- Madrina was all over him!!”

**Tori**: Loved “I spoke at The Grand Marlin last night & guess who I met at the bar?”

### CONVERSATION ON 01-15-2022

**Jeff Bergosh**: Tori are you coming home before Tennis?

**Jeff Bergosh**: If so can you bring mom’s phone to her at Roger Scott she left it at the house?

**Tori**: Hey here’s the stuff just get what you can find and get or need and I’ll get the rest. 

**Tori**: If you just want to tell me what we don’t have at home I can grab it after lunch. 

**Jeff Bergosh**: Okay thanks got it

**Jeff Bergosh**: Get some sleep Tori🙂

**Tori**: Ok thanks ☺️ I’ll probably try to make the ragu today if you can get all of the stuff for that. I’ll make the lasagna sheets and put the rest together tomorrow.

### CONVERSATION ON 01-18-2022

**Tori**: Disliked “I didn’t get the job. Back to the drawing board”

**Tori**: Aww Nick! I’m so sorry /: I really wanted that for you. Maybe you will find something better! ☺️💕

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Hey Tori— I got your Venmo thanks— but why did you pay me so early?  U could have waited till the end of the month.  But thanks! 

Love
Dad

**Tori**: Just got paid won’t get paid again until after the 1st

**Jeff Bergosh**: 👍

**Tori**: Hey I just went to get my parking decal and the guy told me my registration expired. What do I do to get that fixed? Is that a tax collector thing? 

**Jeff Bergosh**: Yes but your registration isn’t expired.  Look in the glove box for the most recent one which you should have. I put it in there when I put your 2022 sticker on your license plate. Look on your license plate it says 2022 which means your registration isn’t expired

**Jeff Bergosh**: You probably grab last year’s registration instead of this year’s look in your glove box again

**Tori**: Ok it just said 2021 so he was just making sure I knew. 

**Jeff Bergosh**: Did u find the current one?

**Tori**: I’ll go take a look real quick 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Important

**Tori**: Yeah you’re right I just grabbed the one that was on top which was expired. The other one was birdied 

**Jeff Bergosh**: Okay good

### CONVERSATION ON 01-26-2022

**Tori**: Because he took away my point since I called it as I hit the ball

**Tori**: They wouldn’t have even called that in ladies league just saying 💁🏼‍♀️

### CONVERSATION ON 01-29-2022

**Tori**: Hey Dawnmarie says hi lol 😂 

