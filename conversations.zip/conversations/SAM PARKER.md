

## CONVERSATIONS WITH SAM PARKER

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Sam Parker**: Boom! I bet Marcille is thinking he will be unopposed. Your brother would be awesome and the dual name recognition would help

**Sam Parker**: How much does a poll cost?

**Jeff Bergosh**: $625

**Jeff Bergosh**: Do do you want me to forward my contact at Gravis?

**Sam Parker**: Yes, I will probably do one around April. Planning my first campaign event for Feb 20th.

**Jeff Bergosh**: 👍

**Sam Parker**: Thanks

**Jeff Bergosh**: 👍call him, he’ll take care of you

**Sam Parker**: You are killing it

**Sam Parker**: Proof that multiple opponents split the anti-incumbent votes

**Jeff Bergosh**: Thanks Sam!  You’ll do likewise I know!

### CONVERSATION ON 02-14-2020

**Sam Parker**: Underhill is ridiculous. Can’t believe you have to work with him

**Jeff Bergosh**: Yeah—he is a tool.  We’re going to open that beach!

**Sam Parker**: Y’all were on the news about the beach access issue. He wants y’all to buy more land but he says we waste money in my county

**Jeff Bergosh**: He’s a nut

### CONVERSATION ON 04-06-2020

**Sam Parker**: At one of my signs vandalized last night for the first time. I wanted to ask your opinion on if you think I should just leave it up or put a new sign over?

**Sam Parker**: My first instinct was to just quietly replace it and be sone with it but wanted to seek wise counsel from just a few friends. 

**Jeff Bergosh**: Sam this happen to me too man what you have to do is just put a new sign up as right away

**Jeff Bergosh**: I’ve had them run my signs over and I just get out there and put a new one up as quick as I can

**Sam Parker**: I really thought about just leaving it like it didn’t bother me.....immature folks

**Jeff Bergosh**: It sucks.  People are immature

**Sam Parker**: You still looking good in your race? Has Underhill‘s secretary made any traction? I think it’s just funny to refer to him that way

**Jeff Bergosh**: Im doing well, ahead in three polls run so far.  And I think the national emergency helps the incumbents; nobody cares about our political opponents at all.  They are irrelevant.  My top opponents, Jesse Casey and Underhill’s secretary—-I’m holding them underwater... they can’t get air.  They’re like dolphins I’m holding underwater and they can’t come up and blow out their blowholes LOL😂😂

**Jeff Bergosh**: I’m drowning them

**Sam Parker**: Laughed at “Im doing well, ahead in three polls run so far.  And I think the national emergency helps the incumbents; nobody cares about our political opponents at all.  They are irrelevant.  My top opponents, Jesse Casey and Underhill’s secretary—-I’m holding them underwater... they can’t get air.  They’re like dolphins I’m holding underwater and they can’t come up and blow out their blowholes LOL😂😂”

### CONVERSATION ON 04-17-2020

**Sam Parker**: Yeah I got off easy because we won’t have the decision made before y’all ever meet which will make it even easier for y’all. At least you got your name plugged on channel 3 news too. Free advertisement on election year is always good

**Sam Parker**: Y’all got off easy that’s what I meant to say

**Jeff Bergosh**: Yeah but our sheriff won’t cooperate and enforce...at least you all have Sheriff Johnson who has your backs!  

**Jeff Bergosh**: We’ll watch how Navarre goes, thanks for going first LOL

**Sam Parker**: They currently already have a deputy station at the bridge to turn people away. I cannot understand why they say it would be any harder to have a checkpoint to just allow residents only. They’re not going to do anything about people congregating because they don’t do anything to enforce it in the stores or the parks or anywhere else.

Or Sheriff or use it as a chance to ask for more money in the budget. It’s gonna be interesting to see how many millions we all lose in local option sales tax funds this year as well as property tax valuations for the following budget year

**Sam Parker**: Our property appraiser said that our oil field valuations will drop drastically as well as valuations on the beach because of the reduced rental income this year

**Sam Parker**: Have a good night buddy. I would say that being on the news two days in a row and in every newspaper today was worth at least $5000 in advertisement four months prior to my election 👍🏻

**Jeff Bergosh**: Have a great night!  And yes, that media coverage is gold.  You’re going to win your election big, it won’t even be close

### CONVERSATION ON 04-19-2020

**Sam Parker**: I drove by this which is on the for sale sign in front of the old abandoned KFC building in Milton. I googled the phone number and found out this is the same guy running against you in district one. Was not sure if you knew he worked for Brian DeMaria while currently being Doug’s secretary. 

**Sam Parker**: I’m going to go out on a limb and assume this guy that just sent me a text message is probably a democrat. 


**Jeff Bergosh**: Yes good assumption!

### CONVERSATION ON 04-22-2020

**Sam Parker**: There’s live stream meetings are a hit. You’re guaranteed to get reelected buddy. Keep up the good work and have a great day

**Jeff Bergosh**: Thanks Sam!!  Greatly appreciate your participation!  Good luck in tomorrow’s meeting.

### CONVERSATION ON 04-26-2020

**Jeff Bergosh**: Hey good morning Sam this is Jeff Bergosh. Just wondering if you would be willing to join me on Wednesday for my coffee with the commissioner event? Matt Gaetz is going to join me but he cannot do it until 9 AM so I’m going to try and get you and Nathan Boyles from Okaloosa on my coffee to talk about regional issues with reopening the economy.  If you’re available I’ll send you the login credentials—- hope you can join me!

**Sam Parker**: Sounds fun! Thanks for thinking of me. 

**Jeff Bergosh**: Cool!  It will be fun.  I’m waiting to hear back from Nathan.  I’ll send you the log in credentials

**Jeff Bergosh**: You can join from your laptop or smartphone

**Sam Parker**: Sweet, have a great day! I will help spread the word to increase viewership. 

**Jeff Bergosh**: Thanks Sam!

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Good afternoon Sam- I sent you a Microsoft teams invite for tomorrow morning’s virtual coffee with a commissioner meeting at 0630.  If you can join in a couple of minutes early that would be great.  Looking forward to hearing your thoughts on the next phases of recovery for our region.  I’m also attaching the call in number here as well.  

Thanks!

Jeff Bergosh

**Sam Parker**: Great. I look forward to seeing you tomorrow morning

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-29-2020

**Jeff Bergosh**: Hey Sam—thanks very much for appearing on our coffee meeting this morning—great conversation!

**Sam Parker**: Was a great time. Thanks

**Jeff Bergosh**: I saw this earlier today.  It’s pretty scathing.  Trouble........

**Sam Parker**: It mentions your opponent in there is why I sent it to you. 

**Jeff Bergosh**: Yep—-twice 👍

**Sam Parker**: You have your election in the bag

**Jeff Bergosh**: I hope so!  Thanks for the positive outlook!!

### CONVERSATION ON 05-12-2020

**Sam Parker**: Can you send me Cody Rawson’s direct number? I will not mention where I got it

**Jeff Bergosh**: 850-968-0991 is the only number I have for him.  I don’t have his cell

### CONVERSATION ON 05-13-2020

**Sam Parker**: You already did a mailout? What did it look like? I have been wondering when and what I should put out for my first kailoit

**Sam Parker**: Mail out 

**Jeff Bergosh**: I’ve done one Sam- it was for my petitions and I got all my petitions back—30% response.  Have not done any since

**Sam Parker**: Samparkerrealty@gmail.com

**Jeff Bergosh**: Sent them

**Sam Parker**: Thanks.

**Sam Parker**: Let me know when you develop a plan on when you were going to start sending out mailers and how many. Always good to bounce ideas off of each other

**Jeff Bergosh**: Already have it

**Jeff Bergosh**: Just please keep this timeline and strategy between us— wouldn’t want Underhill’s secretary to get it. 😎

**Sam Parker**: Sorry about that I was on the phone. I haven’t wrote down anytime on stuff like you but looking yours over will be a great place to start

**Jeff Bergosh**: Got my poll results back today.  Of the 256 that are “decided” today, here’s what it looks like in my race

**Jeff Bergosh**: Keep this confidential please

**Sam Parker**: How many total were polled and what does that cost to do?

I told you that you are solid

**Jeff Bergosh**: Thanks Sam 

**Jeff Bergosh**: I can get you my guy’s number at Gravis— just let me know

**Sam Parker**: That’s actually surprising that so many of the ones who responded are already decided. Just a couple months ago it seemed like the overwhelming majority were undecided

**Sam Parker**: Do you think Lumon has anything to worry about? I thought it was him putting his brother up to run just to keep anyone outside of the race but I saw that his brother raise $10,000 last month so I guess it’s going to be an actual race

**Sam Parker**: I met with a donor over here in Milton today. Funny that even people over here hate Underhill

**Jeff Bergosh**: Everybody hates him

**Jeff Bergosh**: Lumon is a lock and so is Steven

**Sam Parker**: He definitely will not be able to run for office outside of that district in the future

**Sam Parker**: I think me and Lynchard are solid over here but seriously concerned about Salter’s race

**Jeff Bergosh**: I think the incumbents are strongly positioned in Santa Rosa——except for Williamson... not sure what happened there

### CONVERSATION ON 07-15-2020

**Jeff Bergosh**: In a meeting I’ll call u back

### CONVERSATION ON 08-06-2020

**Sam Parker**: Just saw you on TV. Who did you hire to make that commercial? I am thinking about doing TV. I have done polling and I am ahead but there are a lot of undecideds which concerns me

**Jeff Bergosh**: Good morning Sam.  I use Southern Media, Inc

**Jeff Bergosh**: Call Jim— he can do it

**Sam Parker**: Liked “Call Jim— he can do it”

**Sam Parker**: Did you do it because you were worried about where you were at in the polls or just because you had some money left over? I’m trying to decide between doing another mail out or maybe some TV. What do you think would be more effective?

**Jeff Bergosh**: I had the luxury of a decent sized war chest so I added $7K to TV ads just to insure saturation. I’ve been ahead by sizable margins in every poll I’ve run— but Jesse Casey does have some momentum so I take him very seriously.  He is a real threat because he is known and liked— and so I’m just throwing the kitchen sink at the advertising

**Jeff Bergosh**: It’s crazy that folks would vote for him knowing he’s not well spoken, not educated, and he doesn’t do debates or forums because he’d get his clock cleaned.  And his voters don’t care.  It’s quite remarkable

**Sam Parker**: Gotcha

**Jeff Bergosh**: How far ahead are you in your polling Sam?

**Sam Parker**: The last pole I saw was a little over a week ago and I was up by 13%

**Sam Parker**: My concern is that there were still 29% undecided

**Jeff Bergosh**: Sam that’s pretty strong my poll— thing 30% undecided but with a 13 point lead that late in the race—- I think you’re in pretty good shape good luck my friend!!

**Sam Parker**: Liked “Sam that’s pretty strong my poll— thing 30% undecided but with a 13 point lead that late in the race—- I think you’re in pretty good shape good luck my friend!!”

**Sam Parker**: I feel like I’m going to win and everyone tells me that but there is a strong anti-encumber undercurrent so I don’t want to leave anything to chance. I have already done four mailers so I may just go ahead and do one more that can drop next week

**Jeff Bergosh**: That’s a good plan Sam.  Mailers are the best advertising I have found in my five elections.  People look at them, throw them on their kitchen table, etc.  they are a physical, tangible thing with our faces and names on them.  Funny how “experts” try to sell online, text, email, etc————-but none of those mediums are as powerful as mailers

**Sam Parker**: Liked “That’s a good plan Sam.  Mailers are the best advertising I have found in my five elections.  People look at them, throw them on their kitchen table, etc.  they are a physical, tangible thing with our faces and names on them.  Funny how “experts” try to sell online, text, email, etc————-but none of those mediums are as powerful as mailers”

### CONVERSATION ON 08-14-2020

**Jeff Bergosh**: Hey Sam —that was a great performance in last nights debate I listened to it on the radio —-and I think you crushed it!  Congrats!

**Sam Parker**: I appreciate that. I honestly did not prepare at all because I was not going to do it but when I heard that my opponent had logged on I jumped on there and I felt like I crushed it.

**Sam Parker**: I did not hear you guys. Everything still looking good for you over there? Need me to do anything to help?

**Jeff Bergosh**: Six polls have been run in my race and I’ve been in the lead in every one so I feel like I’m looking good.  Jesse is always a threat— but I think I’ll beat him again.  Thanks Sam and have a great weekend my friend!!

**Sam Parker**: You got it

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Great job tonight Sam!  Congrats!  What happened to Salter and Lynchard??

**Sam Parker**: I thought I told you that I figured they would both lose. This waste hauler debacle over here I think cost both of them their seats

**Jeff Bergosh**: Wow!!

**Sam Parker**: Congratulations on your win Commissioner

**Jeff Bergosh**: Thanks and glad u won!!!!!

**Sam Parker**: Me too!!!

### CONVERSATION ON 03-02-2021

**Sam Parker**: https://ssrnews.com/williamson-files-legislation-to-allow-recall-of-county-commissioners/

**Sam Parker**: What is this crap?

**Jeff Bergosh**: Wow!  What’s that all about!

**Sam Parker**: No clue. I just found out. I didn’t get any heads up and haven’t heard from him

**Jeff Bergosh**: Wow!  Wonder if this bill will have legs?

**Sam Parker**: I found out from an Okaloosa commissioner and my guys over here are pissed

**Jeff Bergosh**: Yeah this is BS

**Sam Parker**: Definitely doesn’t seem to be a friendly to local elected officials. Could create a real headache if it gets any legs. 

**Jeff Bergosh**: I don’t think it will go anywhere

**Jeff Bergosh**: My enemies will love this

**Sam Parker**: Mine too. The tree huggers would be starting petitions against all of us

**Jeff Bergosh**: Yep.  Could become a zoo

**Jeff Bergosh**: What would the threshold be I wonder?

**Sam Parker**: I don’t know. Haven’t read the bill

### CONVERSATION ON 07-13-2021

**Sam Parker**: https://www.pnj.com/story/news/2021/07/13/santa-rosa-county-administrator-dan-schebler-resigns/7960194002/

### CONVERSATION ON 07-14-2021

**Jeff Bergosh**: Wow!  What happened?  I thought he was doing a good job,  I know it’s a tough job.

**Sam Parker**: He left because of how our meetings have turned into circuses and he was constantly butting heads with Comm Calkins

I told my wife I should put in an application for Escambia’s County Administrator position. 

**Jeff Bergosh**: That would be awesome Sam— but I wouldn’t wish that on anyone with Doug Underhill and his minions creating massive chaos..

**Sam Parker**: Laughed at “That would be awesome Sam— but I wouldn’t wish that on anyone with Doug Underhill and his minions creating massive chaos..”

