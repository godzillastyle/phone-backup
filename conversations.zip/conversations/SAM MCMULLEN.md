

## CONVERSATIONS WITH SAM MCMULLEN

### CONVERSATION ON 12-25-2019

**Jeff Bergosh**: Merry Christmas to y’all make it a great one!

