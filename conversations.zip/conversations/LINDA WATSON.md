

## CONVERSATIONS WITH LINDA WATSON

### CONVERSATION ON 08-27-2021

**Jeff Bergosh**: Hi Linda you had said you were going to text me David the maintenance man's phone number? Can you please text it to me because I have not received it and I would like to speak with him thank you.

Jeff Bergosh 
2-C

**Jeff Bergosh**: Thank you Linda-- I called and he answered my question!  

### CONVERSATION ON 10-08-2021

**Jeff Bergosh**: Hi Emily I was traveling yesterday and I'm in Copenhagen and just got your message today.  I spoke with Linda Watson on Tuesday, copied to this text, and she assured me that she programmed the following codes for the building:  #7777. And #0916.  Additionally, she assured me the problems that were occurring with the codes were limited to the front building entrance and NOT the front gate.  I'll ask her by copy of her on this text to double check this.  Again-- sorry for the inconvenience but #7777 should be working for both and if not we will get that sorted.  I'll be on a train to Sweden tomorrow but should have cell reception and I'll follow up.  Sincerely

Jeff Bergosh

**Jeff Bergosh**: Will do

### CONVERSATION ON 01-19-2022

**Jeff Bergosh**: Awesome!!  Thank you Linda!

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: Good morning Linda I have a question for you: I am going to be replacing my air conditioning unit and the air handler unit in 2-C. I'm wondering if you have a good contact number for a reputable mechanical contractor with whom Tristan Towers has experience and with whom you think has a reputable track record. I've called Emerald Coast heating and air multiple times over the past two weeks to get a quote and have yet to get a call back ---so I'm just wondering if you might have a name and number that I could try and I would greatly appreciate it thank you Linda!

R/

Jeff Bergosh

**Jeff Bergosh**: Thank you Linda!

### CONVERSATION ON 02-01-2022

**Jeff Bergosh**: Hi Linda-- Can you please remind me again what the four digit code is to access my AC unit on the roof? I was thinking it was 1980

