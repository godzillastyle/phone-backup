

## CONVERSATIONS WITH SCOTT MILLER

### CONVERSATION ON 12-03-2019

**Scott Miller**: It turns out I was wrong about the type of housing. These are not workforce housing. They are premium market rate housing like South Town. The plan is to put the entrance on Pine Forest Road.

**Jeff Bergosh**: Thank you for the clarification Scott I’m sure I am glad to hear that

**Scott Miller**: Right now the zoning is correct for Apartments. What we are looking for is to get a change in the FLU to accommodate lower density for the project. If we can’t get that, then we are going to have to go with a higher density project that will include a commercial component. Our goal project will actually be a lower impact on the neighboring residents. It is not out of the question that we may reduce it to a subdivision which would have the least impact but to do that, we would have to get the FLU change.

**Scott Miller**: Probably best not to tell anyone specifically what we are doing. Just that we are going for the least impact option. One way or another we are going to make use of the property.

**Scott Miller**: The way things are now kind of boxes us in to an option that they will probably like the least.

**Jeff Bergosh**: Thanks for that information and I will keep that close-hold

### CONVERSATION ON 12-05-2019

**Scott Miller**: So from agenda rundown, it looks like that pine forest thing is just gonna roll through this meeting at least. 

Do you think there is a chance that it won’t make it at least to the next meeting?

Trying to figure out if I need to come to the meeting. 

### CONVERSATION ON 12-06-2019

**Scott Miller**: You sounded great on channel 3.

**Jeff Bergosh**: Thanks Scott

### CONVERSATION ON 12-25-2019

**Scott Miller**: 
Merry Christmas 

**Jeff Bergosh**: Merry Christmas

### CONVERSATION ON 01-02-2020

**Scott Miller**: Hey man, Happy New Year!!!

**Scott Miller**: We are looking forward to next weeks commission meeting and wanted to know if there are any people who have expressed significant concerns about our FLU application on Pine Forest Rd that you think we should have direct contact with.

**Scott Miller**: Anyone that you could connect us to would be great.

**Jeff Bergosh**: Hey Scott—Happy New Year to you as well!!

**Jeff Bergosh**: Call me when you have a moment

**Scott Miller**: I think that we have probably addressed the road safety concerns through our meetings with FDOT. They are requiring that we install Decel and turn lanes on Pine Forest AND gated and coded access on Mandeville that is RESTRICTED to emergency services.

### CONVERSATION ON 01-03-2020

**Scott Miller**: Yesterday when we spoke you mentioned something about the Pine Forest property being in your “study area”. Which study are you referring to?

**Jeff Bergosh**: NW District 1 Advisory Committee

### CONVERSATION ON 01-07-2020

**Scott Miller**: Can we be called upon last?

**Jeff Bergosh**: That will be up to the chairman

**Jeff Bergosh**: But I’m sure he’ll accommodate the request

### CONVERSATION ON 01-08-2020

**Jeff Bergosh**: Thanks Crain

**Scott Miller**: Call me when you have a minute.

