

## CONVERSATIONS WITH TYLER MARSH

### CONVERSATION ON 11-18-2019

**Tyler Marsh**: I like your vibe Grandma... we gotta get back to you on the other stuff... 

### CONVERSATION ON 02-11-2020

**Tyler Marsh**: Terrible 

**Tyler Marsh**: So no paddle boarding?

### CONVERSATION ON 02-12-2020

**Tyler Marsh**: I hope the island breezes are nice, and your pina coladas are full...

**Tyler Marsh**: I just cant wait to hear about your next trip...  pardon the pun...

**Tyler Marsh**: Yes, smart ass... 

**Tyler Marsh**: As it should be, approaching V Day

### CONVERSATION ON 02-13-2020

**Tyler Marsh**: Everyone should pray for Grandma's equilibrium and balance to be made whole again, we know she will heal from the bumps and bruises... 

### CONVERSATION ON 03-25-2021

**Tyler Marsh**: I'm on my last shots of our Jager... so we will need to start fresh when I see you in Alaska...

**Tyler Marsh**: Getting Alaskaned early...

**Jeff Bergosh**: LOL

**Jeff Bergosh**: #Ready

**Tyler Marsh**: Angiyok!!!

https://thevore.com/eskimo-english-dictionary/

