

## CONVERSATIONS WITH CREIGHTON JORDAN

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Right on!  Thanks so much for the call and the support!!

### CONVERSATION ON 04-16-2021

**Jeff Bergosh**: Hello Creighton I have funded the phase 1 design I’ll get a status update ASAP

**Jeff Bergosh**: I’ll see what we can do.  What is the address again?

**Jeff Bergosh**: And I’ll ask staff to assess and assist

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Creighton: just checked on the project.  100% plans were just completed on 4-9.  Actually a 5-phase project.  Phase 1 short of funding by about $109K phase 2 short of funding by $360K.  I’m working the plan to get them both funded for execution in May

**Jeff Bergosh**: I’ll request copies

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: Good morning Creighton.  I forwarded the 100% plans to you Saturday morning— just making sure you got them and my email

