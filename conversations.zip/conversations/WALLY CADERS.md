

## CONVERSATIONS WITH WALLY CADERS

### CONVERSATION ON 01-06-2021

**Jeff Bergosh**: Hey Wally! it was great talking to you today. thank you so much for taking time to talk to me and educate me about the different kinds of stone that we can do our kitchen with. I’m attaching Gary Crawley‘s contact information here because he is the guy that’s building our cabinets and our island. I appreciate you helping coordinate this and Sally and I will come by to pick out the quartz for the countertops. Thanks again Wally!

Jeff Bergosh

