

## CONVERSATIONS WITH GIB LOVETTE

### CONVERSATION ON 07-18-2020

**Jeff Bergosh**: Thank you Gibb—-I’m so proud of him too!!  He will always do the right thing as Willie regardless of who gets mad about it!!

**Jeff Bergosh**: Thanks Gibb— I agree.  And any other Judge might have done just that!  But thankfully Gary understands the national historic preservation act and I believe he probably realizes that the tenants of that law we’re not followed. So he was the perfect judge to get this at the perfect time. I believe Grover Robinson in the city we’re going to tear that thing down this weekend and he put a stop to that!

**Jeff Bergosh**: I agree Gibb.  I am one of them!

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: Thank you so much Gibb!!!

**Jeff Bergosh**: I know and I’m so thankful for you all!! You have been there for every election—I’m so thankful!

