

## CONVERSATIONS WITH TERI AULGER

### CONVERSATION ON 01-27-2020

**Teri Aulger**: These are some of the awards that Dennis earned representing the county at mechanical international competitions over 32 years.  Fyi he is in ICU with several bloodcots as a side effect of the chemo last week.  So far so good though.  His drop  earned him 62,000...but he were not forced out early it would have been 140,000.  
He would accept 12,000...he said the 10,000 could have been when he talked to Ackerman while on meds...it is possible. But with what he lost through drop...and the value of the tools...
Thank u

**Jeff Bergosh**: Sorry to hear about his condition and I understand about the money.  Thank you for letting me know.

**Teri Aulger**: Thank u...trying to clear those with medications...holding his own and good spirits.  But it would be wonderful to have this behind them.

### CONVERSATION ON 02-10-2020

**Teri Aulger**: My brother in law passed away last night...anyway we can get this tool issue completed would be great for my sister to not deal with this.

**Jeff Bergosh**: Teri I am so sorry to hear that I will mention it today I have a meeting with administrator Gilley at 4 o'clock and I will mention this and try to get it resolved again very sorry to hear that

**Teri Aulger**: Thank you...we appreciate it. My sister Sherri Rigby is a planner and I am sure she would like this off of her plate. 

**Jeff Bergosh**: Got it.  I'll let you know what comes of this.

**Jeff Bergosh**: .....the meeting at 4:00 today I mean

**Teri Aulger**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-17-2020

**Teri Aulger**: Could you give me a call when you have a moment

### CONVERSATION ON 02-18-2020

**Teri Aulger**: So sorry to bug you one more time before Wednesday's meeting  thought this could help. Dennis had 1700+ hours of sick leave which he of course forfeited half of that when he left. He also had annual leave of 85 hours and 10 hours floating holiday.  Had he been allowed 12 weeks of FMLA as the law allows  he would have been able to use 480 hours of that forfeited sick time. That 480 with the annual leave and floating holiday equals 575 hours that he could have been paid which would be $12,977.  Sherri is asking for 3,500.00 more than offered....
Sherri Rigby's # 554-2910. 
You can call her tonight if you would like...or if you didnt mind.  May make her feel good knowing someone cares.

**Jeff Bergosh**: I will call her-- thanks for this additional insight and information

### CONVERSATION ON 02-26-2020

**Teri Aulger**: This Friday night at 6pm we are going to Elpaso on Mobile Hwy to celebrate my "officially old man"!! Todd is turning 50!  Come join if you can!

**Teri Aulger**:  I would guess 6-7... Probably arrive about 6:05

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: Thx Rick!

**Jeff Bergosh**: Good morning Terry-- Hope all is well with you all!  I have a question for you: I am going to be replacing my air conditioning unit and the air handler unit in 2-C. In our condo at the beach (Tristan Towers) and am wondering if you could help me get in contact with an estimator/installer at air design systems who could give me a quote for this work and a realistic installation timeframe.  Thanks very much Terry!

R/

Jeff Bergosh

**Teri Aulger**: Of course! You can call Tony Sprouse at 850-232-6194.  Or I can have him call you.  He will probably need to come look at unit for size limitations of the air handler. Condo closets are usually smaller than household units.

Let me know if you want to call him or if you want him to call you.

I will make sure he gives you a friends and family discount. 

**Jeff Bergosh**: Thank you Terry!! I greatly appreciate it!!  I'll call him rn

**Teri Aulger**: He is really good!

**Jeff Bergosh**: He already responded to my call and we've got them set up to come out tomorrow and give me the estimate thank you so much!

**Teri Aulger**: Anytime.

