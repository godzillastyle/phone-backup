

## CONVERSATIONS WITH ROBERT FORESTER

### CONVERSATION ON 05-18-2020

**Jeff Bergosh**: They have been begging us for a transfer station but we have not approved it as of yet.  

