

## CONVERSATIONS WITH DOUG ARD

### CONVERSATION ON 01-28-2021

**Jeff Bergosh**: Hey Doug I see that you've called I'm in meetings today but I am checking on the issue I'm going to see where staff is with i.  as soon as I get information you'll be hearing from someone from my office

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-29-2021

**Jeff Bergosh**: Got it

### CONVERSATION ON 02-03-2021

**Jeff Bergosh**: I'll send it in to staff again.  They've been overwhelmed with illegal dumping

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Debris along Blue Angel getting picked up this morning

