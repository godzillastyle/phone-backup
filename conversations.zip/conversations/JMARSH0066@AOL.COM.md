

## CONVERSATIONS WITH JMARSH0066@AOL.COM

### CONVERSATION ON 03-28-2020

**Jeff Bergosh**: Nope, not to my knowledge.  

