

## CONVERSATIONS WITH WILLIAM NORTH ESCAMBIA

### CONVERSATION ON 11-05-2019

**William North Escambia**: Hey! Next message is from a reader. State problem? I would think, but wanted to pass along.

**William North Escambia**: ---reader submitted -- "There is no warning on Mobile Hwy that you are approaching Beulah Elementary. The County needs to put a warning on the pavement and a sign School Zone Ahead. The traffic on Mobile Hwy is going 55 mph before and after the tiny little flashing sign. Do this BEFORE a tragic accident happens!" 

**Jeff Bergosh**: Thank you William--it is but I'm going to send it to our roads folks so they can get a jump on it as this is a safety issue.  I appreciate the heads up!  Jeff B

**William North Escambia**: Thanks!

### CONVERSATION ON 01-03-2020

**William North Escambia**: Give me a call at your convenience ref 9 mile i10

**William North Escambia**: FDOT made me a map. 🙂

**William North Escambia**: But I had already made my own and posted

**Jeff Bergosh**: Thanks William!

### CONVERSATION ON 02-24-2020

**William North Escambia**: In case you missed it...  http://www.northescambia.com/2019/07/eight-foot-alligator-captured-near-bratt-highway-with-video

**William North Escambia**: If it's the same alligator trapper called to Beulah as did this one in Bratt, it will be relocated to Molino

**William North Escambia**: Guy has like an alligator farm/refuge (but don't post/spread that info -- he likes to keep that quiet to keep curious people away for obvious safety treason)

**William North Escambia**: *reasons

**Jeff Bergosh**: That's good to know-- thanks for the heads up William.  Glad they are not going to kill him

**William North Escambia**: The trapper says they do not...unless it's injured or has some extreme health problem. 

### CONVERSATION ON 03-12-2020

**William North Escambia**: Really disappointed that CMR decided to cut the live feed for the press conf. this morning. That should have been aired/streamed. I thought for sure that would be streamed especially with potentially vital information being shared.

**Jeff Bergosh**: I agree with you and I thought it was streamed I had no idea they were going to cut the feed and I think it was a big mistake I've had several emails about it

**William North Escambia**: I presumed commissioners thought it was since it came back with no mention of Eric and went into next item.

**Jeff Bergosh**: What a shame--it was a food press conference with good questions and answers from Malcolm Thomas, Mayor Robinson, and County Staff Members.  Sorry this ball got dropped

**William North Escambia**: I just talked to Janice and she said she knew it was not being streamed because CMR didn't have a microphone over there hooked into the streaming system. which that could have been solved with the wireless mic. She said The pressure is being posted on YouTube in the next little bit

**Jeff Bergosh**: Okay good at least it will be up

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: Dr. Lanza will be the guest tomorrow morning

**William North Escambia**: My questions would be the things you want to know...how many tests have been given in Escambia County and how many results are back (The state dashboard only shows 118 as of Tuesday a.m. reported back to FDOH). Also now that the state is breaking down their reports and including positive cities like Cantonment, if there are positives in other postal cities/zip codes  like Pensacola Beach, Molino, Century, etc, will those locations appear? Or is some system of broader geographic areas being used by FDOH?

**William North Escambia**: Also, I'm inundated with people who say they have all the symptoms and are being denied tests because they did not travel, and they don't **know** if they had contact with a known positive?

**Jeff Bergosh**: Great questions!  I'll ask them both William

### CONVERSATION ON 04-02-2020

**William North Escambia**: Somehow the county failed to live stream the press conference this morning on Facebook as announced. Disappointing. 

**Jeff Bergosh**: Wow!  That's really disappointing. 

**Jeff Bergosh**: Sorry about that William-- we need to do better!

**William North Escambia**: follow up -- the presser does appear now and says "was live". IDK why it did not appear when it was actually live. View low view count and zero realtime comments would seem to indicate that others were not seeing live either. 

**William North Escambia**: sorry for multiple messages -- just noticed it was NOT broadcast live on the county's facebook page. it was broadcast live on the "Escambia Cmr", which is a personal Facebook page with five friends. That was reposted to the county page after it ended.  

**Jeff Bergosh**: Oh, okay.  Well that explains it.  They had their Facebook on the wrong account probably

**William North Escambia**: Looks that way. I didn't know the Escambia Cmr personal page existed. The county page is the one that was linked in the presser announcement. 

**William North Escambia**: Happy Birthday! 🙂 \

### CONVERSATION ON 04-03-2020

**Jeff Bergosh**: Thanks William!

### CONVERSATION ON 04-10-2020

**William North Escambia**: FYI...I'm joining the call to make the local SITREP available to the public again, even if that means a special BOCC meeting if you would like to make comment about the report or chance of meeting.

### CONVERSATION ON 04-11-2020

**Jeff Bergosh**: Thanks William!  I think it was a HUGE mistake for Janice and Alison to suddenly, inexplicably determine our SITREP is now exempt from release.  What are we hiding, and why?  I think it goes against the board's guidance of maximum transparency during this crisis.  I think the board will meet and staff will walk this bad decision back. Folks want information, and the minute we stop being forthcoming with it--we'll be sowing fear, anger, mistrust, and disdain among our constituents---and I don't want any part of that! 

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/bringing-restaurants-to-beulah.html?m=1

Positive news for COVID-19 weary community 🙂

**William North Escambia**: I saw this earlier and got busy on weather stuff. I think it's a great idea! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-26-2020

**William North Escambia**: Getting a lot of questions about the food trucks...do you know which trucks are participating?

**Jeff Bergosh**: Not yet, I'm pretty sure it will be a first come, first serve basis.  I will try to find out tomorrow morning when the office opens and post something on it

**William North Escambia**: pic was posted our FB wall so I didn't know if that was final list. thought there might be more. If you go by there tomorrow, can you snap a few pics of the trucks please

**Jeff Bergosh**: I will-- and I'll forward them to you

### CONVERSATION ON 04-28-2020

**William North Escambia**: AL Gov Ivey just announced stay at home ends 4/30  with limits. Beaches reopen.   https://www.al.com/news/2020/04/gov-kay-ivey-press-conference-on-plans-for-reopening-alabama-watch-live.html

**William North Escambia**: Going well today (reader submitted)

**Jeff Bergosh**: Outstanding!!!! Glad to hear that William!!!

### CONVERSATION ON 07-03-2020

**Jeff Bergosh**: Have a great 4th of July!

**William North Escambia**: received this...was there another message in there, or just a Happy 4th? 

**William North Escambia**: I appreciate the Happy 4th wish regardless 🙂

**Jeff Bergosh**: It was a blog post

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/?m=1

**William North Escambia**: received this...was there another message in there, or just a Happy 4th? 

**Jeff Bergosh**: That's odd. It won't let me link my latest blog post so I don't know what's going on with that. But my latest blog post is an issue we decided last night that's very interesting for citizens it is a searchable employee wage database.  Take a look at my blog I think you'll find it to be very interesting.

**Jeff Bergosh**: And have a great Fourth of July!

**William North Escambia**: salary database...just went and found it. Nice. 

**William North Escambia**: I have not pulled up a map yet...I know D1 approaches Hwy 29 south of I-10....does it go all the way to the east side of 29? Just talking to man upset that Escambia County denied him a biz license by/near the Harley store

**William North Escambia**: sorry *west side of 29

### CONVERSATION ON 08-19-2020

**William North Escambia**: Surprise! It's another congratulations message blowing up your phone! But congratulations! 3 for 3 on returning commissioners is a good thing. 

**Jeff Bergosh**: Thanks William!  I look forward to it!!

### CONVERSATION ON 02-23-2021

**William North Escambia**: Call me please

### CONVERSATION ON 04-28-2021

**William North Escambia**: Running a story about the new Publix that opened this morning with a focus on it being the first grocery story in Beulah.  You want to be included with any kind of statement?

**Jeff Bergosh**: Sure-- thanks William!

"We are excited to see The new Publix Supermarket open in District 1's Beulah community today.  We welcome them!  This shopping center --to include what will eventually be nine additional out parcels on the property with multiple restaurant and retail options for our area---will be a fantastic addition to the community"  

**William North Escambia**: Thanks. I haven't been yet, but have photos. Looks like a nice store. My almost OCD finds the perfect produce section calming. 🙂 

**Jeff Bergosh**: LOL that is calming!  I haven't been there yet either which is kind of curious because when they open the last one in East Hill they made a big deal about it and invited all of us the mayor and the council the commissioners and we all were there. This time around no invites so I guess they wanted it to be low-key

**William North Escambia**: I guess. I'd been bugging their PR people for a couple of weeks about a ribbon cutting, etc.   Never got a real answer.

### CONVERSATION ON 06-07-2021

**William North Escambia**: Any comment on the Childer's back hallway conversation email ? 

**Jeff Bergosh**: Thanks William- but there's really nothing to respond to or add to.  My blog post on this topic from early this morning is my complete statement on this matter.  👍

**William North Escambia**: OK thanks. Had not seen the blog post yet. 🙂

### CONVERSATION ON 08-27-2021

**William North Escambia**: On the Beulah Middle walkway news release, it states "With the explosive growth in the northwest portion of Escambia County".....Walnut Hill,  Nokomis an the others in northwest Escambia County are growing, but not explosively. 🙂

**William North Escambia**: Beulah Middle School is in southern Escambia County, not northwest. 😉  It's in the northwest Pensacola area perhaps

**William North Escambia**: Just FYI (I had to pick at you....)

**Jeff Bergosh**: LOL you're right William

**Jeff Bergosh**: I should've said the Northwest part of district one

**William North Escambia**: Like I said, I'm just picking.  You know NorthEscambia.com covers kind of Nine Mile north, plus adopting the rest of Beulah. Just tell someone that International Paper is in southern Escambia County and see what they say (but it is)

**William North Escambia**: The geographic north-south center of the county is Quintette Road. 

### CONVERSATION ON 01-07-2022

**Jeff Bergosh**: I'll let them know you're gonna call

**Jeff Bergosh**: Hey William hope you're having a great Friday morning. I wanted to let you know I really appreciate you running the Beulah fire station timeline chronology story. I greatly appreciate you covering that. I'm just curious why you didn't mention that you got that from my blog? Also just curious why you didn't at least paste a link to my blog post on the topic on your news piece? Just curious about that let me know thanks!

**William North Escambia**: "Bergosh wrote" should hae said "Bergosh wrote on his blog" and has been updated. That was an absolute oversight on my part. I would not normally link a statement like that to the blog or other source info, unless there was tremendous additional info there that would further explain the story. "Sheriff Chip Simmons said on Facebook", for instance, would not normally be linked back to FB. But if the FB post had tons of backup documentation,  it probably would be. I think that's a pretty standard way of doing for most news outlets.

**Jeff Bergosh**: Thanks William!! I appreciate that!!

**William North Escambia**: As you know, I normally call you. But it was late when I wrote it and really was just a short, sweet and to the point kind of thing. Glad to see it progressing!

**Jeff Bergosh**: Me too!

**William North Escambia**: Feel free to call or text when you have good news like that. I check the blog from time to time but it might be a few days in between visits

**Jeff Bergosh**: Will do William-- have a great weekend

**William North Escambia**: You too! 

