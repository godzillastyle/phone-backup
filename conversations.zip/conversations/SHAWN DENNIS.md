

## CONVERSATIONS WITH SHAWN DENNIS

### CONVERSATION ON 03-03-2021

**Jeff Bergosh**: Hey Shawn thanks for providing that data so quickly. Can you refresh my memory what is the definition of the permanent capacity is that the number of fixed student stations in a particular school?

**Jeff Bergosh**: Okay thanks

