

## CONVERSATIONS WITH LT. JIM ALLEN B-WATCH BELLVIEW FIRE LT

### CONVERSATION ON 12-30-2019

**Jeff Bergosh**: Thank you very much Jim.  Tough day for us losing our Rocky.  Thank you for the kind words and thoughts.  

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: I'm in a BCC meeting I will call you back

### CONVERSATION ON 01-08-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

