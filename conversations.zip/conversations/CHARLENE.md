

## CONVERSATIONS WITH CHARLENE

### CONVERSATION ON 12-25-2020

**Jeff Bergosh**: Thanks Charlene!

