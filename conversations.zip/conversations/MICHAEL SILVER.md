

## CONVERSATIONS WITH MICHAEL SILVER

### CONVERSATION ON 04-25-2020

**Michael Silver**: Just sent email with some of our info ; thanks again!

### CONVERSATION ON 04-27-2020

**Michael Silver**: Mr Bergosh I got the letter, thank you so much. We shootings to announce today! I'll send you an email with all the assets before we do!

**Jeff Bergosh**: Awesome!! Good luck!!

**Michael Silver**: Thank you sir!

**Jeff Bergosh**: 👍

**Michael Silver**: just sent you over the proposed flyer, FAQ, and schedule. I’m waiting on licensing to confirm before we can announce the exact movies, but wanted to get you things first so that everything was run past you

**Jeff Bergosh**: Thanks Michael

**Michael Silver**: No prob thank you sir. We are probably going to show Coco and Selena in Cinco de Mayo too but haven't confirmed !

**Michael Silver**: what do u think


**Michael Silver**: Tues is cinco de mayo

**Jeff Bergosh**: Looks great!

**Michael Silver**: May the fourth be with you !

**Jeff Bergosh**: LOL right!

**Michael Silver**: We will be the only way to celebrate !

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Hey Michael—Channel 3 is going to do a story on your pop-up drive in.  I gave your cell number to Jennifer Munoz from Ch 3.  She will definitely want to do a story!

**Jeff Bergosh**: Extra free publicity for you!

**Michael Silver**: Right on! She just called me I'm gonna get with her today!

**Michael Silver**: Loved “Extra free publicity for you!”

**Jeff Bergosh**: 👍

**Michael Silver**: Thank you!!

**Michael Silver**: Your post got a ton of shares I love how you wrote and shared the plans 

**Jeff Bergosh**: thanks for the compliment— my blog post on this topic got crushed!

**Michael Silver**: Loved “thanks for the compliment— my blog post on this topic got crushed!”

**Michael Silver**: It was great to see so many shares !!! We got Pensacon on board to help push our Star Wars event Monday too! You are invited to any showing anytime we are open you and or whoever, just let me know anytime we will get you taken care of! Thanks again !!

**Jeff Bergosh**: No problem.  One request if I might-would you mind inviting a PTA president to one of the screenings?  She does a lot of good in the community.

**Michael Silver**: Absolutely. Anyone , anytime, whatever you need ! 

**Michael Silver**: I'll wait til it gets a little later then give her a call!

**Jeff Bergosh**: Thanks a lot Michael—she was really excited about it and she reached out to my wife to see if she could get on a list to come to a screening.

**Michael Silver**: Loved “Thanks a lot Michael—she was really excited about it and she reached out to my wife to see if she could get on a list to come to a screening.”

**Michael Silver**: What school is she at?

**Jeff Bergosh**: Cordova Park

**Michael Silver**: My alma mater 

**Jeff Bergosh**: Small world 😎👍

**Michael Silver**: Going to the fair to be interviewed at 0945!

**Jeff Bergosh**: Awesome!! Good luck!

**Michael Silver**: Welcome to join me if you'd like 😁

**Michael Silver**: Thank you sir

**Jeff Bergosh**: In meetings but she is going to interview me separately—and of course I’ll voice strong support.  Please do me a favor and print a copy of the letter that I sent you and show it to Jennifer so that she can have it for the Broadcast

**Jeff Bergosh**: .... the letter Showing the support from my office for this initiative

**Michael Silver**: Got it in my back pocket. 

**Jeff Bergosh**: Awesome thanks Michael

**Jeff Bergosh**: 👍

**Michael Silver**: That's from a thousand feet back

**Jeff Bergosh**: Wow

### CONVERSATION ON 04-30-2020

**Michael Silver**: we made the front page ! 


**Jeff Bergosh**: Way to go Mike!!! By the way— The Facebook post got shared 800 times and my blog got crushed with thousands of hits ——so I think you’ve got a a lot of people looking forward to your drive-in!!  Good luck!!

**Michael Silver**: Appreciate you believing in me and helping make thisnhappenn when so many others wouldn't 

**Jeff Bergosh**: I’m rooting for you!!!!!

### CONVERSATION ON 05-06-2020

**Michael Silver**: Thanks for having me !!!!

**Jeff Bergosh**: Michael—thank you so much for joining us this morning!! It was great to hear about how you are doing.  Good luck and I’ll see you up there!!

**Michael Silver**: Loved “Michael—thank you so much for joining us this morning!! It was great to hear about how you are doing.  Good luck and I’ll see you up there!!”

**Michael Silver**: Thank you sir !

**Michael Silver**: i thought this was really cool to see, i figured you would as well. We changing lives out here...

**Jeff Bergosh**: Nice!

**Michael Silver**: Loved “Nice!”

### CONVERSATION ON 05-16-2020

**Michael Silver**: Mr Bergosh just wanted to share that we got featured on ABC national news !!!
Here's a link to the video

**Michael Silver**: https://youtu.be/oLF3vO8vciM?t=159

**Jeff Bergosh**: That’s awesome Michael!!! Congratulations!!

**Michael Silver**: Loved “That’s awesome Michael!!! Congratulations!!”

**Michael Silver**: Thank you!

### CONVERSATION ON 06-13-2020

**Jeff Bergosh**: Hello Michael— It’s Jeff Bergosh.  I hope all is well with the pop-up movie tour!  I have a quick question for you if you have a minute to chat.  Thanks!  Jeff B

**Michael Silver**: Hey Jeff ! Sounds great, it's going good we are closing out this weekend in Pensacola. I'm on hold with ATT about my internet that's been down 2 days now then I'll give you a buzz !

**Jeff Bergosh**: Okay thanks!

**Jeff Bergosh**: Thanks Michael!

I’m thinking something like this:

“When we established the pop-up drive in movie tour concept we started it in Escambia county in District one at the fairgrounds. We needed a little help from the county—so I contacted District 1 Commissioner Jeff Bergosh at his office —-and he quickly provided me the assistance I needed to get the business off the ground. His assistance and the assistance of his office were vital to the tremendous success we achieved opening up this concept in the Pensacola area—so I’m thankful for Jeff’s help getting the pop-up drive-in movie tour started.  He is a guy that understands small business, and I believe he does a great Job for Escambia County.  He has my support in this election August 18th!”  —-Michael Silver  Escambia County entrepreneur, small business owner, and founder of the Pop-Up Drive-in Movie Tour 2020

**Michael Silver**: That works for me ! I could add some stuff in but that is perfect. Sending back to you so you have it from me

**Michael Silver**: Thanks Michael!

I’m thinking something like this:

“When we established the pop-up drive in movie tour concept we started it in Escambia county in District one at the fairgrounds. We needed a little help from the county—so I contacted District 1 Commissioner Jeff Bergosh at his office —-and he quickly provided me the assistance I needed to get the business off the ground. His assistance and the assistance of his office were vital to the tremendous success we achieved opening up this concept in the Pensacola area—so I’m thankful for Jeff’s help getting the pop-up drive-in movie tour started.  He is a guy that understands small business, and I believe he does a great Job for Escambia County.  He has my support in this election August 18th!”  —-Michael Silver  Escambia County entrepreneur, small business owner, and founder of Drive-In Dudes & the Pop-Up Movie Tour!

**Michael Silver**: Just changed the title at the bottom 

**Michael Silver**: I'm not sure if you want to say something about me graduating from Florida west and exhausting every contact I had before cold calling your office and getting immediate help

**Michael Silver**: Everyone and everywhere else shut me down til you took a chance on me ; that I will not forget !!!

**Jeff Bergosh**: Thank you very much Michael!!!  Good luck to you in Gainesville and Fort Walton!  And thanks for editing that with the right name of your company!

**Jeff Bergosh**: Thank you for that!!

**Michael Silver**: Thanks man I'll definitely send you some pics of our future events !!

**Jeff Bergosh**: Please do!

**Michael Silver**: Please let me know if there's anything else I can do to help as the election draws near, events are my specialty

**Jeff Bergosh**: Will do— and thank you!

**Jeff Bergosh**: Oh— one other thing.  Can you send me your picture?  Like a headshot of you, that I can put next to the quote?  Thanks Michael!

**Jeff Bergosh**: Awesome!! Thanks!

**Michael Silver**: Screenshot from our abc news feature

**Michael Silver**: Or this one

**Michael Silver**: Your pick!

**Michael Silver**: Do you want me to get some numbers together for you? X number of tickets X number of jobs, charitable donations etc?

**Michael Silver**: Would be great for your blog if nothing else that we had a great run here and with your help we did all this and that

**Jeff Bergosh**: Yes that would be amazing I would love to do a post on that!! Thank you!!

**Michael Silver**: Cool I will try to work on that

**Jeff Bergosh**: Great!

**Michael Silver**: If you want to come out and take some pics with me and then team or something could be a cool photo op

**Jeff Bergosh**: I’ll do that.  Is there a time you’ll be out there?

**Michael Silver**: We're doing drive in wrestling today at 4... it's going to be a shitshow, I'll be there about 430 ish and we start playing twister at 8pm today (:

**Jeff Bergosh**: Okay I’ll stop by and say hello!

### CONVERSATION ON 08-10-2020

**Michael Silver**: Just wanted to send this your way in case you were a Metallica fan!

**Michael Silver**: https://www.facebook.com/events/576735223001804/

**Jeff Bergosh**: Wow!!! Hell yes I love Metallica!!

**Jeff Bergosh**: I’m going Michael!! Are tickets on sale yet?

**Michael Silver**: Not yet onsale, I get a couple comps. Let me save you one

**Jeff Bergosh**: That would be amazing!!! Thank you Michael!!

**Michael Silver**: Count on it!

**Jeff Bergosh**: 😁😁😁😁

**Michael Silver**: also - i shared your post, and got this awesome comment

**Jeff Bergosh**: That’s fantastic— thank you for that!! Every vote counts!!

**Michael Silver**: Hey this one is you bro! thank you for all the help.

**Jeff Bergosh**: Thank you so much!!!!

**Jeff Bergosh**: 👍👍

**Michael Silver**: Mark your calendar, and contact me closer to the date! I’ll save ya a ticket, just remind me!

**Jeff Bergosh**: Will do it— that will be a great concert!!!

**Michael Silver**: Yessir ! It will be a one-night video concert I am looking forward to it...

### CONVERSATION ON 08-18-2020

**Michael Silver**: Congratulations !!!!!!!!! 

**Jeff Bergosh**: Thanks Michael!!!!!

### CONVERSATION ON 08-25-2020

**Michael Silver**: Hey Jeff do you think you'll make it to Metallica this sat 8/29?

**Michael Silver**: Want to get you a ticket if so

**Jeff Bergosh**: Yes!  Can I buy a ticket from you?

**Michael Silver**: I got you one of my comps 

**Jeff Bergosh**: Awesome!!!! Thank you!!

**Jeff Bergosh**: I can’t take anything over $100 in value— so if it’s more than that I’ll pay you the difference.  Is that cool with you?

**Michael Silver**: yea man

**Michael Silver**: https://www.universe.com/embed2/events/5f2dd3e92e913426d74fc606?state=%7B%22accessKeys%22%3A%5B%2223H7N1%22%5D%7D

**Michael Silver**: 23H7N1

**Michael Silver**: This is the link i think it becomes active day of

**Jeff Bergosh**: Outstanding thanks Michael!

**Jeff Bergosh**: So I go in and punch in that code the day of?

**Michael Silver**: yeah i think so

**Michael Silver**: and if any trouble just let me know

**Jeff Bergosh**: Will do——really looking forward to this!!!

**Michael Silver**: going to be great!

### CONVERSATION ON 08-29-2020

**Jeff Bergosh**: Hello Michael— on the site but I don’t see a place to punch in the code

**Michael Silver**: Let me check

**Michael Silver**: I got to get to a computer but promise u r all good and set for the event !

**Jeff Bergosh**: Awesome thanks— just let me know what I need to do— greatly appreciate it

**Michael Silver**: Just texted you your ticket 🤟🏼

**Michael Silver**: sorry i mean emailed, i emailed to ur gmail

**Jeff Bergosh**: Thank you Michael!!

**Jeff Bergosh**: Guess where I am!!  I’m stoked for this show tonight Michael!!!!

### CONVERSATION ON 08-31-2020

**Michael Silver**: Sorry I missed this thay night - was a great event 

**Michael Silver**: Give me a call whenever you get a sec no rush 

**Jeff Bergosh**: It was amazing!

**Jeff Bergosh**: Will call u in 5 min if that’s cool

**Michael Silver**: No prob 

**Jeff Bergosh**: It was great talking to you.  Please send the invoice to:

Jeffbergosh@gmail.com

**Michael Silver**: Roger !

### CONVERSATION ON 09-18-2020

**Michael Silver**: Jeff - checking into you guys and seeing how you fared against the storm 

**Jeff Bergosh**: Thanks Michael yes we did okay—-minimal damage no water no structural just lots of trees down how about you?

**Michael Silver**: We did O

**Michael Silver**: OK!

**Jeff Bergosh**: Good! Others not so fortunate

**Michael Silver**: I am over here in Louisiana we have a contract with the Army Corps doing the Operation Blue Roof ... a totally free program for homeowners to get roof tarps applied

**Michael Silver**: I thin its really needed in Pensacola

**Jeff Bergosh**: Cool!  We’re gonna need you over here next

**Michael Silver**: but i heard they weren’t going to activate it

**Jeff Bergosh**: That’s a shame because I know some folks need it

**Michael Silver**: bc there hasn’t been governmental requests or something

**Michael Silver**: I figure i would send u some info about it

**Michael Silver**: https://www.mvn.usace.army.mil/Missions/Emergency-Operations/Blue-Roof-Information/

**Jeff Bergosh**: Please do I’ll make the request!

**Michael Silver**: Its really needed over there.

**Michael Silver**: My understanding is that the Goverenment has to make a request to FEMA for the program. but its free for homeowners its a great program it is paining me to be over here doing this in Louisiana when so many in Pensacola need it

**Jeff Bergosh**: I’ll ask the county administrator about it

**Jeff Bergosh**: We’re supposed to have a special meeting tomorrow at some point

**Michael Silver**: It can help so many people

**Michael Silver**: I have had homeowners come to me crying thanking us for helping save their house

**Michael Silver**: because all these roofing companies cant get to people fast enough, and we are in a very poor area here where a lot of these folks dont even have insurance

**Michael Silver**: if u have any questions about the program or need anything reach out to me, we’ve done over 300 houses over here just my company alone

**Jeff Bergosh**: Will do Michael

**Michael Silver**: thanks for the reply and glad u r all ok

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-20-2020

**Michael Silver**: Awesome work on getting the tarps in just saw your post 

**Jeff Bergosh**: Thanks Michael we’re trying to get the tarp installation program initiated as well

**Michael Silver**: Let me know if I can help. The prime contractor is also located in Pensacola (ESA South) 

**Michael Silver**: Free tarps are amazing; but I get messages like this on my work orders all day....

**Jeff Bergosh**: Yes— some folks can’t get on a roof to install them.

**Michael Silver**: I would venture to say most folks ! I could do this stuff 

**Michael Silver**: https://twitter.com/usacehq/status/1305862432397471745?s=21

**Michael Silver**: This is actually one of my crews 

**Michael Silver**: That they came and filmed 

### CONVERSATION ON 04-02-2021

**Michael Silver**: Happy birthday my friend !

**Jeff Bergosh**: Thanks Michael!! Hope all is well!

**Michael Silver**: Thx you too! Opening drive in again next month!

**Jeff Bergosh**: Fantastic— can’t wait to check it out

**Michael Silver**: Will shoot you info as it comes out !

**Jeff Bergosh**: Please do!

### CONVERSATION ON 05-01-2021

**Michael Silver**: Heyo. We're opening the new drive in tonight I wanted to give you free tickets .1 tickets good for the whole car. This works for showings tonight! 745pm Ghostbusters (1984) and 1015 the goonies use code micopeco at www.timewarptheaters.com

**Michael Silver**: We've got Bon Jovi video concert 5/22 as well!

**Jeff Bergosh**: Michael—Thank you very much but I’m actually in New Orleans for the weekend good luck tonight hope you hope it goes really well!

**Michael Silver**: Let me know anytime You want to check it out 

