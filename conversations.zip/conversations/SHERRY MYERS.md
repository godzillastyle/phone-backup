

## CONVERSATIONS WITH SHERRY MYERS

### CONVERSATION ON 01-12-2020

**Jeff Bergosh**: Jeffbergosh@gmail.com

### CONVERSATION ON 01-13-2020

**Jeff Bergosh**: Got them — very interesting stuff, thanks for forwarding and thanks for the call! 

