

## CONVERSATIONS WITH SHAWN DOMINGUEZ

### CONVERSATION ON 10-25-2019

**Jeff Bergosh**: Hey Shawn—we had a great turnout  sorry you couldn’t make it but CMART and his family came—and I appreciate you sending me a check!!! Thank you very much!!  I really appreciate your support!

### CONVERSATION ON 06-09-2021

**Jeff Bergosh**: Hey Shawn!  Hope all is well.  I’m on an all day resolicitation bye tour of the base for the BOS contract.  Can I call you this afternoon when I get back to my office?

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-05-2021

**Jeff Bergosh**: Of course Shawn— any time!  Call me when it’s convenient and I’ll try to assist

**Jeff Bergosh**: Patty Hightower

School Board D4

