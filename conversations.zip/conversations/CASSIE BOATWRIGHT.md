

## CONVERSATIONS WITH CASSIE BOATWRIGHT

### CONVERSATION ON 09-02-2020

**Jeff Bergosh**: Hi this is Jeff Bergosh trying to speak with you about the library in Bellevue. I attempted to leave a message but your mailbox is full please call me as soon as you can thank you

### CONVERSATION ON 10-21-2020

**Cassie Boatwright**: Do you have time to talk this evening?  

**Jeff Bergosh**: Yes

### CONVERSATION ON 10-22-2020

**Cassie Boatwright**: Good morning. I'll call you back as soon as this meeting is over. Shouldn't be too much longer. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: Hi Cassie-- can you forward by email any general county facility data you might have. (Total number of county owned facilities, total county-owned acres, total sf under roof)-- or any of thus type of information you have easily accessible.

Thanks!

**Cassie Boatwright**: I can get it to you. Do you need it for your 11:30 meeting?  I'll have to run to the back and pull it up for you. 

**Jeff Bergosh**: Yes if possible

**Jeff Bergosh**: Thank u!!

**Cassie Boatwright**: It's 2.7M not including parks but including some spaces that are not under air. 

**Cassie Boatwright**: I'll send it to you. 

**Cassie Boatwright**: Does that help?

**Cassie Boatwright**: That's 252 buildings

**Jeff Bergosh**: Yes it helped immensely!! Thank you so much!!!

**Cassie Boatwright**: Sure thing. I hope the presentation went great!

**Jeff Bergosh**: It did-- thank you!!

### CONVERSATION ON 01-22-2021

**Cassie Boatwright**: Good afternoon. Would you like to tour the jail next week, if it fits in your schedule?

**Jeff Bergosh**: Sure would!  Thanks for the invite!

**Cassie Boatwright**: Great. Should I just coordinate a good time with Debbie?

**Jeff Bergosh**: I actually have my calendar open in front of me.  Does Tuesday or Wednesday afternoon work?  Say 4:30?

**Cassie Boatwright**: I had to check with Chief Powell too. Wednesday at 4:30 will work well. I'll send an invite. Just let me know if anything comes up. 

**Jeff Bergosh**: Okay thanks-- it's on my calendar.  If it's alright, I'd like to bring my brother along as well, Judge Gary Bergosh and also Judge Tom Danheisser.  They are both circuit court judges here in the first judicial circuit

**Cassie Boatwright**: Certainly!  We will make sure they have the appropriate safety gear. 

**Jeff Bergosh**: Perfect!  Thanks Cassie!

**Cassie Boatwright**: Sure thing. Have a good weekend. 

**Jeff Bergosh**: You as well.

### CONVERSATION ON 02-17-2021

**Cassie Boatwright**: The contract is for 365 days for completion.

**Jeff Bergosh**: Thx

### CONVERSATION ON 02-18-2021

**Cassie Boatwright**: Give me just a bit. 

**Cassie Boatwright**: I can email you the link. I just wanted to get it to you now. That's from the county tax assessor's website. 

**Jeff Bergosh**: What does our appraisal say?

**Cassie Boatwright**: Let us check. 

**Cassie Boatwright**: County survey said 3.9 acres.  We will check the appraisal too. 

**Jeff Bergosh**: Oh well

### CONVERSATION ON 02-19-2021

**Cassie Boatwright**: Good morning. If you have a minute today, give me a shout about the appraisal please. 

**Jeff Bergosh**: Thanks will do

