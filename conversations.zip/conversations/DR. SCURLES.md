

## CONVERSATIONS WITH DR. SCURLES

### CONVERSATION ON 03-02-2020

**Jeff Bergosh**: Thank you very much Dr. Scurles

### CONVERSATION ON 08-03-2020

**Jeff Bergosh**: Hello Dr Scurles I'm in a meeting at the moment but I will call u when I'm out

### CONVERSATION ON 08-14-2020

**Jeff Bergosh**: Dr. Scurles I am sorry to hear that I truly am.  I certainly hope y'all can work it out amicably

### CONVERSATION ON 08-20-2020

**Jeff Bergosh**: Thanks Dr. Scurles!

