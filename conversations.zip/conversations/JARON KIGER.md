

## CONVERSATIONS WITH JARON KIGER

### CONVERSATION ON 11-08-2019

**Jeff Bergosh**: Jaron—I’ll be coming in a little bit late today probably right around lunchtime.  Let me know you got this

Jeff

**Jaron Kiger**: Ok. Dave was wondering when you would be in. He has to leave around lunch to meet a contract at his house. I’ll let him know. 

**Jeff Bergosh**: Okay thx.  No problem with Dave leaving early.

### CONVERSATION ON 11-22-2019

**Jaron Kiger**: Hey, looks like I must have submitted my time sheet on accident earlier this week. Can you unlock it for me? 

**Jeff Bergosh**: No problem Jaron I just returned it for correction. Let me know if it worked

**Jaron Kiger**: Yes sir, that worked. Thanks! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-03-2019

**Jaron Kiger**: Hey, I’m going to come in, and stay an hour late today.

**Jeff Bergosh**: Okay

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: I'm still in a meeting but I'm approving timesheets.  Need you to submit your sheets online

**Jaron Kiger**: Ok. I'm submitted 

**Jeff Bergosh**: Thx

### CONVERSATION ON 04-01-2020

**Jaron Kiger**: Any word from Tim and Heather? 

**Jeff Bergosh**: They’ll be in later this morning—possibly

### CONVERSATION ON 04-29-2020

**Jaron Kiger**: Good morning, do you need me to send out a daily attendance this morning? I didn’t get an email instructing me to do so.

**Jeff Bergosh**: Not needed thanks

**Jaron Kiger**: Ok. Sounds good

### CONVERSATION ON 06-04-2020

**Jaron Kiger**: Hey, I have an appointment at 8 this morning. It should be short and I’ll be in by 9. I’ll just take PTO.  Thanks

**Jeff Bergosh**: Got it.

**Jeff Bergosh**: Jaron—I’ll be out of the office this morning for some meetings, I’ll be back around lunchtime.

**Jaron Kiger**: Ok

### CONVERSATION ON 06-10-2020

**Jeff Bergosh**: Jaron I’m giving you two jobs to close where are you?

### CONVERSATION ON 06-23-2020

**Jaron Kiger**: Sacred heart said they wouldn’t test me cause I don’t have symptoms. I didn’t mater that I was around someone who was positive. They gave me the address of the place I went this morning.

**Jeff Bergosh**: Okay well so much for that idea!

**Jeff Bergosh**: Alright well let me know when you hear one way or the other.  Good luck.  I’ll check with Tony to see how  he wants me to account for your time

**Jaron Kiger**: Alright. Thanks. Escambia health department said they would be calling me every morning. So I can ask them tomorrow if there’s any way to get a faster test

**Jeff Bergosh**: Okay appreciate that

### CONVERSATION ON 06-25-2020

**Jaron Kiger**: Hey, I got a letter from the escambia heath department for my work. I can email it to you. What’s your email? 

**Jeff Bergosh**: Jeffrey.bergosh@pbss-llc.com

**Jeff Bergosh**: Any word yet on your status?

**Jaron Kiger**: No, word yet. I haven’t gotten my daily call from them yet either. 

**Jaron Kiger**: I’m feeling fine though. No symptoms

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-26-2020

**Jaron Kiger**: Should I enter it under FFCRA Emergency paid sick leave? 

**Jeff Bergosh**: Never mind I had the office take care of it

**Jeff Bergosh**: They will pay you normally and you won’t have to use your leave— it will be like what Heather is using.  Any word on your test results?

**Jaron Kiger**: No word on it. It took my girlfriend’s dad 9 days to get his negative results. But I’m still symptom free. Feeling fine. 

**Jaron Kiger**: They have a rapid test in Panama City, But they don’t have appointments open tell July. 

**Jeff Bergosh**: Glad you’re feeling okay- guess we will find out when we find out!  

Have a great Weekend!

Jeff B

### CONVERSATION ON 06-29-2020

**Jaron Kiger**: Hey, I just wanted you let you know Gary is texting me asking how I’m feeling. Did you tell everyone at the meeting this morning?

**Jeff Bergosh**: No

### CONVERSATION ON 07-01-2020

**Jeff Bergosh**: Good morning Jaron—any word yet on your status?  Please let me know so I can pass this along to Tony.

**Jaron Kiger**: Good morning—-I’m waiting to hear from the health department today. I think today might be my last day I need to quarantine. But I will let you know after I talk with them. They usually call around noon

**Jeff Bergosh**: Okay thanks Jaron.  You still feeling okay?

**Jaron Kiger**: Yes. I’m feeling fine. 

**Jeff Bergosh**: Glad to hear that

**Jaron Kiger**: I just talked to the health department. They said I’m clear to go back to work tomorrow. They said they would send me an email for my work. I’ll forward it to you.

**Jeff Bergosh**: That’s awesome—great news!

**Jaron Kiger**: And I called the health department and they looked up my test. It was negative. They should send me something in the mail. 

**Jeff Bergosh**: Jaron that is fantastic news I’m gonna call Tony right now and tell him and will see you in the morning and remember when you come back you don’t have to explain anything to anyone it’s your private business and nobody needs to know about your fiancé and nobody needs to press you so far as they all know you were on PTO

### CONVERSATION ON 08-21-2020

**Jaron Kiger**: Hey Jeff, I wanted to let you know what’s going on. Gary says he lost his sense of taste, so he is leaving early today and going to get tested at sacred heart. He’s going to take the rest of the day off. we are going wait and see if his condition gets any worse over the weekend, and decide if he should come in on Monday. 

Give me a call if you need more information.

**Jeff Bergosh**: Okay thanks for the heads up—- I hope he’s okay.  Do me a favor and let Tony Know as well.  Please let me know Monday if we have any more news on him.

**Jaron Kiger**: Will do. He seemed fine. He just wanted to be safe. I’ll tell Tony and update you on Monday.

### CONVERSATION ON 09-16-2020

**Jaron Kiger**: Hey, I just wanted to let you know I’m not coming in today. It’s way to rainy and windy to be out driving. I hope that alright

**Jeff Bergosh**: Absolutely Jaron— nobody is coming in today.  Stay safe!!

**Jaron Kiger**: Ok thank. 

### CONVERSATION ON 09-17-2020

**Jaron Kiger**: Liked “All-

I came to bldg 458 today to assess damage:  carpets throughout our spaces are soaked, map room has standing water, several sections of roof have been damaged and allowed for water intrusion.  Power and water are on, no visible damage  to anyone's computers, 1 of 2 ACs is functional, phones are inoperable and neither NMCI nor PBSS networks are up, and emails not working.  Two doors damaged (map room and side exit by my office) and are open but wedged shut with cinder blocks.  I'm going to see Mark Powell now about getting our spaces repaired and carpets pulled and/or vacuumed up.  I will keep you all posted with a follow on text and phone calls.  Be safe everyone.”

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: Jaron— If you are able to do so I need for you to submit your electronic timesheet so I can approve it

**Jaron Kiger**: I can, what should we put our time under for the storm? 

**Jeff Bergosh**: Is there an admin line on your timesheet?  If there is, use that.  If there isn’t just put it in under RCM engineer and they’ll have to fix it up in Huntsville

**Jaron Kiger**: I just put it in RCM. There was no admin. 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: You saved it, need to submit it

**Jaron Kiger**: Sorry. I fixed it 

**Jeff Bergosh**: Got it thx

### CONVERSATION ON 09-20-2020

**Jaron Kiger**: Hey Jeff, have you heard anything about our building? Is work back on for tomorrow?

**Jeff Bergosh**: Yep.  We are working tomorrow— we will have a meeting and Tony will call in and we will determine our schedules going forward based upon our facility condition and our ability to access our networks, emails, internet, etc.  0730 staff meeting.

**Jaron Kiger**: Ok. Sounds good. See you tomorrow

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-09-2020

**Jaron Kiger**: I just submitted it 

**Jeff Bergosh**: Thx

### CONVERSATION ON 10-15-2020

**Jaron Kiger**: Hey Jeff, I am planning on flexing my time tomorrow. I’ll be coming in at 8:30 and leaving at 5. I hope that is ok. Thanks!

### CONVERSATION ON 10-16-2020

**Jeff Bergosh**: Sure thing— no problem Jaron

**Jeff Bergosh**: Jaron- please submit your electronic timesheet so I can approve it.  Thanks!

**Jaron Kiger**: Done 

### CONVERSATION ON 10-19-2020

**Jaron Kiger**: Hey Jeff, I am going to flex my time again tomorrow. I will be in at 8:30. Hope that’s alright. Thanks.

### CONVERSATION ON 10-20-2020

**Jeff Bergosh**: No problem

### CONVERSATION ON 10-28-2020

**Jaron Kiger**: I forgot my wallet at my house, so I had to turn around to get it. 🤦
But I’m on my way, will be a little late 

**Jeff Bergosh**: Got it, thanks for the heads up

### CONVERSATION ON 11-02-2020

**Jaron Kiger**: I got held up in some traffic getting out of Navarrethis morning. I’m hoping to be there by 730 for the morning meeting

**Jeff Bergosh**: Okay thx for the heads up

### CONVERSATION ON 12-31-2020

**Jaron Kiger**: I do not have John’s number. But everyone else said they would do it. Also, I fixed my time sheet. 

**Jeff Bergosh**: Thanks Jaron

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: Jaron- I need you to put in your timesheet online

### CONVERSATION ON 04-14-2021

**Jaron Kiger**: Hey, my track meet for tomorrow got pushed back a few hours because of rain. So I’m going to come in during the morning tomorrow, and take PTO when I leave. I’ll have to leave the office at 10:30.

**Jeff Bergosh**: That’s fine see u in the morning

### CONVERSATION ON 04-22-2021

**Jeff Bergosh**: Jaron due to the safety training I’m running a little behind so let’s make our meeting today 2:30 in the conference room thanks

**Jaron Kiger**: Ok. That works 

### CONVERSATION ON 05-14-2021

**Jeff Bergosh**: Hey Jaron I sent your time card back to you for correction you need to put the one hour of PTO from Thursday into the PLP column right now you put it into the do not use column. Once you make the correction just put a note in the owners notes and that will allow you to resubmit it. Please take care of this as quick as possible thanks

**Jaron Kiger**: Ok. I will be back at the office soon to fix it. Thanks. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-20-2021

**Jeff Bergosh**: Jaron I am out of the office for a meeting. Remember today at 10 AM is the supervisors safety meeting and you were sitting in for me. Don’t forget to be at that meeting at the Sign in thanks

**Jaron Kiger**: Yes sir. I will be there 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-11-2021

**Jeff Bergosh**: Hey Jaron— I need you to go ahead and put you time in the electronic time card 

**Jaron Kiger**: Done

**Jeff Bergosh**: Thx

### CONVERSATION ON 06-17-2021

**Jaron Kiger**: Sounds good! 

### CONVERSATION ON 07-01-2021

**Jaron Kiger**: 👍

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Has MediaCom shown up yet?

**Jaron Kiger**: Not yet. 

**Jeff Bergosh**: Ok

**Jaron Kiger**: They just got here. They are working on it. 

**Jeff Bergosh**: Okay thanks

**Jaron Kiger**: The internet is back on.

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-26-2021

**Jaron Kiger**: I got a negative result on the instant test. So I am just going to rest up, and see if my fever will come down today. If so, I would like to come to work tomorrow.

**Jeff Bergosh**: Okay sounds good.  Glad you were negative

### CONVERSATION ON 08-06-2021

**Jeff Bergosh**: Jaron,

I need for u to put your time in the online timesheet.  There’s two entries;  one for July 31st and the other one is August 6th for the rest of the week.

Thanks

**Jaron Kiger**: Done. 👍

**Jeff Bergosh**: Thx

### CONVERSATION ON 08-10-2021

**Jaron Kiger**: Good morning Jeff, I started feeling sick last night and now I have a 101 degree fever. Other than that I just feel achy. So I will not be coming in to work today. I’ll try to get a covid test ASAP.

**Jeff Bergosh**: Got it Jaron I hope that you’re feeling better let me know how it goes

**Jaron Kiger**: I tested positive this afternoon. My fever has not broke and I’m still achy. So I’ll be quarantined for the next two weeks. Let me know if I need to do anything for work. Thanks.

**Jeff Bergosh**: Sorry to hear this Jaron.  I’ll speak with Tony to determine steps to take.

**Jaron Kiger**: Thanks Jeff! 

**Jaron Kiger**: Jaronkiger@gmail.com

**Jeff Bergosh**: No problem.  Okay got it.  PBSS Safety would like me to ask if you have any idea where you might have picked the virus up?  You said something about a friends group— is that where?  They’re trying to rule out the possibility that you got it here at work if possible to do that. Let me know, thanks!

**Jaron Kiger**: I got it from my girlfriend. She’s sick right now too. She got it from one of her friends.

**Jeff Bergosh**: Okay thx Jaron. 

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: Hey Jaron just checking in to see how you’re doing.  You doing alright?

**Jaron Kiger**: I’m doing ok. My temperature keeps spiking up to 102.6 degrees. But I’m fighting it back with Tylenol and ibuprofen. I’m at 100.3 right now. Others than that I’m just very tired and fatigued. I’ve been resting all day. 

**Jaron Kiger**: Thanks for checking in. 

**Jeff Bergosh**: Absolutely Jaron!  Hang in there and  beat this thing!

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: Let me know, and thanks!

**Jaron Kiger**: I logged in, and it looks like it was already filled out. I resubmitted it though. Let me know if I need to do anything else. 

**Jaron Kiger**: All my symptoms are starting to subside. I’ve been able to keep my fever down for 24 hr now with medication. And I lost my taste and smell last night. It’s very weird not being able to taste when you eat.

**Jeff Bergosh**: Oh my gosh!  Sorry to hear that!!  Hopefully it’s temporary only!  Glad the fever is receding.  Hopefully it will be incremental improvements going forward from here.  Have a great weekend Jaron!

### CONVERSATION ON 08-17-2021

**Jeff Bergosh**: Hey Jaron!  Just touching base to see how you’re doing.  Are you hanging in there?  Feeling better?  I hope so!

Jeff

**Jaron Kiger**: Hey Jeff, I am starting to feel better. Today was the first day I haven’t had any symptoms. I’m not as fatigued, but I’ve really been trying to take it easy today. Is everyone doing alright at the office?

**Jeff Bergosh**: Glad to hear that!! Yes— we are all great just wanting to make sure you’re alright.  Take it easy and get well soon!

### CONVERSATION ON 08-18-2021

**Jaron Kiger**: Glad to hear everyone is doing alright. When am I clear to come back to work? I’ve heard 10 days from the first symptom. Which would be Friday. But I don’t know what ELE’s recommendation is.

**Jeff Bergosh**: Thanks Jaron I’ll find out for sure and let you know.  Probably Monday though

**Jaron Kiger**: Ok. Sounds good. Just let me know 

**Jeff Bergosh**: Will do.

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: Jaron:  I have just heard back from PBSS on your return.  If you do not have a fever and are symptom free, you can report back to work tomorrow morning.  Just check in with me directly once you arrive so we can discuss what we share with other employees about your absence.  No one has asked, and I’ve told nobody outside of Tony and PBSS safety.  Our coworker simply believe you’ve been on PTO, and are not entitled to know anything beyond that as it’s your personal, private medical information.  So just be mindful of that if certain employees attempt to pry information from you upon your return

### CONVERSATION ON 08-27-2021

**Jaron Kiger**: Good morning Jeff. I just wanted to give you a heads up. I am going to flex my hours today. I will be in a hour later at 8, and stay an extra hour this afternoon.

**Jeff Bergosh**: Okay no problem

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: Just a reminder we have safety training today at 11:40 in the transportation compound

### CONVERSATION ON 10-01-2021

**Jeff Bergosh**: Hey Jaron— I know you’re on PTO but I need for you to fill out your electronic timesheet for today and submit it please.  Thanks!

Jeff

**Jaron Kiger**: No problem. Done. 
Thanks! 

**Jeff Bergosh**: Thx Jaron!

**Jeff Bergosh**: Can you take care of that for me?

**Jaron Kiger**: Sorry I can’t talk, but I fixed it. Thanks for catching that. I always get the LWP and PLP mixed up. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-15-2021

**Jeff Bergosh**: Hey Jaron -- I just returned your timesheet for correction-- you need to list Monday as a holiday

**Jaron Kiger**: Ok, I just fixed it. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-27-2021

**Jaron Kiger**: Hey Jeff, I found out my father has covid and I spent Christmas Eve and day with him and our family. He is doing fine, and no one else is having any symptoms including me. my fiancée and I tested tonight and both got negative tests. I wanted to let you know because of the question on the covid sheet about close contacts. Let me know if you are aware of the most recent guidelines on what to do. Thanks

**Jeff Bergosh**: Jaron if you tested negative you’re fine— no issue.

**Jaron Kiger**: Awesome. Sounds good. and I’ll try and keep my distance from people out of an abundance of caution

### CONVERSATION ON 12-28-2021

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-07-2022

**Jeff Bergosh**: Jaron, please put your time in the electronic timesheet

**Jaron Kiger**: Done 👍

