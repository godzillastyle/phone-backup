

## CONVERSATIONS WITH CONNIE CLARK

### CONVERSATION ON 10-25-2019

**Jeff Bergosh**: Okay great I’ll head that direction.  Thanks again Connie and sorry for the mix up 

**Jeff Bergosh**: Got it

