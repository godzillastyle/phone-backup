

## CONVERSATIONS WITH MIKE CHMURA

### CONVERSATION ON 04-09-2021

**Jeff Bergosh**: Mike I am going to connect you with the engineer and the project manager of this project and they can loop you into exactly what's happening and bring in any of your staff that you want to bring into the project I'll do that when I get back to the office

