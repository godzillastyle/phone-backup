

## CONVERSATIONS WITH MICHAEL KIMBERL

### CONVERSATION ON 04-28-2021

**Jeff Bergosh**: On a call  lol call u back

### CONVERSATION ON 10-30-2021

**Jeff Bergosh**: Absolutely-- will call u

