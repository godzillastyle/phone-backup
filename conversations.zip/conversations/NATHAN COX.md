

## CONVERSATIONS WITH NATHAN COX

### CONVERSATION ON 03-29-2020

**Jeff Bergosh**: Nathan thank you so much —what a very awesome text message to get this morning. If you’d like to contribute to my campaign please make the check out to 

the Jeff Bergosh campaign 

and the address to send it to would be:

5905 Forest Ridge Circle, Pensacola, FL 32526. 

As you texted that —I was actually watching church streamed online and that’s why I did not reply right away. Some surreal times we are all going through right now, right?  Never thought I’d be attending my church online from home on my couch!

But I do appreciate your help— and your kind offer of financial support.

Thank you also for the very awesome sign location on 9 mile road a lot of people have seen those signs and so I’m greatly appreciative of that! 

Stay safe!

Jeff Bergosh

**Jeff Bergosh**: Either a company or a personal check is fine. .......  or both 🙂

Thanks again Nathan!! 

### CONVERSATION ON 12-01-2020

**Jeff Bergosh**: Hey Nathan it’s Jeff Bergosh I just had something I wanna run by you about Antietam please give me a call at your convenience hope things are going well thanks bye

**Jeff Bergosh**: What is will’s cell number?  I’m in the field and don’t have my county phone with me

**Jeff Bergosh**: 👍

