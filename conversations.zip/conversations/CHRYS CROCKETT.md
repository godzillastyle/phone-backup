

## CONVERSATIONS WITH CHRYS CROCKETT

### CONVERSATION ON 05-07-2021

**Chrys Crockett**: This is our little room

**Jeff Bergosh**: That looks really nice!  Is that the type of comforter that you think we need for the unit?

**Chrys Crockett**: I would recommend that type yes

**Chrys Crockett**: Super easy to wash

**Jeff Bergosh**: Perfect.  I think Target sells these

**Chrys Crockett**: Yes its a target brand i got it at dirt cheap

**Chrys Crockett**: Cause they're super expensive

**Chrys Crockett**: Tuesday morning has good stuff cheap and tjmaxx

**Chrys Crockett**: Never spend too much because...well... guests

**Jeff Bergosh**: Absolutely, totally understand!

**Chrys Crockett**: Bed skirts (both ripped)queen and king and a mattress cover for the queen (that one is broken)

**Jeff Bergosh**: Ok where would you recommend I get these?

**Chrys Crockett**: I orded mine from walmart. They have waterproof ones that dont sounds like plastic

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 05-08-2021

**Chrys Crockett**: Heres a couple beds for ideas in Cory's friends condo

**Jeff Bergosh**: Very nice!

### CONVERSATION ON 05-11-2021

**Jeff Bergosh**: The question is-- what color do you recommend and do I need to get 14" drop or 18" drop?

**Chrys Crockett**: I think to 14" will be good.  Will keep them from being on the floor and getting stepped on.  

**Chrys Crockett**: Looking forward as well.  See you then

**Jeff Bergosh**: Thx

**Jeff Bergosh**: I like the look of the light grey, going to go ahead and go with that 

**Chrys Crockett**: Grey is good

**Chrys Crockett**: Its the in color

**Chrys Crockett**: "In"

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Thx

**Chrys Crockett**: It cooled completely off

**Jeff Bergosh**: Did it??  

**Jeff Bergosh**: That's great news!

**Chrys Crockett**: Yes it was actually too chilly lol

**Jeff Bergosh**: LOL I'm happy to hear that!

### CONVERSATION ON 05-15-2021

**Jeff Bergosh**: Hi Chrys I got the bed skirts from Amazon so I'll meet you all out there tomorrow for the change over.  What time do you all plan to head over tomorrow?

**Chrys Crockett**: What is your checkout time?  10 or 11...we will arrive thrn

**Chrys Crockett**: Then

**Chrys Crockett**: Sorry for the late response,  at the river today.

**Jeff Bergosh**: 10 Am is checkout but this latest group has been pretty high maintenance so they'll probably be 11

**Chrys Crockett**: Ok.  We  will arrive 1030.  

**Jeff Bergosh**: Awesome thx we will see you there thanks Chrys!

### CONVERSATION ON 05-16-2021

**Jeff Bergosh**: Hi Chrys are you all at the unit?

**Chrys Crockett**: Yes we are

**Jeff Bergosh**: Okay we'll see you in a minute

**Chrys Crockett**: Ok

**Chrys Crockett**: We discoverd that the kid or whoever peed on the sofa bed as well

**Chrys Crockett**: Which is what was all over the big bed sheets and mattress pad

**Jeff Bergosh**: Wow these folks were the gift that keep on giving

**Jeff Bergosh**: What do we do now?

**Chrys Crockett**: Its all done

**Jeff Bergosh**: Okay thank you!

**Chrys Crockett**: Ine of the robes ended up with us to dry

**Chrys Crockett**: One

**Jeff Bergosh**: Okay 

**Jeff Bergosh**: Just let me know if you got it, thanks!

**Chrys Crockett**: Ty so much

**Jeff Bergosh**: 👍

**Chrys Crockett**: Got it ty

**Chrys Crockett**: I found the missing towel it was wadded up with the pee linens

**Jeff Bergosh**: That's good news!

### CONVERSATION ON 05-20-2021

**Jeff Bergosh**: Hi Chrys!  Just wanted to let you know we figured out the issue with that last guest.... she broke the Rollie's and brought pets.  I think the issues were from her dogs.  She gave a 5-star review LOL.  Anyhow, sorry that was such a nightmare.  I won't be there tomorrow because I'll be at work but please let me know if you need anything for tomorrow's change out.  Hopefully the sheets and comforters came out okay.

Thanks!

Jeff B.

**Chrys Crockett**: Sheets and comforters all the great and they smell good too.   We should have everything we need, I will let you know how the next guests where

**Chrys Crockett**: Were

**Jeff Bergosh**: Thanks Chrys!

**Chrys Crockett**: You are welcome

**Chrys Crockett**: Maybe the lady is just embarrassed because unless she mopped up the floor from her hairless dogs pooping peeing on the floor there probably wouldn't have been Pee on the bed and on a sofa bed I'm not sure though... Did you charge her for bringing a pet

**Jeff Bergosh**: I wasn't able to it's still under Cory's account.  Cory gave her a poor review for the way she trashed the condo.  I'll never rent to her again and hopefully others will watch out for her as well

**Chrys Crockett**: Yea thats crazy.  Irresponsible 

### CONVERSATION ON 05-21-2021

**Chrys Crockett**: Pretty good guests 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Glad to hear that!

**Chrys Crockett**: The master slider glass closes but at the bottom there is a small gap like it is crooked on the track

**Jeff Bergosh**: Okay thanks-- does it open?

**Chrys Crockett**: It opens and closes smooth.  Just if it rains....and the wind howls a bit

**Chrys Crockett**: All done.  

**Chrys Crockett**: Thepatio is set up pretty not sure how ling it will last the wind is realllly bad

**Chrys Crockett**: Long

**Jeff Bergosh**: Right on thanks very much Chrys I'm going to Venmo you right now.  Have a great weekend!

**Chrys Crockett**: Thank you.  You too 

**Chrys Crockett**: Not sure if you asked them to throw the towels in the wash or not, but they did.  Huge help, was awesome.  We were able to wash all of the sofa bed linens in time.  

**Jeff Bergosh**: That's fantastic, great guests

**Jeff Bergosh**: Can you send me a request and we can try it that way?

**Chrys Crockett**: Sure

**Jeff Bergosh**: Got it just paid.  Thanks Chrys!

**Chrys Crockett**: Awesome ty!

**Chrys Crockett**: Next one is thursday..

**Jeff Bergosh**: Yes ma'am 

**Chrys Crockett**: Got it

### CONVERSATION ON 05-25-2021

**Chrys Crockett**: Is thursday a check out check in same day

**Chrys Crockett**: I got it figured out the other unit doesn't check in till Friday

**Jeff Bergosh**: I have them checking in Thursday at 3:00

**Chrys Crockett**: Ok.  Its good.  The other one i clean dont check in till friday so i can do both.  Yours first

**Chrys Crockett**: I was going to tell the other guy no

**Jeff Bergosh**: Ok cool thx Chrys!

**Chrys Crockett**: I wont cancel on you.  Promise

**Chrys Crockett**: The other unit is so wishywashy

**Jeff Bergosh**: Thank you so much for that 🙂🙂

### CONVERSATION ON 05-27-2021

**Chrys Crockett**: Good guests

**Jeff Bergosh**: Okay cool-- glad to hear that.  

**Jeff Bergosh**: Then if you could just text those to me I'll re-type them and replace them on This Sunday's change out

**Chrys Crockett**: Lol

**Jeff Bergosh**: Also, I bought replacement shelves for the fridge to replace the cracked ones and I'll bring those this Sunday as well. Thanks for all your help!

**Chrys Crockett**: Sure thing you're welcome

**Jeff Bergosh**: Awesome-- thanks!

**Chrys Crockett**: Im waiting for towels

**Chrys Crockett**: Going to head to my other unit down the street to start the laundry there...will be back here in an hour to fold towels and finish here.

**Jeff Bergosh**: Sounds great!  Thx

**Chrys Crockett**: Ok all done.  The robes and towels took forever to wash and dry.  Was a close one whew

**Jeff Bergosh**: Right on-- thank you Chrys!

**Jeff Bergosh**: Sending you your pay rn on Venmo

**Chrys Crockett**: Ty so much

**Chrys Crockett**: See you Sunday 

**Jeff Bergosh**: Yes ma'am we'll see you there -- thanks and have a great afternoon!

**Chrys Crockett**: You too

### CONVERSATION ON 05-30-2021

**Chrys Crockett**: All done if its ok i leave the bath mat in the dryer? Its still pretty wet

**Jeff Bergosh**: Yes sounds good

**Jeff Bergosh**: I'll Venmo u your money--thanks Chrys!!

**Chrys Crockett**: Ty so much.  If you ever have time i have a question about a business i want to start..maybe you would have some advice? 

**Jeff Bergosh**: Of course-  would love to discuss.  Just call me tomorrow or Tuesday in the afternoon.  Have a great rest of the weekend!

**Chrys Crockett**: Sounds great ty!  You too

### CONVERSATION ON 06-04-2021

**Chrys Crockett**: All kinds of $3 towels at dollar general..gray and white.  Want me to pick up some on my way tomorrow 

**Chrys Crockett**: I have great success with dg towels

**Jeff Bergosh**: Okay yes please!  Thank you Chrys!

**Chrys Crockett**: Ok will do.  Awesome

### CONVERSATION ON 06-05-2021

**Chrys Crockett**: Decent guests.  

**Chrys Crockett**: She is right..the ac is doing its old tricks

**Jeff Bergosh**: Ok

**Jeff Bergosh**: On way there

### CONVERSATION ON 06-08-2021

**Chrys Crockett**: Hello there.  I am at the ER my doctor told me to come in.  My blood pressure is all out of wack (super high)  arm pain, neck pain.  Nauseous.   I wanted to let you know ahead of time in case i am unable to make it sat.  Depending on what happens

**Jeff Bergosh**: Ok I hope u are alright.  

**Chrys Crockett**: Ty

### CONVERSATION ON 06-09-2021

**Chrys Crockett**: Im out of the hosp.    They dont have any answers for the blood pressure or arm pain.  They suspect pinched nerves from my neck.  I have been laid up 4 days now.    My husband dosent want me to clean anymore until we know what is happening.  My bp gets up to 167/105 when im moving around.  

**Jeff Bergosh**: Oh my gosh-- sorry to hear that and I hope you're able to get better.  I'll call you this afternoon so hopefully you can give me some pointers on how to clean this unit on Saturday 🙂🙂

**Jeff Bergosh**: And I'll come by at some point and pick up the sheets and bedding for the change out.  Just let me know when it's convenient.

**Chrys Crockett**: Ok sounds good.  I havent done the laundry yet but i will try to tonight so it is all clean and ready for you

**Jeff Bergosh**: Thanks so much and I'm praying for a speedy recovery!

**Jeff Bergosh**: I'm actually playing tennis early Saturday morning at the Moors which is in Milton-- perhaps I could get with you after at about 10:00 or so and grab the bedding then I'll head out to the unit to get it cleaned

**Chrys Crockett**: Sure that will work well for us

**Jeff Bergosh**: 👍

**Chrys Crockett**: Dryer lint filter too.  Before i forget 

### CONVERSATION ON 06-10-2021

**Jeff Bergosh**: Thx. I'll make sure to clean it!

### CONVERSATION ON 06-11-2021

**Jeff Bergosh**: Hey Chrys-- what kind of mop do you use to clean the unit?  I'm going to get one like the one you have.  Also, where do you recommend I get one like yours for a good price?  Thanks, and I hope you're feeling better!

Jeff B

**Chrys Crockett**: It's a spin mop and I think you can get them pretty much Any retail...Walmart 

**Jeff Bergosh**: Okay thanks Chrys!  And are you still good with me swinging by after tennis in the morning at about 10:30 or so, to pick up the bedding and sheets on my way to the condo to do the turnover?  Thanks and just text me the location--I'll text when I'm on way there!

**Chrys Crockett**: Sounds good. 3510 Robinson point rd 

**Jeff Bergosh**: 👍 thanks Chrys!

### CONVERSATION ON 06-13-2021

**Jeff Bergosh**: Hi Chrys!  I just venmoed u $50 for your assistance with yesterday's changeover.  I'm realizing that the hard part is doing all this darn laundry and it was so helpful for me to have you do it and have it ready for me so I greatly appreciate that! And I thought it was gonna be a piece of cake I barely finished in time lol!  Anyhow enjoy your weekend and again thank you for your help!

**Chrys Crockett**: Awe thank you so much!  

**Jeff Bergosh**: 🙂👍

**Chrys Crockett**: Yes the laundry is a bear!

**Jeff Bergosh**: Yeah it is!

### CONVERSATION ON 06-16-2021

**Chrys Crockett**: https://www.facebook.com/marketplace/item/4013820172065505/?ref=facebook_story_share

**Chrys Crockett**: Red lazy boy sleeper sofa

**Jeff Bergosh**: Wow that's a great price!  Thanks for sharing.  But I think we are going to purchase two new ones from Wayfare they have some decent styles on special for between four and 600

### CONVERSATION ON 06-21-2021

**Jeff Bergosh**: Hi Chrys!  Hope you're feeling better  and that things are getting back to normal for you all.  I'm just checking in to see if you'll be able to clean form me Thursday of this week and Wednesday of next week---as those fall on work days for me.  I have laundered the sheets, pillowcases, comforters, and shands for this week's changeout and can get them to you beforehand if you're available.  Just let me know, and thanks!

**Chrys Crockett**: Sure thing i can do thursday and wed

**Jeff Bergosh**: That's awesome!  Thanks.  How can I get the clean laundry to you?--will you be in Pensacola at all this week?

**Chrys Crockett**: I can come that way wed

**Jeff Bergosh**: Okay I've got them in my truck so I can meet up with you and get them to you.  Thx Chrys!

**Chrys Crockett**: Spunds good ty

**Jeff Bergosh**: If that doesn't work I can just bring them out on my lunch break to the condo this Thursday.  So either way I'll get them to you.  Thx👍

**Chrys Crockett**: I could even meet up on my way there.  However is good

**Jeff Bergosh**: Okay.  Just let me know and whatever works better is great! 🙂

### CONVERSATION ON 06-22-2021

**Chrys Crockett**: Is it ok we meet you on thursday on the way to the condo 

**Jeff Bergosh**: Sure, that will work.  Just text me when u r on the way 👍

**Chrys Crockett**: Ok sounds good ty

### CONVERSATION ON 06-24-2021

**Chrys Crockett**: Whats the address?

**Jeff Bergosh**: For where we meet so I can get you the laundry?

**Chrys Crockett**: Yes

**Jeff Bergosh**: Oh, okay.  Are u coming through Pensacola on the I 110?  If so, I can meet you at that shell station right at Bayfront parkway before the 3 mile bridge.

**Jeff Bergosh**: Circle K Gas Station at Bayfront parkway and Chase Avenue 


700 Bayfront PKWY
Pensacola, Fl
32502

**Chrys Crockett**: 940

**Chrys Crockett**: Arrival 

**Jeff Bergosh**: Okay I'll be there 

**Jeff Bergosh**: 👍

**Chrys Crockett**: Here 

**Jeff Bergosh**: Here

**Chrys Crockett**: Ac is not working

**Jeff Bergosh**: Okay it has been working Diane the last time I called but I'll call them out again and I'll lower the temperature from my remote app

**Jeff Bergosh**: I'm calling the service company again

**Chrys Crockett**: Its set at 66 its 74 in here 

**Jeff Bergosh**: I just notched it down to 64

**Jeff Bergosh**: If possible I would close the blinds and make sure the doors are kept closed let's just see if it drops in temperature at all. And also let's make sure the fans are going to thanks Chrys!

**Chrys Crockett**: Ok

**Chrys Crockett**: They left curling iron in a small gift bag.  I put it in owner closet 

**Jeff Bergosh**: Thanks 

**Jeff Bergosh**: I'll mail it to them if they request it back 🙂

**Chrys Crockett**: I turned the ac off for a bit and back on its cooling

**Jeff Bergosh**: Hallelujah!!!

**Jeff Bergosh**: Thank you

**Chrys Crockett**: Ye

**Chrys Crockett**: Yw

**Jeff Bergosh**: Im still gonna have the technicians come out to double check it again.  It probably needs more Freon again

**Chrys Crockett**: Yea cause it seems to have stopped cooling again

**Jeff Bergosh**: Hi Chrys-- when you're done cleaning please let me know so I can pay you on Venmo.  Also,and before you leave, please just make sure all the blinds are drawn and the fans are going to keep it as cool as possible before the next guests arrive at 3:00.  I'm still waiting on AC company to call me back

**Chrys Crockett**: Ok yea i shut it off for a bit again.  Its humid air in here.  74..but so sticky 

**Chrys Crockett**: Folding towels and will be finished

**Jeff Bergosh**: I've noticed that it does better when it's set to the "fan on" instead of "Auto"-- so I've got it notched down to 65 and in the fan on position

**Jeff Bergosh**: Did they clean the new BBQ? And did they leave the grill scrubber?

**Chrys Crockett**: They didnt.  Scrubber is here.  Blood on queen sheets as well.  Several spots

**Jeff Bergosh**: Okay. Thx.  Hopefully they'll come out in the wash

**Chrys Crockett**: You have 4 beach towels that are clean I just found 4 more beach towels that they had waded up underneath clean folded ones they were wet

**Jeff Bergosh**: So there's a total of how many clean ones for next guests?

**Jeff Bergosh**: Just 4?

**Chrys Crockett**: Yes 4

**Chrys Crockett**: Beach towels

**Chrys Crockett**: Might try shutting the air off for a while and turning on before check in

**Chrys Crockett**: I think its freezing over.  It ran cool for about 30 mins after i shut it off for a bit

**Jeff Bergosh**: Okay we will go with 4 I guess

**Chrys Crockett**: Wow, definitely wasn't like that when we left looks like that got pulled out pretty hard I close the curtains and the fan was in front of the curtains

**Chrys Crockett**: I didn't notice any issues with the curtain rod when I closed it .. That was the 1st room I finished and closed up.  Is the stucco wet

**Jeff Bergosh**: .....the guy sounded kind of out of it

### CONVERSATION ON 06-29-2021

**Jeff Bergosh**: Good Morning Chrys-

The current guest is checking out and We have a new guest checking in tomorrow, Wednesday.  This one only stays 2 days then we have a 9 day guest checking in Friday.  I'm hoping you're feeling better and that you're available to clean those days.  Please let me know and I hope all's well.  Friday's changeover will probably be light given he's only there two days.  🙂

Thanks Chrys!!

**Chrys Crockett**: Sure thing I can do Wednesday and Friday

**Jeff Bergosh**: Awesome!  Thank you Chrys!!!

**Jeff Bergosh**: On my lunch break I'll swing by and fix the curtain rod these guys broke.  Thanks again!

**Chrys Crockett**: You're welcome 

### CONVERSATION ON 06-30-2021

**Chrys Crockett**: We will arrive about 11 o'clock today

**Jeff Bergosh**: Right on thx!

**Chrys Crockett**: Hey Jeff.   There is going to be about 3 or 4 extra loads of laundry to prep this unit if the next guy needs tue sofa beds.  And that is 3 or 4 more loads even if i do off site.  And 2 loads of towels i may be able to do here, but will be waiting on the dryer.  They didnt start the towels and they used every available linen.  I wanted to let you know before i started because this adds a few more hours of work for sure. @$100 is already way below market.  

**Chrys Crockett**: So all the extra queen sheets got used and the ones from the last guests blood didnt come out. 

**Chrys Crockett**: 😴done

**Jeff Bergosh**: Oh my gosh that's a load of laundry!!

**Jeff Bergosh**: Did I get the Dr Pepper?

**Chrys Crockett**: Yes we have it

**Jeff Bergosh**: 👍😎

**Jeff Bergosh**: Sending u your money rn.  Thanks Chrys and I'll see u on Friday.  Hopefully these guests take it easy......

**Chrys Crockett**: See you then ty

**Jeff Bergosh**: 👍

**Chrys Crockett**: Hey there.  Im going to have all the linens ready and try to wash everything while im there friday.   My schedule is reallllly full the first 2 weeks of july with turn overs here.  I will not be able to commit to any cleaning with my check out and check in times.  Plus i hurt my shoulder pretty good today.  We will for sure friday, but def need to lighten my load.  I can on occasion,  as long as i do not have a turnover here.  July is pretty crazy for me.  I got used to having someone to help me, and took on a lot.  But now that im doing it alone, it is craziness.  Maybe when zoey starts school in aug i can take more cleaning

**Jeff Bergosh**: Okay I totally understand Chrys.  We will take it in a case by case basis after Friday -- hopefully your shoulder will be feeling better.

**Chrys Crockett**: Turnoverbnb is a site i used to use to find jobs.  Your condo was the first i ever took

**Jeff Bergosh**: Okay I'll check it out!  Thanks!

### CONVERSATION ON 07-01-2021

**Jeff Bergosh**: Hey Chrys-- I purchased new king and queen sheet sets and comforters for the guests tomorrow I will bring those when I come at around 11 o'clock. I also bought an extra set of towels so all we need to wash to get ready for the long-term guests that start tomorrow are the bathmat, any beach towels used,  and the bath robes and one set of towels. I'll see you tomorrow and thank you!

**Chrys Crockett**: OK I am still working on the laundry I will have as much of it done as possible Hopefully all of it.   The towels robes and bathmats are already finished.   Just working on the comforters and sheets even with my high capacity washer it gives me problems with valencine and drying

**Chrys Crockett**: Balancing 

**Jeff Bergosh**: Okay thanks!

### CONVERSATION ON 07-02-2021

**Jeff Bergosh**: Keith, this is Jeff Bergosh.  Please call me back.  It’s 4:00 Friday.  Thanks.

**Chrys Crockett**: All done

**Jeff Bergosh**: Okay great I'm sending u the money right now

**Chrys Crockett**: Ok ty

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Have a great 4th!

**Chrys Crockett**: You as well

