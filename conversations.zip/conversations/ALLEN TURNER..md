

## CONVERSATIONS WITH ALLEN TURNER.

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: Hello Allen—-we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for assisting with this effort by helping me garner financial supporters.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Allen Turner.**: You are welcome. I sent out an email this morning g with your flyer attached.

**Allen Turner.**: See u there. 

**Jeff Bergosh**: Thank you Allen!!!

**Allen Turner.**: YW

### CONVERSATION ON 11-01-2019

**Allen Turner.**: I don’t know that name. Sorry!

**Jeff Bergosh**: Okay thanks very much Allen!

### CONVERSATION ON 11-04-2019

**Jeff Bergosh**: Hello Allen—I just wanted to let you know that Hill Kelly Dodge sent me a nice campaign contribution and I’m sure it was based upon your discussions with them—so thank you very much!!  It was from their company so I’m assuming I’d make the thank you card out to Miles Bentley?  Or do you think it would be someone else?  I wouldn’t  want to send it to the wrong person 


Thanks Allen!!

**Allen Turner.**: Miles is who I spoke with! Great!!

**Jeff Bergosh**: 👍thank you!!

**Allen Turner.**: YW

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: FYI— Governor DeSantis’ executive order from just today with addendum for essential businesses

Stay Well Allen,

Jeff Bergosh

**Allen Turner.**: Thank you.  

**Jeff Bergosh**: 👍

**Allen Turner.**: Is this the one Gov promised for today?

**Jeff Bergosh**: Yes

### CONVERSATION ON 04-24-2020

**Allen Turner.**: http://www.myfloridalegal.com/newsrel.nsf/newsreleases/149613C55712374385258553005E4083

**Allen Turner.**: This is going to help us!! Please read.  New Wave is the company that comes here the most frequently. 

**Jeff Bergosh**: Wow!! That’s outrageous!!  Glad they’re getting shut down!

### CONVERSATION ON 01-12-2021

**Allen Turner.**: Got your message.  Thank you. 

**Jeff Bergosh**: 👍  thank you!!!!!

**Allen Turner.**: YW!

