

## CONVERSATIONS WITH WES MORENO

### CONVERSATION ON 09-19-2020

**Wes Moreno**: Good Morning Commissioner,¿¿I have a supervisor enroute to assess Ms. Payne's concerns in Crystal Creek - also I have emailed Mr. Love in Cresent Lake to let him know I have spoken with Gulf Power regarding his concerns - I gave him my number - Gulf Power states they are still working the area.¿¿Wes 

**Jeff Bergosh**: Thank you Wes!!

**Wes Moreno**: Always welcome Commissioner 

**Wes Moreno**: Regarding Ms. Luster on Peppertree - I have spoken with Gulf Power rep in EOC to get a better explanation regarding the tree - meanwhile, we have a Gulf Power cutting crew embedded with us - I am sending them to peppeetree to see if they can assist - I have spoken with Ms. Lyster - Will keep you posted - Wes 

**Jeff Bergosh**: Thank you Wes!

**Wes Moreno**: Commissioner, can you get the name of the Pastor's electrician? 

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Wes--thanks for handling these issues.  I hate to keep throwing things your way but I have two additional locations that need some assistance:


"Lisa Bailey  850 324 1906. The address where the tree is 2337 belleflower road pensacola fl.   My address is 2301 belleflower road. Thank you for your help"

**Jeff Bergosh**: 7040 Pine Forest Rd. really bad pine tree that will go back across the highway because it is leaning on another tree before falling.

**Wes Moreno**: Well get on them Commissioner 

**Wes Moreno**: We'll 

**Jeff Bergosh**: Thank you!!

**Jeff Bergosh**: 
Wes here is a Facebook PM I got and it may be something your Gulf Power contact could provide an assist with-- can you please check into this issue as well?  Thanks so much!

**Wes Moreno**: Thanks Commissioner, I will dig into this one - Wes

### CONVERSATION ON 09-20-2020

**Wes Moreno**: Wes, Gadsden Street United Methodist has power

**Wes Moreno**: From Gulf Power rep

**Wes Moreno**: Also, we are going to begin picking up debris tomorrow using in-house forces - do you have a preference of where we start in your area? 

**Jeff Bergosh**: Hey West thank you so much for getting the Methodist Church back up and running. We greatly appreciate that. Wherever they need is greatest that's where I'd like to start picking up obviously there's debris in every neighborhood including mine however if you guys determine where it's the worst at the moment I would prefer if you all would start there with the pick up

**Wes Moreno**: 👍👍

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: 👍

**Wes Moreno**: Ferrovial  picking up that debris on Blue Angel!
Now we know they can!

**Jeff Bergosh**: That's fantastic!

### CONVERSATION ON 04-21-2021

**Jeff Bergosh**: Part II-- location cross street

**Wes Moreno**: Thanks Commissioner, I will make sure these areas are safed up, will also contact FDOT contractor and make them aware - Wes 

**Jeff Bergosh**: Thanks a million Wes!!

### CONVERSATION ON 06-19-2021

**Wes Moreno**: Good Morning Commissioner,

Our latest report - We have two houses in Ferry Pass that received possible tornado damage, no one was home, no one injured - a building in Ellyson received some roof damage - Forest Creek is good, Bristol Park is good, Croydon is good

Wes 

**Jeff Bergosh**: Thanks Wes!

### CONVERSATION ON 06-22-2021

**Wes Moreno**: Commissioner,

I just learned that we had an employee choke in the lunchroom at COC - Fire Marshall Joe Quinn performed the Heimlich Manuever twice, successfully dislodging the blockage of the airway.

Wes 

**Jeff Bergosh**: Wow!  Glad he was able to be saved!!  Awesome!

### CONVERSATION ON 06-23-2021

**Wes Moreno**: Commissioner,

An ECAT bus has crashed at Fairfield and Davis - multiple injuries 

**Jeff Bergosh**: Oh no!  Hate to hear this! Hopefully everyone will be okay.  Thanks for the heads up and please keep me informed on this.  

**Wes Moreno**: All of our passengers are good, driver is good, passengers in van that was pushed into the bus are being checked out, injuries do not appear to be life threatening, however a couple are being transported to Sacred Heart 

**Jeff Bergosh**: Thx for update

### CONVERSATION ON 06-26-2021

**Wes Moreno**: Good Morning Commissioner,

The State has made a formal request of Escambia to send our emergency command center Thor to Miami to assist in the recovery/rescue efforts - I have given Director Gilmore approval to send the conmand center and one employee, Chris Holloman Chris will leave out in the morning

Wes 

**Jeff Bergosh**: Fantastic thanks for the heads up!  

### CONVERSATION ON 07-15-2021

**Wes Moreno**: Commissioner, we had an employee involved in an accident at Ellyson Field - our employee was in a dump truck - Right now it appears a van pulled out in front of our dump truck. Our employee swerved hit the van a little bit and as he came around he was meeting a Jeep head-on - hit the Jeep as he was trying to swerve again and went into the national guard armory - no serious injuries - will keep you posted of any developments

**Jeff Bergosh**: Thank you very much for the heads up Wes. I'm certainly glad no one was injured seriously and again thank you for keeping us in the loop in real time it's greatly appreciated!￼

**Wes Moreno**: Commissioner,

There is a fire at the ECUA recycling facility at the landfill - will keep you posted - Wes 

**Jeff Bergosh**: Wes thank you for the heads up I hope everyone's OK and that it's not too bad

**Wes Moreno**: Update,

Fire Services has hot spot cooling off. Paul Williams indicated they would be here a couple more hours. 

No injuries or rolling stock damage. 

Recycling equipment will have to be assessed for damages. 

ECUA on site working closely with Fire Services. 





ECUA working 

**Jeff Bergosh**: Okay thx for update

### CONVERSATION ON 08-09-2021

**Wes Moreno**: Commissioner,

We had four inmates transported to Baptist Hospital - the crew was working at Brent Park - they got into some drugs (spice), not sure if it was a planned drop or if they happened upon it. It appears, as of now, they will recover - Wes 

**Jeff Bergosh**: Thanks for the heads up I hate to hear this but these guys will always try and get over. Glad it looks like they'll be all right though

### CONVERSATION ON 08-10-2021

**Wes Moreno**: Commissioner, I was just notified that we have an escaped inmate worker off of a road work crew in the 10 Mile Road area. I will update with more information as I receive it. Wes

**Wes Moreno**: Inmate has been recaptured - Wes 

**Jeff Bergosh**: Right on good job

### CONVERSATION ON 08-11-2021

**Wes Moreno**: Commissioner,

We have an ECAT bus involved accident at Johnson and Chisolm - bus and vehicle appeared to be totaled. 1 passenger off the bus transported to hospital with what appears to be non-life threatening injuries. I will keep you updated as we get more information. Wes

**Jeff Bergosh**: Hate to hear this, thx for update--hope everyone is alright!

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: She is Judge Petrie's assistant and she knows the whole story about the table

Thanks Wes!

### CONVERSATION ON 08-24-2021

**Wes Moreno**: Commissioner,

We have a corrections officer being arrested for domestic violence. Will keep you posted.

Wes 

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: Okay thanks.  Sorry to hear this....

### CONVERSATION ON 08-28-2021

**Wes Moreno**: Good morning commissioner, good for a call?

### CONVERSATION ON 09-01-2021

**Wes Moreno**: Good Morning Commissioner, 

We have an EMS supervisor involved a vehicle crash while responding to another crash. Our employee is OK, the other person isbeing transported. I will provide ore details as I get them. Wes 

**Jeff Bergosh**: Oh no!  Hope everyone is okay and thanks for the heads up!

### CONVERSATION ON 09-05-2021

**Wes Moreno**: Good Afternoon Commissioner, 

We have a female inmate in the hospital with covid, her family has opted to not put her on a vent. She has been in custody since July.. Will keep you updated.

Wes 

**Jeff Bergosh**: Okay thanks Wes

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: Wes I just emailed you something important.  Please take a look and let me know your thoughts.  Much appreciated

### CONVERSATION ON 09-28-2021

**Wes Moreno**: Good Afternoon Commissioner,

PNJ will be running a story tomorrow regarding Jail Medical

Wes 

**Jeff Bergosh**: Okay thx for heads up

**Jeff Bergosh**: Will it be a hatchet piece-- or a fair story.  Do you have any sense of it?

### CONVERSATION ON 10-11-2021

**Wes Moreno**: Good Afternoon Commissioner,

A firefighter has gone into cardiac arrest while training at the Mc Donald shopping center - will keep you updated as information is received.

Wes 

**Wes Moreno**: Commissioner, 

Firefighter is in ICU but stable 

Wes

**Jeff Bergosh**: Thx for info prayers for a speedy recovery

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: Also-- I want to say thank you very much for the quick work staff made of replacing the worn out signs in the mid-county commerce park-- and also for having the grounds mowed and trimmed.  I heard back from the tenants and they are greatly appreciative!!  Thanks Wes!!!

### CONVERSATION ON 10-30-2021

**Wes Moreno**: Commissioner,  my number is now working again for calls and texts 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-05-2021

**Wes Moreno**: Commissioner, this is the driveway entrance, it is immediately east of the Paradise hotel

**Jeff Bergosh**: Right on thank you Wes!  And you have 2 spots for us for tomorrow, is that right?

**Wes Moreno**: That is correct, call Art Mead when you're close, his number is 850-554-2905

**Jeff Bergosh**: Will do Wes -- thanks again!

**Wes Moreno**: Correction on the contact info - it will be Kirk Troil - 850-281-9919 He will meet and guide you in - Have a great time

**Jeff Bergosh**: Got it.  Thanks Wes!

### CONVERSATION ON 11-13-2021

**Jeff Bergosh**: Wes:  Channel 3 is calling about a death at the jail tonight. Do you have any information you can pass? Thanks

### CONVERSATION ON 11-15-2021

**Wes Moreno**: This just came through, along with some others,  not sure what was going on with messaging 

**Jeff Bergosh**: That's what I assumed happened because normally you respond very quickly.  Thanks Wes!

### CONVERSATION ON 11-19-2021

**Jeff Bergosh**: Wes can you give me a quick call-- have a question for you that's important.  Thanks!

Jeff B

### CONVERSATION ON 11-28-2021

**Wes Moreno**: Commissioner, EMS OTW to jail, female inmate expericing heart failure, CPR is being performed - will update as information is received 

**Jeff Bergosh**: Thanks for heads up I hope she is alright!

**Wes Moreno**: Commissioner, 

Unfortunately she passed, 20yr old female

**Jeff Bergosh**: Drug overdose?  Or heart failure at age 20??

**Wes Moreno**: I'm still gathering information, I will keep you updated

**Jeff Bergosh**: Okay thanks Wes

### CONVERSATION ON 12-02-2021

**Jeff Bergosh**: Bob Sidoti.  ESA South

### CONVERSATION ON 12-04-2021

**Wes Moreno**: Good Morning commissioner, we had a male inmate experience a medical alert this morning. He has been transported to the hospital and is incubated. The toxicology report was negative for drugs. 

Wes 

**Jeff Bergosh**: Thanks for the heads up

### CONVERSATION ON 12-12-2021

**Wes Moreno**: Commissioner, 

A correctional officer has been attacked, he is on the way to Sacred Heart via ambulance - he is conscious,  will provide updates as I receive then.
Wes  

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: Okay thanksI hope he is going to be okay

**Wes Moreno**: His head and face is knotted up pretty good. CT scan is pending, not sure if anything is fractured. He was removing an inmate from the shower as the nurse was on the floor to do her medical rounds. 

**Wes Moreno**: Nothing broke...just swollen and cuts

**Jeff Bergosh**: That's good to hear.  Thanks for update.  I'm sure the prisoner will be charged appropriately

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas to you and your family Wes!

**Wes Moreno**: Thanks so much, Merry Christmas to you and your family too 🎁🎄

### CONVERSATION ON 01-04-2022

**Wes Moreno**: Suicide attempt in jail, still working him at jail. Rich on his wat in, will call when he knows more.

**Jeff Bergosh**: Okay thx for heads up Wes

**Wes Moreno**: He has been put on a vent and they are running tests for brain activity

### CONVERSATION ON 01-06-2022

**Wes Moreno**: Commissioner, the inmate who attempted suicide was taken off the vent this afternoon at 2:00, at the request of the family - he passed this evening at 8:20 - Wes 

**Jeff Bergosh**: Thanks for the update--tragedy all the way around 

### CONVERSATION ON 01-12-2022

**Wes Moreno**: Got it

**Jeff Bergosh**: 8503401715

**Jeff Bergosh**: Thx

### CONVERSATION ON 01-15-2022

**Wes Moreno**: Good evening Commissioner, there was a fire this evening at Solid Waste, in the recycling building

**Wes Moreno**: Fire knocked down appears fire in equipment that sorts trash.   It appears there is No damage to the recycling building isolated to equipment. 

**Jeff Bergosh**: Thanks for heads up!  Glad to hear damage limited to equipment

### CONVERSATION ON 01-26-2022

**Wes Moreno**: Good Morning Commissioner,

Male inmate experienced a medical emergency, was transported to Baptist. Will provide updates as they are received.
Wes

**Jeff Bergosh**: Okay thx for update

### CONVERSATION ON 02-01-2022

**Wes Moreno**: I'll call you back.

**Jeff Bergosh**: 👍

