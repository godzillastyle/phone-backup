

## CONVERSATIONS WITH SAVA VERAZO

### CONVERSATION ON 02-06-2020

**Sava Verazo**: Jeff 
A legal beagle in the audience informed me that he handles BMSU’s for developers and  clients regularly and it takes 60% approval by the affected parties or residence. The HOA board at Inerarity told me they’ve not signed any such agreements other than Doug telling them they have no choice, does that sound right??

### CONVERSATION ON 02-07-2020

**Jeff Bergosh**: Sava—I am not certain but I will find out.  Thanks for speaking, thanks for being there

**Sava Verazo**: I just feel sorry for those folks, there’s got to be a more reasonable/feasible way. I did more research when I got home and it appears the gentleman was an engineer not an attorney and evidently theres a different standard for different categories;
Lighting vs sewage systems and so on. Thank you! for all you do 👍

### CONVERSATION ON 02-10-2020

**Sava Verazo**: Hey Jeff bring at a dozen yard signs Monday as well. I’ve already got ok from family and friends to place them, Sava

**Jeff Bergosh**: Outstanding thank you Sava

### CONVERSATION ON 02-13-2020

**Sava Verazo**: Are we still on to do signs on Monday
Sava

**Jeff Bergosh**: Yes- absolutely.  Let me know what time works best for you and thanks very much for your assistance!!

**Sava Verazo**: Anytime after 10:30 if that’s ok

**Jeff Bergosh**: Sounds good.  I’ll call u at 10:30 and we can decide a good spot to meet up!

**Sava Verazo**: Sounds good

### CONVERSATION ON 02-17-2020

**Sava Verazo**: Almost done call u in a few mins 

**Sava Verazo**: I’m in the car rolling, where u wanna meet 

**Sava Verazo**: Fishermans corner

### CONVERSATION ON 02-21-2020

**Sava Verazo**: You been working hard, seeing your big signs going up. Looking good 👍

**Jeff Bergosh**: Thanks Sava—going to get a lot more out this Sunday as well!  Thanks for all your help!!!!

**Sava Verazo**: I’m still finding you some good locations for bigger signs

**Jeff Bergosh**: Thank you my friend!!!!

**Sava Verazo**: Your Welcome 

### CONVERSATION ON 02-22-2020

**Sava Verazo**: Hey buddy got more locations for you I Ur district.I’ll text them to you

**Jeff Bergosh**: Awesome thank you!!!!!

**Sava Verazo**: Leave him 5 signs as well he’ll put them up beside his yard. He’s the brother-in-law of The guy I introduced you to, Greg Till the bee farm fella 

**Sava Verazo**: Call me when u get a chance won’t take but a min Sava 

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Sava—sorry I didn’t see this till this morning.  I will call u later this morning after church if that’s alright

**Sava Verazo**: Hey buddy just tried calling u back give me a call

**Sava Verazo**: Put one up at my aunts house
7550 Hiawatha st 
Pen , fl. 32526

**Sava Verazo**: And at my Cruz’s 4692 poinciana dr.32526

**Sava Verazo**: Call me back I have still another place while ur out putting up

**Sava Verazo**: Here’s another of my family’s properties. Can’t miss it Owens put one of his up there. Cuz told me we can put one up right beside his 😁

3210 Godwin lane  32526

**Sava Verazo**: You can put big signs up at all three of these if you want 

**Sava Verazo**: Anyone ask Tina told you you can put them there 

### CONVERSATION ON 02-25-2020

**Sava Verazo**: Looking across the street when ur coming out of the Perdido Bay Country club on Doug Ford Road. 

**Jeff Bergosh**: That looks fantastic Sava—thank you!!

### CONVERSATION ON 03-01-2020

**Sava Verazo**: Do you still need me to help place a few signs today after church or not, Sava

**Jeff Bergosh**: Hey Sava!  I’ll be out after church putting up a few and I could get you some more yard signs if that would be alright—if you could help me find a home for them that would be super!

**Sava Verazo**: REW

### CONVERSATION ON 03-04-2020

**Sava Verazo**: If you can have at least 6-8 large signs made up for the spots I’ve got for Sunday They are all top notch locations in ur district, Sava

**Jeff Bergosh**: Outstanding thank you I’ll be ready!!  Thanks very much!!

**Sava Verazo**: 👍

**Sava Verazo**: I have a church board meeting till around 1:00 Sunday, I can meet you and be ready to go by 1:30 if that’s ok

**Jeff Bergosh**: That’s perfect Sava—I’ll plan on that!

**Jeff Bergosh**: Hey Sava—should I just swing by after work and pick up the signs?  Or do you think Mike Papadoulas will give us till Sunday?

Just don’t want to lose them or have them end up in the trash

Just please let me know and I’ll plan accordingly

Jeff B

**Sava Verazo**: We’re old friends He said we can get them Sunday. I also found out where her property starts and his ends so we can just move them down around the fish sign or take’m up and move to another location if 800 ft further down isn’t to ur liking, Sava

**Sava Verazo**: He said he’s turned down people like ur opponent and others cause once he allowed them and everybody started putting up every kind of signs even non political and advertising. No worries I have plenary of other sites 

**Sava Verazo**: Ah

**Jeff Bergosh**: Thank you Sava—so we can just move them Sunday.  Thanks very much for working that out!!

**Sava Verazo**: No worries

### CONVERSATION ON 03-08-2020

**Sava Verazo**: I’ll call you when I’m out of church 

**Sava Verazo**: I’ll call you when I’m out of church 

**Jeff Bergosh**: I’m here when you’re ready

**Sava Verazo**: There in 5 mins

**Sava Verazo**: I’m in the strip mall at Bower and Sorrento

**Sava Verazo**: Where are you ?

**Jeff Bergosh**: Okay I’m Across the street I’ll come right back

### CONVERSATION ON 03-12-2020

**Sava Verazo**: I put out 25 signs today!

**Jeff Bergosh**: That’s awesome thank you so much Sava!!!!!!!!!  That’s incredible!!!!!!

**Sava Verazo**: 
 Just curious, 
How many are in a full package like you gave me ?

**Jeff Bergosh**: 50 I believe

**Sava Verazo**: Then 25 more to go 👍

### CONVERSATION ON 03-13-2020

**Sava Verazo**: Call me when u can

**Jeff Bergosh**: Will do

### CONVERSATION ON 03-14-2020

**Jeff Bergosh**: That’s Awesome Sava!

### CONVERSATION ON 03-17-2020

**Sava Verazo**: Can you give me a quick call

### CONVERSATION ON 03-18-2020

**Jeff Bergosh**: Will do Sava

### CONVERSATION ON 03-20-2020

**Sava Verazo**: Give me a call when you can got something for you 

**Sava Verazo**: Your right, several older folks out here are stressing concerns that county leaders need to take the lead on doing more to shut beaches 

**Sava Verazo**: The board through Janis can direct the Sheriff’s office to keep folks off the beach, just my thoughts 

**Jeff Bergosh**: Thx

**Sava Verazo**: While I agree from the medical standpoint being outside at the beach is better, I’m concerned that if a large number of them do get sick they’ll flood the available beds in each of our three biggest hospitals leaving none for our locals. They could go back home and lay out in there own back yards. While not as fun as our beaches safer for our locals, just my thoughts 
Sava 

**Jeff Bergosh**: Yes I agree and that’s why we closed them 

### CONVERSATION ON 03-25-2020

**Jeff Bergosh**: Hi Sava—I’m in a meeting I’ll call u back

**Sava Verazo**: Ok

### CONVERSATION ON 03-28-2020

**Sava Verazo**: Call me when you can 

**Jeff Bergosh**: LOL I like that cartoon

### CONVERSATION ON 03-29-2020

**Sava Verazo**: Call me when u can please 
Sava 

### CONVERSATION ON 04-22-2020

**Sava Verazo**: It’s back up, Not sure how long it’ll stay up, we’re getting more stormy weather tonight and tomorrow

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: Thank you so much Sava!!

**Sava Verazo**: 👍

### CONVERSATION ON 04-28-2020

**Sava Verazo**: Good morning Jeff
FYI
Two separate poles show 75% of population said it’s a mistake to open up beaches right now another 80% said they’re not going out for another 2-4 weeks even if leaders open things up, I agree! Error on side if safety, just my thoughts !

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-05-2020

**Jeff Bergosh**: Doug’s secretary raised a whopping............wait for it................
Drumroll....................................$250
In his April report.    Conor MacGregor would say “That’s It!?!”

**Sava Verazo**: Very deserving wouldn’t you say!

**Jeff Bergosh**: Yes!  

### CONVERSATION ON 05-12-2020

**Jeff Bergosh**: In a meeting I'll call u right back

**Sava Verazo**: Call me when u can 

**Sava Verazo**: Call u back in 10 mins 

**Jeff Bergosh**: Will do

### CONVERSATION ON 06-03-2020

**Sava Verazo**: I need bout 10 more wires when we meet 

### CONVERSATION ON 06-28-2020

**Sava Verazo**: Hey give me a call back 

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Great News- I was just endorsed officially by the police union, the PBA!!  Can u believe it?  Will miracles never cease?!?

**Sava Verazo**: Fantastic my friend God is watching over you !

**Jeff Bergosh**: Thanks Sava!  I was stunned!  They’ve never endorsed me before so I am really happy I got it

**Sava Verazo**: Wow that speaks big !

**Jeff Bergosh**: Yep!  I’m supposed to get a letter and a check in the next couple of days from them.  Really cool!

**Sava Verazo**: Maybe make up small add on signs and I’ll help u stick’n in top of ur big ones like Owens did with the fire fighters 

**Jeff Bergosh**: LOL That’s not a bad idea!!

**Sava Verazo**: That should somewhat dilute his firefighters endorsement signs

**Jeff Bergosh**: Yep

**Sava Verazo**: And zap his ego ! 

**Jeff Bergosh**: He is going to be crestfallen that he didn’t get it 

**Sava Verazo**: Couldn’t of happen to a nicer fella 😁

**Jeff Bergosh**: 👍

**Sava Verazo**: FYI
I’ve saturated the area between the the intersection of old Gulf Beach Hwy and Sorrento Down to entrance of Perdido Bay Country Club entrance  and in front of Butches with ur signs 

**Jeff Bergosh**: Nice!!!  Thank you Sava!!

**Sava Verazo**: That’s a highly visible and traffic area. Owens group might take a couple of them out but they won’t get’m all, plus I have folks watching them with surveillance cameras

**Jeff Bergosh**: Awesome!

**Sava Verazo**: Ur welcome !

**Jeff Bergosh**: I greatly appreciate your help!!

**Jeff Bergosh**: Hey Sava- great talking to you today.  If you’re available and can assist—we will be doing campaign sign waving  on two Saturdays from 11:00-2:00. August 1st at the entrance to the Pensacola Interstate Fairgrounds and August 15th at the Kentucky Fried Chicken at the intersection of Mobile Hwy and Michigan Avenue.  If you could come down and help that would be awesome!!  I’ll have shirts for everyone and also I’ll provide sodas and lunch!  Thanks!!

### CONVERSATION ON 07-18-2020

**Sava Verazo**: Call me.....
Important 

**Sava Verazo**: When u can 

### CONVERSATION ON 08-18-2020

**Sava Verazo**: Morning......
I’m transporting older folks to the poles all morning that can’t drive them selves....
Good luck Jeff, prayers all day for you my man!

**Jeff Bergosh**: Thank you so much Sava I feel really good about today I think when it’s all said and done I win by 5 to 7 points and Johnathan takes third place and that I beat him by 15 points

**Jeff Bergosh**: Thank you for all the help that you gave me during my campaign I greatly appreciate it Sava

**Sava Verazo**: 👍

**Sava Verazo**: Wish I could of done more my friend 

**Jeff Bergosh**: You were incredible!! Thank you.  Your help us what is pushing me to this victory this evening!

**Sava Verazo**: Congratulations my friend !

**Jeff Bergosh**: You made it happen Sava!!!!

**Jeff Bergosh**: I’m so happy!! Thank you!!

**Sava Verazo**: Your the man!

**Sava Verazo**: Couldn’t see it on my screen.....
How did Owens do?

**Jeff Bergosh**: I beat him by 15 points

**Sava Verazo**: Couldn’t of happen to a nicer fella 👌

**Jeff Bergosh**: Thank you Sava! But I will say this opinions vary LOL

### CONVERSATION ON 08-20-2020

**Sava Verazo**: FYI
I saw Owens pulling up signs yesterday at noon.....
Was so tempted to roll window down and yell out.....”Told u so dummy!”

**Sava Verazo**: Or better yet....
“ tried to tell you Underhill tainted you!
Lol

**Sava Verazo**: And I’m sure it will take Jessie the rest of this year to take his One million signs down.....

**Sava Verazo**: Sorry The devils gotten in me this morning, I know It’s not the godly thing to do, but just so damn excited bout ur win have to blow a little energy off......
Congratulations again Jeff!

**Jeff Bergosh**: Thank you so much Sava ——without your help I don’t know if I could’ve pulled it off!!!

### CONVERSATION ON 08-21-2020

**Sava Verazo**: Call when u can 

### CONVERSATION ON 09-14-2020

**Sava Verazo**: Morning Jeff, water rising fast out here, can u get the road Dept to bring more sand bag material to the ball park behind the county sub-station. Folks are scrambling for it and it may not last long as it is, 
Thanks 
Sava 

**Jeff Bergosh**: I will- thanks for the heads up!

**Sava Verazo**: Thanks, 
Stay safe....

**Jeff Bergosh**: You too!

**Jeff Bergosh**: ......looks like this thing is inching closer our direction, eastward 

**Sava Verazo**: That what cuz in the NI weather bureau said!

**Sava Verazo**: Call me back please

**Sava Verazo**: Can they drop sand  behind the county sub station o. The old Gulf Beach Hwy side. 
The present site has a long line of cars waiting and are creating a traffic  hazard. It’s like too many kids waiting in line to use the water fountain. 

### CONVERSATION ON 09-20-2020

**Sava Verazo**: Morning buddy still digging out of the crap here. The Road guy failed us greatly. While we have time before another storm can there please be a couple or at least one more site for picking up sand out here in Perdido area or in ur district close to Perdido. Hundered of folks needed to sandbag lost much property because they spent needless hours waiting in a long line to get sand. Site needs to have accessibility from several side of the pils. The existing one site is like a water fountain line with one drinking while a hundreds are waiting for hours, finally leaving without sand.

**Sava Verazo**: FYI
Presently I have very poor phone service but folks out here in Perdido say Janis should be put in jail, one,to get her the hell out of the way and two,because she deserves it.......

### CONVERSATION ON 09-26-2020

**Sava Verazo**: Sorry.........
Ok front door is open 

**Sava Verazo**: Sorry.........
Ok front door is open 

**Sava Verazo**: Meant for my sister Jeff

### CONVERSATION ON 10-06-2020

**Sava Verazo**: Thanks for ur help Jeff

**Jeff Bergosh**: Absolutely Sava!

### CONVERSATION ON 11-29-2020

**Sava Verazo**: Hey Jeff hope you had a nice Thanksgiving staying safe could you tell me what the last day of pick up on the roadside as I still have a few more trees I got to get to roadside

**Jeff Bergosh**: Hey Sava— we’ll be picking up through Christmas— although we are asking that folks have their debris on the curb no later than Dec 1st

### CONVERSATION ON 12-25-2020

**Sava Verazo**: Merry Christmas to you and yours......
SavaClaus 

**Jeff Bergosh**: Merry Christmas Sava!

### CONVERSATION ON 01-01-2021

**Jeff Bergosh**: Happy New Year Sava!

### CONVERSATION ON 05-01-2021

**Sava Verazo**: Hey buddy, 
Give me a call please 
Sava

**Jeff Bergosh**: Driving through New Orleans right now but I will call you

**Sava Verazo**: ￼👍

### CONVERSATION ON 05-04-2021

**Sava Verazo**: Please Keep that under ur hat concerning Chance 

**Jeff Bergosh**: Absolutely 

### CONVERSATION ON 06-03-2021

**Sava Verazo**: Hey Jeff, 
Can you please call me when you have a min, 
Sava 

**Jeff Bergosh**: Will do.  In a meeting 

**Sava Verazo**: 👍

### CONVERSATION ON 06-09-2021

**Sava Verazo**: Hey buddy,
I still need to speak with you when you get a chance.....
Sava 

### CONVERSATION ON 06-23-2021

**Sava Verazo**: Hi Jeff,
Reminder,
HOA board member Don and Sava meeting at Butches Bistro tomorrow at 11:30, Lunch, then look at dangerous entrance into Perdido Country Club  neighborhood.

### CONVERSATION ON 06-24-2021

**Jeff Bergosh**: Hey Sava I just tried to call you I had a little bit of an issue at my job today and we got hit with some unexpected requirements that are going to necessitate that I’m in my chair at my desk in my office at 12 noon. Therefore I still want to meet with you guys but I don’t have time to sit down and have a lunch first. So I’d like to meet you all at the entrance to the country club at it between 11 and 1115 so we can talk about that entrance and what we need to do to get it fixed. Please call or text to verify to me that you got this and if that works 1115 at the entrance to the country club thanks and sorry about the last-minute modification

**Sava Verazo**: Plenary of room to Pull up on the shoulder as soon as u pull in 

### CONVERSATION ON 07-14-2021

**Jeff Bergosh**: Hope all is well— please share this with your HOA President.  More info to come as well!

**Sava Verazo**: Thank you so much Jeff, 
With the traffic getting worst by the day everybody’s been asking about it. This will sure quench their thirst for an answer thank you so much.
Sava

**Jeff Bergosh**: Absolutely.  It’s coming, early 2022

### CONVERSATION ON 11-18-2021

**Sava Verazo**: Can you talk for a min

**Jeff Bergosh**: Sure

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Hi Sava I am in a BCC shade session I’ll call u between meetings

**Sava Verazo**: FYI
On the subject of the roundabout......
I was the president of a super HOA group on the Key consisting of 11 condos and community HOA’s to address big issues on the Key. I was able to contact 6 of the 11 today since we found out that Underhill put it in the Agenda. They’re highly opposed to it saying it will slow traffic down even more than it already is, a turn lane to Johnson’s beach not a round about would better address the problem. 
The meeting Doug had was loaded with his plants. That’s what he does when trying to justify his addenda. I’d advise including DOT’s thoughts as well before going forward with any roundabout.
Savac

**Jeff Bergosh**: Okay thanks Sava

**Sava Verazo**: I just got call backs from three more who are also opposed, Spanish Key, Key West of Perdido and Pescadora Only 1 out of 9 said he had no opinion, key Harber group

### CONVERSATION ON 01-25-2022

**Jeff Bergosh**: I’ll call u right back

**Sava Verazo**: Good morning call me when you get a chance.
I don’t answer I’ll call you back 
thanks Sava

**Sava Verazo**: Send me the meeting info and the church again so I can pass that around 
thanks
Sava 

**Jeff Bergosh**: Will do

### CONVERSATION ON 01-26-2022

**Sava Verazo**: Good morning..
FYI
See statement put out by PSC:

**Sava Verazo**: 
FYI 
I’ve read the article that the public service commission posted on the rate increase. I’m meeting with legal counsel to get opinion on the part that mentions a separate higher rate for anyone that uses over 1000 kW./month Which is pretty much everyone. There was little or no opposition at the public service commission hearing because they sugar coated it stating that the average bill would only go up about $8 to $10 so no one really opposed when the emphasis should've been put on the higher rate for anything over 1000 kWh. That’s the same as a surcharge. That’s the part thats kicking everyone’s ass. Read the part that says the utility can not earn a profit on energy when applying for a cost increase due to higher fuel prices I think what they're doing is illegal based on the PSC own language.

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: Thanks

**Sava Verazo**: Good morning Jeff,
FYI 
Several of the committee folks in the HOA and elderly citizen requested that there be a chalkboard at the meeting this evening. Could you please have your people arrange that thanks. They also wanted to be Provided with contact information to the Florida Public service commission as well as contacting  Northwest Florida legislative group and the governor’s office. I was working out of town and couldn’t help them or I would have. 
Thanks Sava

**Jeff Bergosh**: I’ll see what I can do Sava— thanks for the heads up!

**Sava Verazo**: http://www.psc.state.fl.us/AboutPSC/MeetTheCommissioners

**Sava Verazo**: This site will help u direct energy complaint to your constituents as far as contacting public service commission committee men and women

**Sava Verazo**: When the picture of each of the commissioners on the public service website comes up you touch the one that you want and all the contact information comes up for each one of the members including the chairman.

**Jeff Bergosh**: Thanks Sava!

**Sava Verazo**: welcome

**Sava Verazo**: FYI
Broxton returned my call we had a long lengthy informative exchange of information. 
I’m sitting in a dentist chair with my jaw is jacked open I’ll tell you about it tonight.

**Jeff Bergosh**: 👍

**Sava Verazo**: Senator Broxton 
your constituents need your help. Florida Power and Light has doubled everyone's energy bill. Folks are having to do without medicine and food to pay the power bill. The Florida Public service commission needs to recall and re-address the misleading statement that FPL stated in there justification.
Sava Varazo
850-7122340

**Sava Verazo**: That’s what I sent to Senator Broxton below was one of his responses

