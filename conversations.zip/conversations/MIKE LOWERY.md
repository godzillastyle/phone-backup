

## CONVERSATIONS WITH MIKE LOWERY

### CONVERSATION ON 11-17-2019

**Mike Lowery**: Commissioner Bergosh,

FYI - Tonya Ellis is denying me Union Business tomorrow.  Which in turn prevents me from attending the BOCC Public Forum and Regular Business meeting at 8:30 a.m. and 9:00 a.m. while there is ECAT / ECCT agenda items.  Therefore, forbidding our members their voice at County “morning” meeting and silencing our 1st amendment rights to voice our opinions as an organization.

Mike Lowery

### CONVERSATION ON 06-04-2021

**Mike Lowery**: Commissioner Bergosh,

I thought you were spot on last night concerning the 401a plan.  PNJ is really disappointing….

Mike Lowery

**Jeff Bergosh**: Thx

**Mike Lowery**: Former Operations Manager at ECAT who resigned because he saw he was targeted by Transit Director Tonya Ellis and became a school bus operator for $12.50 an hour.  Plus, she blocked him trying to apply as a bus operator at ECAT wins a million dollars.  Can we say Karma!

### CONVERSATION ON 06-09-2021

**Mike Lowery**: https://www.facebook.com/1355533181/posts/10226111286752760/?d=n

**Mike Lowery**: Commissioner please check out ricks log article.  Thank you sir.

**Mike Lowery**: Ricks blog

### CONVERSATION ON 06-10-2021

**Mike Lowery**: Commissioner - just sent this to my members:

Updated news:

The first of 3 arbitrations for the unjust treatment of Local 1395 Union President / Business Agent Michael Lowery came in today.  The Arbitrator sustained the grievance in favor of Local 1395.  The Arbitrator awarded the one day suspension and any lost benefits back to President Lowery.  Along with strong language in favor of the Union.  The Arbitrator also sustained that Escambia County must pay the full amount of his fees = almost $5000.

1 down 2 to go!  Thank you to all of you for your support!

### CONVERSATION ON 06-11-2021

**Mike Lowery**: Good Morning Commissioner,

I just wanted to note I sent an email to your office for your review.

Thank you sir.

Mike

**Jeff Bergosh**: Ok thx Mike

### CONVERSATION ON 06-16-2021

**Mike Lowery**: https://ricksblog.biz/ecat-facilities-unacceptable/

### CONVERSATION ON 06-17-2021

**Mike Lowery**: Bravo!

**Jeff Bergosh**: Thx

### CONVERSATION ON 06-18-2021

**Mike Lowery**: https://ricksblog.biz/jail-conditions-hidden-from-bcc-public/

### CONVERSATION ON 06-21-2021

**Mike Lowery**: Hey Jeff,

Did you see the invite by ECAT / ATU to stop in tomorrow or Wednesday for our Maintenance apprenticeship training dialogue?  Tonya sent you an invite last Friday to your district1@myescambia.com email.  It would be amazing if you stopped in.  You’ll be impressed by the ATU apprenticeship programs and funding sources.  

Mike Lowery

**Jeff Bergosh**: I did get the invite unfortunately my schedule precludes me from attending.  Thanks for the invite though!

### CONVERSATION ON 06-24-2021

**Mike Lowery**: Good Morning Commissioner,

On Tuesday and Wednesday the ATU leadership brought in Jermaine Gibson who is the Workforce Coordinator for ATU out of Washington DC.  Under my direction he educated ECAT Management and some Fleet Maintenance Management of the ATU Apprenticeship / Training / Mentor  programs that literally will bring in new Technicians and Bus Operators from all areas such as Veterans, local applicants, and right out of the high school ranks.  These programs would be paid by Federal dollars.  Jermaine educated Management on how this Department of Labor program along with many other programs is a Union Labor Organization / Transit Agency joint partnership.  For example:  A new hire who is under the apprenticeship program there would be $5000 per trainee to train them and as long as they are under the program the program would pay for 1/2 the new hires hourly salary for a minimum of one year.  There is also a mentor program that would develop a stronger workforce which ultimately would create loyal employees.  Please feel free to call me or ECAT Deputy Director Rodriques Kimbrough for his thoughts of implementing this apprenticeship program immediately at ECAT.

Thanks,

Mike Lowery

**Jeff Bergosh**: That sounds like a great plan

### CONVERSATION ON 06-29-2021

**Mike Lowery**: Hello Commissioner Bergosh,

Could I call you this afternoon for a brief discussion with you?

Mike Lowery

**Jeff Bergosh**: Sure

**Mike Lowery**: Can I call you at 3:00 pm?

**Jeff Bergosh**: Sure

### CONVERSATION ON 06-30-2021

**Mike Lowery**: 
Commissioner,

Here is the letter sent to my attorney.  This shows the second arbitration case was weak too.  The third case (termination) will be even more embarrassing as well for the County.  I was fighting for protective measures on COVID for the workers in March 2020 during the Pandemic.  

The thing is when I spoke to the media at ECAT - I was off duty and in a public area.  The next day the protective measure I was fighting for - y’all (the Commissioners) agreed to.

Mike Lowery
(850) 554-6034

**Jeff Bergosh**: Thanks Mike

**Mike Lowery**: https://ricksblog.biz/bus-union-prez-wins-another-arbitration/?fbclid=IwAR356IBfMoJwjhuIZqsdVXJCqKSi_iN9WAI194QZatMXejUJB6ieobG5l6Y

### CONVERSATION ON 07-07-2021

**Mike Lowery**: Commissioner - FYI - I just sent you an informational email to your myescambia account.

Mike Lowery

**Jeff Bergosh**: Got it.  Thanks

**Mike Lowery**: No Sir.  Thank you for actually paying attention.  

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-08-2021

**Mike Lowery**: Good Morning Commissioner,

Please check your email (MyEscambia email).  ATU International VP Curtis Howard sent you an email with an attachment.

Thank you sir!

Mike

**Jeff Bergosh**: Got it

### CONVERSATION ON 07-20-2021

**Mike Lowery**: CDC review in September 

**Mike Lowery**: Talks say it will likely be extended through the year.

**Jeff Bergosh**: Thx Mike

### CONVERSATION ON 07-26-2021

**Mike Lowery**: https://ricksblog.biz/ecat-pay-raises/?fbclid=IwAR0pGzLQkNyrfle_3buxNHWikBrF3V3mc-G9yHA4knWstOj9_vEodNhJs9o

**Jeff Bergosh**: 👍💥

### CONVERSATION ON 07-30-2021

**Mike Lowery**: https://ricksblog.biz/atu-prez-pam-childers-literally-lied/?fbclid=IwAR1RFLQa7aj8YYJwUwG7FueO8vOlpjSuD4AQ0phtXt44vqozKwFXECns4qU

**Mike Lowery**: https://ricksblog.biz/breaking-bus-union-approves-wage-agreement/?fbclid=IwAR2a8626F2Ub5H9ParR1b25GC_XiMF-XryJPW2T0E9QFczeL5suvEk-vW7w

### CONVERSATION ON 08-05-2021

**Mike Lowery**: Commissioner 

Tonight’s meeting - to long.  Had to leave.  Please support ECAT raise.  Thank you 

Mike

**Jeff Bergosh**: We did

**Jeff Bergosh**: Congrats

**Mike Lowery**: Thank you sir. 

### CONVERSATION ON 08-11-2021

**Mike Lowery**: Wage MOA signed!

**Jeff Bergosh**: Congratulations Mike!!

### CONVERSATION ON 08-12-2021

**Mike Lowery**: Good Morning Commissioner,

FYI - ATU filed an unfair labor practice charge against ITL Solutions a few months back tied to the intermingling of work.  The attached is UC (Unit Clarification) petition against ITL we filed against them a couple days ago.  ITL is using ECCT drivers / county vehicles to do their Medicaid Florida State contract.  That should be very concerning to the County.  The overseer of ECCT (Transit Director) is fully aware of this intermingling of work by ITL.  Concerns of mileage, fuel, etc.  The Union is demanding we now represent all ITL drivers for both the County contract and the State contract.

Mike

### CONVERSATION ON 08-18-2021

**Mike Lowery**: https://ricksblog.biz/lowery-reports-possible-covid-death-among-county-workers/?fbclid=IwAR16LOvYHK6peEHEdr6SL7u1XfQby2gcZEwG283EBjpXj6ncG2gXjQMQFAc

### CONVERSATION ON 08-31-2021

**Mike Lowery**: Commissioner 

ECAT system in dire straights!  This old trolley had to be used today on Route 52 (Cordova Mall, Sacred Heart Hospital, PSC).  Our fleet is tore up.  No spare buses….

**Mike Lowery**: This is the normal bus on this route - ☹️

**Mike Lowery**: BTW - My arbitration coming up September 22nd.

**Jeff Bergosh**: Thx for heads up

### CONVERSATION ON 09-27-2021

**Mike Lowery**: Good Morning Commissioner,

I’m happy to report that ATU representing ECAT for the third negotiation session in a row had positive movement with Management under Wes Moreno’s leadership.  We now have 31 articles reached with tentative agreements.  We still need to address about 25 articles but as long as both parties make the effort to meet frequently in October and November we should be able to finalize the labor contract.  That is the goal of the Union.

Mike Lowery

**Jeff Bergosh**: Thanks Mike for the update glad to hear it’s moving in the right direction!

**Mike Lowery**: Just need commitment of setting up more negotiation sessions by the County Management team. 🙏

**Jeff Bergosh**: Seems like a reasonable request I think that will happen

### CONVERSATION ON 10-06-2021

**Mike Lowery**: Good Morning Commissioner BERGOSH,

First and foremost.  I hope you and your family are doing well.

My text today is about my concerns of my members at both ECAT and the Operational units.  I’m getting a lot of calls about staffing concerns or the lack thereof by existing workers.  For example at ECAT recently two more employees gave notice to resign.  ECAT is about 25 bus operators down which is over a 1/3 of the driver work pool.  Full staffing of bus operators is normally about 71.  In maintenance, we lost 3 Master Technicians in the last 2 months with one giving notice yesterday even after the substantial raise given.

I would love to discuss with you my thoughts, ideas, and concerns at your convenience.  I really think that County Management and the Union-leadership should be communicating about this.  This is critical sir.

The overtime at ECAT is crazy.  Some drivers reporting they getting 30/40 and upwards of 60 hours OT each pay period.   While that’s great for their bank accounts  I’m seeing more safety concerns, more accidents and over all bum out causing the opposite affect.

So, I hope to hear from you soon to discuss.

Thanks so much,

Mike Lowery

**Jeff Bergosh**: Mike- I share your concerns however I will be leaving the country and will not return until Wednesday of next week so I will make it a point to get with you towards the end of next week to discuss these very important issues

**Mike Lowery**: Thank you sir.  Safe travels and enjoy.  

### CONVERSATION ON 10-08-2021

**Mike Lowery**: Commissioner BERGOSH,

Here is the transcript from my termination arbitration.  I thought you might want to check it out.

Mike Lowery

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 10-09-2021

**Jeff Bergosh**: I’ll give it a read, thanks Mike

**Mike Lowery**: Opening statements by attorneys was very interesting.

**Mike Lowery**: Opening statements by attorneys was very interesting.

