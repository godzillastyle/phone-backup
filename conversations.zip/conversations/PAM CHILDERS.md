

## CONVERSATIONS WITH PAM CHILDERS

### CONVERSATION ON 08-06-2020

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Thanks I lumped them all in the same bucket

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thank you Pam!!!

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: Okay will do thanks for the heads up

### CONVERSATION ON 07-22-2021

**Jeff Bergosh**: Do you have something in writing that says the 401a for elected officials is illegal?

**Jeff Bergosh**: Thank you.

Jeff Bergosh

District1@myescambia.com

**Jeff Bergosh**: Thank you!

