

## CONVERSATIONS WITH RON SCORZELLI

### CONVERSATION ON 11-13-2019

**Ron Scorzelli**: Hey Jeff,   Just checking if you wanna golf Sunday?

**Jeff Bergosh**: Hey Ron thanks for thinking of me and I wish I could I already made plans for this Sunday afternoon can we shoot for later in the month?

**Ron Scorzelli**: Sounds good    I’ll touch base in a week or so. 

**Jeff Bergosh**: Right on!

### CONVERSATION ON 11-28-2019

**Ron Scorzelli**: Happy Thanksgiving !

**Jeff Bergosh**: Happy Thanksgiving Ron!

### CONVERSATION ON 01-17-2020

**Ron Scorzelli**: I’m in.   

### CONVERSATION ON 01-18-2020

**Jeff Bergosh**: 👍

**Ron Scorzelli**: K.  Leavin at 8.   If changes let me know.   Thxs 

**Ron Scorzelli**: Thxs ! everybody played really well.  I’m in for next Saturday

### CONVERSATION ON 04-10-2020

**Ron Scorzelli**: 🦠👍

### CONVERSATION ON 04-17-2020

**Ron Scorzelli**: Based on weather report I'm looking at ,  I say call it now.      Don't want to make ride for nothing.    Hope this ok.   But you asked.  Lol 

**Ron Scorzelli**: K

### CONVERSATION ON 04-18-2020

**Ron Scorzelli**: 👍 

**Jeff Bergosh**: You all have a great weekend- see you all next week

**Ron Scorzelli**: Everyone have great weekend.   A lot of great shots today.  

### CONVERSATION ON 04-22-2020

**Ron Scorzelli**: In👍

### CONVERSATION ON 04-25-2020

**Jeff Bergosh**: 👍

**Ron Scorzelli**: 👍

### CONVERSATION ON 05-01-2020

**Ron Scorzelli**: 👍

### CONVERSATION ON 05-08-2020

**Ron Scorzelli**: 👍

**Ron Scorzelli**: It's a reach at best.   

### CONVERSATION ON 10-10-2020

**Ron Scorzelli**: Hey Jeff,    I know it’s short notice. But checking to see if you wanna golf tomorrow?

**Jeff Bergosh**: Hey Ron— Id be up for that if we can do it in the afternoon after church.  What time are you thinking?

**Jeff Bergosh**: ... and which course?

**Ron Scorzelli**: What is closest  course to you. ?

**Jeff Bergosh**: Scenic Hills or Osceola or Marcus Pointe

**Ron Scorzelli**: I’ll check in morning for scenic in the afternoon.   Ok?

**Jeff Bergosh**: Sounds great- let me know what time & I’ll be there.

**Jeff Bergosh**: Thanks for the invite!

**Ron Scorzelli**: Ok will do.  

### CONVERSATION ON 10-11-2020

**Ron Scorzelli**: Hey Jeff I’ll meet you at scenic at 2pm.    They only have front nine open but we can loop it if that’s ok.   See you then.

**Jeff Bergosh**: Right on- see you then!

**Ron Scorzelli**: Got cart meet you in parking lot

**Jeff Bergosh**: Okay almost there

**Ron Scorzelli**: 10-4.  No rush

### CONVERSATION ON 10-30-2020

**Ron Scorzelli**: Hey Jeff,   Unfortunately I have to cancel Sunday golf.   My 93 year old mom is here.    I’m good on Sunday November 29th or December 6th

### CONVERSATION ON 10-31-2020

**Jeff Bergosh**: November 29th sounds great— Tiger Point 12:00 noon?

**Ron Scorzelli**: Sounds good

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-27-2020

**Ron Scorzelli**: Hey don’t know if you were still on for golf Sunday.   But weather looks bad.

**Jeff Bergosh**: Yeah Ron I saw that too : 70% chance for rain.  Want to push it one week to the 6th?

**Ron Scorzelli**: Sounds good touch base during week.  

**Jeff Bergosh**: Okay sounds good Ron!  Have a great weekend!

**Ron Scorzelli**: You 2.      

### CONVERSATION ON 12-05-2020

**Jeff Bergosh**: Hey Ron— we playing Golf tomorrow at Tiger Point?  I’m up for it if you’re still available at 12:00.  Just let me know— hope all is well

Jeff B

**Ron Scorzelli**: Hey thought I see you at the courts.      Can you do 1pm?

**Jeff Bergosh**: Yes

**Ron Scorzelli**: Ok I’ll call now for t time

**Ron Scorzelli**: We are set 1pm

**Jeff Bergosh**: Right on I’ll see you there at 1:00! Thanks for setting it up

**Ron Scorzelli**: Np. 

### CONVERSATION ON 12-25-2020

**Ron Scorzelli**: Merry Christmas bud🎁🎄

**Jeff Bergosh**: Merry Christmas!!

### CONVERSATION ON 02-08-2021

**Ron Scorzelli**: Hey Jeff , haven’t forgotten you.  Unfortunately Sunday is Valentine’s Day lol.  😂.   So golf is out.   Plus weather is gonna be freezing.      Maybe 28th.

**Jeff Bergosh**: Thanks Ron!  I totally understand.  Yes lets shoot for the 28th.   Hope all is well!

**Ron Scorzelli**: All well.   Sounds good

