

## CONVERSATIONS WITH JOHN PEACOCK

### CONVERSATION ON 08-04-2020

**John Peacock**: Heard your response on district only commissioners.  I have written a paper that I would like you to read. Please send me your personal email address.  This is John peacock if you don’t have me in your phone 

**Jeff Bergosh**: Jeffbergosh@gmail.com

**Jeff Bergosh**: Thanks John

**John Peacock**: Sent

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2020

**John Peacock**: Congrats 

**Jeff Bergosh**: Thanks John!

### CONVERSATION ON 08-19-2020

**John Peacock**: Let me know when you want to chat about my paper 

### CONVERSATION ON 08-20-2020

**Jeff Bergosh**: Will do John— looking forward to it!

### CONVERSATION ON 03-25-2021

**John Peacock**: I’m 100% behind your discussion of at large.  While the intent was clearly to provide a voice to the minority population an argument can easily be made that the socio-economic status of minority population has not improved as a result.  That is because of the myopic thinking (ward politics as you call it)    Another option would be to elect the county executive that would have direct accountability to the voters and have to work with all commissioners.  Executive/legislative branches.  Let me know how I can help. A change is desperately needed

**Jeff Bergosh**: Thanks we will be discussing this issue at our morning meeting

**John Peacock**: I saw that.  Thank you.  A voter should be able to effect change with their vote. Our current system prevents that in only being able to vote for 1 and 3 others can vote to have a negative effect on you and you are powerless to change.  With at large you get a shot at three votes and would need the remaining 4 to vote the same way.   The voter has a better shot.  If you look at the QOL surveys for the past 12 or so years the status of the  minority population has not improved. Lumon would have a hard time saying the change to the current form has benefited his constituents.  The elected executive is the best option because then it would force someone to run on a platform 

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: I thought it was a worthwhile idea but there was no appetite whatsoever from my peers During our Meeting yesterday. unfortunately they’re very comfortable with the status quo.

**John Peacock**: I was disappointed that there was just a very cursory discussion. You were correct to point out the system is broken but no one discussed to fix

**Jeff Bergosh**: No appetite whatsoever for any kind of fix or change which is lamentable. Because you are right it is a broken system when one commissioner can hold up a very important worthwhile and legal project because one citizen or two don’t like it

**John Peacock**: I definitely believe we need an executive branch so that one person is accountable to the entire community

### CONVERSATION ON 03-30-2021

**John Peacock**: HWY 29 through car city should be renamed Ted Ciano Blvd.  He started car city and did so much for our community   Now that the Ciano name will no longer be anywhere in car city, renaming part of 29 will make sure his name carries on

**Jeff Bergosh**: That seems reasonable.

**John Peacock**: How do we make that happen?

**Jeff Bergosh**: The commissioner for that district

**Jeff Bergosh**: Lumon May

**John Peacock**: Thanks

**Jeff Bergosh**: 👍

**Jeff Bergosh**: There is a better way for the county to govern, John.  I’ve described it in the above blog post if you’d like to check it out.

**John Peacock**: Thanks. My viewpoint under development as we speak. I appreciate your forward thinking 

**Jeff Bergosh**: I look forward to reading it.  

### CONVERSATION ON 04-17-2021

**John Peacock**: https://www.pnj.com/story/opinion/2021/04/17/want-save-escambia-county-new-form-government-needed/7228386002/

**Jeff Bergosh**: Saw it this morning.  Nicely done, appreciate the kudos

**John Peacock**: Take it and run.  No down side to forming a committee to discuss

### CONVERSATION ON 05-20-2021

**John Peacock**: Love the shipyard idea    So much potential there including some current port operations.  Let me know how I can help 

**Jeff Bergosh**: Will do.  We need a lot of money

### CONVERSATION ON 06-03-2021

**John Peacock**: You have no evidence To make the claim that someone “purposely “ withheld information.  That’s a preposterous and inflammatory statement 

**John Peacock**: How many people have left the county and now can come back and ask for back pay.  This could be a staggering number 

### CONVERSATION ON 06-17-2021

**John Peacock**: Barry lied.  If the new rates were adopted then the taxpayers would save money.  He said that the taxpayers cost is the same regardless 

**John Peacock**: This is a moral and ethical issue.  No one deserves 40 plus percent 

**John Peacock**: Exclude elected officials for this

### CONVERSATION ON 09-27-2021

**John Peacock**: 6 ambulances available for all of Escambia county tonight?  Mom fell again at ALF , been 40 minutes, still no EMS

### CONVERSATION ON 09-28-2021

**Jeff Bergosh**: I hope all’s well with your Mom.  We’re working to improve our staffing levels but this is a national challenge all over the place keeping enough EMTs and paramedics on staff.

**John Peacock**: Took 90 mins inside city limits.  Supposed to be 10 ambulances but only had 6 including 2 up north.  I’d like to see that data that this is a national issue.  Do we even have 10 operational ambulances?

**Jeff Bergosh**: We have 30+

**Jeff Bergosh**: The issue is crews to staff them

**John Peacock**: Well it’s the most basic function of government and we are failing 

**Jeff Bergosh**: We’re not failing— we’re Struggling with the same staffing challenges every city county and major metropolitan area in the country is also fighting against

**Jeff Bergosh**: Labor is the new big issue and a lack of people who wanna work is creating tremendous ripple effects throughout the country this is not limited to the EMS department of Escambia county John that’s a major oversimplification

**John Peacock**: I watched my mom lie in the ground screaming in pain for 90 mins waiting for a service we pay a premium for inside the city limits 

**Jeff Bergosh**: Where was the Pensacola fire department? You do pay a premium for them and they make a tremendous pay where were they? If it was a lift assist they should’ve been on scene within five minutes

**Jeff Bergosh**: Ask Grover about that

**John Peacock**: I called 911. Routed through Escambia county   The fear was that She may have broken a hip again.  It was not just a lift assist

**John Peacock**: She had to go to ER

**Jeff Bergosh**: I hate to hear this John.  Did we transport her upon arrival—- and most importantly— is she okay?

**John Peacock**: The EMS were wonderful and extremely apologetic. My issue is not with them

**Jeff Bergosh**: Thanks they are good people that work there.  Also I don’t want to seem Calous. I understand this is a very important issue and so I am going to speak to the director of public safety this morning about it to get the specifics of this individual case and why our response time was so long

**John Peacock**: I would like to speak to mr Gilmore myself 

**Jeff Bergosh**: I’ll ask him to call you

**John Peacock**: I sent an email last night requesting a call

