

## CONVERSATIONS WITH BARBARA MAYALL

### CONVERSATION ON 12-02-2019

**Jeff Bergosh**: Sorry, I can't talk right now.

**Barbara Mayall**: Can you call when you get a minute please? 

**Jeff Bergosh**: Sure will 

**Barbara Mayall**: Thanks 

### CONVERSATION ON 12-05-2019

**Barbara Mayall**: Thanks Jeff. Let me ask if you are willing to vote on a compromise? Dont have a cash lane during peak times for instance spring break-labor day, Blue Angel  etc. and after labor day please open one cash lane. Please? What can that hurt? It may increase off season visits to beach! Incentives!

**Barbara Mayall**: BTW Ryan Crane said you were the only Commissioner to respond! 

**Barbara Mayall**: Please have town hall meeting 

**Barbara Mayall**: Good ideas on all

### CONVERSATION ON 02-06-2020

**Barbara Mayall**: Are you going to address the REAP issue at budget hearings?

**Jeff Bergosh**: I've requested staff to look into the mold issues

**Barbara Mayall**: Thank you. I'm an advocate for these types of programs, just need them to be safe 

**Barbara Mayall**: I hope this will be fixed as well.

**Barbara Mayall**: Is that what the $500. is for?

**Jeff Bergosh**: No-- just for general support of the organization

**Barbara Mayall**: $5,000 for support??? No improvement 

### CONVERSATION ON 02-08-2020

**Jeff Bergosh**: I'm working that on a separate track

**Barbara Mayall**: Thanks

**Barbara Mayall**: This felt has been on this roof for a while. Just thought you might want to know. It may have something to do with mold. 

**Jeff Bergosh**: Thanks Barbara

**Barbara Mayall**: Thank you 

### CONVERSATION ON 04-02-2020

**Barbara Mayall**: The dr. Along with patients coming over are not from Escambia County.  Please help our District 

**Barbara Mayall**: Please Jeff 

**Barbara Mayall**: D4 is not responding to constituents.  Ee need help with Louisiana coming in yo get "elective surgery" please help us!!

**Barbara Mayall**: Sorry about mistake 

**Barbara Mayall**: And we are allowing Hotspots like Louisiana coming in to get abortions in D4 and packing in AFP like sardines 

### CONVERSATION ON 08-19-2020

**Barbara Mayall**: Congratulations Jeff.

**Jeff Bergosh**: Thanks!

### CONVERSATION ON 10-18-2020

**Barbara Mayall**: Taking Home made peanut brittle orders today! Peanut brittle made by the FIRST PENTECOSTAL CHURCH Ladies. How many ? $2.00 a pie pan size

### CONVERSATION ON 11-19-2020

**Barbara Mayall**: Last call for peanut brittle! making today

### CONVERSATION ON 11-09-2021

**Barbara Mayall**: Barbara Mayall here. FPC making peanut Brittle Thur. Want some?

