

## CONVERSATIONS WITH LARRY KELLY

### CONVERSATION ON 02-26-2020

**Larry Kelly**: Commissioner Larry Kelly no rush can you give me a call I'm confused on a boundary line of your District

**Jeff Bergosh**: Thanks very much for all your help Larry!

**Larry Kelly**: If you ever need it my email address is 

larrykelly1901@ gmail.com

**Jeff Bergosh**: Got it!  Thanks!

### CONVERSATION ON 05-19-2020

**Larry Kelly**: Put a big sign at the feed store Home Pine Forest Road across from 5 Flags right next to the sheriff big sign you on the left sheriff in the middle Stacy on the right

**Jeff Bergosh**: Right on Larry!!  Thank you and will do!!

### CONVERSATION ON 06-19-2020

**Larry Kelly**: Hitman Larry Kelly I need you to call me when you get a chance we are problem for this ballpark people in this neighborhood not Justa Street this neighborhood is not happy

**Larry Kelly**: I pocket called you man I didn't mean to

### CONVERSATION ON 06-24-2020

**Jeff Bergosh**: Hey Larry-- I have a call in to Michael Rhodes-I will call you as soon as I hear back from him

**Larry Kelly**: By the time you hear back from him the damage will be already done it took years to get this buffer back from last time and now Michael Rose is tearing it down again I thought that you and me and somebody from the parks what's going to meet out here before all this stuff started but I guess I thought wrong

**Jeff Bergosh**: Larry I had no idea this was happening today.  Your call is the first I'm hearing of this and yes, I am wanting to meet with you and Michael our there but I thought from our conversation the burning issue was the dust.  So I got that handled that day.  I'm working as fast as I can Larry

**Larry Kelly**: Wilson Robinson planted trees back there done everything in his power to make wrong right Michael Rose knows this he was right in the middle of it but now that Wilson is gone I guess he just does anything he wants

**Jeff Bergosh**: I'll get this fixed. Working it right now

**Larry Kelly**: Thanks I have not lost faith in you so don't get me wrong I know you just inherited this mess

**Larry Kelly**: That is why I wanted you somebody from Parks and me to get back here I want you to be aware of all of the bad problems we have back here and Parks needs to fix it I think politics got Michael Rose his job I personally don't think he's capable of it I am not two-faced I will never say something behind your back that I won't say to your face

**Jeff Bergosh**: Thanks Larry.  I'll get to the bottom of it and I'll get it fixed you can take that to the bank!  Thanks!👍👍

**Larry Kelly**: I know you will you can ask anyone that knows me and they will tell you then when it comes to county commissioner I will tell them all you are the best

**Jeff Bergosh**: Thanks very much Larry-- greatly appreciate it.  Whatever it takes we will fix this.

### CONVERSATION ON 06-25-2020

**Larry Kelly**: Michael Rhodes call me yesterday I called him back this morning I thought that you would set it up where we could have a meeting out here this week I want to keep this traffic flow like Wilson Robertson had it if Michael Rose has his way it's going to really stir up a storm where the County Commissioners 

**Larry Kelly**: I talked to Michael Rose this morning and it was not a friendly conversation

**Larry Kelly**: He is all about his ballpark and his ball players what he does to his neighbors is not his concern

**Larry Kelly**: If it's possible why can't you and me meet back here leave Michael out of it then then you and Parks can do whatever y'all see fit Michael was slinging the F-word around I told him there was no reason for him to do what he's done back here my neighbor next to me he has really butchered her buffer and she wants it 

**Jeff Bergosh**: I'll be out there this afternoon

**Jeff Bergosh**: I'll get it fixed

**Larry Kelly**: I realize all of that but I think you need to lay your eyes on it I was with a customer so I couldn't get right back with you

**Jeff Bergosh**: I understand and I will.  It's been super hectic here today--in and out of meetings and a major uptick in COVID 19 cases.......

**Larry Kelly**: I understand

**Larry Kelly**: When you come this afternoon or you going to call me and let me meet over there with you

**Jeff Bergosh**: Sure will

**Larry Kelly**: Thanks

**Jeff Bergosh**: 👍

**Jeff Bergosh**: On way over there from my office on NAS Pensacola.  I'll call u when I get there

**Larry Kelly**: OK sounds good

### CONVERSATION ON 06-26-2020

**Larry Kelly**: You and Michael do whatever you want back there you're going to anyway I'm coming to the County Commissioners meeting I've got somebody checking whether it's this Thursday or next Thursday the other commissioners and the people in District 1 need to know how you treat their neighbors when we met you had to close ears to everything

**Jeff Bergosh**: ???

**Larry Kelly**: 24 feet from the chain link fence to where the markers that I want to protect the buffer if you will meet me out here and listen to our problems with an open mind instead of what just telling me what you and Michael Rose is going to do we might can get it fixed you're out here making decisions on what you know very little about

**Jeff Bergosh**: We are pulling the paving project for now--I'm going to have it re-assessed to make sure it doesn't infringe on the buffer and I am requesting drawings for the project.  In the meantime I'm requesting additional plants be planted to thicken the buffer.  Until we get the drawings for the paving and get that sorted out-we will keep the water trucks coming out to keep the dust under control.  Given time, I'll get things fixed properly Larry.  👍

**Larry Kelly**: That's all fine and good I personally think you're getting the cart ahead of the horse I think it needs to be paved first then I think the reflector poles need to go up next then you can feel in the plant but we do need to iron this out before the next commission meets

**Jeff Bergosh**: I want to see drawings first before they just go out and pave over-- this way they won't infringe on the buffer.  This will take some time but when I get the drawings I'll go over them with you before we start the paving.  This could take a while--but this way everyone will be on the same page before the work starts.  I'll let you know when I get the drawings.  Will probably be several weeks out.

**Jeff Bergosh**: Have a great weekend!

**Larry Kelly**: This ain't no football game I'm not going to let you stand there and run the clock out it starts coming to that I want the Commissioners and everybody to know what the neighbors want out here

**Jeff Bergosh**: Call me

**Larry Kelly**: You're forgetting I do this for a living you can go to planning and zoning and have them plans in 1 hour

**Jeff Bergosh**: Call me

### CONVERSATION ON 06-29-2020

**Larry Kelly**: Me and Parks could not agree so I'll see you Thursday at 4:30 and we'll get this out on social media and let the public be the judge

**Larry Kelly**: I don't think the County Administrator is aware of what went on this morning back there I can't find any Common Sense nowhere in parks

**Jeff Bergosh**: She is going to call you

**Larry Kelly**: I will be on the lawn mower for about another 30 minutes maybe 40 I'll put my phone on vibrate and Hope did I can hear her call

**Larry Kelly**: It is my understanding that the county road department is going to be the ones to pave this road can you get one of them to meet me back here I want to avoid testifying before the Board of Commissioners because you and Parks are not going to like what I'm going to have to say I would like to see if we could resolve this before Thursday I did not know that when you testified before the commissioners you could download it and put it on social meeting

**Larry Kelly**: That was supposed to be social media not meeting

**Jeff Bergosh**: I'm passing this to Janice Gilley

**Jeff Bergosh**: She will be calling you Larry

### CONVERSATION ON 06-30-2020

**Larry Kelly**: I just spoke with the County Administrator she said she has been out here and without Gathering the facts she has listen to Michael Rose and Ken Shelby it seems to be a one-sided deal and and Kenny seems to be the boss what you promised Ken Shelby stated that ain't going to happen what I am asking is not unreasonable and to let Michael Rose talk to your people and swing them F words to the ones that pay his salary is a disgrace the problems that the commissioners before you addressed and fixed you have torn down

**Jeff Bergosh**: What did she say??

**Larry Kelly**: She pretty much said she has been out here and look and she is happy with what can Shelby wants to do what I am asking is not unreasonable now is the time to fix the problem but I think it's not the county commissioner it's not the County Administrator it's not the head of parks is Ken Shelby that has all the power and the rest that I have mentioned bowels down to him My Neighbor Next Door is horrified over what they have done and her safety is in jeopardy like I said it is a disgrace

### CONVERSATION ON 07-21-2020

**Larry Kelly**: If you want to know why I turned so bitter against you I met with Michael Rose and Ken Shelby Shelby told me in so many words he didn't care what you promised me he was not going to do it and Michael Rose back him up so I figured you told them what to do

**Jeff Bergosh**: I never authorized them to say that Larry.  I'm just trying to do the best I can under excruciatingly difficult circumstances.  Just lost a friend to COVID-19 and it has me really, really depressed and concerned. This thing is for real and I'm worried.  Thanks for reaching out and letting me know this.  

**Larry Kelly**: Sorry about your loss I have lost many a good friend and I know how hard it is to deal with especially the way you have lost your friend I am a designer and I am well respected in what I do this project could be really good if it was done right but I'm telling you these two guys are not qualified to do the job again my heart sincerely goes out to you and your loss

**Jeff Bergosh**: Thanks Larry.  It hurts.

### CONVERSATION ON 08-26-2020

**Larry Kelly**: Hi Jeff this is Larry I'm in the process make an appeal to the governor and to the state legislature I have been asked to try to work this out with you as County Commissioner so I am requesting a meeting on the ball Park Road with you Michael Rose and maybe the County Administrator I think you will need to know all of the facts before you make a decision on how to handle this it involves the health and mental stress that you are putting the disabled and senior citizens some have said it is bordering on abuse-of-power

