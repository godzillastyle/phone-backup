

## CONVERSATIONS WITH TODD HUMBLE

### CONVERSATION ON 11-07-2019

**Todd Humble**: I am designing a shade sale version of this idea so can have huge visual impact.  No architect fees just to get an estimate from a mock up

**Todd Humble**: Great outdoor storytime venue and summer reading events on tolerable days

### CONVERSATION ON 11-08-2019

**Todd Humble**: STOA Architects has  schedule of 100% design final ready to bid the end of February (2.23.2020 in current estimated time line).

**Jeff Bergosh**: Outstanding!  Thanks for the update Todd

### CONVERSATION ON 11-21-2019

**Todd Humble**: Do you have a couple minutes to talk?

**Todd Humble**: In general I am going to slow architect as they changed concept from modern back to traditional.  I am good with internal footprint progress but exterior has went wrong way.  I hope not much delay, but none of exteriors are even close to the 10% image.  We only have once to do this right and I don’t want to rush to the common.

**Todd Humble**: their idea was to cut corrugated metal at various angles to create flat walls that have illusions of depth.  

**Todd Humble**: That is just a normal square corner

**Todd Humble**: This was information I was going to say... frustrated none of the 35% exterior concepts advanced the idea

### CONVERSATION ON 12-16-2019

**Todd Humble**: http://kaz-shirane.net/light-origami/

### CONVERSATION ON 01-22-2020

**Todd Humble**: Good morning,  I am heading to Hardee’s now but be 15 minutes plus or minus depending on traffic from ten mile to there

**Jeff Bergosh**: Fantastic thanks Todd

### CONVERSATION ON 01-24-2020

**Todd Humble**: Still not there but close

**Jeff Bergosh**: Can I publish these renderings?

**Todd Humble**: They worried is gonna cost to much to achieve, but will seek informal estimates with this design

**Todd Humble**: I am worried size

**Todd Humble**: I think this okay because doesn’t show too much and photo to follow

**Todd Humble**: The above to are vague enough to say getting closer on design passing 35%.  Still a work in progress, but getting closer

**Todd Humble**: Above two

**Todd Humble**: The above two don’t scare me as over promised (close to front and inside a reading area

**Jeff Bergosh**: Okay.  Thanks very much Todd!

**Todd Humble**: Want me to try and get higher resolution from architecture firm rather than photo of print?

**Jeff Bergosh**: That would be awesome!! If you could email them to me that would be great.  Only send me the ones you are comfortable with me putting on the blog so folks can see the vision of what we’re trying to do

**Todd Humble**: Okay understood...

**Jeff Bergosh**: Thx

**Todd Humble**: Kept fiddling with image cuts.  In your email now

### CONVERSATION ON 01-31-2020

**Todd Humble**: Do you have one or two minutes?

**Jeff Bergosh**: Yes—I’ll call u when I am out of this meeting I’m in

**Todd Humble**: ?

**Jeff Bergosh**: Sorry Todd

### CONVERSATION ON 02-11-2020

**Todd Humble**: I snagged these excellent condition unique  rolling swing away desk adult size chairs... $20 for an over $600 chair that I intend to use.  I was happy finding them as comfortable, but became exceptionally happy when I found their original price.

**Todd Humble**: I also sat in this chair while on vacation in Jordan.  I found them on Ali-baba very inexpensive, but easy held a 320 pound man that wiggled to test strength.  These geometric stacking ones are my intention for meeting room chairs.   Still no update on expected costs per square foot, but I will keep furnishings comfortable and easy to clean at minimal expense and good visual impact.

**Todd Humble**: Legs and base are metal...

**Todd Humble**: The originals cost a bit more... 

### CONVERSATION ON 02-14-2020

**Todd Humble**: When asking where are the electrical transformers and air handlers. The architect stated they were placing all on roofs which was not our intention.  Added penetration for leaks and heavier beams for weight and future difficulties to maintain were all pointed out.  We are pushing, but they pushing back to ready for bid process to start end of April or first week of May.  This new timeline puts bid opening at 1st week of July.  Purchasing and legal typically taking 30 days, plus the actual 30 day of the bid window is why I am saying July instead of June now... Still be ready for a summer ground breaking.  New sign will say ground breaking Summer 2020.   We can only do this once and I want to insure we have the best possible building for the future maintenance and functionality within our budget.

**Todd Humble**: We will try to recover the time, but I want to insure message of Summer 2020 now so if June vs July is not resolved nothing to worry about.  Might be able to get purchasing to expedite some to speed up, but no sense pushing until plans in hand.

**Jeff Bergosh**: Thank you Todd for the update.  Summer 2020 sounds great!

### CONVERSATION ON 02-18-2020

**Todd Humble**: Origami inspired trees in Bellview Library design and CNC production files for no fee secured.

**Todd Humble**: People of D1 can help make these trees later this year... We have most of the parts to build a full scale (5 foot by ten foot) CNC router now...  will be having classes using a two foot by two foot area this summer.  

### CONVERSATION ON 03-18-2020

**Todd Humble**: Nothing overdue until May 1st?  And no late fees or fines,?  At our Libraries suggestion from myse6

**Jeff Bergosh**: Sounds good

**Todd Humble**: Standard for free meals has been child must be present to receive the meals .  Nothing to this point has changed. 

**Jeff Bergosh**: Okay good thx

**Jeff Bergosh**: Which Library location?

**Todd Humble**: Currently all seven and we have requested additional meals if available to add other locations, but no confirmations back on capability to supply more

**Jeff Bergosh**: Excellent news thanks

**Jeff Bergosh**: Sorry to be cynical but that's just a known fact or reality people will game the system

**Todd Humble**: We will figure that out... technically the previous postponed programs did not cover Libraries...  I am going to need these staff to keep some locations open as I have many staff in at risk age group or edge of it

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: With the governor shutting down the state Todd are we still going to supply lunches from the libraries?

### CONVERSATION ON 04-02-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Todd Humble**: Just want to make certain you know zoom has been hacked.  Inappropriate words and images from nasty people during events they are not a part of hi jacking the event

### CONVERSATION ON 04-03-2020

**Todd Humble**: Sorry I hadn't seen this.  Yes we will serve meals.  If schools open within a quarter mile radius of us we would stop at that location. 

**Todd Humble**: We are asking for double portions to distribute on the Thursday before Good Friday.

### CONVERSATION ON 04-08-2020

**Todd Humble**: I would like an opinion on my initial origami verses and contemporary angular design.  Very crude comparison but folded object look verses angles.. ?

**Todd Humble**: Building shape is identical 

**Todd Humble**: Textures interesting, but origami quirky tourist photo op (Instagram moment destination while in Pensacola)

**Todd Humble**: My doodles that would need refined if asking a group.  Architect stated their design origins Montessori which is the exact opposite of mine.  Montessori a rose is green stem red flower and does allow an orange stem with green flower.  Library as a place of silence my opinion library a place of activity with silence not expected unless in a meeting room...  Opinion as a friend not as my boss...

**Todd Humble**: Parking lot view a simple origami box with right angle windows which they changed to the following picture 

### CONVERSATION ON 05-14-2020

**Todd Humble**: Bright Sunshiny Day...

**Jeff Bergosh**: Nice!

**Todd Humble**: I am planning to just go to architect tomorrow and make sure where they are at and push onward.

### CONVERSATION ON 06-05-2020

**Todd Humble**: I have an update on new Library 

**Todd Humble**: Please call me

### CONVERSATION ON 06-08-2020

**Todd Humble**: An update...

### CONVERSATION ON 06-09-2020

**Todd Humble**: If funds allow the architect did find a place that will build a hurricane rated origami shade structure.  Won’t be part of any project work, but will push Friends donations towards this if bid allows.  It will be a future feature and really helps the current fresh air social fears soothing 

**Todd Humble**: Reminder from last year idea

**Todd Humble**: As soon as funds capacity is known may be able to share in October after project award

**Jeff Bergosh**: Perfect.  Thank you Todd!

### CONVERSATION ON 07-14-2020

**Todd Humble**: I will send over video walk thru later this morning (was generated at 65%), but only minor changes since then  (85% accurate to nearing final).   Out building an option for future planning to just rough a couple pull tubes for now (possible friends funded addition they could operate separately to avoid management issues of separated space and special events usage). This out building space will start as bike parking area without structure.

**Jeff Bergosh**: Thank you Todd I look forward to seeing it!

**Todd Humble**: My aide sent a link because animation file too large for email.  If doesn’t work I can see if I can post to YouTube 

**Jeff Bergosh**: Okay thanks Todd I’ll check it out

### CONVERSATION ON 07-15-2020

**Todd Humble**: The interior layout differences are trivial to the library (new construction about 95%) and meeting room (former bank has less glass to eliminate the easily perceived second entrance).  Secondary structure is future planning.  Daylight capable movie projection outside is crucial as the estimated 15% of school youth that will be using the facility from about 2pm to 6pm are well beyond building capacity (non-pandemic time) .  New   release family friendly films will keep a portion of youth outside during crunch time.  Exterior impact has had improvements, but geometric shapes creating a unique contemporary feel by using traditional building materials in a non traditional way is intensional and at 80% on cosmetics in the video.  A new version will be available later this month when plans should be ready to start legal steps for bid.  I would 100% share this fly through on your blog as the general layout and open flexible use of space (shelves not on walls are on rollers) has no expected changes.  Just use the google link and instructions to press play in upper right hand corner.  Have a productive day.

**Todd Humble**: D1 e-mail has YouTube link now

**Jeff Bergosh**: Thanks for the update and information Todd!!

**Todd Humble**: Keep up the good work you do for all of us.  Have a safe day.

**Jeff Bergosh**: Thank you Todd!!

### CONVERSATION ON 07-17-2020

**Todd Humble**: Finalized carpet theme (will only need layout tweaks).  A dark water ocean effect in youth with a little dark green along wall edges at faux geometric tree bases.  In adults a lighter water effect carpet with a zigzag path to reading area.  To save funds the zigzag carpet (dark with turquoise splash) will be used as the only carpet pattern in the meeting room.  I do want a grassy path to lead youth to back, but need to see what standard cut options there are to minimize special cuts.  We will experiment with our unbuilt large CNC as it has a knife option that I think can cut the squares for us.  Cassie of facilities already mentioning we may want to pull carpet out seperate to use State contract pricing and possible staff install.

**Todd Humble**: The dark green edge and possible pathway.  Instead of initially planned river to pond.. now island in the ocean... all water themed flooring 

**Todd Humble**: https://youtu.be/ybOstEZ47ls

**Todd Humble**: A projector similar to this model will insure daylight capable movie projection.  Wiring for multiple unit is being roughed in for possible vector mapping night time events on a regular schedule 

**Todd Humble**: The following video demonstrates how easy vector mapping can be.  Students will be taught this skill as demonstrated i this music video.

**Todd Humble**: https://youtu.be/i7X8ZnmLfM0

**Todd Humble**: Only a few seconds projected on her dress.

**Todd Humble**: Simple origami animals at life size scale will be welding class project to be created by our citizens as guided by my aide and myself as beginners welding teachers.  Risk management already approved this, but covid has delayed the start of these classes.

**Todd Humble**: As experts are developed we can upgrade our large CNC into a water bath plasma cutter to create complex origami panels to weld together.  When the National institution of Museums and Libraries is able to resume grants I have already been verbally told by their grants administrator this project would score highly and likely be funded with a 10-20% matching required grant up to $250k.  Their funding may not return soon, but the plasma CNC upgrade is not unreachable 

**Todd Humble**: We own this one now.  It can be expanded to a five foot by ten foot cutting area

**Todd Humble**: Plasma upgrade kit very affordable 

**Todd Humble**: https://www.youtube.com/watch?v=z77W_dqhU7o

**Todd Humble**: This box cutter blade drag knife kit is already owned for the CNC.   It states upto .25” cut depth so I think custom curvy path of carpet is staff created probable (or public).

**Todd Humble**: Sorry so much, but I can assure you this library will be nationally recognized in Library Journal at the least and I personally know the editors at MAKE magazine that will feature the welding classes origami project.  

**Todd Humble**: Caleb of MAKE likes playing with fire ...

**Todd Humble**: https://youtu.be/tzfyoSgFGNc

**Todd Humble**: https://youtu.be/qfdV031I_F0

**Todd Humble**: I am making shou-Sufi-van myself already which will be used for the faux geometric trees.  A class as well if risk management will approve (safer than welding).

**Todd Humble**: Water based stains make shou Sugi bon pop...

**Todd Humble**: The geometric trees in adult portion of video are being designed at no cost by Kent State architectural design professor who make them for a project previously.  We will cut on the CNC, burn, and stain ourselves from his CAD files

**Todd Humble**: I will refine these into 100% achievable phases that can be shared before primaries...

**Todd Humble**: Stay safe.

### CONVERSATION ON 08-27-2020

**Todd Humble**: Please call me when you can 

**Jeff Bergosh**: Will do Todd

**Todd Humble**: Quick thoughts: 1. Crossing guards at peak times reduces  traffic flow risk.  2. Known sex offenders cannot visit this property due to school proximity another risk reducer. 3. Fly through animation given to help at crunch time. 

Have a great weekend, stay safe. 

### CONVERSATION ON 11-05-2020

**Todd Humble**: Parking and holding pond draft being engineered now.  The yellow highlighted spaces will be angled to use as going up the hill from Bellview ave and turn lane entry of mobile hey will be widened for in and out.  Center existing divided entry being removed to help keep pond as small as possible in corner at Mobile hwy

**Todd Humble**: I will get you a clean version without correcting notes ASAP

**Jeff Bergosh**: Thanks for the update Todd

### CONVERSATION ON 11-25-2020

**Todd Humble**: Update... updated plans should be to us next week.  Civil could be a week after because the civil engineer has covid.  

**Todd Humble**: Purchasing coordination meeting was today and everything seemed smooth.  Paul just needs the finished plans so he can get the boiler plate going.

**Todd Humble**: Happy Thanksgiving.

**Jeff Bergosh**: Thanks for the update Todd— happy thanksgiving to you as well!

### CONVERSATION ON 12-03-2020

**Todd Humble**: Good Afternoon Commissioner Bergosh,   Please call me when you have two minutes.  Todd

### CONVERSATION ON 12-04-2020

**Jeff Bergosh**: Thanks Todd

### CONVERSATION ON 12-07-2020

**Todd Humble**: Good evening,  two minutes when you can please.

**Todd Humble**: This message will suffice.  Purchasing received the civil so they could start today.  About two weeks the proper version so we can have the bid option  given during the 30 days.

### CONVERSATION ON 12-08-2020

**Jeff Bergosh**: That’s outstanding news Todd— thanks for the update!

**Todd Humble**: I would like to make a verbal comment when you have a minute 

### CONVERSATION ON 12-10-2020

**Todd Humble**: Enhanced the park like feel with less blacktop (none on Bellview side).  Added 20 spaces and NO holding pond required...  not approved yet, but we expect it will be...

**Todd Humble**: When approved I will send you the pdf

### CONVERSATION ON 12-16-2020

**Todd Humble**: Bellview just posted for bids to start...

### CONVERSATION ON 01-01-2021

**Todd Humble**: Happy New Year 

**Jeff Bergosh**: Happy New Year!

### CONVERSATION ON 01-04-2021

**Todd Humble**: Have you got a minute to discuss Bellview 

### CONVERSATION ON 01-05-2021

**Todd Humble**: Need 20 seconds 

**Jeff Bergosh**: Hi Todd— I’ve been traveling for the last few weeks out of state.  I’m in Texas now and will be back in Pensacola tomorrow.  I’ll give you a call when I’m back to discuss.  Happy New Year!

**Todd Humble**: Meeting now.  All asking for extension to bid.  Mechanical still isn’t complete

**Todd Humble**: I want to say don’t do holding pond version

**Jeff Bergosh**: What does Cassie think?

**Jeff Bergosh**: I don’t want to slow the momentum

**Todd Humble**: She already saying we have to extend since they do not have all info

**Jeff Bergosh**: How long will this take?? What is delay on Mechanical?

**Todd Humble**: I prefer not to waste their civil time on holding 

**Todd Humble**: Mechanical engineer had not included all boiler details

**Jeff Bergosh**: How long a delay??

**Todd Humble**: Two weeks seem reasonable but no time

**Todd Humble**: Has been stated

**Jeff Bergosh**: Okay then I’d say go ahead and take the two weeks

**Jeff Bergosh**: To get it right

**Todd Humble**: Thank you

**Jeff Bergosh**: I was afraid we were looking at 2 months

**Jeff Bergosh**: But 2 weeks seems reasonable

**Todd Humble**: Have a good vacation and thank you.

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-21-2021

**Todd Humble**: UWF bike trails are another local option in a heavily wooded terrain in D5 just a few miles from Beulah here in Escambia County 

### CONVERSATION ON 02-04-2021

**Todd Humble**: #1 users of Tryon branch on Langley are district one residents as well as the Southwest Branch library on gulf beach hwy

**Todd Humble**: Based on the registration address of the actual citizen checking out physical library materials 

**Todd Humble**: Past three years for certain; not a covid related fluke 

**Jeff Bergosh**: Thank you for that Datapoint Todd that really helps!

**Todd Humble**: We expect a lot of new users, but I am certain many will at least pickup materials closer to their house even if during after school surge

### CONVERSATION ON 02-18-2021

**Todd Humble**: Not sure if Janice shared why I was not present.   I was at hospital today with my wife.

### CONVERSATION ON 02-19-2021

**Jeff Bergosh**: She did not.  I hope you are alright Todd!  Good news- the contract was approved, 5-0 vote

**Todd Humble**: Wife was in.  She is doing well, but waiting on results.  Great news on Library.  On adult sized ground breaking shovels do you have a list?  I am having my aide check how many Bellview honor roll students there are for kids shovels.  

**Todd Humble**: High end shovels for leadership remembrance are about $65.  We are going to acid etch a cheap shovel to see how it turns out

**Jeff Bergosh**: Probably you, Cassie, Janice, and the commissioners plus the Library BOG—and Is suggest an invite to the Superintendent of Schools and School Board Chair Patty Hightower

**Todd Humble**: Okay.  Yes with proximity possibly the principal’s for Bellview as well with honor students.

### CONVERSATION ON 03-18-2021

**Todd Humble**: Good morning,  I received the timeline and schedule of values Wednesday for Bellview.  Do you have a preferred date for us to get set for the ground breaking.  

It is a good sign we received the timeline a couple weeks earlier than expected.  They took down power poles immediately on day 1 and expect to have their temporary power today.

**Jeff Bergosh**: How about Tuesday March 30th or Wednesday the 31st?

**Todd Humble**: I would like to suggest the week after Good Friday to insure no one has taken a holiday based on the short week.  We can work toward 3.31 if you prefer.

**Todd Humble**: Vacations may be just as bad after Easter though

**Todd Humble**: The youth participation idea works best on a weekend to avoid school conflicts. 

**Todd Humble**: I believe the student participation brings immediate buy-in and based on prior experience many of the youth kept their shovels in their rooms and parents still talked to the children’s librarian two years later about the experience 

**Todd Humble**: I am getting a digital copy of the paper timeline I received and will forward it as soon as received today.

**Jeff Bergosh**: Thanks and whenever you want to do it works fine for me. However I do believe a Tuesday or Wednesday morning would work and you could coordinate with Bellview elementary school and the principal there to have a lot of students come over and participate and watch it could really be a big event a big win for the county

**Todd Humble**: Okay... I hadn’t thought about the additional classes option... Nor sure what percentage school vs online at the youngest ages

**Todd Humble**: Have to get branding on them but kids shovels acquired 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-23-2021

**Todd Humble**: Principal Groff would like to do all of second grade.  It would be five classes around 80 children.  To get permission slips back and avoid a testing week (testing on April 6&7) she is suggesting April 13 or 14 keeping with your Tuesday or Wednesday preference.  Do those dates look okay?

**Jeff Bergosh**: Sure!  Sounds fantastic!

**Todd Humble**: You want to just ask the group on Thursday Bocc or have me ask aides now?

**Jeff Bergosh**: I’d suggest asking the aides now

**Todd Humble**: Ok

**Todd Humble**: Lowe’s in Escambia has no more kids shovels currently :)

**Jeff Bergosh**: Shovels!!  Awesome!

**Todd Humble**: Got some nice adult sized as well

**Todd Humble**: Filled back vent wood handles

**Jeff Bergosh**: 👍

**Todd Humble**: I have CMR working on a unique version of our owl logo in a faceted origami style that we can use for branding on the shovels if it turns out nice

**Todd Humble**: Sorry forgot to ask preferred time

**Todd Humble**: I will ask available times from aides if possible conflicts

**Todd Humble**: School schedule 9am to 11 am or 12 to 1:30 are available slots to easily get kids across street and back to classes or lunch

### CONVERSATION ON 03-26-2021

**Todd Humble**: Not finalized, but I thought I would share the library owl variant we will use at Bellview to go with the geometric designs.  Final will be ready for shovel decals soon.

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-06-2021

**Todd Humble**: The ~20 or so 2nd graders will have safety vests and hard hats also.  Stickers tomorrow I was told... they are sending one class plus some top AR readers... less than 30 for certain to keep risk perception minimal

**Jeff Bergosh**: That’s going to be awesome!

**Todd Humble**: I hadn’t thought about party supplies making cheap hats... 

**Todd Humble**: They look real :) 

**Jeff Bergosh**: Yeah!

### CONVERSATION ON 04-08-2021

**Todd Humble**: Since no one really knows what WFPL stands for each location will have a unique owl variation with the library’s name as the main feature.  This is image on youth materials.  Instead of “my” possessive term the “your” clearly states it belongs to everyone and specifically the person reading the sign.  See you Monday

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-14-2021

**Todd Humble**: My answer on Bellview to the public has been late spring… 

**Jeff Bergosh**: Thx

### CONVERSATION ON 10-05-2021

**Todd Humble**: They are replacing soils to address drainage issues at Bellview.  When the work is resolved I will provide an update for yourself and the citizen.

