

## CONVERSATIONS WITH JIM FAXLANGER

### CONVERSATION ON 10-28-2019

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jim Faxlanger**: Call me when
You can

**Jeff Bergosh**: 👍

**Jeff Bergosh**: On other line

**Jim Faxlanger**: K

### CONVERSATION ON 11-02-2019

**Jeff Bergosh**: Today at Navy Federal credit Union look who’s parked in the first available non-handicap spot😂

**Jim Faxlanger**: That place is out-of-control

### CONVERSATION ON 11-09-2019

**Jeff Bergosh**: First non-Handicap spot today at Navy Federal credit Union.   These guys are a real hoot!

**Jim Faxlanger**: Neither the sheriff deputy or navy federal give a shit

**Jeff Bergosh**: I guess not

### CONVERSATION ON 11-29-2019

**Jim Faxlanger**: You home

**Jim Faxlanger**: ??

**Jim Faxlanger**: Can you talk?

**Jeff Bergosh**: Sure

### CONVERSATION ON 12-06-2019

**Jim Faxlanger**: You ok?

**Jeff Bergosh**: All good, you?

**Jim Faxlanger**: Off today. I saw you friend Vicki is giving a status report from on the base  reporting on Facebook

### CONVERSATION ON 12-07-2019

**Jim Faxlanger**: Laughing at Morgan’s tantrum. Yesterday he was asking the public to be patient as the information will come out slow. 
Today he is whining about the FBI not doing press briefings. 
Such a Narcissistic ass

### CONVERSATION ON 12-09-2019

**Jim Faxlanger**: Hey Jeff, give me a call when you can

**Jim Faxlanger**: https://www.dcma.mil/Portals/31/Documents/Policy/DCMA-MAN-4201-18.pdf?ver=2019-01-15-073316-963

**Jim Faxlanger**: Here is one

**Jim Faxlanger**: https://www.dcma.mil/Portals/31/Documents/Policy/DCMA-MAN-4201-18.pdf?ver=2019-01-15-073316-963

**Jim Faxlanger**: Another

### CONVERSATION ON 12-13-2019

**Jim Faxlanger**: Hey what’s you home address. Trying to list another reference

### CONVERSATION ON 12-15-2019

**Jeff Bergosh**: 5905 Forest Ridge Circle Pensacola, Fl  32526

**Jim Faxlanger**: Got it thanks. Looks like you are enjoying Orlando

**Jeff Bergosh**: Oh yeah.  Good to get away from time to time

**Jim Faxlanger**: Amen

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Jim Faxlanger**: Call me

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: Jim—I counted up my petitions and I’m sitting at 489 so if you haven’t got any filled out don’t sweat it, if you do have some for me I’ll swing by and grab them after work if that’s cool.  I’m taking them all to Stanford’s office tomorrow on my lunch break 😎👍

Thanks for your help!

**Jim Faxlanger**: You certainly can pick up the ones Melissa and I signed.  

**Jeff Bergosh**: Okay thanks!

### CONVERSATION ON 02-26-2020

**Jim Faxlanger**: Someone told me you let Vicki Campbell campaign at your “Coffee with Commish” event??

**Jeff Bergosh**: She came and gave a presentation

**Jeff Bergosh**: Debra Brusso is bent out of shape over it

### CONVERSATION ON 02-27-2020

**Jim Faxlanger**: Jeff, my friend, I am not bent out of shape at all. Just not quite sure why, with all of the anti-Vicki Campbell voters in our district, you would let her campaign at your meeting??
Oh well guess it’s your campaign. 

**Jim Faxlanger**: Why no response?

**Jeff Bergosh**: In conference in Destination 

**Jeff Bergosh**: We’ll talk later

**Jim Faxlanger**: Ok

**Jim Faxlanger**: Not sure what you are thinking. This certainly will not benefit you or your campaign. Especially if the grand jury report comes out before the primary. 

### CONVERSATION ON 02-28-2020

**Jeff Bergosh**: In conference.  Will call u back

### CONVERSATION ON 04-20-2020

**Jim Faxlanger**: Will you listen and watch this?

**Jim Faxlanger**: What did you think?

**Jim Faxlanger**: Ok I guess your friends don’t warrant a response 

**Jim Faxlanger**: Go ahead and be that way. 

**Jim Faxlanger**: Good luck Jeff

### CONVERSATION ON 04-21-2020

**Jeff Bergosh**: Not ignoring you-out late fixing multiple damaged signs all over D1 from the wind storm.  

**Jeff Bergosh**: Call me when you can talk 

**Jim Faxlanger**: I don’t think talking will do any good. 

**Jeff Bergosh**: ?

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: In a mtg

**Jim Faxlanger**:  Call me back when you can

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: Jim:  I spoke to Scott Lunsford yesterday as I said I would—and I gave him your cell number. He told me he would call you.

### CONVERSATION ON 05-19-2020

**Jim Faxlanger**: Looks like you are all in on Vicki’s request. 

**Jim Faxlanger**: Did you get us a rate reduction with the savings like you told me you were going to push for in exchange?

### CONVERSATION ON 05-20-2020

**Jim Faxlanger**: Keep in mind that if ECUA stops providing twice weekly service to Santa Rosa they can change pickup days and split routes instead of laying off some people due to their immediate increase in capacity. No need for a transfer station 

**Jeff Bergosh**: Good point

**Jim Faxlanger**: Push it back!!!!

### CONVERSATION ON 05-21-2020

**Jim Faxlanger**: Don’t act on that yet. I am going to catch Vicki

**Jeff Bergosh**: Wow!

**Jim Faxlanger**: Thought you were going to call me back 

**Jeff Bergosh**: Waiting for Pat Johnson to call and confirm we own it

**Jeff Bergosh**: Odom, not the ECUA, appealing

**Jim Faxlanger**: I see the update but not any article. 
Vicki has gone underground 

**Jim Faxlanger**: So how long before it is denied and then released?

**Jim Faxlanger**: Call me

### CONVERSATION ON 05-29-2020

**Jeff Bergosh**: Front page of today’s PNJ

**Jim Faxlanger**: Beautiful 

**Jeff Bergosh**: Wouldn’t have known had you not shared that document with me.  Thank you for that Jim!

**Jeff Bergosh**: ........ECUA certainly wasn’t going to tell me, our attorney, or our administrator

**Jim Faxlanger**: Anytime. Just don’t help great pumpkin any more. SHE NEEDS TO GO. 

**Jim Faxlanger**: Makes the board look really stupid, but that’s not hard. 
Can’t wait to hear what Campbell says to you. 

### CONVERSATION ON 06-18-2020

**Jim Faxlanger**: Can you talk?

**Jeff Bergosh**: In a bcc mtg

**Jeff Bergosh**: I can call u when I get out

**Jim Faxlanger**: Ok

**Jim Faxlanger**: Hey look up the voting record of Karisa Bennett for me. 

**Jim Faxlanger**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-27-2020

**Jeff Bergosh**: Jim-you’re a person that’s been around healthcare and I greatly value your opinion——-What’s your take on masks?  I’m getting conflicting passionate pleas for mandating them and against mandating them.  Messaging from health agencies has been all over the place.  Thoughts?

**Jeff Bergosh**: A ha- there it is!

**Jim Faxlanger**: Here is the charts

**Jeff Bergosh**: Thanks Jim!

### CONVERSATION ON 07-28-2020

**Jim Faxlanger**: Jeff do you think you could have the county guys come out and mow our holding pond? It is really getting overgrown

**Jeff Bergosh**: Sure.  I’ll get them out there.

**Jim Faxlanger**: Thanks 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-06-2020

**Jeff Bergosh**: In a BCC meeting will call u after

**Jim Faxlanger**: Ok. 

### CONVERSATION ON 08-18-2020

**Jim Faxlanger**: Congrats buddy

**Jeff Bergosh**: Thanks Jim

**Jim Faxlanger**: You’re welcome 

### CONVERSATION ON 09-11-2020

**Jeff Bergosh**: We have an issue where a for-profit hospital is bringing in helicopter ambulances at an alarming rate necessitating we bring an ambulance firetruck and sheriffs vehicle to close down Highway 98 for them to do these patients. They’ve done this 140 times since the first of the year. Knowing how expensive air ambulances are —what is going on here Jim? Do you have any idea of how this is getting paid for? Knowing your background I thought you might have a thought on it but I am going to figure it out because it is closing Highway 98 For an hour each time and folks are getting angry about it.

**Jim Faxlanger**: Can I give you a call later? I am doing funeral services all day. 


**Jeff Bergosh**: Sure Jim thx

### CONVERSATION ON 09-12-2020

**Jim Faxlanger**: Sorry, I can't talk right now.

**Jim Faxlanger**: Phone tag your it

### CONVERSATION ON 09-18-2020

**Jim Faxlanger**: Sorry, I can't talk right now.

**Jeff Bergosh**: No worries I was returning your call.  Returning calls today just trying to catch up....................

### CONVERSATION ON 10-01-2020

**Jim Faxlanger**: Hey buddy they came by and picked up the massive pile of debris in the road. Thank you for making it happen. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-10-2021

**Jim Faxlanger**: You up?

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: Yes

**Jim Faxlanger**: Can you talk?

**Jeff Bergosh**: Yes

### CONVERSATION ON 08-13-2021

**Jim Faxlanger**: Call me

**Jeff Bergosh**: In mtg will call back

**Jim Faxlanger**: K

**Jim Faxlanger**: You need to respond back to them that there needs to be an urgency due to the conflict of the two speed limits on opposite sides of the road

**Jeff Bergosh**: They know

**Jeff Bergosh**: Fires been lit 🔥

**Jim Faxlanger**: Ok thanks Jeff 

### CONVERSATION ON 09-22-2021

**Jeff Bergosh**: In mtg will call I back

**Jim Faxlanger**: K

### CONVERSATION ON 09-24-2021

**Jeff Bergosh**: Hey Jim I just got word back from the roads crew that they finished cutting the Deerfield Estates pond today. they sent some pictures and it looks good. have a great weekend!

**Jim Faxlanger**: Thanks for your help. I saw them knocking it out earlier. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: Jim— I have a quick healthcare related question— do u have a minute to talk?

**Jim Faxlanger**: Absolutely 

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas to you and your family Jim!

**Jim Faxlanger**: Merry Christmas to you and yours as well. 

### CONVERSATION ON 01-17-2022

**Jim Faxlanger**: Absolutely love it!!!

**Jeff Bergosh**: Thought you’d get a kick out of it.  I’ll have one for you when you get back.  I gave one to Gary today and he loved it. Have a safe trip back Jim.

**Jim Faxlanger**: 👍🏼👍🏼👍🏼

