

## CONVERSATIONS WITH TIM DAY

### CONVERSATION ON 03-02-2020

**Jeff Bergosh**: County does not own it 

**Tim Day**: Commissioner - is there more info for the situation or wrong Tim?

**Jeff Bergosh**: I’m told a citizen put this complaint into code enforcement

**Tim Day**: Did you get any information besides the subdivision? If not, I’ll search for any complaint within it. Thanks 

**Tim Day**: Thank you for the information. I’ll follow up with my folks in the morning. Have a great evening!

### CONVERSATION ON 03-03-2020

**Jeff Bergosh**: Thanks Tim!

**Tim Day**: Commissioner - I placed a packet on Debbie’s desk regarding the sign. The adjacent pond parcel was accepted by the Board on 20 June 2019. Please feel free to give me a call discuss further.

### CONVERSATION ON 04-09-2021

**Tim Day**: Just making sure you were contacted. Baseball opening ceremonies canceled for tomorrow. Thanks

**Jeff Bergosh**: Thanks Tim.  I was.  I’m going to participate in the rescheduled event next Saturday.

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: In the TPO I'll call u right after

### CONVERSATION ON 04-26-2021

**Tim Day**: Tampico property already under notice

**Jeff Bergosh**: About to go on Channel 3 can you please call me?

### CONVERSATION ON 05-06-2021

**Tim Day**: 31 parking spaces + 4 ada= 35 total

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: Is this the area we discussed earlier?

**Tim Day**: Yes

### CONVERSATION ON 11-05-2021

**Tim Day**: Can you give me a call when you have about 10 minutes to chat please?

**Jeff Bergosh**: Will do.  I’ll call u on my lunch break

