

## CONVERSATIONS WITH JOHN CAMPBELL

### CONVERSATION ON 10-30-2019

**Jeff Bergosh**: John, for the handrail job at 623 they are saying the materials costs are low.  Smitty says other similar jobs ended up with materials costs were $13K you have $3.8K.  

**John campbell**: 601 stairwell. Pretty much the same.  Done last year,  $4,106 for material 

**Jeff Bergosh**: Thx

**John campbell**: Shops have done several of these stairwells of similar size.  How about some feedback on  what they are paying for  those rails? 

### CONVERSATION ON 12-06-2019

**John campbell**: Hey Jeff.  I'm at the exchange at Corry.  Let me know when  they open the base back up.  I heard  they got the shooter about  15 minutes ago. 

**John campbell**: Hopefully the idiot  is dead. 

**Jeff Bergosh**: Yeah they got him he's down I'm told there's multiple fatalities and up to 15 people shot keep that between us though

**John campbell**: Sure will

**John campbell**: Whoever is  operating  that  system needs more practice,  they aren't very good at it  yet. 

**John campbell**: Are they trying to lift the active

**John campbell**: Are they going to lift the lock down soon

### CONVERSATION ON 02-10-2020

**John campbell**: hey Jeff.  I was on a site visit to  saufley with Andrew.  I'll  call Lynette now. 

**Jeff Bergosh**: Okay thanks John

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: ??

**John campbell**: Got it.  He was looking for a package  we submitted  for the manhole on page road. I told him we would  track it down and resend. 

**Jeff Bergosh**: Thanks

### CONVERSATION ON 03-12-2020

**John campbell**: Jeff.  Had some issues with the ladies this morning.  Just  now heading out.  Might be a few minutes late for this mornings meeting.  I'm  on my bike so no reply.  Just wanted to  give you a  heads up. 

**Jeff Bergosh**: John I'll be leaving at 7:30 for an off base meeting.  I'll get with you individually when I get back to the base

**John campbell**: Sounds like a plan 

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: John--submit your timesheet

**Jeff Bergosh**: I need to approve it

**John campbell**: Sorry.  Internet  has been down all day.  Had to log in with another device to  submit. 

**Jeff Bergosh**: Okay thanks

**Jeff Bergosh**: Got it

### CONVERSATION ON 05-01-2020

**John campbell**: Hey Jeff.  I forgot to send you that email  to remind you that I have a  doctors appointment  this morning.  I should  be in by lunchtime. 

**Jeff Bergosh**: Got it

### CONVERSATION ON 09-01-2020

**John campbell**: Hey Jeff.  What time do you expect to be here this morning.  I came in to fill out time cards an request PTO. 

**Jeff Bergosh**: It will be later I'm at a service appointment with my truck

**Jeff Bergosh**: Just let me know what u need in terms of time off and it is approved John

**John campbell**: Will you approve of a return date of 9-21-20. With the holiday next week that puts me at about 80 hours of PTO.  We are driving to  NH with my mom And need the extra weekend to make it work. 

**Jeff Bergosh**: Yes-- approved.  Just write it up and email it to me

**Jeff Bergosh**: I'll work out the additional extensions

**John campbell**: Also,  I had that job done yesterday but got distracted yesterday by a phone call from the funeral home. It is now in your inbox. 

**John campbell**: Will do on the email  request.  

**John campbell**: Send me a reminder at the end of each week and I'll make sure  my electronic timecards are submitted. Hard copies are in your inbox. 

**John campbell**: I don't have anything  due until 9-28-20.

**Jeff Bergosh**: Okay will do John I am sorry for your loss.

### CONVERSATION ON 09-02-2020

**John campbell**: Thanks Jeff. 

**Jeff Bergosh**: John I have spoken with Tony and we would like to send flowers so just let us know where to send them once you have that all finalized.  Thanks

**John campbell**: Hey Jeff.  My sister did not like flowers for some reason,  I guess she thought it was a waste.  Anyways,  she asked for donations to her church in lou of flowers. If you're interested I'll get that info for you and Tony. 

**Jeff Bergosh**: Okay that would be great thanks!

**John campbell**: Pace Community Church,  4310 N.  Spencerfield Rd. , Pace FL 32571

**Jeff Bergosh**: Thanks John- again you have my condolences

**John campbell**: Thanks Jeff. 

**Jeff Bergosh**: Hey John- sorry to keep texting you but can you fill out and submit your time for Monday, August 31st in the electronic timesheet.  ELE needs it to begin payroll processing.

Thanks
Jeff B

**John campbell**: I did that and I even submitted  it on Monday.  On Tuesday I  did  the rest of  this week and submitted  that as well. 

**Jeff Bergosh**: Ok thx John

**John campbell**: If you  need anything,  I good with the texts. 

### CONVERSATION ON 09-11-2020

**Jeff Bergosh**: Hello John-- hope all is going as well as can be expected.  Can you go ahead and fill in the electronic timesheet for this week for us?  Thanks

**Jeff Bergosh**: John, can you enter your time in the online portal?

**John campbell**: Hey  Jeff.  What's  that web address.  Sorry  my brain is a little  scrambled right now.  

**Jeff Bergosh**: Http://time.eleinc.com

**John campbell**: Done. 

**Jeff Bergosh**: Thanks John.  Hope all is going as well as can be expected given the circumstances.

Jeff B

**Jeff Bergosh**: John- can you correct and re submit?  You put regular time when it should have been PTO

**John campbell**: Done.  Sorry about that. 

**Jeff Bergosh**: No worries thanks John

**John campbell**: Your welcome. 

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: John, I need for you to submit your electronic timesheet

**John campbell**: Done.  Is the office  going to be  ready for  us on Monday? 

**Jeff Bergosh**: Not sure.  Are u back in town?

**John campbell**: Yes

**Jeff Bergosh**: As of right now it's a workday for us all but there are some issues with the office right now there's no network connectivity but we do have power and air but we had quite a bit of water infiltration so will assess it Monday morning during the meeting and figure out what we can do

**John campbell**: Okay.  I'll be there. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-25-2020

**Jeff Bergosh**: John I need you to submit your electronic timesheet for approval.  Thanks!

**John campbell**: Done 

**Jeff Bergosh**: Thx

### CONVERSATION ON 12-02-2020

**John campbell**: Ok

### CONVERSATION ON 02-22-2021

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

### CONVERSATION ON 03-09-2021

**Jeff Bergosh**: https://apple.news/Az8Sf3KQ2TBu5pF0aPqbcEA

### CONVERSATION ON 03-22-2021

**John campbell**: Hey Jeff.  Call me when you get in the office.  This is John Campbell. 

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: Enjoy the day off!

**John campbell**: Acknowledged. 

### CONVERSATION ON 07-21-2021

**Jeff Bergosh**: John: your title on the job for first navy bank is inaccurate.  Please go into the folder and correct it;  it lists a different building and room number in the title

**Jeff Bergosh**: Should be bldg 3466

**John campbell**: Ok

**Jeff Bergosh**: Let me know when u get it fixed.  Once you do, have Ira upload the corrected package into LiveLink

**John campbell**: Done

**John campbell**: And uploaded by Ira

**Jeff Bergosh**: Right on thanks

### CONVERSATION ON 07-30-2021

**John campbell**: Done

**Jeff Bergosh**: Got it- thx

### CONVERSATION ON 08-09-2021

**Jeff Bergosh**: John—I need your hard copy time sheet for last week.

Thanks!

### CONVERSATION ON 08-16-2021

**John campbell**: Hey Jeff.  Just a reminder that I have a dentist appointment this morning and I will be in between 9-10 am.  John Campbell. 

**Jeff Bergosh**: Got it, thx

### CONVERSATION ON 09-19-2021

**Jeff Bergosh**: John I need you to resubmit your online copy time sheet you listed the time for last week as time worked that should be PTO/PLP-  as you were out of the office

**John campbell**: Will do when I get back to the house 

**Jeff Bergosh**: I

