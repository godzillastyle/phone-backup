

## CONVERSATIONS WITH JASON FISCHER

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: Hello Representative Fischer, this is Jeff Bergosh a County Commissioner from Escambia County.  I was a school board member for many years, We worked together with the Florida Coalition of School Board Members back in 2014 and 2015.  Anyhow, the elections bill that you all will be considering today has an onerous provision inserted at the very end which is not present in the Senate Version.  This provision makes some county commissioners who just won re-election to 4 year terms last year (like I did) run again next year.  It appears very punitive to about 19 counties and if there is any way you could ask about this I would be greatly appreciative.  I support the bill overall— except for this provision which is really unnecessary and unneeded.  Thanks for your consideration!

**Jeff Bergosh**: Yes sir

**Jeff Bergosh**: Thanks for anything you can do

**Jeff Bergosh**: But why not school boards as well then??

