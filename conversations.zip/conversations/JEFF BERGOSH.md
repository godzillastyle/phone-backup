

## CONVERSATIONS WITH JEFF BERGOSH

### CONVERSATION ON 10-18-2019

**Jeff Bergosh**: Test

**Jeff Bergosh**: Test

### CONVERSATION ON 10-19-2019

**Jeff Bergosh**: But it will be December or January of next year

**Jeff Bergosh**: Have fun but study hard!!

**Jeff Bergosh**: Tori--once again your NFCU checking got hit with a $29 insufficient funds fee.  I covered it the last two times but I thought you told me you were closing this account??  If you are not using it, go close it. And why do they keep giving you this penalty fee?!?  You need to sort this out today.  Call them and fix it.

**Jeff Bergosh**: Just close the checking

### CONVERSATION ON 10-21-2019

**Jeff Bergosh**: There will be some serious, significant bad weather moving through our area between 6:00PM tonight and 4:00AM tomorrow.  If you are going to be out driving between those times be extra vigilant and careful——it will be bad

**Jeff Bergosh**: Hello Collier—we’re just about 24 hours away from my fundraiser tomorrow from 5:00-7:00PM at McGuire’s Grand Hall, and I just wanted to take this opportunity to say thank you for helping with this effort by being on the host committee.  I cannot tell you how much your support, assistance and encouragement means to me—thank you very much!

Jeff Bergosh

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 10-23-2019

**Jeff Bergosh**: You’ve got $208.90 in there.  Love u!

**Jeff Bergosh**: It was an excellent event thanks in large measure to you Jim!  

### CONVERSATION ON 10-27-2019

**Jeff Bergosh**: Hey Theresa it’s Jeff Bergosh I’m out at Perdido Bay right now scoping different locations it looks like we won’t be able to film where my brother used to live I could not get a hold of the current resident

### CONVERSATION ON 10-28-2019

**Jeff Bergosh**: So tonight’s Superintendent workshop is at 6:00 at the REX theater......at 5:30, on the same block, Pensacola Dream Defenders are promoting a “Day of Rage” against white cops shooting Tymar Crawford.  Could be a volatile mixup/mashup?  You all still wanting to go to this Studer panel????

### CONVERSATION ON 10-29-2019

**Jeff Bergosh**: Sally—unfortunately for her, it appears as if one of your tennis friends got popped for a DUI Sunday night.  This is why I am so careful.  This will cost her $10 Grand minimum plus embarrassment and humiliation.  Just not worth it.........

**Jeff Bergosh**: And that’s why I won’t drink at all. If I’m driving just not worth the risk

**Jeff Bergosh**: NFCU checking account hit you with ANOTHER$29 insufficient funds fee Tori!!!  I thought until said you were going to close this account!!!!!!!!!!!!!!!!!

**Jeff Bergosh**: Close this checking account.  Call them today and close it Tori

**Jeff Bergosh**: 1800842NFCU

### CONVERSATION ON 10-31-2019

**Jeff Bergosh**: Here’s my costume

### CONVERSATION ON 11-03-2019

**Jeff Bergosh**: 12-0

### CONVERSATION ON 11-04-2019

**Jeff Bergosh**: But I’m glad he’s OK in the car is OK

### CONVERSATION ON 11-06-2019

**Jeff Bergosh**: Hey check your mail today I sent you a little traveling 💰

**Jeff Bergosh**: I’ll ask Alison about it

**Jeff Bergosh**: 👍😎👏

### CONVERSATION ON 11-07-2019

**Jeff Bergosh**: Will call you after

**Jeff Bergosh**: Having him pay would have been better.... resource depletion

**Jeff Bergosh**: Your mailbox is full

**Jeff Bergosh**: Chorus Nylander from Channel 3 called me during the meeting and I did confirm that they were officers at Public safety but I did not give him any specific information I told him it was part of an ongoing investigation. Someone had called him and took them off and that's why he's there and not here

### CONVERSATION ON 11-08-2019

**Jeff Bergosh**: But if your proposal does not go—I told Ron then at that point I’d look at what he’s proposing, but not until we’ve run your (PADP) deal through the Triumph and BCC process

### CONVERSATION ON 11-11-2019

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 11-13-2019

**Jeff Bergosh**: What time/day is the conference?  Is it just a one day, Wednesday?

**Jeff Bergosh**: Or Thursday I meant?

**Jeff Bergosh**: Do u want to meet at Artel Gallery this afternoon at 4:45?  I spoke Steve and he is going to be there and he will show me the equipment that’s there for our use

**Jeff Bergosh**: In today’s mail

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Really?? That's the number I have

### CONVERSATION ON 11-14-2019

**Jeff Bergosh**: I'll call u right back

**Jeff Bergosh**: I’m on the phone with an environmental activist

### CONVERSATION ON 11-15-2019

**Jeff Bergosh**: Hello??

**Jeff Bergosh**: ????

**Jeff Bergosh**: Meet me down there, I’m going to leave work and get there by 4:00.  Love u❤️❤️

**Jeff Bergosh**: Sally I just missed a call from Health and Hope clinic and I called it that number back 13 times and it rang and rang and rang and rang and rang and rang and rang and rang and nobody answered

**Jeff Bergosh**: Anyway I listen to your message I understand you left your phone at home and that’s too bad because the plans have all changed around and we got invited to go backstage and meet the band but I had to leave work early that’s why I’ve called you 100 times today trying to see if you could meet me

**Jeff Bergosh**: So because you didn’t get the messages or the phone calls or anything we got a change the plan around so when you get to the hotel go to the front desk and and show your ID and you’ll get a room key and then just head up to the room it’s room number 1107

**Jeff Bergosh**: I’ll be across the street but there’s a lot of security and protocols and I may not be able to get you in if you’re not there by 4:45 but that’s OK after I meet the band I’m gonna come back to the room and I’ll meet you and then we’ll go back together I’m sorry I got all screwed up but when I can’t get a hold of you it makes things difficult

### CONVERSATION ON 11-17-2019

**Jeff Bergosh**: How will he ever get anything past if all he does is insult and a lie about his peers on the board?

### CONVERSATION ON 11-20-2019

**Jeff Bergosh**: I can’t tag her, just tried but we r not friends on Facebook

**Jeff Bergosh**: Yes, $329.49

**Jeff Bergosh**: https://ebp.delta.com/mobiqa/wap/b50e727/M1fWiQ2W3iM/

**Jeff Bergosh**: DL1900, ATL TO JFK, 2:00pm 21NOV. Open link to view Boarding Pass.

**Jeff Bergosh**: https://ebp.delta.com/mobiqa/wap/b50e728/Zcf5dW1g9z0/

**Jeff Bergosh**: Hamilton is almost sold out on Saturday night do you want me to buy these two tickets on Ticketmaster so that we don’t get boxed out on Saturday night?

**Jeff Bergosh**: If you are opposed to this you may want to consider going to the meeting

**Jeff Bergosh**: On Dec. 3rd

### CONVERSATION ON 11-21-2019

**Jeff Bergosh**: Vaucluse

**Jeff Bergosh**: 63rd park

**Jeff Bergosh**: 63rd park

**Jeff Bergosh**: Porterhouse 

**Jeff Bergosh**: Porterhouse 

**Jeff Bergosh**: Sparks

**Jeff Bergosh**: Sparks

**Jeff Bergosh**: Smith and wollensky

**Jeff Bergosh**: Smith and wollensky

**Jeff Bergosh**: Catch

**Jeff Bergosh**: Catch

### CONVERSATION ON 11-22-2019

**Jeff Bergosh**: Everything going okay Brandon?

### CONVERSATION ON 11-23-2019

**Jeff Bergosh**: Dan, thought you and Steve would get a kick out of this guy out in front of Trump Tower we met today LOL

### CONVERSATION ON 11-24-2019

**Jeff Bergosh**: One World Trade Center 

### CONVERSATION ON 11-25-2019

**Jeff Bergosh**: Just leaving the base, stopping at wal mart on the way home to get stuff for thanksgiving

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: 😂

### CONVERSATION ON 11-26-2019

**Jeff Bergosh**: Did you???

**Jeff Bergosh**: Employee of the month———-u on way home soon????

**Jeff Bergosh**: Hey Janice, can you give me a call?

### CONVERSATION ON 11-27-2019

**Jeff Bergosh**: Awesome

**Jeff Bergosh**: I see he responded to you

**Jeff Bergosh**: 😂😂😂😂😂😂😂😂😂

**Jeff Bergosh**: Triggered

**Jeff Bergosh**: But I’m hearing Marty Stanovich is running

**Jeff Bergosh**: He told me so

**Jeff Bergosh**: I like Marty

**Jeff Bergosh**: And thanks!

**Jeff Bergosh**: 😂😂😂😂

**Jeff Bergosh**: He’s a pariah now

### CONVERSATION ON 11-30-2019

**Jeff Bergosh**: Just call when you’re ready I still have to go to the grocery store anyway so don’t rush it

### CONVERSATION ON 12-01-2019

**Jeff Bergosh**: No OT

**Jeff Bergosh**: What BS calls

### CONVERSATION ON 12-02-2019

**Jeff Bergosh**: You on way?

### CONVERSATION ON 12-04-2019

**Jeff Bergosh**: I don’t know what happened I think your call dropped

**Jeff Bergosh**: R u home?

**Jeff Bergosh**: By the way Did a small package come for me on Monday? It had a day timer in it?

### CONVERSATION ON 12-05-2019

**Jeff Bergosh**: What r u doing at civic center?

**Jeff Bergosh**: See u at the house after.....

**Jeff Bergosh**: Love u

**Jeff Bergosh**: Nothing fixes all traffic 

**Jeff Bergosh**: Compelling data that confirms what I have known all along

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: Crazy hectic tragic day that was surreal 

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: Hey what time are you coming home Sally?

**Jeff Bergosh**: Three of my employees are locked down and they’re building the rest of us we’re on our way and we’re prevent him from getting on the base

**Jeff Bergosh**: Something major happening at NAS Pensacola front gate.   Traffic at a standstill at the foot of the bridge, 6 ECSO cruisers just whizzed by with sirens blaring.  Major gridlock

Jeff B

**Jeff Bergosh**: 9 cruisers total racing there

**Jeff Bergosh**: Or you may use my headshot from the county’s website

**Jeff Bergosh**: MyEscambia.com

**Jeff Bergosh**: D1 Commissioner Jeff Bergosh

### CONVERSATION ON 12-07-2019

**Jeff Bergosh**: https://news.yahoo.com/witness-describes-massive-police-response-211346138.html

**Jeff Bergosh**: My interview on Fox News Yesterday

**Jeff Bergosh**: Jason—

This is a correspondent with NBC that has called for information.  I deferred to you and gave her your contact information and here is her cell number in case you want to reach out to her.



Jeff Bergosh
Escambia County Commission District 1

### CONVERSATION ON 12-08-2019

**Jeff Bergosh**: I have a seat saved for you

**Jeff Bergosh**: Parking around back where it says guest parking

**Jeff Bergosh**: Good morning Blayne, this may be of interest to you, the photos, and description.  Disregard if you are already aware of this

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2019/12/escambia-county-provides-mobile-command.html?m=1

### CONVERSATION ON 12-09-2019

**Jeff Bergosh**: Please text me Scott’s cell number

**Jeff Bergosh**: Hey I made spaghetti for dinner there’s plenty of leftovers and it’s ready when y’all get home love you

### CONVERSATION ON 12-10-2019

**Jeff Bergosh**: ?

### CONVERSATION ON 12-11-2019

**Jeff Bergosh**: Love u

**Jeff Bergosh**: I’m not going to be there

**Jeff Bergosh**: I’m leaving after NFCU contract vote

**Jeff Bergosh**: That’s huge news!!!

**Jeff Bergosh**: No 7:30 today

### CONVERSATION ON 12-12-2019

**Jeff Bergosh**: Here

**Jeff Bergosh**: Isn’t happy hour over??

**Jeff Bergosh**: Can I come casual??

### CONVERSATION ON 12-13-2019

**Jeff Bergosh**: 18 holes at Shingle Creek

### CONVERSATION ON 12-14-2019

**Jeff Bergosh**: I'll probably just release it today any way.  They are not following our policy

**Jeff Bergosh**: And that’s one thing we have to consider before I release the report

**Jeff Bergosh**: Wagon circling

### CONVERSATION ON 12-15-2019

**Jeff Bergosh**: I’m just trying to work out what evidence they have that supports this paragraph.....



**Jeff Bergosh**: I’m emailing Janice this morning I’m requesting additional information specifically about how they claim to know that on April 23 the decision was made to report you to the state. I am going to request to see that source documentation.

**Jeff Bergosh**: Do you think Leanne Salter would talk to me?

**Jeff Bergosh**: My question to our attorney

**Jeff Bergosh**: It should not be this way though

**Jeff Bergosh**: Right is right 

**Jeff Bergosh**: Wrong is wrong

**Jeff Bergosh**: This feels wrong

**Jeff Bergosh**: Look at your county email

**Jeff Bergosh**: His name is Jerry Maygarden

**Jeff Bergosh**: That's what changed I'm afraid

### CONVERSATION ON 12-16-2019

**Jeff Bergosh**: Hey where r u??

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: To discuss follow up from Monday where I received still no responses

**Jeff Bergosh**: Are u calling?

### CONVERSATION ON 12-19-2019

**Jeff Bergosh**: https://apple.news/AVjIzub9XQZCN5AICbPyZKg

**Jeff Bergosh**: Your voter ID registration number on the left of your name

**Jeff Bergosh**: Thanks for having me on

**Jeff Bergosh**: And by the way the only reason I wouldn't want it to be a 2/3 majority and make that the solution only is because going forward into our future based upon the demographics and the shifts that are happening in America I would not be surprised if the majority party very soon could make up 2/3 of the house of representatives which would make that bar too easy to climb over if it was simply 2/3 required.  Specifying a percentage of the minority party would have to be supportive would protect the power of the minority party and make the process bi-partisan

### CONVERSATION ON 12-20-2019

**Jeff Bergosh**: Me or mom or Tori

**Jeff Bergosh**: Mom can be there right when u touch down

**Jeff Bergosh**: That is Nicky’s flight number that gets to Pensacola at 2:45 today

**Jeff Bergosh**: Flight is coming in early, ahead of schedule at 2:16

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: Did Edler ask him for a statement?

**Jeff Bergosh**: Please copy me on that email if you’re comfortable doing so

**Jeff Bergosh**: Where r u? 

### CONVERSATION ON 12-21-2019

**Jeff Bergosh**: Tomorrow you are delivering???

**Jeff Bergosh**: Where are you turkey?

**Jeff Bergosh**: Exiting to watch

**Jeff Bergosh**: *exciting

### CONVERSATION ON 12-22-2019

**Jeff Bergosh**: OK I found the $100 gift card to Amazon for Nicky and I bought it along with that video game for Brandon

**Jeff Bergosh**: 😎

**Jeff Bergosh**: I’m incognito with my hat and hoodie—walked right by Nikki and Tina Bonsignore and they didn’t even recognize me lol 

**Jeff Bergosh**: I work 12-31-19

### CONVERSATION ON 12-27-2019

**Jeff Bergosh**: Did u see this wonderful post this morning?

**Jeff Bergosh**: Calling Chips

### CONVERSATION ON 12-28-2019

**Jeff Bergosh**: Just a lot of union BS

**Jeff Bergosh**: Embarrassing 

### CONVERSATION ON 12-31-2019

**Jeff Bergosh**: Happy New Year!!!!!

### CONVERSATION ON 01-01-2020

**Jeff Bergosh**: We ate at a restaurant called august which is a fancy five star restaurant and although the food was very very foo foo—— it was very tasty

### CONVERSATION ON 01-02-2020

**Jeff Bergosh**: Straight to her voicemail 

**Jeff Bergosh**: Okay she called back

**Jeff Bergosh**: Trying to call u at health and hope clinic— phone line keeps hanging up on me

**Jeff Bergosh**: Great intro music just now!

**Jeff Bergosh**: Let me know and I'll head that way

### CONVERSATION ON 01-03-2020

**Jeff Bergosh**: I just found out about it last night and it is a horrible plan that will have tremendous negative impacts to all of us generally but to NFCU employees particularly?

**Jeff Bergosh**: As soon as you are able we should discuss.  I’m calling Broxson and Gainer personally

### CONVERSATION ON 01-04-2020

**Jeff Bergosh**: Hey happy new year Billy. I sent this thank you card to Ryan shavers however it came back returned and I do not have his cell phone number. Can you please forward this to him and I will deliver it personally to his company headquarters. Thanks very much Billy

### CONVERSATION ON 01-05-2020

**Jeff Bergosh**: Hey you all— mom and I will be going to bed soon and you all are all out for the night.  I just want to remind you all to be safe and responsible;  cops are everywhere so if you are drinking DO NOT DRIVE.  Do not risk it, call Uber or call mom and I.  Be smart.  We love you!

Dad

### CONVERSATION ON 01-06-2020

**Jeff Bergosh**: Just like the Sebring 

### CONVERSATION ON 01-07-2020

**Jeff Bergosh**: Mandeville will likely get kicked down the road tonight

**Jeff Bergosh**: Already met with the residents and I’ve already spoken to the developer

**Jeff Bergosh**: Thursday I can be home early, like 4:00

**Jeff Bergosh**: She tried to deflect by saying it was an “oversimplification”

### CONVERSATION ON 01-08-2020

**Jeff Bergosh**: Yeah I heard Bill is going to get behind Greg Marcile for state attorney

**Jeff Bergosh**: I’d love to see my brother in that office cause I know he has balls I don’t dislike Greg however when I had the Newpoint information the collusion and conspiracy to keep information deliberately from the School board Greg Marcile and Russ Edgar did nothing

**Jeff Bergosh**: She’s rapidly getting to a point where I don’t know if she’s gonna be able to stay if I’m being very honest about it

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: 1:30 flight tomorrow

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 01-10-2020

**Jeff Bergosh**: Which actually helps me I think

**Jeff Bergosh**: I think Jay supports it

### CONVERSATION ON 01-11-2020

**Jeff Bergosh**: Yes

**Jeff Bergosh**: It’s like she thinks she is in charge

### CONVERSATION ON 01-12-2020

**Jeff Bergosh**: Believe me---been here, done that many times previously 👍

**Jeff Bergosh**: Thanks though

**Jeff Bergosh**: Have a great on Mel--headed to church 

### CONVERSATION ON 01-13-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 01-14-2020

**Jeff Bergosh**: Men’s Barn Meeting 
Contact person is Jim Porter 850-232-8518

**Jeff Bergosh**: Please contact this gentleman and arrange for a $2500 donation from my discretionary if we can get her on next week’s agenda that would be great thanks Debbie

**Jeff Bergosh**: Sorry about the rapidfire I’m on a short break slammed at work

**Jeff Bergosh**: Can you please text me Stephen’s phone number

**Jeff Bergosh**: I'm pretty sure Sally is going though

### CONVERSATION ON 01-16-2020

**Jeff Bergosh**: Dinner is in the fridge

**Jeff Bergosh**: ???

**Jeff Bergosh**: Meaning he would go 9 months without a paycheck

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 01-17-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 01-19-2020

**Jeff Bergosh**: Just making sure

**Jeff Bergosh**: If it might reflect poorly on new leadership 

**Jeff Bergosh**: Which it will

**Jeff Bergosh**: ..........we all take our lumps

**Jeff Bergosh**: Heard ceremony got rocked in 30 seconds flat 

**Jeff Bergosh**: Cerrone 

**Jeff Bergosh**: 49 ers running away with it

**Jeff Bergosh**: 2 score game right now 

### CONVERSATION ON 01-21-2020

**Jeff Bergosh**: Debbie can you reach out to Debbie Graham at the Pensacola Chamber of Commerce and ask her where physically the meetings are held for the military affairs committee?

**Jeff Bergosh**: Doug jumped in too

### CONVERSATION ON 01-22-2020

**Jeff Bergosh**: I have a couple of pistols including a small .380

### CONVERSATION ON 01-24-2020

**Jeff Bergosh**: For your contact lens appointment Monday

**Jeff Bergosh**: I’ll have staff investigate

**Jeff Bergosh**: It is in an enclave that is part of the county

**Jeff Bergosh**: We’ll get it sorted out

**Jeff Bergosh**: If it’s any consolation—— for the last 13 years they have beat me to death with negative attack pieces against me and over 20 cartoons lampooning me. It’s horrible but you will get through it and you don’t deserve it

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 01-26-2020

**Jeff Bergosh**: So we have 100% chance of rain for the next four hours are we going to go to dinner or are we going to postpone the whole affair until February 9?

**Jeff Bergosh**: I only ride with these kinds of planes

**Jeff Bergosh**: Yeah

**Jeff Bergosh**: Like one of those Geico commercials it’ll be OK we’ll figure it out in the operating room

### CONVERSATION ON 01-27-2020

**Jeff Bergosh**: Today's garbage cartoon in the PNJ
Liars

**Jeff Bergosh**: Welcome to the war

**Jeff Bergosh**: Of course it’s not fair

**Jeff Bergosh**: That is today’s liberal, agenda-driven drive by media

**Jeff Bergosh**: Facts don’t matter, smear the guys we don’t like

**Jeff Bergosh**: This will backfire on them

**Jeff Bergosh**: If anyone asks you about it simply tell them what I’ve told you. I’ve participated in this parade for the last 13 years with no issue. This year the PNJ wants a different candidate to win my race so they will vilify me every way they can including portraying me as a racist which I am not. If I was a racist I certainly would not participate in this parade for the last 13 years. Nor would I have ever owned a bar that primarily served black female customers.  Facts do not matter though to the fake news media locally

**Jeff Bergosh**: I’ve been absorbing these attacks for awhile now, regardless of what I do or do not do.  The evidence was the parade itself.  How in the world can that be turned into an attack?

**Jeff Bergosh**: Here is what you have to be prepared for:  no matter what I do or do not do, say or do not say, they will attack me.  Focus on what I do:  my job and I work very hard at it and I am proud of my accomplishments.   When I am attacked, I will respond.  Otherwise—-what’s the use in serving?

**Jeff Bergosh**: And I will win this election despite whatever PNJ does or does not do.  

**Jeff Bergosh**: I’m going to ignore this

**Jeff Bergosh**: But I think there are larger forces at work here and I just might be a pawn in a three-dimensional chess game

**Jeff Bergosh**: And we can discuss that tonight I’ll tell you my theory and you can tell me what you think

**Jeff Bergosh**: Meanwhile should you go to the civic con thing? And we divide and conquer and I go to the executive committee meeting?

**Jeff Bergosh**: I think you should present it

**Jeff Bergosh**: Don’t let them throw you off your game otherwise they win

**Jeff Bergosh**: If someone ask you about it tell them the truth! It’s ugly politics at its worst and fake journalism. Remember I was not the one campaigning that day

**Jeff Bergosh**: And I’ve been in that parade for 13 years and if invited to participate again I will do so again unashamedly

**Jeff Bergosh**: Don’t let those light weights throw you off your game

**Jeff Bergosh**: And don’t tell Sarah about it test her see if she even knows I bet she doesn’t even know

**Jeff Bergosh**: He can take the car I’ll leave and still pay for his insurance and his fucking phone but he is moving out he’s got a week

**Jeff Bergosh**: Don’t fuck it up

**Jeff Bergosh**: In my profession I absorb a lot of BS attacks—-just like the one in today’s PNJ cartoon.  So if it’s any consolation you are not the only one they are portraying in a false light

**Jeff Bergosh**: They have hated every day of my existence as an elected official for the last 13 years and have hammered me with unfair, inaccurate cartoons

**Jeff Bergosh**: .......or they do run and kowtow to the media to curry favor

### CONVERSATION ON 01-30-2020

**Jeff Bergosh**: Do you want me to stop on the way home and pick up dinner?

### CONVERSATION ON 01-31-2020

**Jeff Bergosh**: OK so this is funny:  I have a Ronald Reagan calendar in my office and being that it is the last day of January I am flipping it to the February page.

**Jeff Bergosh**: The February page has President Reagan posing with his security detail and it’s kind of freaky having this up on my wall frankly

**Jeff Bergosh**: Don’t want people getting the wrong idea about me😂😂😂😂

### CONVERSATION ON 02-02-2020

**Jeff Bergosh**: I’m stuck because I kind of like both teams but because Andy Reid is coaching the Chiefs and I like Mahomes I’ll probably root for the Chiefs

**Jeff Bergosh**: 😂

### CONVERSATION ON 02-03-2020

**Jeff Bergosh**: Saturday February 22nd through Monday March 2nd.   10 days total.  First day fast, 9 days juicing.

What do you say?

**Jeff Bergosh**: Yes?

**Jeff Bergosh**: Just went through it all— got your health and hope and all mine—but not nursespring

**Jeff Bergosh**: Steaks going on the grill soon—u on way home??

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Jeff Bergosh**: They may have misunderstood the question as well because of the way I worded it and perhaps they were voting to disapprove or approve of the job the commission is doing as a whole

**Jeff Bergosh**: Frank I got some polling information back.....give me a call if you have a moment to discuss.  Huge positive result in a hypothetical SA matchup Bergosh/Marcile

**Jeff Bergosh**: I just checked and I didn’t get either one.  Oh well.  I just sent you an email please see if you can reply to that and add the quote or just let me know what the total is via text

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

### CONVERSATION ON 02-07-2020

**Jeff Bergosh**: Need a worker order created right away as soon as u get here

**Jeff Bergosh**: In your email box

**Jeff Bergosh**: Heather— quick question:  I’m going to close out Johns work order in eLe database and there is no 20604.  There is only up to 20603 so how do I close this to run reports for tony?  Thanks

**Jeff Bergosh**: Tim’s electronic timesheet needs to be submitted

### CONVERSATION ON 02-11-2020

**Jeff Bergosh**: Sally I’m coming down with a cold— I ate some chicken noodle soup and took a NyQuil!

Love u!

### CONVERSATION ON 02-13-2020

**Jeff Bergosh**: Trying to call u- we r playing phone tag

**Jeff Bergosh**: Good job!

**Jeff Bergosh**: So just to confirm:  bonefish at 6:30?

**Jeff Bergosh**: ......just kidding

**Jeff Bergosh**: Hey look at it this way if half the people go to bonefish and have to people go to V Paul’s we can have dinner and Skype

**Jeff Bergosh**: John/Gary

We won't be having our 7:30 AM meeting today. I don't believe much has changed between yesterday afternoon and this morning so I will get with you guys later this morning individually if needed.

**Jeff Bergosh**: No—- 

### CONVERSATION ON 02-14-2020

**Jeff Bergosh**: Are you wearing a ski mask?

### CONVERSATION ON 02-18-2020

**Jeff Bergosh**: Debbie:  I have the PEDC board meeting this morning at 10:00 at the  CoLab building on Garden street.  I need you to meet me there at 9:50 with the agenda and back up book— I don’t  have it

**Jeff Bergosh**: Thanks!

**Jeff Bergosh**: Tim-  The question being asked is why was the building spray-painted as part of a dig permit?

**Jeff Bergosh**: Okay thanks

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 02-19-2020

**Jeff Bergosh**: Brandon— I also have VSP vision coverage through my day job

**Jeff Bergosh**: Hey Randy--I'm in a meeting I'll call u right after I get out.  I hope all is well

**Jeff Bergosh**: I hope it was simply a misunderstanding

**Jeff Bergosh**: And the funny thing is he thinks he’s normal and we are all fucked up

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Where is the physical framed document?

**Jeff Bergosh**: I’m going to call Mary Engelhart

**Jeff Bergosh**: 5 of the 127 were not fans LOL

**Jeff Bergosh**: Just sent you “Country at the Clinic” draft sponsorship forms to your email. ❤️😁😎. Love u

### CONVERSATION ON 02-21-2020

**Jeff Bergosh**: Hey Nick I just got paid and I threw you 100 bucks into your checking account that way you can get through next week with more than just Ramen love you

**Jeff Bergosh**: It works--with this latest batch I have met my 440 petition requirement----lots of doubles in the return envelopes

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Good morning Gary-I hope all is well. I just wanted to reach out to you this morning and ask if you had any properties on the west side of Pensacola where I might be able to put up some signs.  My opponents in this election are putting up a ton of signs and I want to keep pace with them. Today after church I plan to put out 20 of these roadsigns and I didn't know but thought you might have some properties along Pine Forest, Barrancas, Blue Angel, Lillian, Michigan ave, or other west side areas where some signs would help me. If you all do have some areas where I could put signs up I would greatly appreciate it!  And as I said after church this morning I intend to spend the entire afternoon putting them up. Thanks in advance for any help you could provide on this front!

**Jeff Bergosh**: Good morning Bill I hope all is well. I just wanted to reach out to you this morning and ask if you had any properties on the west side of Pensacola where I might be able to put up some signs.  My opponents in this election are putting up a ton of signs and I want to keep pace with them. Today after church I plan to put out 20 of these roadsigns and I know you might have some properties along Pine Forest, Barrancas, Blue Angel, Lillian, Michigan ave, or other west side areas where some signs would help me. If you all do have some areas where I could put signs up I would greatly appreciate it!  And as I said after church this morning I intend to spend the entire afternoon putting them up. Thanks in advance for any help you could provide on this front!

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: David--I got the stakes you cut---thanks very much!!  Also, thanks for letting me borrow the mini sledgehammer!

**Jeff Bergosh**: I have a 12:00 on Monday with you all

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: Good luck with stuff

**Jeff Bergosh**: Destin

**Jeff Bergosh**: John: can you call Bill Swaney.  He is calling about the manhole job.  His number is 452-4613

### CONVERSATION ON 02-28-2020

**Jeff Bergosh**: Carey Lohrenz first female F 14 Tomcat pilot.  Fearless leaders facing fears

### CONVERSATION ON 02-29-2020

**Jeff Bergosh**: Thanks

### CONVERSATION ON 03-02-2020

**Jeff Bergosh**: Tim---It's my understanding that a complaint was put in on this sign.  I have permission from developer who owns this property to have this sign here.  It is not county property. Call me if you need

**Jeff Bergosh**: It is los suenos subdivision off of Bauer Road

### CONVERSATION ON 03-03-2020

**Jeff Bergosh**: Contact info

**Jeff Bergosh**: Dawn Troche 

**Jeff Bergosh**: Employee of the month—where r u???

**Jeff Bergosh**: ????????

**Jeff Bergosh**: Why—do u need it sooner?

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Here is the letter that was sent on the 24th.  I also emailed it to you as well.  In meetings or I'd try to call you again.  

Jeff Bergosh 

### CONVERSATION ON 03-05-2020

**Jeff Bergosh**: 
Also come to find out I did have a bout 10 hangers at the office that I’ll be bringing home

**Jeff Bergosh**: In a mtg

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: I am in meetings that's why I didn't take your call.  I spoke to Janice about you wanting a meeting--she told me she has called and there was no answer

### CONVERSATION ON 03-06-2020

**Jeff Bergosh**: I’ll answer that big one today, and we will Deal with that other very large and expensive Wendy Underhill request next week

**Jeff Bergosh**: 


### CONVERSATION ON 03-08-2020

**Jeff Bergosh**: Finishing last sign then I’m headed home to make dinner

### CONVERSATION ON 03-11-2020

**Jeff Bergosh**: Good call

**Jeff Bergosh**: Which is ridiculous

### CONVERSATION ON 03-12-2020

**Jeff Bergosh**: LOL

**Jeff Bergosh**: What time do you want me to make the reservation for?

**Jeff Bergosh**: I think this is beneficial

**Jeff Bergosh**: That’s a shame

### CONVERSATION ON 03-13-2020

**Jeff Bergosh**: May still need David Heroux’shelp as well

**Jeff Bergosh**: Need u to enter your timesheet Tim

**Jeff Bergosh**: Ok

**Jeff Bergosh**: When u make the deposit, just put it directly into the same account I’ll move your money from.  Our joint savings account.

The number is 

0877642306

**Jeff Bergosh**: Hey Kevin--been kind of busy with Coronavirus issue but I did forward the Rebel Road issue to staff so they will be reaching out to you and probably Shawn Dennis on what we can do and what it will cost.  Just didn't want you to think I had lost sight of this issue 

**Jeff Bergosh**: .......Trend line looks like it’s going back down again

**Jeff Bergosh**: I wish I could Nick but if you want to go there I’ll get the room ready for you

**Jeff Bergosh**: I need for you all to enter your timesheets in the system

**Jeff Bergosh**: I wanna know about the nuclear power plants he’s built though I have some concerns about those

### CONVERSATION ON 03-14-2020

**Jeff Bergosh**: Household cleaner Aisle

**Jeff Bergosh**: Crazy crowd here!!!

**Jeff Bergosh**: Double what a normal Saturday looks like

**Jeff Bergosh**: No:  napkins, TP, bleach, sanitizer, hand soap, Lysol, cleaner wipes

**Jeff Bergosh**: And u get a paycheck Tuesday

**Jeff Bergosh**: So we’re going to get some exercise

### CONVERSATION ON 03-16-2020

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Rick's blog is reporting we do, that the test was administered Wednesday at a clinic and came back this morning positive.  That is why I'm asking.  Is that true to your knowledge?

### CONVERSATION ON 03-17-2020

**Jeff Bergosh**: This is important

**Jeff Bergosh**: Did the Governor just class all bars for 30 days?

### CONVERSATION ON 03-18-2020

**Jeff Bergosh**: Here's a dumb question though what if the same family goes to all library's will there be a check off protocol? I only ask this because I know people particularly in times of distress or emergency will unfortunately try to game the system to their advantage

**Jeff Bergosh**: Which leaves if you were resources for the families that are legitimately playing by the rules and only attempting to get meals as authorized

**Jeff Bergosh**: You may want to consider some sort of a check off system so that you guys don't get played

### CONVERSATION ON 03-19-2020

**Jeff Bergosh**: Even did a blog post about it

**Jeff Bergosh**: On Tuesday

**Jeff Bergosh**: True

**Jeff Bergosh**: 11 o'clock tomorrow will be the board of County commissioners

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: Governor DeSantis just issued an executive order that prohibits on-premise consumption of food in restaurants as well as alcoholic beverages.  Only food to go from restaurants is permitted.  Takes effect immediately

**Jeff Bergosh**: Crazy

**Jeff Bergosh**: Governor closed all on premises restaurants and alcohol consumption effective immediately

**Jeff Bergosh**: Right now

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Us

**Jeff Bergosh**: Did what we do today include the fishing pier at Pensacola Beach?

### CONVERSATION ON 03-21-2020

**Jeff Bergosh**: Hot mike

### CONVERSATION ON 03-22-2020

**Jeff Bergosh**: 


**Jeff Bergosh**: New case today here

### CONVERSATION ON 03-23-2020

**Jeff Bergosh**: And I don’t know that the Island Authority would have done it unilaterally

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/tomorrow-dr-john-lanza-will-join-me-for.html?m=1

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/tomorrow-dr-john-lanza-will-join-me-for.html?m=1

Hello William-- this online event will be tomorrow morning.  If you have questions you would like me to ask just send them to me and I'd be happy to ask them or you can tune in tomorrow morning and ask them yourself.  Hope all is well

### CONVERSATION ON 03-25-2020

**Jeff Bergosh**: But he himself said it’s good to be out and stressed the fact that having the parks open for people to enjoy the outdoors is a good thing. So if it’s  good to enjoy a park as long as you observe the social distancing why is it bad or unlawful for us to enjoy our beach if we observe social distancing? I mean what’s the difference? Of course there is no good answer that question. So what we end up doing is punishing everyone for the miss behavior of a few.

### CONVERSATION ON 03-26-2020

**Jeff Bergosh**: Tennis this afternoon?

**Jeff Bergosh**: Love u

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: I don't know why I'm getting push back to that either

**Jeff Bergosh**: Screening phone line locally for COVID-19

850-746-2684

**Jeff Bergosh**: Don- can you play the song "Save Me". By the band "Beautiful Creatures". For my intro?  Thanks very much!!

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-27-2020

**Jeff Bergosh**: Sally- I’ll transfer your paycheck amount directly into your checking account if you want me to.  Then when you deposit your check, just put it into our joint savings account to replace the money transferred.

Savings Account number for the deposit is:


0877642306

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: https://apple.news/Ag8jToj6PQvG3WxMbY1NEoQ

### CONVERSATION ON 03-28-2020

**Jeff Bergosh**: Need your help getting fridge organized

### CONVERSATION ON 03-30-2020

**Jeff Bergosh**: ??

**Jeff Bergosh**: I sent you a meeting invite for a test call at 2:30 on zoom

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: Governor's Safer at Home Executive Order

**Jeff Bergosh**: Governor’s EO from today FYI

### CONVERSATION ON 04-02-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 04-03-2020

**Jeff Bergosh**: Tony, do you have a moment to talk?  I have a couple of issues I'd like to discuss when you have a moment.  Thanks!

Jeff B

### CONVERSATION ON 04-05-2020

**Jeff Bergosh**: I’m not putting the password out publicly and anyone that would do that is not thinking straight

**Jeff Bergosh**: Yes I did

### CONVERSATION ON 04-06-2020

**Jeff Bergosh**: Nick I got your tax form back but I need your signature on it if you can just sign your name how you normally sign it and take a picture of it and send it to me I’ll take care of it

**Jeff Bergosh**: And it looks like you’re getting $925 back as a refund

### CONVERSATION ON 04-07-2020

**Jeff Bergosh**: Hello Heather—I went to open the FY 19 Database and it appears to be  locked.  Any suggestions so I can run the reports?

**Jeff Bergosh**: Is that what you do?

### CONVERSATION ON 04-09-2020

**Jeff Bergosh**: Hey guys—off my Napster.  I’m on lunch using it!

**Jeff Bergosh**: This story has been “disappeared” off the internet.  What happened??

**Jeff Bergosh**: Now it just looks as though got very important position is going to go east

### CONVERSATION ON 04-11-2020

**Jeff Bergosh**: Sally—you won’t believe this article!!

### CONVERSATION ON 04-12-2020

**Jeff Bergosh**: Good Morning William and Hapoy Easter.  In case you wanted to know, because they have walked back their initial bad decision to keep the report from the public, I will be sending out an email to the administrator this morning officially withdrawing my request for a public meeting of the board.  Because they’ve made this decision which is the correct decision —a virtual meeting the board next week won’t be necessary. So I anticipate the board will not meet again until planned on May 7.

**Jeff Bergosh**: In case you wanted to know, because they have walked back their initial bad decision to keep the report from the public, I will be sending out an email to the administrator this morning officially withdrawing my request for a public meeting of the board.  Because they’ve made this decision which is the correct decision —a virtual meeting the board next week won’t be necessary. So I anticipate the board will not meet again until planned on May 7.

### CONVERSATION ON 04-13-2020

**Jeff Bergosh**: She hasn’t filed her taxes yet

**Jeff Bergosh**: She needs to put that straight toward her bills!!

### CONVERSATION ON 04-15-2020

**Jeff Bergosh**: I think I’m gonna massage it some more and maybe take out the part vote for Jeff

### CONVERSATION ON 04-16-2020

**Jeff Bergosh**: This interview is nothing but a contrived, planned kabuki dance designed to cover for this gaffe

**Jeff Bergosh**: If this was a hundred paddle boarding yuppies at Bayview park his guys would have broken it up instantaneously

**Jeff Bergosh**: Outzen knows his boundaries, that's my opinion

**Jeff Bergosh**: Experience matters:  Now more than ever!

**Jeff Bergosh**: Tested Leadership for trying times

**Jeff Bergosh**: I work a semi-flexible schedule and work until 4:30-5:30 daily

**Jeff Bergosh**: ......Even Andrew “Tallman” knows that too.  But hey—- he’s in the tank for Doug and Doug’s secretary so I expect no less

### CONVERSATION ON 04-17-2020

**Jeff Bergosh**: Which one wins?  Need to make a decision?

**Jeff Bergosh**: Congrats on the article though it was very positive

**Jeff Bergosh**: I’m here ❤️😎👍

**Jeff Bergosh**: At Tuscan

**Jeff Bergosh**: They’re super busy

**Jeff Bergosh**: Still waiting

**Jeff Bergosh**: What time did they say it would be ready??

**Jeff Bergosh**: ??

**Jeff Bergosh**: From laptop or smartphone

### CONVERSATION ON 04-18-2020

**Jeff Bergosh**: Social distancing

### CONVERSATION ON 04-20-2020

**Jeff Bergosh**: About time

**Jeff Bergosh**: I thought around and Russia had a deal to cut production to raise the price

### CONVERSATION ON 04-21-2020

**Jeff Bergosh**: Really???

**Jeff Bergosh**: What BS

**Jeff Bergosh**: Shameful

**Jeff Bergosh**: We tried to appeal that decision!!!

**Jeff Bergosh**: They said NO

**Jeff Bergosh**: .......Toughest would’ve had to make in public office probably

**Jeff Bergosh**: *vote I’ve

### CONVERSATION ON 04-22-2020

**Jeff Bergosh**: Left wingers want unlimited shut down

**Jeff Bergosh**: It's going to infuriate locals 

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: And District 2 wants to bring that kind of leadership to District 1.  No thanks 

**Jeff Bergosh**: .......No thank you to Underhill's secretary Johnathan Owens

**Jeff Bergosh**: Here's the complete exchange in case you didn't see it, sent to me by a constituent

**Jeff Bergosh**: Autocorrect got me

**Jeff Bergosh**: Minutes

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/bringing-restaurants-to-beulah.html?m=1

### CONVERSATION ON 04-24-2020

**Jeff Bergosh**: Tim can you submit your electronic timesheet?

### CONVERSATION ON 04-27-2020

**Jeff Bergosh**: Hello Sam—to what email address should I send the meeting log-in credentials for Wednesday morning’s virtual coffee meeting online?

Thanks, 

Jeff Bergosh

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Says it was delivered but Brandon does not see it

**Jeff Bergosh**: Important

**Jeff Bergosh**: Big number

**Jeff Bergosh**: Audio and video if you can do it

### CONVERSATION ON 04-29-2020

**Jeff Bergosh**: Good morning Congressman Gaetz, I’m going to call you in 10  minutes

**Jeff Bergosh**: Hey Luke there was some sound issues with the live recording. I had our IT department clean it up and I've sent you a link to a much better cleaner version. I'm hoping you can switch it out for the one that you have linked on Matt's page -----it is much better.  Thanks Luke!

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: Is my cc activated?

**Jeff Bergosh**: 2019 tax form

**Jeff Bergosh**: 2019 w-2

**Jeff Bergosh**: Do this first 

**Jeff Bergosh**: 2018 Tax Form

**Jeff Bergosh**: I am

**Jeff Bergosh**: But you need to fill out the form online

**Jeff Bergosh**: With the info I’m sending you

**Jeff Bergosh**: W-2 2018

**Jeff Bergosh**: W-2 2018

**Jeff Bergosh**: Have you Drivers license ready plus the forms I’ve texted u

**Jeff Bergosh**: Then google this

**Jeff Bergosh**: Then go to this site

**Jeff Bergosh**: And click “apply here”

**Jeff Bergosh**: 256074974

**Jeff Bergosh**: Checking account number is

**Jeff Bergosh**: 7046191024

**Jeff Bergosh**: From Administrator Gilley just now👍

### CONVERSATION ON 05-01-2020

**Jeff Bergosh**: Tim I need your timesheet put in electronically

### CONVERSATION ON 05-05-2020

**Jeff Bergosh**: Blackberry Ridge 

**Jeff Bergosh**: This one’s better.....

**Jeff Bergosh**: https://www.google.com/amp/s/amp.pnj.com/amp/3078935001

**Jeff Bergosh**: 


**Jeff Bergosh**: Maybe the week after, and we can invite Kevin Adams as well—make it a multi-entity D1 coffee

**Jeff Bergosh**:  ......

### CONVERSATION ON 05-06-2020

**Jeff Bergosh**: Wow—you’re not going to believe this!

### CONVERSATION ON 05-07-2020

**Jeff Bergosh**: ECUA should have taken it

### CONVERSATION ON 05-08-2020

**Jeff Bergosh**: You will win your lawsuit and it should have never come to that

**Jeff Bergosh**: And the taxpayers lose

### CONVERSATION ON 05-10-2020

**Jeff Bergosh**: Virtual backgrounds dint work well, I need a physical background

### CONVERSATION ON 05-11-2020

**Jeff Bergosh**: 2 of them in garage

**Jeff Bergosh**: I’ll get the addresses


**Jeff Bergosh**: Sorry— meant to send this 👍

### CONVERSATION ON 05-12-2020

**Jeff Bergosh**: I'll be on Ch3 news at 6 talking about the need for a burn ban

**Jeff Bergosh**: It will take a minute though

**Jeff Bergosh**: We're gonna be talking about the future of youth sports in the county in the era of Covid and with Ray Palmer we're gonna talk about Covid and the impact on all of the different sports tourism events his organization sponsors

**Jeff Bergosh**: Mike Rose is also going to give some breaking news about some tremendous upgrades that are gonna be added to the Beulah Park including a climbing wall of water feature in an outdoor workout area so there's gonna be some breaking news

**Jeff Bergosh**: *Rhodes

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/05/burn-ban-now.html?m=1

### CONVERSATION ON 05-13-2020

**Jeff Bergosh**: Got my poll results today!!!

**Jeff Bergosh**: From February it looked like this

**Jeff Bergosh**: I lost 3% but Jesse lost 11% 😎👍

**Jeff Bergosh**: On TV frequently, no oxygen for my opponents

**Jeff Bergosh**: Hell David—got my latest poll numbers back from Gravis today, of the 256 respondents that have decided in my race, the breakdown looks like this:

**Jeff Bergosh**: Here's her text to me:

**Jeff Bergosh**: Hello Chip.  I just received results back from my polling company Gravis Marketing.  I polled my race and several others including yours, you against David Alexander.  Anyhow, for District 1 in this poll you are crushing it 75% to 25% among the respondents that have decided as of the date of this poll.  Congrats and keep up the great work Sheriff!!

**Jeff Bergosh**: That was what I sent in February

**Jeff Bergosh**: I can send you the mailers I sent out in my first campaign—did several.  Just text me a good email to send them to

**Jeff Bergosh**: (I included my palm card with the petition mailer)

**Jeff Bergosh**: Back of palm card

**Jeff Bergosh**: Gotta do it methodically 

**Jeff Bergosh**: I’m beating Underhill’s secretary by 30 points

**Jeff Bergosh**: $1,250

**Jeff Bergosh**: 10,234 called. 329 responded 256 decided as of today

**Jeff Bergosh**: Gotta make it work!

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Gene: I had a schedule shift this afternoon and I won’t be able to make the meeting over at your place——I’ll be on a conference call with county admin over this whole burn ban issue with these fires and dangerous fire conditions

**Jeff Bergosh**: But I want them to be blissfully unaware

**Jeff Bergosh**: Emcon Alpha

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Posted then deleted

**Jeff Bergosh**: Months ago

**Jeff Bergosh**: 7:39?

### CONVERSATION ON 05-15-2020

**Jeff Bergosh**: Call me about paying the tree guy

**Jeff Bergosh**: I forgot to get that money out of the safe but I do have a work around plan

**Jeff Bergosh**: ?????

**Jeff Bergosh**: Call me about paying the tree guy

**Jeff Bergosh**: Marlette is a sack of crap, dishonest liar and he does not represent Pensacola and Escambia county with his garbage hit pieces like this morning’s tripe.  God knows I’ve been on the receiving end of many of them since 2006.   Keep up the great work —-and just know that those of us who pay attention know the real deal about that clown.  Have a great weekend.

Jeff Bergosh

### CONVERSATION ON 05-17-2020

**Jeff Bergosh**: Man that’s one heck of a big dog!!

**Jeff Bergosh**: Hey good afternoon Jim this is Jeff Bergosh. I'm out delivering signs today and was wondering if you could give me the gentleman's name at Highway 98 and dog track that requested a sign. I can swing by and drop it off today if that would be OK

### CONVERSATION ON 05-18-2020

**Jeff Bergosh**: I’m calling Janice Gilley right now

**Jeff Bergosh**: No response.  I’m disgusted.  This gets taken care of this week or I’ll go buy them on my county credit card and deliver them myself in my truck

### CONVERSATION ON 05-19-2020

**Jeff Bergosh**: That was her response

**Jeff Bergosh**: So yes, please follow up with her office at 8

**Jeff Bergosh**: They would not make a career Firestation wait two months for replacement mattresses

**Jeff Bergosh**: So we need to get this done today even if I have to do it myself in my truck

**Jeff Bergosh**: Folks Are getting spun up about this as I knew they would. This is why I really didn’t want to move it forward

**Jeff Bergosh**: Anything

**Jeff Bergosh**: According to news releases all valid claims and all complete submissions have been processed in the Florida unemployment system. Therefore knowing you have not been paid yet you need to login to figure out what is missing from your application. Go to the above website and login with your Social Security number and your pin number which hopefully you established when you made your initial application for unemployment. If you don’t have a pin number you will have to wait on hold and call them. Either way You need to look into this because there’s potentially $1600 coming your way when you navigate this process successfully

**Jeff Bergosh**: $2000

**Jeff Bergosh**: Can we move this?

**Jeff Bergosh**: Please call me ASAP

### CONVERSATION ON 05-20-2020

**Jeff Bergosh**: COVID-19 Crazy!

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: He hasn’t called yet

**Jeff Bergosh**: Go look at Ricks blog

**Jeff Bergosh**: Good article

### CONVERSATION ON 05-22-2020

**Jeff Bergosh**: Can the screenshots be released to Chorus Nylander?  Lots of people have them now, they are on Facebook and Doug Underhill admits he released the transcripts because he “disagrees” with your legal opinion.  Please advise.

### CONVERSATION ON 05-23-2020

**Jeff Bergosh**: Out of edamame

### CONVERSATION ON 05-24-2020

**Jeff Bergosh**: Tori--are u coming home?  Don't u work 7-7 tomorrow?   Anyway don't drink and drive--call us if u need a ride or take an Uber,  let us know though

### CONVERSATION ON 05-25-2020

**Jeff Bergosh**: Hope you had a great weekend!

### CONVERSATION ON 05-28-2020

**Jeff Bergosh**: When I was leaving for work today I noticed Brandon’s front driver side tire is flat. So when you guys get back from tennis call AAA on mom’s membership card and they will come and change the tire under mom’s membership. Then Brandon should take his car to pep boys and let them repair the flat there is probably a slow leak or a nail in it

### CONVERSATION ON 05-29-2020

**Jeff Bergosh**: Then call me and I’ll pay over the phone with charge card

**Jeff Bergosh**: And while you’re there call the Florida department of economic opportunity and ask where your unemployment payments are.

**Jeff Bergosh**: Just put $740 in your checking

**Jeff Bergosh**: He thinks he's got a whistle blowing patriot like Edward Snowden

### CONVERSATION ON 06-04-2020

**Jeff Bergosh**: Also I’m out on my walk right now can you please text me the phone numbers for the folks that are angry about the car wash?

**Jeff Bergosh**: I will call Jim back if you can get his number

**Jeff Bergosh**: He's got no money and no name recognition in District one and he's going to lose badly

**Jeff Bergosh**: In fact I'm going to squash him like a roach

### CONVERSATION ON 06-05-2020

**Jeff Bergosh**: Need you to enter your timesheet online Tin

### CONVERSATION ON 06-07-2020

**Jeff Bergosh**: Good Morning Mike—. I made just a couple of edits to the mailer.  Thanks very much!  Hope you’re having a great weekend.

### CONVERSATION ON 06-08-2020

**Jeff Bergosh**: Hey I got your key

**Jeff Bergosh**: Put it on your computer

**Jeff Bergosh**: Tim you have one due

**Jeff Bergosh**: Locate water lines at 5th and Thompson

**Jeff Bergosh**: Tim where are you?

**Jeff Bergosh**: Trying to call you

**Jeff Bergosh**: Hey Heather I’m trying to reach Tim can you call him and have him call me?  he’s got a project due I can’t find him and I need to know what’s going on

**Jeff Bergosh**: We extended it last week until today

### CONVERSATION ON 06-10-2020

**Jeff Bergosh**: Tim u have 3 due today

### CONVERSATION ON 06-12-2020

**Jeff Bergosh**: I put the $107 in your account this morning Brandon.  Make sure you buy that book.  It will help you get a better grade in the class

**Jeff Bergosh**: Mine too

**Jeff Bergosh**: Then, call this guy at GMI for the poll

### CONVERSATION ON 06-13-2020

**Jeff Bergosh**: I’m actually working on my campaign and I was just calling to see if I could get a quote from you regarding helping your business by putting up the signage warning drivers about horses

**Jeff Bergosh**: The two things I need are sign locations in Beulah along Beulah Road and on Mobile Hwy So if you have friends or relatives on those major roads that you think would allow me to put a sign up that would be greatly helpful and I would really appreciate that

**Jeff Bergosh**: ... and also quotes/testimonials!

**Jeff Bergosh**: So I was thinking of something like this:


As the owner of horse rides of Pensacola for over a decade I have enjoyed operating my business out in the Beulah community. But as Beulah has grown the number of interactions between horses and cars has increased —unfortunately leading to the death of a horse very recently on Frank Reeder Road. When I knew that we needed warning signage out in the community alerting drivers to the presence of horses and riders —-I contacted Commissioner Jeff Bergosh and he immediately assigned staff to the issue.  Within two weeks we had warning signs installed making our operations and drivers much safer. I appreciate Commissioner Bergosh ‘s support for local small businesses and his fast response to important issues. I think Jeff does a great job and he has my full support in this election.

—-Cheryl Glass, owner operator of Horse Rides of Pensacola

### CONVERSATION ON 06-14-2020

**Jeff Bergosh**: Questioned “Thank you so much Cheryl I do have shirts and I’ll get some to you!  Can’t tell you how much I appreciate the support!!”

### CONVERSATION ON 06-15-2020

**Jeff Bergosh**: Janice your mailbox is full and I need to speak with you on an urgent matter please call me as soon as you get this message thank you

### CONVERSATION ON 06-16-2020

**Jeff Bergosh**: Absolutely

**Jeff Bergosh**: Have you not called me I have every confidence that last night would’ve been a whole lot worse

### CONVERSATION ON 06-17-2020

**Jeff Bergosh**: Debbie recorded it

**Jeff Bergosh**: He was mr nice guy when I called him LOL

**Jeff Bergosh**: Probably not appropriate to send to the work email addresses though....

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Get your money!

**Jeff Bergosh**: Also- did u attend the training today?

**Jeff Bergosh**: Sally-okay got you all set.  You have $1000 in checking and $916.29 in savings and we paid back Brandon his tuition of $338–I just transferred that over.😎👍

**Jeff Bergosh**: In BCC meeting

**Jeff Bergosh**: Also- in my conference call yesterday with County Attorney and County Administrator—-I demanded an answer, in writing, about their official version of what happened with Naomi Price

**Jeff Bergosh**: Send it to me at district1@myescambia.com

**Jeff Bergosh**: It was bullshit what they tried to do!!

**Jeff Bergosh**: Mattresses delivered today Beau—sorry it took as long as it did.  It should not have.  But we got them there today at long last!

### CONVERSATION ON 06-19-2020

**Jeff Bergosh**: .....but I’m not sure about the star’s prison guards

### CONVERSATION ON 06-20-2020

**Jeff Bergosh**: No small six pack bottles so I’m buying another large blue machine

**Jeff Bergosh**: And we will get something done for the folks out there

### CONVERSATION ON 06-22-2020

**Jeff Bergosh**: Verification code

**Jeff Bergosh**: Y52-EW8.    Or Y52-EWS

That’s the best I can tell

### CONVERSATION ON 06-24-2020

**Jeff Bergosh**: He was going to map the printer for you

**Jeff Bergosh**: Are u at Corey?

### CONVERSATION ON 06-25-2020

**Jeff Bergosh**: 12 points up on Jesse

**Jeff Bergosh**: 28 points up on Underhill’s Secretary

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: Got the survey numbers back today

**Jeff Bergosh**: You’re up 64-36 over Brusso among the voters who are decided as of today

**Jeff Bergosh**: Got the survey back.  Here are the numbers for your race

**Jeff Bergosh**: We're going to replant any of the buffer that had to be cut in order to get the paving trucks out there to pave the road

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: On way home

**Jeff Bergosh**: Hi Jaron can you enter your time into your time sheet so I can approve it?

### CONVERSATION ON 06-29-2020

**Jeff Bergosh**: I'll send you the link/form

### CONVERSATION ON 06-30-2020

**Jeff Bergosh**: I understand

**Jeff Bergosh**: It comes with the territory

**Jeff Bergosh**: And as a current non-office holder ( Jesse, Jonathan, and Trotter) they can go in and sweep away any negative comments and ban users because they are not office holders

**Jeff Bergosh**: Or I would have done it long ago

**Jeff Bergosh**: Information moving slowly today.....

**Jeff Bergosh**: Gregory Testing site had 204 specimens collected yesterday. We are still waiting for the information from the department of health through CMR for the number tested at Ascension and UWF

**Jeff Bergosh**: Most of those are high res

**Jeff Bergosh**: Fire in D1 on Bauer Road and no response from Lillian Volunteer Fire Department??  Can you please get me a report on this with truthful information?  

### CONVERSATION ON 07-01-2020

**Jeff Bergosh**: I just found out my employee Jaron Kiger tested negative!

### CONVERSATION ON 07-02-2020

**Jeff Bergosh**: Good for them

**Jeff Bergosh**: It will pass 4-1

**Jeff Bergosh**: But this is a start!

**Jeff Bergosh**: LOL that’s right

**Jeff Bergosh**: He beat a lot of local firms out of money

**Jeff Bergosh**: I saw an attack flyer Greg Fink put out during Doug’s race with Gene and it detailed the creditors Doug stiffed in the bankruptcy

**Jeff Bergosh**: And I’m pretty sure NFCU took a $29K hit

**Jeff Bergosh**: And I think Gulf Coast Community Bank was a huge number—like several hundred grand

**Jeff Bergosh**: It will be brought back for discussion and to schedule it on the 16th

### CONVERSATION ON 07-03-2020

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2020/07/escambia-employee-salary-database-goes.html?m=1

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2020/07/escambia-employee-salary-database-goes.html?m=1

**Jeff Bergosh**: You'll like this Randy

**Jeff Bergosh**: William-- you'll like this........

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2020/07/escambia-employee-salary-database-goes.html?m=1

**Jeff Bergosh**: I'll re send

### CONVERSATION ON 07-06-2020

**Jeff Bergosh**: And I’ll get Debbie working the other direction on the meetings

### CONVERSATION ON 07-08-2020

**Jeff Bergosh**: Need access code

**Jeff Bergosh**: Just let me know, I have them safe

**Jeff Bergosh**: That’s fantastic!!

**Jeff Bergosh**: Your call went blank

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: I’d just deposit them in person this time!

**Jeff Bergosh**: Hey Nick-  call the Escambia Supervisor of elections office and request your absentee ballot for the primary election August 18th.

You can call them at 850-595-3900 and request it.  

Love-

Dad

**Jeff Bergosh**: Or you can request one online at 

Escambiavotes.com

**Jeff Bergosh**: Hey Nick I missed a call from you just making sure everything’s OK

**Jeff Bergosh**: You have a complete copy now of 2018 and 2019 returns

### CONVERSATION ON 07-10-2020

**Jeff Bergosh**: Need you To reschedule my 1115 with Scott Luth

**Jeff Bergosh**: You okay?

**Jeff Bergosh**: What's the press conference about?

**Jeff Bergosh**: That's how we did our coffees until we figured out how to go directly to Facebook on Zoom.  

### CONVERSATION ON 07-11-2020

**Jeff Bergosh**: And thank you for your support Tia!!

### CONVERSATION ON 07-12-2020

**Jeff Bergosh**: Yeah I did

**Jeff Bergosh**: But those residents had coverage, then had it taken away .  And then their ISO ratings went up along with their homeowners insurance rates

**Jeff Bergosh**: So they’re pissed at me

**Jeff Bergosh**: Disappointing

### CONVERSATION ON 07-13-2020

**Jeff Bergosh**: But dickhead Outzen will never let reality get in the way of a salacious headline

**Jeff Bergosh**: Particularly if Studer tells him to do it

**Jeff Bergosh**: Go look for yourself Mel 

**Jeff Bergosh**: Florida.hometownlocator.com.  Escambia county ZIP Codes and population by ZIP Code 32526 is nearly 40,000 residents triple the number of residents in Stevens district more than double Doug's district more than triple lumen's district. 8000 more residence than Roberts district. Rick Outzen and this article Is a dishonest fraud

**Jeff Bergosh**: Thx

### CONVERSATION ON 07-14-2020

**Jeff Bergosh**: Praying!!

**Jeff Bergosh**: Out of market are

**Jeff Bergosh**: I see it dropping big again

### CONVERSATION ON 07-15-2020

**Jeff Bergosh**: He says one more word about my family and I will

**Jeff Bergosh**: You can call

**Jeff Bergosh**: Hey Chorus the meeting abruptly ended so if you're out and about I can meet you somewhere in the next 15 minutes or so

### CONVERSATION ON 07-16-2020

**Jeff Bergosh**: You have $92.02 in your checking

**Jeff Bergosh**: Right on!!!! Congratulations!!

**Jeff Bergosh**: Who can be against us!?!

### CONVERSATION ON 07-17-2020

**Jeff Bergosh**: I ordered pizza for us— it’s in the way.  Come home boxer!!

**Jeff Bergosh**: *on the way

**Jeff Bergosh**: POS

**Jeff Bergosh**: Take a look at my blog

**Jeff Bergosh**: If I had school-age kids I would not be sending them back

### CONVERSATION ON 07-18-2020

**Jeff Bergosh**: As long as they don't use cursewords I always allow the comments

**Jeff Bergosh**: And I know that is offensive sometimes but that's what the first amendment is there to protect us all against the blowback from saying things that people do not like

**Jeff Bergosh**: Listen I don't agree with everything that gets posted on my blog believe me I don't

**Jeff Bergosh**: It's ugly sometimes like when mobs are burning the American flag calling for white people to be killed

**Jeff Bergosh**: I've been consistent for 12 years on that blog cursewords the N-word and stuff like that does not get posted but people call me all kinds of other names insinuate things about me or others and it gets posted

**Jeff Bergosh**: Otherwise I'm a hypocrite

**Jeff Bergosh**: And I'm not a hypocrite

**Jeff Bergosh**: Because I'm not a racist

**Jeff Bergosh**: But I will not apologize for being a white heterosexual Christian rule following law-abiding man in America today

**Jeff Bergosh**: Never will I apologize for that

**Jeff Bergosh**: It's not strictly white people that are racist

**Jeff Bergosh**: Remember just as many people think I'm bought and paid for which is equally ridiculous and also bullshit

**Jeff Bergosh**: I know the truth I know it's in my heart and I stick to my beliefs and I stick with the constitution

**Jeff Bergosh**: Fraud

**Jeff Bergosh**: Looks like it will be the week of the 24th

**Jeff Bergosh**: On way

### CONVERSATION ON 07-19-2020

**Jeff Bergosh**: It's about a double standard

**Jeff Bergosh**: That never happened

**Jeff Bergosh**: He's a big time Jonathan supporter in Beulah so that helps me;  he's ripping away Jesse Casey Supporters over to Jonathan's camp which works toward my favor.  So he can talk shit about me if he wants to--he's my tool, working in my interest to pry away Jesse votes to third-placer Jonathan--yet he's not bright enough to see it.  I'll deal with his libel/slander on August 19th on a separate track.  Again- thanks for pointing this out

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-20-2020

**Jeff Bergosh**: At Burger Factory

### CONVERSATION ON 07-21-2020

**Jeff Bergosh**: Please

**Jeff Bergosh**: She is bat-shit crazy

**Jeff Bergosh**: This is why I don’t go to that site

**Jeff Bergosh**: And you should not either

**Jeff Bergosh**: 😑

**Jeff Bergosh**: Ignore the hate

**Jeff Bergosh**: Love it

**Jeff Bergosh**: It’s on like Donkey Kong!

**Jeff Bergosh**: Your next post should be something like:    And how many federal state and ethics related lawsuits and complaints is the district to office up to now? I know it is more than any other commissioners office in the history of this county but what’s the actual number Wendy?

**Jeff Bergosh**: I overnighted it today— it will be there by 3:00

### CONVERSATION ON 07-22-2020

**Jeff Bergosh**: Fire!!

**Jeff Bergosh**: Sally I’m going to bed- 😩.  Love u!  Come home soon!!

**Jeff Bergosh**: He'll be red-faced and bent out of shape

### CONVERSATION ON 07-24-2020

**Jeff Bergosh**: "i'll be willing to discuss this issue with my counterparts and follow the most responsible course of action going forward. I expect a robust discussion on this topic at the next meeting."

### CONVERSATION ON 07-25-2020

**Jeff Bergosh**: https://www.thestar.com/entertainment/opinion/2020/07/24/evidence-suggests-ufo-whistleblower-bob-lazar-was-telling-the-truth-all-along.html

**Jeff Bergosh**: Here is the general flavor

### CONVERSATION ON 07-26-2020

**Jeff Bergosh**: Hey Brandon we’re gonna have a steak dinner tonight at 7 o’clock if you’re out and about and want to join us I’ve got one with your name on it!

### CONVERSATION ON 07-27-2020

**Jeff Bergosh**: Can’t find the email either

**Jeff Bergosh**: I would not expect too much to come from it though

### CONVERSATION ON 07-28-2020

**Jeff Bergosh**: What is your and Heather’s status/plans? Did you drive to South Carolina?

### CONVERSATION ON 07-29-2020

**Jeff Bergosh**: Debbie please send me the meeting log in for 4:30

**Jeff Bergosh**: Heading to bed.  Exhausted

### CONVERSATION ON 07-31-2020

**Jeff Bergosh**: He should check his email and show up to events!

**Jeff Bergosh**: By the way— we had a debate yesterday at Marcus Pointe and Jesse Casey pulled a no-show

**Jeff Bergosh**: That's the last thing I'll do.  Remember I don't like that guy, don't want to see or think of him

**Jeff Bergosh**: Just make it $200

### CONVERSATION ON 08-03-2020

**Jeff Bergosh**: Hi Mike- Jeff here— do you have a quick minute to chat so we can put the finishing touches on the card?

**Jeff Bergosh**: Hey Andrew-  our forum you're sponsoring tomorrow- it's at 5:30PM at fish house dock, right?  My calendar for some reason says 2:00-2:30??

**Jeff Bergosh**: Wow!  About that party and their plan!!wow!!

### CONVERSATION ON 08-04-2020

**Jeff Bergosh**: That’s why his handlers have him hiding in the basement and not filling out surveys and not taking part in these forums

**Jeff Bergosh**: That DOES NOT HAPPEN

**Jeff Bergosh**: call me and I’ll explain it

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: We are on break

### CONVERSATION ON 08-05-2020

**Jeff Bergosh**: U have like 600 in chi

**Jeff Bergosh**: Checking

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 08-06-2020

**Jeff Bergosh**: No need— I just got him sorted out

**Jeff Bergosh**: Who???

**Jeff Bergosh**: Who said that???

**Jeff Bergosh**: And stop following.  Liars that lie

**Jeff Bergosh**: They know they are losing so here come the lies

**Jeff Bergosh**: I’ll be winning on the poll that counts, in 12 days 🙂👌👍😎

**Jeff Bergosh**: Pray for me

**Jeff Bergosh**: I’ll forward you my contact person’s number.  Glad to hear you are up in the polls!!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: And then it comes back for the final vote

**Jeff Bergosh**: Fred--please forward your email so I can send you documentation regarding the subject of our discussion this morning

**Jeff Bergosh**: Staff Response to Mrs. Reeves

**Jeff Bergosh**: No mention of any pool, nothing at all.  It was all a conversation about a fence repair and we gave the correct answer-- which I sent above

**Jeff Bergosh**: I'm in a BCC meeting I will call you back

### CONVERSATION ON 08-07-2020

**Jeff Bergosh**: Think on that

**Jeff Bergosh**: You appear to be incapable of disagreement without personalization be careful with that

**Jeff Bergosh**: Yes or no?

**Jeff Bergosh**: It's not good

**Jeff Bergosh**: When I was concerned with a spike and was going to lead the effort to initiate an ordinance via an emergency meeting—— I wrote an ordinance that had specifics and it took effort, it was time intensive but I had a plan ready to go.  I like Lumon, but that effort was lazy;  no plan

**Jeff Bergosh**: Heather/Tim — need you to put your time into the electronic timesheet so I can approve them

### CONVERSATION ON 08-14-2020

**Jeff Bergosh**: Larry- here is the script in case you didn’t get the email.  Let me know what you think

Thanks,

Jeff Bergosh 

### CONVERSATION ON 08-15-2020

**Jeff Bergosh**: This just came in my mail

### CONVERSATION ON 08-16-2020

**Jeff Bergosh**: If not, they'll get Jesse Casey and his sophisticated, intelligent approach

**Jeff Bergosh**: Thanks Phil

### CONVERSATION ON 08-17-2020

**Jeff Bergosh**: Plus, she has no audience, zilch.  Just her echo chamber of hate that already hate me LOL

**Jeff Bergosh**: He's not involved in my race is he??

**Jeff Bergosh**: On my site 

**Jeff Bergosh**: But notoriously no Facebook posts from him and no Robo call but he said he would do but dodged me

**Jeff Bergosh**: So maybe he is playing both sides he probably is

**Jeff Bergosh**: Here’s my prediction

**Jeff Bergosh**: Here’s the card for you to use for your visit today.  It’s a flexible spending account card

**Jeff Bergosh**: This candidate is so far behind it won’t help him it will only cut into Jessie’s lead so it actually helps me.

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Surrogates

**Jeff Bergosh**: Jonathan drove through and left

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: I have four more to go Windy Hill Baptist Church Pine Summit Baptist Church the interstate Fairgrounds and Charity Chapel

**Jeff Bergosh**: Maybe in 51 months he can try again LOL.  Until then, he’s relegated to being Doug’s coffee fetcher and errand boy

### CONVERSATION ON 08-20-2020

**Jeff Bergosh**: We went to Sobelmans!

### CONVERSATION ON 08-22-2020

**Jeff Bergosh**: What’s the name of the restaurant we’re meeting at tonight at 6:30?

**Jeff Bergosh**: Is it View MKE?

**Jeff Bergosh**: �

**Jeff Bergosh**: Tori we are out front

**Jeff Bergosh**: Waiting on you

### CONVERSATION ON 08-25-2020

**Jeff Bergosh**: Subaru wanted twothousand down and the best deal they could do was 290 a month— Toyota Tercel was about the same

**Jeff Bergosh**: This deal here is no money down just the trade and $270 month

### CONVERSATION ON 08-26-2020

**Jeff Bergosh**: So make sure to let them know to change the ad

**Jeff Bergosh**: How is your neck?  Did the visit help to ease the pain?

### CONVERSATION ON 08-27-2020

**Jeff Bergosh**: I’m having this picture cartoon framed so that it can be placed outside of our office! LOL

**Jeff Bergosh**: ......of course you know it’s based upon what Doug has hanging on his wall.......

**Jeff Bergosh**: Just remember you’ll be getting $200 back via this check— just come by and pick it up and deposit it.  Once u do, it will mean you are out of pocket just $798.17——which is not bad all things considered.  And if the ambulance takes the insurance information I just gave them, I’ll refund that back to you as well.  We will know that in about 30 days.  

Love, Dad

**Jeff Bergosh**: Had a 1:00 I could  not get out of

**Jeff Bergosh**: They wasted too much time this morning grandstanding and bullshitting I don't have that kind of time for those shenanigans

**Jeff Bergosh**: And they schedule this thing last minute remember that

**Jeff Bergosh**: And I did adjust my schedule to give three hours to a two item agenda

### CONVERSATION ON 08-28-2020

**Jeff Bergosh**: You can use it!!

### CONVERSATION ON 08-29-2020

**Jeff Bergosh**: Brandon I bought your airline ticket to San Diego for Christmas let me know as soon as possible if you can make those dates December 21 leaving coming back January 5

**Jeff Bergosh**: Hey Brandon are u there?

**Jeff Bergosh**: We sent this check today

### CONVERSATION ON 09-01-2020

**Jeff Bergosh**: BTW— they fixed my truck under the warranty😎😎👍👍

**Jeff Bergosh**: 😎

**Jeff Bergosh**: And that’s great news because he was never the right guy and he’s not qualified

### CONVERSATION ON 09-02-2020

**Jeff Bergosh**: Tony I spoke with John via text this morning about flowers and a card. And here was his response..

So it looks like she would not have wanted flowers I guess.

-Jeff B

**Jeff Bergosh**: So we had a long face to face meeting about it Monday in my office and she knows I’m pissed off

**Jeff Bergosh**: Then I sent her this as a follow up

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: Can’t do it rn though

**Jeff Bergosh**: Don’t worry though by the time they decide whether or not they’re going to do it it will be 10 years from now

**Jeff Bergosh**: Yeah Doug no material for him!

**Jeff Bergosh**: They look wonderful on golf beach highway😎😎👍👍

**Jeff Bergosh**: They are squeezing out the commerce park

**Jeff Bergosh**: By the way—- did the state DOH exonerate you from Edler’s claims?

**Jeff Bergosh**: Matt

**Jeff Bergosh**: Ha ha that’s great.  That’s table she’s under is the bargaining table—- we’re in negotiations for their contract right now.  Bunch of stupid Fucks that picked the wrong candidate to bash

**Jeff Bergosh**: And I’m here for the next 50 months

### CONVERSATION ON 09-04-2020

**Jeff Bergosh**: I'll let you know as soon as we do that one

**Jeff Bergosh**: Tim- need you to enter your time in the online portal

**Jeff Bergosh**: Mike:  Supervisor of Elections finally released precinct by precinct results:  I won 12 out of 14 precincts.  And I won BOTH Beulah precincts 😎👍👌.  Online haters will have a tough time dealing with this reality as they ALL were certain I’d get beat in Beulah where I live....

### CONVERSATION ON 09-08-2020

**Jeff Bergosh**: Like a horror show monster

**Jeff Bergosh**: Where r u?

**Jeff Bergosh**: For several more hours

**Jeff Bergosh**: Is Sara there too?

**Jeff Bergosh**: R u parked in my space?

**Jeff Bergosh**: This might be wrapping up if u need a ride

**Jeff Bergosh**: *ju-horsy

**Jeff Bergosh**: *autocorrect will not let me truly or ju-jitsu 

**Jeff Bergosh**: Thx for heads up

**Jeff Bergosh**: And I’m working the speed bump issue

### CONVERSATION ON 09-09-2020

**Jeff Bergosh**: Debbie— please forward the emails (staff assessment) for today’s TPO meeting to my gmail account

**Jeff Bergosh**: Should be a couple of them from Christine Franxhi

**Jeff Bergosh**: Please send the one from earlier in the morning

**Jeff Bergosh**: The one from 5:39 pm yesterday I meant

**Jeff Bergosh**: Did u send the one from yesterday?

**Jeff Bergosh**: I’ll be off at 12:45

### CONVERSATION ON 09-10-2020

**Jeff Bergosh**: Otherwise they would list a phone number

**Jeff Bergosh**: Separate issue

**Jeff Bergosh**: I thought you were talking about the 9 mile road project

### CONVERSATION ON 09-11-2020

**Jeff Bergosh**: John not trying to be a pain in the ass but I just had to send it back to you for correction. You put in your time as regular time when it should be PTO. Please go ahead and fix it and resubmit it and then I'll approve it thank you

### CONVERSATION ON 09-15-2020

**Jeff Bergosh**: Press conference in 3 minutes at EOC Facebook site

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: Test

**Jeff Bergosh**: Tony-- we ended up taking a hard hit to the Pensacola area.  I've not heard anything about NASP other than they took a hard hit as well.  My house is okay but I have three big trees down and LOTS of cleanup ahead.  I group texted everyone from the office this morning.  Authorities have ordered a shelter in place, all major bridges are out and there are  lots of road closures-- so not sure what ability to work looks like yet for tomorrow... I'll keep you posted.

**Jeff Bergosh**: Tony-- we ended up taking a hard hit to the Pensacola area.  I've not heard anything about NASP other than they took a hard hit as well.  My house is okay but I have three big trees down and LOTS of cleanup ahead.  I group texted everyone from the office this morning.  Authorities have ordered a shelter in place, all major bridges are out and there are  lots of road closures-- so not sure what ability to work looks like yet for tomorrow... I'll keep you posted.

**Jeff Bergosh**: All--- I just spoke to Mark Powell and the power is out to most of the base the front gate is secured and the Loveless bridge is not passable according to him. Apparently it was hit by a barge too- just like the 3 mile bridge. back gate is secured. they're working on a third way in ---apparently there's a third gate behind the airfield but I don't know where that is. The county will be implementing dusk to dawn curfews as we have reports of looting and lots of flooding lots of roads closed lots of trees down. The NMCI network is down and Mark will call me tomorrow and let me know if building 458 has power or whether or not the PBSS network is up.  Please shoot me an individual text to let me know if you are alright, whether or not you have power, and how your house fared in the storm.  I will be speaking with Tony soon to determine work schedules for us going forward.  

**Jeff Bergosh**: All--- I just spoke to Mark Powell and the power is out to most of the base the front gate is secured and the Loveless bridge is not passable according to him. Apparently it was hit by a barge too- just like the 3 mile bridge. back gate is secured. they're working on a third way in ---apparently there's a third gate behind the airfield but I don't know where that is. The county will be implementing dusk to dawn curfews as we have reports of looting and lots of flooding lots of roads closed lots of trees down. The NMCI network is down and Mark will call me tomorrow and let me know if building 458 has power or whether or not the PBSS network is up.  Please shoot me an individual text to let me know if you are alright, whether or not you have power, and how your house fared in the storm.  I will be speaking with Tony soon to determine work schedules for us going forward.  

**Jeff Bergosh**: All--- I just spoke to Mark Powell and the power is out to most of the base the front gate is secured and the Loveless bridge is not passable according to him. Apparently it was hit by a barge too- just like the 3 mile bridge. back gate is secured. they're working on a third way in ---apparently there's a third gate behind the airfield but I don't know where that is. The county will be implementing dusk to dawn curfews as we have reports of looting and lots of flooding lots of roads closed lots of trees down. The NMCI network is down and Mark will call me tomorrow and let me know if building 458 has power or whether or not the PBSS network is up.  Please shoot me an individual text to let me know if you are alright, whether or not you have power, and how your house fared in the storm.  I will be speaking with Tony soon to determine work schedules for us going forward.  

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: Hi Mark looks like I missed three calls from you I was in the shower just attempting to call you back and I’ll try again in a few minutes

**Jeff Bergosh**: The Kia payments with no money down for brand new 2020 cars were $265-270 per month.

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: They’re coming at 2:30 to give me a quote

**Jeff Bergosh**: Everyone was able to submit their time sheets remotely with the exception of Gary and Dave Midgorden

**Jeff Bergosh**: Jaron and I just entered our time as normal as there was no admin slot for us to enter these hurricane hours

**Jeff Bergosh**: Monday is going to be a workday I am assuming and we will figure out what we can do under the circumstances and conditions that are here on Monday

**Jeff Bergosh**: Hopefully we can get some of this water extracted before the mold and mildew gets really bad that's what concerns me and also the cracks in the second-floor concrete we can discuss when you call me back

**Jeff Bergosh**: Did u try it from your iPhone?

**Jeff Bergosh**: So we will postpone just take it week by week until everyone gets recovered from the storm look forward to getting back out there again when things are back to normal

Jeff B

### CONVERSATION ON 09-19-2020

**Jeff Bergosh**: Wes here is a Facebook PM I got and it may be something your Gulf Power contact could provide an assist with-- can you please check into this issue as well?  Thanks so much!

**Jeff Bergosh**: Can you send me a list of the feeding locations where we're going to set up the pods?

**Jeff Bergosh**: Also can you send me the information about the Red Cross hot meal distribution in District one at the equestrian center?

### CONVERSATION ON 09-20-2020

**Jeff Bergosh**: All----We are working tomorrow— we will have a meeting and Tony will call in and we will determine our schedules going forward based upon our facility condition and our ability to access our networks, emails, internet, etc.  0730 staff meeting.  If anyone knows they cannot make it tomorrow and that they need to take PTO for Monday ---let me know by texting or calling me.  Otherwise I'll see you all tomorrow.

### CONVERSATION ON 09-21-2020

**Jeff Bergosh**: I’ve just emailed you something important take a look

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: I have PBSS structures personnel here securing the side door that was damaged and blown open, housekeeping is here doing routine cleaning, Ira and I both walked PBSS Safety Manager Gerald Flint through our spaces to show him areas of water intrusion and also the structural concrete cracks in the second deck. I've asked him about our carpets he's going to look into that and also there's a lot of water pooled on the roof that is not draining and he will look at that as well. Our entire staff is here everyone is good the planner and estimator function can continue most of what we do can happen it's just that we have no network access nor do we have email or printer capabilities but we will limp along. 

**Jeff Bergosh**: Hey Steve did you all get mail today?  They didn't deliver my mail just wondering if you got mail

### CONVERSATION ON 09-22-2020

**Jeff Bergosh**: Are you able to do that today?

### CONVERSATION ON 09-23-2020

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-24-2020

**Jeff Bergosh**: Debbie please forward Syd’s telephone number and information from this text message string to Joy Jones and West Marino so that they can ascertain who is responsible for cutting these trees down I’m hoping someone can make contact with Mr. car and put eyes on this situation thank you

**Jeff Bergosh**: Call me

**Jeff Bergosh**: I’m making red beans and rice and bratwurst for dinner😎👍

**Jeff Bergosh**: Leftovers in fridge, I’m heading to bed—bible study first thing in the mooring.   Love you❤️❤️

### CONVERSATION ON 09-25-2020

**Jeff Bergosh**: Sally —-share this video with your friends at tennis this morning. This is what lunatics look like when they find out Trump is going to appoint a third supreme court justice :-)

(there is some choice language in there)

**Jeff Bergosh**: You have $403 in checking before your check even gets deposited

**Jeff Bergosh**: Just imagine what her reaction might be if Trump wins on November 3?

**Jeff Bergosh**: https://wdtprs.com/2020/09/video-unhinged-karens-spittle-flecked-obscenity-laced-nutty-on-hearing-that-justice-ginsberg-died-language-warning/

**Jeff Bergosh**: New information:



**Jeff Bergosh**: I'd like to see it before it is sent though 

**Jeff Bergosh**: Looks good to me-- please include my signature!

### CONVERSATION ON 09-28-2020

**Jeff Bergosh**: Mark Faulkner Janice and Eric Gilmore

**Jeff Bergosh**: For the 7th

### CONVERSATION ON 09-29-2020

**Jeff Bergosh**: I’m at front door

**Jeff Bergosh**: ???

**Jeff Bergosh**: This exchange from Brandon’s roommate Brandon just now

**Jeff Bergosh**: Is Brandon in a room— has he been seen yet?  

**Jeff Bergosh**: I drove his roommate back home

**Jeff Bergosh**: Can you talk?

**Jeff Bergosh**: ???

**Jeff Bergosh**: Where r u guys??

**Jeff Bergosh**: We got moved to a different location

**Jeff Bergosh**: I’m in the padded cell area now with people freaking out

**Jeff Bergosh**: In Mom’s car

**Jeff Bergosh**: He’s been taken back

### CONVERSATION ON 09-30-2020

**Jeff Bergosh**: Just called 5- sisters.  It just rang and rang.  I’ll call back at 11:00 when they open

**Jeff Bergosh**: I called five sisters Inn spoken to Chris the manager and he had great things to say about Brandon was totally understanding and he’s going to clear the schedule for a couple days and wish to Brandon all the best and said just have him call when he’s feeling better and will get them right back on

**Jeff Bergosh**: I told him to call me when he’s released and I’ll get him.  I told him how much we love him and how concerned we are about him

**Jeff Bergosh**: Hi Brandon, I’m heading your way with Brandon’s part of the rent.  Will you be at the apartment at 5:00?  That’s what time I’ll be there approx

### CONVERSATION ON 10-01-2020

**Jeff Bergosh**: He said the doctor said it’s up to you and I whether or not he can come home.  Sounded very sad

**Jeff Bergosh**: Coming home now

**Jeff Bergosh**: Did he ever return your call Nick!

**Jeff Bergosh**: Tori are u at the house?

**Jeff Bergosh**: ....but I hate it for them

**Jeff Bergosh**: Any update?

**Jeff Bergosh**: While I’m getting my ass kicked every day by citizens that are pissed off...............at FDOT

### CONVERSATION ON 10-02-2020

**Jeff Bergosh**: Debbie please call this lady she has multiple issues on Muldoon Road and outside of her subdivision with debris that’s blocking the roadway creating unsafe driving conditions can you please speak with her and get the precise details and pass to staff?

**Jeff Bergosh**: Her home number is 850-453-5099

### CONVERSATION ON 10-03-2020

**Jeff Bergosh**: I’ll come home immediately if necessary

**Jeff Bergosh**: Two things:

I think he needs focus meds again for daytime:  adderal 

I would like to get Dr sampalli for his Dr

**Jeff Bergosh**: And we should probably consider hiding the booze in the house for a period of time too

**Jeff Bergosh**: We won 1st set tie-breaker 6-6(7-1)

### CONVERSATION ON 10-04-2020

**Jeff Bergosh**: Great throw

### CONVERSATION ON 10-05-2020

**Jeff Bergosh**: Kassabian appointment Friday at 3:50—- earliest time they had after they get records from Baptist Hospital

**Jeff Bergosh**: Do you think it’s in the laundry?  Did you wash a load of darks and could it have been in his pants pocket?

**Jeff Bergosh**: ???

**Jeff Bergosh**: Did you look in your car yet for Brandon’s wallet?  Is it in the back seat?  

**Jeff Bergosh**: Where did you have it last?

**Jeff Bergosh**: Tim/Heather— I need your hard-copy timesheets.  Please print them out and put them in my inbox

**Jeff Bergosh**: Janice:  can you give peg David a call?  She is the Nature Trail HOA President and she's trying to coordinate debris removal and is running into a brick wall with having her residents' debris removed to the OLF 8 field 

### CONVERSATION ON 10-06-2020

**Jeff Bergosh**: Call Gene Hall first thing in the morning to discuss amendment for and help him understand what it means

**Jeff Bergosh**: Call Gene Hall first thing in the morning to discuss amendment for and help him understand what it means

### CONVERSATION ON 10-07-2020

**Jeff Bergosh**: Judith jarman  850-944-1567

**Jeff Bergosh**: Judith jarman  850-944-1567

### CONVERSATION ON 10-08-2020

**Jeff Bergosh**: She’ll be back at 11:00

**Jeff Bergosh**: *super important

### CONVERSATION ON 10-09-2020

**Jeff Bergosh**: From the house right?

### CONVERSATION ON 10-11-2020

**Jeff Bergosh**: I’m at your old stomping grounds scenic Hills

**Jeff Bergosh**: Thanks for taking a good clubs and leaving me the third stringers LOL

### CONVERSATION ON 10-12-2020

**Jeff Bergosh**: Nice!!!!

**Jeff Bergosh**: Hi Jennifer thanks for interviewing me earlier this afternoon.  I wanted to let you know that I published the complete report and poll that I referenced in our interview on my blog. please feel free to link it in your report if you feel it would be helpful.  It has some really interesting eye-opening statistics and facts about what people really want on that field!😎👍

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: Are u off the call?

### CONVERSATION ON 10-14-2020

**Jeff Bergosh**: But later we’re going to play tennis.  Do you want to join us?

**Jeff Bergosh**: Okay 5:00 at UWF -//Tori and I will meet you at UWF for tennis.  I have an extra racquet for you to use.

**Jeff Bergosh**: Call the clinic, you volunteered there yesterday and maybe you left it there

**Jeff Bergosh**: Also:  you had it at the clinic last night, so did u go anywhere after that?

**Jeff Bergosh**: Mom saw I put her card in your wallet last night

**Jeff Bergosh**: Or go there

**Jeff Bergosh**: Liked “Found it!!!”

**Jeff Bergosh**: Your Girl Sarah Peacock called this morning and needs my “help” with an issue in Beulah.  Thought you’d find that to be interesting 😁

**Jeff Bergosh**: FYI

**Jeff Bergosh**: Hi Brandon do you have a minute to talk?

Thanks,

Jeff Bergosh

### CONVERSATION ON 10-15-2020

**Jeff Bergosh**: You’ll be happy to know that I put a plug in today at the meeting for Health and Hope clinic and the flu shot event Saturday morning! 😁👍

### CONVERSATION ON 10-16-2020

**Jeff Bergosh**: Good Morning Brandon— here is a copy front and back of the insurance ID card.  You may need to show the receptionist this before your appointment this morning at West Florida Hospital at 10:30

**Jeff Bergosh**: Can u talk?

### CONVERSATION ON 10-21-2020

**Jeff Bergosh**: And I blind copied you on a request I just sent to planning staff.  I think these people on the Beulah Scoop are full of shit.  I’ll get the proof from staff this morning in it

**Jeff Bergosh**: Tennis today at 5:00??  If yes, where?

Love you!

### CONVERSATION ON 10-23-2020

**Jeff Bergosh**: ✅ done

### CONVERSATION ON 10-26-2020

**Jeff Bergosh**: Look— I was just checking to see if you got it that’s all

### CONVERSATION ON 10-27-2020

**Jeff Bergosh**: This is what Chris Edmonson sent to the Government:  that we’re not responding to his repeated calls on 10-14 and again on 10-21

**Jeff Bergosh**: Can you send him your sponsorship package?

**Jeff Bergosh**: I just got off the phone with him and I believe they will do a sponsorship :)

### CONVERSATION ON 10-28-2020

**Jeff Bergosh**: *fifth cent on the bed tax

**Jeff Bergosh**: Plus Brandon comes at six so I don’t really want us drinking in front of him ——-so get here soon so you can have some drinks before he gets here LOL.....Otherwise the bar closes at 10 till six

### CONVERSATION ON 10-30-2020

**Jeff Bergosh**: I need you to enter your timesheet thx

**Jeff Bergosh**: Hey Nick— are you in class rn?

### CONVERSATION ON 10-31-2020

**Jeff Bergosh**: Call them

**Jeff Bergosh**: I got the front decorated so hurry home so we can go vote love you!!

**Jeff Bergosh**: Hello??

**Jeff Bergosh**: Sally Tori and I are just gonna go ahead and vote I’m going to give you the address so you can meet us there but we need to be back here before it’s dark because the trick-or-treaters will start coming and we want to be here when that happens.

**Jeff Bergosh**: Here’s the address where you can early vote up until 7 o’clock tonight

**Jeff Bergosh**: 6675 Pine Forest Road Suite 11

**Jeff Bergosh**: Hey Nick me and mom just transfer the 750 into your checking account love you hope all is going well

### CONVERSATION ON 11-02-2020

**Jeff Bergosh**: Need to figure this out ASAP

**Jeff Bergosh**: .... then I’ll fill it up from there :)

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Although Sally wants us to go by Michelle’s party

**Jeff Bergosh**: It’s a tough nasty business we are in

**Jeff Bergosh**: Sally— look at this basic (back of the bar napkin) idea of the before and after kitchen....is this sort of, kind of what you’re thinking?

### CONVERSATION ON 11-04-2020

**Jeff Bergosh**: Thought it sounded familiar

**Jeff Bergosh**: ......plus the mortgage

**Jeff Bergosh**: Do you have a PBSS cell phone?  Need to know yes or no ASAP.  If yes— text me the number

### CONVERSATION ON 11-05-2020

**Jeff Bergosh**: Call me when you get a minute — wanted to tell you what happened with Connie Bookman at this morning’s meeting.  Love u!!

### CONVERSATION ON 11-06-2020

**Jeff Bergosh**: I’m donating 2500 to this organization from my discretionary— I thought you might like the way they’ve designed their return envelope on the inside it gives options for recurring sponsorship which I think is pretty nifty

**Jeff Bergosh**: I see Donovan did a 1,000.00 sponsorship— that’s pretty cool!

### CONVERSATION ON 11-10-2020

**Jeff Bergosh**: I spoke to Megan

**Jeff Bergosh**: She needs a referral sent from Dr. Kassabian’s office.  It can be faxed, attn Megan, to 850-439-2122

**Jeff Bergosh**: They need 

- formal referral
- medical history
- most recent progress notes

**Jeff Bergosh**: They are accepting patients but are currently on a wait list

### CONVERSATION ON 11-12-2020

**Jeff Bergosh**: Also-- did Edler prescribe Hopkins medicine?

**Jeff Bergosh**: And finally-- was it hoopaugh that got the promotion that Matt Selover should have received?

**Jeff Bergosh**: In checking

**Jeff Bergosh**: $41,464.03.  In savings. 😎👍

**Jeff Bergosh**: ❤️

### CONVERSATION ON 11-15-2020

**Jeff Bergosh**: 	17.	 33-34.  Or. 17.   34-35


**Jeff Bergosh**: 	17.	 33-34.  Or. 17.   34-35


### CONVERSATION ON 11-17-2020

**Jeff Bergosh**: I’ll be there

**Jeff Bergosh**: Meeting at office first to drive Gary and Carissa there

**Jeff Bergosh**: I’ll send you the link

**Jeff Bergosh**: —my remarks are brief 

**Jeff Bergosh**: https://www.facebook.com/esccounty/videos/839896553452711/

### CONVERSATION ON 11-18-2020

**Jeff Bergosh**: This is what she sent me this morning

### CONVERSATION ON 11-19-2020

**Jeff Bergosh**: I’ll try hi again

### CONVERSATION ON 11-20-2020

**Jeff Bergosh**: Lincoln Project = a bunch of shithead, liberal Republicans.

**Jeff Bergosh**: R u on way?

**Jeff Bergosh**: .....or the trust can ramp up slowly as revenues permit.  My understanding is that there millage Levi will produce roughly $10 million annually so money will not be the issue so far as I could tell

**Jeff Bergosh**: * their.  *levy

### CONVERSATION ON 11-23-2020

**Jeff Bergosh**: Hey— I just sent you the .jpegs and I’m working on the PowerPoint ❤️😎👍

**Jeff Bergosh**: I just sent you the 2020 Christmas at the Clinc PowerPoint

**Jeff Bergosh**: The next thing we need to have is the projector so I can do a practice run before next Monday.

**Jeff Bergosh**: 😁

### CONVERSATION ON 11-24-2020

**Jeff Bergosh**: Can you get a status on this from staff please—— 
Mr. McSwain— 7608 Woods Lane— needs the road department to bring some more gravel out to this road.  968-6076

### CONVERSATION ON 11-27-2020

**Jeff Bergosh**: K

**Jeff Bergosh**: You saved your timesheet— need you to submit it

**Jeff Bergosh**: That’s sketchy!!

**Jeff Bergosh**: Could collapse,  where is that?

**Jeff Bergosh**: I’ve got Marty’s speech and the spreadsheet tabs printed out.  Do you want me to 3-hole punch Marty’s Speech/script so it can be put into a binder for him?

**Jeff Bergosh**: Political Correctness

### CONVERSATION ON 12-01-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 12-02-2020

**Jeff Bergosh**: Dave-  just let me know your status when you can.  I’m assuming you are simply sick and that no news is good news with respect to your COVID-19 test.  But by all means let me know if I am wrong and also how you’re doing and when you’ll be back.  Thanks!

Jeff B

### CONVERSATION ON 12-03-2020

**Jeff Bergosh**: Having a hard tome finding one who is accepting new patients though

**Jeff Bergosh**: Dave, what is your status?  

### CONVERSATION ON 12-04-2020

**Jeff Bergosh**: Hey Brandon where r u? 

**Jeff Bergosh**: Heather the FY20 open work order report you sent me today was from October 24th

### CONVERSATION ON 12-09-2020

**Jeff Bergosh**: Then we can forward the exact specifications to the woodsman

**Jeff Bergosh**: Also:  here’s the card for Christmas.  There’s $2,000.00 available on it.  The only thing I want for Christmas is a sonicare toothbrush flosser combo

**Jeff Bergosh**: Will try again

**Jeff Bergosh**: 1201 W. HERNANDEZ ST Pensacola, FL., 32501

3:00 PM today with Dr. Sompalli

### CONVERSATION ON 12-10-2020

**Jeff Bergosh**: Debbie— can you check on the status of my computer?  

**Jeff Bergosh**: He won't be told no

**Jeff Bergosh**: Very poor form

### CONVERSATION ON 12-14-2020

**Jeff Bergosh**: Hey I’m starting to wind down— had a really productive day.  Are you headed home soon?  Love you!

### CONVERSATION ON 12-15-2020

**Jeff Bergosh**: And yes just for the file and for the sake of keeping the paperwork straight you might want to do that and bring the announcements as well

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: They definitely won’t print one without the headshot

**Jeff Bergosh**: I’ve got them bundled up a certain way with zip ties and I just don’t want Brandon up there messing with them I’ll do it myself

**Jeff Bergosh**: Just tell Sharon I’ll bring them by as soon as I get off of work tonight as many as she wants

**Jeff Bergosh**: Alright I’m heading to bed.  Love u!!

**Jeff Bergosh**: It’s Southwest

**Jeff Bergosh**: Should I give PBSS a courtesy heads up?

**Jeff Bergosh**: Hi Sharon I just spoke to my brother and as a Judge in the state of Florida he can marry Seth and his fiancée---and he will be here and is available to do it.  But you all have to get a marriage license for him to do it.  His cell phone number is 850-698-8094

### CONVERSATION ON 12-17-2020

**Jeff Bergosh**: 👍

**Jeff Bergosh**: What’s the name of that paint again?

**Jeff Bergosh**: What he asked me to do is to go by Home Depot and get paint sample sticks of light beige and then to compare them to the beige in our dining room and then just tell him what the paint code is and he’ll pick up that paint too

**Jeff Bergosh**: Janice:  please forward me an electronic copy of Keith's report that we discussed yesterday afternoon.  Thank you

### CONVERSATION ON 12-18-2020

**Jeff Bergosh**: Tim/Heather please put your electronic timesheet in the system ASAP— corporate is trying to get them in by 10:30

**Jeff Bergosh**: Heather—. Please create an executable for this job.  It is coming through on my NMCI account but I cannot forward it to PBSS system—-not going through.  Phil requests completion by Tuesday, 12-22

**Jeff Bergosh**: Disregard— it just came through so I’ll forward it

### CONVERSATION ON 12-19-2020

**Jeff Bergosh**: Saw these at Lowe’s—-similar time what we will have

**Jeff Bergosh**: Hard to Kill is a good one too

**Jeff Bergosh**: ......Then they just started getting ridiculous

**Jeff Bergosh**: He has a small role in executive decision which is really good to

### CONVERSATION ON 12-22-2020

**Jeff Bergosh**: Tell Tori she forgot her phone but we have it— it’s here at the house

### CONVERSATION ON 12-24-2020

**Jeff Bergosh**: https://decisionmagazine.com/appeals-court-pensacola-cross-can-remain-on-public-property/

### CONVERSATION ON 12-25-2020

**Jeff Bergosh**: Dave— I hope you and your family have a very Merry Christmas and a Happy New Year!  When you have a moment— I need you to enter your time in the electronic timesheet and submit it, so I can approve it.  Thanks Dave!

### CONVERSATION ON 12-26-2020

**Jeff Bergosh**: No drive through 

**Jeff Bergosh**: So it will be a minute

**Jeff Bergosh**: I’ve never seen a place this busy!!!

**Jeff Bergosh**: Nobody in the lobby has been served yet

### CONVERSATION ON 12-28-2020

**Jeff Bergosh**: I got tortilla chips and four great movies— heading back up the hill right now

**Jeff Bergosh**: I got tortilla chips and 4 good movies including “Tenet”

**Jeff Bergosh**: Heading back home rn

**Jeff Bergosh**: I got tortilla chips and 4 good movies including “Tenet”

**Jeff Bergosh**: Heading back home rn

### CONVERSATION ON 12-31-2020

**Jeff Bergosh**: .... why is the county being saddled with this cost at the 11th hour and 59 th minute?  Like Insaid on channel 3:  it's sloppy and choppy

**Jeff Bergosh**: Warren you also have to fill out your time sheet for just one day on the  1st of January

**Jeff Bergosh**: And then submit it

### CONVERSATION ON 01-01-2021

**Jeff Bergosh**: You missed a beautiful sunset!

### CONVERSATION ON 01-02-2021

**Jeff Bergosh**: https://californiathroughmylens.com/biking-coronado-island

**Jeff Bergosh**: That’s where we’re going later this morning!!

**Jeff Bergosh**: I just received and approved the quote for the work from selectricity 

**Jeff Bergosh**: Quote was high at $3,110.  Does that seem reasonable to you?  

### CONVERSATION ON 01-04-2021

**Jeff Bergosh**: Guess who just got her official offer letter for the ER?! 👏🏼👏🏼🥰

### CONVERSATION ON 01-05-2021

**Jeff Bergosh**: Or I could call now

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: I’ll be home after

**Jeff Bergosh**: Can you amend this Sacred Heart contract to indicate the total allotment of $3.5Million is not exclusive to Sacred Heart and that sacred heart is not the exclusive agent for vaccination in Escambia County?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I never want to be confused with D2

**Jeff Bergosh**: I’ve asked the attorney to modify the contract that we will approve tonight to indicate that the 3.5 million is the total pool of dollars available and that it is not exclusively for sacred heart Hospital but for any county approved licensed provider to draw down upon. This will not slow down sacred heart or community Health Barrasso makes very clear that we are not giving exclusive sole source contract to one hospital over the other two

### CONVERSATION ON 01-08-2021

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: Got 4 hrs sleep

**Jeff Bergosh**: *patting

**Jeff Bergosh**: I personally think the rollouts been a disaster. They should've distributed these just like they do the flu shots and let everyone give them

**Jeff Bergosh**: Instead it's political favoritism cronyism and the average guy gets stuck in the back of the bus

**Jeff Bergosh**: How are you doing Brad?  Are you out of the hospital?  Sally and I are keeping you in our prayers for a speedy and complete recovery!!🙏🙏🙏

### CONVERSATION ON 01-11-2021

**Jeff Bergosh**: Will call u right after

### CONVERSATION ON 01-12-2021

**Jeff Bergosh**: Also, this came in the mail for you.....

**Jeff Bergosh**: I’m trying to activate AT&T right now they may be calling you for confirmation

**Jeff Bergosh**: So make sure you answer your phone

**Jeff Bergosh**: Love u!!

**Jeff Bergosh**: Nvm

**Jeff Bergosh**: Hey Brad— give me a call when you can.I’m hoping that you are feeling better and that you’re out of the hospital but I’ve been thinking about you give me a call let me know that you’re all right. Jeff

### CONVERSATION ON 01-13-2021

**Jeff Bergosh**: Today on my walk I’m listening to the greatest hits of Journey and Bryan Adams ——and even though it’s cold the sun is shining and I’m smiling from ear to ear! Love you!!

### CONVERSATION ON 01-14-2021

**Jeff Bergosh**: Yeah but I’m not gonna give her a pass. She goes on their passive aggressively and says all four of my tires had to be replaced because of this. That’s a fucking lie

**Jeff Bergosh**: And if she has really got that bad of a lucky streak going she needs to not be a cheapskate and when she buys her tires she needs to fucking buy the road hazard warranty!!

**Jeff Bergosh**: Her and “Denise Watson”.  Two haters of mine that live in BRF

**Jeff Bergosh**: Hey Brad!  I sure hope you are alright.  Sally and I are worried about you—-we’re hoping you are only having phone issues.... anyway— call or text me back to let me know you are okay.   Look forward to talking to you soon!

**Jeff Bergosh**: In mtg will call back

### CONVERSATION ON 01-15-2021

**Jeff Bergosh**: BTW— I’ve confirmed Brad is still alive but he is still hospitalized in Redlands.  He’s on oxygen fighting for his life.  This picture is from a week ago Wednesday.

### CONVERSATION ON 01-18-2021

**Jeff Bergosh**: How are u doing Nick?!?

**Jeff Bergosh**: ........and unnecessary

**Jeff Bergosh**: It just seemed bush league to me for her to threaten me with going before a judge just because I didn’t answer the question with an answer that was acceptable to her.

### CONVERSATION ON 01-19-2021

**Jeff Bergosh**: Randy-Brad died on Saturday.  He lost his battle with COVID-19.😪😪😪😪.  Devastating news.  Apparently there will be an online memorial on zoom.  I'll send you the information as I receive it.  I just now got this news from his friend on Facebook- BJ Streeby.

**Jeff Bergosh**: Here is what I just received Randy

**Jeff Bergosh**: Randy- here is what I received today regarding Brad's online memorial service.  I tried to text it to you earlier but it didn't go through. 

### CONVERSATION ON 01-20-2021

**Jeff Bergosh**: In mtg

**Jeff Bergosh**: Will call after

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: There’s room enough for all of us to get a win!

**Jeff Bergosh**: Poof there it goes

### CONVERSATION ON 01-22-2021

**Jeff Bergosh**: Hey Ira I had to send your time sheet back for correction. Please resubmit it and indicate Monday as a holiday thanks

### CONVERSATION ON 01-25-2021

**Jeff Bergosh**: Don’t worry this is an anomaly

**Jeff Bergosh**: We’ve Been going through days where the high temperatures in the upper 40s and it’s been cloudy and rainy and miserable this is the first day in the 70s we’ve had in a while

**Jeff Bergosh**: But I’ll take it😎👍

**Jeff Bergosh**: Give me a call when u have 5 minutes to talk.  Important!

Thanks!

### CONVERSATION ON 01-26-2021

**Jeff Bergosh**: It’s a D2 conspiracy

**Jeff Bergosh**: "Yo I'm getting my ass kicked on Facebook today!!"  --Doug

**Jeff Bergosh**: "Yo I'm getting my ass kicked on Facebook today!!"  --Doug

**Jeff Bergosh**: He's getting his guts ripped out on there---Wow!

**Jeff Bergosh**: Most, but not all, instances of doing something in the course of one’s duty also lead to the conduct being considered “in the public interest.”  But not all.

**Jeff Bergosh**: Not sure

**Jeff Bergosh**: Loved “I got so excited I just wet my pants”

**Jeff Bergosh**: But those comments — wow it is rough

**Jeff Bergosh**: This guy must love lawyers I guess

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Too bad if he does though

**Jeff Bergosh**: Tim’s alright but Doug is a POS

**Jeff Bergosh**: But he is above that petty stuff.  He’s better than following rules

**Jeff Bergosh**: Laughed at “and I want to be the kid who sticks the bomb up his ass...metaphorically speaking.”

**Jeff Bergosh**: And I’ll press the button as he tries to escape the room

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Give me a call when u have 5 minutes to talk.  Important!

Thanks!

### CONVERSATION ON 01-27-2021

**Jeff Bergosh**: I got an email to my email box from a person named DH and I wanted to speak to that person I’m out in the field can you forward me the telephone number associated with that email today?

**Jeff Bergosh**: I'll double check though

### CONVERSATION ON 01-29-2021

**Jeff Bergosh**: Tim/Heather please put your electronic timesheet in the system ASAP—

### CONVERSATION ON 01-30-2021

**Jeff Bergosh**: It’s an enigma

**Jeff Bergosh**: Maybe their “Patron” told them to do it because he’s got a secret crush on Doug???  Who knows but it’s strange, almost cultish

**Jeff Bergosh**: They are ethically compromised

### CONVERSATION ON 01-31-2021

**Jeff Bergosh**: Yep

**Jeff Bergosh**: This one will NEVER see the light of day unfortunately.  But it’s the best one and you kind of have to think deep about what the rat is saying....And how PNJ responds

**Jeff Bergosh**: Maybe I’ll do a series.  Part 1, 2, 3, 4 etc.

### CONVERSATION ON 02-02-2021

**Jeff Bergosh**: What time today are u and Heather switching off?  There are some jobs coming in that need to be created and closed.

**Jeff Bergosh**: How much is this going to cost???

**Jeff Bergosh**: Nvm

**Jeff Bergosh**: I’m in a meg rn but when I get out I will

**Jeff Bergosh**: D’oh

**Jeff Bergosh**: You guys are making some good progress now!

### CONVERSATION ON 02-03-2021

**Jeff Bergosh**: Your refund from Roger Scott hit your account today :)

**Jeff Bergosh**: Getting ready for bed,  love u❤️❤️

**Jeff Bergosh**: ..... there needs to be

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Excellent outtakes today!

**Jeff Bergosh**: BTW- in case you missed our review meeting this morning- they put out the 41 names who’ve applied for the CSC........

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/02/blog-post_57.html?m=1

**Jeff Bergosh**: BTW- in case you missed our review meeting this morning- they put out the 41 names who’ve applied for the CSC........  

http://jeffbergoshblog.blogspot.com/2021/02/blog-post_57.html?m=1

**Jeff Bergosh**: In mtg

### CONVERSATION ON 02-05-2021

**Jeff Bergosh**: Better them than me 

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Sally— Sign us up for the Bread and Table event in Alabama for Valentine’s Day!  I’m in!

### CONVERSATION ON 02-07-2021

**Jeff Bergosh**: I read this and thought that you might like to read it.  Once you graduate in a year and a half—- you can defer payments a lot of different ways for a long time.  


Also— looks like you are in for some dangerous cold weather over the next week.  Stay warm, stay safe!!  ⛄️⛄️⛄️⛄️❄️❄️❄️❄️❄️❄️

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Brought a lunch for him today and gave it to him

**Jeff Bergosh**: Cockblockage

**Jeff Bergosh**: This may cost her her fucking job

**Jeff Bergosh**: This may be the straw

**Jeff Bergosh**: Please send it to me

**Jeff Bergosh**: Yes he is!

**Jeff Bergosh**: Ultimate cock block has been maneuvered 

### CONVERSATION ON 02-10-2021

**Jeff Bergosh**: I only see one text message

**Jeff Bergosh**: Who knew right?

**Jeff Bergosh**: That’s outstanding Rick! God I love the sunshine law! I’m really looking forward to tomorrow’s meeting now😎

**Jeff Bergosh**: I’m in the field right now so I haven’t had the opportunity to go through all the emails but I read the two articles that you wrote and it’s really really problematic for navy federal’s credibility so far as I can tell...

**Jeff Bergosh**: Nicky-I’m in a meeting can I call u after?

**Jeff Bergosh**: I hope he’s not

**Jeff Bergosh**: Hey Scott in case you haven’t seen it there’s a pretty explosive series of blog posts on ricks blog you need to look at and at some point this afternoon I’d like to discuss it with you before my meeting with Janice and Allison thanks man

**Jeff Bergosh**: I got the email dumped you and I’m going through it right now

**Jeff Bergosh**: I saved it

**Jeff Bergosh**: She says “she will need an explainer”. And draws a sad face. :( 

**Jeff Bergosh**: Not cool

**Jeff Bergosh**: We have a workshop with them tomorrow

**Jeff Bergosh**: It’s going to be ugly for them because I’ve got the emails and I’m going through them one by one.  Page by page. Centimeter by centimeter

**Jeff Bergosh**: Trouble

**Jeff Bergosh**: They may have been able to Put just enough space between them and the actual issue to make it legal

**Jeff Bergosh**: Remember guys no 730 meeting this morning I will be out of the office until about lunchtime

**Jeff Bergosh**: Hi Brigette— I understand the short list is down to three individuals all of them are very well qualified including one local named Ed Spears. I certainly hope that you will follow the process and not let Karen attempt to add Johnathan Owens into the mix as he is not qualified

**Jeff Bergosh**: And it’s my understanding she’s trying to shoehorn Johnathan into the job that Paola was doing

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: D'oh

**Jeff Bergosh**: That’s where I am🙂

**Jeff Bergosh**: I’m going to put you in touch with the gentleman I just described

### CONVERSATION ON 02-12-2021

**Jeff Bergosh**: Thanks for the kind words that you said about me I appreciate that

**Jeff Bergosh**: Right!

**Jeff Bergosh**: He must think that none of us know about that otherwise how could he talk about anything to do with economic development with a straight face

**Jeff Bergosh**: 😂😂

**Jeff Bergosh**: And that's a losing strategy

**Jeff Bergosh**: Hey Jim do you still have Navy Federal credit Union’s corporate address that you mailed Cutler Dawson a letter to a couple of years ago? If you do can you please send me that address? I’d greatly appreciate it hope all is well

### CONVERSATION ON 02-13-2021

**Jeff Bergosh**: That POS was saying "Our Schools SUCK"

### CONVERSATION ON 02-15-2021

**Jeff Bergosh**: Hello Brandon, please reply to confirm and prevent delays to your appointment on Fri Feb 26 2021, 11:00am at Clarkson Eyecare - Nine Mile Reply Y to confirm, N to cancel. or text with Qs 

We have added additional disinfection protocols at every step throughout your visit and taken every precaution for your safety. For details on how we are handling COVID-19 visit https://well.app/ZIaqmi In the event you are displaying flu like symptoms, we encourage you to reschedule your appointment. Please contact us at 850-479-2020 and we will be happy to reschedule your appointment.

**Jeff Bergosh**: This is newsworthy

**Jeff Bergosh**: No— my bad.  We did get it on the 11th

### CONVERSATION ON 02-16-2021

**Jeff Bergosh**: You have 2 prescriptions ready @ Publix #1343 for $10.70.  Save time. Pay now: https://rx.publix.com/7 Reply STOP to stop.

### CONVERSATION ON 02-17-2021

**Jeff Bergosh**: Rick Outzen going after Navy Federal Credit Union.  Wow—-ouch

**Jeff Bergosh**: Going to bed.  Big morning tomorrow.  Love you!  Come home soon!❤️❤️

**Jeff Bergosh**: Always an angle with him

**Jeff Bergosh**: What’s his angle

**Jeff Bergosh**: Alison-  please take a look at this, as it relates to grounds for discipline for registered architects in Florida.  The team “leader” is a Florida RA.  And going through her emails I see lots of emails upon which she is copied where the board’s interests appear to be undermined.

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 02-18-2021

**Jeff Bergosh**: In BCCMeeting rn

**Jeff Bergosh**: They should have just voted against it.  I had 3 votes

**Jeff Bergosh**: Because they voted for it after the fact doesn’t excuse their bs

**Jeff Bergosh**: And doesn’t buy back good will

**Jeff Bergosh**: Cassie-- I knew I wasn't that far off.  Our library property is nearly five acres, not 3.7 acres.  Where did the 3.7 acre number come from?????

### CONVERSATION ON 02-19-2021

**Jeff Bergosh**: Tim/Heather please put your electronic timesheet in the system ASAP—

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 02-20-2021

**Jeff Bergosh**: And we’re up to the one in the first set :-)

**Jeff Bergosh**: This guy is a POS

**Jeff Bergosh**: Never liked him

**Jeff Bergosh**: He came up to me once at a wahoos game talking shit when I was on the school board

**Jeff Bergosh**: I gave it back to him quick

**Jeff Bergosh**: He left the area fast

**Jeff Bergosh**: Shit talkers 

### CONVERSATION ON 02-21-2021

**Jeff Bergosh**: What a dumb sack of crap that guy is

**Jeff Bergosh**: He needs to stick to schlepping penny stocks and high cost fully loaded mutual funds

### CONVERSATION ON 02-22-2021

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: Because of the massive gate back up and also due to the fact that at least three of us will be on PTO this morning, the weekly meeting normally held at 7:30 on Monday will be held tomorrow at 8:00AM

**Jeff Bergosh**: And I’ll have to coordinate with my wife it would probably be at her office off of Olive Road at her clinic

**Jeff Bergosh**: Please call her at 850-748-4456 on her cell or 850-479-4456 at her office extension 123

**Jeff Bergosh**: And see if 630 works for her

### CONVERSATION ON 02-23-2021

**Jeff Bergosh**: Please let me know this time works.  Mom said Tue/Thurs works in your schedule.  I’ve given him all the information about insurance so that’s all covered.  He also told me point blank that his professional duty and obligation is 100% only to you, the patient.  He has a lawful obligation to keep your information between you and him only under Federal Law.  So you can know this is all private between you and him.

**Jeff Bergosh**: Mom and I love you so much we just want the best for you and the best starts one step at a time, beginning with this first appointment Thursday. 

Love,

Dad

**Jeff Bergosh**: Just forwarded you an email back and forth between  Marina Khoury and I.  Unbelievable to me the arrogance and tone-deafness......

**Jeff Bergosh**: 100% absolutely it is within the governor's authority to order flags state wide to be set at half staff. Like him or hate him rush Limbaugh was a titan in media particularly a.m. talk radio. Absolutely appropriate in my opinion if the governor authorizes it to lower the flag to half staff to honor him.

### CONVERSATION ON 02-25-2021

**Jeff Bergosh**: Again, we disagree—-/ but that’s okay we can agree to disagree

**Jeff Bergosh**: I love u!!

**Jeff Bergosh**: OK here’s what’s important about the vaccination event tomorrow.

**Jeff Bergosh**: It starts at 8 AM and goes until 2 PM

**Jeff Bergosh**: citizens 65 and older and healthcare personnel are eligible

**Jeff Bergosh**: I will on my lunch break though

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2021/02/blog-post_89.html?m=1

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2021/02/blog-post_89.html?m=1

### CONVERSATION ON 02-26-2021

**Jeff Bergosh**: Hi Brandon, Please do not forget your appt on Fri Feb 26 2021, 11:00am at Clarkson Eyecare - Nine Mile.  We have added additional disinfection protocols at every step throughout your visit and taken every precaution for your safety. For details on how we are handling COVID-19 visit https://well.app/peMfoA. In the event you are displaying flu like symptoms, we encourage you to reschedule your appointment. Please contact us at 850-479-2020 and we will be happy to reschedule your appointment.

### CONVERSATION ON 02-28-2021

**Jeff Bergosh**: Don’t you work today?

### CONVERSATION ON 03-01-2021

**Jeff Bergosh**: Mass transit advisory committee

**Jeff Bergosh**: Here’s the link to the item

**Jeff Bergosh**: Jeffbergosh@gmail.com

**Jeff Bergosh**: Tori— I need your W-2 from NurseSpring if u want me to file your taxes through my CPA

**Jeff Bergosh**: And any other employer you worked for in calendar year 2020

### CONVERSATION ON 03-02-2021

**Jeff Bergosh**: Debbie— where are the login credentials for this meeting at 6:00

**Jeff Bergosh**: I don’t see the login information on the calendar

**Jeff Bergosh**: Agreed

**Jeff Bergosh**: Thanks for the heads up I’ll keep an eye on it

### CONVERSATION ON 03-03-2021

**Jeff Bergosh**: Why not nuclear power in the mix

### CONVERSATION ON 03-04-2021

**Jeff Bergosh**: And what a “vanilla” speech

**Jeff Bergosh**: Looks like he left though

**Jeff Bergosh**: You are not making sense

**Jeff Bergosh**: Know that

**Jeff Bergosh**: I'm on my way.

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-05-2021

**Jeff Bergosh**: Sally— what time is your event tonight?  I want to work a plan to be your designated driver so just let me know the start and approximate end time please.  😎👍❤️

**Jeff Bergosh**: I’ll meet u at the house at 4:30 and take you there

**Jeff Bergosh**: Ben’s BD card covered❤️😎👍

**Jeff Bergosh**: I also got two extra cards—-one for Gary’s Bday March 12th and Alex’s Bday March 21st

**Jeff Bergosh**: Just let me know when u r ready for me to pick u up

**Jeff Bergosh**: I’m done going through the emails at my office

**Jeff Bergosh**: Just let me know when you’re ready ❤️👍

**Jeff Bergosh**: But I personally think he made a mistake in strategy-- he should've held that announcement close to his vest until much later in the cycle so that he's not such a lame duck for so long......but hey I was never one that thought he was real bright on strategy.

### CONVERSATION ON 03-06-2021

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Have fun though!

**Jeff Bergosh**: Plus he probably knows that the counties response to Petrie in the circuit court is going to be devastating to his argument for reimbursement thanks to the go by that Figlio produced at your expense thank you

**Jeff Bergosh**: Not a good day for Doug today

**Jeff Bergosh**: If they had them

### CONVERSATION ON 03-08-2021

**Jeff Bergosh**: it’s amazing to me people think these guys are world class. They come across in these crass backbiting condescending emails and texts like they are world class-less

**Jeff Bergosh**: From Clarkson eye care

### CONVERSATION ON 03-09-2021

**Jeff Bergosh**: I'm going to compare it to what Tru green just offered and go with the better price

**Jeff Bergosh**: LOL those last two were not for you

**Jeff Bergosh**: He and Wendy were on a vendetta they even made public records requests of Gary’s schedule and then they found to their dismay that a different judge had switched with Gary he was only there by happenstance

**Jeff Bergosh**: That wouldn't surprise me

### CONVERSATION ON 03-10-2021

**Jeff Bergosh**: Do u need it again?

### CONVERSATION ON 03-11-2021

**Jeff Bergosh**: You have 2 prescriptions ready @ Publix #1343 for $8.66.  Save time. Pay now: https://rx.publix.com/7 Reply STOP to stop.

### CONVERSATION ON 03-12-2021

**Jeff Bergosh**: Fire fighters talking shit about their bosses online.  No leadership at all

**Jeff Bergosh**: FYI— why is he permitted to run us down?

**Jeff Bergosh**: Call me

**Jeff Bergosh**: It’s funny they get called out for being unethical which they are for working behind the clients back which they were and for that I get excoriated and you get dragged into it

**Jeff Bergosh**: How does that work?

**Jeff Bergosh**: Doesn't this guy work for us?

**Jeff Bergosh**: Call me

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-15-2021

**Jeff Bergosh**: You have 2 prescriptions ready @ Publix #1343 for $8.66.  Save time. Pay now: https://rx.publix.com/7 Reply STOP to stop.

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: 
He is very meek and mild mannered at work

**Jeff Bergosh**: Now that our kitchen is done

**Jeff Bergosh**: Doing well I can’t complain I won the election :-)

**Jeff Bergosh**: Hi Renee— if you all will be out in Beulah and are looking for an additional story, Chester Holland called and he is upset about a serious traffic issue out there — he saw a bear miss today where a young child was almost struck and killed by a truck.  His member is 850-503-7515. He lives at 5950 Frank Reeder Road

**Jeff Bergosh**: Very near the fire station

**Jeff Bergosh**: He’s got a story

### CONVERSATION ON 03-18-2021

**Jeff Bergosh**: I’ve got Gary’s card so we could drop it on him as well 

**Jeff Bergosh**: I thought I’d be late and I’m the first and only one here LOL

**Jeff Bergosh**: Gary said he’s OK

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Good Morning David—that screenshot of Jacqueline Rogers sending a complaint to the JQC on my brother—- was that posted on ECW?  Where did that come from?  Trying to find context, and I’m wondering why she’d threaten my brother if her beef is with me.

**Jeff Bergosh**: Do you know the date on that?

**Jeff Bergosh**: Perplexed as to what else it could be

### CONVERSATION ON 03-20-2021

**Jeff Bergosh**: Then shopping

### CONVERSATION ON 03-22-2021

**Jeff Bergosh**: Debbie- can you assist Michael with this?

**Jeff Bergosh**: Not going to make TPO mtg

**Jeff Bergosh**: Need u to sign the counter

**Jeff Bergosh**: I signed it

**Jeff Bergosh**: My question is simple:  what will they do if we say No?  Will they have to suck it up— or will they just walk?

**Jeff Bergosh**: Or can they?

**Jeff Bergosh**: I’m going to have a lot of technical questions— love the idea of the full financials

**Jeff Bergosh**: Sally will also.

### CONVERSATION ON 03-23-2021

**Jeff Bergosh**: Also:  we have to sign our initial documents for the condo loan online.  It will tell you to use last four of as number—- but use 0928 instead.  0944 wont work.  You need to go through and sign that tonight.  Love u!!

**Jeff Bergosh**: Would that change if enacted apply to the single member district commissioners in charter counties?

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: Hey Brandon go check the front door I think they just delivered your contact lenses love you

**Jeff Bergosh**: I’d get it quick there are workers out from we wouldn’t want it to “walk away”

**Jeff Bergosh**: In BCC mug will call u after

**Jeff Bergosh**: It was really convoluted the way it was presented— but I did some additional, independent research and figured it out.  It’s us getting our share, not a tax.  Thus, I’ll definitely support it

**Jeff Bergosh**: I'll bring a handle

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: In a meeting will call u back

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: Hi Mark I’ve done significant research today and spoken to multiple technical representatives at  Gordian group and have some information to pass on and some good news. If you can call me at your convenience I’d greatly appreciate it thank you.

### CONVERSATION ON 03-29-2021

**Jeff Bergosh**: The crown

**Jeff Bergosh**: Thanks for following up on this David— I greatly appreciate it!!

**Jeff Bergosh**: Hello Alex—I hope you have a productive week in Tallahassee.  Thank you so much for speaking with me Saturday morning about the upcoming redistricting and more importantly---the onerous “add-on” that was hastily placed on the very end of HB 7041 while it was still a committee bill.  The Senate companion SB 90 is a very good bill and most of us statewide support it. We also support the vast majority of the provisions contained within HB 7041.As you know and as we discussed this added provision that was added at the table during a committee hearing will make every county commissioner who is elected in a single member districts state wide have to run for reelection next year. This includes those of us who just won hard fought contests last year. 
This will cut our terms in half and many of us may very well lose our subsequent election.  

The justification I hear for this added provision is because after redistricting —-some voters will live in districts and be represented by county commissioners that they did not vote for for the last two years of such commissioners' terms. However that justification does not square with the reality of what has been added to the bill. If that was truly the goal then these provisions should/would apply equally to all single member district school board members and authority board members like ECUA board members here in Escambia County as well. But because it doesn’t —-it debunks the voter purity justification and again—only seems punitive toward  county commissioners. If this is the intention of the legislature and they have to have this language— enactment of this provision of this legislation should be delayed.  This is  due to the COVID-19 pandemic and the tremendous delay in redistricting this year That we are all now dealing with and will be dealing with in addition to this bill if it passes.,  because the Census Bureau is so far behind many counties like Escambia more than likely will not finish the redistricting process this year.  the effective date of this provision of the bill, if this language must be included, should be pushed out to July 31, 2022 to allow all counties the opportunity not to rush redistricting which would risk litigation.  Additionally—This would allow time for all potential candidates and current office holders to plan for the reality of running three elections within four years. Yes —- we know this also impacts 20 of the 40 state senators who also must re-run 2 years early—they must re-run after the decennial redistricting—however they have always known this as this had always been the case. By contrast —Local office holders have never had to meet this requirement and so therefore many of us were caught flat-footed. Again—-If it’s truly about one vote one voter and fair representation--then this should apply to all single member elected county office holders state wide, however it does not and therefore just seems to be punitive toward county commissioners.  In addition: 

—-this legislation if passed with this provision will reduce the amount of available campaign contributions made to all candidates as there is a finite number of check writers in each county and this provision would require nearly 160 County commissioners state wide to run again two years ahead of time the effect of which would be a fight for campaign dollars between and among Republicans at all levels of government leading to a massive sucking of campaign contributions away from all candidates most specifically important state wide Republican candidates. 


——This legislation, if passed with this provision will be extremely burdensome on county supervisors of elections who will suddenly have to deal with all commissioners county wide running simultaneously—This could lead to a loss of institutional knowledge if a majority of commissioners lose their elections. Also this will slow the work of government significantly as additional time and effort would necessarily have to be put into campaigning and fundraising by all such candidates— which would slow tough decision making and slow down important projects.

Thank you very much in advance Alex for any help you can give with slowing this destructive provision down——or at a minimum at least having the effective date of this section delayed-----if it must be added------until July 31 of 2022.

Thanks!

Jeff Bergosh 
Escambia County Commissioner District 1

### CONVERSATION ON 03-30-2021

**Jeff Bergosh**: Several follow up items

**Jeff Bergosh**: The latest one is from the 29th

**Jeff Bergosh**: It will be a bloodbath very similar to the Japanese dolphin harvest

**Jeff Bergosh**: Is this fake summer or last spring or second spring?

**Jeff Bergosh**: LOL

**Jeff Bergosh**: https://apple.news/Ak0S0zYS7Qvmy5W6nOaCuzA

**Jeff Bergosh**: Should I run for this next year if MATT leaves?

**Jeff Bergosh**: There would be a hell of a lot of comp petition including big names in the county it would be like a bloodbath like the Japanese dolphin harvest

**Jeff Bergosh**: But I campaign pretty damn hard

**Jeff Bergosh**: Otherwise hell yeah

**Jeff Bergosh**: Nothing damaging though

**Jeff Bergosh**: I’m gonna pray about it because I would have to leave my job and resign so once again it would be a big risk like when I ran for county commission and had to resign

**Jeff Bergosh**: Crazy

**Jeff Bergosh**: D'oh

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/03/blog-post_89.html?m=1

### CONVERSATION ON 03-31-2021

**Jeff Bergosh**: From Nick:

Hey thanks, Dad! 1339 N. Jackson St., Apt. 305, Milwaukee, WI 53202.

**Jeff Bergosh**: Will u call her?

**Jeff Bergosh**: Check this out:

**Jeff Bergosh**: From Michelle Salzman

**Jeff Bergosh**: Really???

### CONVERSATION ON 04-01-2021

**Jeff Bergosh**: On a serious note I sent you your navy records and also your new automobile registration and sticker you should be getting it today or tomorrow in the mail

**Jeff Bergosh**: enjoy fake winter IV

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Tell me how it turns out please

**Jeff Bergosh**: And yes if you can replace those heads in and get the whole thing up and running and synchronized let’s go ahead and do it and I can have a check or a credit card with however you want me to pay you

### CONVERSATION ON 04-02-2021

**Jeff Bergosh**: We found out that their deductible for their hurricane loss is $500,000 so we need to talk about it because that assessment hasn’t hit yet it’s coming though. Call me when you get done with tennis so we can discuss it love you

### CONVERSATION ON 04-05-2021

**Jeff Bergosh**: R u watching National Championship?

**Jeff Bergosh**: Right on see you tomorrow

**Jeff Bergosh**: Please call when you have a moment

### CONVERSATION ON 04-08-2021

**Jeff Bergosh**: If it’s after 1130 I can participate if they’re going to do it earlier than that I may not be able to

**Jeff Bergosh**: Spam

**Jeff Bergosh**: Not pantry door

**Jeff Bergosh**: In a BCC meeting

### CONVERSATION ON 04-12-2021

**Jeff Bergosh**: Tally*

**Jeff Bergosh**: John and Gary:  please bring me a copy of your hard copy timesheet(s) from last week.  Thanks!

### CONVERSATION ON 04-13-2021

**Jeff Bergosh**: Debbie— The new owners of George’s are attempting to utilize an adjacent property that they purchased for parking and they’re being cited for it can you check with Tim Day and see why this is happening?

**Jeff Bergosh**: Debbie— Can you please check with Tim Day about these Code Enforcement citations that were put on everybody’s trash can out in a very rural part of Beulah? These folks have had their trash cans on their yards near the street for decades with no issues. So if we could find out where this is all coming from if it was a complaint by a neighbor or whatever the case might be I’d like to know that so I can pass it along

**Jeff Bergosh**: Part two

**Jeff Bergosh**: Park in my spot

**Jeff Bergosh**: Walk to the front where the commission chambers are

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: Dental appointment Monday April 26th

**Jeff Bergosh**: Hey Janice it's Jeff Bergosh it's about 11:45 and I have a very quick question but it's important please call me when you get this thank you

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: Doug Talks a lot of shit but he has no idea how Tallahassee works

**Jeff Bergosh**: Senator Baxley the sponsor submitted a revised strike all bill yesterday morning 17 minutes before the deadline. It incorporated a lot of the language from the house bill however it's specifically did not include the provision about commissioner elections which is telling

**Jeff Bergosh**: And I've been speaking with his legislative liaison Debbie Dennis multiple times over the last three weeks and have developed a very good rapport with her

**Jeff Bergosh**: So glad they got it fixed!!

**Jeff Bergosh**: It is really like flying blind without having a phone!!

### CONVERSATION ON 04-15-2021

**Jeff Bergosh**: Thank you!

**Jeff Bergosh**: I agree with not having single member districts

**Jeff Bergosh**: The singer for Krokus, Mark Storache, said “I think we’re at the Pensacola Fucking Zoo!

**Jeff Bergosh**: Willis Halfacre has emailed saying no response from Engine 2

### CONVERSATION ON 04-16-2021

**Jeff Bergosh**: I’ve been speaking with his legislative liaison very frequently center backs leaves legislative liaison the Senate sponsor

**Jeff Bergosh**: But at the end of the day even if it goes through I believe it we challenged because it’s unconstitutional the constitution says we have four year terms and to change that I do not believe can happen this way

**Jeff Bergosh**: And also we also will probably not have adequate time to do redistricting if we do not get our data from census until October at which point this onerous legislation would apply to D2 and D4 in their 2020 for campaigns

**Jeff Bergosh**: *2024

**Jeff Bergosh**: So there are several fall back positions

**Jeff Bergosh**: Tim/Heather please put your electronic timesheet in the system ASAP—

### CONVERSATION ON 04-17-2021

**Jeff Bergosh**: Brandon— I’m looking at flights for you to Milwaukee and we spoke to Nick— he’s excited to have you up there.  The dates that work best are Saturday May 8th leave Pensacola 9:30AM return to Pensacola Wednesday May -12th at 6:45 PM

Do those days work for you in your schedule?

**Jeff Bergosh**: Can u get those days off from the job to go up there?  Let me know and I’d it works I’ll book it!

**Jeff Bergosh**: Booked it

**Jeff Bergosh**: U just need to get the days off now 😎❤️👍

**Jeff Bergosh**: I think you’ll be very happy this is what he wanted so he knows it’s coming not a surprise

### CONVERSATION ON 04-18-2021

**Jeff Bergosh**: 4 of 7 voted “at large”

**Jeff Bergosh**: One member is a former state rep

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: I know Rep Fisher from Duvall who sits on the committee and he and I are texting back and forth rn

**Jeff Bergosh**: Board members do not want that

**Jeff Bergosh**: I lived it, it sucked having a KING superintendent

**Jeff Bergosh**: Good morning Michel I hope all is well I know this is probably a hectic week with the end of session nearing. I see that house bill 7041 is up today at 2:30 in the state affairs committee. Is this the stop where this bill will get fixed? According to the sponsor? I note that the Senate companion bill senate bill 90 has never had the provisions about county commissioner elections contained within it. Please let me know and thanks for all you do!

**Jeff Bergosh**: I just went through every amendment and I don’t see any change to that language. The only amendment Ingnolia put in was that instead of taking affect July 1, 2021 it will take affect upon becoming law which is even sooner

**Jeff Bergosh**: * I mean he put numerous amendments in but that’s the only one near the end of the bill where the commissioner language is located

**Jeff Bergosh**: So far as I can tell, the amendments put forward exempt most other large counties....manatee, Collier, and Escambia final three large counties impacted by this bill, along with 13 small counties

**Jeff Bergosh**: These counties still subject to that language

**Jeff Bergosh**: If you are able to perhaps provide a suggestion to Blaise: 

If he were to add an amendment which stipulates “ this subsection shall not apply to any county which has a population exceeding 300,000 citizens”. Such a change would remove the last remaining large counties from the impacts of that language. It might be worth a try?

**Jeff Bergosh**: I spoke to FAC and it applies to 19 county commissions

**Jeff Bergosh**: ...including Escambia

**Jeff Bergosh**: Janice-- I thought we were going to add Concurrency as a discussion on this meeting?  

**Jeff Bergosh**: The stated goal will be that after the census redistricting —some voters will be represented by commissioners for whom they did not vote.  But this argument doesn’t make sense; this same condition will exist for school board and utilities authority board members around the state yet this provision does not apply to them.  Also, many of the large counties that have single member districts are exempted, as is Miami Dade’s commission.  This appears punitive to commissioners in single member district commission counties.

**Jeff Bergosh**: The small counties

**Jeff Bergosh**: But why not school boards as well then??

**Jeff Bergosh**: The thing is it is and was always that way for the senate under the constitution— thus they had the luxury of seeing it coming and planning for it financially with their PACs etc.  none of us commissioners saw this coming and some of us (like me) had vicious, brutal elections we fought hard to win 4-year terms and the passage of this bill like this will knock many of us out—— plus, as chair next year of Escambia’s board, I’m supposed to serve on the canvassing board under statutes—- however if I have to run again I’ll be precluded from serving in this role (as will all similarly affected counties).  All commissioners running simultaneously will be chaos for fundraising as well— many reasons why this provision is not good....

**Jeff Bergosh**: I’m hearing this is directed at a commissioner somewhere in the Tampa Bay Area that has irked someone in the legislature.  But this one paragraph punishes nearly 100 commissioners statewide.  It’s not a good net if it kills 100 porpoises to catch one Tuna

### CONVERSATION ON 04-20-2021

**Jeff Bergosh**: Debbie can you forward this to staff for their action?  Thanks!

**Jeff Bergosh**: Brandon, your dental appointment is today at 11:20 AM. When you arrive please remain in your vehicle. Respond HERE to this message and a staff member will be out greet you. See you soon. (850) 476-5233 Tap for more

### CONVERSATION ON 04-21-2021

**Jeff Bergosh**: Hello Wes-- this is a state road but this is a major safety issue.  Is there anything we could do in the meantime to patch it up for safety's sake?  Thanks and if not can we please pass this on to the state folks so they can repair these holes?

Much appreciated,

Jeff Bergosh

**Jeff Bergosh**: Remember to go in to your email in order to sign the latest addendum for the condo

**Jeff Bergosh**: Current Senate version does not contain that language center back to me did not add it included a lot of the language from the hospital.

### CONVERSATION ON 04-22-2021

**Jeff Bergosh**: Hey Debbie— I received this question from my homeowners association about the fence surrounding a county retention pond in Bell Ridge Forest subdivision.  Can you please ask staff to answer?

Thanks— I’m curious to know myself 

**Jeff Bergosh**: In a BCC meeting

### CONVERSATION ON 04-23-2021

**Jeff Bergosh**: I had a great conversation with the seller today call me and I’ll tell you about it it was really good

### CONVERSATION ON 04-26-2021

**Jeff Bergosh**: Brandon I need you to open the front door for the workers they’re there to start the floor

**Jeff Bergosh**: Here’s good news I fix the dishwasher! It’s working like a champ

**Jeff Bergosh**: *fixed

### CONVERSATION ON 04-27-2021

**Jeff Bergosh**: Thank you!

**Jeff Bergosh**: Okay, looks like this oils on the senate site

**Jeff Bergosh**: And this is fantastic because that’s the bill sponsor who offered the strike all

**Jeff Bergosh**: Which is fine by me— not my issue

**Jeff Bergosh**: Looks like Ingnolia did what he said he would.  He filed a strike all amendment last nigh and the commissioner election language is removed.

**Jeff Bergosh**: Thanks for your work on this!

### CONVERSATION ON 05-01-2021

**Jeff Bergosh**: So start getting ready

**Jeff Bergosh**: But just the same it’s happy to see them finally recognize something I’ve done positively

### CONVERSATION ON 05-04-2021

**Jeff Bergosh**: Ok

**Jeff Bergosh**: What time is reservation tonight, and where?

**Jeff Bergosh**: Alright well I made reservations for brunch Sunday at the beach for Mother’s Day at 11:30

### CONVERSATION ON 05-05-2021

**Jeff Bergosh**: First page and last page

**Jeff Bergosh**: P2

**Jeff Bergosh**: P3

**Jeff Bergosh**: P4

**Jeff Bergosh**: P5

**Jeff Bergosh**: P7

**Jeff Bergosh**: Got us booked on Southwest airlines out of Pensacola for the round-trip to Seattle. I found dates and times that equal the lower price than if we would’ve flown out of New Orleans which is very unusual!

Alaska here we come!!

**Jeff Bergosh**: Hovering around 30 people in the hospitals. But according to Gay Nord the CEO of West Florida Hospital with whom I spoke today. The average age has gone down from 70 in the early part of the pandemic to 50 today locally

**Jeff Bergosh**: Got it booked!

### CONVERSATION ON 05-06-2021

**Jeff Bergosh**: And Moby mats for handicap access?

**Jeff Bergosh**: On with Eric Gilmore

### CONVERSATION ON 05-07-2021

**Jeff Bergosh**: I’m at NFCU right now getting the check 😎👍

### CONVERSATION ON 05-08-2021

**Jeff Bergosh**: 2 part process

**Jeff Bergosh**: His part completed

**Jeff Bergosh**: I’m still here stuck on hold

### CONVERSATION ON 05-10-2021

**Jeff Bergosh**: What’s the status?

**Jeff Bergosh**: Call me with update as soon as you can so I can get Tony aware of it before he gets blindsided

### CONVERSATION ON 05-11-2021

**Jeff Bergosh**: Hi Chrys- looking forward to meeting you today at the condo at 12:00.  We went shopping for the items we discussed and I found everything on the list at BJs, Tuesday Morning, and TJMaxx

**Jeff Bergosh**: The only thing Sally and I couldn't find were the bed skirts.  I'm going to buy them on Amazon and I'll get them by tomorrow.

**Jeff Bergosh**: White, light grey, or sand-- what color do you recommend?

**Jeff Bergosh**: 70?

**Jeff Bergosh**: I assume that’s a no go?

**Jeff Bergosh**: I know you’re busy I totally get it.  When you come up for air let’s get together and work on the reservations

**Jeff Bergosh**: Okay great appreciate that

### CONVERSATION ON 05-12-2021

**Jeff Bergosh**: Got it.

**Jeff Bergosh**: Hi Linda my name is Jeff Bergosh I just bought unit to see in Tristan Towers. The seller gave me your name I'm trying to locate the air conditioner unit on the roof so I can have it serviced. I'd like to schedule a time so that you can show me which unit belongs to unit to see. Also the seller told me that you guys provide the bulbs for the porches there is no bulb on my porch I'm told they have to be turtle friendly and at the HOA provides them please give me a call back and let me know how we can handle these issues thank you my telephone number is 293-1459.

**Jeff Bergosh**: View from rooftop—on 15 th floor

**Jeff Bergosh**: The ac at the condo was working today though🤨

**Jeff Bergosh**: Brandon coming in a little late, 10:45

### CONVERSATION ON 05-14-2021

**Jeff Bergosh**: Window guys on way right now

**Jeff Bergosh**: R u still at house?

**Jeff Bergosh**: Tori move your car to the opposite side of the cul-de-sac by Mike’s house do not park in front of the mailbox where we won’t get our delivery. Move the car to the opposite side of the cul-de-sac please so that these guys and their giant trucks have a place to park and so they don’t pull into the lawn and rec my sprinkler pipes again!

**Jeff Bergosh**: Tori move your car to the opposite side of the cul-de-sac by Mike’s house do not park in front of the mailbox where we won’t get our delivery. Move the car to the opposite side of the cul-de-sac please so that these guys and their giant trucks have a place to park and so they don’t pull into the lawn and rec my sprinkler pipes again!

**Jeff Bergosh**: So far so good

**Jeff Bergosh**: But now I am.  Looks fantastic!

### CONVERSATION ON 05-16-2021

**Jeff Bergosh**: We’re in our new backyard 😎❤️👍

**Jeff Bergosh**: Just sent you $100 on Venmo 

### CONVERSATION ON 05-17-2021

**Jeff Bergosh**: To you

**Jeff Bergosh**: Look in your inboxes

**Jeff Bergosh**: Guess what came in the mail for u today?

### CONVERSATION ON 05-18-2021

**Jeff Bergosh**: Will 1:00 work for the tour Sally?  Monday, June 7th?

**Jeff Bergosh**: Airbnb.com/rooms/49674927

**Jeff Bergosh**: Airbnb.com/rooms/49674927

**Jeff Bergosh**: http://Airbnb.com/rooms/49674927

**Jeff Bergosh**: http://Airbnb.com/rooms/49674927

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: Are you on my listing?  2303929 ?

**Jeff Bergosh**: Here’s the updated link

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: I just had a really good sit-down with Jaron and we went through his program overview line by line.  It's still got a few issues but he and I went trough it in depth; it has a lot more numbers and data as you requested and I think when you see it this afternoon when I send it with the sit rep you'll be very happy!



**Jeff Bergosh**: https://www.vrbo.com/2303929

### CONVERSATION ON 05-20-2021

**Jeff Bergosh**: It’s there

**Jeff Bergosh**: We need a fourth player and I thought it be fun if you and I could play on the same team :-)

**Jeff Bergosh**: ❤️😎👍 Brandon and I are going to play tennis together on Saturday morning! Hey how are you

**Jeff Bergosh**: Dinner is served!

**Jeff Bergosh**: I’ll put yours in the fridge❤️😎👍

**Jeff Bergosh**: Heading to bed, Bible Study early AM tomorrow.  Love u!  See u when u get home.

**Jeff Bergosh**: In a meeting can't talk 

### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Have a great weekend

**Jeff Bergosh**: I'm trying to send you your payment but keep getting error

### CONVERSATION ON 05-23-2021

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: https://www.vrbo.com/2303929

### CONVERSATION ON 05-24-2021

**Jeff Bergosh**: Really??

**Jeff Bergosh**: Brandon will be too

**Jeff Bergosh**: Tim/Heather— I need your hard-copy timesheets.  Please print them out and put them in my inbox

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: Below my white coffee maker

### CONVERSATION ON 05-26-2021

**Jeff Bergosh**: Don’t want to work with DPZ 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: .......For your own sanity and self preservation

### CONVERSATION ON 05-27-2021

**Jeff Bergosh**: My lunch break workout ride 12 miles.  Visuals are incredible!

**Jeff Bergosh**: Love u❤️❤️

**Jeff Bergosh**: Chrys-- can you do me a favor please and take a picture of the sign on the fridge and also the last page of the guest book page so I can change out the contact information for guests?   I'd greatly appreciate that-- and Cory would probably like that too, LOL

### CONVERSATION ON 05-28-2021

**Jeff Bergosh**: 3rd level

**Jeff Bergosh**: Our VRBO listing with pictures

**Jeff Bergosh**: Three Mike Bridge is open today!!!!  Woo hoo—- first time in 9 months!!!

### CONVERSATION ON 05-30-2021

**Jeff Bergosh**: Tori we’re planning on having dinner at Karaba’s next to the Civic Center between seven and 715 will get there meet us after your shift :-)

**Jeff Bergosh**: Looking like 0730ish

### CONVERSATION ON 06-01-2021

**Jeff Bergosh**: Okay so I’ll send $50 today and the card 😁👍

**Jeff Bergosh**: Have a great day

**Jeff Bergosh**: Tim/Heather— I need your hard-copy timesheets.  Please print them out and put them in my inbox

**Jeff Bergosh**: I change it every 30 days and bring the filters with me when I come

**Jeff Bergosh**: It’s due for a change on Saturday June 5th

### CONVERSATION ON 06-04-2021

**Jeff Bergosh**: I hate to hear that

**Jeff Bergosh**: Andy’s latest............

**Jeff Bergosh**: She'll have to put it in writing with her name on it

**Jeff Bergosh**: Yes

**Jeff Bergosh**: She’ll be lionized for “taking a noble position” or “making a stand” —- Yet she conveniently waited until after I demanded a legal opinion and said I wouldn’t vote for it. It’s easy to be a Monday morning quarterback it’s much tougher to jump into the fray and be a leader

**Jeff Bergosh**: She was weak, and opportunistic

**Jeff Bergosh**: By the time she opined, it was a moot point; it was going nowhere and she knew it.  She just took the opportunity to score some cheap political points by her little comments.  

**Jeff Bergosh**: And yeah, I KNOW she doesn’t have my back.  That was just an analogy

**Jeff Bergosh**: 

Great! The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is 3.

**Jeff Bergosh**: Good Morning Joyce- I hope you all are enjoying your stay on the beach.  ATT has reported to me that the modem for internet is malfunctioning.  They sent a new one yesterday to the service address at approximately 1:16.  They were supposed to send it to my home address.....

### CONVERSATION ON 06-07-2021

**Jeff Bergosh**: Hello Sheriff I just missed your call - tried to call u back to leave you a message but your mailbox is full.  

Hope all is well.  Jeff Bergosh 

### CONVERSATION ON 06-08-2021

**Jeff Bergosh**: He told me “ Jeff,  I never have to worry about this contract like I do all the others with you ——I trust you and it’s like it’s on auto pilot”

**Jeff Bergosh**: In mtg will call u back

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/06/blog-post_7.html?m=1

**Jeff Bergosh**: I agree

### CONVERSATION ON 06-09-2021

**Jeff Bergosh**: Marlette cartoon today LOL

### CONVERSATION ON 06-10-2021

**Jeff Bergosh**: No way!!!???!!!

**Jeff Bergosh**: Sarcasm?

**Jeff Bergosh**: Makes you sound really ignorant of economics 

**Jeff Bergosh**: I hope this is some sort of a prank or something................

**Jeff Bergosh**: Who has Rusty’s Phone????

### CONVERSATION ON 06-11-2021

**Jeff Bergosh**: https://weartv.com/news/local/escambia-county-fatal-drug-overdoses-increase-over-60-in-past-year-medical-examiner-says

**Jeff Bergosh**: Call me ❤️

**Jeff Bergosh**: Executive Director Health and Hope Clinic

**Jeff Bergosh**: Office   850-479-4459

**Jeff Bergosh**: They give free Narcan to any citizen in the community who comes by and request it. This is The only Clinic in the area that does this.

**Jeff Bergosh**: Amy—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is 3:00PM

### CONVERSATION ON 06-12-2021

**Jeff Bergosh**: Headed your way

### CONVERSATION ON 06-13-2021

**Jeff Bergosh**: Does that include the IAFF?

### CONVERSATION ON 06-14-2021

**Jeff Bergosh**: Okay I just sent u 9 emails with jpeg screenshots.  Please print all of these out and add them on the top of the existing ones you’ve already printed out. I want to go through all of them and refine what we turn over to the request. I’m not sure if all of these will be responsive to the request but these were the ones I researched and I believe them to be. This is why it has taken so long. So after my meeting this afternoon with Amber, I will go through all of these the ones you’ve printed the ones I’ve sent you that you will print and I’m still searching one of the location. Ideally we will have this ready to turn over to legal By tomorrow morning at which point they can request the payment from the requester and we can put this one behind us. Right now I’m at 13.25 hours total which will probably increase by another hour or two when the whole thing is done

**Jeff Bergosh**: I thought that went really well.

### CONVERSATION ON 06-15-2021

**Jeff Bergosh**: The Studer thing 

**Jeff Bergosh**: I’ll be at home in bed

**Jeff Bergosh**: .........or u and Brigette Brooks could go?

**Jeff Bergosh**: They love her, they love you

**Jeff Bergosh**: Drew Mikel

**Jeff Bergosh**: Hey Beau I hope all is going well. So I just wanna give you some warning I got hit with a gigantic very very expensive public records request for all my social media text messages emails phone records everything the whole kitten caboodle for a five month. Regarding fire and public safety. So some correspondence between you and I will have to be turned over just wanted to give you a heads up this is a wonderful request coming from the lawyer for the fire Union

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: $1000 in checking $800 savings

**Jeff Bergosh**: 4-1 vote

**Jeff Bergosh**: Call me and tell me what happened 

**Jeff Bergosh**: I'm gonna do it right now and he did just text me back and said this is directly from Mark Powell so I'll go in because I had planned to go in anyway in the morning and take care of the payroll stuff.  And this will help me make up some time from today I had a real long County commission meeting today

**Jeff Bergosh**: Did you get the memo we are off tomorrow let me know or I’ll try and call you

### CONVERSATION ON 06-18-2021

**Jeff Bergosh**: Drew—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is after 3:00PM.  I'll text you if the cleaners complete the unit prior to that.  Have a safe trip down!   --Jeff

### CONVERSATION ON 06-19-2021

**Jeff Bergosh**: I think she overstepped

**Jeff Bergosh**: I think so

**Jeff Bergosh**: Do u have screenshots from social media pages demonstrating this allegation that someone took a picture of your private text messages and published them online?  If so, please forward to me I am looking into this!

Jeff Bergosh 

**Jeff Bergosh**: I’ll ask the cleaners to not show up until 10:30

### CONVERSATION ON 06-20-2021

**Jeff Bergosh**: Have a great Father’s Day too!

### CONVERSATION ON 06-22-2021

**Jeff Bergosh**: That’s big dollar!!!!

**Jeff Bergosh**: So u can manage it

**Jeff Bergosh**: Maybe we could come there for Christmas?  I’ll talk to mom

**Jeff Bergosh**: And VRBO

**Jeff Bergosh**: Hey Danny-- hope all is well.  Great kickoff party-- and awesome parade!  Congrats.  Anyway, in reconciling my bank account today I saw that my check to you hasn't cleared yet.  I just want to make sure you got it and I'm respectfully requesting that you cash it as soon as possible to keep me in line with the state's gift policy.  Thanks Danny!

Jeff Bergosh 

### CONVERSATION ON 06-23-2021

**Jeff Bergosh**: Tony:

I've got Ira working on the cost works cost question. I've got Jaron working on his equipment list and his requirements as well. I've asked John campbell who actually did AIS inspections to put together a list of the hand tools necessary and what he feels would be needed to do an average of 300 buildings per year. And I've got Tim working on the costs for new surveying equipment and vehicle as he reports the condition of what we have is not good.  Once I have solid answers to these questions I will forward them along to you and I will be working on a couple of variations of org charts to meet the requirements.

V/R

Jeff

### CONVERSATION ON 06-24-2021

**Jeff Bergosh**: Tim did u send the numbers? 

**Jeff Bergosh**: Are we going to have to put him into a Britney Spears lockdown conservatorship?????

**Jeff Bergosh**: We’ll get market price next year 🙂👍

**Jeff Bergosh**: I would always conserve cash

**Jeff Bergosh**: Just let me know what time you're headed that way and I'll meet you

**Jeff Bergosh**: Thanks

**Jeff Bergosh**: Okay I'll try that

**Jeff Bergosh**: I just shut it off

**Jeff Bergosh**: I'll leave it off a while

**Jeff Bergosh**: Wayne—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is after 3:00PM.   --Jeff

### CONVERSATION ON 06-25-2021

**Jeff Bergosh**: I do have all those dates blocked on VRBO and AirBnB though already

**Jeff Bergosh**: Hey Tony your call dropped I just wanted to let you know I tried calling you back but I guess you're in an area with bad reception

### CONVERSATION ON 06-26-2021

**Jeff Bergosh**: I don’t support given that much power to a guy like Peacock

### CONVERSATION ON 06-27-2021

**Jeff Bergosh**: Me and Brandon are going to watch a movie!

**Jeff Bergosh**: Come home and watch it with us!

### CONVERSATION ON 06-28-2021

**Jeff Bergosh**: You’ll like this post!!!!!!

**Jeff Bergosh**: But it's fine.  He can wait 40 months to do it😎🙂👌

**Jeff Bergosh**: He'll raise no money, nobody knows him, and if he runs against me it won't end well for him; I'll crush him like a roach, just
Like I did for Doug's Secretary 

**Jeff Bergosh**: 😎🙂👌👍

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/06/blog-post_28.html?m=1

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/06/blog-post_28.html?m=1

**Jeff Bergosh**: May take me a bit longer

### CONVERSATION ON 06-29-2021

**Jeff Bergosh**: I'm in

**Jeff Bergosh**: Hey Tony I'm working with Rodolfo on the non-recurring pricing and I've kind of run into a snag on the excavation permit pricing for the non-recurring do you got five minutes we can talk about this real quick?

**Jeff Bergosh**: And he wants to know if we can get the numbers for 2019 for the 44 jobs that we did

**Jeff Bergosh**: Ira does the reproductions costs include tax?

**Jeff Bergosh**: Cristhian—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is after 3:00PM Wednesday, tomorrow.   --Jeff

### CONVERSATION ON 06-30-2021

**Jeff Bergosh**: Good morning Marcus.  A co-worker and Air Force vey with whom I work was involved in a hit and run accident and USAA is yanking their chain.  He’s trying to work through the issues but I think he’s getting stonewalled.  He probably needs a lawyer So I told him to call you and I gave him this number.  I told him you are a vet and a friend and a man that can be trusted.  He will talk it over with his wife Christine and probably call you this evening or tomorrow.  Hope you can help him he’s a good guy.  Hope all else is well.

Jeff B

### CONVERSATION ON 07-01-2021

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Rain must be throwing them off their game

**Jeff Bergosh**: It was backed up when I came in too

**Jeff Bergosh**: Kerri Rourke just asked if this proposal and the prices are still good. We need to get an answer to her right away you sent this on the 21st and in the body of the letter it said the price was good for 30 days obviously 30 days have expired but not by much. Please let me know as soon as possible if this is still a good quote and I’ll let Carrie know thanks

**Jeff Bergosh**: I may be going back to Singapore in February I talk to all the guys and they know I’ll be chairman next year could be great! I hope you’ll go with me this time!❤️❤️❤️

**Jeff Bergosh**: Neil—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 1744. If you have any questions at anytime feel free to text or call me. Check in is after 3:00PM Friday, tomorrow.   --Jeff B

### CONVERSATION ON 07-02-2021

**Jeff Bergosh**: Good Morning Sheriff.  I know you’re super busy but I have a quick question for you if u have time for a call.

### CONVERSATION ON 07-03-2021

**Jeff Bergosh**: Here

**Jeff Bergosh**: Do you want me to see if Sally will be our 4th?

**Jeff Bergosh**: Veiled threat about my house burning, Under a string created by the former disgraced fire fighter Brian caro which was of course “liked” by Jacqueline Rogers

**Jeff Bergosh**: Working like a champ now!

### CONVERSATION ON 07-04-2021

**Jeff Bergosh**: Looks like about six more hours to get where you’re going...

### CONVERSATION ON 07-05-2021

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: 3rd level

**Jeff Bergosh**: I have one guest leaving on Sunday at 10:00 and another coming in at 3:00– so if you’d like to swing by at 2:00 you could check it out

**Jeff Bergosh**: 1200 Fort Pickens Road # 2-C  Pensacola Beach Florida 32561

### CONVERSATION ON 07-06-2021

**Jeff Bergosh**: I’m proud of you Brandon!

### CONVERSATION ON 07-07-2021

**Jeff Bergosh**: 10:45 they'll be there with keys to open it up for you all

**Jeff Bergosh**: Just walked into a meeting I’ll call u back on my break at 11:15

### CONVERSATION ON 07-08-2021

**Jeff Bergosh**: BTW-- Keith Morris resigned yesterday as well.  He was the lead investigator for our ethics/compliance department

### CONVERSATION ON 07-09-2021

**Jeff Bergosh**: He huffed out early before the meeting ended, LOL.. when we voted to pay legal defense costs for an employee.  He's all bent because we won't pay his.....

**Jeff Bergosh**: And all of those who wronged you will be gone

**Jeff Bergosh**: Sallysall

**Jeff Bergosh**: Gary-- check this out.  This is the program Sally and I have been using.  First part of the week is tough but it's doable and it works.  You may want to consider giving it---or something very similar--- a try for a couple of weeks and watch the pounds come off.  This morning I weighed 183.6 pounds as I stepped into the shower

### CONVERSATION ON 07-10-2021

**Jeff Bergosh**: I’ll do a blimp crashing into the water tower and it will have Dandy and Lisa riding on top.  It will say 


“they were trying to get free advertising at the air show but not unlike their business model —their flight skills led to a disastrous calamity!”

**Jeff Bergosh**: What do u think?

### CONVERSATION ON 07-11-2021

**Jeff Bergosh**: I got to assume it was a wrong number or a pocket dial.

**Jeff Bergosh**: Me and mom are enjoying it

**Jeff Bergosh**: Bang there goes another

**Jeff Bergosh**: Wow!!  Big win for the bucks!!

**Jeff Bergosh**: First full NBA game I’ve watched in 10 years!

### CONVERSATION ON 07-12-2021

**Jeff Bergosh**: That’s odd

### CONVERSATION ON 07-13-2021

**Jeff Bergosh**: It’s always something— but it will be there tomorrow and you can get them knocked out one by one

**Jeff Bergosh**: Hey Austin have you heard any word about Sorrento? And the turn into the country club there?

### CONVERSATION ON 07-14-2021

**Jeff Bergosh**: From my contact at TPO:

**Jeff Bergosh**: Here’s what I uncovered:

Fdot has a resurfacing projected scheduled for February 2022. In that project the intersection will be addressed. There will be added paved shoulders to allow for a wider turning radius. Also the slope on travel lanes will be adjusted to make for a smoother transition across southbound lanes and onto Doug Ford dr.  



**Jeff Bergosh**: Milwaukee starting out sluggish

**Jeff Bergosh**: In following up from the coffee meeting today— I spoke With my wife Sally who runs the Health and Hope Clinic and she just got a shipment of more Narcan and would happily give you a lot of doses of it for your men to have in their cruisers. I gave her your cell phone number so she could give you a call do you have time to speak with her about it?

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Brandon— where r u?

**Jeff Bergosh**: $1,100 chk.  $1000 sac

**Jeff Bergosh**: Nobody reads that paper anyway so but I would be curious to see what it looks like

**Jeff Bergosh**: 1-850-885-3726 Ronnie hill

**Jeff Bergosh**: 1-850-885-3726 Ronnie hill

**Jeff Bergosh**: I’m in a meeting I’ll call you right back

**Jeff Bergosh**: Thx

**Jeff Bergosh**: I am in a meeting I will call u back

### CONVERSATION ON 07-17-2021

**Jeff Bergosh**: Congratulations Robert on a great ceremony!

**Jeff Bergosh**: Hi Phillip—The unit is all keyless entry, the code to the front gate and lobby is #0916, the unit is 2C, the code to it is 2296 If you have any questions at anytime feel free to text or call me. Check in time is anytime after 3:00PM Sunday, tomorrow.   --Jeff, your VRBO host

### CONVERSATION ON 07-19-2021

**Jeff Bergosh**: Debbie can we check with Tanya Gant and the cat about this request?

### CONVERSATION ON 07-20-2021

**Jeff Bergosh**: It’s just they go “day/month/ year”

**Jeff Bergosh**: Instead of “month/day/year””

**Jeff Bergosh**: They still have not collected cash yet

**Jeff Bergosh**: I fell asleep But mom woke me up so I could watch the end

**Jeff Bergosh**: Great finish

**Jeff Bergosh**: Called him

### CONVERSATION ON 07-21-2021

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/07/blog-post_66.html?m=1

**Jeff Bergosh**: He called Andy and Lisa at PNJ and dialed this cartoon up for today.  The Patron

**Jeff Bergosh**: Hey are u on way home soon?  

**Jeff Bergosh**: In mtg will call u right back

### CONVERSATION ON 07-22-2021

**Jeff Bergosh**: Went very well

**Jeff Bergosh**: But we did get two brand new medical directors for EMS 😁👍

**Jeff Bergosh**: So COC will just continue to pull money from paychecks which essentially allows her to reinterpret and void our contract

**Jeff Bergosh**: If so, please send me that.  We are in receipt of a paid for legal opinion so I want to ensure I’m getting the right information

### CONVERSATION ON 07-23-2021

**Jeff Bergosh**: 💥 

**Jeff Bergosh**: Boom!!

**Jeff Bergosh**: How dare him!!!

**Jeff Bergosh**: I guess so

**Jeff Bergosh**: I bet he’s sitting in his office right now taking it out on his poor office help

**Jeff Bergosh**: He’s probably yelling and screaming at them taking it all out on them

**Jeff Bergosh**: 
I have a feeling she’ll be working for the clerk

**Jeff Bergosh**: Yeah she’ll be staying in the building just moving her boxes and office belongings down a couple of floors

**Jeff Bergosh**: That’s my prediction

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Her “Colonel Jessup “ moment:

You’re goddamn right I said it’s illegal it’s illegal!!!!

**Jeff Bergosh**: Wait, what, What do you mean I have to pay 45 allowed it and it’s illegal?

**Jeff Bergosh**: Need 5 min

**Jeff Bergosh**: Front gate is a parking lot

### CONVERSATION ON 07-25-2021

**Jeff Bergosh**: I’m on the way home almost there to make us breakfast :-)

**Jeff Bergosh**: https://floridapta.org/resolutions-bylaws-lc2021/

**Jeff Bergosh**: Okay I guess you got tied up.... I’m going to start dinner and my relax mode portion of the day....we can do the newsletter one night this week or next weekend😉😉🤪🤪

### CONVERSATION ON 07-26-2021

**Jeff Bergosh**: I’m just about to leave the office and could meet you there

**Jeff Bergosh**: Love u

**Jeff Bergosh**: Love u ❤️❤️❤️❤️

**Jeff Bergosh**: Is it the “umbrella roaming client”

**Jeff Bergosh**: “Cyber ark identity system tray”

**Jeff Bergosh**: But I’m willing to look at it given her proclivity for jumping into our lane

**Jeff Bergosh**: I’m liking Gary Salmons more and more I like the way he doesn’t put up with Hymie’s crap

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Laughed at “Queen of Conflation”

**Jeff Bergosh**: We'll get it sorted out!

### CONVERSATION ON 07-27-2021

**Jeff Bergosh**: 👍

**Jeff Bergosh**: How about blaming the fucking hospitals who's own staff's are 50% unvaccinated?

**Jeff Bergosh**: How about blaming the fucking dip shits who won't get vaccinated?

**Jeff Bergosh**: Call them out you know the segment of the population that has the most hesitancy call them out

**Jeff Bergosh**: And on the communities that are not getting vaccinated do you know who they are although it's not politically correct to say it?

**Jeff Bergosh**: Just kidding

**Jeff Bergosh**: I wonder if Doug will actually pay Ed or if he’ll stiff him like all the legal fees?

**Jeff Bergosh**: Dildo Doug and Cox stick cotton to peas in a pod

### CONVERSATION ON 07-28-2021

**Jeff Bergosh**: This is the first I’ve heard about any dance recital

**Jeff Bergosh**: No.

**Jeff Bergosh**: I was in with the P&Es and didn’t have my phone

**Jeff Bergosh**: Okay thanks— there’s the call in number— just let Andrew know you’re sitting in on eLe’s behalf

### CONVERSATION ON 07-29-2021

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Hey— be careful on the drive home!!  The sky just opened up and it is storming!

**Jeff Bergosh**: Heather-  I was looking for u where did u go?  I nee

**Jeff Bergosh**: I need u to send me the reports once u close the job I put on your desk

**Jeff Bergosh**: Let's give it 15 or 20 minutes then re engage it 👍🙂

**Jeff Bergosh**: AC service will be out to the unit today.  I'm waiting for precise time but they have a few calls stacked ahead.  They'll need to access the unit to check the air handler in addition to checking the unit on the roof so again, I'll let u know when they're on the way--will probably be in afternoon.

### CONVERSATION ON 07-30-2021

**Jeff Bergosh**: Check out the first couple of pages then skip down to the last few pages

**Jeff Bergosh**: It’s a scholarly piece on hospital “rounding” and “scripting”

**Jeff Bergosh**: It’s scathing

**Jeff Bergosh**: https://docs.google.com/document/d/16eBjlJIv6JJ0PbDtn34uO2AnPJXBjnPNItUI2mSKyZg/edit?fbclid=IwAR12kLkFzlS7yyRSyGxYKyi0FS1FDhnMCFLMHdL4DBwLZJqJ4kk--tUrNFg

**Jeff Bergosh**: Then check this out:

**Jeff Bergosh**: https://www.pnj.com/story/opinion/columnists/2021/07/30/andy-marlette-column-could-escambia-county-florida-commissioners-end-up-wheel-fugitives/5415964001/

**Jeff Bergosh**: False light??

**Jeff Bergosh**: I don’t take the plan, they know it, yet the put my picture in the article insinuating I am a “criminal”

**Jeff Bergosh**: https://www.pnj.com/story/opinion/columnists/2021/07/30/andy-marlette-column-could-escambia-county-florida-commissioners-end-up-wheel-fugitives/5415964001/

**Jeff Bergosh**: In today’s paper

**Jeff Bergosh**: Not about me I’m not even mention in the article but of course he put my picture up there

**Jeff Bergosh**: I also corrected him on some things he said on citizens watch about me so it was contentious for a minute there

**Jeff Bergosh**: But then we actually had a pretty decent conversation after

**Jeff Bergosh**: Just voted by everyone in the whole county because decisions Stephan makes and decisions I make affect the whole county.

**Jeff Bergosh**: Currently 4/5 of the County voters are disenfranchised

**Jeff Bergosh**: That’s the stark reality

**Jeff Bergosh**: Mcarro@svn.com

**Jeff Bergosh**: On way.  

**Jeff Bergosh**: Okay I just returned it for correction

**Jeff Bergosh**: This paper is a piece of shit

**Jeff Bergosh**: I think he was embarrassed

**Jeff Bergosh**: Already did

**Jeff Bergosh**: Did he turn on Grover??? I thought he worshiped Grover carried his jockstrap and rode his nuts???

**Jeff Bergosh**: That makes sense

**Jeff Bergosh**: Problem is— he’s a pimp

**Jeff Bergosh**: He’d put someone else up

**Jeff Bergosh**: To take his fall

**Jeff Bergosh**: What a fake he is

**Jeff Bergosh**: David—we have ammunition. But we’re being told we can’t publish it

**Jeff Bergosh**: Yes

**Jeff Bergosh**: “Con man”

**Jeff Bergosh**: That’s what they said

**Jeff Bergosh**: Nothing unflattering will ever be published about him ever. Even if he’s caught fucking a horse on Palafox Street

**Jeff Bergosh**: Thanks a lot!

**Jeff Bergosh**: My satisfaction comes from beating his crypto-candidates he runs against me— like Jonathan 

**Jeff Bergosh**: Ira I need for you to enter your time in the online timesheet for me pleas

**Jeff Bergosh**: Ira— didn’t u take PTO this week?

**Jeff Bergosh**: https://www.pnj.com/story/opinion/columnists/2021/07/30/andy-marlette-column-could-escambia-county-florida-commissioners-end-up-wheel-fugitives/5415964001/

**Jeff Bergosh**: We are going to continue to absorb body shots and elbows to the face until we go on offense with the opinion we have in our pocket.  

**Jeff Bergosh**: What I find troubling is this paper consistently engages in actual malice by putting me in a false light. How do they do that? Well——- I don’t even take this plan I never have and yet there’s my fucking picture. Doug doesn’t take the plan yet they don’t put his fucking picture in the paper. Actual malice false light......Sullivan versus New York Times needs to be revisited

**Jeff Bergosh**: Just level with me:  is this a confidence issue?  Are you not confident in what we were given in that July 22nd memo?  If so, please tell me that’s the reason for holding back

**Jeff Bergosh**: Can u take a call at 7:45?

**Jeff Bergosh**: It’s about Selover

**Jeff Bergosh**: And something Charlie apparently wrote in a memo.  I need to get to the bottom of it

**Jeff Bergosh**: Call me when you get this please

**Jeff Bergosh**: Important

**Jeff Bergosh**: I need for you to correct your time sheet you put down leave without pay but you meant to take PTO right?

### CONVERSATION ON 07-31-2021

**Jeff Bergosh**: Just let us know we love you!

### CONVERSATION ON 08-01-2021

**Jeff Bergosh**: My app can not communicate with the AC

**Jeff Bergosh**: Is it 71 degrees in there right now?

**Jeff Bergosh**: I picked up some heavy duty high-speed fans that I'm going to bring by for you guys. I know the text said the AC is working but it's so hot I want you guys to have fans that help you sleep comfortably. I should be there in about 45 minutes. 👍🙂

**Jeff Bergosh**: I’d like to get your take on it off the record— I won’t say I’ve spoken to you —-then I’ll ask questions of PS Director Gilmore separately and get his take

**Jeff Bergosh**: Got to figure Beulah out

### CONVERSATION ON 08-02-2021

**Jeff Bergosh**: AC is working just fine!!

**Jeff Bergosh**: Can’t find one

**Jeff Bergosh**: Not all parts of Mississippi are that bad

### CONVERSATION ON 08-03-2021

**Jeff Bergosh**: And the transcripts to which you are referring are the shade meeting transcripts of the board?

**Jeff Bergosh**: Or the deposition transcripts?

**Jeff Bergosh**: The truly scary thing that I’m very worried about is the federal government attempting to nullify local government codes and zoning

**Jeff Bergosh**: Which would allow high density low income housing to be put next to nice subdivisions etc.

**Jeff Bergosh**: Hi Joy—The condominium unit is all keyless entry, the code to the front gate and lobby is #0916, ( and it is five individual keystrokes- #. 0. 9. 1. 6. )the unit is 2C, the entry code to the unit’s front door is 2296.  If you have any questions at anytime during your stay ---please feel free to text or call me. Check in time is anytime after 3:00PM Wednesday, tomorrow.   --Jeff, your VRBO host.  

Please let me know you’ve received this,  and have a safe trip over to the beach.  thanks!

### CONVERSATION ON 08-04-2021

**Jeff Bergosh**: Your boy Marlette

**Jeff Bergosh**: If it happened the way you say it happened

**Jeff Bergosh**: Meanwhile— Andy’s cartoon from today LOL

**Jeff Bergosh**: At least I’m not in this one!!

**Jeff Bergosh**: Nick just got home!

**Jeff Bergosh**: Today’s cartoon.  Are we still sure we don’t want to release our opinion? I mean at least I’m not in this cartoon this time but he is running you and Steven down and I believe he and Lisa Savage will continue to do so. Perhaps we need to discuss this whether or not to release our opinion at tomorrow’s meeting? As a matter fact let’s go ahead and do that: please add a discussion item for a board discussion on whether or not to release our opinion to your portion of the agenda tomorrow. It’s time to go on offense and I wanna be on the record supporting that

### CONVERSATION ON 08-05-2021

**Jeff Bergosh**: I thought for a minute there you were gonna close it with and she says it’s yours

**Jeff Bergosh**: Do I just need to buy you your own Napster subscription? Lol

**Jeff Bergosh**: Where's Lumon?  We're about to vote on OLF 8 and   A 2-2 doesn't move 

**Jeff Bergosh**: But I won't😎

### CONVERSATION ON 08-06-2021

**Jeff Bergosh**: I’ll send you the address and phone number

**Jeff Bergosh**: You can come by the house I got a shit load of it

**Jeff Bergosh**: And you should quarantine at our house so you can at least see Nicky before he leaves

### CONVERSATION ON 08-07-2021

**Jeff Bergosh**: What’s happening?  Are you still not feeling well?

**Jeff Bergosh**: Hi Justin—The condominium unit is all keyless entry, the code to the front gate and lobby is #0916, ( and it is five individual keystrokes- #. 0. 9. 1. 6. )the unit is 2C, the entry code to the unit’s front door is 2296.  If you have any questions at anytime during your stay ---please feel free to text or call me. Check in time is anytime after 3:00PM Sunday, tomorrow.   

--Jeff, your Pensacola Beach AirBnB host.  

Please let me know you’ve received this,  and have a safe trip over to the beach.  thanks!

### CONVERSATION ON 08-09-2021

**Jeff Bergosh**: Now please exit Napster so I can continue exercising :-)

**Jeff Bergosh**: They’re not yours I bought them at the waterfront rescue Mission thrift store

**Jeff Bergosh**: I’m on the line

**Jeff Bergosh**: Heather/Tim— I need your hard copy time sheets for last week.

Thanks!

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: Another topic we probably should not discuss

**Jeff Bergosh**: But every white person isn't a racist

**Jeff Bergosh**: And I don't associate with people who are racist

**Jeff Bergosh**: And the vast majority of folks in this community are not racist

**Jeff Bergosh**: But a lot of us will not swallow CRT bullshit and white privilege bullshit and be ashamed of how we were born.

**Jeff Bergosh**: Nor should we

**Jeff Bergosh**: BTW— that post and your comment is still up on ECW— just checked and was able to see it using a sock puppet account

**Jeff Bergosh**: Hey Danny great talking to you and I appreciate you being able to take this on Thursday.

The address for the condo is: 1200 Fort Pickens Road unit 2-C. The name of the complex is Tristan Towers

**Jeff Bergosh**: Code to get in gate and lobby is #0916

Unit code is 2296

**Jeff Bergosh**: Venmo is the payment app

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: That’s why I’m here so let’s

**Jeff Bergosh**: Hey someone from that office is going to call you I've given them your number

**Jeff Bergosh**: Are you going to cover it?  I hope you do

**Jeff Bergosh**: It was Marcel Davis that said it

### CONVERSATION ON 08-12-2021

**Jeff Bergosh**: Are you okay with that?

**Jeff Bergosh**: It’s going to go live in about 15 minutes!!

**Jeff Bergosh**: PNJ has it

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: They all get passes except Trump and Gaetz

**Jeff Bergosh**: Biden got a huge pass on his harassment charge too

**Jeff Bergosh**: Property manager Tristan Towers

**Jeff Bergosh**: But if you are still interested I’ll turn that off

**Jeff Bergosh**: I have it listed on Zillow

**Jeff Bergosh**: Hey Jaron!  Just checking in, I hope you’re feeling better.  Also, if there’s any way you can log into the online system to enter your time that’d be great.  Just enter 8 hrs regular for Monday, and for the rest of the week they should have added a special category of FMLA PTO

**Jeff Bergosh**: Sorry about all the pictures but that was the only way to get the entire article copied the way the news journal puts it on their site mixed in with advertisements.

### CONVERSATION ON 08-14-2021

**Jeff Bergosh**: Coming up in 5

### CONVERSATION ON 08-15-2021

**Jeff Bergosh**: Let her stew on that for a while lol

**Jeff Bergosh**: On Sunday

**Jeff Bergosh**: Gate code and front door code.   Five keystrokes 

#. 0. 9.  1.  6. 

Condo unit is 2-C

Code for condo is 

2296

**Jeff Bergosh**: Complex  is Tristan towers 

**Jeff Bergosh**: Hello Francesca,  I’m going to forward the condo information to you on this number ahead of your arrival at Pensacola Beach tomorrow

**Jeff Bergosh**: The condominium unit is all keyless entry, the code to the front gate and lobby is #0916, ( and it is five individual keystrokes- #. 0. 9. 1. 6. )the unit is 2C, the entry code to the unit’s front door is 2296.  If you have any questions at anytime during your stay ---please feel free to text or call me. Check in time is typically anytime after 3:00PM tomorrow, Monday, however we have the unit cleaned and ready to go ——so feel free to check in anytime tomorrow after 8:00AM 🙂

—Jeff, your Pensacola Beach AirBnB host.  

Please let me know you’ve received this,  and have a safe trip over to the beach.  thanks!

### CONVERSATION ON 08-16-2021

**Jeff Bergosh**: “Chains of command”

### CONVERSATION ON 08-18-2021

**Jeff Bergosh**: Hey Brandon call me when you can so we can talk about your tuition and getting that paid and worked out. Love you

**Jeff Bergosh**: Their cartoon

**Jeff Bergosh**: My response

**Jeff Bergosh**: “TRUST ME!!”

**Jeff Bergosh**: I’m on the call

**Jeff Bergosh**: Better rendition here

**Jeff Bergosh**: I think I’m gonna call them out at this meeting on Thursday and just hold up a big picture of his cartoon were used the N-word I’ll just say this is the guy were talking about white privileged and can use the N-word with no repercussions

**Jeff Bergosh**: I’d think Lumon would be pissed off and outraged that Marlette used the N-word!

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: She will work with Alison on language 

**Jeff Bergosh**: Fucking file it

**Jeff Bergosh**: And get us past this is what we should do

**Jeff Bergosh**: Write of mandamus

**Jeff Bergosh**: Bullshit

**Jeff Bergosh**: If illegal- judge will deny it

**Jeff Bergosh**: Not a peep from my peers

### CONVERSATION ON 08-20-2021

**Jeff Bergosh**: Email for the package

**Jeff Bergosh**: But send it tomorrow or Monday if possible

**Jeff Bergosh**: Running 5 min. Late

**Jeff Bergosh**: I’ll send you the codes tomorrow afternoon

**Jeff Bergosh**: Have a safe trip!

### CONVERSATION ON 08-21-2021

**Jeff Bergosh**: Yes- on court rn

**Jeff Bergosh**: Last of the condo laundry just went in dryer— once I bag it I’ll be on my way back to the condo👍🙂❤️

**Jeff Bergosh**: But only for a quick stop

**Jeff Bergosh**: 1200 Fort Pickens Road # 2-C  Pensacola Beach Florida 32561

**Jeff Bergosh**: Hello Julie: The condominium unit is all keyless entry, the code to the front gate and lobby is #0916, ( and it is five individual keystrokes- #. 0. 9. 1. 6. )the unit is 2C, the entry code to the unit’s front door is 2296.  If you have any questions at anytime during your stay ---please feel free to text or call me. Check in time is typically anytime after 3:00PM tomorrow, Sunday,  however as we discussed earlier —we will the have the unit cleaned and ready to go at 1:00 PM so feel free to check in anytime tomorrow after 1:00 PM🙂

—Jeff, your Pensacola Beach AirBnB host.  

Please let me know you’ve received this,  and have a safe trip down to the beach.  thanks!

### CONVERSATION ON 08-22-2021

**Jeff Bergosh**: The cleaners are inside finishing

**Jeff Bergosh**: I told them to be done by 1:00 so you could check in 2 hours early —. But they need every bit of that time to get the unit ready for you

**Jeff Bergosh**: Paradise!!

**Jeff Bergosh**: Found it!  I’m headed that way with the spare! 🙂

### CONVERSATION ON 08-23-2021

**Jeff Bergosh**: All about Parents

**Jeff Bergosh**: Including Weis elementary where Sally worked for five years

**Jeff Bergosh**: Those teachers killed them selves bent over backwards like circus contortionists to help those students and that community

**Jeff Bergosh**: Makes people skeptical and when people are skeptical they think nefarious conduct is happening

**Jeff Bergosh**: Yes- 

### CONVERSATION ON 08-24-2021

**Jeff Bergosh**: I thought you owned this domain? You probably need to check and make sure it gets renewed before you lose it if you still want it

**Jeff Bergosh**: Randy called me Randy Hamilton and said he checked your domain and it’s registered from a company called named juice.com and he believes dan.com is not a scam it might be a real sight so you may want to make a phone call and just call them and see

**Jeff Bergosh**: Namejuice.com

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: Matt— this document was just released to me via a public records request.  Is this legit?

**Jeff Bergosh**: Was he currying favor with Jana

**Jeff Bergosh**: I’ll check again 

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: Why are you battling me on my Napster?

**Jeff Bergosh**: Also mom and I are going to kick in 200 a month toward your rent

**Jeff Bergosh**: In today’s paper, obituary section....

**Jeff Bergosh**: Or did he have it and not use it

**Jeff Bergosh**: I think it’s a pretty damning indictment of Janice still and Jimmy Maddrey

### CONVERSATION ON 08-26-2021

**Jeff Bergosh**: https://apnews.com/article/europe-france-evacuations-kabul-9e457201e5bbe75a4eb1901fedeee7a1

**Jeff Bergosh**: Can u believe this??!!???

**Jeff Bergosh**: I told him your pissed off

**Jeff Bergosh**: You’re 

**Jeff Bergosh**: How about those families

**Jeff Bergosh**: Hello Joshua-- just attempting to follow up with you on my dryer and paying your invoice for the service call.  Were you able to get the dryer working again?  What was wrong with it?  Thanks!

Jeff Bergosh 

**Jeff Bergosh**: Go ahead and fix those issues;  I'll schedule the duct cleaning

### CONVERSATION ON 08-27-2021

**Jeff Bergosh**: I'll call u right back

**Jeff Bergosh**: And if this is going to alter her life an I’ll advised decision about a dog —-then maybe it was a good thing. 

**Jeff Bergosh**: She knows we love and support her but I’m not gonna enable her bad choices bad decisions particularly when they’re going to impact me and you maybe she needs to move out

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Where are you I need the cart

**Jeff Bergosh**: ???????

**Jeff Bergosh**: Hey Gary quick question for you. I see were each of the three wires goes from the old plug into the new plug. But inside the box for the old plug appears to be a fourth wire just sitting there not attached to anything it looks like a ground wire how should I treat that when I put the new plug outlet in?

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: 8:15 is okay

**Jeff Bergosh**: Sounds like ballpark prices!!

**Jeff Bergosh**: John-- I need your hard copy time sheet

### CONVERSATION ON 08-31-2021

**Jeff Bergosh**: Rooms to go is giving me the runaround and saying there’s nothing they can do they can’t deliver till at least the 15th of this month. Spoke to the manager they can none of them can do anything. Do you want to get a refund and start all over again?

### CONVERSATION ON 09-01-2021

**Jeff Bergosh**: What about something like this?

**Jeff Bergosh**: Contender?

**Jeff Bergosh**: This one looks great— even has grey seat cushions!

**Jeff Bergosh**: What about black?

**Jeff Bergosh**: How about 2 benches, Grey and black 4-Person set?

**Jeff Bergosh**: Did you have any difficulty at customs?

### CONVERSATION ON 09-02-2021

**Jeff Bergosh**: Jeffbergosh@gmail.com

Autumn2012

**Jeff Bergosh**: New password I just changed it

**Jeff Bergosh**: It’s getting close

**Jeff Bergosh**: I’m going by the house first— to get the mail

**Jeff Bergosh**: On last item

**Jeff Bergosh**: I’m here at house what can I grab for u?

**Jeff Bergosh**: We just censured Doug at tonight's meeting by a 4-1 vote.  I made the motion.  He threatened our Attorney, so she brought a document memorializing Doug's threats.  He was Censured.

**Jeff Bergosh**: Here is Alison's letter to the board 

### CONVERSATION ON 09-03-2021

**Jeff Bergosh**: Thought u did this yesterday

**Jeff Bergosh**: Tim call me— trying to reach you

**Jeff Bergosh**: https://www.podomatic.com/podcasts/rick9662/episodes/2021-09-03T06_55_36-07_00

**Jeff Bergosh**: Heather can you please ask Tim to complete the online timesheet for August 31 and for the end of this week? I texted him but I don’t think he got my text but I need to get this done for the end of the month in Huntsville

**Jeff Bergosh**:  Be be Bridlewood and Swanee construction 

**Jeff Bergosh**:  Be be Bridlewood and Swanee construction 

**Jeff Bergosh**: "Chango" is the one I like

### CONVERSATION ON 09-06-2021

**Jeff Bergosh**: Guess where I am?

**Jeff Bergosh**: Great podcast rick!  Thanks for calling out the PNJ on  their BS stance about a lack of leadership on the board.  We do have a lack of leadership locally;  it’s not elected “board” officials though.  It’s a leadership deficit in the editorial “board” of the monopolistic daily paper 😎👍👌

**Jeff Bergosh**: You may be interested in this— The clerk and her lawyer sent an ultimatum to us on Friday.  Posted the document in this blog post.

**Jeff Bergosh**: Now suddenly they want an alternative dispute resolution mechanism

### CONVERSATION ON 09-07-2021

**Jeff Bergosh**: Let’s see how I’m doing later on today and tomorrow first.  The point is, I have to be careful about my symptoms and my job out here.  I have to sign a sheet every day attesting that I don’t have symptoms.  This morning when I got here I signed it, truthfully.  But as the day has worn on I’ve begun to feel unwell— so I’m in my office with door closed and I certainly don’t want to be on that dais tonight if there’s any chance of spreading something.   I have to be responsible

**Jeff Bergosh**: I’m probably bolting for home at 3:30 and not looking back and we’ll see how I’m feeling in the morning.

**Jeff Bergosh**: Keep this between us only please 

**Jeff Bergosh**: Don’t want anyone to think I came to work sick knowingly— because I didn’t and wouldn’t

**Jeff Bergosh**: .......in the era of COVID

**Jeff Bergosh**: Better to be safe than sorry

### CONVERSATION ON 09-08-2021

**Jeff Bergosh**: Negative on the home test, too

**Jeff Bergosh**: Got 9 1/2 hours sleep, feel like I could climb Mt Everest today LOL

**Jeff Bergosh**: I’m working on September Newsletter.  Getting some good ideas from Facebook to add.  Send me anything else you want me to put in there.  Love u!!

### CONVERSATION ON 09-09-2021

**Jeff Bergosh**: 27 is his anniversary

**Jeff Bergosh**: What’s her full name?

**Jeff Bergosh**: Barbara ______________?

**Jeff Bergosh**: ????

**Jeff Bergosh**: Never mind I found it in your email.  Barb Freeman

**Jeff Bergosh**: Just sent you a preview email 😎❤️👍

### CONVERSATION ON 09-10-2021

**Jeff Bergosh**: So you can call them and pay it off ❤️😎👍

**Jeff Bergosh**: Thurs through Tuesday

**Jeff Bergosh**: December too cold

**Jeff Bergosh**: I booked Stanley steamer to come to the condo next Wednesday between 12 and three to steam clean the white couch

**Jeff Bergosh**: That way it’s really clean before your parents arrive

**Jeff Bergosh**: October 7-12 work for Copenhagen?

**Jeff Bergosh**: We can fly on those dates round trip, both of us, for just $756.50

**Jeff Bergosh**: Incredible price

**Jeff Bergosh**: I’m booking it 👍👍❤️❤️👍👍❤️❤️

**Jeff Bergosh**: We’re going to Copenhagen!!

**Jeff Bergosh**: Hey Nick I’m looking at budgeting for me and mom to come visit you in mid November will you have any type of a break at that point where we could hang out?

**Jeff Bergosh**: I’m looking on that Google flight site and there’s some pretty good deals

**Jeff Bergosh**: Hey Tori there should be a package from Amazon on the front door will you please bring it in before you leave for work tonight?

**Jeff Bergosh**: Thank you!

### CONVERSATION ON 09-11-2021

**Jeff Bergosh**: Hey Sally— when you go to play tennis— the lock box combination on the gate is 1-9-8-5

### CONVERSATION ON 09-12-2021

**Jeff Bergosh**: 11 3/4” x   5 1/2”

**Jeff Bergosh**: 11 3/4” x   5 1/2”

**Jeff Bergosh**: Hey we’re barbecuing steak tonight at the condo you’re both invited if you’d like to come we’re going to cook it and eat at 6:30 just let me know love you!

### CONVERSATION ON 09-13-2021

**Jeff Bergosh**: Tell her to request one using the 1459 number

**Jeff Bergosh**: Constant Contact: Your verification code is 827348.  This code is valid for 5 minutes.  We'll never contact you to ask for this code.

**Jeff Bergosh**: I didn’t know they put this on social media they contacted my office. via email and I’ve responded

**Jeff Bergosh**: *spainhower

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: Hey Brandon— grandma and Boppa, me, Tori and Mom  are organizing a dinner— are you working Friday night? Or are you available to meet us for dinner at 6:30?

**Jeff Bergosh**: The issue we discussed yesterday-- how is that being addressed? Outside of this meeting?

**Jeff Bergosh**: Unicorn man— u awake?

**Jeff Bergosh**: Bruce Miller is “not happy”

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/09/blog-post_89.html?m=1

**Jeff Bergosh**: On conf call will call u right back

**Jeff Bergosh**: Hey Gary we’re gonna do the cookout Saturday afternoon at 2:30 so if you and Carissa and Ben would like to join us —-just come on out it’s gonna be kind of casual and we’re just going to throw some food on the barbecue and everyone’s going to visit and just hang out.  I invited Aunt Mary but she’s out of town.  Hope you all can make it!

**Jeff Bergosh**: Your guy Cris Dosev just showed up.....

**Jeff Bergosh**: Okay you’re good to go it looks like

**Jeff Bergosh**: ????

**Jeff Bergosh**: Do I have your phone?

**Jeff Bergosh**: He’s a piece of shit

**Jeff Bergosh**: And I will not tolerate any of his bullshit at all

**Jeff Bergosh**: McGuires Sunday?

**Jeff Bergosh**: And Saturday I’ll throw an invitation to Gary and Carissa too

**Jeff Bergosh**: Sunday will be just us though— you ne Tori Brandon and your mom and dad

**Jeff Bergosh**: Uh oh— no tables at Grand Marlin for 6

**Jeff Bergosh**: How about H20

**Jeff Bergosh**: They have a table at 6:30

**Jeff Bergosh**: Okay:  I made the command decision and made the reservation at grand Marlin for Sunday for six people because Brandon can make it Sunday we’ll have dinner at 5:45 and I’ve got the reservation.

**Jeff Bergosh**: Tomorrow and Thursday yes

**Jeff Bergosh**: Hoping for good news this week 

**Jeff Bergosh**: Its
$0

**Jeff Bergosh**: Hey Aunt Mary!  Sally and I are planning a cookout this Saturday afternoon at 2:30-3:00ish our at our condo on the beach and we wanted to invite you to join us if you’re available.  Sally’s folks are in town from San Diego, and I’m inviting Gary and Carissa as well.  It will be a lot of fun— and we’ve all had our COVID shots LOL.  Let me know— hope you can make it!

### CONVERSATION ON 09-15-2021

**Jeff Bergosh**: Doug issued a press release about the meeting yesterday calling me a meanie LOL

**Jeff Bergosh**: Can you believe that fucking tool?

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: I’m gonna turn this around on

**Jeff Bergosh**: It’s my understanding mainly what we’re going to get is some gusts but not real strong and a lot of rain

**Jeff Bergosh**: I’ll take care of it

**Jeff Bergosh**: Is the flight on time?

**Jeff Bergosh**: ?

**Jeff Bergosh**: Doug just released this “Press Release”. LOL,  I think he should’ve sent it to the onion or the Babylon Bee

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: Ronda Wood
7030 Nathan Rd
32526
850-712-8237
Thank you

**Jeff Bergosh**: Please have staff coordinate a response

**Jeff Bergosh**: In BCC meeting

**Jeff Bergosh**: Tori take a look at the front door— some female lady just came up and looked in the window

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-17-2021

**Jeff Bergosh**: Debbie please have staff make contact with miss Wood about these issues in these pictures thank you

**Jeff Bergosh**: Hey Brandon can you give me a call when you have a minute I have to ask you about Christmas we’re trying to make some reservations to go to San Diego love you

### CONVERSATION ON 09-19-2021

**Jeff Bergosh**: Ok

### CONVERSATION ON 09-20-2021

**Jeff Bergosh**: He was full of shit and we all knew it

### CONVERSATION ON 09-21-2021

**Jeff Bergosh**: Debbie— please call her and assist her with this information about the contact number for the roads crew

**Jeff Bergosh**: I’ll call u back finish meeting

**Jeff Bergosh**: How is your Dad?

### CONVERSATION ON 09-22-2021

**Jeff Bergosh**: Meadow Field Circle and Beulah Road

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: POS

**Jeff Bergosh**: Andy’s version……

**Jeff Bergosh**: In safety meeting will call u back

**Jeff Bergosh**: Just a reminder we have safety training today at 11:40 in the transportation compound

**Jeff Bergosh**: Just a reminder we have safety training today at 11:40 in the transportation compound

**Jeff Bergosh**: Just a reminder we have safety training today at 11:40 in the transportation compound

### CONVERSATION ON 09-24-2021

**Jeff Bergosh**: https://youtu.be/0JPRvxTjfOk

**Jeff Bergosh**: https://youtu.be/0JPRvxTjfOk

**Jeff Bergosh**: LOL

### CONVERSATION ON 09-28-2021

**Jeff Bergosh**: I’m going on Rick Outzen’s show in 5 minutes to discuss the EMS debacle

**Jeff Bergosh**: 1370 WCOA

**Jeff Bergosh**: At 7:10

**Jeff Bergosh**: Good luck in your match tonight love you!!

**Jeff Bergosh**: Got a lot packed up tonight, including the bikes👍❤️

### CONVERSATION ON 09-29-2021

**Jeff Bergosh**: He’s going to support HHC Christmas at the clinic

**Jeff Bergosh**: Send him a package

**Jeff Bergosh**: Here’s something interesting:  when I went to link yesterday’s podcast to my blog I found out IT has blocked access to podomaric. LOL

**Jeff Bergosh**: https://www.pnj.com/story/news/local/escambia-county/2021/09/29/escambia-county-may-outsource-medical-care-county-jail-inmates/5898129001/

### CONVERSATION ON 09-30-2021

**Jeff Bergosh**: Have fun without me LOL but do not drink and drive

### CONVERSATION ON 10-01-2021

**Jeff Bergosh**: Soft toss

**Jeff Bergosh**: I went to get ultrasound yesterday……..

**Jeff Bergosh**: Are you all calling AAA?

**Jeff Bergosh**: I’ll transfer the money to your red card

**Jeff Bergosh**: 
Maybe that’s what it costs with tax tag freight and shipping

**Jeff Bergosh**: No blood clot in my calf

**Jeff Bergosh**: He ain’t going to like my proposal, LOL

**Jeff Bergosh**: But I don’t care

**Jeff Bergosh**: I just hope that Lumon and Stephan will support my map which reflects the wishes of Kevin Adams and Vicki Campbell as well

**Jeff Bergosh**: Open meeting

**Jeff Bergosh**: If he and Stephen do the one precinct swap

**Jeff Bergosh**: It would really be helpful if you could speak with Lumon about that of course don’t tell me what he says LOL

**Jeff Bergosh**: And if you could speak with Steven that would be greatly appreciated but absolutely don’t tell me what he says LOL

**Jeff Bergosh**: Hey Jaron sorry to bug you again but I need you to correct your time sheet you put down leave without pay when you should’ve put PLP

**Jeff Bergosh**: Cheaney@escambiasoe.com

**Jeff Bergosh**: Cheaney@escambiasoe.com

**Jeff Bergosh**: Should I call Sonja?

### CONVERSATION ON 10-03-2021

**Jeff Bergosh**: I’m starting dinner 🙂it will be ready at about 7:15.  Sound good?

### CONVERSATION ON 10-04-2021

**Jeff Bergosh**: VRBO/2303929

**Jeff Bergosh**: https://www.vrbo.com/2303929

**Jeff Bergosh**: We got wrecked with the change

**Jeff Bergosh**: We will need to probably head to your place initially as we can’t check in to the Airbnb until 1500

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: Any schools there?

### CONVERSATION ON 10-06-2021

**Jeff Bergosh**: At that website

**Jeff Bergosh**: Bearfamilyfoundation.org

**Jeff Bergosh**: Jenifer Gosh

**Jeff Bergosh**: Dave- just letting you know that because Tim is out until the 12th you’ll be the on-call CET until then.  So on your paycheck you’ll get that pay for the days Tim is/was unavailable to be on call.  Wednesday 10-6 through Monday 10-11

### CONVERSATION ON 10-07-2021

**Jeff Bergosh**: It’s not always a structural issue; often it’s the people

**Jeff Bergosh**: Oct. 13th

### CONVERSATION ON 10-08-2021

**Jeff Bergosh**: Emily I heard back from the property manager.  The codes are in the computer she has assured me.  Just please ensure you're using five keystrokes with the # sign first

# 7 7 7 7

Should work front gate for parking and front door of building.  Any issues on the codes in my absence while I'm in Europe please call Linda Watson, property manager, for assistance.  Appreciate your patience with this.....

Jeff B

**Jeff Bergosh**: Hi Emily I was traveling yesterday and I'm in Copenhagen and just got your message today.  I spoke with Linda Watson on Tuesday, copied to this text, and she assured me that she programmed the following codes for the building:  #7777. And #0916.  Additionally, she assured me the problems that were occurring with the codes were limited to the front building entrance and NOT the front gate.  I'll ask her by copy of her on this text to double check this.  Again-- sorry for the inconvenience but #7777 should be working for both and if not we will get that sorted.  I'll be on a train to Sweden tomorrow but should have cell reception and I'll follow up.  Sincerely

Jeff Bergosh

**Jeff Bergosh**: Hi Emily I was traveling yesterday and I'm in Copenhagen and just got your message today.  I spoke with Linda Watson on Tuesday, copied to this text, and she assured me that she programmed the following codes for the building:  #7777. And #0916.  Additionally, she assured me the problems that were occurring with the codes were limited to the front building entrance and NOT the front gate.  I'll ask her by copy of her on this text to double check this.  Again-- sorry for the inconvenience but #7777 should be working for both and if not we will get that sorted.  I'll be on a train to Sweden tomorrow but should have cell reception and I'll follow up.  Sincerely

Jeff Bergosh

**Jeff Bergosh**: Hi Emily I was traveling yesterday and I'm in Copenhagen and just got your message today.  I spoke with Linda Watson on Tuesday, copied to this text, and she assured me that she programmed the following codes for the building:  #7777. And #0916.  Additionally, she assured me the problems that were occurring with the codes were limited to the front building entrance and NOT the front gate.  I'll ask her by copy of her on this text to double check this.  Again-- sorry for the inconvenience but #7777 should be working for both and if not we will get that sorted.  I'll be on a train to Sweden tomorrow but should have cell reception and I'll follow up.  Sincerely

Jeff Bergosh

### CONVERSATION ON 10-09-2021

**Jeff Bergosh**: In Denmark I found this dish detergent for you LOL

### CONVERSATION ON 10-10-2021

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Hey Nick we’re running a little slow your mom is having a hard time getting going but we will be there probably a little late probably more like 945-ish

**Jeff Bergosh**: OK we’re here and we’re coming up

### CONVERSATION ON 10-11-2021

**Jeff Bergosh**: In movie

**Jeff Bergosh**: Movie almost over

### CONVERSATION ON 10-12-2021

**Jeff Bergosh**: I just landed in America but was under the impression you were back to work today.

**Jeff Bergosh**: I’m waiting right by the train stop

**Jeff Bergosh**: It’s one stop away

**Jeff Bergosh**: Take escalator to top

**Jeff Bergosh**: Answer your phone

**Jeff Bergosh**: Still in restroom trying to hurry

**Jeff Bergosh**: Having a bit of a stomach issue

### CONVERSATION ON 10-13-2021

**Jeff Bergosh**: I just got home— thanks for unpacking me and starting the laundry!  I’m keeping it going but feel wiped out and will probably be in bed comatose by 8.  Felt great this morning but I’m fading fast LOL

**Jeff Bergosh**: Our flight to Miami from London was empty so I got a row to myself and slept 5 hours

### CONVERSATION ON 10-14-2021

**Jeff Bergosh**: ❤️❤️

**Jeff Bergosh**: Just wrapping up

**Jeff Bergosh**: What's he do??

**Jeff Bergosh**: Tell me what we need to do 

**Jeff Bergosh**: He rides Underhill's nuts like a groupie

### CONVERSATION ON 10-15-2021

**Jeff Bergosh**: ❤️❤️

**Jeff Bergosh**: Thx

### CONVERSATION ON 10-16-2021

**Jeff Bergosh**: I have seat for I

### CONVERSATION ON 10-17-2021

**Jeff Bergosh**: Jeffbergosh@gmail.com all one word

**Jeff Bergosh**: Then go to our VRBO listing and pick a couple of pictures to add 

**Jeff Bergosh**: I’ll send you the link to your email

**Jeff Bergosh**: 
So please send me the picture of Dr Slowinski it’s not in the email you reference it but it’s not attached please send it love you

### CONVERSATION ON 10-18-2021

**Jeff Bergosh**: I need your hard copy time sheets

Thx

**Jeff Bergosh**: https://www.healthandhopeclinic.org

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: I just got off the phone with Bob Sidoti he was in a conference over in New Orleans. He confirmed they are definitely going to sponsor and they’re also working on some door prizes. Bob told me he would contact you personally before the end of the week to hash it all out.

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: From Billy Anderson

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I also just put a call into Freddy Donovan Junior but got his voicemail

**Jeff Bergosh**: When you believe in the product it’s easy to try and go sell it!

### CONVERSATION ON 10-20-2021

**Jeff Bergosh**: Brandon— you need to get a shirt that says “Let’s go Brandon!”

**Jeff Bergosh**: Have you heard about that phrase?  

**Jeff Bergosh**: Someone wrote that on my blog

**Jeff Bergosh**: And I googled it and saw a video it was hilarious 

**Jeff Bergosh**: That sounds like it should be a slogan!  “Cock Block Peacock!!”

**Jeff Bergosh**: “LETS GO BRANDON!!” LOL

**Jeff Bergosh**: See you tomorrow

### CONVERSATION ON 10-21-2021

**Jeff Bergosh**: Debbie— can you do me a favor?

**Jeff Bergosh**: I got distracted when I pulled in and I don’t think I locked my truck

**Jeff Bergosh**: https://m.youtube.com/watch?v=WbZNMTLoGfM#menu

**Jeff Bergosh**: Thought this Matt Damon scene from departed would elicit a smile

**Jeff Bergosh**: Kendrick could’ve taken my call—He was just waiting for permission

**Jeff Bergosh**: At least he came back and answered today

**Jeff Bergosh**: I’m happy to call him just need a telephone number

**Jeff Bergosh**: Call me Guido the collector🎩🎩😎😎👍👍

**Jeff Bergosh**: “ hi have you heard the great news about the Health and Hope Clinic?”

**Jeff Bergosh**: Doug got shut down hard

**Jeff Bergosh**: ……..and it was really fantastic

**Jeff Bergosh**: It reminded me of this scene from the departed

**Jeff Bergosh**: https://m.youtube.com/watch?v=WbZNMTLoGfM#menu

**Jeff Bergosh**: Just sent you the SITREP-- hope you're feeling better Tony!

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 10-22-2021

**Jeff Bergosh**: Today

**Jeff Bergosh**: I’ll get the proof

**Jeff Bergosh**: It was bullshit move to pull Matt

**Jeff Bergosh**: So it all works out in the end but they made a lot of money in Escambia county and they should not to pull that crap a lot of their business is going to get shut down in Escambia county I predict that happening they’ll just have to make it all in Santa Rosa County

### CONVERSATION ON 10-23-2021

**Jeff Bergosh**: Is that from your public records?

**Jeff Bergosh**: It’s like truth serum

**Jeff Bergosh**: And now he gets to play collector

**Jeff Bergosh**: And he’s watching Doug buy things left and right and center

**Jeff Bergosh**: And he’s going to be publicly humiliated

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: In fact I’d be willing to go with Paul’s map

**Jeff Bergosh**: Which would cost me the fairgrounds my library and two schools in Kevin’s district

**Jeff Bergosh**: But I’d pick up a lot of territory on the west side of Pensacola

**Jeff Bergosh**: I hope I can get my compromise map past Paul and the rest of the board if so that’s the perfect map I believe

**Jeff Bergosh**: Double hit both varieties either way equally

**Jeff Bergosh**: Mine’s below it

**Jeff Bergosh**: Doug will get nothing he wants as long as Lumon and Stephen stick with me

**Jeff Bergosh**: Lol

**Jeff Bergosh**: That ain’t up to me

**Jeff Bergosh**: I bet there’s some really interesting stuff in there

### CONVERSATION ON 10-24-2021

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Yes it does 

**Jeff Bergosh**: But setting that aside there is still a difference between Vicki Campbell and Lois Benson ECUA at the most a parent Vickie just won her election less than a year ago. Lois hast to run again in less than a year

**Jeff Bergosh**: Bender pulled a fast one on all of us at first meeting— I just caught it and corrected it

**Jeff Bergosh**: Tuesday, the 26th at 4:00 I’ll see u there

**Jeff Bergosh**: If you're not there and he gets there I'll give him a temp.  Access code to get in and spray.  But I have a feeling he's probably on his way there right now. 

### CONVERSATION ON 10-25-2021

**Jeff Bergosh**: And maps on 11”X17” paper please, or as big as you can make it

**Jeff Bergosh**: Thanks!!

**Jeff Bergosh**: I just booked our Cabo flights— emailed you the confirmation number.

**Jeff Bergosh**: Also by the way Cox cable has requested a meeting with me today at 11:15 on a conference call. The persons name is Kristen Longley. Aren’t they sponsoring Christmas at the clinic? Let me know if they have already sent in their form if not I can put this call off for kicks something down the road

**Jeff Bergosh**: “Thank you for all your gracious support!”

**Jeff Bergosh**: They should do more!

**Jeff Bergosh**: Had a great call with them— Longley and Delliman

**Jeff Bergosh**: And I took the opportunity to thank them for their historic support of the Health and Hope Clinic. And then I went on to list all the positive attributes and the talking points for Health and Hope Clinic.

**Jeff Bergosh**: Going to bed I love you I’ll see you when you come home

**Jeff Bergosh**: ❤️❤️

**Jeff Bergosh**: I'll check my calendar when I get back to the office and let's firm it up

**Jeff Bergosh**: Kevin I sent the invitation via messenger-- wouldn't go through on a text

**Jeff Bergosh**: I need your hard copy time sheets

Thx

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: Ric could pull that costume off though with believability

**Jeff Bergosh**: Tallman did a big segment on Beach Haven this morning... Asmir job on Steven and I and glorification of Doug and Doug's righteousness it was sickening

**Jeff Bergosh**: FYI-- does he still work here?

**Jeff Bergosh**: Separated at Birth?

**Jeff Bergosh**: Going to bed I love you I’ll see you when you come home

**Jeff Bergosh**: It might have some meaning to whoever is interviewing you

### CONVERSATION ON 10-27-2021

**Jeff Bergosh**: I wonder if you shared with his pastor how he lies about me and the other commissioners?

**Jeff Bergosh**: And slanders us online?

**Jeff Bergosh**: No I think on Halloween night I’ll be at my house celebrating Halloween like a normal human does by passing out candy to kids that dress up not trying to make it a church night like freaks the likes of Conor do

**Jeff Bergosh**: But please by all means thank him for the incredibly kind gesture

**Jeff Bergosh**: He meant Perdido I’m sure

**Jeff Bergosh**: Wonder what Bender thinks now?

**Jeff Bergosh**: Good info, good news

**Jeff Bergosh**: I’d ignore it

**Jeff Bergosh**: Andrew “Tallman” McKay and pariah Doug Underhill

**Jeff Bergosh**: I’m sure they’ll be all over social media today with this garbage

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: I’m good I’m parked so you all have fun no rush I have reading I can catch up on

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2021/10/blog-post_41.html?m=1

**Jeff Bergosh**: Good Morning Alex— you might appreciate this blog post. The county is no longer going to use the Pensacola News Journal for legal ads. This will deprive Garnet and the PNJ of more than $100,000 yearly. I bet Christina Pushaw would appreciate what we’re doing. Perhaps other markets could do likewise to Gannett outlets that are feckless and biased.

### CONVERSATION ON 10-29-2021

**Jeff Bergosh**: Need to get 2 more tickets for Gary and Carissa

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: Hey David— great to see you last night at Michelle’s fundraiser.  Looks like it was a big success!  Also— thanks for throwing a Babe Ruth candy bar into dill hole Chance Johnnymeyer’s punchbowl — the stupid post about recall and accountability.  It’s amusing to watch all 5 of the usual tools come out and try to attack you.  Amusing chuckle that produces, so thanks!!!

### CONVERSATION ON 11-01-2021

**Jeff Bergosh**: In meeting will call u back

**Jeff Bergosh**: Sorry I couldn’t answer at the dentist

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 11-02-2021

**Jeff Bergosh**: Just sent you the updated slide for the condo giveaway.  Also—— GREAT press release!!  Fantastic!

**Jeff Bergosh**: Just need the name and contact number for the person who will be in charge of coordinating the parking downtown

**Jeff Bergosh**: Doug got humbled

**Jeff Bergosh**: Again

**Jeff Bergosh**:  I know

### CONVERSATION ON 11-03-2021

**Jeff Bergosh**: Heading to bed… exhausted and huge day tomorrow 

Love u❤️❤️

### CONVERSATION ON 11-04-2021

**Jeff Bergosh**: I'll have to look closer didn't realize that

**Jeff Bergosh**: It sure does!  You're right

**Jeff Bergosh**: And takes us way past the interstate

**Jeff Bergosh**: What does the move of the meeting to next Tuesday do to our Dec. 2nd timeline?

**Jeff Bergosh**: I’m in a BCC meeting

**Jeff Bergosh**: Where are you John?

### CONVERSATION ON 11-05-2021

**Jeff Bergosh**: On with Tim Day

**Jeff Bergosh**: FYI FDOT is all over the bridge issue

**Jeff Bergosh**: Train tressle

**Jeff Bergosh**: Gary Bergosh.   850-698-8094

**Jeff Bergosh**: I need you both to submit your electronic timesheets—for both screens Oct 30-31 and Nov 1-5

**Jeff Bergosh**: Thx

**Jeff Bergosh**: FYI

### CONVERSATION ON 11-06-2021

**Jeff Bergosh**: You on way

**Jeff Bergosh**: No cappuccino sorry

**Jeff Bergosh**: They’re out

**Jeff Bergosh**: Checking out now 

### CONVERSATION ON 11-07-2021

**Jeff Bergosh**: *like

**Jeff Bergosh**: I want to discuss though

### CONVERSATION ON 11-08-2021

**Jeff Bergosh**: Yes there’s going to be a splash down for spaceex tonight off the coast.

**Jeff Bergosh**: Love u

**Jeff Bergosh**: Warren— I’m assuming you are taking additional time for recovery since you’re not here.  Is this correct?  No issue at al of so, just wanting to know.  Thanks,

Jeff

### CONVERSATION ON 11-09-2021

**Jeff Bergosh**: 4-1 vote

**Jeff Bergosh**: We just got our map approved to include everything I had put into the plan.

**Jeff Bergosh**: It died quick, Doug’s proposal

**Jeff Bergosh**: Going to bed— I have to get up at 4:50AM for coffee w the commissioner

### CONVERSATION ON 11-11-2021

**Jeff Bergosh**: Happy Bithday!

**Jeff Bergosh**: 👍❤️👌🎩

**Jeff Bergosh**: Tennis courts also have lights

**Jeff Bergosh**: OK I just spoke with the front desk and they will honor the same rate they just need you to come by and show your ID and they will honor the same rate for one additional day and will just pay that with our private funds

### CONVERSATION ON 11-12-2021

**Jeff Bergosh**: Day

**Jeff Bergosh**: I’m playing golf right now

**Jeff Bergosh**: I need you both to submit your electronic timesheets

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Hey Joseph.  A couple of things on the electronic timesheets for our annex today will probably need to wait until Monday for me to sort out-- as I'm on PTO in Orlando.  Warren Kirkland can't put in his time-- for this past week his should be 40 hours PTO as he is recovering from surgery.  Dave Midgorden is on PTO today and he has errors on his timesheet which I've sent back to him for correction but may not be corrected until Monday.  Let me know if fixing this Monday will work.

Thanks,

Jeff Bergosh

**Jeff Bergosh**: Hey Dave I returned your timesheet for correction you had Tuesday and Wednesday listed as leave without pay I don’t believe that’s correct so please take a look at it correct it and resubmit it thank you

Jeff

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: Mel I just saw your post but the one part that's wrong is the $1.4 million Delta was funded from BP money the 8.4 million that the board got from Levin--not from restore pot one money

**Jeff Bergosh**: So bottom line is $2.5 Million from Doug's discretionary and $1.4 Million from D2 portion of the $8.4 Million from BP

**Jeff Bergosh**: Looks like he doesn't have a lot of attendees

**Jeff Bergosh**: Now he's talking drainage???

**Jeff Bergosh**: So Chris Curb, Jonathan, Conor, county staff, you and Kevin and Krupnick--------outside that There's  about 6 people

**Jeff Bergosh**: Is that Mike weaver??

**Jeff Bergosh**: Nice-- Good points by Kevin!!

**Jeff Bergosh**: 3 people watching official county livestream.  Pathetic participation, as I predicted

**Jeff Bergosh**: Kevin's crushing it

**Jeff Bergosh**: Down to 2 watching on livestream

**Jeff Bergosh**: Pathetic

**Jeff Bergosh**: Oh yay Conor is going to explain it so now I can understand it LOL

**Jeff Bergosh**: Doug's got his spokesman speaking for him Connor the 22-year-old

**Jeff Bergosh**: Wow-- That ended with a third with a pastor pretty much putting Doug in this meeting out of its misery

**Jeff Bergosh**: Brandon’s coming over for Thanksgiving after he gets off of work!  👍👍😊😊

**Jeff Bergosh**: Ask him why he rushed it tell him Jeff Bergosh wanted to wait till 2023 but you rushed it why

**Jeff Bergosh**: Ask him why he wanted to rush it

### CONVERSATION ON 11-18-2021

**Jeff Bergosh**: Chip should make that are required accoutrement and chest device for the dress uniforms

**Jeff Bergosh**: Not true

**Jeff Bergosh**: Adopting my position to wait

**Jeff Bergosh**: Adopting my position on at large districts

**Jeff Bergosh**: Are you going to order Bergosh.com?

**Jeff Bergosh**: The Beulah one is tomorrow night

**Jeff Bergosh**: He's going backwards now he wants to wait until 2023 he's adopting my initial position because he didn't get what he wanted

**Jeff Bergosh**: But I'm not coming off my position he wanted to move it forward I'm gonna move it forward

**Jeff Bergosh**: What I told you today when I did call you Steve was absolutely 100% true. He did want to push he pushed hard you can go watch the video for yourself. He blew off a meeting didn’t get what he wanted and now he’s walking it back and playing Mr. Rogers those are the facts

**Jeff Bergosh**: If you can’t see it I can’t help you he’s a Chamaeleon

**Jeff Bergosh**: He doesn’t get to start a game and then when he’s getting his ass kicked in the third quarter say well let’s just stop the game and start next week fuck that

**Jeff Bergosh**: But I’m not letting this fuck stick quit when he’s about to get submitted he doesn’t get to tap out.  All he’s done for the last five years is talk shit and he blew off the meeting no one called him out on that he’s the reason why this happened he wanted it he blew up a meeting he didn’t get what he wanted and now he’s trying to do a Mr. Rogers act and people are buying it

**Jeff Bergosh**: Because Ally if you want it’ll lead to negative consequences I can guarantee you that because he’s a piece of shit

**Jeff Bergosh**: And he’s a liar

**Jeff Bergosh**: I told you the facts period

### CONVERSATION ON 11-19-2021

**Jeff Bergosh**: I thought I had Steven Barry's cell number but I don't .  No worries.  Thanks Kevin.

**Jeff Bergosh**: Hey Joseph I'm trying to call you and I'm getting a voicemail in there and the voicemail box is full but we're having trouble accessing the electronic time card to put our time and is it down?

### CONVERSATION ON 11-20-2021

**Jeff Bergosh**: Going to bed love u!!!

### CONVERSATION ON 11-22-2021

**Jeff Bergosh**: Guess who stopped by for dinner?

**Jeff Bergosh**: My meeting got pushed to 8 o’clock. So if you’d like me to call in earlier I am available to do so just let me know thanks Rick

**Jeff Bergosh**: Calling now

**Jeff Bergosh**: It appears other than that they were having a sensational season

**Jeff Bergosh**: Try calling Wes Moreno

**Jeff Bergosh**: I’ve got his number

### CONVERSATION ON 11-23-2021

**Jeff Bergosh**: That’s the eye care clinic I just called and double checked they have a prescription on file for you for eyeglasses so you just need to call them up get a copy of that prescription and I’ll figure out somewhere where you can go today and have them done quickly

**Jeff Bergosh**: She’s resending

**Jeff Bergosh**: Ok— just got it

**Jeff Bergosh**: Emailing to u now

**Jeff Bergosh**: You have 1 prescription ready @ Publix #1343 for $3.90.  Save time. Pay now: https://rx.publix.com/7 Reply STOP to stop.

**Jeff Bergosh**: Apparently part of a bill just recently signed

### CONVERSATION ON 11-24-2021

**Jeff Bergosh**: Plus we have leftovers

**Jeff Bergosh**: I wonder Philip Salzman still thinks Doug is the greatest thing since sliced bread

**Jeff Bergosh**: I just called Michel and she verified it what a despicable thing to say about someone

**Jeff Bergosh**: You can by his standards

### CONVERSATION ON 11-30-2021

**Jeff Bergosh**: Keel Point has $78 left in it
My Flex Card only has $12

**Jeff Bergosh**: So Keel Point should have worked

### CONVERSATION ON 12-01-2021

**Jeff Bergosh**: Thank you Michelle

**Jeff Bergosh**: Pocket dialed you

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: The only way to accomplish that is that if they blow me up when I'm sitting on my couch

**Jeff Bergosh**: Stated differently if they threw a stick of dynamite under my couch that's the only way those two dimwits unseat me

**Jeff Bergosh**: Tomorrow’s hard-copy headline…..

**Jeff Bergosh**: Plus the airlines will rebook you if it’s for Covid I believe that’s part of the federal transportation bill

### CONVERSATION ON 12-04-2021

**Jeff Bergosh**: it will be at the intersection of Rossi way and Dowdy drive.  2:00 PM

**Jeff Bergosh**: Good morning Steve I wanted to let you know I’ve committed to appear at a neighborhood meeting in what will be the new district to this more this afternoon at 2 o’clock with the state rep Alex Andrade I’m just throwing out an invitation if you’d like to come and meet these folks they’ve had flooding and drainage issues and I committed to this months ago before I knew where the lines would be I’m still going but I want to give the opportunity to district 2 candidates let me know if you’d like to go and I’ll give you the address it’s at 2 o’clock today

**Jeff Bergosh**: it will be at the intersection of Rossi way and Dowdy drive.  2:00 PM

**Jeff Bergosh**: Today at 2:00 if you're interested.  Left u a detailed voice mail on the subject

**Jeff Bergosh**: Hi chance this is Jeff Bergosh from the scabby Konicki mission hey today at 2 o’clock there will be a neighborhood meeting I had committed to attend it several months ago before the redistricting I am still going to attend it but it is about water issues stormwater and drainage state representative Alex Andrade will be there and others so I wanted to extend an invitation to you it’s at 2 o’clock today. Short notice I know but if you’re interested call me and let me know and I’ll give you the details of where in win.

### CONVERSATION ON 12-05-2021

**Jeff Bergosh**: Waters back on

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: I’m on way.  

**Jeff Bergosh**: Do u have an umbrela?  

**Jeff Bergosh**: Heather and Tim:  I need your hard copy timesheets from last week.  Thanks!

**Jeff Bergosh**: Good morning Cindy. I just got off the phone with my counterpart at ECUA and they are recommending 48 hours of boil water in the midst of yesterday’s line break. Vicki Campbell  told me they will probably be bringing door hangers to let the residents know—- but I wanted to give you the information early in case you wanted to send out an email.

### CONVERSATION ON 12-07-2021

**Jeff Bergosh**: So if you could just send her the news release and explain that’s how she can get on the call

**Jeff Bergosh**: In a year

**Jeff Bergosh**: It’s been canceled

### CONVERSATION ON 12-08-2021

**Jeff Bergosh**: Sally— UPS just delivered a package to the front door

**Jeff Bergosh**: I stopped by to say hello to 5-Sisters’ Blues cafe’s newest bartender!  They were slammed!

### CONVERSATION ON 12-09-2021

**Jeff Bergosh**: Rough guesstimate

**Jeff Bergosh**: It’s a SLT

**Jeff Bergosh**: 2WD

### CONVERSATION ON 12-10-2021

**Jeff Bergosh**: Call me when u get this— there is someone out at the front door ringing the bell

**Jeff Bergosh**: White pickup truck

**Jeff Bergosh**: Liability

**Jeff Bergosh**: U

**Jeff Bergosh**: Sally your friends’ party starts in an hour are u on way home?

**Jeff Bergosh**: ?

**Jeff Bergosh**: That’s also before I heard what you told me about the situation

### CONVERSATION ON 12-11-2021

**Jeff Bergosh**: Lineup at six?

**Jeff Bergosh**: Bebe Le clout sold out

**Jeff Bergosh**: I’ll get this— It’s the next best that they have

**Jeff Bergosh**: They ridicule ivermectin

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: In shower will call u in 5

**Jeff Bergosh**: HCA base plan will be much cheaper Tori

**Jeff Bergosh**: Either way—- get signed up for something.  $100 month is worth it——BELIEVE ME!!

### CONVERSATION ON 12-14-2021

**Jeff Bergosh**: Please send regrets

**Jeff Bergosh**: PNJ ran the hatchet piece on Hamlin, it just popped up on their site and will probably be in print tomorrow.  It’s bad.😕

**Jeff Bergosh**: This, below, came to me but was no doubt meant for you

**Jeff Bergosh**: Jeffbergosh@gmail.com

Goldendoodle1

**Jeff Bergosh**: Check it out.  It’s a bad hatchet job

**Jeff Bergosh**: Will be front page tomorrow

**Jeff Bergosh**: I’ll be headed that way in 15 minutes

### CONVERSATION ON 12-15-2021

**Jeff Bergosh**: And as you know it’s true

**Jeff Bergosh**: He’s a fake and a fraud

**Jeff Bergosh**: Looks like it was semi hidden

**Jeff Bergosh**: The gate is the worst I've ever seen this morning--  already been stuck 15 minutes

**Jeff Bergosh**: No 7:30merting

### CONVERSATION ON 12-16-2021

**Jeff Bergosh**: They close at 8 so u probably can’t make it 

**Jeff Bergosh**: But if u can get there by 8 I’ll tell them not to throw the vial out

**Jeff Bergosh**: U have $1000 in chk

**Jeff Bergosh**: I sent it

**Jeff Bergosh**: Looks like “Mr. Big” isn’t a very good guy……

**Jeff Bergosh**: Heading to bed I got to get up at 5 AM for Bible study I love you come home soon!!!

**Jeff Bergosh**: Visa comes through!!!

**Jeff Bergosh**: *Bosa

### CONVERSATION ON 12-17-2021

**Jeff Bergosh**: I don’t have it

**Jeff Bergosh**: Early to mid February——- time to face the music!

### CONVERSATION ON 12-21-2021

**Jeff Bergosh**: OK I got it ——eight people 7 o’clock  New Year’s Eve….not the tap room ——but the big room right next to the tap room in the IPC 

😀👌👍

**Jeff Bergosh**: Hey Tori I’m gonna stop at panda express on the way home and get some food for me and mom are you working tonight or do you want me to bring something home for you? Just text me what you want me to grab for you if you’re not working

**Jeff Bergosh**: I see they scheduled the hearing on Feb 16th and 17th over Zoom.  Tick tick the clock’s ticking—-great news right before Christmas on the farm 😎👌👍

**Jeff Bergosh**: Can a public watch the spectacle?

**Jeff Bergosh**: BTW— that sounds like a great greeting card to the farm.  And or neatly decorated envelope with beautifully stenciled letters to the family. Inside a copy of that notice.

Followed by:

MERRY FUCKING CHRISTMAS!

**Jeff Bergosh**: Maybe he’s doing it on credit? He probably told Erin I’d gladly pay you Tuesday for a hamburger today!

**Jeff Bergosh**: *Herron

### CONVERSATION ON 12-22-2021

**Jeff Bergosh**: I have a call him right now to Mike Wood at T-Mobile ——just waiting for him to call me back

**Jeff Bergosh**: OK I talked to Mike Wood. He says you need to go to the Bayou Boulevard T-Mobile store it’s behind the Chick-fil-A. He will put a call into the manager there that he knows and he’s looking into the issue as well.

**Jeff Bergosh**: R u on way home???

**Jeff Bergosh**: Which one was it— the lady in the office next to Ira??

**Jeff Bergosh**: Unreal

**Jeff Bergosh**: But she’s glib

**Jeff Bergosh**: That’s not what happened

**Jeff Bergosh**: I know he really badly wants to be in charge though……

### CONVERSATION ON 12-23-2021

**Jeff Bergosh**: It means:  I’m running this MF er

**Jeff Bergosh**: Mom wrote that

**Jeff Bergosh**: So comparing the two bills I still think you owe me money

**Jeff Bergosh**: The name of the place we are going in Coronado is the “Tavern”

**Jeff Bergosh**: If u want to gps it

**Jeff Bergosh**: I think it’s just 

### CONVERSATION ON 12-29-2021

**Jeff Bergosh**: Hey Debbie can you text me Grady Lee’s home and cell number please? I’m on my walk but I don’t have his numbers if you could text them to me I can call him on my lunch break today thank you.

**Jeff Bergosh**: There in an email he sent or Tina Arroyo sent yesterday or the day before

**Jeff Bergosh**: If so, I can do it

### CONVERSATION ON 12-30-2021

**Jeff Bergosh**: Hey I just got off the phone with your mom I wanted to give you an update call me when you get a chance love you

**Jeff Bergosh**: The deal is in escrow right now in San Diego but it’s supposed to close before the end of the year which means today or tomorrow

**Jeff Bergosh**: Here’s his contact info. Michael

**Jeff Bergosh**: This is the broker I spoke to about the multi-unit apartments.  He is in Phoenix through Tuesday but is looking forward to speaking with you.   I’m going to give him your office’s number as well.  Get well soon and Happy New Year!

Love,

Jeffrey Wayne

### CONVERSATION ON 12-31-2021

**Jeff Bergosh**: Don’t stay all day

### CONVERSATION ON 01-02-2022

**Jeff Bergosh**: Let me know if that works to get the car started

### CONVERSATION ON 01-04-2022

**Jeff Bergosh**: I have an update on Murillo and the costs.  Call when you can.

**Jeff Bergosh**: Love u— headed to bed.  Come home soon and be safe.❤️❤️

**Jeff Bergosh**: That’s awesome!!

### CONVERSATION ON 01-05-2022

**Jeff Bergosh**: Hey can you check with David Herro I was at the office yesterday afternoon and I was told there would be a framed district one map leaning on the door but it wasn’t there and it wasn’t in my office can you check with him and see what the status of that is?

**Jeff Bergosh**: Free FedEx alert: Signature req'd for package delivery 01/06. For options fedex.com/t/288349723415/en_US and select Manage Delivery. Reply STOP to stop msgs.

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Stay strong I love you and will help you however I can

**Jeff Bergosh**: I signed the document with a large signature I pulled a John Hancock on it

**Jeff Bergosh**: They got removed today

**Jeff Bergosh**: LOL Senator Salzman

**Jeff Bergosh**: Maybe Brent is prescient

### CONVERSATION ON 01-07-2022

**Jeff Bergosh**: You are correct it came out on 12/15/21

**Jeff Bergosh**: Weak and humbled

**Jeff Bergosh**: Got two minutes

**Jeff Bergosh**: Good Morning Ira— just checking on you because typically you are here early.  Making sure you are okay

Jeff

**Jeff Bergosh**: Hey Danny I talked to Gary and Carissa they're both going to go in place of Sally and I thank you so much for getting them on the list and I apologize for not being able to make it this year!

**Jeff Bergosh**: The news journal does this all the time but typically Channel 3 does not do this that's why I asked you because I consider you to be an upstanding individual who does things right

**Jeff Bergosh**: 8506988094

**Jeff Bergosh**: His cell

**Jeff Bergosh**: Just keep it close hold for me if you don't mind

### CONVERSATION ON 01-09-2022

**Jeff Bergosh**: Exiled!!

### CONVERSATION ON 01-10-2022

**Jeff Bergosh**: Klendathu2122!!

**Jeff Bergosh**: Sorry I just saw this—- call me

**Jeff Bergosh**: This don’t look like fun……..

**Jeff Bergosh**: Heated Burkah

**Jeff Bergosh**: Hello Eric— I have an issue I’d like to discuss with you from 12-17-21.  It has to do with a constituent 911 call and what transpired.  When you get a few minutes could you give me a call?

Thanks!

Jeff B

### CONVERSATION ON 01-11-2022

**Jeff Bergosh**: Tim-  I need your hard copy timesheet

### CONVERSATION ON 01-12-2022

**Jeff Bergosh**: Thanks Wes

**Jeff Bergosh**: Test

**Jeff Bergosh**: Wes the text messages not going through so I'm just gonna tell you his name and number

**Jeff Bergosh**: Andy Huffman 

**Jeff Bergosh**: LOL

### CONVERSATION ON 01-13-2022

**Jeff Bergosh**: Her phone number is

850-525-4196

**Jeff Bergosh**: Hey Tori—-did u go to work?

### CONVERSATION ON 01-14-2022

**Jeff Bergosh**: By the way your information from the other day was true we got screwed by the state on that deal

**Jeff Bergosh**: Homemade pizza night—- yours is going in the oven right now…Mozzarella onion and fresh garlic!

### CONVERSATION ON 01-15-2022

**Jeff Bergosh**: I’ll get it all

**Jeff Bergosh**: Will get some today, some tomorrow morning

### CONVERSATION ON 01-18-2022

**Jeff Bergosh**: I’ll be the designated driver for the evening for you and I LOL

**Jeff Bergosh**: Come home soon boxer!!

### CONVERSATION ON 01-19-2022

**Jeff Bergosh**: Perfect

**Jeff Bergosh**: Hey Sally can you join me for an open house/happy hour tomorrow at 4:30 before the 6:00 Maserati open house?  This one will be in downtown for a new company opening up in Pensacola called Circulogene.  Mayor and others will be there— I just got the invitation just now….

### CONVERSATION ON 01-20-2022

**Jeff Bergosh**: Inmtg will call u back

**Jeff Bergosh**: Warren the meeting is starting where ru?

**Jeff Bergosh**: Safety meeting

**Jeff Bergosh**: In trans compound

**Jeff Bergosh**: ????????????????

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: I think Everett my girl and I think it’ll probably others in the party that might

**Jeff Bergosh**: *might go

**Jeff Bergosh**: https://weartv.com/news/local/florida-passes-bill-stripping-school-board-members-of-salaries?fbclid=IwAR3WH9V6PegFV4UusiyHsEP6DWE-_PBFQ7T3HJ6oFvfS6qXKFrfaNfsRmas

**Jeff Bergosh**: https://weartv.com/news/local/florida-passes-bill-stripping-school-board-members-of-salaries?fbclid=IwAR3WH9V6PegFV4UusiyHsEP6DWE-_PBFQ7T3HJ6oFvfS6qXKFrfaNfsRmas

**Jeff Bergosh**: Love it

**Jeff Bergosh**: Probably not

**Jeff Bergosh**: They’ll be some Democrats are against it and a lot of unions will lobby against it

### CONVERSATION ON 01-22-2022

**Jeff Bergosh**: And I change your air filter and put the freshman in and put the screen door in the living room back on the track it was off the track

### CONVERSATION ON 01-23-2022

**Jeff Bergosh**: Pot roast will be ready at 6:30!

**Jeff Bergosh**: Foods ready!

### CONVERSATION ON 01-24-2022

**Jeff Bergosh**: That’s what the meeting was all about??

**Jeff Bergosh**: …..Not something to be boasting about

**Jeff Bergosh**: I believe that

**Jeff Bergosh**: It appeared to me from talking to the two folks from the state will be conducting this that it is a TDT audit.

**Jeff Bergosh**: ….And nothing more

### CONVERSATION ON 01-25-2022

**Jeff Bergosh**: *on

**Jeff Bergosh**: That guy suddenly started coming to my men's Bible study group about 3 1/2 weeks ago the one that I've gone to for 12 years and the candidates seem to find when they decide they wanna run very interesting

### CONVERSATION ON 01-26-2022

**Jeff Bergosh**: I hope he’s alright.  Hate to hear this

**Jeff Bergosh**: Monday morning at 7:20 or tomorrow at 7:20?

### CONVERSATION ON 01-27-2022

**Jeff Bergosh**: ❤️👍

**Jeff Bergosh**: My Co-worker, Jaron Kiger, is getting married on Friday March 25th in Navarre at 1:30 in the afternoon.  Do you want to go?  Are you able to?  Let me know and I’ll RSVP for us.  Love,  me

**Jeff Bergosh**: Hey I’m working on the January/February Newsletter and I’m using the template from last year—- but I’m looking for Health and Hope 2021 Annual Report but can’t find it on your website.  Can u send me a copy or a link to it? 

Love u!

### CONVERSATION ON 01-28-2022

**Jeff Bergosh**: Big project, multi state, out of the box thinking and bold

**Jeff Bergosh**: https://www.pnj.com/story/opinion/columnists/2022/01/28/escambia-county-commissioners-sue-people-personal-profit-andy-marlette/9234965002/

**Jeff Bergosh**: https://www.pnj.com/story/opinion/columnists/2022/01/28/escambia-county-commissioners-sue-people-personal-profit-andy-marlette/9234965002/

**Jeff Bergosh**: In mtg now but when I get back to office I’ll do it

**Jeff Bergosh**: I just sent the final draft let me know if it looks good and if so I’ll put it out to the entire list

**Jeff Bergosh**: Big deal for the Perdido Chamber of Commerce

### CONVERSATION ON 01-29-2022

**Jeff Bergosh**: I left the list on the table and I’m at Wal Mart— can u take a picture of it please and send it to me?  Thanks!  Love, me ❤️❤️

**Jeff Bergosh**: There are so many great movies it’s hard to choose.  This is my list of all time favorites by genre and year.

**Jeff Bergosh**: *Psycho

**Jeff Bergosh**: It’s really quirky and offbeat

### CONVERSATION ON 01-30-2022

**Jeff Bergosh**: What happened Brandon??

**Jeff Bergosh**: Call me

**Jeff Bergosh**: Keep me posted— let
Me know if u need a ride.  Love u!

**Jeff Bergosh**: Moms at Health and Hope Clinic rn I told her what’s happening so she might be calling u too.  Let us know what u need 👍

### CONVERSATION ON 02-01-2022

**Jeff Bergosh**: Can’t do mondays

**Jeff Bergosh**: How about any time on the 24th or 25th or evening of 23rd.  14th is Valentine’s Day so that’s out

**Jeff Bergosh**: Or to the house?

**Jeff Bergosh**: Thanks Tony!

**Jeff Bergosh**: This was the scene last night when I made the statement “I trust the content of the PNJ….”

**Jeff Bergosh**: Call me after

**Jeff Bergosh**: It was a part of the question and answer session

