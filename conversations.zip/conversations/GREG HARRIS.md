

## CONVERSATIONS WITH GREG HARRIS

### CONVERSATION ON 03-12-2020

**Greg Harris**: Good morning Commissioner, how are you doing? I just wanted to give you a heads up. I would have been at the meeting this morning however I have a Board of Governors emergency call with the other team owners in the league and the league office at 9 am. We'll be discussing the current state and options to proceed with playing and what protocols we'll follow should we need to cancel/suspend the season.

**Greg Harris**: Please let me know if you have any questions.

**Jeff Bergosh**: Thanks Greg yeah it’s been kind of fluid and I think there’s gonna be a lot of changes upcoming to sporting events so I hope it’s not too much of an impact but we’ve got to protect public safety

**Greg Harris**: I 100% understand.

**Greg Harris**: Any chance of the county shutting the building down?

**Jeff Bergosh**: I don’t think were at that point yet thankfully

### CONVERSATION ON 06-04-2020

**Greg Harris**: Hey Commissioner, sorry to bother you during the meeting. I’ll be coming by there shortly to be in attendance. I just wanted to give you a heads up that Michael Capps, who is there, will have to head out at noon to meet with all the principals at the building to go thru graduation logistics, and he definitely knows the most about all the renovations that are being discussed and can answer any specific questions any of you may have. If it comes to it and time moves on, as I believe it is scheduled last in the agenda, might it be possible to move it up? Just throwing it out there. If not, no worries at all. I’ll see you soon!

**Jeff Bergosh**: Got it

**Greg Harris**: Do you have any questions about our amendment? Give me a call if you do. 

**Greg Harris**: Thank you for your vote for the team and building!

**Jeff Bergosh**: Absolutely Greg!  Congrats!

**Greg Harris**: Thank you Commissioner! We'll definitely continue to do everything we can to help the bottom line for the County! And this will help significantly!

### CONVERSATION ON 08-19-2020

**Greg Harris**: Congrats on the win last night!

**Jeff Bergosh**: Thx Greg!

### CONVERSATION ON 04-24-2021

**Greg Harris**: Hey we're trying to get ahold of Cassie with Facilities. We have a ton of fog and moisture in the arena. We play tonight and tomorrow. SMG is trying to get ahold of her to find out if the county has large fans to help but she's not responding. It's bad in here. Any way you're able to get ahold of her to respond? Sorry to bother you. Here are some pictures.

**Greg Harris**: She finally called Cyndee. 

**Jeff Bergosh**: Okay let me know what we can do to help Greg

**Greg Harris**: Thank you! 

**Jeff Bergosh**: 👍

**Greg Harris**: Everything is working good. We’re playing, glass is good. Everything cleared up for us.

### CONVERSATION ON 05-13-2021

**Greg Harris**: Hey Commissioner! So we made it to the finals again, and hopefully we can bring another championship home! We’re playing at home tomorrow night. If you can make it, would love to have you here. Hope all is well!

**Jeff Bergosh**: Thanks Greg— I’ll try to make it out.  Best of luck in the game!!

### CONVERSATION ON 12-25-2021

**Greg Harris**: Merry Christmas!!

### CONVERSATION ON 12-26-2021

**Jeff Bergosh**: They are slammed

