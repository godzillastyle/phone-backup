

## CONVERSATIONS WITH REED MOSS

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: From Administrator Gilley just now👍

**Reed Moss**: thank you sir

**Jeff Bergosh**: Mattresses Are coming soon I've been pressing hard ----because I can't believe it takes this long to purchase mattresses

**Reed Moss**: thank you for following it threw I know the guys and myself will be super happy to have new beds

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2020

**Reed Moss**: congrats on the win 

### CONVERSATION ON 10-30-2020

**Jeff Bergosh**: I'll call u right back-- on the other lone

**Jeff Bergosh**: *line

**Reed Moss**: Okay

### CONVERSATION ON 10-31-2020

**Jeff Bergosh**: Hey Reed --I was really looking forward to seeing that video but unfortunately I got held up today and with it being Halloween I'm gonna be slammed so I won't be able to get up with you. I'll try to call you this week at some point and work around your schedule to get to see it.  hope you have a good Halloween talk to you soon.

**Reed Moss**: ok no problem just let me know and happy halloween

### CONVERSATION ON 02-24-2021

**Reed Moss**: Mr. Bergosh its Reed Moss if you could give me a call back sometime that would be great theres some things i would like to bring up. 

**Jeff Bergosh**: Hey Reed!  Will do, I'm in meetings all morning.  Will call in my lunch break

**Reed Moss**: yes sir that will work thank you

**Jeff Bergosh**: In afternoon mtg

**Reed Moss**: Okay

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 02-25-2021

**Jeff Bergosh**: Your phone cut out

**Reed Moss**: 18503248481

**Reed Moss**: anthany manning

