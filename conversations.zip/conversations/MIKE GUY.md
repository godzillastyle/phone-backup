

## CONVERSATIONS WITH MIKE GUY

### CONVERSATION ON 04-22-2020

**Jeff Bergosh**: Thank you!!And thanks for all the great talking points many of which I’m going to incorporate into this morning

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Hello Mike—here is the director of community health northwest- Chandra Smiley.  They have been conducting tests at various locations around the county for us.  Call her, let her know where you’ve been and what you’ve been doing and she will call you back and let you know where the next screening events going to be where you can come and get a test performed

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Right on.  Hope it comes out negative for you and your family!👍

