

## CONVERSATIONS WITH JOY JONES

### CONVERSATION ON 12-21-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Joy Jones**: Ok thanks

### CONVERSATION ON 12-23-2020

**Joy Jones**: Good morning Commissioner, have you been updated on Longleaf?

**Jeff Bergosh**: No ma'am--- but I've not checked my email.  Is everything okay?

**Joy Jones**: BDI came back at an even higher cost than the first one.  

**Jeff Bergosh**: For just their portion or for the overall project?

**Joy Jones**: Their design to go to 3-lanes plans

**Jeff Bergosh**: How much more?  What was it before, and what will it be now?

**Joy Jones**: 1st ask was $438.600

Had meeting and discussed they needed to work with what remains in their contract, $256,902

They came back with $446,425

**Joy Jones**: Debbie sent them an email that we wouldn't go with them.

**Jeff Bergosh**: Okay that is disappointing.  What are next steps?  How do we maintain the timelines if we have to go out and rebid?

**Jeff Bergosh**: Or--- do we have to re bid or can you just renegotiate tour price with another approved vendor under the CCNA?

**Joy Jones**: We have a draft scope we can finish and submit to Purchasing today.  We will press purchasing, designer, and contractor from there.  Expect 90 for purchasing and six months for design.  To be honest, overall 2 year schedule could stretch another 3-6 months longer.  We will be diligent.

**Joy Jones**: It has to go to Purchasing.

**Jeff Bergosh**: Okay sounds like a plan.  Thanks and Merry Christmas

**Joy Jones**: Thank you Commissioner, Merry Christmas to you and yours!

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: Hi Joy, this is Jeff B.  How many employees do you have in the engineering department?  And how many of those are professional engineers?  Thanks!

**Joy Jones**: We have 49 and six positions are engineers (2currently vacant)

**Jeff Bergosh**: Thanks

### CONVERSATION ON 01-26-2021

**Joy Jones**: Commissioner- just wanted to make sure you saw the email from James Duncan with a Gulf Manor info for your meeting tonight.  

**Jeff Bergosh**: I did Joy thank you very much that was very very helpful and I just got off my phone call so it was perfect I appreciate it

**Joy Jones**: You're very welcome.

### CONVERSATION ON 08-31-2021

**Joy Jones**: Commissioner, upon further review the outfall maintenance will need to be performed by the state for Dowdy / Willowside wetlands.  I will make that official request to FDOT and copy your office.

