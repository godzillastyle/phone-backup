

## CONVERSATIONS WITH SUR NAST

### CONVERSATION ON 08-16-2020

**Jeff Bergosh**: Thank you Sue!!

**Jeff Bergosh**: Thanks for being there for my campaign yesterday!! That meant a lot to me !!!!

**Jeff Bergosh**: Thank you Sue!!!!!!!!

### CONVERSATION ON 10-21-2020

**Jeff Bergosh**: That's a great idea Tom!

**Jeff Bergosh**: LOL I haven’t either Leaving it blank LOL

