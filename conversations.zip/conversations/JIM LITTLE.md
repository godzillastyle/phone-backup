

## CONVERSATIONS WITH JIM LITTLE

### CONVERSATION ON 03-24-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/tomorrow-dr-john-lanza-will-join-me-for.html?m=1

Hello Jim:  i'll be having Dr. Lanza with me tomorrow morning live on Facebook to answer questions about COVID-19. If you have any questions that you would like me to ask him I'd be happy to do so or you can tune in and ask him yourself it starts at 6:30 AM 

**Jim Little**: Thanks for the heads up!

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-25-2020

**Jim Little**: Call me back when you have a second 

**Jim Little**: Hey good morning Commissioner, I'm writing a story based on your live stream this morning with Dr. Lanza and your support for opening the beaches when y'all meet on April 2. I wanted to embed the video in the article but it looks like you have that disabled in your Facebook page settings for that video. I will still link to it but just wanted to let you know if you changed that I can embed the video in the article.

**Jeff Bergosh**: Okay thanks Jim I'll go in and change that--I thought there was a lot of good information in there so I'm glad to hear you'll be doing a story on it!

### CONVERSATION ON 04-10-2020

**Jim Little**: Hey Commissioner can you call me back when you have a second? Wanted to ask you about the call for a special meeting

**Jeff Bergosh**: Okay will do.  On a conference call but will call u after

### CONVERSATION ON 04-12-2020

**Jeff Bergosh**: Jim in case you didn’t see the county late yesterday afternoon relented and they’ve walked back their decision on the COVID-19 sit rep. They are going to start releasing it again and therefore I am going to withdraw my request for a special meeting.

**Jim Little**: Thanks, I know we had a story about that. I’ll probably be doing another story tomorrow and I’ll mention that. Happy Easter

**Jeff Bergosh**: Happy Easter Jim

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: Jim, here is a Good, positive news story that’s exploding on my blog right now....Good news for a COVID-19 weary community.........in case you are interested in discussing it.

**Jim Little**: Looks like a good story, unfortunately I’m on furlough this week, so I wouldn’t. be able to do a story until next week. 

**Jeff Bergosh**: Furlough??  Wow!  Sorry about that.  See you next week.  Should I pass it along to Madison Arnold?  .... I don’t have her number

**Jim Little**: Yeah her number is (850) 281-5548

**Jeff Bergosh**: Thx

### CONVERSATION ON 08-03-2020

**Jeff Bergosh**: Hey Jim it’s Jeff Bergosh here. I’m just checking that you received my survey and my recent headshot that I sent to you yesterday evening at 8:55 PM. Please advise and thanks very much!

**Jim Little**: Hey, yes I got it, was just about to reply. Everyone sent them in last night, so going through a ton of emails. Thanks for sending!

**Jeff Bergosh**: 👍that’s what I figured but I just wanted to be sure.

### CONVERSATION ON 06-03-2021

**Jim Little**: Commissioner, just wanted to let you know that piece was an editorial opinion piece, I’m literally not allowed to have any say in what they write. 

**Jeff Bergosh**: Thanks.  I’m not impressed with your editorial board.  They diminish the good work you do

**Jim Little**: Understand 

### CONVERSATION ON 09-28-2021

**Jeff Bergosh**: On line will call u right back Jim

**Jim Little**: Liked “On line will call u right back Jim”

