

## CONVERSATIONS WITH TUCKER DORSEY

### CONVERSATION ON 01-08-2020

**Tucker Dorsey**: Can I call you right back?

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-22-2020

**Tucker Dorsey**: Good afternoon, Jeff. Just rounding back up with you to see if you had any information for us on the Jennings place submittal and commission meeting date. Thank you very much. 

**Jeff Bergosh**: Can I call u back in 5?

**Tucker Dorsey**: Yes sir 

**Tucker Dorsey**: Jeff, I did not know, but I get the Hammond situation after our conversation. I’m sorry. I inherited him in my Jennings mess. I fixed the environmental. I did not allow us to present a sub-standard product to the County. I will let Hammond know his cost and liability to Forestar in this deal. He will not bring another Forestar project before you. I will personally come and present our final plat request to the County Commission and tell him to stay at the house. If December is an option, I will be very grateful. So long as the as builts meet the county standards as approved, and requirements, met, I really need the December meeting. Any help with that effort is humbly appreciated. 

### CONVERSATION ON 10-23-2020

**Jeff Bergosh**: Thanks Tucker I will speak with the department.  I hope you have a great weekend

### CONVERSATION ON 12-10-2020

**Tucker Dorsey**: Good evening Commissioner, I haven’t been in a Commission meeting in a long time. 

**Jeff Bergosh**: Hello

**Tucker Dorsey**: Thank you very much!

**Jeff Bergosh**: 👍

**Tucker Dorsey**: Jeff, again, thank you. My team wants to be a good addition to the Escambia community. It’s important to me personally as well as professionally. Please let me know how I can be helpful to the county and District 1, sincerely. 

**Jeff Bergosh**: Thanks Tucker!

### CONVERSATION ON 08-27-2021

**Tucker Dorsey**: I’m on the other line. Can I call you right back?

**Jeff Bergosh**: Sure

### CONVERSATION ON 08-31-2021

**Tucker Dorsey**: Good afternoon Jeff, any updates on the Jennings connectivity issue? Thank you 

**Jeff Bergosh**: Still working it but I’ll have something to report soon

**Tucker Dorsey**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-15-2021

**Tucker Dorsey**: Jeff, again, I sincerely appreciate your involvement in this situation on the hiatus. I have confirmed that the small pond in phase 1 was properly dedicated to Escambia County. Allison thought differently. The large pond will be dedicated with the plat for phase 2 and completion of the entire development. Additionally, I have confirmed that our contractor will be warranting all infrastructure work that would include the entire connectivity road to Daniels Grove as well as the waterline. So if I can deliver clear title with regards to the property and warrant the infrastructure there, we should be good to go. Again, thank you for your involvement. Call on me anytime. 

### CONVERSATION ON 09-29-2021

**Tucker Dorsey**: Thank you for your help with the hiatus, Jeff. We have a couple of other minor issues for final plat, but they are being properly addressed. I am personally very grateful and a Commissioner Bergosh supporter. Call on me anytime. 

