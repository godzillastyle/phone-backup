

## CONVERSATIONS WITH RICHARD ALLISON

### CONVERSATION ON 11-21-2019

**Jeff Bergosh**: Vaucluse

### CONVERSATION ON 03-01-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Richard Allison**: Ok, maybe another time.

### CONVERSATION ON 03-19-2020

**Richard Allison**: Jeff, my wife manages Cracker Barrel on I-10. I told her she does not have to close because they are not in the city. Does the county have plans to close restaurants?

**Richard Allison**: Commissioner, we don’t support the City of Pensacola on restaurant closing but support Governor’s plan to limit seating.  You have a position yet?

**Jeff Bergosh**: Hi Richard.  I’m waiting to hear from the Health Department.  They just announced this meeting so I’m going to hear what they say but I’m not going to take any decision lightly.  This is heavy.....

**Richard Allison**: Yes it is.  I just hope for cooler heads and a balance. I think Gov DeSantis is on the right track. I’m glad I am not in your seat tomorrow.  I wish I could go but as far as the beach, fresh air is good and virus transmission is low unless Health Department thinks otherwise.  Good luck tomorrow.

**Jeff Bergosh**: Thank you Richard...tough stuff

### CONVERSATION ON 04-14-2020

**Richard Allison**: Natural light, fresh air could keep coronavirus out of workplaces, scientists suggest

https://www.foxnews.com/science/natural-light-fresh-air-could-keep-coronavirus-out-of-workplaces-scientists-suggest

I read about a US Army study that patients with the Spanish Flu did much better in overflow tents and pushed into the sun than those in hospital buildings. 

I don’t know why we don’t investigate that, it is so simple! 

I think open beaches with crowd control or groups not allowed would be good medicine.

Explore the Fox News apps that are right for you at http://www.foxnews.com/apps-products/index.html.

### CONVERSATION ON 05-16-2020

**Richard Allison**: Thank you Jeff.  Your calls to the sheriff seems to quieted thing down some. Thank you again.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-19-2020

**Richard Allison**: Jeff, I think I spoke too soon but in the last 15 minutes, a motorcycle sped past here going near 100 mph and then a red Barracuda going almost that fast 5 minutes later and then another two motorcycles racing.  Please help or someone will get killed.

**Richard Allison**: This is every single day. It stopped for a few days and starting up again.  It is motorcycles, cars, trucks and etc.  It is the Wild West here with no enforcement.  Any relief is appreciated. Thanks.

**Jeff Bergosh**: Will do Richard!

**Richard Allison**: I am so sorry to ask you again but it is out of control around here.  One kid was run over and killed last year in front of my house.  I think the only solution is lowering the speed to 30 and putting in a few speed bumps. We have a school at the corner of Muldoon and Cerny with no school zone, a church at the opposite corner and a large apartment complex with children walking up and down the road.  I think your idea of the sidewalk will help but reckless driving is out of control.  Thanks Jeff for any help you can give us for the long term. The short term solutions help if enforcement is present but I realize they can’t be here all the time.

### CONVERSATION ON 05-20-2020

**Jeff Bergosh**: Sorry to hear this Richard I’ll see what can be done

**Richard Allison**: Thank you Commissioner.

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: I'm in a meeting can I call u back?

**Richard Allison**: Sure.

**Richard Allison**: Not important but just reminder on Cerny Rd and Owens activity at corner of Blue Angel and Lillian Hwy.  We can talk anytime.

### CONVERSATION ON 06-29-2020

**Richard Allison**: https://youtu.be/ox-0NusoIAA

### CONVERSATION ON 07-19-2020

**Richard Allison**: Jeff, this is only one I could catch on video today because I was working in the yard.  Cerny is 35 and I am requesting it be 30 so we could get two or three speed bumps on this section.  This one guy went through here about a half a dozen times.  There are more than this guy and also cars too.  People bicycle, jog and children play here too.  I want to be clear that it is cars and motorcycles and some cycles are dirt bikes that are coming from behind Saufley.  It even happens late at night too.  Today was especially active.  Remember we have these apartments, church and charter school all here all within a thousand feet. Please help.

### CONVERSATION ON 10-08-2020

**Jeff Bergosh**: In a meeting will call u after

### CONVERSATION ON 11-30-2020

**Jeff Bergosh**: I'm in a meeting I will call you back

**Richard Allison**: 👍

### CONVERSATION ON 12-14-2020

**Richard Allison**: Jeff, can you help us with the Sheriffs Department again? It starts when they get home from work between 4 to 6pm and they can race at different times until 10:30 at night.

**Richard Allison**: It involves Cernuda and Muldoon.  The one guy lives across the road from me and has no tags on the bike.

**Richard Allison**: These videos are the slower runs.  I can’t catch them on the fast ones.

**Jeff Bergosh**: Richard I will and I have also asked staff to reach out to you about engineering studies for this area to include the feasibility of traffic calming devices. Have you heard from our staff yet?

**Richard Allison**: Not yet and I am honored to help

**Jeff Bergosh**: Okay they’ll be reaching out

**Richard Allison**: Thanks.

### CONVERSATION ON 01-05-2021

**Richard Allison**: Hi Jeff, they are several days working on the sidewalk here on Cerny Rd.  I never heard from the planners. Sidewalks are looking good.  Is there any plans for traffic calming?

**Jeff Bergosh**: I’m out of town at the moment but I will ask.  You should have been contacted by Mr. Don Christian about the speed bumps

**Richard Allison**: Thanks Jeff. I will wait for the call.

### CONVERSATION ON 01-08-2021

**Richard Allison**: I guess the road project manager doesn’t want my comments.  Have a good weekend, Jeff

**Jeff Bergosh**: We’re they out there yet?

**Richard Allison**: Yes, they are making progress on the sidewalk. Looks good.

**Jeff Bergosh**: But what about the traffic folks for the speed bumps?

**Richard Allison**: I have not seen them yet.

**Richard Allison**: Jeff, i just finished talking to Mr. Chamberlain and there is noting in the plans to lower the speed limit or traffic calming devices.  The problem is not so much slowing down traffic but there is no traffic patrol by FSP or Sheriff.  Traffic calming I feel is needed because people know that there is no enforcement and if there is no enforcement, then we need traffic calming.  Mr Chamberlain wanted to do another traffic study but I asked to postpone it because of cold weather and the problem comes back when the weather improves and he agreed.  If you ever get some time, I would like to talk further.  The sidewalks look great and will help keeping people that are walking safer.

### CONVERSATION ON 02-10-2021

**Richard Allison**: Jeff, is the fine in the City of Pensacola for not wearing a mask legal under the Governor’s Executive Order?  Is this a bluff?

**Jeff Bergosh**: I don’t think the city can enforce that— the Governor has pre-emotes the city’s ability to do so

**Richard Allison**: That is what I thought. Tax

**Richard Allison**: Tnx 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-13-2021

**Richard Allison**: Commissioner Jeff,  I think I am ready for that traffic study to reduce the speed limit to get speed bumps.  I also talked to deputies about this vandalism and speeding on Cerny and Muldoon and they said they are overwhelmed with other duties too.  The first photos are where I witnessed a guy trying to throw a trash bag out the car window but the car dragged the bag for a quarter mile strewing garbage everywhere.  The other photos are from a guy that drives a old gray suv and calls himself Roughcut and I confronted him face to face telling him I am getting Sheriff involved.  He told me he looks for standing water after a rain to mud on the right of way.  I could not get his tag but I could see it was from Baldwin County but I think it was fictitious.  I think there are others.  More to send...

**Richard Allison**: Here is racing stripes down the road where the smoked tires going backwards and then popping the car into drive and smoking up the road.  I did not get pictures of another incident where they tried to mess up your sod on the new sidewalk.  I spent a half hour scraping up the sod and smoothing it down as it was supposed to be.  I wish I got pictures of that.  We also have unlicensed dirt bikes all weekend going up and down the road, sidewalks and every place else.  Most all this is during daylight hours.  Call me when you can please.

**Jeff Bergosh**: Thanks for sending this information Richard I will touch base with you at some point tomorrow so we can discuss next steps

### CONVERSATION ON 04-21-2021

**Richard Allison**: Me. Jeff, did you ever get a chance to think about Cerny Rd?

**Jeff Bergosh**: Working on it. Will call to discuss this week on Friday

**Richard Allison**: Good deal 👍

### CONVERSATION ON 04-26-2021

**Richard Allison**: I tried calling today.  Do you have any solution or want to drop it?

**Jeff Bergosh**: Hi Richard I apologize for not getting back to you Friday I’ve just been absolutely swamped we had a fire last week and there’s been issues with homeless and I’ve just been underwater but I’m still work and your issue I’m never going to drop it we’re going to get something done it might take me a little longer though

**Richard Allison**: Ok.... 👍 

### CONVERSATION ON 06-22-2021

**Richard Allison**: Jeff, your highway people told me a couple of weeks ago they could put some little yellow reflectors around this soggy area to discourage “muddying” along the road.  I caught the guy doing it but could not get his tag.  He comes over from Alabama to the Chicago Store.  I don’t care to catch him but I would like to make it hard for him to rut up our area.  The Baptist Church and I keep this mowed and this is not right.  This last time he backed up on the speed signed and let her rip going west.  I think pounding 3 or 4 little yellow reflectors would make it not worth his while.  When I caught him he said he does it everywhere he sees water on the side of the road.  What makes it worse is he doesn’t even live in Florida.  Can you help me please?

**Jeff Bergosh**: I will.  I’ll see if we can get some installed.  There will always be malicious idiots causing trouble no matter what we do though...

**Richard Allison**: I know...  Just part of the territory.  Thanks Jeff.

### CONVERSATION ON 06-23-2021

**Jeff Bergosh**: Yes it is

### CONVERSATION ON 10-02-2021

**Richard Allison**: Hi Jeff, I caught red handed one of the idiots trying to mud run in front of the swamp.  He came onto Cerny at the stop without stopping and he was positioning himself off the road to make a mess but he thought I would go around him and I didn’t.  I got his tag instead. Florida Y35 7P8.   Old Chevy or GMC pickup.  I don’t expect anything tonight but I am not sure what can be done at this point.  You have any ideas?

### CONVERSATION ON 10-03-2021

**Richard Allison**: Jeff, one other thing... Do you have any volunteer old guys like me too old to fight fire but can wash hose, fill air bottles, load hose etc at the fire station?

**Richard Allison**: I am 67 years old and willing to help if I would be useful.  Sometimes cleaning up after a working fire is more work than the actual fire...  I can get you my fire service references...

### CONVERSATION ON 10-04-2021

**Jeff Bergosh**: Richard that is an awesome thing to volunteer to do.  I’ll check on that and let you know

**Richard Allison**: Thanks

