

## CONVERSATIONS WITH DONNA UNDERDONK

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: Sure, Donna. Whatever I can do to help- no problem. We just bought (2) Kia’s in a 12 month period for Tori & Brandon. They have a zero down low monthly payment on a 3 year lease with low cost option to buy at the end of the lease period. My sales guy is Neil Patel. Let me know what kind of car you are looking for & I’ll put some feelers out. Sally told me about the hurricane flooding your house. I’m so sorry. 

**Jeff Bergosh**: Tell him u want the “BERGOSH deal”-lol

### CONVERSATION ON 09-24-2020

**Jeff Bergosh**: Hi Donna- I'm in a BCC meeting I'll call u after

