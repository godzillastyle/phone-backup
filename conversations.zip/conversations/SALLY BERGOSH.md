

## CONVERSATIONS WITH SALLY BERGOSH

### CONVERSATION ON 10-18-2019

**Jeff Bergosh**: Leaving the office right now headed home ❤️❤️

### CONVERSATION ON 10-22-2019

**Jeff Bergosh**: Please remember to bring home the easel on your way home... love u!

**Sally Bergosh**: Liked “Please remember to bring home the easel on your way home... love u!”

### CONVERSATION ON 10-23-2019

**Jeff Bergosh**: Tara and Shawn came through for us—this was in the envelope!!😎👍

**Sally Bergosh**: Loved an image

**Jeff Bergosh**: From David Peaden-can you make this date/time?  I can do it if you can😎


Gospo and Gumbo is this Sunday at 5 Eleven Palafox at 4 pm. It is for the Michael E. Green Prescription Fund for the St. Joseph’s Clinic. Sally and you are welcome to be my guest. I just need to know for sure if you want to go and I will put you on the list. I spoke to Sally about it last night and told her I would follow up with you.

**Sally Bergosh**: Omg! I would have LOVED to attend, but I’m in Atlanta with Sara for National Free & Charitable Clinics Convention. We have to leave Sunday at 8 am- 1st session is at 3 pm Sunday! Bummer!! I was so excited to make that connection!! I think u should go & take notes for our spring event! Maybe Gary could go with you!?!

**Jeff Bergosh**: Okay I’ll go and represent us 😎👍

**Sally Bergosh**: Loved an image

### CONVERSATION ON 10-24-2019

**Jeff Bergosh**: Logo on the way!

**Sally Bergosh**: Got it- we will use face one for your ad & other one for logo!:)

**Sally Bergosh**: Should I reach out to Robert Rinke one last time?

**Jeff Bergosh**: Maybe let the sleeping dog lie for this time......

**Sally Bergosh**:  That’s kind of what I thought- Sean Harmon is my biggest disappointment so far!:(

**Jeff Bergosh**: Well you and I both know that disappointment. All we can do is try and then at the end we tally it up and take what we get and be thankful. 👍😎❤️

**Sally Bergosh**: Ok - never heard back from Hoxend & I sent him press release

**Jeff Bergosh**: We can work on him.  I’ll take that on 

### CONVERSATION ON 10-26-2019

**Jeff Bergosh**: Test

**Sally Bergosh**: Love!!❤️❤️

### CONVERSATION ON 10-27-2019

**Sally Bergosh**: Hey

**Sally Bergosh**: This from Maria Orff:
Decided to go to the fair this evening, not to mention bottleneck at the entrance to the fair. No police presence directing traffic into the fair. What is wrong with our county.  From my past experience police is always present at big events. I was so disappointed and I am sure the sheriff is acting like a jack ass again. Please let Jeff know. It is a shame. Big events like this bring in tax dollars which benefits the county. Just don’t understand the thinking behind this. Apologies if I am venting but I am miffed, had to wait in traffic to get in for almost an hour.

**Jeff Bergosh**: I tried but got out bid!

**Sally Bergosh**: Take note of what was included & how many & how they recognized their sponsors!!

**Jeff Bergosh**:  I

**Jeff Bergosh**: It’s pretty Freeform so far

**Sally Bergosh**: Stay- do not leave & take pictures of everything please!!:)

**Sally Bergosh**: Did u win me a date in the city?!

**Jeff Bergosh**: Unfortunately I got out bid—sorry 😏

**Sally Bergosh**: Love u, PC!!❤️❤️

**Jeff Bergosh**: Love u most.  Goodnight❤️❤️

**Sally Bergosh**: Love!!❤️❤️

### CONVERSATION ON 10-28-2019

**Sally Bergosh**: Can u ask Gary about this: I received this today from a church pastor on Sure! In inmate from work release 1 mentioned that she needs dental assistance but that she needed an outside advocate to get an appointment arranged. She’s awaiting her prison sentence and wanted it to be taken care of prior to that ruling. I don’t know her, her last or her even if her intentions are genuine. But I thought I’d at least ask around to see how an inmate would get dental care, and if I were able to arrange it if Health and Hope would see her.

Kind of a mouthful!😅

**Jeff Bergosh**: I can tell you it’s a scam!! You and I are paying for her dental care while she is in the Escambia County Jail. Even if she has other dental insurance when they’re in jail we end up paying for it and it’s extremely expensive. If she’s in state prison the state pays for it. There is no need for any additional assistance if she’s going to either jail -/—her dental and medical will all be taken care of by the taxpayers

**Jeff Bergosh**: I love you Sally-Brandon and I hung out tonight I made tacos for us and we watched football. We missed you!! Now I’m heading to bed love you❤️❤️❤️

**Sally Bergosh**: Love you right back, handsome & think you get brownie points for being the BEST dad ever!!❤️

**Jeff Bergosh**: Love u!

### CONVERSATION ON 10-29-2019

**Jeff Bergosh**: Keep her in your prayers this is in today’s paper

**Sally Bergosh**: Oh no.......this is horrible. She is VERY involved at Olive Church & this is going to kill her! :(

**Sally Bergosh**: Although Matt Gaetz came out of this okay......

**Jeff Bergosh**: Yeah I was bummed out to see this....we can all take a lesson from this though, and say “there but for and by the grace of God go I”

**Jeff Bergosh**: You have an appt with Holly Crawford, Pa on Oct 30@2:20 PM. YES to confirm. 850-626-9626 to cancel or resched. STOP to opt-out. Rates may apply.

**Sally Bergosh**: Just took care of- thanks!

**Jeff Bergosh**: Are you almost home boxer?? 

**Sally Bergosh**: I’m ironing out job description for hiring Narcan Position!!

**Jeff Bergosh**: In Pensacola?

**Sally Bergosh**: Yes!

### CONVERSATION ON 11-01-2019

**Jeff Bergosh**: On way home 😎❤️👍

**Sally Bergosh**: Party starts at 6 pm

**Jeff Bergosh**: Hurrying

### CONVERSATION ON 11-04-2019

**Sally Bergosh**: Call me

### CONVERSATION ON 11-06-2019

**Sally Bergosh**: This is Claire’s mom, Huntley Jimenez. She wanted to know if the youth commission was meeting this week? I told her one of you would call her and get her up to speed.:)

**Jeff Bergosh**: Thanks!

**Sally Bergosh**: Thank you!!❤️❤️

**Sally Bergosh**: ❤️

### CONVERSATION ON 11-07-2019

**Jeff Bergosh**: In mtg

**Jeff Bergosh**: Look what Rocky did today!!!!!!!!

**Sally Bergosh**: Did he harm the poles or mugs?

**Jeff Bergosh**: No

### CONVERSATION ON 11-08-2019

**Sally Bergosh**: How did it go?!!?

**Jeff Bergosh**: It was awesome

**Jeff Bergosh**: Can u talk?

**Sally Bergosh**: Tag- u r it!!

### CONVERSATION ON 11-10-2019

**Sally Bergosh**: On my way back from church- love you! ❤️

### CONVERSATION ON 11-11-2019

**Jeff Bergosh**: I just sent u the PowerPoint rough draft to your email check it out and let me know what you think?

**Sally Bergosh**: Looks great but where is the text to give?

**Jeff Bergosh**: I’m going to add it—just wanted to make sure u were good with the format and the 10 seconds in between slides first

**Sally Bergosh**: Yes- 

**Jeff Bergosh**: Okay I’ll add the text to give and the sponsors posters as well and I’ll clean it up some more

**Sally Bergosh**: Thank you- on conference call- will call u back

**Jeff Bergosh**: Okay

**Sally Bergosh**: Sara asked me if I had seen it today!!

### CONVERSATION ON 11-13-2019

**Jeff Bergosh**: Chip Simmons edged me out for first place dang it ! he raised $38,000 in October and I only raised $29,000 in October so I didn’t finish first I’m in second but still feeling great! Love you

**Sally Bergosh**: Love u & am so proud of u!!❤️

**Jeff Bergosh**: Thank you—love u too!  

**Jeff Bergosh**: Non-stop one way flight 2 hrs on Silver Airways $199

**Sally Bergosh**: That means $400 for Mike

**Sally Bergosh**: 😥

**Jeff Bergosh**: I can find a much cheaper round trip for him.  

**Jeff Bergosh**: $239 round trip

**Sally Bergosh**: Here’s the line- up

**Jeff Bergosh**: Okay so u will be doing Thursday and Friday till 2:30? The Wednesday session is optional-  so I assume you are not going to the Wednesday, right?

**Sally Bergosh**: Correct

**Jeff Bergosh**: Okay let’s discuss it tonight and game plan a strategy that will work

**Jeff Bergosh**: I’m planning on going there right after I get off today

**Sally Bergosh**: Yes!

**Jeff Bergosh**: Okay meet me there at 5:00 okay?

**Sally Bergosh**: Yes- I will be there

**Jeff Bergosh**: 👍😎❤️

**Sally Bergosh**: Does this seem ok for Sara’s plaque?

**Jeff Bergosh**: Looks awesome!!!

**Jeff Bergosh**: Perfect

**Sally Bergosh**: K

**Jeff Bergosh**: Heading toward Artel RN

**Sally Bergosh**: Almost to your garage

**Sally Bergosh**: U here!?!

**Sally Bergosh**: Monday night at 5:30 pm we need to book the private room at McGuires for (10)- Hillary Smith’s bday!

**Jeff Bergosh**: This Monday??

**Sally Bergosh**: Yes

**Sally Bergosh**: Thank u !

### CONVERSATION ON 11-14-2019

**Jeff Bergosh**: Just leaving office and got your message.  I don’t think we get BLAB tv plus I’m heading to Guitar Center to get your cable.  You need to have someone else tape it.  Call Sara

**Sally Bergosh**: Do I have $ in my account? I have a hair appointment at 5:30 pm tonight

**Jeff Bergosh**: Yes $700

**Sally Bergosh**: Oh- ok

### CONVERSATION ON 11-15-2019

**Jeff Bergosh**: Sally—Civic Center staff invited us to meet the band backstage before the show—do you want to take them up on this?  It’s at 4:45.  Awesome right?!?!!!

**Jeff Bergosh**: Meanwhile though there’s plenty of drinks in the cooler help yourself until I get back love you❤️❤️

**Sally Bergosh**: I’ve got my phone now & will just meet u back at the hotel- letting the dog out at the house right now!! Have fun & see u soon!❤️

**Jeff Bergosh**: Love u❤️

### CONVERSATION ON 11-18-2019

**Jeff Bergosh**: Any issues?

**Sally Bergosh**: Randy has still not shown up but maintenance guy has been very nice!

**Jeff Bergosh**: How is it looking?

**Sally Bergosh**: Randy just informed me he has another writing class tomorrow at noon.....this guy is not “with it”- I told him we booked this with him months ago & we need to be able to set up tomorrow, too.

**Jeff Bergosh**: Okay we will get u in there tomorrow too

**Jeff Bergosh**: R u still over there

**Sally Bergosh**: Sara & Becky are there- I’m down the street picking up wreaths & trees- all the stuff for the screen is by the wall we need to set it up at

**Jeff Bergosh**: At the wall?

**Sally Bergosh**: Yes- inside Artel

**Jeff Bergosh**: Okay still in meeting but I’ll come over after and before my lunch.  If we don’t have enough time I’ll get back there at 4:15 and we can do it before your dinner function tonight

**Sally Bergosh**: Perfect!:)

### CONVERSATION ON 11-20-2019

**Sally Bergosh**: Will u go back to your post from last night & tag Barbara Freeman instead of Barbara Rogers, who wasn’t even there!?

**Jeff Bergosh**: Will do ❤️😎

**Jeff Bergosh**: You need to share my post to your wall, then you can tag her because you are friends with her

**Sally Bergosh**: Get rid of the tag on the other Barbara

**Sally Bergosh**: Do I have $ in my account?

**Jeff Bergosh**: I’ll check rn

**Jeff Bergosh**: My coworker Gary has been to New York several times with his wife; he gave me this cheat sheet listing some big attractions and their vicinities.  I thought that was really nice🙂

**Sally Bergosh**: Awesome!!❤️

**Jeff Bergosh**: DL2715, PNS TO ATL, 9:05am 21NOV. Open link to view Boarding Pass.

### CONVERSATION ON 11-23-2019

**Jeff Bergosh**: Sally I’m out in front of the restaurant under the awning just waiting for you where are you?

**Sally Bergosh**: Gift shop line!!

**Jeff Bergosh**: ????

**Sally Bergosh**: Inside the door

### CONVERSATION ON 11-25-2019

**Sally Bergosh**: In Bella Magazine this month!


**Sally Bergosh**: Omg!!

**Sally Bergosh**: I totally agree

**Sally Bergosh**: B had class at 9:30 am today

**Sally Bergosh**: What a good grandson! ❤️

### CONVERSATION ON 11-26-2019

**Jeff Bergosh**: ????

**Sally Bergosh**: Can u go on that public record site for Florida & just try looking up an Andy Miller for me please?!?

**Jeff Bergosh**: Andy Miller? Is that his full name

**Sally Bergosh**: He wants to do a Thanksgiving Neal for one of our patient FAMILIES tomorrow & I’ve got to at least try & have him vetted!

**Jeff Bergosh**: Okay.  Does he live here in Escambia County?

**Sally Bergosh**: Yes

**Sally Bergosh**: White guy brown hair very nice......said he just got back from Tony Robbins thing & he encouraged everyone at the conference to “pay it forward” anonymously for Thanksgiving. My clinical director wants us to try & vet this guy.......grrrrr

**Jeff Bergosh**: Not seeing his name come up

**Jeff Bergosh**: Meanwhile, dinner is served!

**Sally Bergosh**: Wowza- that looks amazing!!

**Jeff Bergosh**: It’s awesome!  Come home!

### CONVERSATION ON 11-27-2019

**Sally Bergosh**: Have u told Tori & B what time we are eating turkey tomorrow? 2:00?

**Jeff Bergosh**: Yes

**Sally Bergosh**: R they both coming?

**Jeff Bergosh**: She’s working till 5

**Jeff Bergosh**: She will come at 5

**Sally Bergosh**: I need our IPC #

**Jeff Bergosh**: 294

**Jeff Bergosh**: Why

**Sally Bergosh**: I took Carol to lunch and THANKED her profusely for all she does at the clinic!!:)

**Sally Bergosh**: I didn’t know your # so just wrote your # on the ticket- she can look it up, right?

**Jeff Bergosh**: Yes 

### CONVERSATION ON 11-29-2019

**Sally Bergosh**: We also need those things we put on ornaments to hang on tree- hooks

**Jeff Bergosh**: What?  Call me, I do t know what that is??

**Jeff Bergosh**: Bad wreck on I-10 Eastbound at Hwy 29 according to the radio.  Hope everyone is away from that area

### CONVERSATION ON 12-01-2019

**Sally Bergosh**: Loved “Around here the world stops, traffic comes to a halt, there are no Cars on the road, there are no people on the streets, there is nobody shopping at Walmart—-and no phones get answered when the Alabama Crimson Tide plays Auburn in the iron bowl.”

**Sally Bergosh**: Loved “The Ducks just won 24-10!!!10 go decks 24 to 10 skews me 24 to 10 the ducks won why is it showing it”

### CONVERSATION ON 12-02-2019

**Sally Bergosh**: This #giving Tuesday is taking MUCH longer then I had anticipated!! Sorry!! I’m putting the work in so it’s done for tomorrow!!

**Jeff Bergosh**: No worries dinner is ready when you get here❤️❤️

**Jeff Bergosh**: I have coffee with commissioner in morning so I’m going to bed.  I put the soup in the fridge—it’s really good.  Goodnight, love u

**Sally Bergosh**: ❤️❤️

### CONVERSATION ON 12-04-2019

**Sally Bergosh**: Who is this: The Staley Family, 454 Peachtree Lane, Bowling Green, KY 42103? We received a Christmas card from them last year but I have no clue

**Jeff Bergosh**: Jimmie Staley—you can scratch them from the list.  They are folks that I know from Facebook 

**Sally Bergosh**: Are u sure u don’t want to send them one? Good PR?

**Jeff Bergosh**: Nah, let’s save them for more friends and family locally

**Sally Bergosh**: Do we know any electricians?

**Jeff Bergosh**: I know one, why?

**Jeff Bergosh**: What’s happening?

**Sally Bergosh**: Jim trouble shooter this light going out last week. There is no electricity coming to it- it’s not a matter of changing the ballis. We now need an electrician to come help us for cheap/ I kind

**Jeff Bergosh**: Okay this could be a David Mobley deal

**Sally Bergosh**: Perfect- great idea!!

**Jeff Bergosh**: It’s a small black book

**Sally Bergosh**: I have not seen it!:(

**Sally Bergosh**: Ask Brandon

**Jeff Bergosh**: Neither did he.  It must have got lost.  I’ll look around the house today when I get home but if it’s not there I’ll report it as not delivered to Amazon.  It’s $11 bucks but hey I just want my day timer

### CONVERSATION ON 12-05-2019

**Sally Bergosh**: If u get done at meeting - we are at Civic center!!

**Jeff Bergosh**: I’m still in meeting

**Jeff Bergosh**: ??

**Sally Bergosh**: Wreaths of Joy at Civic Center- they have a chair for u & pretty frocking amazing event!!

**Jeff Bergosh**: Still in meeting for hours

**Sally Bergosh**: Loved “Patti and Tom Wilser are coming to our house for Christmas Morning 10 AM and ret Patti and Tom Wilser are arriving in SD on SWAirlines at 10 AM on December 25 and returning December 28!!! I am so excited!!!”

### CONVERSATION ON 12-06-2019

**Jeff Bergosh**: In Governors press conference

**Sally Bergosh**: I’ve gotten dozens of these kinds of messages today- this (1) is from Brian Nall:

“Let Jeff know I’m praying for him today as much is on his plate with NAS Shooting. Appreciate his service and leadership.”-Brian Nall

**Jeff Bergosh**: Thanks!

**Sally Bergosh**: Thank you, Hillary!!❤️

### CONVERSATION ON 12-07-2019

**Jeff Bergosh**: Got your index cards

**Sally Bergosh**: Thank you!!

**Jeff Bergosh**: ❤️

**Sally Bergosh**: Classic!!

### CONVERSATION ON 12-08-2019

**Sally Bergosh**: I’m “late” cuz I sing in choir at Hillcrest

**Jeff Bergosh**: Same seating location

**Jeff Bergosh**: Off street

### CONVERSATION ON 12-10-2019

**Jeff Bergosh**: Do you have any interest in going to McGuire’s IPC Christmas Happy Hour at 5:30-7:00 tonight?

**Jeff Bergosh**: ?????? Do u want to go??????

**Sally Bergosh**: No

**Jeff Bergosh**: Okay just making sure

**Sally Bergosh**: I’ve got Christmas get together with Stacey, Bonnie & Donna for dinner

**Sally Bergosh**: Starts at 6:30 pm

**Jeff Bergosh**: Okay love u.  I’ll see u at the house.  Don’t drink and drive and remember you have to pack for your trip still..............

### CONVERSATION ON 12-11-2019

**Sally Bergosh**: Please call Terri Aulger ASAP:

Of course....I really need your other half....my brother in law needs some help as a former county employee.  He was mechanic for landfill 32 years...long story... They won't let him have his tools he feels Janice gilley's making an example of him...he has pancreatic cancer...I really need his help.

**Sally Bergosh**: ,? 

**Jeff Bergosh**: Okay I’ll call her

**Jeff Bergosh**: Text me her number please

**Jeff Bergosh**: Ok thx

**Jeff Bergosh**: Room is good?

**Sally Bergosh**: I told her u were going to call her A Thanks...just a sad situation.  He's been my brother in law for 41 years 

**Sally Bergosh**: That was her reply- my text above!!:)

**Jeff Bergosh**: Going to bed.  Love u!!

**Sally Bergosh**: In bed- love u most!!❤️

**Jeff Bergosh**: That sucks!  Wear the ski mask and bundle up Nick!

**Sally Bergosh**: I’m in Orlando & I have the air cranked it’s so hot!!

### CONVERSATION ON 12-12-2019

**Sally Bergosh**: So- I have a self- parking pass up in the room-9939 Universal Blvd., Orlando 32819......Rosen Shingle Creek, rm #11314, 11th floor, wing 3.....far from the elevator- VERY nice resort, very good restaurants.

**Jeff Bergosh**: Okay I’ll text u when I get close

**Sally Bergosh**: They have a key for you at the front desk

**Sally Bergosh**: Love u & be safe!!

**Jeff Bergosh**: Awesome.  Love u too!

**Jeff Bergosh**: Where in the room will u leave the pass?

**Sally Bergosh**: It’s bright orange sitting by the tv- or it might be quicker to just ask for another one at the front desk- this place is massive!!

**Jeff Bergosh**: Okay I’ll see u tonight I’ll call u from the road.  Have a meeting at 9:00 then I’m leaving straight after

**Jeff Bergosh**: In room, where r u?

**Sally Bergosh**: Go to conference center downstairs, turn left at stairs & we r in Butler room!!  What do u want to drink? Beer or wine?

**Jeff Bergosh**: I’m rugged from the road

**Jeff Bergosh**: ???

**Sally Bergosh**: Jeans & shirt

**Sally Bergosh**: Come on!!

**Jeff Bergosh**: Shorts?

**Sally Bergosh**: Sure!!:)

**Sally Bergosh**: Hurry up, Boxer!!

### CONVERSATION ON 12-13-2019

**Jeff Bergosh**: 4 more holes

**Sally Bergosh**: In the rain?!!?

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Back at room, getting a shower.  R u done with conference yet?

### CONVERSATION ON 12-16-2019

**Sally Bergosh**: Another package arrived as Tori arrived home, & so I gently urged her to write down her debt on paper & start knocking it out- she mentioned Dylan’s gift & I told her u & I had Marsh peeps covered. She told me to get F off her & she regrets EVER moving home & would rather be “homeless”.....I left the room in shock- I have no words!!:(

**Sally Bergosh**: 💔

**Sally Bergosh**: I just chatted with Tori & told her she has so much to be thankful for & she cried & told me it’s just been a hard year

**Jeff Bergosh**: Wow

**Jeff Bergosh**: What should we do??

**Sally Bergosh**: Love on her!!

**Jeff Bergosh**: ❤️

**Jeff Bergosh**: Just about to go to bed

**Sally Bergosh**: Just finished grant- on my way home.

**Jeff Bergosh**: ❤️

**Sally Bergosh**: Was this at Christmas at the clinic?

**Sally Bergosh**: Oh good!! Fantastic!! 

**Sally Bergosh**: Yay!  How did it go?

### CONVERSATION ON 12-17-2019

**Sally Bergosh**: This from Sara Davy- this guy sponsored Christmas at the Clinic & wants us to join him for this upcoming event! He’s an old friend of John Davy & tried to have u as a guest at Wreaths of Joy this year but u had county meeting!!

Hey! Hope you had a good flight! I shared your contact with Rene West @ Executive Landscaping. He ask us to the Big Brothers fundraiser on Jan 17 and wanted to ask y’all too.

**Jeff Bergosh**: Thx

**Sally Bergosh**: Put on calendar please- we don’t want another IHMC

**Jeff Bergosh**: What time on the 17th and where?

**Jeff Bergosh**: Also—Gary and Carissa Invited us to their house Christmas Eve for the gift exchange how do you want us to respond?

**Sally Bergosh**: Yes that’s fine as long as Freak 1 & Freak 2 aren’t there!!

**Sally Bergosh**: 1/17- Black Tie at Skopellos, 5:30/6 pm

**Jeff Bergosh**: It will be family only—not neighbors

**Sally Bergosh**: K

**Sally Bergosh**: We have candle light service at church either at 4:00 or 6:00 pm-invite them!!

**Jeff Bergosh**: Okay

**Jeff Bergosh**: 4:00

### CONVERSATION ON 12-18-2019

**Sally Bergosh**: Buy your table for prayer breakfast ASAP- I do NOT want to be in the back with Underhill!!

**Jeff Bergosh**: Where is your party tonight?

**Sally Bergosh**: Stacey Balka’s house down the street from Cordova Park Elementary

**Jeff Bergosh**: Hey do I need to head that way?

**Jeff Bergosh**: ????

**Sally Bergosh**: We r leaving Stacey’s house right now!! I’m headed towards Tonya’s house- 5101 High Pointe Drive

**Jeff Bergosh**: Okay I’ll head that way

**Sally Bergosh**: Love you!!

**Jeff Bergosh**: Love u!

**Sally Bergosh**: ❤️❤️

**Jeff Bergosh**: Here

**Sally Bergosh**: Hang in there, Nicky!! We are so excited to get you HOME to sunny Florida!! Love you!!❤️

### CONVERSATION ON 12-19-2019

**Jeff Bergosh**: I read this sad and tragic article about Judy Garland.....thought it might interest you.  Love you!!!



**Sally Bergosh**: I’ve read everything on her- she’s my girl!! Very tragic life

**Jeff Bergosh**: Yep 

### CONVERSATION ON 12-20-2019

**Sally Bergosh**: Meanwhile- while u r in trenches in a battle over a random employee at the county- we got this massive postcard today!!

**Jeff Bergosh**: What a nice guy— sending out Christmas Cards!

**Sally Bergosh**: “Casey cares for the community”- someone SMART is helping him!!

**Sally Bergosh**: Did u invite your pastor to the prayer breakfast yet?

**Jeff Bergosh**: No

**Jeff Bergosh**: Call me

**Jeff Bergosh**: Can u be there to get him at that time

**Sally Bergosh**: Yes

### CONVERSATION ON 12-21-2019

**Sally Bergosh**: Did your media guy call you back?

**Jeff Bergosh**: He never did, he must be on vacation

**Jeff Bergosh**: Take pictures though and we will put it on Facebook.

**Sally Bergosh**: Already did!!:)

**Sally Bergosh**: So so many of our patients don’t have transportation in the rain so I’m delivering a few turkeys & hams with Carol & the rest will be picked up at the clinic tomorrow! Ughhh

**Jeff Bergosh**: Wow that’s dedication

**Jeff Bergosh**: ?

**Sally Bergosh**: ❤️❤️

### CONVERSATION ON 12-22-2019

**Jeff Bergosh**: Is This is the one he wants?

**Sally Bergosh**: Yes- perfect!!👍

**Jeff Bergosh**: Got it

**Jeff Bergosh**: I’m in Best Buy anything else I can get here?

**Sally Bergosh**: On Nickys list he asked for Amazon gift cards.....

**Jeff Bergosh**: How much?

**Sally Bergosh**: $100

**Jeff Bergosh**: Doesn’t look like they have them here but I’ll go somewhere else

**Jeff Bergosh**: Should I grab a couple of small gifts for Alex and Ben?

**Sally Bergosh**: Nothing more then $100 total!!

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Situational awareness

**Sally Bergosh**: U rock!!❤️❤️

**Sally Bergosh**: Classic!!

**Jeff Bergosh**: Bed bath and beyond

**Jeff Bergosh**: R u still out and about?

**Sally Bergosh**: R u working on January 1? I need u the 31st- 1st- r u good?!

**Jeff Bergosh**: I am off Jan 1

**Jeff Bergosh**: I’m off the night of 12-31-19 though 😁

**Sally Bergosh**: Perfect!!

**Jeff Bergosh**: Are u at the dance recital?

**Sally Bergosh**: Dance recital is over & almost home!!

### CONVERSATION ON 12-23-2019

**Sally Bergosh**: ❤️❤️Drive safely!!

### CONVERSATION ON 12-24-2019

**Jeff Bergosh**: Can u call me when u have a minute?  Love,  me

**Sally Bergosh**: Maybe u could pick up some quick Christmas candy stocking stuffer for B’s stocking & Nick’s!

**Jeff Bergosh**: Ok

**Sally Bergosh**: Mostly B!!

### CONVERSATION ON 12-30-2019

**Jeff Bergosh**: R u at home?

**Sally Bergosh**: The boys all want to be there

**Jeff Bergosh**: Okay I’ll call and set it up for this afternoon

**Sally Bergosh**: Call Tori first

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: Classic

**Sally Bergosh**: I think Tori is taking it the worst!! She finished with her client early & came home only to find that Nicky had eaten her steak from McGuires yesterday & I guess her car broke down & she said with Rocky & all that she is declaring this the worst day ever!!:(

**Jeff Bergosh**: Well unfortunately I got a call from the veterinarian this morning. And the news is not good about Rocky. His body can’t take the stress of surgery and the sock or whatever the object is in his stomach is not passing. He started vomiting and is rejecting the anti-nausea medicine. The doctor recommends sadly that it’s time for euthanasia.  Obviously I am very sad. So we can do this a couple of different ways we can all go see him and say goodbye and leave or we can be there when they administer the medicine. Let me know what you all think and if you want to say goodbye to him One last time in person before we put him down. I spoke to the doctor at length they will cremate him we’ll get the ashes and I’ll probably spread them at the beach. Although it is very hard to do —-we must remember that even though we love Rocky he is an animal and this is part of it but he’s had a good life and we have really enjoyed having him as part of the family for the last 13 years. but we all knew this day would come in today it’s here. Let me know how you guys want me to proceed I can just take care of it if that’s easier for you all but let me know love you all

Dad

**Sally Bergosh**: When r u going there?

**Sally Bergosh**: I don’t know if we all should be there- what do u guys want?

**Sally Bergosh**: Tori- what time do u get off of work?

**Jeff Bergosh**: I called them and made the appointment it’s at 5:20 that’s the last time they could do it 520 at Pine meadow Vet clinic

**Sally Bergosh**: We will all be there!!❤️😥

**Jeff Bergosh**: 😩😪

### CONVERSATION ON 12-31-2019

**Jeff Bergosh**: Tarzan slot machine

**Sally Bergosh**: Where is that?!

**Sally Bergosh**: Worker here said she doesn’t think we have Tarzan

**Sally Bergosh**: We r going towards smoking courtyard

**Sally Bergosh**: We r by Canal Street exit- seriously, Susan & Bruce don’t want to leave me alone & they e ready to go back to hotel

**Sally Bergosh**: We are on a road trip & need our music- get off our Napster, please!!

**Sally Bergosh**: 😘

**Sally Bergosh**: Still on our road trip so can u please get off our Napster account?

**Jeff Bergosh**: Thanks Guys--it's tough saying goodbye--but I appreciate the kind words!

**Sally Bergosh**: Thank you! This has been very sad for us💔

### CONVERSATION ON 01-02-2020

**Jeff Bergosh**: Hey Sally can u give me a call?  It’s about Tori’s car.  Love u

**Jeff Bergosh**: At Kia with Tori

**Sally Bergosh**: I just opened mail from Allen Turner Foundation & he sent us a check for $10,000!! I can’t believe it!!👍❤️❤️

**Jeff Bergosh**: That’s outstanding!!!!!!!!!!!!!!!!!

**Jeff Bergosh**: Nicole partridge would’ve never got that check LOL

### CONVERSATION ON 01-03-2020

**Sally Bergosh**: Picking up Panda Express for din-din tonight & family game night!! If I don’t hear back from you in the next 30 minutes I will get everyone orange chicken & fried rice

### CONVERSATION ON 01-04-2020

**Sally Bergosh**: Where r you?! Thought we were taking down Christmas today?!!?

**Jeff Bergosh**: Wal mart 

### CONVERSATION ON 01-07-2020

**Sally Bergosh**: Let me know when u feel up to responding - this is the message we received yesterday from Nena Haigler:

Hayne good with playing Sunday at 3. Check with Jeff. We can play at UWF if you prefer. Dinner out after.

**Jeff Bergosh**: Okay let’s do this 😎

**Jeff Bergosh**: Love u— long day I’m hitting the sack.  R u almost home?

**Sally Bergosh**: Yay!! Really?! I’m in driveway!!

### CONVERSATION ON 01-08-2020

**Sally Bergosh**: Thank you!! ❤️❤️

**Sally Bergosh**: Got it!!:)

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: Remember we’re gonna meet at home at five so we can go to that movie at seven and have dinner first at mellow mushroom

**Jeff Bergosh**: Let me know if that plan is still ago

**Sally Bergosh**: Yes!!

**Jeff Bergosh**: See u at 5:00 😎👍

**Sally Bergosh**: I’m trying to get up the hill 😂

**Jeff Bergosh**: Right on have fun!

**Sally Bergosh**: Enjoy!!❤️

**Sally Bergosh**: Can u come by clinic and pick up these chairs that are all attached that need to be removed from our lobby & donated across the street?

**Jeff Bergosh**: When—can it be done Saturday?

**Sally Bergosh**: Can’t Nicky come by after golfing? It will literally take 10 minutes MAX!

**Sally Bergosh**: They are just too heavy for me

**Sally Bergosh**: 1718 East Olive Rd- we r in parking lot behind Olive Church

### CONVERSATION ON 01-10-2020

**Jeff Bergosh**: I’ll call u right back

### CONVERSATION ON 01-11-2020

**Sally Bergosh**: Jim Cox is sick & cant go- this text from Carol!! I’ve wanted to go to this for years but sells out quickly! 

Hi Sally, Jim is not feeling well today.  He is dead tired.  We have tickets tonight for Beethoven and Blue Jeans at the Sanger.  Would you and Jeff like to have the tickets?  Dress is casual.

**Sally Bergosh**: The storm is supposed to come in & out quickly- done by 6 pm tonight!

### CONVERSATION ON 01-13-2020

**Sally Bergosh**: Can you add this photo to our New Years Post you did? It won’t allow me to make any changes since your post!:(

**Jeff Bergosh**: Ok

**Sally Bergosh**: Thank you!!❤️

**Jeff Bergosh**: Done ❤️

### CONVERSATION ON 01-15-2020

**Sally Bergosh**: Can u check if I have $ in my account?

**Jeff Bergosh**: You do you have more than $300 in there love you

**Sally Bergosh**: Thank u!!:)

### CONVERSATION ON 01-16-2020

**Jeff Bergosh**: Employee of the month—r u coming home??

### CONVERSATION ON 01-17-2020

**Jeff Bergosh**: Do you Tori and Brandon want to march in Monday’s Martin Luther King Parade with me?  It’s 10:00-11:15.  ❤️😎👍

**Sally Bergosh**: I can’t/ I have a tennis match

**Sally Bergosh**: Kids can’t either- darn it!:(

**Sally Bergosh**: Do u or Mike Kenney know anyone at Sinclair Broadcasting? My friend Susan Davis just applies for a job in Sales with them- 

**Jeff Bergosh**: I’ll ask

**Sally Bergosh**: ?!!?

### CONVERSATION ON 01-18-2020

**Sally Bergosh**: Who do we know at Sinclair, WEAR TV?

**Jeff Bergosh**: I know the local news director that’s it

**Sally Bergosh**: What’s his name?

**Sally Bergosh**: Thanks!

**Jeff Bergosh**: ❤️

### CONVERSATION ON 01-21-2020

**Sally Bergosh**: Daniel Kreitzman is one of the asses that commented on your MLK parade pictures- he put on his Facebook & said he is going to file lawsuit since u r stifling his freedom of speech- Doug’s wife said u weren’t marching for MLK but Yourself! Ugh!!

**Jeff Bergosh**: What a tool

**Jeff Bergosh**: He’s a campaign acolyte for Jonathan Owens.  I had a couple of imposters who had friended me so I I un-friended them.  I did nothing wrong, these tools are just grasping at straws.  Just ignore their noise.

**Sally Bergosh**: Ugh!! Let the ugliness begin!!:(

**Sally Bergosh**: For Wendy to jump in immediately is just crazy

**Jeff Bergosh**: Don’t let it get to you.  Hate from the hate squad

**Jeff Bergosh**: Tools

**Sally Bergosh**: Don’t engage!!

**Jeff Bergosh**: I didn’t

**Jeff Bergosh**: Hey I’m making Dinner—you going to make it home for it?

❤️

Me

**Sally Bergosh**: I already told u I’m watching Sara’s first presentation on Narcan to entire college of health at UWF

**Sally Bergosh**: Of course- she started at 6 pm & I’m still at the clinic

**Jeff Bergosh**: Okay I’m making pasta and there will be leftovers ❤️👍

**Sally Bergosh**: Love you!!

**Jeff Bergosh**: Love u most!

### CONVERSATION ON 01-22-2020

**Jeff Bergosh**: Employee of the month are you coming home?

**Sally Bergosh**: On my way- event at NEL

### CONVERSATION ON 01-25-2020

**Sally Bergosh**: Yikes!! What was the email address it was sent from- phishing attack- hope he didn’t fall for it!!

**Sally Bergosh**: Gary is freaking out.,...what does Phill think he should do?

**Sally Bergosh**: Thank you!! Thank Phill for us!!

### CONVERSATION ON 01-27-2020

**Jeff Bergosh**: Today’s PNJ cartoon.  I guess they don’t want me participating in The parades any more......

**Sally Bergosh**: Unbelievable! This confirms to me that the PNJ is definitely trying to influence your election!! Why did they not include the other commissioners?! This is personal to them!!

**Jeff Bergosh**: Welcome to what I’ve known for years

**Jeff Bergosh**: And make no mistake about it they are fake agenda driven biased slanted “news”

**Sally Bergosh**: Still glad you baited them last week at your meeting? At the end of the day they have more ink & it’s really not worth it. “County Chaos” is what Johnathon Owens is running his entire campaign against you on.....this falls right in line with his plan!!

**Jeff Bergosh**: When I’m over the target (s) I take anti-aircraft Fire 

**Jeff Bergosh**: Love u

**Sally Bergosh**: Love u right back!!

**Jeff Bergosh**: Stick with me!  Stand with me!

**Sally Bergosh**: So the Civicon Chat today featuring Grover & Janice Gilley is sponsored by the PNJ & is now moved to main Saenger Theatre due to over 400 peeps attending- r u sure u don’t want to be there & hear Janice’s vision for the county? Seems a little more important

**Jeff Bergosh**: No

**Sally Bergosh**: PNJ is being fed stories by DUnderhill- mark my words!

**Jeff Bergosh**: Wouldn’t surprise me

**Jeff Bergosh**: Focus on some positive stuff

**Sally Bergosh**: Monday paper- readership?

**Jeff Bergosh**: Smaller than Sunday’s LOL

**Jeff Bergosh**: Let me know what you think obviously I prefer you to be with me at the rec but I’m just thinking out loud.......

**Sally Bergosh**: I want to be by your side- can u ask Gary to attend or Carissa?

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: ❤️

**Sally Bergosh**: Worst morning ever for our family!! Rebel flag is being put in every cartoon with you- manipulation with social media & the press in P’Cola is very scary!! My job is very public so don’t think this only affects you! Every decision u make spills out onto the rest of us!! I’m about to do a presentation in front of hundreds of women of all colors & I feel like there is a dark cloud over this event!!!!!!

**Sally Bergosh**: Maybe I will just let Sara present for us- I don’t want a dark cloud over the good things our clinic is doing!!

**Jeff Bergosh**: I know but I did not want to not tell you

**Jeff Bergosh**: Unless John told her

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Brandon- you have crossed the line one too many times between your constant guilt trips about anything we do for your siblings, to how we don’t do enough for u rants, to your blatant disrespect by smoking in my backyard & in my face! You do NOTHING to show me respect or to give back to this family- zero chores, laundry, dishes, etc. I’m at the end of my rope after today’s incident of you completely disobeying my request to keep it down this AM with Tori’s few hours to get sleep before her next shift at 1 pm!! You singing super loud on purpose & telling me it’s Not your fault Tori is working those hours tells me you have ZERO respect!!

**Sally Bergosh**: I should have not said the words “I hate you” in anger. Quite the contrary, I love you too much to allow you to continually disrespect me!! 

**Sally Bergosh**: You either need to move out & not lean on me for anything or start changing your black heart- you are living a Godless life of “ME, ME, ME”- We will chat more Tonight!!

**Jeff Bergosh**: He knows what I just told him he’s got a week it’s time for him to move out and be a big boy

### CONVERSATION ON 01-30-2020

**Sally Bergosh**: I’m on my way home- has to put out another fire!!

**Jeff Bergosh**: I’m still at work :(

**Jeff Bergosh**: ?

**Sally Bergosh**: No- I will make something when I get home

**Jeff Bergosh**: Are you sure?

**Sally Bergosh**: Whatever u want is fine with me

**Jeff Bergosh**: I had a great luncheon with Gary holt today and he gave me $900 worth of checks for my campaign😎👍

**Jeff Bergosh**: But it was a 2 1/2 hour lunch that’s why I’m working late

**Sally Bergosh**: No worries- I’m still at clinic- crazy lady called me at 5:30 pm tonight saying one of my best doctors tried to kill her:(

**Jeff Bergosh**: What????

### CONVERSATION ON 01-31-2020

**Sally Bergosh**: I’m going to get off work EARLY for real today! I’m getting a pedi & just had the BEST meeting with a fundraising guru- she had some amazing ideas for our clinic!!

**Jeff Bergosh**: Outstanding!

**Sally Bergosh**: What time are u planning on getting back to house? 

**Jeff Bergosh**: Hopefully by 5:00 ish

**Sally Bergosh**: Huntley Jiminez’s message:

Hey! Any ideas for a rotary speaker about the NAS shooting? Chip will come but wanted to have someone with NAS too

Do u have the commander Lucky’s contact info?


**Jeff Bergosh**: Have her call Jason Bortz—NAS Pensacola’s public Information Office.  He can arrange a speaker or he will probably come himself and speak on the topic.

**Jeff Bergosh**: LOL

**Sally Bergosh**: That FUNNY!! Love you! Do u want me to pock up a Sky pizza for us?

### CONVERSATION ON 02-01-2020

**Sally Bergosh**: Can u buy this kind of body wash? It’s a game changer!!

**Sally Bergosh**: Oscar films!!

**Jeff Bergosh**: New theater?

**Sally Bergosh**: Love!!

**Sally Bergosh**: “It’s soooo Preeeety!”

**Sally Bergosh**: Don’t drink then ski, but u can ski & then get hot toddies!

**Sally Bergosh**: Google it

**Sally Bergosh**: It’s what u drink after skiing to get warm

**Sally Bergosh**: Loved “Its whiskey, honey, lemon juice, and hot water.”

**Sally Bergosh**: Classic, B!! 😂

**Sally Bergosh**: Hamilton?!!:)

**Sally Bergosh**: Rise up🎶

### CONVERSATION ON 02-02-2020

**Sally Bergosh**: His daddy is a minister

### CONVERSATION ON 02-03-2020

**Jeff Bergosh**: Hey Don’t make any plans for Friday, February 14th—-Valentine’s Day.  I have 7:15 reservations for you and I somewhere special downtown. ❤️❤️❤️❤️❤️❤️


Love u!

Me

**Sally Bergosh**: Sounds like a hard rock concert- late start

**Jeff Bergosh**: Not a concert I promise!  A delicious meal at a great restaurant!!

**Sally Bergosh**: Sounds great!! We need to put a date on our calendars for juicing!! I’m getting to my rock bottom- yikes!! Need to cleanse!

**Jeff Bergosh**: We will do it!  

**Jeff Bergosh**: Are we on!!!!????

**Sally Bergosh**: Thought we were dining with the Haigler’s on feb 23!

**Sally Bergosh**: Are we signed up yet for Gilf Power Symposium yet? Let me know what I owe as your “add on” for attending sessions!

**Jeff Bergosh**: Okay—let’s shift it two days then.  Monday Feb 24th through  Wednesday March 4th

**Jeff Bergosh**: And Debbie has the information about the cost for a visitor’s pass.  Can you call her and ask?

**Sally Bergosh**: Yes- we will just not eat at the Destin Gulfpower Symposium, do long walk instead!!:)

**Jeff Bergosh**: Okay

**Jeff Bergosh**: SALLY I need a copy of your W-2 form from nurse spring. I have all of the documentation necessary to file taxes that’s the one document that we have yet to receive. Can you call Audrianna or Susan and see if they can print one out for you?

**Sally Bergosh**: U sure it wasn’t in basket?

**Jeff Bergosh**: Positive

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Sally Bergosh**: Amazing!!:)

### CONVERSATION ON 02-05-2020

**Sally Bergosh**: Hey, Sally!! We would love to get together Thursday night. Maybe dinner?

**Sally Bergosh**: Us too! McGuires or wherever u all want to go!:)

### CONVERSATION ON 02-06-2020

**Jeff Bergosh**: In an executive session can I call u back?

**Sally Bergosh**: Yes but don’t forget! Looks like applications for county funds are due in 2 weeks!!??!

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Check your email :)

**Sally Bergosh**: K

**Jeff Bergosh**: Did u get the package?

**Sally Bergosh**: Yes! 

**Sally Bergosh**: Thank you! Can u talk?

**Jeff Bergosh**: Yes

**Sally Bergosh**: https://www.gulfpowersymposium.com/event/42dbd15d-c75c-4c25-9502-6c8b1ce00b8f/register

**Sally Bergosh**: $325!!!

**Sally Bergosh**: Loved “Thursday night works great for us too, Gary & Ben leave for hiking on Friday.❤️looking forward to seeing you”

### CONVERSATION ON 02-07-2020

**Sally Bergosh**: Do I have money in my account? 

**Jeff Bergosh**: Yes—$600

**Jeff Bergosh**: 😎👍❤️

**Sally Bergosh**: Oh good- I thought I was broke!

**Jeff Bergosh**: Nope—You’re rich LOL

**Jeff Bergosh**: Okay -  I’ve got it:

2-entree plate
Side item: fried rice
Two entrees: Kung pao chicken
                        Shanghai angus steak
                        (Alternative—if one of the two above is out:   black pepper chicken)

Add one chicken egg roll


Love u!!!!!!!!

**Sally Bergosh**: Got it

### CONVERSATION ON 02-10-2020

**Jeff Bergosh**: Whew......!  My office is not cleaned out LOL. 😂😗

**Sally Bergosh**: Hallelujah!!

**Jeff Bergosh**: Tori and I made dinner for you it’s in the microwave 👍❤️

**Jeff Bergosh**: Goodnight

**Sally Bergosh**: Just leaving Impact 100 event-:)

**Jeff Bergosh**: Drive safe love you

### CONVERSATION ON 02-11-2020

**Jeff Bergosh**: Come home soon, love u!

**Sally Bergosh**: I miss you!! You told me to take this job.....grrrrr!

**Jeff Bergosh**: Love u

**Jeff Bergosh**: Goodnight

**Sally Bergosh**: We start Narcan distribution tomorrow & I have BSF in the AM, so........

**Sally Bergosh**: These were from Becky today! Her last day is Thursday....

**Sally Bergosh**: Bad fall?😘❤️❤️

**Sally Bergosh**: Oh no!!😱We are sending you lots of love & hugs!!🥰

**Sally Bergosh**: Free stay now?!! 

### CONVERSATION ON 02-12-2020

**Sally Bergosh**: Maybe this is Gods way of keeping you in recovery rest & relaxation mode!!❤️

**Sally Bergosh**: Get it, mom? "TRIP"-😂

### CONVERSATION ON 02-13-2020

**Jeff Bergosh**: In a meeting will call u back

**Jeff Bergosh**: You’re hired as my social scheduler 😁❤️

**Sally Bergosh**: I already had the job❤️❤️

**Jeff Bergosh**: Yes u did

**Jeff Bergosh**: 😂👌

**Sally Bergosh**: ❤️❤️

**Sally Bergosh**: Perfect!! I’ve been phone tagging with Jeff all morning! Have you all been to Angelines  Italian downtown yet?

**Sally Bergosh**: I’m good with whatever- we love Angelines, The District, VPauls, Iron, Global Grill-I’ll go with whatever you guys want. I was trying to think of one of our newer restaurants for Mary & Sally to try! 

**Sally Bergosh**: Loved an image

**Jeff Bergosh**: Okay—we love bonefish

**Sally Bergosh**: Okay- just called & made us reservations for “6” under Bergosh at 5:30- if u get there at 6 pm, no biggie

**Jeff Bergosh**: Bonefish at 6:00 😎👍

**Sally Bergosh**: I was told to make it at VPaul’s 

**Sally Bergosh**: We have a reservation at 5:30 pm at VPauls for “6”

**Jeff Bergosh**: Okay—VPaul’s  for 6

**Jeff Bergosh**: Sold!!

**Sally Bergosh**: See you all then!👍

**Jeff Bergosh**: LOL no worries

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: So much FUN tonight!! Happy Birthday, Aunt Mary!! Love you!!❤️❤️

### CONVERSATION ON 02-14-2020

**Sally Bergosh**: Please call me! 

### CONVERSATION ON 02-16-2020

**Sally Bergosh**: Yes

**Sally Bergosh**: We got through 4 episodes & got the gist of it- the guy was kind of an over- the- top activist about everything. We are now watching Narcos, Mexico Season 2......

### CONVERSATION ON 02-17-2020

**Sally Bergosh**: Don’t forget THZiS Friday is Trouba

**Jeff Bergosh**: Okay got it

**Sally Bergosh**: Troubadour

**Sally Bergosh**: Can u attend Founders Day THIS Friday at 11:30-12:30?

**Sally Bergosh**: The Wright Place?

**Jeff Bergosh**: Yes

### CONVERSATION ON 02-18-2020

**Jeff Bergosh**: In mtg will call back

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: That’s awesome!

**Sally Bergosh**: We should at least go by!!:)

**Sally Bergosh**: In fact, I think I want to play!:)

**Jeff Bergosh**: Look what I just picked up😁😁😁😁😁

**Sally Bergosh**: Yay!!

**Jeff Bergosh**: 127 this week—more than last week’s 83

**Jeff Bergosh**: I’m opening them right now 😁😁😁😁😁😁😁😁😁😁😁😁😁

**Sally Bergosh**: Very exciting!! Did u help me with country at the clinic sponsorship form

**Jeff Bergosh**: Sorry not yet but I will

**Jeff Bergosh**: They decorated the back of this envelope LOL

**Sally Bergosh**: Were they fans?

**Jeff Bergosh**: Yes

### CONVERSATION ON 02-21-2020

**Jeff Bergosh**: So I’m heading to the Wright place downtown at 11:30 for the founders day luncheon—is that right?

**Sally Bergosh**: Yes- just finished 3rd set

**Jeff Bergosh**: 70 more today

**Sally Bergosh**: You are like a kid in a candy store! I’m at home drinking coffee & thinking about getting ready for our amazing monster dinner!!

### CONVERSATION ON 02-23-2020

**Sally Bergosh**: I need your help editing Country at the Clinic Sponsorship Forms. Are u on target to be home soon? Love you & Harry brought u a campaign donation!!❤️❤️

### CONVERSATION ON 02-24-2020

**Jeff Bergosh**: I’m here at the library saving you a seat 😎😎

**Sally Bergosh**: See u at home! Love u!

**Jeff Bergosh**: Love u

### CONVERSATION ON 02-25-2020

**Sally Bergosh**: Did we order more keirigs?

**Jeff Bergosh**: ???

**Jeff Bergosh**: From who?  

**Sally Bergosh**: I mean did u buy any this week?

**Jeff Bergosh**: Yes

**Sally Bergosh**: I think u need to check under your car seat

**Jeff Bergosh**: Are we out????

**Sally Bergosh**: Almost & it’s only Tuesday

**Jeff Bergosh**: Our kids have taken a liking to them it seems

**Sally Bergosh**: Or they are under your seat- I don’t remember unpacking them

### CONVERSATION ON 02-26-2020

**Sally Bergosh**: I’m in my 4th rotation of the stop light down the hill from our house.....this is crazy!!

**Sally Bergosh**: The alarm is going off in my car- please come quick!!!!!

**Sally Bergosh**: I'm playing in a tennis tourney- what time will u be there?

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: Heading back to the room for break

**Jeff Bergosh**: R u at the room?

**Sally Bergosh**: Yes- I’ve been working all morning- it’s like I’m not even away!! Grrrrr

### CONVERSATION ON 02-28-2020

**Jeff Bergosh**: No worries, I got u the late checkout for 12:15. 😎👍

**Jeff Bergosh**: And I’ll bring you coffee at first break, 9:45❤️

**Sally Bergosh**: Yay!! Love you, PC!!

**Jeff Bergosh**: Love u most!

**Jeff Bergosh**: Okay on way up

**Sally Bergosh**: K- take a good picture I can use for a Health & Hope Clinic post on social media!

**Jeff Bergosh**: I’m just too tired I can’t make it tonight I love you!  Good luck in the tournament Drive carefully and I’ll see you when you get home love you❤️❤️❤️

**Sally Bergosh**: Come on Boxer!!

### CONVERSATION ON 02-29-2020

**Sally Bergosh**: 6:30 or 7?

### CONVERSATION ON 03-02-2020

**Jeff Bergosh**: I’m going to stop and grab a card for Ben from our family on the way home and drop it off at Gar’s house.  I’ll throw $40 in there.   

Love u!
Me

**Sally Bergosh**: Thank you!! Love you!!

**Jeff Bergosh**: Love u most! 

**Jeff Bergosh**: Ben’s Card

**Sally Bergosh**: Of course, monkeys!!

**Jeff Bergosh**: LOL

**Sally Bergosh**: Classic!! We get to see Nicky next week for Spring Break- woohoo!!

### CONVERSATION ON 03-03-2020

**Sally Bergosh**: Remember- I’m looking for sponsors for Country at the Clinic- & we use many of PCC students at our clinic......I would have loved to meet those peeps behind their walls & ask for sponsorship!! Keep me in mind next time u have another meeting like that

**Jeff Bergosh**: Somebody really liked your card Aunt Sally!

**Sally Bergosh**: ❤️❤️

**Sally Bergosh**: I just got this text from Tori Woods 

Do you know how to get ahold of Steve Berry? MCARTHUR needs a sponsorship for our carnival 

**Jeff Bergosh**: I don’t have his cell #

**Sally Bergosh**: I have her his secretary’s contact #

**Sally Bergosh**: Dawn is her name, correct?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Hello

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Mcguiver in the house!

**Sally Bergosh**: Yay!! You are the bomb!! Love you!!❤️

### CONVERSATION ON 03-05-2020

**Jeff Bergosh**: Does the hook work??

**Jeff Bergosh**: 😎👍❤️

### CONVERSATION ON 03-06-2020

**Sally Bergosh**: 10 minutes to leave Bell Ridge gate- it’s back to back and worst then ever- u can not survive this that much longer!!! 

**Jeff Bergosh**: I know it’s victim of circumstance

**Jeff Bergosh**: Wish I was in control of it because it would be done by now

**Sally Bergosh**: I would be raising hell at this point!! The people that live in subdivisions on 9 Mile are trapped & cant get out!! When are they going to 4 lane our side going towards interstate?!!?

**Jeff Bergosh**: Summer it will be complete

**Jeff Bergosh**: This year

**Sally Bergosh**: Now all lanes are stuck at light staring at each other- lights are not in sinc- even though no one is actually leaving NFCU at 8 am

**Jeff Bergosh**: I’m calling my contact at the state

**Sally Bergosh**: Good idea- it’s a train wreck & people are now driving pissed!!

**Sally Bergosh**: At da car wash on Brent!! It was time!

**Sally Bergosh**: More importantly- what r u doing in Destin?!

**Jeff Bergosh**: Don’t text and drive its dangerous

**Sally Bergosh**: That must be one hell of a beach!! 

### CONVERSATION ON 03-07-2020

**Sally Bergosh**: Remember to reserve IPC for (4)

**Sally Bergosh**: At 7 pm

### CONVERSATION ON 03-08-2020

**Sally Bergosh**: David is out front washing your black truck.....so, so sweet!❤️❤️

**Jeff Bergosh**: That’s so nice of him!

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you MOST!! Don’t u have any friends on Beulah Road that will let u put a sign up? 

**Sally Bergosh**: What’s the hotel called & who are u with?

**Sally Bergosh**: The hotel is called the Journeyman or is that the name of the bar?

### CONVERSATION ON 03-09-2020

**Sally Bergosh**: As soon as u know where you are interning over the summer, the sooner we will be able to make plans to come visit! I’m thinking August, maybe!

### CONVERSATION ON 03-10-2020

**Jeff Bergosh**: Sally—I’m doing a $2,500 sponsorship from my county discretionary funds for this organization. :)

**Sally Bergosh**: K!:) r we going to the event this year with Deb & Mike & the Roche’s?!!?

**Jeff Bergosh**: Sure!

**Jeff Bergosh**: I’ll pay for our tickets separately

**Sally Bergosh**: Just yours & only the difference

**Jeff Bergosh**: 👍

**Sally Bergosh**: Have u heard of Oasis Prep school?

**Jeff Bergosh**: Nope

**Jeff Bergosh**: But that doesn’t mean anything it could be some kind of a private school or something that I’m just not familiar with

**Sally Bergosh**: Enjoy New Orleans & we will see you on Thursday?

**Jeff Bergosh**: ......uh, wait till u see it LOL

**Sally Bergosh**: Nicky- everything ok?! Travel safe!!

**Jeff Bergosh**: I’m coming home with Carne Asada burrito fixings!

**Sally Bergosh**: On my way home from clinic!:)

### CONVERSATION ON 03-11-2020

**Sally Bergosh**: From Madrina Ciano:

Just had a meeting with Lumon May and another individual in regards to solutions for EMS and Lumon is going to connect Jef and this gentleman and I wanted to do some due diligence and get his number in advance

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Hey everyone I’m making teriyaki chicken for dinner tonight, so don’t stop for food, save your money!

**Sally Bergosh**: Loved “Hey everyone I’m making teriyaki chicken for dinner tonight, so don’t stop for food, save your money!”

### CONVERSATION ON 03-12-2020

**Jeff Bergosh**: ??

**Sally Bergosh**: 7?

**Jeff Bergosh**: Okay

**Sally Bergosh**: Yay, PC!! You did good!! We love you, Debbie. Call me when u r ready to chat or need some soup or something! We love you!:)

### CONVERSATION ON 03-13-2020

**Sally Bergosh**: Please move my $$ over & I’ll deposit after lunch with Nicky & his girlfriend

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Done

**Sally Bergosh**: Got it/ thanks!!

**Jeff Bergosh**: Where r u?  Nick is leaving soon

**Sally Bergosh**: Nicky knows I’m with my student- we had lunch today together

### CONVERSATION ON 03-14-2020

**Jeff Bergosh**: They brought 1 pallet of water right when I got to the water aisle,  I grabbed 3 cases

**Sally Bergosh**: Oh my!! What about dollar store? They might have that Lysol!?

**Sally Bergosh**: Do they have sparkling water? Tori has her own worries!!

### CONVERSATION ON 03-16-2020

**Jeff Bergosh**: They will be announcing a nationwide halt on gatherings of 50 or more for the next eight weeks......just be prepared for that announcement to come out.  the county and the city are also going to make similar joint announcements later this morning.  You need to plan appropriately as it pertains to Country at the clinic

**Sally Bergosh**: Got it!

### CONVERSATION ON 03-17-2020

**Jeff Bergosh**: The governor just announced that all bars and nightclubs will be closed for the next 30 days

**Sally Bergosh**: Got it

### CONVERSATION ON 03-19-2020

**Sally Bergosh**: 1809 Amos Circle, Michele Kobielnik her house & she wants a sign- she asked me over a week ago at Impact 100 event & she just reminded me again!!

**Jeff Bergosh**: Will do.  And do you have jroane bergmans address?  She wants one too

**Sally Bergosh**: 1816 West Jackson Street, 32501

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Hey I just sent you an email you should read.  Important!

**Sally Bergosh**: K

**Sally Bergosh**: Can u change a pdf into word so I can make changes? I sent to your gmail

**Jeff Bergosh**: Okay

**Sally Bergosh**: Thank u- kind of an emergency as this chick is going to her accountant today and needs the right amount

**Jeff Bergosh**: Just sent it back to u in word

**Sally Bergosh**: Yay- u r a lifesaver!!

**Jeff Bergosh**: Love u

**Sally Bergosh**: U du bomb!!

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: In BCC meeting 

**Sally Bergosh**: Gotcha

**Jeff Bergosh**: Crazy stuff going on

**Jeff Bergosh**: Only food take out permitted from now on

**Sally Bergosh**: What about beaches?

**Jeff Bergosh**: We are taking that up next

**Jeff Bergosh**: Crazy crazy stuff

**Sally Bergosh**: Well our clinic just made the decision to stay open as long as we can & help those new patients that need affordable/ free meds!! They want me to reach out to media & let them know we are keeping our ER’s from getting flooded

**Jeff Bergosh**: That’s outstanding

**Sally Bergosh**: We don’t want u blind-Sided when u walk in the door tonight. Kids bathroom flusher part broke. I came home to that & got the toilet to flush but thought maybe u could get the part on your way home tonight?

### CONVERSATION ON 03-21-2020

**Sally Bergosh**: Garage light is on

**Jeff Bergosh**: Got it

**Jeff Bergosh**: I got Alex his birthday card and money taken care of. Love you

**Sally Bergosh**: Live you MOST!! R u getting your hiking adventure in? 

**Sally Bergosh**: *love

### CONVERSATION ON 03-23-2020

**Jeff Bergosh**: Went through our accounts today;  sent Nick an extra $100 and also sent Hillcrest $100.  Love u!

**Sally Bergosh**: Love you right back!!

**Sally Bergosh**: Take-out & delivery is still on the table, PC!!❤️❤️

**Jeff Bergosh**: Wow!!

### CONVERSATION ON 03-24-2020

**Sally Bergosh**: 😥

**Sally Bergosh**: 💔

### CONVERSATION ON 03-25-2020

**Sally Bergosh**: Love you, PC and think you did an amazing job this morning!! You were a class act & even took the “planted” questions by fictitious Kaya Jones on Dr. Edler’s behalf......and Nick Grady!

**Sally Bergosh**: Evil can’t mask their evil & you rise above it & acted like a gentlemen! Be sure to thank Janice & doc profusely!!

**Jeff Bergosh**: Thank you!!  Love u!!! 

**Sally Bergosh**: Call me please

**Jeff Bergosh**: On conference call

**Jeff Bergosh**: Will call u after

**Sally Bergosh**: K

**Sally Bergosh**: Oh- I thought u were doing an all nighter. Good- I’m glad u will get to come home & sleep before work tomorrow- love you, Tori!!❤️

### CONVERSATION ON 03-26-2020

**Sally Bergosh**: Can u help me with the West Florida Hospital receipt for Kendrick?

**Jeff Bergosh**: Yes I’ll do it this morning.  I’ll get it to you ASAP

**Jeff Bergosh**: I just emailed the invoice to you ❤️

**Sally Bergosh**: Thank you!!

**Jeff Bergosh**: No problem—love u!!

### CONVERSATION ON 03-27-2020

**Jeff Bergosh**: Just picked up 1,000 from 2 new supporters!

**Sally Bergosh**: Yay!! Go get’m PC!! Love you!!❤️🥰

**Jeff Bergosh**: Love u most!!

**Sally Bergosh**: Love these photos!! Donna just me one too!

**Sally Bergosh**: I’m hanging in there- I just finished new web site- check it out & give me your feedback! Healthandhopeclinic.org Hoping to work so hard that I don’t mind not being able to do any social stuff for a while!! How are u coping with virtual school? Love you guys!!❤️❤️

**Sally Bergosh**: Oh my goodness! We are full steam ahead converting our 49 plus schools into converting to on-line classrooms almost overnight. Our poor teachers are having to just jump in and do it with basically 2 weeks to prep. Should be interesting!

**Sally Bergosh**: And college grads, too! Such a crazy time!! I’m trying to hold our free clinic for people without insurance together. I’m getting creative and doing drive-thru check ins, telemedicine, and begging & pleading via grants, etc for more supplies!! All the other public clinics have shut down services...... Brandon & Tori’s PENSACOLA State College classes will be starting again Monday- all online, too! Poor Nicky is stuck in Wisconsin because even though his w law school went virtual for rest of semester, his Navy reserves unit won’t let him leave!!

### CONVERSATION ON 03-28-2020

**Sally Bergosh**: I need tampons!! I can’t believe it- 

**Jeff Bergosh**: I’ll go back and get them on a second trip

### CONVERSATION ON 03-30-2020

**Sally Bergosh**: 6202 N 9th Ave - Dr. Jones Dermatology office said she would meet u there to get file shelf’s we desperately need at clinic

**Jeff Bergosh**: I can do it at lunch break at 11:00

**Sally Bergosh**: Perfect! They said to bring a wre

**Sally Bergosh**: nch in case u want to take in 2 parts. 


**Sally Bergosh**: Brung a wrench

**Sally Bergosh**: U leaving the base? 

**Jeff Bergosh**: On way now 

**Sally Bergosh**: Me too!:)

**Sally Bergosh**: If u r coming from Airport & 9th it’s the driveway after Express Oil Change on right hand side. George’s Bistro is across the street

**Sally Bergosh**: Thank you, Brandon for contributing in a POSITIVE way to our family! Love you!!❤️❤️🥰

**Sally Bergosh**: Awww!!

### CONVERSATION ON 03-31-2020

**Sally Bergosh**: Yay!! Good job, PC!! Text me when u are on your way!:)

**Jeff Bergosh**: I’m leaving the base right now to head that direction are they already for us to move those cabinets?

**Sally Bergosh**: Yes!!

### CONVERSATION ON 04-01-2020

**Sally Bergosh**: Great job, Host Bergosh!! It felt like u kept cutting Janice off so make sure u apologize to her & tell her how much u appreciate her waking up early with u each Wednesday- she has a “servitude” heart & that needs to be acknowledged!

Love you! Great job!

**Jeff Bergosh**: Thank you Sally!! And I will.  

Love u!!

**Sally Bergosh**: Loved this!!

### CONVERSATION ON 04-02-2020

**Sally Bergosh**: Don’t forget about Donny Godwin

**Jeff Bergosh**: Okay

**Sally Bergosh**: Having a good bday so far?!!?

**Jeff Bergosh**: Busy and hectic

**Jeff Bergosh**: 😬

**Sally Bergosh**: 🙃

**Sally Bergosh**: So......Doug Underhill is at it again on social media- he asked a guy on Facebook “what kind of crack are u smoking”?!!? I’m taking screen shots 

**Jeff Bergosh**: He’s a tool!

### CONVERSATION ON 04-04-2020

**Jeff Bergosh**: Easter covered!   Love u❤️

**Sally Bergosh**: Yay!! Maybe an Uber gift card for Nicky?

**Sally Bergosh**: I will mail him his loot this week!:)

**Sally Bergosh**: BOOM!

We got word this morning that are Pure Spray kills Covid19

https://finance.yahoo.com/news/pure-bioscience-pure-hard-surface-130400434.html

This product is a no brainer!

 If you guys know anyone that I could contact that may be able to get this out in the masses, please let me know. Everyone needs to have this disinfectant spray and we have it in stock.

### CONVERSATION ON 04-05-2020

**Jeff Bergosh**: We’re halfway through the walk rn

**Sally Bergosh**: Loved “Kelsey is doing schoolwork outside by where your truck is parked. You guys should swing by and say hi on the way back”

### CONVERSATION ON 04-08-2020

**Jeff Bergosh**: Got Hillcrest our offering 🙂

**Sally Bergosh**: Thank you for taking care of us always! You did great today! Not as many questions but it was reassuring to me & very needed! Rick’s blog was on this am & Kevin & Faxlanger

**Jeff Bergosh**: Thanks—did you see I asked your question LOL

**Sally Bergosh**: No- I left to pee & came back but could tell u had asked it- what did they say?

**Jeff Bergosh**: They’re testing them and they are in the same “waiting line” as everyone else

**Sally Bergosh**: I joined and am waiting for our “host” to accept us into the meeting!!😂

### CONVERSATION ON 04-09-2020

**Sally Bergosh**: Loved!!❤️

**Sally Bergosh**: I saw it on Facebook- so thoughtful!!❤️❤️

**Sally Bergosh**: Where are the amigos hiding for this picture?!! Lol😂

**Sally Bergosh**: Loved an image

### CONVERSATION ON 04-10-2020

**Sally Bergosh**: I’m bringing home Tuscan Oven for din-din!:) Love you!

**Jeff Bergosh**: Awesome thank you!  Can you grab me the Abba Danza calzone

**Jeff Bergosh**: Please?😎❤️

**Sally Bergosh**: Man Cave Snack Basket from the Easter Bunny!! ❤️❤️

**Jeff Bergosh**: Nice!!

**Sally Bergosh**: Hmmm- that does NOT look like the picture. Ugh! They had it advertised as an Easter Basket!:( Sorry, Nicky. I wanted you to know Easter Bunny loves you!

### CONVERSATION ON 04-11-2020

**Sally Bergosh**: Click here to see our updated homepage with our modified schedule and an updated video message from Pastor Jim.

**Sally Bergosh**: https://hillcrestchurch.com/covid-19-update/

**Jeff Bergosh**: https://babylonbee.com/news/liberal-treated-with-hydroxychloroquine-hopes-he-still-dies-of-covid-19-to-prove-trump-is-stupid

### CONVERSATION ON 04-13-2020

**Jeff Bergosh**: Tori is getting $1,200 Stimulus payment into Wednesday.

**Sally Bergosh**: Is that her Covid-9 $ or tax refund?

**Jeff Bergosh**: COVID-9

### CONVERSATION ON 04-14-2020

**Jeff Bergosh**: Hillcrest offering made today!

**Sally Bergosh**: Thank you for taking care of this!!

**Jeff Bergosh**: No problem ❤️👍

**Jeff Bergosh**: Going to bed—got a big morning tomorrow.  Drive safe!  Love u!!

### CONVERSATION ON 04-15-2020

**Sally Bergosh**: Who the “F” is this Jeff Love?!!? Just cuz they ask a few hundred crazy ass ?’s doesn’t mean you ask it......defeiend this guy immediately

**Sally Bergosh**: You handled with grace & dignity!! Great job- love you!

**Jeff Bergosh**: What do you think?  1st draft of big billboard

**Sally Bergosh**: I love it! 

**Jeff Bergosh**: I’m only worried about mixing the message

**Jeff Bergosh**: I just put the website instead

**Sally Bergosh**: Eyes read left to right, put your web address first! Baptist is starting all their weekly correspondences with “We are in this TOGETHER”
Also needs more blue to get the theme of election ad vs. COVID billboard- more red, white & BLUE like your palm cards

**Jeff Bergosh**: Burgers with toasted buns and grilled sautéed onions is on the menu tonight complete with tater tot’s. 😎👍👍❤️

**Sally Bergosh**: ❤️❤️

**Sally Bergosh**: This is Tori Woods’ (Junior League President & ECCPTA President) peeps that live by the fairgrounds & are currently on septic.(they are in your district)
850-944-1737 Geneva Copeland is her grandmother and Anita Donson is her aunt. Thank you for calling them

### CONVERSATION ON 04-17-2020

**Sally Bergosh**: Text me the two billboard options when u get them

**Jeff Bergosh**: Will do!  Love u!

**Sally Bergosh**: Love you right back!

**Sally Bergosh**: Everyone hands down said last one!!

**Jeff Bergosh**: 
Experience now more than ever

**Jeff Bergosh**: That one?

**Sally Bergosh**: Jeanette likes the 1st one & Yuri & I like the last

**Sally Bergosh**: Please buy a newspaper on the way home!:)

**Jeff Bergosh**: Okay will do although it’s going to be in tomorrow’s edition not today’s

**Jeff Bergosh**: ❤️❤️❤️👍😎😎

**Sally Bergosh**: Hope you have reached out to Tori Wood’s grandma.....septic

**Sally Bergosh**: I gave them a description of your car for p/ up & I already paid. When u arrive call  & they will bring it out to your car!:)

**Jeff Bergosh**: Awesome!  On way there

**Jeff Bergosh**: Is it under the name Sally???

**Sally Bergosh**: Your name - call when u arrive

### CONVERSATION ON 04-18-2020

**Jeff Bergosh**: Final

**Sally Bergosh**: Crazy, isn’t it?!!?

**Sally Bergosh**: Everyone is chatting about dad’s inappropriate  post about black people?!

**Sally Bergosh**: Nicky sent it to us.....please delete immediately!!

**Sally Bergosh**: Additionally it is the picture that accompanies this comment that is BAD

**Sally Bergosh**: Call me if u need my help deleting this- it’s got to be deleted by dad’s login since he was the poster

### CONVERSATION ON 04-21-2020

**Jeff Bergosh**: Sally—dinner is in the microwave—I have to go to bed to be ready for my coffee meeting.  Love you—come home soon!!❤️❤️❤️

### CONVERSATION ON 04-22-2020

**Sally Bergosh**: Ask more of peep’s questions & less about YOU (school board “I” Singapore)- too much resume- peeps tune in to hear the news stuff & will respect u for asking the right questions!!

**Sally Bergosh**: Shhhhh

**Sally Bergosh**: Strong finish, PC!!❤️❤️

**Jeff Bergosh**: Love u—thanks for tuning in!!

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: This was sent to me today by a constituent.....Is this the “better representation” D2 office wants to bring to D1?

### CONVERSATION ON 04-25-2020

**Sally Bergosh**: This is from Michelle: The entire state is shutdown.  And I get a Robo call from the school district telling me I can ‘safely’ get my child’s picture taken on Wednesday by going to a photography studio in Pace 😳 
I messaged someone at the district in complete disbelief and they tell me the entire school district is doing it 😳
You can’t even get a tooth fixed or go to your doctor, or go have a meal- but you can go get a spring photo! (Yearbook orders were weeks ago- so it’s not for that!)
The 1st is Friday- so it’s even before the May 1st date.. 
.I’m just in utter disbelief

### CONVERSATION ON 04-27-2020

**Jeff Bergosh**: Sally—. I got Brandon‘s birthday gift ordered it will be delivered Thursday or Friday to the house. It is a brand new black iPhone 11. I sent you the confirmation email. Love you❤️❤️

**Sally Bergosh**: That’s fantastic news!! Also our PPP just got submitted to SBA

**Jeff Bergosh**: Right on great news!👍👍

**Sally Bergosh**: Nice!! Oh boy, let the haters begin their feeding fest!

**Jeff Bergosh**: 😂😂😎😎👍👍

**Sally Bergosh**: This is from my friend,Chuntell Patterson-her contact # 
Hi there! I hope all is well. Sooo I just read a blog by Jeff about a beta test for the drive thru movie theater. I currently reside in district 1 and live a few mins from the fair grounds... if able , I would love to participate in the testing this week if spots are available. It just happens my schedule is open lol 

**Sally Bergosh**: Well dang it to heck!!😂

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Did you get the package from the porch this morning?

**Jeff Bergosh**: ????

**Sally Bergosh**: Got it & put on dining table!

**Jeff Bergosh**: 👍

**Sally Bergosh**: Do we have gas heat pump? Where do u pour the bleach in air condition unit?

**Jeff Bergosh**: No ours is electric

### CONVERSATION ON 04-29-2020

**Sally Bergosh**: Inappropriate to tell Governor to open the state- too soon & should be done in stages

**Jeff Bergosh**: It’s time to start

**Sally Bergosh**: Great job today- looking forward to watching later with Matt G! Great ?’s about PPP! Eugene Love tried to create more havoc! 

**Sally Bergosh**: Yes, indeed!!😱

### CONVERSATION ON 04-30-2020

**Sally Bergosh**: Just got a call from Josh, bank manager at our Regions location & then got this text from Scotty Barrow a few minutes later!

Great news! Your SBA loan for the Health and Hope Clinic received approval this morning with a loan number. Please monitor your email for loan documents. Congratulations!

**Jeff Bergosh**: Way to go!!!!!!!  Awesome!!!!

**Sally Bergosh**: Yes!! You were so RIGHT about reaching out to Scotty Barrow!!

**Sally Bergosh**: https://www.forbes.com/sites/robertpearl/2020/04/21/3-coronavirus-facts/?subId3=xid%3Afr1588159175502dge#1c49d5f84721

**Sally Bergosh**: Read this article

**Jeff Bergosh**: Dinner is ready, spaghetti ❤️😎👍

### CONVERSATION ON 05-01-2020

**Sally Bergosh**: Who is CEO of WFHospital?

**Sally Bergosh**: I’m addressing my Thank You for their payment for CATC

**Sally Bergosh**: Christmas at the Clinic

**Sally Bergosh**: Chuntell said she enjoyed her drive- in movie night experience last night & said “Thank you”!

**Jeff Bergosh**: Gay Nord

**Jeff Bergosh**: Awesome— glad to hear it turned out well!

**Sally Bergosh**: If I’m sending something to Gay Nord, do I send directly to the hospital

**Jeff Bergosh**: That’s where I sent mine

### CONVERSATION ON 05-02-2020

**Sally Bergosh**: Tori & I are on a birthday bike ride at the beach for a couple of hours- we should be home by 3:00

**Jeff Bergosh**: Okay.  Where do you get the bikes?

**Sally Bergosh**: We rented $10 each for 2 hours!! Do u want to go next Saturday with me? Perfect weather!

### CONVERSATION ON 05-04-2020

**Sally Bergosh**: https://apple.news/APeBb0ZinTVGFau3o2PsgSQ

**Jeff Bergosh**: Interesting

**Sally Bergosh**: There’s no sound on your prayer video! Plus you’re scowling- smile!! You’re getting a pro ledge very few get asked to do- I can’t think of a bigger honor!! I’m blown away by their request

**Sally Bergosh**: I know this church well from their partnership at Ensley Elementary- they helped supply hundreds of mentors at that school!! Love their pastor- very supportive of community

**Jeff Bergosh**: There’s sound when I play it

### CONVERSATION ON 05-05-2020

**Sally Bergosh**: Omg!! U never kissed me goodbye!??!

**Jeff Bergosh**: Yes I did!!

**Jeff Bergosh**: You don’t remember??????

**Sally Bergosh**: No

**Jeff Bergosh**: Yes!!

**Jeff Bergosh**: I just donated and I invited all my Facebook friends to donate as well.  I also shared a post on my Facebook timeline.  Good luck in smashing this $1,000 goal!!!!  Love u!!!!!

**Sally Bergosh**: Love you right back! I feel like I might be wearing my peeps down so close to me recent bday ask! Oh well- the worst case scenario is they don’t give, right?!!?

**Sally Bergosh**: Thank YOU for your support, PC

**Jeff Bergosh**: They will give!!

**Jeff Bergosh**: Love you most

**Sally Bergosh**: Did we inquire about refinancing our house yet?

**Jeff Bergosh**: Come to find out where about as low as we can get we are sitting right now at 3.625

**Jeff Bergosh**: .....Impossible to get it much lower on a 30 year refinance

**Sally Bergosh**: Ok- never mind!!

**Jeff Bergosh**: 👍

**Sally Bergosh**: In honor of Cinco De Mayo, Taco Tuesday And Corona Virus reprieve......I’m bringing home Taco’s for the family & a gallon of margaritas! My pick up time is 6:30 pm so dinner will be served at 7!

### CONVERSATION ON 05-06-2020

**Sally Bergosh**: DUI?

**Jeff Bergosh**: Sally I’m falling asleep .  Love u 

**Sally Bergosh**: I’ve tried to leave twice but the cleaning crew showed up & so we addressed a few things.

**Jeff Bergosh**: Ok I love u

**Sally Bergosh**: Will do!! That is so thoughtful!!❤️

### CONVERSATION ON 05-07-2020

**Sally Bergosh**: Good morning Sally Sue. Jim would like Jeff’s contact information as he has a question about the Governor’s Order. He says he won’t keep him long - just has a question & looking for an educated opinion.  Or could you give him Jim’s number.  712-9224

Thanks mam. Tonya Sue

**Jeff Bergosh**: I called him he didn’t answer I left him a message

**Sally Bergosh**: Fabulous!!:)

### CONVERSATION ON 05-08-2020

**Sally Bergosh**: Mailbox is full & I need to talk to you

**Sally Bergosh**: Please call me

**Jeff Bergosh**: Just called u back.  I was driving on base but my phone didn’t rings 

**Jeff Bergosh**: In mtg will call u right back

**Sally Bergosh**: I just ordered you lasagna/ salad & we p/ up at 6:30 pm

**Sally Bergosh**: I’m heading home in 10 minutes

**Jeff Bergosh**: On my way

**Sally Bergosh**: Go where? Home? Ok me too

**Jeff Bergosh**: Home

**Jeff Bergosh**: Long day

**Sally Bergosh**: I’m just picking up the food

### CONVERSATION ON 05-09-2020

**Sally Bergosh**: Honey bunches of oats, Special K with almonds, coffee creamer, Sparkling H20, Skinny Cows, Licorice, CheezeIts, sour patch for B, Fresh cherries, 4 packs of chocolates for Nurse Appreciation Week, Greek Yogurt, Lime-Aid by Simply Fresh

**Sally Bergosh**: Simply Truly cans

**Jeff Bergosh**: Got it

**Sally Bergosh**: Yay!! 

**Sally Bergosh**: Thank you!!

### CONVERSATION ON 05-11-2020

**Jeff Bergosh**: I’ll call u right back

**Sally Bergosh**: Do we have a pop- up tent I can borrow for tomorrow?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: One good one, one bad

**Sally Bergosh**: We will take the good one- thanks!

### CONVERSATION ON 05-12-2020

**Sally Bergosh**: When can u help me put these signs up?


**Jeff Bergosh**: Yes

**Jeff Bergosh**: Sunday afternoon project

**Sally Bergosh**: Do u have a second?

**Sally Bergosh**: Call me!! 

**Sally Bergosh**: Yes!!

### CONVERSATION ON 05-13-2020

**Sally Bergosh**: B got $750 from PSC !! Woohoo!!

**Jeff Bergosh**: Nice!

**Sally Bergosh**: Love you!! 

**Jeff Bergosh**: Love u most!

**Sally Bergosh**: Shawn just called & his amigos will install signs on Tuesday morning. So can u help me with best location this weekend?

**Jeff Bergosh**: That’s fantastic!!  Yes!

**Sally Bergosh**: Omg!! I forgot the pop up tent again!!

**Jeff Bergosh**: Remind me and I’ll dig it out

### CONVERSATION ON 05-14-2020

**Sally Bergosh**: Too cute!!❤️❤️

### CONVERSATION ON 05-15-2020

**Jeff Bergosh**: $950

Savings Account Number

0877642-306

**Sally Bergosh**: https://www.eventbrite.com/e/craft-lab-tickets-105007470170

**Sally Bergosh**: Come home EARLY!! I took the day off to oversee this tree business!! Now we have tree guy, Mr. Greg, David Mobley & Steve all discussing our tree......ugh!! Just cut it down & be done with it!! Come home, Boxer!!

**Jeff Bergosh**: I’m buried

**Sally Bergosh**: Grrrrr

**Sally Bergosh**: Come home Boxer!!:)

**Jeff Bergosh**: On way!

### CONVERSATION ON 05-17-2020

**Sally Bergosh**: I’m in the car

### CONVERSATION ON 05-18-2020

**Jeff Bergosh**: 👍😎

**Sally Bergosh**: Sally, I’m trying to help my 10 yr old son win a contest...So Micah entered a bowling competition and made a video. He’s totally trying to win!! If you and Jeff and anyone you can get to vote would go vote for him, he’d SOOO appreciate it!  I think you can vote once for each device. You just have to click the link then find his video and then click to vote for it and enter the info-you don’t have to sign up for anything. Here’s the link ... it takes about 30 seconds. 


**Sally Bergosh**: https://www.bowling.com/shelterstrikes/

**Sally Bergosh**: I’m so glad you are here for your dad. All those tests & appointments would be scary to face alone. We will be praying that all goes well. Keep us posted & sorry we will miss you on this trip. No San Diego this summer. We do have all three kids home right now which has been such an amazing treat. Nicky drove down from law school & we are just trying to spend as much time with him as we can right now!! ❤️❤️

**Sally Bergosh**: June will be great! Nicky has some internships that I think will bring him back to law school before then but you never know! His girlfriend lives in P’Cola, so we do have that in our favor!!❤️

### CONVERSATION ON 05-19-2020

**Jeff Bergosh**: That’s probably a $600,000 unit that we cannot afford

**Sally Bergosh**: HOA includes water & cable for $740 p/ month- I think we could get a deal if we allow them to sell by owner! Just call & ask

**Jeff Bergosh**: Okay

### CONVERSATION ON 05-20-2020

**Sally Bergosh**: It sounds like u r being very rude & disrespectful to VC

**Sally Bergosh**: Remember she has a lot of fans so this zoom is supposed to be about collaboration!!

**Sally Bergosh**: U r doing all the talking

**Sally Bergosh**: U keep repeating the same talking points!! The county does have a say in this- blah blah blah-

**Sally Bergosh**: Collaboration- unification- one voice

**Sally Bergosh**: Stronger together

**Sally Bergosh**: U need to engage Kevin!!

**Sally Bergosh**: Include Kevin

**Sally Bergosh**: Great wrap up

**Jeff Bergosh**: Thank you!

**Jeff Bergosh**: Didn’t see this till just now—was filming with this camera

**Sally Bergosh**: Film with the other camera

**Sally Bergosh**: Loved this message this morning!!

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: Hey employee of the month!! R u coming home?  I have to wake up early and I’m fading.  Love u!!

**Sally Bergosh**: Love you right back! We had many fires this evening at the clinic & I am just finishing with the last one.

### CONVERSATION ON 05-23-2020

**Jeff Bergosh**: 😪

### CONVERSATION ON 05-26-2020

**Sally Bergosh**: They were put in your dad’s briefcase

**Sally Bergosh**: I’m not resells sorry- they were left on the dining table right by dad’s briefcase so when I was cleaning dishes & laundry last night I put them in dad’s briefcase assuming they were his. Sorry, not sorry.

### CONVERSATION ON 05-27-2020

**Jeff Bergosh**: Sally the launch got aborted due to weather.  They will try again in the next couple of days

**Sally Bergosh**: Yes!! 

### CONVERSATION ON 05-28-2020

**Sally Bergosh**: https://youtu.be/fHagSmOhP1g

### CONVERSATION ON 05-29-2020

**Sally Bergosh**: Will u keep me updated on the launch?

**Jeff Bergosh**: Will do.  It’s slated for tomorrow afternoon

**Sally Bergosh**: Oh yay!!

**Sally Bergosh**: I’m taking Bree to lunch tomorrow

**Jeff Bergosh**: Well , just be supportive ❤️🙂

**Sally Bergosh**: Call me please

### CONVERSATION ON 05-30-2020

**Jeff Bergosh**: SALLY you will be happy to know I am making reservations for the Hilton Garden Inn at Pensacola Beach tomorrow will stay tomorrow night and get up and go to work from there directly I’ve spoken to Julian McQueen and he says come on out he’ll get us in early we can come enjoy the pool all day tomorrow so I thought that would make you happy I’m taking care of that today love you

**Jeff Bergosh**: Meet Badger!!  ❤️❤️

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Love, love, LOVR

**Sally Bergosh**: ❤️❤️❤️❤️

**Sally Bergosh**: Yet another reason to come visit your sister!! We are home of the blue angels!! We get to see them all the time!❤️❤️👍

### CONVERSATION ON 06-01-2020

**Jeff Bergosh**: Here’s what I sent to Julian:



“Julian:  you succeeded in making our 26th anniversary truly a special day. The food and beverages in the restaurant and out at the pool were fantastic, the bungalow was amazing and of course the room had a breath taking view and was incredible.  We truly enjoyed the entire day and night and all the extra touches you provided that made it extra special.  You have a beautiful property out there——and a really great staff—we had a blast!!  Thank you from the bottom of my heart!”

**Sally Bergosh**: Love!!❤️❤️

### CONVERSATION ON 06-02-2020

**Sally Bergosh**: June 6, 6:30 IPC room with the Haigler’s - be sure u make a reservation.....although I heard an employee there tested positive- sure u want to go there?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Love u— going to bed I have coffee meeting tomorrow morning.  ❤️

**Sally Bergosh**: I’m at clinic & logging off my computer- be home shortly! Love you!!❤️❤️

**Jeff Bergosh**: 🙂

**Sally Bergosh**: Hallelujah & praise God!!❤️

**Sally Bergosh**: I loved this devotional today & thought I'd share with all of you!


### CONVERSATION ON 06-03-2020

**Sally Bergosh**: Great show this morning!! 

**Jeff Bergosh**: Thank you!!!  Love you!!

### CONVERSATION ON 06-04-2020

**Jeff Bergosh**: So I am a county commissioner I fix potholes I approve budgets and I am in charge of setting policy. The guy who called and left this message must think I’m in charge of the world. What do you say to a call like this?

**Sally Bergosh**: Poor baby!! “It’s the end of the World, as we know it”🎶😱

**Jeff Bergosh**: Crazy shut right??!!??

**Sally Bergosh**: Yes & so, so sad!!:(

**Jeff Bergosh**: Got home, exhausted.  Going to bed.  Love u!!!

**Sally Bergosh**: Me too- on my way!!❤️❤️

### CONVERSATION ON 06-05-2020

**Sally Bergosh**: Can you move my funds over- I left u my check this morning

**Jeff Bergosh**: Okay will do.   Love u!!!

**Jeff Bergosh**: ✅ done.   U have $1,000 in checking and $687.68 in savings

Love u!

**Sally Bergosh**: Love you!!❤️❤️

**Sally Bergosh**: We need something iced cold & light coolers

**Sally Bergosh**: Helllllllo?!!?

**Jeff Bergosh**: Yes

**Sally Bergosh**: Or a nice dinner downtown maybe?

### CONVERSATION ON 06-08-2020

**Sally Bergosh**: I really like this one!!

**Jeff Bergosh**: Good message!

**Sally Bergosh**: That’s great news👍

### CONVERSATION ON 06-09-2020

**Sally Bergosh**: From my richest friend I know: just got her text message:

Hi my friend… Tell Jeff… From a board member of pace… thank you

**Jeff Bergosh**: That was nice!

### CONVERSATION ON 06-11-2020

**Jeff Bergosh**: Sally— I’m fading fast, headed to bed so I can get up for bible study at 6:00.  Love you!!  Come home soon!

**Sally Bergosh**: I am! We gave away 50 boxes of food tonight to our patients!  Fresh fruit & veggies! Amazing night at our clinic!

### CONVERSATION ON 06-12-2020

**Sally Bergosh**: Love this one this morning!!


**Jeff Bergosh**: Sally—Janice followed up on the trash issue

**Sally Bergosh**: Thanks, PC!! Love you & am proud of you for getting up this am for Bible study!❤️🙏

**Jeff Bergosh**: Love u!

**Sally Bergosh**: R u at your downtown office? I want to come meet u & get a drink at Old Hickory Whiskey Bar!

### CONVERSATION ON 06-15-2020

**Sally Bergosh**: This Sunday is Fathers Day & the kids & I want to treat you to a nice dinner. What is your preference, the later the better or early because of your busy work day the next day?

**Sally Bergosh**: We have a choice between 4 pm- 10 pm

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: How about 6:00?

### CONVERSATION ON 06-16-2020

**Jeff Bergosh**: 👍

**Sally Bergosh**: Love these pictures- great memories forever!!  Keep the pictures coming! We’re going to come out to Wisconsin after your dad’s election, so.......

### CONVERSATION ON 06-17-2020

**Sally Bergosh**: Dear God- ask Chandra a question!!

**Sally Bergosh**: Did u run out of ?’s.....reading comment & asking for commentator’s bio?!!? Ask Chandra a question

**Jeff Bergosh**: She got the first 20 minute segment

**Jeff Bergosh**: This was a rant on my phone this morning....LOL.

**Sally Bergosh**: Oh myyyyyyyy- report him quickly!! 

**Jeff Bergosh**: I called him

**Sally Bergosh**: Thank you Jesus!!🙏❤️

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Can I call u back after or do I need to step out?

**Sally Bergosh**: B butt dialed you again!!

**Jeff Bergosh**: Okay.  Love u!

**Sally Bergosh**: Great one today!!

**Jeff Bergosh**: Here’s my first campaign postcard—going to the absentee voters.  What do you think?  Mike Kenney is pretty amazing!

**Sally Bergosh**: Love the first side with your face. I did notive your last bullet point under “secured millions of dollars- is the fire station & equipment. If you are going to get specific- why not bullet point the library, the light on Beulah Rd & Mobile Hwy, & the upgrades to Beulah park? The 2nd side of the mailer is crazy busy, but so are you, so I guess that works!! Lol

**Sally Bergosh**: Text me when u r heading home & I will try & leave clinic at the same time!

**Jeff Bergosh**: Okay will do.  Was at BCC meeting till noon so I’m still here at base playing catch up!

Love u!!

**Sally Bergosh**: Love you right back!!

**Jeff Bergosh**: Okay I’m leaving my office right now... what a day!  

**Sally Bergosh**: I agree & im taking off too!

**Sally Bergosh**: Dear Family,
In the spirit of Fathers Day we have reservations at The District for din-din!! Join us if you can!! We will be leaving the house at 5:50 pm if you’d like a ride!!❤️❤️

**Jeff Bergosh**: Awesome!!  Happy Father’s Day to me!!!

**Sally Bergosh**: Yes- Sunday because that’s Fathers Day!!

**Sally Bergosh**: Nope

### CONVERSATION ON 06-19-2020

**Jeff Bergosh**: Thank you!  Love u!

**Sally Bergosh**: Love u, too!! Please make IPC reservations 

**Jeff Bergosh**: Yes will do

**Sally Bergosh**: 6:30?

**Jeff Bergosh**: Sure

**Sally Bergosh**: Can u confirm the prisoner guards in Pensacola have not recvd a raise in 7 years?!!?

**Jeff Bergosh**: Not sure about that.  Our correctional officers in the county have had 3% raises every year for the last 8 years.  I can confirm that!😎👍

### CONVERSATION ON 06-21-2020

**Jeff Bergosh**: New billboard up at fairground!!!

**Sally Bergosh**: Nice!! Need to cut that tree a bit- give it a haircut!!

**Sally Bergosh**: We really enjoyed last night, too!! Happy Fathers Day!! Let's do it again soon!!❤️

### CONVERSATION ON 06-22-2020

**Sally Bergosh**: Covid-19
Sally, Shatzi called Carol this afternoon to say that she has a fever of 100.6, aches and pains, and feeling really ill. She will be tested tomorrow. She found out that the friend she dined with on Tuesday at the Stonebrook Club has tested positive for Covid. On Wednesday, Shatzi saw 5 patients. She was wearing a cloth mask.

**Sally Bergosh**: On my way home!!

**Sally Bergosh**: Perfect gift- cute picture!!❤️❤️

**Sally Bergosh**: So sweet!!:)

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Look at my slim & trim mom!! Love these pictures!!❤️

### CONVERSATION ON 06-23-2020

**Jeff Bergosh**: I love you- going to bed because I have to get up at 4:30 for my coffee livestream.  Come home soon❤️❤️

**Sally Bergosh**: Love you- it was a zoo tonight so I’m still closing up. Love you!!

### CONVERSATION ON 06-24-2020

**Sally Bergosh**: Great job!! Loved the optimistic message from your guest panel!❤️

**Jeff Bergosh**: Love you!!

### CONVERSATION ON 06-25-2020

**Sally Bergosh**: Oh my goodness- great news!!

**Jeff Bergosh**: Yep!!

**Jeff Bergosh**: I’m on a conference call I’ll call I right back

**Sally Bergosh**: K

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: All bars statewide just got shut down again by the state DBPR!

**Jeff Bergosh**: Wow!

**Sally Bergosh**: Totally!! :(

**Sally Bergosh**: B is moving all his stuff out today & said u never offered to help him you only offered your truck.....I told him hthstvwas not true

**Jeff Bergosh**: I’ll help him tomorrow

**Jeff Bergosh**: CRAZY day!!  CRAZY

**Sally Bergosh**: Totally- I’m packing my bags & going home, too

### CONVERSATION ON 06-27-2020

**Sally Bergosh**: Can u send me Grant’s social media rant?

**Sally Bergosh**: Loved “Hey all—I just wanted to report that Grant Bridges called me today and we spoke at length. He apologized profusely and I accepted his apology. He took responsibility for what he said and told me he felt remorseful. Furthermore, he took down the post and told me he felt really badly and that he had made a mistake. I just wanted you all to have that data point and know that he in fact realized what he did was wrong.”

**Sally Bergosh**: His TRUE character was revealed!! His spirit of entitlement & myopic point of view is childish. Cut him loose & move on. Does Alex know what he did?

### CONVERSATION ON 06-29-2020

**Sally Bergosh**: Tori was just able to print a document on our printer....

**Sally Bergosh**: Mask on? Mask off? Watch, then decide for yourself.

Huge shout out to Providence Sacred Heart and Holy Family/Providence Health Care, Eastern Washington for working with us on this story!

🎥: Aaron Calendine

Full disclaimer: this is a demonstration about droplets, not about how a virus (i.e. COVID-19) behaves or transmits. As Dr. Rich David said, "We used bacteria to show where the droplets go... The bacteria show where your secretions came from... These spots on the plates we're seeing, those are colonies of thousands of millions of bacteria that have just divided enough and multipled enough that we can actually visually see them on the plate."

tl;dr - Droplets transmit COVID-19. This is a demonstration on droplets.

**Sally Bergosh**: I just sent you the video in messenger on the science experiment relating to droplets 

**Sally Bergosh**: Heading home

**Jeff Bergosh**: Love u!

### CONVERSATION ON 06-30-2020

**Sally Bergosh**: Can u tell me my balance? 

**Sally Bergosh**: I’m sharing a tennis lesson with Jeanette 

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Checking now

**Sally Bergosh**: 🙏

**Jeff Bergosh**: $48.23

**Jeff Bergosh**: Do u want me to transfer some from savings?

**Sally Bergosh**: 💕yes!!

**Jeff Bergosh**: I transferred $100

**Sally Bergosh**: Fathers Day did me in!!

**Jeff Bergosh**: U have $148

**Sally Bergosh**: Thank you

**Jeff Bergosh**: I know. Thanks for that!!❤️❤️

**Jeff Bergosh**: I love you— heading to bed so I can be on my game for tomorrow’s coffee w/ commissioner.  Love u!!

**Sally Bergosh**: Love u!! 

### CONVERSATION ON 07-01-2020

**Sally Bergosh**: Thought it went well- a little scary that all those CEO’s of hospitals still have so much unknown.....?!? Yikes! So everyone’s just winging it, almost reactive vs. proactive!

**Jeff Bergosh**: Yes—I was surprised about their lack of information about recovery in particular

**Jeff Bergosh**: Whew big-time relief!!!!

**Sally Bergosh**: Yay!! Now let’s pray our Kelsey doesn’t have it!! She just got tested!

**Jeff Bergosh**: Fingers crossed!

**Sally Bergosh**: From Bob & Janet Olliff:

Hi Sally!  I know you get questions often because of Jeff’s position and I am about to do that right now.  I hope you don’t mind!  We have more friends from Mississippi who are thinking of coming to Pensacola Beach next week. When they called one of the hotels on the beach, they told him that the beach might be closing.  Do you know if there is any truth to this?  Thanks, Sally! 💕

**Jeff Bergosh**: I don’t think that will happen

### CONVERSATION ON 07-02-2020

**Sally Bergosh**: The Wahoos just cancelled their 4th of July event

**Jeff Bergosh**: Yep I heard about that.  It’s a shame

**Sally Bergosh**: Woohoo!!:)

**Jeff Bergosh**: They owe Brandon a heck of a lot more though!!

### CONVERSATION ON 07-03-2020

**Jeff Bergosh**: SALLY I finished my neighborhood meeting I had to repair a sign and then I had to stop at my office to pick up some postcards that I will send out tomorrow  and the next day —and then I’ll be heading home.  Running just a little behind sorry.  love you❤️

**Sally Bergosh**: Lol- I just got home- drive safe! Love you!!❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: A “little behind”......hmmmm

**Sally Bergosh**: Bring food!!

**Sally Bergosh**: Healthy food

**Jeff Bergosh**: Got it, bringing it home for you!❤️😎👍

**Sally Bergosh**: Yay!!

### CONVERSATION ON 07-04-2020

**Jeff Bergosh**: Sounds great we’ll come by and say hello to everyone

**Sally Bergosh**: Hey, Sally! We just got done playing a fierce game of tennis around the corner from our house! We would love to come see you whenever you get situated, let us know a good time! Jeff & I are in the middle of our 6th day juicing so not wanting to be around food- but count us in for getting together- Tori is working 1/2 day today, B is in his 2nd week moved in his apartment by UWF & Nicky is back at law school doing his internship in Wisconsin! 6 weeks until Jeff’s Election Day! Let’s get together for some drinks!

**Sally Bergosh**: Yes!!👍🥂

### CONVERSATION ON 07-05-2020

**Sally Bergosh**: We are on our way!!👍

### CONVERSATION ON 07-06-2020

**Sally Bergosh**: Can u please help me strategize getting on commissioner’s calendars? How should I go about this?

**Jeff Bergosh**: I’m working it from my side but I would start with a call to Debbie.  She has the inside track on Arretta, Dawn, and Angela Crawley’s calendars (commissioners aides)

**Jeff Bergosh**: Tell them you would like a quick 15 minutes in person or via phone conference

**Sally Bergosh**: Got it!:)

**Jeff Bergosh**: ....tell them it’s about next week’s outside agency requests for the health and hope clinic

**Sally Bergosh**: I called all three just now & every call went to gmail so I left a good message 

**Sally Bergosh**: Voicemail, not gmail

**Sally Bergosh**: We are on for your off jail Saturday at 1:00, Rob said long pants & no open toe shoes!

**Jeff Bergosh**: Okay perfect. 

### CONVERSATION ON 07-07-2020

**Jeff Bergosh**: Love you!  I’m going to bed—got to get up at 4:30 for my coffee tomorrow.  Come home boxer!!

### CONVERSATION ON 07-08-2020

**Sally Bergosh**: Great job on the front end with Janice & Eric. I think Stafford was boring......I saw peeps jump off after few minutes. Janice saying Stafford’s lack of opponents & unopposed elections are a testimony of character was a stretch

**Sally Bergosh**: You looked skinny- btw!!❤️

**Jeff Bergosh**: Thank you!!!!  Love u!!!

**Jeff Bergosh**: Great News- I was just endorsed officially by the police union, the PBA!!  Can u believe it?  Will miracles never cease?!?

**Sally Bergosh**: I love this news!! Thanks for making my day!!

**Jeff Bergosh**: It made my day too!! Thought you’d like to hear some good news!!

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Going to bed— love u!  Come home soon! Brandon is here doing laundry 🙂

### CONVERSATION ON 07-10-2020

**Sally Bergosh**: In front of our house today?!!?

**Jeff Bergosh**: Water leak

**Sally Bergosh**: There were 3 ECUA trucks there at once so I figured I better let you know! 

**Jeff Bergosh**: Where were they digging where they did they dig up our driveway or where were they

**Jeff Bergosh**: It’s hard to tell from the picture

**Sally Bergosh**: I’m at the clinic so I can assure you I have no idea!! Ashley Woodcock sent to me from next door

**Jeff Bergosh**: We got it fixed I talked to ECUA

**Jeff Bergosh**: 👍🙂

### CONVERSATION ON 07-12-2020

**Jeff Bergosh**: Okay that’s smart.  Good move Nick!

**Sally Bergosh**: We love you, Nicholas!! Which friend did u move in with while waiting it out?

**Sally Bergosh**: Cool

**Sally Bergosh**: Oh thank God he is awake!! Is he coherent?

**Sally Bergosh**: Keep us posted please! Is mom feeling ok?

**Sally Bergosh**: Physically- like does she have a fever or anything?

**Sally Bergosh**: ❤️

**Sally Bergosh**: Good. So glad you & Tyler are with her right now!!❤️❤️

### CONVERSATION ON 07-13-2020

**Sally Bergosh**: Mario’s tournament THIS Saturday- can I tell him yes?!!?

**Jeff Bergosh**: Sure

**Sally Bergosh**: K

**Sally Bergosh**: Please let me know after u r updated

**Sally Bergosh**: Thank you!! So frustrating....

**Sally Bergosh**: 🙏❤️❤️

**Sally Bergosh**: Heart bypass surgery soon 🙏🏻

### CONVERSATION ON 07-14-2020

**Sally Bergosh**: Dad is having open heart surgery-Direct line to Dad at Hospital is 6197402569.  For family only.

**Sally Bergosh**: Sara Peacock will not know what to do with herself!! Remember, call it the police & sheriff union- PBA, then define it plus Volunteer fire association endorsements!! Yay!!

**Jeff Bergosh**: 😁😁😁😁😁😁😁😁

**Sally Bergosh**: My dad is having open heart surgery right now- please pray for him!! My mom is already campaigning for us to come for Christmas!! ❤️❤️🙏

**Jeff Bergosh**: 🙏 

### CONVERSATION ON 07-15-2020

**Jeff Bergosh**: Can you believe that piece of shit??

**Sally Bergosh**: Please don’t say anything more!!

**Jeff Bergosh**: It’s over

**Sally Bergosh**: Omg!! I was so proud of Sara!! She handled him with class

**Sally Bergosh**: I’m so bummed Lumon left before we presented

**Jeff Bergosh**: That’s what he does

**Sally Bergosh**: This is so up Lumon’s alley- what we do everyday is his peeps!!

**Jeff Bergosh**: I believe he will vote for it

**Jeff Bergosh**: I believe it will be 3-1

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Do u have time for a quick question?

**Sally Bergosh**: Never mind

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Just got back to office

**Sally Bergosh**: Any update?!!?

**Sally Bergosh**: Got it! Everyone’s asking so I didn’t know how long the surgery was.

**Sally Bergosh**: Yikes!!

### CONVERSATION ON 07-16-2020

**Sally Bergosh**: This from Monica Sanford:

Just had to say your husband was correct that underhanded Underhill was completely "disgusting". ¿¿I immediately thought..  well that's immature and embarrassing as hell.¿¿You do great things for thousands of people to receive much needed healthcare chica.. hugs. 

**Jeff Bergosh**: Thanks!



**Sally Bergosh**: Perfect- thank you!

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you right back!!

**Sally Bergosh**: So B cancelled via a text to me at 2:30 am.....waaaaay too late to cancel our 7:30-9 am tennis lesson with Paul Einhart....... he f’d me up at RScott & I’m furious!!

**Sally Bergosh**: Bad choices are stacking up!!

**Jeff Bergosh**: Sorry to hear this, very uncool

**Sally Bergosh**: Woohoo- got a small dental grant today!

**Jeff Bergosh**: I just talked to Jeanette.  3:00 Saturday- we’re on

**Sally Bergosh**: Does she understand we have to be somewhere at 4?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: 4:20

**Sally Bergosh**: K!:)

**Jeff Bergosh**: Going to bed, got to get up early for bible study.  Love u!  Come home soon boxer!❤️

**Sally Bergosh**: What’s his name? Get his business card always!! My friend is a headhunter & she will get some of her best employees at random places- love it & think that is a HUGE compliment!!

**Sally Bergosh**: That happened to Tyler when he was a waiter in Hawaii & he ended up getting a great real estate job in San Francisco

### CONVERSATION ON 07-17-2020

**Jeff Bergosh**: Going into the mail today 😎👍

**Sally Bergosh**: You’re the BEST- love you!!

**Jeff Bergosh**: Love u most!

**Jeff Bergosh**: ???? Foods here

**Sally Bergosh**: On way

### CONVERSATION ON 07-18-2020

**Sally Bergosh**: This text just came to my phone fr FRM:AT&T 
SUBJ:Payment on hold. Call 3527291270 .
MSG:0319

**Jeff Bergosh**: Fraud— do not respond

**Jeff Bergosh**: !!!

### CONVERSATION ON 07-19-2020

**Sally Bergosh**: I’m stopping for gas

**Sally Bergosh**: & on my way home

**Jeff Bergosh**: No— I’ll do it just come home

**Jeff Bergosh**: I’ll go get it

**Sally Bergosh**: Done

**Jeff Bergosh**: Okay I’ll pay for it at least 

**Sally Bergosh**: $30

**Jeff Bergosh**: Making dinner

**Sally Bergosh**: Are you a republican or a Democrat?

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 07-20-2020

**Jeff Bergosh**: Sally— got the poll results back today— and as of right now- among those voters who have made up their minds in my race, the numbers are as follows:

Jeff Bergosh.        42%
Jesse Casey.         34%
Jonathan Owens.  14%
Jimmie Trotter.       10%


8 point lead over Jesse
28 point lead over Doug’s Secretary 
32 point lead over Trotter

It’s noteworthy to point out that at this point in the race 4-years ago, Jesse and I were in a virtual dead heat in my final, 30 days before the vote poll——so I feel good about where we are as votes are being cast right now as we speak—but I’m going to continue to run as if I am 20 points behind!

### CONVERSATION ON 07-21-2020

**Sally Bergosh**: Please read!! Very timely & important lesson!!

**Jeff Bergosh**: Okay will do!  Love u!

**Sally Bergosh**: Wendy just attacked me in Facebook as the commissioners wife trying to get taxpayers dollars for non profit

**Jeff Bergosh**: Ignore her

**Jeff Bergosh**: 4 weeks and one day

**Sally Bergosh**: This is not their site it’s from our night on that fireman’s Facebook comments

**Jeff Bergosh**: Please don’t engage

**Jeff Bergosh**: 14% is all Doug and Wendy and Jonathan get.  They are non-factors and should be disregarded

**Sally Bergosh**: https://apple.news/AQTKvFSlNRwKmW9qOISq7oA

**Sally Bergosh**: I engaged in Michael Aaron’s post with Wendy after she called me trashy

**Jeff Bergosh**: I get it!  It sucks absorbing attacks.  Just say your piece and turn it off

**Sally Bergosh**: Wendy Kinton Underhill if writing a grant on behalf of an amazing non profit that has never put in for funding in their 17 year history, but is the only free community clinic open during COVID & is keeping sick people out of our hospitals for real emergencies & that provided over $2.5 million last year in medical & dental services with all volunteer nurses & doctors- guilty as charged! At least I don’t go to the BOCC begging for legal fees for my husband’s inappropriate behavior that has landed him in countless lawsuits! 

**Jeff Bergosh**: ❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️

**Jeff Bergosh**: And if she pipes up after that you should do something like this:  And by the way Wendy don’t ever presume to lecture me on ethics you and your husband went bankrupt belly up and beat a Lotta good business is out of hundreds of thousands of dollars locally in Escambia County. Hey by the way when you got back up on your feet did you pay them back?

**Sally Bergosh**: So much for scripture I sent you earlier.....I feel a bit ashamed I engaged.....

**Jeff Bergosh**: Don’t be.  It’s human nature to respond to lies and we all have the right to defending our reputations, dignity, and honor.  I love u!!

**Sally Bergosh**: Shaun Hall likes her calling me trashy

**Jeff Bergosh**: That’s because he’s a piece of shit firefighter who worships Doug and Jonathan

**Jeff Bergosh**: Seriously Sally— do not let this consume you.  Let it go.  You said your piece—let it go

**Sally Bergosh**: Milt passed away last night from COVID- service is on Sunday!! I think we should attend.🙏❤️

**Sally Bergosh**: I’m updating our BOD roster. Do I put a credential next to Nix Daniel’s name? Like McLeod is MD, dentist is DMD

**Jeff Bergosh**: We will definitely attend—sorry to hear this

### CONVERSATION ON 07-23-2020

**Jeff Bergosh**: In today’s paper

**Sally Bergosh**: Love it!!❤️

**Sally Bergosh**: Yay!!

### CONVERSATION ON 07-24-2020

**Jeff Bergosh**: Headed home from my office just now—-long day.  R u headed home soon?

**Sally Bergosh**: I’m home

**Sally Bergosh**: Did u already order the pizza?

### CONVERSATION ON 07-25-2020

**Sally Bergosh**: Hey do I have money in my account? 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Lots

### CONVERSATION ON 07-27-2020

**Jeff Bergosh**: Great message to start our Monday!

Thanks!

Love u!

**Sally Bergosh**: Love you right back!!❤️

**Sally Bergosh**: Do u think I should pick up the phone & clear the record about my grant request with Jacqueline Rodgers?

**Jeff Bergosh**: Sure

### CONVERSATION ON 07-28-2020

**Jeff Bergosh**: Your instincts were spot on Sally— that guy emailed back and apologized 🙂

**Sally Bergosh**: Yay

**Sally Bergosh**: Call me when u get a second

**Jeff Bergosh**: Mailed it certified, return receipt

😎👍❤️

**Sally Bergosh**: Yay- thank you! Pathways just called & informed me they are laying bunch of peeps off since having to cancel bunch of their fundraisers & by the end of the year will be in a $300,000 deficit

**Jeff Bergosh**: Oh my!!

### CONVERSATION ON 07-29-2020

**Sally Bergosh**: Too much “personally this is going to be a hard decision for me”- you keep saying that over & over.......

**Sally Bergosh**: You are doing all the talking in this 2nd half of the segment!  Ugh

**Sally Bergosh**: I loved the doctor segment today!❤️

### CONVERSATION ON 07-30-2020

**Sally Bergosh**: Love!!❤️❤️

### CONVERSATION ON 08-01-2020

**Jeff Bergosh**: Have fun and be safe!!

**Sally Bergosh**: Loved a movie

**Sally Bergosh**: Loved “We could come down to Chicago for the day while you guys are up here ”

### CONVERSATION ON 08-02-2020

**Sally Bergosh**: Hey, family!! Your last chance to support your dad before Election Day will be on Saturday, August 15, 11-2 pm in front of KFC on Michigan & Mobile HWY. please invite friends to participate. We will supply tshirts, cold drinks & lunch for everyone that joins us to wave signs that day!!

### CONVERSATION ON 08-03-2020

**Sally Bergosh**: Brandon- are you alive? You know we had a steak & baked potatoes for you last night!! Where have you been? Wishing you well in your finals this week!! Love you! Invite your friends to wave with us on Saturday, August 15!

**Sally Bergosh**: Are u planning on going to our last sign waving day & supporting your dad?

**Sally Bergosh**: That’s amazing your first class is on a Saturday!?

**Sally Bergosh**: Yes! See if your friends can come help like Nicholas did (4) years ago & like Alex did for your dad last Saturday!

### CONVERSATION ON 08-04-2020

**Sally Bergosh**: Jacqueline Rodgers latest rant with 200 plus peeps weighing in with pitchforks!!

I am a bit frustrated. 
I wear a mask and so does my family when we are in public places that necessitate it. Some in my family have to wear them daily to work, etc.
But I am frustrated with a BCC that WASTES TIME on the same issue *over and over* just for appearances and political purposes. 
For the second or third time, they are going to discuss mask mandates again, including making it a second degree MISDEMEANOR for someone not wearing a mask!
Do you know that the City of Pensacola has not issued any citations for non-mask wearing? It's all for show.

In the meantime, we have a commissioner, Comm. Barry,  that  personally negotiates a higher than standard land purchase from his constituents on Kingsfield Rd. right before a primary (and higher than what he admits the land would appraise for) WITHOUT the ordinance required appraisal for land acquisitions over $20,000 and NOT A PEEP from his colleagues (except one) or the Media (as they run their 1,000th covid story ad nauseum). 
Should THAT be a misdemeanor? 

You have two commissioners, May and Barry, that *did not even take* the required Commissioner Ethics Training until a public records request was done in April asking for all of the BCC's certificates. (Bergosh only sent a receipt, so let's hope he passed!) This is required annual training!
The PRR was sent on April 9th. 
Barry's Certificate is dated April 10th and May's is dated April 15th.
Should THAT be a misdemeanor?

A Commissioner (Bergosh) makes a passionate plea at the budget hearing for the County to newly fund, with scarce taxpayer dollars, an Outside Agency that his own wife just became the Executive Director of  and villainizes anyone that raises an eyebrow at that ... meanwhile we don't have enough money to fund four person crews at the Fire Department.
Maybe THAT should be a Misdemeanor!  

But these fine fellows want to tell US how we should run our life, even to the point of possibly handing out Misdemeanors for not wearing a mask. 
Again, I wear a mask and have many for my family. 
That is not the point!
This is all *smoke and mirrors* for them not doing what they are supposed to do and doing things they shouldn't! 
How will it ever change???!!!

There was just a call for EMS in Cantonment and do you know where the nearest unit was to respond? 
CENTURY!!!
That is easily a 30-45 drive. 
But since they cook the reporting stats, we will never know. 
(They still haven't answered my public records request on the number of times that EMS is holding calls.)

But let's have pandering coffees with commissioners and another long discussion at the next meeting about how the BCC can tell us how to live our life, while they ignore the *real* Health and Safety issues that have festered for years while they were in office! 
Wake Up!
We do not have safe Fire or EMS coverage. 
Commissioners, Why don't you devote as much attention to that as you do to helping Developers and mandating medical advice???!!!

We are losing Fire fighters/Paramedics/EMTs because of the conditions and lack of support in those departments. 
I talk to the people on the ground. 
I am not making this up. 
You can see that this has happened for years and they have gone through several Chiefs and Directors but the BCC continues to ignore it. 

Corona virus is real. We lost an uncle to it. 
Several of my kids work in the medical field. 
I've had friends very sick with it. I get it. 
But the issue has become so fake and politicized that it is hard to wade through all the virtue signaling to get to the truth. 
And I've been disgusted by the cannibalization of our community, promoted by our leaders, to hide their inability to deal with issues they are actually in charge of! 
There are many things that the BCC could be doing to make us safe but they refuse to do so. 
A fake, unenforceable mask mandate is not one of them.

**Jeff Bergosh**: Don’t pay any attention to that site

**Jeff Bergosh**: It means nothing.  It is a toxic, hate-fueled pit of snakes.  I have not been on that site for more than 130 days.  One of the best decisions I’ve made recently.  You should do likewise.... turn it off.

**Sally Bergosh**: What is the stuff about EMS turning calls away now?!!? That is an emergency & im worried about public safety.......

**Jeff Bergosh**: It’s bullshit, not true

**Jeff Bergosh**: I’m walking the dog LOL

**Sally Bergosh**: So sweet!!:)

**Sally Bergosh**: Loved an image

### CONVERSATION ON 08-05-2020

**Sally Bergosh**: Steve Jargan looks like a fake Facebook account asking Doug Underhill questions on this mornings coffee zoom! He’s such a snake!!

**Jeff Bergosh**: It probably is/was Doug.  He is a snake

**Sally Bergosh**: I’m touring YMCA for BOD 

**Jeff Bergosh**: Cool!  Let me know what you think of it

**Sally Bergosh**: So turns out my wedding ring’s stone was almost falling out & 2 of the prongs were broken......yikes!!

**Sally Bergosh**: I’m checking them in to be repaired & cleaned up!

**Sally Bergosh**: Do I have $ in my account?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: 1100 sav

**Sally Bergosh**: Thank you- Do u know how lucky I am to have not lost the diamond?!!?

**Jeff Bergosh**: I’m so glad

**Jeff Bergosh**: That would have sucked

**Sally Bergosh**: I just found out John Porter (JP) from Baptist stays so skinny cuz he only eats (1) meal a day!!

**Jeff Bergosh**: I simply wish I had the discipline to do that but I don’t

**Jeff Bergosh**: I need three meals daily to keep my energy level up

### CONVERSATION ON 08-06-2020

**Sally Bergosh**: Hmmmmmm

**Jeff Bergosh**: LOL

**Jeff Bergosh**: ......Nobody, or very few, will even get that 13 year old reference.  Mark my words Sally.  Regardless of what happens in this election between Jesse and I—-this clown Jonathan will lose—3rd place bronze medal is what he will get.   And it will be spectacular ——by a 20+ point margin.

**Sally Bergosh**: Did u mandate masks? People are already wishing you well at your next job

**Sally Bergosh**: Are you pushing for mask wearing ordinance......?!!?

**Jeff Bergosh**: No!  No I didn’t 

**Jeff Bergosh**: Please tell me you are not on Facebook again.  Turn off the lies!!

**Sally Bergosh**: Darrell Tatum said you are pushing for masks on Willy’s political page so I had to correct him 

**Jeff Bergosh**: Good.  Get off that site

**Jeff Bergosh**: My recommendation is that you unfollow that site too.  

**Sally Bergosh**: Yep!! 

**Jeff Bergosh**: No friends there

**Sally Bergosh**: Grrrr- you’re losing big in his self righteous haters.club

**Jeff Bergosh**: That’s fine.  Unfollow it

**Jeff Bergosh**: Remember, it’s always easy for folks to take shots at the guy who is the leader, the king of the mountain.  That’s me.  The good news here is that there are multiple people trying to take me off the mountain— and they are ripping each other apart too—and ultimately they are fighting over the “anti-leader” voters, and as they split this number, mathematically it makes it nearly impossible for any one of them to get the plurality of votes necessary to win.  Not impossible, but unlikely.  So let’s turn the noise off for 12 days and then we get back to our lives, win or lose, no matter what.  Love u!!❤️❤️

**Sally Bergosh**: Love you!! Promise me u will not bad mouth your opponents

**Jeff Bergosh**: I have not and will not.  I have always run clean campaigns and I always will.

**Sally Bergosh**: What year were u at Yamotos?

**Jeff Bergosh**: 1987-1988

**Sally Bergosh**: How was your meeting?

**Jeff Bergosh**: Walking into it rn

**Jeff Bergosh**: 🙏

**Sally Bergosh**: I’m praying for HIS guidance & peace!:)

**Jeff Bergosh**: Me too!!

**Sally Bergosh**: Be a statesman!

**Jeff Bergosh**: Always

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 08-07-2020

**Sally Bergosh**: I thought this was great timing after last night’s fiasco

**Jeff Bergosh**: Isn’t that the TRUTH!!

**Sally Bergosh**: I got this from Don McLoughlin: 

Just saw today's PNJ editorial page.¿Just means Jeff must be doing something right!!! Really!!!¿Water off a ducks back....¿¿Typical Andy Marlette....anti business.

**Jeff Bergosh**: Cartoon

**Sally Bergosh**: Send it to me please

**Sally Bergosh**: What you have missed today. They are saying you did something wrong using campaign money for the clinic in hopes of getting something back in return.

### CONVERSATION ON 08-09-2020

**Sally Bergosh**: Brandon said he wants to come for Sunday night dinner! Will you text him and let him know what time?

**Sally Bergosh**: Why?!

**Sally Bergosh**: We love you- drive safe!!

### CONVERSATION ON 08-10-2020

**Sally Bergosh**: Friends and Neighbors, with the election only a week away, I wanted to give the voters a more specific list of what I would like to accomplish while in office. 

1. Look at the budget and see how we can allocate the proper funds for our First Responders. Each area of District 1 has their own unique problems. If you need an Ambulance, a Police Officer, or the Fire Department, you should get help quickly! LIVES DEPEND ON THIS!

2. Work on the planning within the district. A big example of this right now is working with the “Master Plan” of Beulah and OLF-8. I will listen to the stakeholders (the residents) before making any decisions. 

3. The Growth of our communities has really taken off. I would like to consider ALL of the resources available to the BOCC, to incorporate a stable plan to build the infrastructure up to match the development. Infrastructure = Safety! The safety of our residents is the top priority!

Folks, this is just the beginning. My promise is to ALWAYS listen to the residents. I will work HARD as your County Commissioner in District 1! Thank you for all of your support!

#CaseyCares

**Sally Bergosh**: He just put this out today! He finally has a plan.....

**Jeff Bergosh**: He copied me LOL

### CONVERSATION ON 08-11-2020

**Sally Bergosh**: Mary Sue’s hubby passed away from COVID this week.

**Sally Bergosh**: I’m going to get over to the funeral at 2 pm Friday. So sad!!

**Sally Bergosh**: This is the couple that host the NurseSpring Christmas party every year & he was retired big wig from Gulf Power.....😥💔

**Jeff Bergosh**: Sad

### CONVERSATION ON 08-12-2020

**Sally Bergosh**: Great job this morning!! DC is much more articulate then I remember him being in the past. Maybe his coke days are behind him! Lol

**Jeff Bergosh**: Thanks!  I thought he was a great interview— looking forward to reading his article in the Atlantic

**Sally Bergosh**: I need u to transfer $700 to my checking, Tori and I found the best deal at the Pfizer

**Sally Bergosh**: Tell me when u have moved it over

**Sally Bergosh**: Ready?

**Sally Bergosh**: Never mind- we just booked and we don’t pay until we are there for check in!:)

**Jeff Bergosh**: R u sure?  I’m logged in right now??

**Jeff Bergosh**: Okay, sounds good!

**Sally Bergosh**: Love you!!:)

**Jeff Bergosh**: Love u most!!!  Thanks for taking care of this!!

**Jeff Bergosh**: SALLY you’ll get a kick out of this this is my good music good mood big smile walking playlist for my lunch break walk today. The 1980s band loverboy :-) remember them?

**Sally Bergosh**: Hi Sally, Mario gave me your number. I was reaching out because my school let go of 14 teachers today based on seniority. I was only in Santa Rosa County 1 year. Previously, I was in Okaloosa, and before that New point. Wondered if Jeff would help me to find something in Escambia. Would you mind passing this msg on. This is Nancy Ellman. Really need to use my connections so I thank you in advance.

**Sally Bergosh**: Oh my goodness! This morning’s devotional was spot on!!

### CONVERSATION ON 08-13-2020

**Sally Bergosh**: Do u have stamps at home?

**Jeff Bergosh**: Yes I do have a whole bunch at my office on the base I’ll bring them home tomorrow

**Jeff Bergosh**: Sally—heading to bed love u!  Spaghetti is in the fridge!!

Love, me

**Sally Bergosh**: Ughhhhh- I am running on Adrenalin & have just kept working tonight after the clinic crazy ended! I’m packing up right now!

### CONVERSATION ON 08-14-2020

**Sally Bergosh**: I just got your email add from your campaign!!❤️

**Jeff Bergosh**: Did you like it?

**Sally Bergosh**: Of course & I like the organization of info & all the great links!

**Sally Bergosh**: My tennis was rained out- so I have time to go to bank or did you already move funds over?

**Jeff Bergosh**: No I haven’t yet so if it’s convenient just put your check straight into your checking account😁👍

**Jeff Bergosh**: Love u!! 

**Sally Bergosh**: Will do! Love you!

**Jeff Bergosh**: Thank you for forwarding 

Love u!

**Sally Bergosh**: What is our IPC #? 

**Jeff Bergosh**: 294

**Jeff Bergosh**: Why?

**Sally Bergosh**: I’m going to see if I can do a party room at Flounders for Bree’s baby shower like we did for the kids for their bday party

**Jeff Bergosh**: Oh, okay.  When is that?

**Sally Bergosh**: October 3, 3 pm

**Jeff Bergosh**: Oh, okay.  That will be nice for you to do that👍

**Sally Bergosh**: Does our IPC also work at Crabs ?

**Jeff Bergosh**: Yes I believe it does

**Sally Bergosh**: Yay!!:)

### CONVERSATION ON 08-16-2020

**Sally Bergosh**: On way home

### CONVERSATION ON 08-17-2020

**Sally Bergosh**: We are waiting up for you!! Love you & so proud of all your hard work!!❤️❤️

**Sally Bergosh**: I agree with Brandon!! Get those texts out!!

**Sally Bergosh**: Awwww- thanks, Susan!! Final stretch!!

### CONVERSATION ON 08-18-2020

**Sally Bergosh**: Are you at the precinct or at work right now? 

**Jeff Bergosh**: I’m at precinct Fr..43 Beulah free Will Baptist Church and I’m gonna be here all day

**Jeff Bergosh**: Why is everything OK?

**Sally Bergosh**: Yes- what time is your text message going out?

**Jeff Bergosh**: 900

**Sally Bergosh**: I’ve been getting lots of “good luck” text messages this morning!

**Jeff Bergosh**: Me too

**Jeff Bergosh**: 😎😎👍👍

**Sally Bergosh**: Is your competition there?

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: Nope

**Jeff Bergosh**: Jesse has some relatives and Jonathan has some firefighters waving

**Sally Bergosh**: Of course....ugh!! 

**Jeff Bergosh**: It doesn’t matter I’m feeling incredible love like I’ve never felt before people are stopping people put me over people are asking for T-shirts it’s amazing it’s overwhelming I got emotional

**Sally Bergosh**: This is amazing & I know you needed that- God has a way of giving us exactly what we need, when we need it!

**Jeff Bergosh**: That is soooooo true!

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Love!!❤️

**Jeff Bergosh**: 😎😎👍👍

**Jeff Bergosh**: Loved “Good stuff pops😌”

**Sally Bergosh**: Of course, I never got the text! Ugh!

**Sally Bergosh**: Thanks, Jeanette!! ❤️❤️

### CONVERSATION ON 08-19-2020

**Sally Bergosh**: Johnny Cole said to text him & he wants to help you take down signs!!:)

**Jeff Bergosh**: Okay

**Sally Bergosh**: I just pulled all signs by our interstate entrance except the huge one!!

**Jeff Bergosh**: Thank u!!

**Sally Bergosh**: I’m right by Stefani Rd for my nail appointment- do I need to check down there for your signs?

**Jeff Bergosh**: No— I’m not picking up signs from just the road today that’s a next week or two weeks from now thing I am just picking up signs at the precincts and that’s the only priority for today

**Jeff Bergosh**: I’m hoping I can have it all wrapped up by around 2 o’clock and we can get on the road by 4 o’clock

**Sally Bergosh**: I’m all packed & at my appointment- I’ll check in with you and see what still needs to be done

**Jeff Bergosh**: Okay I have 2 more to do.  I have to stop at the house to drop off first—— my trucks full!!!!

**Sally Bergosh**: Loved my devotional today!!

**Jeff Bergosh**: Thank you Susan!!!!

**Sally Bergosh**: Loved “Congratulations!  🎉🍾🎊 I know you both are glad it is over.  I hope we can celebrate soon.  Have fun WI!”

### CONVERSATION ON 08-20-2020

**Sally Bergosh**: Sounds great!!👍

### CONVERSATION ON 08-22-2020

**Sally Bergosh**: Thanks Mom & Dad Marsh!!

### CONVERSATION ON 08-25-2020

**Jeff Bergosh**: I’m with Brandon at the Kia Dealership 

**Jeff Bergosh**: 😎👍

**Sally Bergosh**: I’m racing across town to get to my last USTA tennis match!

**Sally Bergosh**: Send me pictures but I really think you could get something in same price range at Nissan and Hundai

**Jeff Bergosh**: He’s going with a dark grey Kia Forte.  We’re not going to be able to do any better than the deal I worked up 😎👍

**Sally Bergosh**: Beautiful car- I approve!!❤️

**Sally Bergosh**: Tara got Robert Rinke- $1000 sponsorship

**Jeff Bergosh**: Nice!

### CONVERSATION ON 08-26-2020

**Sally Bergosh**: I’m still in a meeting- but can call u on way home

**Jeff Bergosh**: I’m making hamburger helper!

**Sally Bergosh**: Now that sounds healthy- lol!!

### CONVERSATION ON 08-27-2020

**Sally Bergosh**: This is from a girl on my tennis team: Lori Orslene!

Please vote Like for the Recreation Opportunity ideas (I wrote it) if it’s not a conflict of interest because of your hubby and if you agree. Thanks! Lori  PS: See you tomorrow.

**Sally Bergosh**: https://colab.dpz.com/olf8/olf8-map/

### CONVERSATION ON 08-28-2020

**Jeff Bergosh**: Wow is that timely or what?!?

**Jeff Bergosh**: ❤️❤️❤️

### CONVERSATION ON 08-29-2020

**Sally Bergosh**: My tennis just got rained out

**Jeff Bergosh**: Sorry— ours is still a go!

### CONVERSATION ON 08-31-2020

**Sally Bergosh**: I really need some intros or email addresses this week for H&H’s Christmas Gala please!:)

**Jeff Bergosh**: Will do it!

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you right back!!❤️

### CONVERSATION ON 09-01-2020

**Sally Bergosh**: On Beulah Scoop you are getting complaints about roots coming up in the Pathways so kids are getting hurt trying to ride their bikes or people trying to run & getting hurt! This should come before climbing rocks

**Jeff Bergosh**: Okay I’ll see what can be done

**Jeff Bergosh**: .......and I was right, it was the transmission/torque converter

**Sally Bergosh**: 👍❤️❤️

**Jeff Bergosh**: Newsflash for you hot off the press the school board did not pick Keith Leonard as superintendent

### CONVERSATION ON 09-02-2020

**Jeff Bergosh**: Grilled Chicken for dinner 👍👍

**Sally Bergosh**: Nope- we had another coaching tonight with Jessica in California & she making us change a bunch more crap!

**Jeff Bergosh**: Love u goodnight!  Leftovers in the fridge 😎👍❤️

**Sally Bergosh**: Jim Cromley sent me $1000 today!!

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: 👍

**Sally Bergosh**: Tori is bummed- our ink just ran out on our computer!!

**Jeff Bergosh**: Okay well I’ll get more

**Jeff Bergosh**: Look in top right drawer— there may be one more cartridge in there

**Sally Bergosh**: Look on Beulah Scoop- someone posted newspaper article about 

**Sally Bergosh**: 6 lanes vs. 4 lanes- project is never-ending

**Jeff Bergosh**: The FDOT is like a gift that keeps on giving to me. The only thing that would’ve been worse is if they would’ve announced this three weeks ago a week before my election LOL

**Jeff Bergosh**: 😂😂😂😂😂😂😂😂😂😂😂😂

**Sally Bergosh**: Just leaving Salzman’s party- huge crowd!:)

### CONVERSATION ON 09-05-2020

**Sally Bergosh**: Can u make sure u put my team of 4 reservation at IPC Sunday at 5 pm?

**Sally Bergosh**: Totally not my fault but my mani/ pedi is taking long- they are almost done but if u have to scoot, I would go on!!

**Sally Bergosh**: I’m sorry I didn’t get home in time, PC! Love you!!❤️

### CONVERSATION ON 09-08-2020

**Sally Bergosh**: Please let Sara respond first if Doug goes down that road again tonight at the meeting. Sara says “she’s got this”!!

**Jeff Bergosh**: So you think I should say nothing and ignore him?

**Sally Bergosh**: Just Sara go first- we want to make this about the mission not the people as I’m sure that’s what u want too

**Jeff Bergosh**: Okay

**Sally Bergosh**: Thank you for respecting our wishes

**Jeff Bergosh**: 👍

**Sally Bergosh**: We r here for your spectacular meeting- according to Pam Childers there is supposed to be boxing gloves on for this budget meeting! Grrrr

**Jeff Bergosh**: LOL

**Sally Bergosh**: So far so good/ no Underwood is making it all go better!

**Jeff Bergosh**: Don’t worry he’ll be back LOL

**Jeff Bergosh**: Let’s talk about what just happened later.  Not via text though.  

**Sally Bergosh**: Just text me when u r leaving

**Sally Bergosh**: Hp

**Jeff Bergosh**: I will.  ❤️

**Jeff Bergosh**: Don’t drink and drive

**Sally Bergosh**: I’m at Hickory Bar

**Jeff Bergosh**: Don’t drink and drive

**Sally Bergosh**: Where r u?

**Jeff Bergosh**: Still in marathon

**Jeff Bergosh**: Hello?

**Sally Bergosh**: We r good!! We had waters between our drink & a half! We split our 2nd 

**Sally Bergosh**: Home❤️

**Jeff Bergosh**: Meeting just ended

**Jeff Bergosh**: On way

**Sally Bergosh**: I brought in the trash cans! Love you!

### CONVERSATION ON 09-09-2020

**Sally Bergosh**: I need Bender’s cell #

**Jeff Bergosh**: Sally I’m making dinner—!steaks are going on the grill in about 5 minutes.  R u on way home?  

Love u!!

**Sally Bergosh**: Yes- I was able to get the dishwasher to run this morning so they are clean!

**Jeff Bergosh**: I saw that and emptied it ❤️❤️

### CONVERSATION ON 09-10-2020

**Sally Bergosh**: I’m getting these random phone #’s sending me these texts:

Sally, final notification about your USPS package 2A51H3 from 04/22/2020. Go to: m6szv.info/EjTDrCjRQ4

**Sally Bergosh**: Here’s another one!

Sally, urgent notice about your USPS package 8S93L3 from 05/11/2020. Go to: m5smz.info/RXKfYLfpSO

**Jeff Bergosh**: Looks like spam or malware I would not click these links.  It’s fraud 

**Jeff Bergosh**: Delete them

### CONVERSATION ON 09-11-2020

**Jeff Bergosh**: Keith Hoskins is asking for a call with me this morning at 9:30–saying it’s a matter of “High Importance”. What do you think—should I take it?

**Sally Bergosh**: Yes- be respectful & nice

**Jeff Bergosh**: Like Dagnall was to me?

**Jeff Bergosh**: I texted him back and said sure

**Sally Bergosh**: Move on & be professional

**Jeff Bergosh**: .....Gee, I wonder what’s so “High Importance”

**Sally Bergosh**: Construction-

**Jeff Bergosh**: My guess:  Either the six Lane project or OLF8 playground mall

**Jeff Bergosh**: One of those two

**Sally Bergosh**: Attitude- be POSITIVE & make sure you align with him emphasizing you & him want the same thing!! 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Stopping to get printer ink on way home 😎👍

### CONVERSATION ON 09-12-2020

**Sally Bergosh**: Is this a good guy?

**Jeff Bergosh**: Yes

**Sally Bergosh**: If I order Patrellas for dinner will u pick it up on your way home?

### CONVERSATION ON 09-14-2020

**Sally Bergosh**: It keeps moving closer & closer to us. Yesterday it was predicted to hit New Orleans, now it’s predicted to hit right at the Alabama/ Mississippi border & we are in the cone!!

**Sally Bergosh**: Your weather is forecasted at 78 degrees tomorrow

### CONVERSATION ON 09-16-2020

**Sally Bergosh**: Test

**Jeff Bergosh**: Got it

**Sally Bergosh**: We have another tree in the back that fell down & yet another tree between David & our house that David has declared to be ours on our property line.

**Sally Bergosh**: Brandon- you okay?

**Sally Bergosh**: Brandon is alive, everyone!! He is trying to sleep! 😂

### CONVERSATION ON 09-17-2020

**Jeff Bergosh**: Will call u right back

**Sally Bergosh**: If u stop anywhere- my clinic needs more dry ice

**Sally Bergosh**: First quote with important note- better to do all now since the county will haul away for free after hurricanes!

$2,200.00 to remove tree and stump and wood line all the way across the backyard

**Sally Bergosh**: Greg said he will clean up the tree branches from the grass

**Sally Bergosh**: I think we should go make a run for gas up to Buckeyes this evening

**Sally Bergosh**: Help is on the way!

**Jeff Bergosh**: Nice 

**Jeff Bergosh**: Got it thanks Nick

**Sally Bergosh**: No call still

**Sally Bergosh**: He still hasn’t called. Can u just text me his # or just tell him to come over?

### CONVERSATION ON 09-18-2020

**Sally Bergosh**: 8507122492 Derrick Lee (Nick’s buddy)

**Jeff Bergosh**: Got it

**Jeff Bergosh**: Voicemail— left him a message

**Sally Bergosh**: Really?!!?

**Jeff Bergosh**: They called back

**Jeff Bergosh**: Absolutely

**Sally Bergosh**: U can stay as long as you want!! We love you, B!!

**Sally Bergosh**: How?

### CONVERSATION ON 09-22-2020

**Jeff Bergosh**: Hey where are you?

**Sally Bergosh**: We are at VPauls!! R u still in meeting?

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: No— just got home

**Jeff Bergosh**: Tried calling and texting you

**Sally Bergosh**: I have your charcuterie 

**Jeff Bergosh**: Thank you!  I’ll take it for lunch tomorrow

### CONVERSATION ON 09-23-2020

**Sally Bergosh**: Did u get an email from Ellen Sanders yesterday?

**Jeff Bergosh**: Yes we read it and will respond to her today

**Sally Bergosh**: Copy me so I know what’s going on when she calls me next please❤️

**Jeff Bergosh**: Okay will do

### CONVERSATION ON 09-25-2020

**Jeff Bergosh**: https://wdtprs.com/2020/09/video-unhinged-karens-spittle-flecked-obscenity-laced-nutty-on-hearing-that-justice-ginsberg-died-language-warning/

**Sally Bergosh**: Can u make sure I have funds- my every (3) month tennis dues is due today

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: Who is that chick.......?!? This video means nothing because there are crazies on both sides!!

**Jeff Bergosh**: She’s just an unhinged leftist fruitcake job pissed off about RBG dying before Biden gets in office LOL

**Jeff Bergosh**: That’ll be one hell of a video

**Sally Bergosh**: Totally!!

**Jeff Bergosh**: Are you done with tennis already?

**Sally Bergosh**: Nope

**Jeff Bergosh**: Have fun!

**Sally Bergosh**: Back at the grindstone

**Jeff Bergosh**: Love u!

**Sally Bergosh**: Love u most!!

**Jeff Bergosh**: Did you deposit that campaign check $72.51 yet?

**Sally Bergosh**: Yes

**Jeff Bergosh**: 👍thanks!

**Sally Bergosh**: Waiting on contractors

**Jeff Bergosh**: Hey Tori got home and I invited her to come with us to dinner.  R u coming home soon?

### CONVERSATION ON 09-27-2020

**Sally Bergosh**: Home- we won in one heck of a tough match- (2) tie breakers!! I played against Dr. Barbra French & Sue Nast

### CONVERSATION ON 09-28-2020

**Sally Bergosh**: Brandon finally gave us his address last night: 2220 Gloria Circle -Building 12, Apartment 143, Pensacola, FL 32514

### CONVERSATION ON 09-29-2020

**Sally Bergosh**: I need u to call around for help for our son!! He just admitted that he smokes pot regularly & he did provide pot to Cunningham & Kaser in high school. He is all over the place like his head is scrambled!!

**Sally Bergosh**: 20 minutes ago he announced he is done with school & then he came back in my room & said he changed his mind & he is going to stay in school......

**Jeff Bergosh**: I will 

**Sally Bergosh**: WtF?!!?

**Jeff Bergosh**: I will find help

**Jeff Bergosh**: Are u going to drive him straight to his class, or to his apartment?

**Sally Bergosh**: His apartment so he can get his books & car. 

**Jeff Bergosh**: Okay. Just keep telling him how much we love him

**Jeff Bergosh**: I’m researching programs at Lakeview

**Sally Bergosh**: What about a grief counselor? Can u talk to Cameron’s dad & get the real scoop? Reach out & tell him how sorry we are for his loss?

**Jeff Bergosh**: I’ll look into several options but I believe Lakeview is the starting point for all of it

**Sally Bergosh**: Gary has a counselor for Alex

**Jeff Bergosh**: I’m trying not to bring Gary into this.  I’m desperately hoping this is a transitory issue and that once he comes down from this high we will get Brandon back

**Jeff Bergosh**: Are you all headed out soon?  It’s almost 8:30

**Sally Bergosh**: Nope- I can’t get him in the shower- I finally got him to eat some eggs & drink a cappuccino

**Jeff Bergosh**: You might have to just drop him off at school directly

**Jeff Bergosh**: Or else he will miss class

**Sally Bergosh**: I’m in his room with him

**Sally Bergosh**: He is acting like he is asleep

**Sally Bergosh**: Text me when u get to the door so I can let u in

**Jeff Bergosh**: Here

**Jeff Bergosh**: Sally do I need to call the lady about the 3:00 appointment?

**Sally Bergosh**: No

**Jeff Bergosh**: What is status?

**Jeff Bergosh**: This exchange from Brandon’s roommate Brandon just now

**Sally Bergosh**: Ok- I’m going to go home then?!?

**Jeff Bergosh**: I guess?  If he is sleeping... I hope he is sleeping

**Jeff Bergosh**: Just now......

**Sally Bergosh**: He just called & he wants us to order pizza - he is on his way to the house!

**Jeff Bergosh**: ??

**Jeff Bergosh**: Sally will you meet these folks over at Brandon’s apartment?

**Sally Bergosh**: Let’s call that lady & see if they can come tomorrow to OUR house?

**Jeff Bergosh**: Any update(s)?  I’m at the fire station but meeting doesn’t start for 10 minutes

**Sally Bergosh**: I just finished briefing the Lakeview guy & talking  to Dr. Jessica Ham & they both said the not sleeping for a long time combined with this traumatic event is probably what has triggered this manic episode which is a Segway for bypolar episode

**Jeff Bergosh**: Okay are they going inside the apartment?

**Sally Bergosh**: Yes- just the younger guy is here & was escorted by roommate into the apartment. 

**Jeff Bergosh**: Okay please call or text me with any updates I’m at this meeting but it’s not my meeting so I can step out

**Jeff Bergosh**: Love u!

**Sally Bergosh**: Love you most

**Jeff Bergosh**: Any news yet?

**Sally Bergosh**: B is starving!! 

**Jeff Bergosh**: I am too 

**Jeff Bergosh**: Where r u?

**Sally Bergosh**: Please fricking save me

**Jeff Bergosh**: Where r u?

**Jeff Bergosh**: In back?

**Sally Bergosh**: Yes

**Sally Bergosh**: He’s combative & hostile and embarrassing the fuck out of me

**Sally Bergosh**: Inpatient with psychiatrist

**Jeff Bergosh**: I’m in waiting room

**Jeff Bergosh**: In the secured area

**Sally Bergosh**: I know😥

**Sally Bergosh**: I’m in our same room still but some chick just came in to our room & asked me for our medical card then came back bopping into the room & asked me if I wanted to pay now cash or charge or pay later by a bill $780 or some unGodly amount of money & I just told her to wait till u came out

**Jeff Bergosh**: Okay

**Sally Bergosh**: I’ve never been so cold & uncomfortable in my life!! This is a complete nightmare

**Jeff Bergosh**: Yes it is

**Jeff Bergosh**: Trying to get Brandon Calmed down

**Sally Bergosh**: I’m in our old room staring at the nurse station like a complete moron! I thought he was sleeping

**Sally Bergosh**: Some nurse just came by for his glasses

**Jeff Bergosh**: Nope 

**Jeff Bergosh**: Not yet

**Sally Bergosh**: They are waiting to transfer him but need him to calm the F down

**Sally Bergosh**: Is he still talking?!

**Jeff Bergosh**: No

**Jeff Bergosh**: I’ll stay with him if you want to head home and get sleep

**Sally Bergosh**: If you will give us your consent I can have this lady come talk to you- it can even be at our house. Why don’t you come back to the house with me?

**Sally Bergosh**: 👍

**Jeff Bergosh**: I’ll call u after I get off

**Sally Bergosh**: Brandon finally gave us his address last night: 2220 Gloria Circle -Building 12, Apartment 143, Pensacola, FL 32514

**Sally Bergosh**:  He passed me on Davis Hwy- he did go to class

**Sally Bergosh**: I’m at his apartment & he is pretending to be asleep- his roommate just let me in.

**Sally Bergosh**: I’m in his room with him.

**Sally Bergosh**: He is breathing calm & his eyes are closed

**Sally Bergosh**: He was pretending

**Sally Bergosh**: He just said he really was on his way to class but then YOU told him to go back to his apartment & get sleep. 

**Sally Bergosh**: Your dad & I just left our jobs & will be taking him to Baptist Hospital for evaluation- 

**Sally Bergosh**: We were on the phone with Carolyn Sherman (770) 312-4494 and she thinks he will be more comfortable with her sending a counselor to his apartment. So they are coming at 3 pm

**Sally Bergosh**: Now B is saying he will not speak to them if they come & then he hung up on us. We are outside his apartment. The good news is his roommates are all there & said they will not leave him alone. 

**Jeff Bergosh**: I agree and it’s traffic hour right now

**Sally Bergosh**: Sure- I’ll head over to his place right now

**Sally Bergosh**: Are they really going over there right now?

**Sally Bergosh**: I’m on my way

**Sally Bergosh**: Should I knock on the door or wait till we know the counselor peeps are there?

**Sally Bergosh**: Is the roommate going to text u when they get there?

**Sally Bergosh**: He’s still threatening to leave & freaking out!! Why the F have they not put him to sleep or had him committed yet?

**Jeff Bergosh**: Where are you Sally?

**Sally Bergosh**: In the frickin back

**Sally Bergosh**: He just called the nurse ignorant & racist

**Sally Bergosh**: They are Baker Acting him & they had security come in & now they are wrestling him to the ground to give him the shot & now he is sobbing

### CONVERSATION ON 09-30-2020

**Sally Bergosh**: Can u talk for a second?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: No visitors allowed where Brandon is being housed— I just called and checked :(

**Sally Bergosh**: Yep

**Jeff Bergosh**: Also:  I left a message at 5-Sisters for them to call— nobody answering the phone just a message machine?

**Sally Bergosh**: Any callback?

**Jeff Bergosh**: Nope

**Sally Bergosh**: I thought about a good term to use- he is having some health issues & currently at Baptist hospital 

**Sally Bergosh**: Any news?

**Jeff Bergosh**: Not yet

**Jeff Bergosh**: But no updates from Baptist yet

**Sally Bergosh**: I’m going to reach out to PSC maybe they have a student relations person I can contact- I just don’t want his teachers thinking he’s blowing off school

**Jeff Bergosh**: Michael Johnston might know

**Sally Bergosh**: PSC is taken care if & Brandon called to do a short check- in with me. I just spoke with Dr. Sompalli & even though he is off work this week he has checked in with Dr. Packers & will call me back in 20 minutes 

**Jeff Bergosh**: I just talked to Brandon as well- told him I was paying the rent for him and that I got his shifts covered by talking to Manager Chris.  I told him to sleep, take the medicine, and be honest with the doctors.  I told him We’d be there to get him when he’s released.  He gave me his professors’ names Rogers and Quezada-Gonzales and I told him I would contact them to let them know he was sick and will be out. Brandon seemed appreciative of that!  I’m gonna go to Navy Federal get the rent money and meet his roommate and pay his rent for him love you!

**Sally Bergosh**: I doubt they will be releasing him today.....he needs to get better

**Sally Bergosh**: Nothing

**Sally Bergosh**: They said we would hear from them at some point today after Dr. Sompolli had evaluated him. We are still waiting. The lady that we all spoke to yesterday said she would check on him today for us..... I’ll check in with her in a bit.

### CONVERSATION ON 10-01-2020

**Sally Bergosh**: Please let me know the minute after u talk to Brandon......do u think it’s weird we haven’t heard from him?

**Jeff Bergosh**: I will— have not heard from him yet today.  Not necessarily weird— they may be putting him through tests etc.  or he may be sleeping.

**Sally Bergosh**: Sure

**Jeff Bergosh**: Sally I just spoke to Brandon he said he spoke with you and the doctor on a conference call is that true?

**Jeff Bergosh**: Call me

**Sally Bergosh**: https://www.homeofgrace.org/

**Sally Bergosh**: Where r u?!!?

**Sally Bergosh**: U made it sound like you were heading home soon when we talked 3 hours ago

**Jeff Bergosh**: Meeting just ended

**Jeff Bergosh**: Okay good.  He needs sleep!

**Sally Bergosh**: Thank you, Jesus!! I was getting really nervous that no one had heard from him!

**Sally Bergosh**: Please everyone let me know the minute you have heard from him. 

**Jeff Bergosh**: I tried calling and the nurse said he wouldn’t come to the phone.  She said try back in a little while.  

**Sally Bergosh**: ?!!?

### CONVERSATION ON 10-02-2020

**Jeff Bergosh**: Brandon called me and asked if I could pick him up when he gets released this morning.  He believes the doctor will release him and the he is much better now.  He asked if I’d be able to drop everything and get him today.

**Sally Bergosh**: Nope- he needs to sign off on that paper that we are part of his medical team/ rights & he needs to take a drug test & agree to go to therapist

**Jeff Bergosh**: Who’s there who’s there LOL

**Sally Bergosh**: 😂

**Jeff Bergosh**: 👍

**Jeff Bergosh**: On way

**Sally Bergosh**: K

**Jeff Bergosh**: 1101 west Moreno Street

**Sally Bergosh**: I thought we were meeting at the house & driving together?

**Jeff Bergosh**: I’ve spoken to Brandon and it looks as though he will be released this afternoon at 4:00.  I’ll go there after work and get him. He is doing much better and has agreed to all treatments going forward and he’ll be staying at the house with us for at least a week.  I also spoke at length with Dr. Packard his treating physician.  He agrees this is a solid course of action.  Brandon will be prescribed a medicine to calm him and help him sleep that he’ll take once daily at bed time for the next 30 days leading up to a follow up appointment that will follow the 30 days.  We will take it one step at a time— let’s all be very supportive and there for him.  Love you— Dad.

**Sally Bergosh**: K

**Sally Bergosh**: Yes, I set that timeline up with his therapist at 11 am this morning. We went over the plan & the condition is still that he has to agree to us being included in his medical team, drug urine test & to go to therapy after release.

**Jeff Bergosh**: 👍

**Sally Bergosh**: She suggested we still go by his apartment and do a search & grab him clean clothes, etc.  before we go get him

**Jeff Bergosh**: Can you do that since you are up that way?  And I’ll go get him since it’s closer to down here?

**Jeff Bergosh**: You’ll need to call and coordinate that with his roommate though

**Sally Bergosh**: Sure- promise me he is getting drug tested

**Jeff Bergosh**: He is.  That’s what I told Dr. Packard

**Sally Bergosh**: His roommate is at work until midnight

### CONVERSATION ON 10-03-2020

**Jeff Bergosh**: Sally— I’m at tennis for an hour and a half but text or call me if anything happens and I’ll leave immediately and race home

**Jeff Bergosh**: I’ll be checking my phone between every side change

**Sally Bergosh**: He came out of his room the moment your keys locked behind you. He wanted to immediately go to his apartment for shoes & racket so we just said no. Then he was going to buy shoes at Dick’s Sporting Good but they don’t open in time, then he wanted us all to go to breakfast.......I got him & Tori to go on a walk in the neighborhood. Tori helped him put the patch on........all before 8 am

**Jeff Bergosh**: Okay just be calm

**Jeff Bergosh**: On way home

**Sally Bergosh**: Where r u Boxer?!!?

**Sally Bergosh**: Yes

### CONVERSATION ON 10-05-2020

**Jeff Bergosh**: Here is what I sent Dr. Packard this morning, below.  I haven’t heard back.  Can you please send the same, similar request to Dr Sompalli as well?  Love u.  I am on hold with Kasabian’s office now.......


Good Morning Dr. Packard.  First, thanks very much for looking after my son Brandon Bergosh as he struggled last week with a bout of Psychosis.  His mom, sister, and I spent the entire weekend with him at the house and he’s slowly improving.  We’re ensuring he takes his Zyprexa at bed time each day and he’s been getting sleep.  He has adamantly refused to take the tramadol.  I’m going to bring him to his primary care physician today to get a prescription for the albuterol inhaler so that we will have a spare.  It also appears as though one of the challenges he will face is concentration— so if it does not interact badly with the zyprexa  I think maybe getting him his adderal prescription renewed may be helpful.  Please let me know if this will be safe for him— he’s been on it intermittently since middle school for concentration.  Finally, we are helping him get caught up with school but we feel he needs one more week with us closely monitoring him before he should attempt to go back to school in person or to work at his restaurant waiter job.  It would be greatly helpful if we could get a doctor’s note for work and school to excuse Brandon from the 28th Sept-when the onset occurred— to the end of this week.  I’m hoping you or your staff can assist with this and if so I’ll come by and pick up this note.  Without the note—I fear Brandon will be dropped from his classes (last two he needs for graduation from PSC) and I also worry his employer may fire him.  I’m very sorry for the long and rambling text but we desperately need your assistance with these things to help Brandon’s continued road to recovery.  Thank you from the bottom of my heart!

Respectfully,

Jeff Bergosh

**Jeff Bergosh**: Just got this back from Dr. Packard:

“Absolutely regarding the letter. I discussed that with Brandon and the social worker was supposed to have given him a letter at the time of discharge. It was a very busy day on Friday and she may have forgotten. Brandon also left a sweatshirt in my office which I gave to the nurses station. Glad to hear that he is staying the course. I do believe he will need further stabilization, agreeing with your assessment. I will call over to Baptist and make sure that letter is ready for you”

**Sally Bergosh**: Any luck with Kasabian?

**Jeff Bergosh**: Just got this back from Dr. Packard:


Absolutely regarding the letter. I discussed that with Brandon and the social worker was supposed to have given him a letter at the time of discharge. It was a very busy day on Friday and she may have forgotten. Brandon also left a sweatshirt in my office which I gave to the nurses station. Glad to hear that he is staying the course. I do believe he will need further stabilization, agreeing with your assessment. I will call over to Baptist and make sure that letter is ready for you

**Jeff Bergosh**: I’m going to keep trying to get something sooner

**Sally Bergosh**: So do u want me to go get that stuff from Baptist?

**Jeff Bergosh**: Only if you are in that area and can.  Otherwise I will

**Jeff Bergosh**: How did walk go?

**Sally Bergosh**: It went great! 

**Sally Bergosh**: He’s on the phone with my dad- God help us!!😂

**Jeff Bergosh**: Is he doing better do u think?

**Sally Bergosh**: The same with less hyper- he talked about the Corona Virus not being real & how he wants to try out for the basketball team & be president.....Tori heard the whole thing

**Jeff Bergosh**: Okay so we still have some recovery that needs to happen

**Jeff Bergosh**: I’m at the house and we are looking for it and it’s not here

**Sally Bergosh**: Not in the car

**Jeff Bergosh**: Call me

**Sally Bergosh**: Whaaaaat?!? That’s amazing!! Details please!!

**Sally Bergosh**: We are all glad that 2 1/2 hour search is over & solved! ❤️

### CONVERSATION ON 10-06-2020

**Sally Bergosh**: Your voicemail is full

**Sally Bergosh**: Dah

### CONVERSATION ON 10-07-2020

**Sally Bergosh**: Can you please remember my sandbags & to get me email for Donovan Baskins & Lovett & Frank (tennis guy from tennis league)

**Sally Bergosh**: Hey, Sharon. We are so thrilled for Seth & his decision to serve! Can you give us Katelyn's address!? Thanks!❤️

### CONVERSATION ON 10-08-2020

**Jeff Bergosh**: Please tell me the Health and Hope Clinic’s newest intern/volunteer showed up for orientation today 🙏🙏🙏🙏🙏🙏🙏🙏🙏🙏🙏🙏🙏

**Sally Bergosh**: Yes!!

**Sally Bergosh**: He is in orientation with a bunch of cute girls!:)

**Jeff Bergosh**: I am soooooo happy😁😁😁😁😁

**Sally Bergosh**: Me too!

**Sally Bergosh**: Email addresses please!:)

**Sally Bergosh**: I want Mark Faulkner’s email, too!

**Sally Bergosh**: Do you have your lawyer friend’s email or Valentino’s email address?

**Jeff Bergosh**: I’ll look for those

### CONVERSATION ON 10-09-2020

**Jeff Bergosh**: What time for dinner Saturday night at Mcguires six or 630?

**Sally Bergosh**: 6:00 pm dinner!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-11-2020

**Sally Bergosh**: I’m leaving Sara’s house now

**Sally Bergosh**: Too funny!! We love you guys & always have the best time!!

### CONVERSATION ON 10-13-2020

**Sally Bergosh**: This makes me so happy!! I love you, PC!!❤️❤️

**Jeff Bergosh**: Love you most!!

**Jeff Bergosh**: Can u talk?

**Sally Bergosh**: Mario wants to know if we can join him THIS Saturday for a stress relief tourney at 4:00

**Jeff Bergosh**: Sure!

**Sally Bergosh**: I’m at my USTA match started at 7 pm

**Jeff Bergosh**: Okay good luck love u!!

**Sally Bergosh**: Best message ever!! I prayed for all of you too!!

### CONVERSATION ON 10-14-2020

**Jeff Bergosh**: Brandon lost his wallet— any chance he left it at the HEalth and Hope Clinic?

**Sally Bergosh**: I’ll check- I know he had it last night because he ran & got dinner for himself & one of our doctors with my Ccard & I watched him put it in his wallet

**Jeff Bergosh**: Did he give you your card back?? I hope?

**Sally Bergosh**: Yes

**Sally Bergosh**: We have not seen his wallet- tell him to trace his steps

**Jeff Bergosh**: ......he can’t find it

### CONVERSATION ON 10-15-2020

**Jeff Bergosh**: Also the board approved the $14,250 expenditure today as well—- I had to abstain but the board approved it. 👌👌👍👍

**Sally Bergosh**: Who do I love?!!?❤️❤️❤️

**Jeff Bergosh**: Me!!

**Sally Bergosh**: Brandon is volunteering right now at the clinic & then he said he is going to play tennis with Tori tonight

**Jeff Bergosh**: How’s he doing?

**Sally Bergosh**: Great

**Jeff Bergosh**: I ❤️ you—laying down to bed— bible study at 6:00AM.  Love you!!!

**Sally Bergosh**: Love you!! I’m closing the clinic right now.....❤️❤️

**Sally Bergosh**: So well that I had to wake your ass up for your class & make-up test!🙃

**Sally Bergosh**: Then I get this.....

**Sally Bergosh**: I’ve tried calling B this morning on my way to my tennis match this morning & he won’t answer- isn’t his class today in Spanish at 9 am?!?

**Jeff Bergosh**: 9:30

**Jeff Bergosh**: I’m texting him;  he told me he was turning his phone off at 10:00PM

**Sally Bergosh**: I woke him up finally!! Phew!! 🤯

### CONVERSATION ON 10-16-2020

**Sally Bergosh**: Can u please call Baptist back & see if we can just talk to someone for a few minutes?

**Jeff Bergosh**: Yes I will

**Jeff Bergosh**: ?

**Sally Bergosh**: From Terry Aulger:

Silly question do you know the brand of the Murphy bed you used to have or may still have?  

### CONVERSATION ON 10-17-2020

**Sally Bergosh**: Ding dong the tent is dead!!:(

**Sally Bergosh**: Your tent!!

**Jeff Bergosh**: Oh well.... it served us well for 4 yrs

**Sally Bergosh**: I’m going to fill up since the light is on & I’m running on empty

**Jeff Bergosh**: I will do it

### CONVERSATION ON 10-18-2020

**Sally Bergosh**: Loved “Hello friends and family today's the day! It's gorgeous beautiful weather great food and great friends and family gathering at Katelyn's from 4 clock on! Or drop in as you can, Food served at 5:30 or anytime!”

### CONVERSATION ON 10-20-2020

**Jeff Bergosh**: Dinner will be ready at 7:25

**Sally Bergosh**: Yummy!! I’m at the clinic but will see if anyone has keys to lock up tonight

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: Heading to bed-love you and dinners in the fridge.  ❤️

**Sally Bergosh**: 😥

### CONVERSATION ON 10-21-2020

**Sally Bergosh**: Look on Beulah Scoop- the land behind Publix has changed to commercial land? Dewey Barnes says some choice words about you- he lives in Keystone & is such a jerk

**Jeff Bergosh**: He’s a POS Jonathan Owens guy.  Just ignore him.  

**Jeff Bergosh**: I looked and don’t see that post.  Was it on a different site maybe?

**Sally Bergosh**: Cheryl Donaldson Casey posted it yesterday afternoon at 3:30

**Sally Bergosh**: I sent you the email I just sent Cindy about THIS Saturday- none of us can do the morning meeting/donut run this year & you would be at the picnic at noon representing us!

**Jeff Bergosh**: Okay

**Jeff Bergosh**: *on it

**Sally Bergosh**: Tori said she will most likely go with you to the BRF picnic.❤️

**Jeff Bergosh**: 👍

**Jeff Bergosh**: ?

**Sally Bergosh**: I can leave here at 4:30 pm-meet you there at 5 pm

**Sally Bergosh**: We are at Beulah Park tennis courts, Tori if u can join us!

**Sally Bergosh**: On our wY home

### CONVERSATION ON 10-22-2020

**Jeff Bergosh**: I invited Brandon to play tennis with me after work and he said yes initially but then came back and said “No, I’ve got to volunteer at Mom’s Clinic!”   Thought you’d appreciate that ❤️❤️

**Sally Bergosh**: Love!!❤️

**Jeff Bergosh**: Bonnie Smith just came by the house and brought two homemade cherry pies!!  Very thoughtful!

**Sally Bergosh**: One is for Donna Underdonk! I’m in charge- did she leave you a code for her garage?

**Jeff Bergosh**: No— was she supposed to??

**Jeff Bergosh**: Hopefully she can text it to you

**Sally Bergosh**: B seemed really good this morning!:) I’m leaving for tennis match, B is in the shower & as of now plans on staying at the house to get some studying done.

**Jeff Bergosh**: Okay thx for update love u!!!

### CONVERSATION ON 10-23-2020

**Sally Bergosh**: Can u transfer my pay into my account & subtract the $200 I received early?

**Jeff Bergosh**: Sure will

**Jeff Bergosh**: Can I do it at 1:00? In the field right now

**Sally Bergosh**: Sure- no worries

**Jeff Bergosh**: Okay

**Jeff Bergosh**: And I spoke to Rusty Branch.  He’s going to make the ask and he feels confident you will get either a flight in the jet, a flight in Julian’s new Helicopter, and a couple of nights in one of the hotels for your paddle raise.  😎👍.  I should know details by Monday or Tuesday of next week.

**Sally Bergosh**: Oh my goodness - that would be amazing!!:)

**Sally Bergosh**: R u at TRUMP?!?

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 10-24-2020

**Jeff Bergosh**: What time is dinner?

**Sally Bergosh**: 7:30

**Sally Bergosh**: I’ll come home & get u!:)

**Jeff Bergosh**: Okay sounds good!  Love u!

### CONVERSATION ON 10-25-2020

**Jeff Bergosh**: Brandon had to head home to do laundry the game went long. So no one was here so I decided not to make the steaks tonight. Tori I gave her some money and she’s going to Wendy’s to get me one of those pretzel buns burgers so text her or call her what you would like I gave her money and she’ll get one for you too :-)

**Sally Bergosh**: Loved an image

### CONVERSATION ON 10-26-2020

**Sally Bergosh**: Hey, PC- will u please follow up with Rusty today & basker-Donovan?

**Jeff Bergosh**: Will do

**Sally Bergosh**: He is so talented!! I will definitely check it all out!❤️

### CONVERSATION ON 10-27-2020

**Jeff Bergosh**: Our loan for remodeling the kitchen was just funded, so let’s get the ball rolling on getting an estimate😁👍

**Sally Bergosh**: Yes!!

**Sally Bergosh**: What is the update about hurricane 

**Sally Bergosh**: I just got this from one of our pastors:

FYI...  They’ve move the arrival time of Hurricane Zeta.  It will come ashore in New Orleans at 8am Wednesday.  It will be out of our area by 8pm Wednesday.  Thought you would want to know this for planning.

**Jeff Bergosh**: Fdonovanjr@baskervilledonovan.com

**Jeff Bergosh**: Did my favorite volunteer show up to his volunteer shift tonight?  🙂

**Sally Bergosh**: Yes❤️❤️

### CONVERSATION ON 10-28-2020

**Jeff Bergosh**: Got this from Rusty

**Sally Bergosh**: So do I get to come, too?!!?

**Jeff Bergosh**: I have a feeling it’s not just about Health and Hope....Otherwise they would’ve just called you. I think they wanna bend my ear about traffic the bridge the fifth sitting on the bed tax and all these other things as well

**Jeff Bergosh**: Come home boxer and let’s have a hurricane party!!!

**Sally Bergosh**: Oh that looks fantastic or maybe a French 75?! Champagne is in the fridge in bottom bin!!

**Jeff Bergosh**: Come home, it will all be there tomorrow, LOL❤️😎👍

### CONVERSATION ON 10-29-2020

**Jeff Bergosh**: Love you!! Heading to bed goodnight!

**Sally Bergosh**: Love you- licking up right now! I have to open the clinic at 7:30 am tomorrow- so get me up when u are leaving pretty please!:)

**Jeff Bergosh**: Will do!

**Jeff Bergosh**: 👍

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 10-30-2020

**Sally Bergosh**: H didn’t do but I’m on my way!:(

**Jeff Bergosh**: Sorry!

**Sally Bergosh**: ❤️❤️😘

**Jeff Bergosh**: Call me when u have a minute.  ❤️

### CONVERSATION ON 10-31-2020

**Jeff Bergosh**: It’s right there by the Zaxby’s near the Walmart by the fairgrounds it’s in the new strip mall there this is an early voting location for district one Tori and I are going to go and vote and you should head there as soon as you’re done with your mentor student. love you

### CONVERSATION ON 11-02-2020

**Sally Bergosh**: My gaslight just came on.....😂

**Jeff Bergosh**: Okay sorry u may need to stop and get $5 bucks worth

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Do you have time this morning to go online and take care of the FRS liquidation?

**Sally Bergosh**: Tori & I just got back from our 4 mile hike/ walk- I’m going to get on to work real quick & try logging in from my work!:)

**Jeff Bergosh**: Okay thx love u!!

**Jeff Bergosh**: And here is the “back of the bar napkin” rough idea of a before and after master bath.  Your thoughts?

**Sally Bergosh**: I’ve just now looked up for the day from accounting Tuesday & see all these! Can we chat tonight about this? Maybe bring these prototypes home tonight?😂

**Jeff Bergosh**: Ok

**Sally Bergosh**: Loved “Jennifer Brahier was a Professor of mine (fun fact) haha”

**Sally Bergosh**: We didn’t get to vote for City Counsel peeps!:)

**Sally Bergosh**: Holy cow!! Trump is winning in Wisconsin!! Woohoo! :)

**Sally Bergosh**: It’s all coming down to Pennsylvania, Wisconsin, Michigan, & Arizona

### CONVERSATION ON 11-04-2020

**Sally Bergosh**: https://www.zillow.com/homedetails/900-Fort-Pickens-Rd-APT-412-Pensacola-Beach-FL-32561/80762329_zpid/

**Sally Bergosh**: Tennis courts & lots of amenities & lots of living space for future family gatherings!!

**Jeff Bergosh**: $710 month HOA dues though......OUCH!!

**Jeff Bergosh**: Did you go online and get the FRS money yet?

**Sally Bergosh**: Yes step 1: they are mailing me my PIN # which drives the entire transaction!!

**Jeff Bergosh**: Hey I’m exhausted, going to bed early.  I made spaghetti and meat sauce for dinner and Tori and  I already ate.  There is leftovers in the fridge for when you come home.  Love you❤️❤️

### CONVERSATION ON 11-05-2020

**Jeff Bergosh**: .....also, wanted to let you know I transferred your money over a day ahead so you’d be all set for the BMW appointment today, and I’ll deposit your check back into savings tomorrow or Friday to cover it.  Love u!

**Sally Bergosh**: Your mailbox is FULL- tag ur it!!

**Jeff Bergosh**: In BCC meeting can I call u right back?

**Jeff Bergosh**: Okay I listened to your voicemail.  Fred Donovan Jr email:

Fdonovanjr@baskervilledonovan.com

**Sally Bergosh**: Yep- that’s what I had- I’m going to blind copy you so you can follow up tomorrow if you want. I’m up to $67,250!!

**Jeff Bergosh**: Wow!!  You are killing it!!

**Jeff Bergosh**: Hey when u send it, copy FRED SR.  His email is the same just “SR” instead of “JR”

**Sally Bergosh**: Done!!:)

**Jeff Bergosh**: Is my favorite volunteer there tonight?

**Sally Bergosh**: He left a little before me & said he was going to meet Tori to play tennis!🙃

**Jeff Bergosh**: Awesome!

### CONVERSATION ON 11-06-2020

**Jeff Bergosh**: Thought maybe it’s something you could incorporate down the lime in any marketing you do at Health and hope

**Sally Bergosh**: That’s a fantastic idea!!:)

**Sally Bergosh**: Are they local?! We have so many of these centers- make sure the finding is staying in Pensacola

**Sally Bergosh**: *funding

**Jeff Bergosh**: It is

**Jeff Bergosh**: They’re in Gulf Breeze

**Sally Bergosh**: For your information Walmart has butterballs turkeys are .98

**Jeff Bergosh**: Wow!  Maybe I’ll pick a couple up this Saturday!

**Jeff Bergosh**: When I first read it I thought it was $10,000!!

**Sally Bergosh**: I feel very grateful!❤️

### CONVERSATION ON 11-08-2020

**Sally Bergosh**: Wahhhhh


**Sally Bergosh**: 1600 VIA DELUNA DR - Unit # 101B

### CONVERSATION ON 11-10-2020

**Jeff Bergosh**: Hey I tried to call you:  I got home and Brandon’s not here.  Did he show up to help and volunteer tonight??

**Sally Bergosh**: Yes

**Jeff Bergosh**: Okay great!!👍👌🙂

**Jeff Bergosh**: I’m making dinner so I’ll make sure to save you some— a chicken Marsala and rice!!

### CONVERSATION ON 11-12-2020

**Sally Bergosh**: Can u check my balance? I’m at my hair appointment

**Jeff Bergosh**: Will do

**Sally Bergosh**: Thank you!!

**Jeff Bergosh**: $420.51

### CONVERSATION ON 11-13-2020

**Jeff Bergosh**: What’s Dr Mills’ number— can’t read this

**Sally Bergosh**: (850) 221-5511

### CONVERSATION ON 11-16-2020

**Jeff Bergosh**: Wow— I just read that doctor’s newsletter you gave me.  Must be nice to have the problems described in that plus the tax avoidance solutions.  Good problems to have👌😁

**Sally Bergosh**: I love you- ❤️❤️

**Jeff Bergosh**: Love u most!

**Sally Bergosh**: What the heck?!!? You never answer your phone!! Lol- tag- ur it!!

**Sally Bergosh**: Invite them to join us Saturday between 4-4:30, but they need to let us know ASAP so we can get them on the list to play!

**Jeff Bergosh**: Okay I’ll call her

**Jeff Bergosh**: I spoke to Nena and she’s cool.  She understands we can’t make it this weekend. Haine might play in Mario’s Saturday tournament, she will call Mario directly if Haine can play.  Nena is already signed up and committed to play at Roger Scott this weekend

### CONVERSATION ON 11-17-2020

**Sally Bergosh**: I’ve left the house on time!!😘

**Jeff Bergosh**: 👍

**Sally Bergosh**: Thank you for your sweet words, PC! Love you!!❤️❤️

**Jeff Bergosh**: Love you more

**Jeff Bergosh**: You’re a star!!

**Sally Bergosh**: No u are!! Love you, PC!:)

**Jeff Bergosh**: Going to bed, goodnight!  Love you!  I made spaghetti for dinner tonight, leftovers in the fridge.

**Sally Bergosh**: Playing my last match of the season

**Jeff Bergosh**: Good luck!  Win it!

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 11-18-2020

**Jeff Bergosh**: Isn’t this so true, yet so difficult to do

**Sally Bergosh**: I think you need to tell Debbie “Thank you” from her direction on parking to seating- she always has your back behind the scene! That’s invaluable & needs to be acknowledged occasionally. People need to feel respected enough to be thanked!❤️

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: “I'm getting my haircut at eight and will be out of pocket for a couple of hours but I'll be checking emails”

**Sally Bergosh**: Marijuana psychosis

**Jeff Bergosh**: Debbie?  Or who?

**Jeff Bergosh**: ??

**Sally Bergosh**: Brandon

**Sally Bergosh**: I just googled it

**Jeff Bergosh**: Why— was he acting psychotic today?

**Sally Bergosh**: He just said he is “bored” last night & this morning watching that lame show in Netflix “Unicorn”........just worried!!

**Sally Bergosh**: He also shared he HAS smoked pot since his hospital stay- just trying to stay on top of things. 

**Sally Bergosh**: My friend Prebble Baker is having a funeral Sunday at Wahoo stadium for her son, Adam that passed away on November 15

**Jeff Bergosh**: What happened to him?

**Sally Bergosh**: He died- speculation is opioid overdose or suicide......:(

**Jeff Bergosh**: Oh my God that’s horrible.  How old was he?

**Sally Bergosh**: Tori’s age

**Sally Bergosh**: Tragic & so sad

**Sally Bergosh**: This from Debbie Kenney:

We think Kristy, Brian’s wife has sprained her ankle. Can I borrow your crutches

**Sally Bergosh**: Do we still have the crutches?

**Jeff Bergosh**: Yes I have them.  They are in my small closet

**Jeff Bergosh**: I’m making chicken Alfredo and garlic toast for dinner hopefully you can be home to have it —-if not I will save you some love you!!❤️

### CONVERSATION ON 11-19-2020

**Sally Bergosh**: Why is our Amazon password not working? Jeffbergosh@gmail.com
Equinox2013!

**Jeff Bergosh**: I’m not sure let me check it

**Jeff Bergosh**: Try this as password:

21#Gourdach

**Sally Bergosh**: I got paid yesterday- can u transfer funds over EARLY & I will leave u my check for deposit tonight?

**Jeff Bergosh**: Okay will do.  Love!

**Jeff Bergosh**: Done❤️

**Sally Bergosh**: Love u

**Sally Bergosh**: Any luck getting a hold of Marty?!?

**Jeff Bergosh**: I called him and left message

**Jeff Bergosh**: I just talked to Marty everything’s good to go he’s not having hip replacement surgery he’s having a minor procedure he’s got all the equipment he is good to go. Love you❤️❤️

**Sally Bergosh**: Love you!! We need u to tell him the live music is inside so we need him to play music outside from 6 (when it starts) until he starts the live auction at 6:45 pm. K?!?

**Jeff Bergosh**: Love you, heading to bed.

**Sally Bergosh**: Grrrr- just finishing project- heading home

**Sally Bergosh**: That does sound a bit scary as that is what my dentists wear when they are working in our patients’ mouths! Enjoy your family, Cindy! It was a great ceremony outside at Wahoo Stadium. ❤️

### CONVERSATION ON 11-20-2020

**Sally Bergosh**: Can u invite our pastor ❤️

**Jeff Bergosh**: Sure will!

**Sally Bergosh**: I sent Barlow & the old newscaster guy since they have an actual email that gets answered

**Jeff Bergosh**: I sent pastor Jim an invitation and BCC’d you on it so you could see how I phrased it 😁

**Jeff Bergosh**: ......also, I just got off the phone with Marty Stanovich and he’s got the outside music covered — no issues. 👍👌

**Sally Bergosh**: Thank you, Jesus!!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: ?

### CONVERSATION ON 11-23-2020

**Sally Bergosh**: Southern Living Inspired Home

**Sally Bergosh**: https://www.houzz.com/photos/southern-living-inspired-home-beach-style-kitchen-birmingham-phvw-vp~110267484

**Sally Bergosh**: Traditional Soft Contemporary

**Sally Bergosh**: https://www.houzz.com/photos/traditional-soft-contemporary-transitional-kitchen-orange-county-phvw-vp~141976529

**Sally Bergosh**: https://www.houzz.com/photos/white-kitchen-cabinet-ideas-phbr1-bp~t_709~a_17-100

**Jeff Bergosh**: I like the pictures!

**Jeff Bergosh**: I’m finishing your PowerPoint, I’ll send it to you in about 30 Minutes ❤️😎👍

**Sally Bergosh**: You ROCK!!❤️

**Jeff Bergosh**: 😎

**Sally Bergosh**: From Tori:

I just received my email confirmation for interview for ER tech job at West Florida Hospital 💕

**Jeff Bergosh**: That’s good news!

### CONVERSATION ON 11-24-2020

**Sally Bergosh**: Terry Thrash is our team tennis pro & your friend Ed Fleming’s coach. He is amazing & just got surprise married at Rosemary Beach last week. I think we should put in an appearance- drive by at least.

**Jeff Bergosh**: Did you cancel B’s appointment for 4:00 today yet?

**Sally Bergosh**: Yes

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-25-2020

**Sally Bergosh**: I’m so glad your total hip replacement surgery went so well!! Lol!! I have been holding off sending your script for you to learn your lines (haha) but I will send over TODAY!!❤️❤️

### CONVERSATION ON 11-27-2020

**Sally Bergosh**: Hey- our truss is seperated cuz we had too much weight up there!! It will need to be repaired with a new 8 ft. Board & reattached. 

**Jeff Bergosh**: Where is that??

**Jeff Bergosh**: Sally— excel file wasn’t attached.  Just forward me Meghan’s email directly.

Love 

Me

**Jeff Bergosh**: Just let me know

**Sally Bergosh**: That would be fantastic!! 

**Sally Bergosh**: I’m home now.....so frustrated that my printer has been kicked “off line” & Jim doesn’t seem to be able to fix it!!:(

**Sally Bergosh**: I left him at the clinic & he was still trouble-shooting! :(

**Jeff Bergosh**: Okay no problem will do ❤️😎👍

**Sally Bergosh**: Happy Thanksgiving, Marty!! Just making sure you received your script! Do u want me to use your same bio as last year? I emailed the script to you Wednesday. Hope you are doing well with your recovery!:)

**Sally Bergosh**: Why THANK you!!❤️

### CONVERSATION ON 11-28-2020

**Jeff Bergosh**: Don’t worry I’m drinking your cappuccino that you forgot to take with you.... it’s not going to waste😁👌

**Sally Bergosh**: I was just talking about my Capp & leaving it on the maker!!

### CONVERSATION ON 11-29-2020

**Sally Bergosh**: Thank you for choosing USPARK.net. Please present the digital reservation you received to the cashier at the time of entry. 



To receive the discounted rate, also present the digital reservation to the cashier at the time of exit. We are open and our shuttles are operating 24/7.

https://coupons.uspark.net/Coupons/Details/247243

### CONVERSATION ON 11-30-2020

**Sally Bergosh**: This is from Dr. Ham to another physician at H& H.

Ben Clark

**Sally Bergosh**: https://www.evms.edu/media/evms_public/departments/internal_medicine/EVMS_Critical_Care_COVID-19_Protocol.pdf

**Jeff Bergosh**: Wow— this is interesting and very informative!  Thank you for sharing!!

**Sally Bergosh**: Thank you for choosing USPARK.net. Please present the digital reservation you received to the cashier at the time of entry. 



To receive the discounted rate, also present the digital reservation to the cashier at the time of exit. We are open and our shuttles are operating 24/7.

https://coupons.uspark.net/Coupons/Details/247243

**Sally Bergosh**: I received yesterday in text

**Jeff Bergosh**: 👍thx

**Sally Bergosh**: Please call me or text before coming because I think we got everything picked up for tomorrow!:) they still need your help tomorrow at 9 am to help Rob Faberro bring up the doors from the basement to the ballroom

**Sally Bergosh**: I’m on zoom for my first zoom meeting with YMCA board

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: I am at my office right now downtown about to go on a zoom call for OLF8 but I will call you after I leave to make sure you don’t need me to pick up anything

**Sally Bergosh**: Got it!:)

### CONVERSATION ON 12-01-2020

**Jeff Bergosh**: Running a few minutes behind—got held up at work 

**Sally Bergosh**: Me too! Sara is there

**Jeff Bergosh**: Okay I’m here 😎👍

**Jeff Bergosh**: Hey call me when you get this please

### CONVERSATION ON 12-02-2020

**Sally Bergosh**: https://www.zillow.com/homedetails/314-Fort-Pickens-Rd-Pensacola-Beach-FL-32561/80775395_zpid/

**Sally Bergosh**: https://i.pinimg.com/originals/0d/c3/a4/0dc3a45cdb631bed29eac58350d3685f.jpg

**Sally Bergosh**: Cockapoo looks like Rocky as a puppy!! They are so much cuter light brown!!❤️ it’s a cocker spaniel and poodle!

**Jeff Bergosh**: That’s one cute puppy!!

**Jeff Bergosh**: That condo is the same condo Brigette Brooks showed us —-it’s in Susan Bonsignore’s complex

**Sally Bergosh**: That’s my point! Lol

**Jeff Bergosh**: Didn’t we find out there’s still a problem with mold in the roof system there though?

**Sally Bergosh**: Yes! I’m going to chat with Pinky about it!

**Sally Bergosh**: We have been reconciling sheets all day & it looks like we did $73, 450 in sponsorships, $2578 individual tickets, $11,249.75 silent auction, live auction $5775, raffle tickets $1160, $8700 Sponsor a patient, gross=$102,912.75 -5000 (guesstimating expenses)=$97,912.75!!

**Jeff Bergosh**: That’s amazing!!!!!!

**Jeff Bergosh**: Congratulations!!

**Sally Bergosh**: They started very late so u might make it!:)

**Jeff Bergosh**: Still in mtg

**Sally Bergosh**: We are having dinner at Yacht Club- come on!!

**Sally Bergosh**: We are still at Michelle’s reception

**Jeff Bergosh**: On way😎👍

**Sally Bergosh**: Rob eye or Filet?!

**Jeff Bergosh**: Here

**Sally Bergosh**: We are in the rest

### CONVERSATION ON 12-03-2020

**Sally Bergosh**: Danny & cabinet guy want to come over Saturday with a proposal so we can discuss - what time is good for you?

**Jeff Bergosh**: 12:00 Noon

**Sally Bergosh**: Yep!👍

**Sally Bergosh**: I need you to send me out Christmas Visa please!!

**Jeff Bergosh**: Love u!! I’m going to bed exhausted

### CONVERSATION ON 12-07-2020

**Jeff Bergosh**: Got it

**Jeff Bergosh**: Please send Sompalli’s contact info.  I’ll be calling him today

**Jeff Bergosh**: Got it thanks!

**Sally Bergosh**: Loved an image

### CONVERSATION ON 12-08-2020

**Sally Bergosh**: So the wood cabinet guy called today & asked if we have bought our sink & wine fridge yet so he can start making our cabinets? He also said Danny had sent you the link to the “hood” selections he had found that are already painted. We need to pick that out so we can match the paint color........did u take pictures of the dimensions of the wine fridge?

**Jeff Bergosh**: Yes- can you text me his number?

**Jeff Bergosh**: And no Danny didn’t send me the link to the range hood yet

**Sally Bergosh**: Wood cabinet guy

**Sally Bergosh**: https://hoodsly.com/wood-hoods/

**Sally Bergosh**: You can get the exhaust that fits the hoods all here.  If they have what you want it would be best to get it all as one.  That way we know it will all fit together correctly.  You can get it already painted, but I will have to re-paint to match your cabinets

**Sally Bergosh**: Hey, Brandon! I found my notes on your appointment with Dr. Richardson- it’s today at 3:00 pm you call # (850) 908-3217

**Jeff Bergosh**: Okay perfect that’s what we’re doing tomorrow with Dr. Sompalli 👍

### CONVERSATION ON 12-09-2020

**Jeff Bergosh**: OK let’s do this this evening at six let’s make it a date and we will sit down and purchase the hood the beverage fridge and the refrigerator and possibly the sink and a farmhouse faucet as well. Will do it online from the kitchen table

**Sally Bergosh**: Call me

**Jeff Bergosh**: Just tried you back got your voice mail

**Sally Bergosh**: So I just got this from Brandon-

I just got a call & they said it’s at 3:30

**Jeff Bergosh**: Okay good

**Sally Bergosh**: On my way home for our “date”!!

**Sally Bergosh**: ?!!?

### CONVERSATION ON 12-10-2020

**Jeff Bergosh**: Diet Breakfast at my desk before the meeting😁👍

**Sally Bergosh**: Awwww- good boy!! I love you!!❤️❤️

**Jeff Bergosh**: Love u most!

**Jeff Bergosh**: .......the blueberries are delicious!!  An excellent addition to the cereal with Silk

**Sally Bergosh**: I just venmo’d Kelsey $100 for Nicky’s bday! He needed/ wanted new vans tennis shoes!:) She is going to purchase on her way up to see him today!:)

**Jeff Bergosh**: That’s awesome

**Jeff Bergosh**: Love you I’m dozing off.  Come home soon❤️

**Sally Bergosh**: On my way home - we just locked up

### CONVERSATION ON 12-12-2020

**Sally Bergosh**: Loved an image

**Sally Bergosh**: We love you, Bday boy!!

### CONVERSATION ON 12-13-2020

**Sally Bergosh**: Shitheads!! Now we have CeCe Campbell taking shots at your dad on Beulah Scoop!! Your dad called her out! He told her that her comments were such a disappointment since she knows our family! Hell, you helped take care of her mom in her final days!! 💔 

**Sally Bergosh**: Yep

### CONVERSATION ON 12-14-2020

**Jeff Bergosh**: Check out Rick’s Blog!  He AGREES with me that PNJ got this editorial wrong!

**Sally Bergosh**: Post it on Beulah Scoop

**Jeff Bergosh**: I would but they shut that string down for comments

**Jeff Bergosh**: Look Rick is no friend of mine in many respects so the fact that even he recognized that this was a cheap shot says something

**Sally Bergosh**: I totally agree!! Just post his link

**Jeff Bergosh**: Good idea, I will

**Sally Bergosh**: I need you to move chiro $ to my account & please take care of Nicky’s bday pizza!:)

**Sally Bergosh**: I’m thinking my doctor visit won’t be more then $50

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: Spinal epidermal? What was my thing called?

**Jeff Bergosh**: Phlegemon

**Jeff Bergosh**: ......on your spine

**Sally Bergosh**: Epidermal abscess on my spinal chord!! 

**Sally Bergosh**: $60.53

**Jeff Bergosh**: Got it.  How did it go?

**Sally Bergosh**: He sent me over to get X-rays & my real chiro appointment is Wednesday morning

**Jeff Bergosh**: Oh okay.

**Sally Bergosh**: When I talked about past back history, as suspected, he didn’t want to touch me without X-rays first

**Jeff Bergosh**: Understandable.  I just emailed you a rough draft 600 word viewpoint for Health and Hope Clinic.  It’s a starting point but you can revise it as you see fit.  Love I!

**Jeff Bergosh**: *you

**Sally Bergosh**: Thank you- I can’t wait to read after my BOD meeting!!

**Jeff Bergosh**: Good luck with that!

**Jeff Bergosh**: Going to bed.  Love you!  Come home boxer!

**Sally Bergosh**: Just finished typing up the minutes from BOD meeting and am on my way home! Love you- ❤️❤️

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: Don’t forget to send in your head shot with the viewpoint

**Jeff Bergosh**: .....in case they decide to use it

**Sally Bergosh**: That would have been good to know yesterday......hmmmm

**Sally Bergosh**: Will they just ask me for it if they need it or what?

**Jeff Bergosh**: I’d just send it to Lisa— with a “just in case you are considering my viewpoint here is my headshot” one line note

**Sally Bergosh**: Thank you!!

**Sally Bergosh**: Can u ask your bro about doing Seth’s wedding bowels at 6 pm on December 27th?!
Here is from Sharon:

Hey I meant to text you, So sorry to just have called.  I texted Jeff and he is going to think I'm crazy but 2 things. 
1.  I was trying to find a sign for Seth to write welcome home and was wondering if you guys may have one that you put on a fence and I could use the back of it because they are very expensive.
2.  That wants to get married when he comes home can Jeff marry them if you all are going to be here on December 27th

**Jeff Bergosh**: I’ll ask him today

**Sally Bergosh**: *vowels 

**Sally Bergosh**: Vows

**Jeff Bergosh**: LOL autocorrect

**Sally Bergosh**: Grrr

**Jeff Bergosh**: I told Sharon she could have as many yard signs as she wants I threw all the big signs away already told her that

**Sally Bergosh**: Yep- I think that’s why our attic support broke- from all those damn signs!

**Jeff Bergosh**: I don’t think so

**Jeff Bergosh**: 😎👍

**Sally Bergosh**: 😂

**Jeff Bergosh**: It’s been wear and tear for 15 years

**Jeff Bergosh**: But it’s getting fixed now

**Sally Bergosh**: Yes!

**Sally Bergosh**: Sharon wants to come & get some signs TODAY. I gave her B’s contact info but explained he has a doctor appointment at 3:00 pm today so probably you need to advise B where they are in the garage or attic

**Jeff Bergosh**: I’ll drop them off at her house tonight personally when I get home this evening at 6:00.  How many does she want??

**Jeff Bergosh**: How about 7 o’clock dinner this Sunday evening at Mcguires with Gary Carissa Ben & Alex for our gift exchange between families?

**Sally Bergosh**: Perfect

**Jeff Bergosh**: I’ll set it up

**Jeff Bergosh**: By the way I let Sharon know that Gary can do their wedding they just have to get a marriage license before hand

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Will u send me the COVID test site map?

**Jeff Bergosh**: I’ll email the link that has all the testing location sites

**Jeff Bergosh**: Make sure you guys lock your cars each night because we’ve got vehicle thieves in Bell Ridge forest according to Cindy Barrington’s email that I sent you a screenshot of always lock cars all the time

**Sally Bergosh**: B & I will catch them because we are up at night standing guard!! Lol😂

### CONVERSATION ON 12-17-2020

**Jeff Bergosh**: Is it  chantilly lace white?

**Sally Bergosh**: Yes- by Benjamin Moore pair store on I think w street

**Sally Bergosh**: The wood guy knew where to go- call him

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Thx!

**Sally Bergosh**: Don’t forget that cream color on walls

**Jeff Bergosh**: I’m going to try and get it today after work :)

**Sally Bergosh**: Did u find out how much to buy?

**Sally Bergosh**: Make sure u tell them it’s for a kitchen

**Jeff Bergosh**: I just Got off the phone with him and he’s going to purchase it and add it to our bill because he knows exactly what to get and where to get it. We had a great conversation

**Sally Bergosh**: Oh thank you, Jesus!!❤️

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Easy

**Sally Bergosh**: Is it beige or cream?

**Jeff Bergosh**: I’ll check both when I get to Home Depot

### CONVERSATION ON 12-18-2020

**Sally Bergosh**: SD Restaurants arè now opened inside and outside!!!

**Jeff Bergosh**: That’s outstanding news!!!! Where did you hear this??

**Sally Bergosh**: My parents!!❤️

### CONVERSATION ON 12-19-2020

**Jeff Bergosh**: I found them at Target!

**Sally Bergosh**: Get different sizes cuz they are never what they seem & I am always needing them

**Jeff Bergosh**: They had one size, medium.  I bought 3 of them 😎👍

**Sally Bergosh**: Perfect!!:)

### CONVERSATION ON 12-21-2020

**Sally Bergosh**: R union Denver?

### CONVERSATION ON 12-26-2020

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Where is our picture at the top of the mountain?

**Jeff Bergosh**: Line to get into in n out Burger

**Jeff Bergosh**: Line around the bldg to get in

**Sally Bergosh**: Poor baby

### CONVERSATION ON 12-27-2020

**Sally Bergosh**: We want Hagen Dos Magnum bars, no wood sticks!!

### CONVERSATION ON 12-28-2020

**Sally Bergosh**: My dad just snapped at me!!😬

**Jeff Bergosh**: Oh no!  What happened??

**Sally Bergosh**: He was mean & after you said my text was good to send to Charlene & Rachael, he yelled at me as you walked away “did you already send it without asking Jeff first since he bought the steaks?” I said I just had him read it & Jeff said ok.....then he said don’t you yell at me! I said what?! You just yelled at me!! 

**Jeff Bergosh**: Sorry to hear that.  Try to show him a little grace he’s under constant pressure I’m sure.  I’m headed down to get some redbox movies ❤️👍

**Jeff Bergosh**: You all missed a very beautiful view from up here!!

### CONVERSATION ON 12-29-2020

**Sally Bergosh**: Yep- dinner is at 6 or 6:30- Jeff is cooking steaks tonight!:)

### CONVERSATION ON 12-31-2020

**Jeff Bergosh**: 👍

**Sally Bergosh**: Take a picture at Coronado hotel

### CONVERSATION ON 01-04-2021

**Sally Bergosh**: Or you could call Uncle Gary & see if he could give you a ride from the airport! Congrats on the job, Tori!! Is that job at West Florida or Sacred Heart?

**Jeff Bergosh**: D’oh!!

**Sally Bergosh**: Planes have a way of “making up time”!:)

### CONVERSATION ON 01-05-2021

**Sally Bergosh**: Thank you for choosing USPARK.net. We want you to earn free parking! Here’s how:



1. Sign up for your Fast Pass card using the link below.



2. You’ll receive your physical Fast Pass card in the mail within 7 days. Note you must have the physical Fast Pass card with you to redeem your free days.



3. Use your Fast Pass card next time you park with us to earn points towards your free days!



With Fast Pass you'll be earning toward free parking stays with every day you park. 1 free stay up to 7 days for every 35 days of paid parking.



https://www.uspark.net/locations/veterans/signup

**Sally Bergosh**: Yes!! We came home to quite a mess- I’ll explain later! We ran & got some groceries & paper goods to eat out of until the weekend. We are exhausted & going to bed. We both work EARLY in the am! Love you & so thankful u r safe & sound!!❤️

### CONVERSATION ON 01-06-2021

**Sally Bergosh**: https://weartv.com/news/local/gov-desantis-to-hold-press-conference-at-olive-baptist-church-in-pensacola

**Sally Bergosh**: Sacred Heart is giving out 1000 vaccines at Olive on Thursday!!

**Sally Bergosh**: Justin Lobrato

**Sally Bergosh**: *Labrato

**Sally Bergosh**: Bender is at the Olive/ Sacred Heart press conference & Michelle Salzman is chatting away with Ted Traylor!😂

**Jeff Bergosh**: Wow!!

**Sally Bergosh**: Awwww- too precious!!❤️❤️

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: I’m  still at the BCC meeting—- it’s running long

**Sally Bergosh**: Me too!! I just turned in another grant request & completed my data for BOCC!:)

**Jeff Bergosh**: I just left

**Jeff Bergosh**: On way home

**Sally Bergosh**: I’m leaving the clinic in 5 minutes and delivering Kim her paycheck

### CONVERSATION ON 01-08-2021

**Jeff Bergosh**: Sally-  I just paid your Macy’s account.  I paid $160 and next month I’ll pay the same amount and it will be paid off 😎👍

**Sally Bergosh**: Thank you, PC!!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Going in the mail today❤️❤️

**Sally Bergosh**: ❤️❤️❤️

**Jeff Bergosh**: I stopped and got you a treat on the way home

**Sally Bergosh**: You know the way to this girl’s heart!!

**Sally Bergosh**: Sara invited us to The Fish House tonight!

**Jeff Bergosh**: I’m sorry but I’m burned out

**Jeff Bergosh**: Maybe tomorrow?

**Sally Bergosh**: Me too- I already told her no

### CONVERSATION ON 01-11-2021

**Sally Bergosh**: Debbie Degroote just sent:

**Sally Bergosh**: https://youtu.be/pG5yeKCsFYI

**Sally Bergosh**: I have a quick question for you when you get a second

**Jeff Bergosh**: Ok on call with Danny Holman

**Jeff Bergosh**: I’m making dinner on the hot plate LOL

**Sally Bergosh**: Oh my- packing up now & heading home! Love you!!❤️

**Jeff Bergosh**: Love you most.   Do I want me to save you some Mac n cheese?

### CONVERSATION ON 01-12-2021

**Sally Bergosh**: https://issuu.com/greg934/docs/vippensacola_jan21_webmag/1

**Jeff Bergosh**: That’s a nice write-up for the clinic!

**Jeff Bergosh**: ......Our modem came in

**Sally Bergosh**: Yay!! I don’t show that I missed any calls but just got back to my desk & read this text.

**Jeff Bergosh**: I made spaghetti for dinner— leftovers in fridge.  Got the internet back up and running...but I’m exhausted and I’m going to bed... love u!   Come home soon!

**Jeff Bergosh**: ????

**Sally Bergosh**: I’m packing up the clinic right now- has many fires to put out all day!! Ugh!!

**Sally Bergosh**: Loved an image

**Sally Bergosh**: We will definitely do this again!!❤️❤️

### CONVERSATION ON 01-13-2021

**Jeff Bergosh**: I’m in the TPO meeting can I call u back?

**Sally Bergosh**: Of course! I forwarded the electrician’s email- he is going to match the Selectricity’s quote 

**Jeff Bergosh**: That’s awesome news!! Fantastic!

**Sally Bergosh**: WE have a lot to smile about & I feel grateful every day that God picked YOU for me!! Love you & appreciate “us” every single day!!❤️❤️

**Jeff Bergosh**: Ditto!  Just wish u were here with me!!

### CONVERSATION ON 01-14-2021

**Sally Bergosh**: There are two areas on Beulah Scoop where u have been tagged & one is by our Bell Ridge peeps asking for sweep trucks cuz everyone is getting flat tires from the construction on 9 Mile & Bell Ridge & dirt everywhere!! 

**Jeff Bergosh**: I’ll respond

**Jeff Bergosh**: Kim Perdue, Josh’s Mom, is a passive aggressive piece of shit

**Sally Bergosh**: There really is a problem with nails in tires & dirt everywhere!! Kim Perdue can’t help herself- she is a bored & neglected by her husband!😬

**Jeff Bergosh**: Pieces of shit both of them

**Sally Bergosh**: Jeez.....did you see your other tag? Regarding mail & possibly advocating for a new post office out in Beulah!?!

**Jeff Bergosh**: No

**Jeff Bergosh**: Where’s that one??

**Sally Bergosh**: On the Beulah Scoop, about 4 posts down from Kim Perdue’s post

**Jeff Bergosh**: I answered it

**Sally Bergosh**: On my way home!:)

### CONVERSATION ON 01-15-2021

**Jeff Bergosh**: Did the delivery guys show up?

**Sally Bergosh**: Yes- Danny got to meet them and is now setting up- I put the empty filter box on your dresser & Danny said u can get them cheaper on Amazon

**Jeff Bergosh**: Okay cool.  Love u!!

**Jeff Bergosh**: So keep him in your prayers🙏

**Sally Bergosh**: Loved an image

### CONVERSATION ON 01-17-2021

**Sally Bergosh**: I’m hosting a Republican fundraiser for our party.
We will have every representative from here to Jacksonville (minus 2), the incoming speaker of the house, the CFO of Florida, the senator and other state leaders at a very intimate event.  It’s the first time in decades Pensacola has done this. Not sure if it’s outside of your scope, but wanted to make sure you had the opportunity in case it wasn’t

**Sally Bergosh**: We only have a few tickets left

**Sally Bergosh**: All that from Salzman!

**Sally Bergosh**: Want to go?

### CONVERSATION ON 01-18-2021

**Sally Bergosh**: Do we know how the new library will be getting their books? Do they want donations? I have a doctor who wants to donate her library!:)

**Jeff Bergosh**: Wow, not sure but I’ll check

### CONVERSATION ON 01-19-2021

**Jeff Bergosh**: Brad died on Saturday.  He lost his battle with COVID-19.😪😪😪😪

**Sally Bergosh**: Oh noooooooo! I’m so sorry!! Love that guy even though he was dysfunctional he had a big heart!! This makes me so sad. I’m so sorry, Jeff. Do you want to fly out there?

**Jeff Bergosh**: I don’t know, just sad that he couldn’t pull through it.  I’m waiting for an email back... apparently there will be an online memorial coming up on zoom.  So we will definitely participate in that.  In shock right now.  Sadness and shock and I’m in a public meeting as I hear this

**Sally Bergosh**: I’m so sorry😥💔💔

**Sally Bergosh**: I’m so sadddddd.:(

**Jeff Bergosh**: It’s definitely a gut punch

**Jeff Bergosh**: Our stove is working!  I’m making our chicken enchiladas right now!

**Sally Bergosh**: Yay!! This from David Mobley:

Mail just felivered..9 carriers called in sick.

**Jeff Bergosh**: Wow

**Sally Bergosh**: Yep

**Sally Bergosh**: On my way home

**Jeff Bergosh**: 😁👍

### CONVERSATION ON 01-20-2021

**Sally Bergosh**: Great job, PC!! Ask Eric if he thinks Health & Hope will EVER get the vaccines?

**Sally Bergosh**: We were approved by DOH on Dec 30th!

**Sally Bergosh**: I’m sure we are just too small of an entity

**Jeff Bergosh**: I’ll ask him today.  Love u!!

**Sally Bergosh**: Love you right back! 

**Sally Bergosh**: R u going to do anymore vouchers as a county? That was a home run!!

**Jeff Bergosh**: I hope so.  I’ll get some for health and hope clinic if we do

**Sally Bergosh**: Thank you!! People were fighting for them last round!!

**Sally Bergosh**: Can u call me back please?!

**Jeff Bergosh**: Just tried

**Jeff Bergosh**: In mtg will call u after

**Sally Bergosh**: K- my next meeting is at 1 pm

**Sally Bergosh**: Just guesstimating- this is so I can set up our Morgan Stanley account for stocks, etc. I’m filling out the paperwork & they are asking what our liquid net worth is & our total net worth is..... just guesstimating!  Thanks for your help! Our annual income is about $230,000 right?

**Jeff Bergosh**: For us personally???  Why are we giving them our personal information?!?

**Jeff Bergosh**: They don’t need this.  I believe they are looking for the value of the clinic’s assets

**Sally Bergosh**: Just like when we set up our Regions Bank account due to the Patriot Act

**Sally Bergosh**: This is being asked for the BOD chair, treasurer & ED since we are going to be authorized on account

**Jeff Bergosh**: Okay got it

**Sally Bergosh**: So answer the question- what is our liquid net worth & total net worth?

**Sally Bergosh**: https://apple.news/AoWHv6vTyRcOV9PT9VrIyjA

**Sally Bergosh**: https://apple.news/AoWHv6vTyRcOV9PT9VrIyjA

**Sally Bergosh**: Yes- I was vaccinated earlier this month & scheduled for my 2nd vaccination on Feb 4 at 7 pm

### CONVERSATION ON 01-21-2021

**Jeff Bergosh**: I made diner for you, me, Brandon and Tori.  We all ate but I put yours in the microwave.  Love u!!

**Sally Bergosh**: Love u right back!! Crazy night at clinic

### CONVERSATION ON 01-22-2021

**Sally Bergosh**: Can you please look at Beulah Scoop? You need to brain storm a quick solution with this ongoing issue!! You are winning over residence one “Fix” at a time!!

**Jeff Bergosh**: Okay will do.  What is the issue?

**Sally Bergosh**: People are not slowing down on the thin and overcrowded Beulah Road connecting Mobile HWY & 9 Mile......maybe install blinking slow down lights- people are almost getting killed trying to get their mail!!😬

**Jeff Bergosh**: Okay got it

### CONVERSATION ON 01-23-2021

**Sally Bergosh**: Can u bring home a nice bottle of champagne or red wine? Sara’s bday present!!

**Jeff Bergosh**: Will do!

**Sally Bergosh**: R u almost home? Bday lunch is at 12:30 at Yacht Club

**Jeff Bergosh**: No

**Jeff Bergosh**: Just left tailor

**Sally Bergosh**: No worries!:)

### CONVERSATION ON 01-25-2021

**Sally Bergosh**:  Nurses meeting just ended- see u in a few!:)

### CONVERSATION ON 01-26-2021

**Jeff Bergosh**: Doug is getting savaged by the comments on the PNJ Facebook site.  Ouch!

**Sally Bergosh**: Yikes! 😬

**Jeff Bergosh**: It’s like a UFC ground and pound beat down 

**Sally Bergosh**: Stay above the fray

**Jeff Bergosh**: I am— this has nothing to do with me

**Sally Bergosh**: Good

**Jeff Bergosh**: 👍😎

**Sally Bergosh**: On my way home- lots of clinic fires & Kim showed up tonight!!😂

**Jeff Bergosh**: Right on!  Dinner in fridge love u!

**Sally Bergosh**: Too cold for our Florida/ San Diego boy!! ❤️❤️

**Sally Bergosh**: Are you needing another job or is this something u r lining up in advance proactively?

**Sally Bergosh**: Gotcha!! Although experience is experience! I got a lot of mileage off of my internship with San Diego Magazine.....even though it was unpaid

### CONVERSATION ON 01-27-2021

**Sally Bergosh**: Hey- can u check to make sure I have $$ for my hair appointment at 5:30 pm?!

**Sally Bergosh**: ?!!? 911 - can u check on my account?

**Jeff Bergosh**: Okay I’m on the jail tour

**Jeff Bergosh**: No reception

**Sally Bergosh**: Oh wow......well I have an hour and a half in the chair starting now so can u check when u r done & let me know?!?

**Sally Bergosh**: Of course!! ❤️

**Jeff Bergosh**: Ok u only had $83 so I transferred over another $100.  You now have $183.

Love u!

**Sally Bergosh**: Stupid United Way came out yesterday! Did my refund come through?

**Jeff Bergosh**: Didn’t see it

**Sally Bergosh**: Oh my goodness!! So, so proud of you!!❤️❤️

**Sally Bergosh**: Nope- we are going to get u go take that nurse test & get u in the RN PSC program- Seriously!! 

### CONVERSATION ON 01-29-2021

**Jeff Bergosh**: An hour and a half for delivery!?!  Good thing I put in the order the minute I got home LOL

### CONVERSATION ON 01-30-2021

**Sally Bergosh**: Love you!! We need coffee creamer, Skinny cows & wheat thins crackers pretty please! 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-02-2021

**Sally Bergosh**: Danny is super loving this chandelier that I picked out!!😂

**Sally Bergosh**: 72 pieces involved!!

**Jeff Bergosh**: Oh my!!!

**Jeff Bergosh**: Don’t ask

**Sally Bergosh**: Can u make Kim & I a reservation at the IPC McGuires for 1:00 pm today?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Meeting

**Sally Bergosh**: I am going to send you the review I prepared for Kim- after your meeting will u look at it?

**Jeff Bergosh**: Of course

**Sally Bergosh**: Thank you! Just got your message!:)

**Jeff Bergosh**: I read your evaluation I have a few thoughts if you wanna call me we can discuss at your convenience love you

**Sally Bergosh**: She is in my office so I am going to call in a few minutes! 

**Jeff Bergosh**: Love you I’m falling asleep.  

**Sally Bergosh**: I’m getting a lot done so will leave by 9:30😂

### CONVERSATION ON 02-03-2021

**Sally Bergosh**: Any more senior vaccine vouchers at the county?

**Sally Bergosh**: Can u ask Lumon’s May?

**Jeff Bergosh**: I’ll check

**Sally Bergosh**: That’s frickin ridiculous!!

**Jeff Bergosh**: Better late than never!

**Jeff Bergosh**: This is one of the guys running against Doug Underhill.... I’m not sold on the top banner slogan though.....Seems like a Freudian “Double Entendre” LOL. 😂😂😂

**Sally Bergosh**: Lumon May is going to run for mayor!!

**Jeff Bergosh**: That’s not Lumon

**Sally Bergosh**: Connie Bookman know him very well & her & Grover both talked about that rumor.....does he have to give up his seat to run?!

**Jeff Bergosh**: Yes he would have to resign to run but the resignation wouldn’t be until the day of the seat being filled, November of 2022.  I don’t see him doing it

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: I just sent u a list of the 41 applicants for the Escambia children’s trust.  Interesting names on the list

**Sally Bergosh**: Look what I’m still doing tonight all by myself in the clinic......the good news is that I was able to hop out earlier & get my 2nd vaccination!!:)

**Jeff Bergosh**: I just pulled up at the house. Long meeting!  I have pizza left over in the fridge.  Come home— love u!!

**Sally Bergosh**: Love u right back!!❤️

**Jeff Bergosh**: Going to bed love u!

### CONVERSATION ON 02-05-2021

**Sally Bergosh**: I think u should submit David Peaden, II & Tori Woods!! 

**Jeff Bergosh**: Peaden would be good

**Jeff Bergosh**: And I’ll reimburse you.  It says it’s like $79 per
Person

**Sally Bergosh**: So they DID have a package & I just booked with a hotel room including the show & fancy dinner for $400 TOTAL. Let’s split it & ENJOY!! We need a little TLC self-care & we can even bring our bikes for the next day!!❤️❤️

**Sally Bergosh**: We don’t pay until we get there & our confirmation #71600882

**Sally Bergosh**: Woohoo!!

**Jeff Bergosh**: 👍 right on!

**Jeff Bergosh**: TLC

**Sally Bergosh**: https://www.usatoday.com/story/news/health/2021/01/29/covid-19-tylenol-advil-vaccine-coronavirus-cdc-who/4290975001/?fbclid=IwAR11yI92BUwhiQU27utol2x2P2lYaahiLmwtIpgpcjuHkzrgwCfYdvJz5y0

**Jeff Bergosh**: On the other line I’ll call u back

**Sally Bergosh**: Can you pick up some pedialite for mom or Gatorade on your way home. She’s not feeling well 

**Jeff Bergosh**: I will

**Jeff Bergosh**: Who is this?

**Sally Bergosh**: Tori

**Sally Bergosh**: I feel like I’m dying

### CONVERSATION ON 02-08-2021

**Sally Bergosh**: Are any of these that special tooth brush u wanted?

**Sally Bergosh**: Sara’s pantry!  The draws slide out so u can see what you’ve got!!

**Jeff Bergosh**: Yes— lower left hand corner in orange box

**Jeff Bergosh**: Nice

**Sally Bergosh**: ?!!?

**Sally Bergosh**: Oh the toothbrush! I thought u were talking about Sara’s pantry

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Going to bed— love you

**Sally Bergosh**: Still at clinicHeading home now!

### CONVERSATION ON 02-09-2021

**Sally Bergosh**: Send me Linda Moultry’s #

**Sally Bergosh**: I just tried googling glass bar tops glass bar shelves.......I couldn’t find a single example in top building designs that had that & they all still had back lighting. 

**Sally Bergosh**: https://www.google.com/imgres?imgurl=https://thismakesthat.com/wp-content/uploads/2020/05/Barn-Door-With-Glass.jpg&imgrefurl=https://thismakesthat.com/pantry-door-ideas/&docid=O4QpdRSg0sHVkM&tbnid=QT_yGHIayGAIXM&vet=1&w=520&h=900&itg=1&hl=en-us&source=sh/x/im

**Sally Bergosh**: Something like this for our pantry door- love the handles but it silver to match existing handles 

**Jeff Bergosh**: Where do we get something like this, though?

**Sally Bergosh**: Gary Crowley could whip this out at the end & we could pay him $300

**Jeff Bergosh**: Okay that’s fine with me 😎👍

**Sally Bergosh**: Car message this morning on my way to clinic- basically says my car is going to explode - they won’t be able to look at it until after lunch.......why is it so hard to get service at BMW? I asked if I could get a rental car & she said I could walk to Hertz Rental.....REALLY?!!?

**Jeff Bergosh**: That’s shitty

**Jeff Bergosh**: Do u want me to call Sandy?

**Sally Bergosh**: I think my astonishment made her also add or she could get me a ride to my work.....!!

**Jeff Bergosh**: That’s bs

**Jeff Bergosh**: We spend lots with them

**Sally Bergosh**: I’m waiting for my ride.....grrrr

**Jeff Bergosh**: Let me know if u need me to get u

**Sally Bergosh**: I need to get a hold of u!!!!

**Sally Bergosh**: I’ve tried calling 3 x’s in a row!!

**Jeff Bergosh**: I’m here

### CONVERSATION ON 02-10-2021

**Sally Bergosh**: Great job this morning & u left me wanting to know more from the guest speaker!! ❤️

**Jeff Bergosh**: Wasn’t that interesting??

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love u most!!

**Jeff Bergosh**: Oh my God look at ricks blog it’s all coming together now

**Jeff Bergosh**: Wow!

**Sally Bergosh**: Pull out shelves for pantry

### CONVERSATION ON 02-11-2021

**Sally Bergosh**: Do I have a BS or MS?

**Jeff Bergosh**: BS

**Jeff Bergosh**: ❤️😎

**Sally Bergosh**: 😂

**Jeff Bergosh**: Like in Bullshit!  LOL

**Sally Bergosh**: I have 5 volunteers out to tonight- and I wonder why I can’t sleep at night!!😂

**Jeff Bergosh**: LOL sorry about that.  I’ll have a cold beer in your honor........ been one hell of a day

**Sally Bergosh**: Bad press?

**Jeff Bergosh**: No— good press.  Just a long, contentious meeting again with DPZ

**Jeff Bergosh**: I love you——- going to bed exhausted.  Can’t wait for the weekend!   Love u!!!❤️❤️❤️😎😎😎

**Sally Bergosh**: Love you right back!! So glad u will be our new newsletter editor! You ROCK!!

### CONVERSATION ON 02-12-2021

**Jeff Bergosh**: I’m on it.  Just send me the information and the last couple of editions so I know what to look for

**Sally Bergosh**: Beulah Scoop has a very compelling picture from my sweet friend, Marilyn Clifton. At the very least, we need to mow the sides of Rebel Rd & cut back brush so some kid doesn’t lose their life!!

**Jeff Bergosh**: I know

**Sally Bergosh**: The shoulder of the road needs to be mowed down minimum!!

### CONVERSATION ON 02-13-2021

**Jeff Bergosh**: Second dose in my arm!

**Sally Bergosh**: Yayyyy!! Save that picture & get a picture of the other side!:)

### CONVERSATION ON 02-15-2021

**Sally Bergosh**: So Constant Contacts is where Kim has been creating our newsletter. Constant contacts.com, kjohnson@healthandhopeclinic.org, password-HHClivewell!

**Jeff Bergosh**: Okay got it.  Can we switch the email to my email?

**Sally Bergosh**: Of course! Just login & switch or add! 

**Sally Bergosh**: She said she gets graphics from unsplash.com or Ann app on her cell called wordswag, then she saves as a picture & then emails to herself to add to constant contacts!:)

**Jeff Bergosh**: 👍

**Sally Bergosh**: Do u want me to stop for healthy dinner at Panera- soups?

**Jeff Bergosh**: I think we have plenty of food here—- but if you do stop I’d love a bown of their Mac n cheese LOL😎👍

**Jeff Bergosh**: If you’re going to stop I’ll ask Brandon what he’d like, too.

**Sally Bergosh**: Sure

**Jeff Bergosh**: He wants Mac and cheese too

**Sally Bergosh**: Did he die??!?

**Sally Bergosh**: Oh man!! 😥

**Sally Bergosh**: Here is your “to do” list!!


### CONVERSATION ON 02-17-2021

**Jeff Bergosh**: Which do you prefer?  For the edging.  Standard column choices are included in our price



**Sally Bergosh**: As long as it’s thick I’m good!!

**Jeff Bergosh**: 👍

**Sally Bergosh**: I’m still at work- what is the TATIS Deal?

### CONVERSATION ON 02-18-2021

**Jeff Bergosh**: R u okay?  I’m in mtg rn

### CONVERSATION ON 02-20-2021

**Sally Bergosh**: When u get done recovering from tennis- I just got my Ccard statement & I was charged $488.58 by Grand Marriott Point Clear - no worries on my end as long as we were not double charged. This was put on the Ccard they took from me to make the reservations over the phone prior to our weekend stay

**Jeff Bergosh**: I thought something was weird and they Only charged me for the beverages and food and tips. So I had assumed there was a larger charge coming. So I will transfer that amount over to your checking account so you can make an immediate payment.

**Jeff Bergosh**: And it’s beautiful here

**Sally Bergosh**: Yay!! Love you!!❤️

**Jeff Bergosh**: Love u most

**Sally Bergosh**: What do you think of this home?

**Sally Bergosh**: https://www.zillow.com/homedetails/7844-Gulf-Blvd-APT-C-Navarre-FL-32566/2088123080_zpid/?utm_source=email

### CONVERSATION ON 02-22-2021

**Sally Bergosh**: I just paid $350 to Marshals visa account. Are dishes in dishwasher clean?

**Jeff Bergosh**: No not run yet

**Jeff Bergosh**: Is the $350 the account grand hotel charged on?

**Sally Bergosh**: Yes

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Can u do a 6:30 closing this evening?

**Sally Bergosh**: Yes

**Jeff Bergosh**: Okay- at the house, or where?

**Jeff Bergosh**: I’ll set it up at the house.  Just remember to be at the house by 6:30.  Love u!

**Sally Bergosh**: Yes- that’s fine

**Jeff Bergosh**: Got it, it’s set

**Jeff Bergosh**: R u on way??

### CONVERSATION ON 02-23-2021

**Sally Bergosh**: Bathroom designers offer 10 budget-saving tips for layouts, materials, fixtures and more

**Sally Bergosh**: https://www.houzz.com/magazine/how-to-control-the-cost-of-your-bathroom-remodel-stsetivw-vs~122570529

**Jeff Bergosh**: I’ll read it!! 👍😎

**Sally Bergosh**: What is the ceo at West Florida Hospital’s name?

**Jeff Bergosh**: Gay Nord

**Jeff Bergosh**: Got the appointment set up between Brandon and Dr. Hirschhorn this Thursday at 1:00

**Sally Bergosh**: I just made our reservations with the Faberros for Saturday night at 6:15 pm

**Jeff Bergosh**: Okay where?

**Sally Bergosh**: U should have received a text from The District?!

**Jeff Bergosh**: Nope— didn’t get it

**Sally Bergosh**: That’s strange!!

**Jeff Bergosh**: I love you— I’m fading quick, about to go to bed.  I made dinner and there is plenty left over in the fridge.  Goodnight!❤️

**Sally Bergosh**: I just got done cleaning the kitchen & putting the food away- the price I pay with college premed student volunteers!! Ugh!

### CONVERSATION ON 02-24-2021

**Sally Bergosh**: https://click.mail.zillow.com/f/a/-RAhE-c5iHR7KTw_PORzeg~~/AAAAAQA~/RgRiGLEIP0UmZW1vLWluZmVycmVkc2VhcmNoLXJlY3MtZm9yc2FsZWFkZHJlc3MEVwZ6aWxsb3dCCmA1CCw2YGdkogVSIHNiZXJnb3NoQGhlYWx0aGFuZGhvcGVjbGluaWMub3JnWAQAAAAA?target=https%3A%2F%2Fwww.zillow.com%2Frouting%2Femail%2Fproperty-notifications%2Fzpid_target%2F80758142_zpid%2FX1-SSca88woqq0piz0000000000_aau3y_sse%2F%25252Fhomes%25252Ffor_sale%25252F42657_rid%25252F2-_beds%25252F256000-976000_price%25252FX1-SSca88woqq0piz0000000000_aau3y_sse%25252F_surl%2F%3Fz%26utm_source%3Demail%26utm_medium%3Demail%26utm_campaign%3Demo-inferredsearch-recs%26rtoken%3D36ec0517-f96d-47c3-9cd8-2c246fbc5597~X1-ZUtlhegfckru2x_35s1y%26utm_term%3Durn%3Amsg%3A20210224103446f450b2cae29b843e%26utm_content%3D20210224-forsaleaddress-PSS

**Sally Bergosh**: This has tennis courts, pool & the price is right!!

**Sally Bergosh**: Sausalito

**Sally Bergosh**: https://www.houzz.com/photos/sausalito-transitional-san-francisco-phvw-vp~167920596

**Sally Bergosh**: Every glass shower door I see is the soft door that opens

### CONVERSATION ON 02-25-2021

**Jeff Bergosh**: Sally I just found out that we are having a clinic tomorrow morning at Pine Summit Baptist Church in Bellevue. I will get the phone number for the individual who is coordinating but if you have a list of Frontline healthcare workers including Susan Jason who would like a shot get that compiled together and I will forward it to my contact at community Health.

**Sally Bergosh**: I believe he has that last since last week - please confirm he has Susan Jason on his list! Let’s get Tori on that list, too! If I have more names after today’s meeting- can u tell me who to call?

**Jeff Bergosh**: I will.  Getting all the details this morning.

**Sally Bergosh**: Sometimes you can be right & yet still wrong!! As your PR Director, this will look like white privilege & petty.....when u KNOW any day now Gary & Carissa will get on the “compromises health list & get the vaccine. In the meantime 

**Sally Bergosh**: Let Gary & Carissa step up & be the face of their injustices of the world! Not your battle & not a smart play when there are so many peeps everyday risking their lives to help people that have forfeited their “right” in order to let someone else get vaccinated

**Jeff Bergosh**: Carissa got here already

**Jeff Bergosh**: Reservations must be made by calling 850-439-3358

**Sally Bergosh**: Thank you!

**Jeff Bergosh**: 
In order for Susan to be eligible she must demonstrate that she comes into direct contact with patients in the course of her job

**Jeff Bergosh**: I just spoke to community Health Northwest MAR surprisingly short on people wanting to come get shots so if you want to put the word out through your channels that will help!

**Sally Bergosh**: Tori works 7 am- 7 pm tomorrow but has TODAY off! Any ideas for her?!

**Jeff Bergosh**: She needs to rearrange her schedule or take a lunch break or whatever the case might be to go get the shot

**Jeff Bergosh**: Hell she shouldn’t even have to take a break this is something that helps West Florida Hospital

**Sally Bergosh**: Call her

**Jeff Bergosh**: Slammed

**Jeff Bergosh**: Headed to bed— getting up at 4:30 for Bible Study.  Love you!!!!!

Me

**Sally Bergosh**: Love u right back!!:)

### CONVERSATION ON 02-26-2021

**Sally Bergosh**: https://apple.news/AtoldxifOTlWYOgVwPnV_Sw

**Jeff Bergosh**: Did you just send me a WiFi ad from a Facebook message?  If not, I just got one from you and you’ve probably been hacked

**Sally Bergosh**: Yes I sent! We have had so many issues with our WiFi & a friend over behind Beulah school said it has really helped her family!!

**Jeff Bergosh**: Okay good thx

**Jeff Bergosh**: SALLY call me when you get a minute I want to tell you about the electric bill love you bye

### CONVERSATION ON 02-27-2021

**Sally Bergosh**: This is what I want for our front door!!

### CONVERSATION ON 03-01-2021

**Sally Bergosh**: Shouldn’t I have heard something by now about getting my application in to the county?

**Jeff Bergosh**: No— there will be a new application this year.  It is on the agenda this Thursday for the board’s approval.  The applications will be due back to the county from the community providers by April 2nd

**Jeff Bergosh**: https://escambiacofl.civicclerk.com/Web/UserControls/pdf/web/DocPDFWrapper.aspx?ad=2136

### CONVERSATION ON 03-02-2021

**Sally Bergosh**: It’s an island!!


**Jeff Bergosh**: Wow!!!!!!

**Jeff Bergosh**: Remember— nothing hot on there— it will scorch so NO Hot pans on the surfaces. Everything has to be on a hot pad or it will damage the Quartz. Also no bleach-based cleaning products no bleach no harsh chemicals I will purchase special cleaning solution design for Quartz.  In the meantime warm water and a clean cloth and mild dish soap only for cleaning it

**Sally Bergosh**: Mix with spray bottle of D-Natured alcohol!!

**Jeff Bergosh**: Is that what they recommended? Yes 

**Sally Bergosh**: Yes

**Jeff Bergosh**: 👌👍

**Sally Bergosh**: 24-25 inch bar stools- 4 max

**Jeff Bergosh**: Okay let’s start looking 🙂

**Jeff Bergosh**: Falling asleep, I have to go to bed.  Love you!  Kitchen looks awesome!!

**Sally Bergosh**: Yes! I showed it to our accountant today & she asked me if I would design hers!😂

**Jeff Bergosh**: LOL that’s awesome 

**Sally Bergosh**: Loved “Came out looking good!! ”

### CONVERSATION ON 03-03-2021

**Sally Bergosh**: So I received this yesterday-

Congratulations! Your Loan XXXXX77239 has been Funded!

**Jeff Bergosh**: Me too.  It has been😎👍

**Sally Bergosh**: https://parmls.paragonrels.com/CollabCenter/BRIGETTEBROOKS/

**Sally Bergosh**: I have been waiting for Tristan Towers to pop up from Brigette- should I ask for a tour?

**Sally Bergosh**: https://parmls.paragonrels.com/CollabCenter/BRIGETTEBROOKS/

**Sally Bergosh**: Oceanside!!

**Sally Bergosh**: https://parmls.paragonrels.com/CollabCenter/BRIGETTEBROOKS/

**Sally Bergosh**: Can u try & bring home more notebooks please? Egg steeler!!😜

**Jeff Bergosh**: LOL will do

### CONVERSATION ON 03-05-2021

**Jeff Bergosh**: ....this way I can drop u off and pick u up

**Sally Bergosh**: Awwww- that’s so sweet! Starts at 5, ends whenever. Let me know what time you could meet me at the house. I have to play tennis tomorrow so I don’t want it to be a late night. I think our hostess in the same boat which is why she is starting an hour later then “normal”.

**Sally Bergosh**: Thank you for being thoughtful- I love you!! ❤️

**Jeff Bergosh**: Love u too!!

**Jeff Bergosh**: Pick u up at 8:30/9:00?

**Sally Bergosh**: 8?

**Sally Bergosh**: Whenever is fine

**Sally Bergosh**: Thank you

**Jeff Bergosh**: Okay we will leave it flexible but plan on 8:00-9:00 whenever u want.  Love u

**Sally Bergosh**: Love you right back!❤️

**Sally Bergosh**: Hillary Smith is engaged!!❤️

**Jeff Bergosh**: Congrats to her!

**Sally Bergosh**: I’m supposed to bring crackers & cheese or something.....?!?

**Jeff Bergosh**: Tonight?

**Jeff Bergosh**: I’d just suggest that you pick up a deli tray from Wal mart on the way home——they have one for $18 that has two kinds of meats, three cheeses, and crackers.  It’s by Hormel and it’s in the deli section by where they have the BRIE cheese

**Sally Bergosh**: Yes

**Jeff Bergosh**: I’m here 😎👍

**Jeff Bergosh**: Okay I’m heading that way

**Jeff Bergosh**: It’s on my list of things to do

**Sally Bergosh**: I think since Gary has his little brother fighting on his behalf for the vaccine for judges, maybe he could hook us up with a will!❤️👍

### CONVERSATION ON 03-06-2021

**Sally Bergosh**: What r u watching? Come watch a movie with us!!

**Jeff Bergosh**: UFC 

**Sally Bergosh**: Lame!!

### CONVERSATION ON 03-08-2021

**Jeff Bergosh**: Saw your story with Sage the pharmacist was featured tonight on ABC news channel threes 6 o’clock broadcast! Angels in our midst! It was really good to

**Jeff Bergosh**: Too*

**Sally Bergosh**: This was from your older brother tonight-Yes, hard to believe he’s getting bigger and older. Scary. I’d like to see you and Jeff. We are pretty much always free.  Just let me know when and where😀. 

### CONVERSATION ON 03-09-2021

**Sally Bergosh**: Do I need to interact with these Ensec people that just pulled up at our house?

**Jeff Bergosh**: No they are just there to provide a quote for fertilizing the grass and killing the weeds.

**Jeff Bergosh**: I’m going to compare their price to Tru green’s and go with the better option

**Sally Bergosh**: Turns out Ensec is a big supporter of us- this guy said u came to his house in Shadow Grove (2) elections ago with Kevin Adams. He voted for you & Ensec sponsors the H & H clinic every year!!

**Sally Bergosh**: His name is Andy May- super cool guy!

**Jeff Bergosh**: Should I give him the business?

**Sally Bergosh**: How is anything going to help w/ out sprinkler system?

**Jeff Bergosh**: That guy comes this afternoon to give us a quote to fix

**Sally Bergosh**: 🤞

**Sally Bergosh**: Frency Moore’s mom was killed last night by a drunk driver coming home from OB from dinner with friends- they go to Olive Church where I will be Friday from 4 pm- 8:30 pm 💔😥

**Jeff Bergosh**: Oh my gosh that is horrible!!  I’m so sorry to hear that.  I’ll keep her and Jared in my prayers

**Jeff Bergosh**: I’m exhausted, long day and I have coffee w commissioner tomorrow, so I’m headed to bed.  Come home soon!  Love u!!

**Sally Bergosh**: Day from hell- I never looked up.....I’m leaving soon

**Jeff Bergosh**: Sorry!  

**Sally Bergosh**: Love you!!❤️

**Jeff Bergosh**: Love u most!

### CONVERSATION ON 03-11-2021

**Sally Bergosh**: Gary & I never talked- it was all through texting & here was my last text to him:

We want to take you out for your bday dinner!! I’ll get with Jeff & throw out a few potential dates!:)

**Jeff Bergosh**: Got it.  I’ll get a good date/time 

**Jeff Bergosh**: I’m looking at airfare tickets to Seattle for our cruise— will u be coming?  Also, will u be flying from up there or down here with us?

**Sally Bergosh**: Loved an image

**Jeff Bergosh**: June 30-July 10th

**Sally Bergosh**: I think it would be cheaper to fly directly to Seattle from Wisconsin, but selfishly I wish u could come home first & visit!:)❤️❤️❤️

**Sally Bergosh**: Huey Luis was Matthew’s favorite band

**Sally Bergosh**: Loved “I sent him a picture of the album ”

### CONVERSATION ON 03-13-2021

**Sally Bergosh**: Please pick up wedding card

**Jeff Bergosh**: Okay I will

**Sally Bergosh**: Peg said to give to you!!

### CONVERSATION ON 03-15-2021

**Jeff Bergosh**: This is the info on the clinic.  They are open from 7:00AM-5:00PM today.  Call them and set an appointment to check your back

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: That’s the grand total, I just balanced the spreadsheet

**Sally Bergosh**: That’s about what we thought- if anything, I thought we had hit $60k

**Sally Bergosh**: So $62k with totally new flooring

**Jeff Bergosh**: Yep, about that.  

**Sally Bergosh**: Hey, I’m at BMW & I think it’s going to be around $400?!? Warranty is expired which is such good timing for them when I was here last month....🤔

**Jeff Bergosh**: Okay no problem I’ll transfer the money.  However, I was under the impression the warranty was 5 years??  Are you sure the warranty expired?? Or, is this just the cost of service visit?

**Sally Bergosh**: I need u to call these peeps- they only like men here!!!!!!!

**Jeff Bergosh**: Okay, please step out and call me first so I know what’s going on

**Jeff Bergosh**: Meanwhile, I just transferred $400 to your checking account.  You now have $1,674.24 in there 🙂

**Sally Bergosh**: Did you pay Macy’s bill? It’s due today. Do u want me to make payment?

**Sally Bergosh**: $102 is the balance

**Jeff Bergosh**: I paid it off

**Jeff Bergosh**: Two weeks ago

**Sally Bergosh**: Ginny Stevens my accountant wants to know if u know Alain Espinosa that works for the county that is trying to “take charge” at the soccer fields & clean house?!?

**Jeff Bergosh**: Yes I know him

**Jeff Bergosh**: Is she a fan or no?

**Sally Bergosh**: He sounds like a real dick- Napolisn complex!!

**Sally Bergosh**: *Napolian

**Jeff Bergosh**: That is surprising 

**Jeff Bergosh**: But some people react differently when they have a little bit of power

**Sally Bergosh**: I’ve made the decision to hold off on the new tires until I’ve had a chance to chat with you about that- but here is what they just now came out to me in the waiting room to discuss- I approved doing the first (4) items.

After inspecting your vehicle, Sandy Sansing BMW recommends additional services be completed.

To review the inspection and approve the recommendations, click: https://c.xtime.com/mO8tNfi6FgEA2AnsXX 


Reply STOP to unsubscribe.
Mar 16, 2021 7:55:39 AM PST

**Jeff Bergosh**: Okay so $505, yes?

**Sally Bergosh**: Yes- the light at 9 mile & Pine Forest is our- just FYI

**Sally Bergosh**: $547.60

**Jeff Bergosh**: Okay I’ll put the difference in your checking when I get back to my office

**Jeff Bergosh**: This amt. does not surprise me— 1st service visit

**Sally Bergosh**: Did you see the price went down by $10k since you first asked about it, from $429k to $419k?

**Jeff Bergosh**: No, I didn’t

**Sally Bergosh**: The Tristan Towers beach condo

**Jeff Bergosh**: Oh.  Okay.  That’s a good sign!

**Sally Bergosh**: From cousin Sally:

Hey girl! Not sure where I left off but mom and I are on our way to Pensacola and didn’t know what you socialites 😂had planned for either Wednesday or Thursday evening but mom and I thought we would drive out to your house for maybe even just 30 minutes or an hour to throw our arms around y’all’s necks. Let me know if that works!
We will be staying at my dads so I’ll give Gary a buzz in a little bit. They are easier to drop in on obviously being a mile away LOL

**Jeff Bergosh**: Okay.  Tomorrow night?

**Sally Bergosh**: ......what do u think? Wednesday evening have them come by for drinks & appetizers?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Love u❤️❤️going to bed exhausted.  I made dinner it is I. The fridge!

### CONVERSATION ON 03-17-2021

**Sally Bergosh**: From Brigette:
I received the requested disclosures and rental income data and will forward. The seller is a commercial pilot and those were winter renters who preparing to move. 

**Jeff Bergosh**: Also— this login information is not working, are u sure it is correct?

**Sally Bergosh**: News@healthandhopeclinic.org, password is the same-HHCLivewell!

**Jeff Bergosh**: Okay thx

**Jeff Bergosh**: Are Sally and Mary coming over for wine and appetizers tonight?

**Sally Bergosh**: No, thank you- this is Sara’s first day back & we are going over everything

**Sally Bergosh**: Yes- they are coming to the house at 6 pm. I’ll take care of food!

**Jeff Bergosh**: Okay perfect.  I’ll get there ahead of time and get it looking clean and nice!

**Sally Bergosh**: Perfect!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I’m picking up ingredients for a charcuterie board and also some white wine and crackers😎👍

**Sally Bergosh**: Yay!! French bread

**Jeff Bergosh**: On way home

**Jeff Bergosh**: Got us covered

**Sally Bergosh**: Ideas for newsletter

**Jeff Bergosh**: Thanks.  I just emailed you an SALLY an initial analysis I performed I went on the high side but I need to know if what I have projected is in the realm of reality and also if we can utilize second home financing and then subsequently rent out the property which we would need to do for at least the next 3 1/2 years?

**Sally Bergosh**: I got your email & think we are waiting on Brigette

**Jeff Bergosh**: I talked to her.  She had good news 

**Jeff Bergosh**: Call me when u can so we can discuss

**Sally Bergosh**: Will do

### CONVERSATION ON 03-18-2021

**Jeff Bergosh**: Can you make it to McGuires at 4:30-4:45 ish if I can get there too?

**Jeff Bergosh**: Now I know why everyone’s late 🙁🙁😕😕

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Praying for Alex!!🙏❤️

**Jeff Bergosh**: Yes me too.  Wreck #2...............

**Jeff Bergosh**: Hopefully the other party is as well 😫😫😫

**Sally Bergosh**: ❤️❤️❤️

**Jeff Bergosh**: It was a traffic mishap, not an accident. He misjudged the clearance he had while backing up and got stuck with one axle off of a sidewalk.   No injuries and no damage to his vehicle thankfully 👍.   It was a nice dinner and I’m glad I went— just wish you could have joined us but I know you had clinic tonight.  I’m exhausted, headed to bed.  Love u!!❤️❤️

**Sally Bergosh**: Love you right back & am so glad you got to spend time with your family- sorry to have had to miss it. I’m heading home after getting a huge chunk of the BOCC grant completed tonight- it’s due April 2!! Love you!

**Sally Bergosh**: B- your teeth cleaning appointment is made for next Thursday, 11 am!! So start scrubbing those teeth! Love you!!❤️❤️

**Sally Bergosh**: I haven’t had your teeth cleaned since 2019!! Take the appointment!!

**Sally Bergosh**: See if he can do later that day

**Jeff Bergosh**: 850-476-5233 is the dental office number.   Just call them and move it to a date that works in your schedule Brandon

**Sally Bergosh**: Thank you for coming by last night- always a great time!!❤️

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Send me a picture of your bullet points for the newsletter 👍

### CONVERSATION ON 03-20-2021

**Sally Bergosh**: We are going to lunch.....we need sparkling waters, English muffins, French bread, Easter crap to start stock piling, & licorice.......do I have $ in my account?

**Jeff Bergosh**: Yes u have $

**Sally Bergosh**: https://apps.apple.com/us/app/design-home-house-renovation/id1010962391

**Jeff Bergosh**: Hi Brigette! SALLY and I talked and we are interested in putting an offer in for the unit at Tristan Towers 2C.  Let me know if we should make a full offering price bid or should we attempt to lower it and offer less? We will trust your judgment on that one. But I will have a $1000 check for a good faith deposit if you will write up the contract. Of course it will be subject to our inspection, Subject to our obtaining of appropriate financing, subject to a clear title and of course subject to all the other protections in the standard contract. Just let me know when we can get together and sign it :-)

**Sally Bergosh**: Loved “Hi Brigette! SALLY and I talked and we are interested in putting an offer in for the unit at Tristan Towers 2C.  Let me know if we should make a full offering price bid or should we attempt to lower it and offer less? We will trust your judgment on that one. But I will have a $1000 check for a good faith deposit if you will write up the contract. Of course it will be subject to our inspection, Subject to our obtaining of appropriate financing, subject to a clear title and of course subject to all the other protections in the standard contract. Just let me know when we can get together and sign it :-)”

**Sally Bergosh**: Thanks, Brigette! We love the idea of them contributing to closing costs. Let’s have you write-up an offer! Closing will be contingent on financing after contract is accepted.

**Sally Bergosh**: Jeffrey Bergosh & Sally Bergosh

### CONVERSATION ON 03-22-2021

**Jeff Bergosh**: Call me when u can talk about the condo

**Jeff Bergosh**: Sally — everyone’s trying to reach u—- pick up your phone

**Sally Bergosh**: Done!!

**Jeff Bergosh**: 👍👌😎❤️

**Sally Bergosh**: Did u get my paycheck copies- Ginny needs to know if that works?!

**Sally Bergosh**: Jeff answer your phone- everyone is trying to get a hold of u!!❤️

**Jeff Bergosh**: LOL

**Jeff Bergosh**: 👍

**Sally Bergosh**: For newsletter- can u make sure we welcome the following new providers?

Mary Ann Wooten APRN, Charles Thompson MD, Carrie Boyd, APRN, Kara Hyman, APRN, & Kelsey Dutton, APRN

**Jeff Bergosh**: Sure will

**Jeff Bergosh**: I just emailed you the bill.  And the accompanying email from our attorney.  What a total bunch of bullshit.  I’m sick.......

**Sally Bergosh**: I just asked Michelle Salzman about it......

**Jeff Bergosh**: Thank you

**Jeff Bergosh**: I love you I’m going to bed I’m exhausted come home soon boxer and drive safe —-love you

**Sally Bergosh**: Love you right back!!❤️❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: Loved “We’re waiting on their counter offer to come back, but I believe they will!”

**Sally Bergosh**: What is the financing interest rate?

### CONVERSATION ON 03-23-2021

**Jeff Bergosh**: Can you text me a list of your encouragers?

**Sally Bergosh**: Gary Humrichouser
James Hughes
Jim & Rose Book
Kooky McLaughlin
Eric Sheaffer
Debby Booker


**Jeff Bergosh**: Got it!  Sent you first draft.  Let me know what you think?  😎👍

**Jeff Bergosh**: Okay I’m going to bed.  Love u!  ❤️❤️

**Sally Bergosh**: Love u right back!!

### CONVERSATION ON 03-24-2021

**Sally Bergosh**: Brandon- the soonest appointment they had at Dr. Callahan’s Office is Tuesday, April 20 at 11:20 am or Tuesday, April 27 at 8 am. I booked BOTH- one for you & one for me- I’ll let u pick which one you want!!

**Sally Bergosh**: Loved “The home inspector, Jack Needham, is scheduled for this Sunday, 3/28 at 9am. He said if you can plan to arrive around 9:45am. He’ll be well underway and while not finished can answer questions. I’m trying to arrange rooftop access for him to check the HVAC compressor. This may be the only thing outstanding in the inspection if there’s no one to unlock the access for this on a weekend but waiting on an answer from the condo association.”

### CONVERSATION ON 03-25-2021

**Sally Bergosh**: From someone on the Beulah Scoop:

Who do you contact for issues at the Beulah park?  There is something wrong at the bathroom, there is standing water behind the building that smells like sewage. And does anyone know if it gets cleaned? Last time I went in there it was out of soap and paper towels 🤢 and looked like people just dropped tp and trash on the ground.  The porta potties that were there were cleaner than these bathrooms.

**Jeff Bergosh**: I’ll get on this thanks for heads up!

**Sally Bergosh**: Love u!!❤️

**Jeff Bergosh**: Love u most

**Jeff Bergosh**: In meeting will call u back

**Sally Bergosh**: No problem- I left u a message- can u send out the newsletter today?

**Jeff Bergosh**: Yes I will

**Jeff Bergosh**: Just sent it out 😎❤️

**Sally Bergosh**: Thank you- taking it off my list!!:)

**Jeff Bergosh**: It should be in your inbox already,  just came to mine 

**Sally Bergosh**: When do u want everyone’s stuff by for the next newsletter? I have to get stuff from 9 different departments!!:(

**Jeff Bergosh**: You tell me when u want it to go out.  If you can just collect it for me and put it in a file on your desktop then get it to me all at once by say, April 30th, that would be great!  And we can send the next newsletter out in early May 🙂

**Sally Bergosh**: Perfect!!

**Jeff Bergosh**: Going to bed—-love u!!!

### CONVERSATION ON 03-26-2021

**Sally Bergosh**: Do I have a BA or a BS

**Sally Bergosh**: Did u deposit my check? 

**Jeff Bergosh**: BA and yes it’s in your acct. ❤️😎👍

**Jeff Bergosh**: Hey I thought you were coming home early tonight??

**Sally Bergosh**: In my way!!

### CONVERSATION ON 03-27-2021

**Sally Bergosh**: I’m at the dealership waiting on my car/ tires to be done!

**Jeff Bergosh**: Okay what is the eta?

**Sally Bergosh**: Technically- it’s been in the shop since 8:15 am, but my appointment was 9:00......when I got dropped off, they said it should be done SOON.

**Sally Bergosh**: $1188

**Sally Bergosh**: Am I okay?

**Jeff Bergosh**: Yes

**Sally Bergosh**: On my way home now!! She said I had 40,000 miles so new tires in 2 years is not bad

**Jeff Bergosh**: On my way to Wal Mart.  Text me anything I need to put on the list 

**Jeff Bergosh**: ❤️👍

**Sally Bergosh**: B needs deodorant,Tori needs salads, aloe water, fresh watermelon. I need licorice, skinny cow pretzel caramel bars & champagne (chancon)

**Jeff Bergosh**: 👍

**Sally Bergosh**: We are out of this Dove soap for shower

**Jeff Bergosh**:  Ok

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 03-30-2021

**Sally Bergosh**: Tori literally just ran out of her room (hair not brushed) & raced out of the house!! WTF is going on?!!?

**Jeff Bergosh**: I have no idea.  Is she late for work??

**Jeff Bergosh**: Looks like she was wearing light blue scrubs when she left.....so maybe she got called in?

**Sally Bergosh**: https://apple.news/Ak0S0zYS7Qvmy5W6nOaCuzA

**Jeff Bergosh**: Yeah I heard.  Should I run for his seat?

**Jeff Bergosh**: “Congressman and Mrs. Jeff Bergosh......”

**Sally Bergosh**: Yes

**Sally Bergosh**: Some peeps are texting me about this! Lol!😂

**Jeff Bergosh**: LOL. I’m in!!!😎👍

**Sally Bergosh**: Isn’t it a huge pay cut?

**Jeff Bergosh**: .....uh,  me along with:  Frank White, Doug Broxson, Jayer Williamson, Grover Robinson, Chris Dosev, Nathan Boyles, Greg Merk, And probably four or five more LOL

**Sally Bergosh**: Lol!!

**Jeff Bergosh**: But no definitely not a pay cut. A pay increase Congressman make $203,000 per year

**Jeff Bergosh**: So should I jump in and do it :-)

**Sally Bergosh**: Oh yes-:)

**Jeff Bergosh**: Okay damnit— I’m in!!!

**Jeff Bergosh**: LOL

**Sally Bergosh**: Your mailbox is full & im trying to call you! I need your edits tonight from my grant pretty please

### CONVERSATION ON 03-31-2021

**Sally Bergosh**: Is this Nicky’s current address?! Easter is Sunday!!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Seller denied our addendum- we now have a decision to make.  Check your email

**Sally Bergosh**: I kind of agree & said so the other night about the seller putting in $5000 towards closing costs & up to $1000 in repairs plus home warranty for the first year

**Sally Bergosh**: He has shown good faith

**Jeff Bergosh**: So u want to move forward still?

**Sally Bergosh**: Yes

**Jeff Bergosh**: Okay let’s tell Brigette

**Jeff Bergosh**: ........because there are still open questions about the amount of potential assessments that have not been answered

**Sally Bergosh**: Sure

**Jeff Bergosh**: 👍

**Sally Bergosh**: Can u scan over to me the edits for BOCC? I am supposed to play at USTA match tonight at 6 pm......we will see with the pending rain!

**Jeff Bergosh**: I sent them first thing this morning at 0700

**Jeff Bergosh**: I’ll re-forward 

**Sally Bergosh**: To the clinic?!

**Sally Bergosh**: I already reserved IPC for Saturday night at 6 pm for your bday dinner

**Jeff Bergosh**: Both clinic and yahoo

**Jeff Bergosh**: For our Bday celebrations??  How thoughtful ❤️❤️👍👍

**Sally Bergosh**: I found it!!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: So we’ll see what happens.............

**Sally Bergosh**: This is outstanding news......remember, sometimes Michelle exaggerates so let’s not totally “buy in” right now.....grr

**Jeff Bergosh**: I’ll believe it when I see it— but this is a positive step in the right direction

**Jeff Bergosh**: “John Davy says you’re match is going to be a wash out”. LOL

**Sally Bergosh**: I rushed to get there & it was just cancelled until Saturday

**Jeff Bergosh**: Sorry 

**Sally Bergosh**: Yes, Moderna is what we all received

### CONVERSATION ON 04-01-2021

**Jeff Bergosh**: Headed to bed.  Love u!!❤️❤️

**Sally Bergosh**: Love you right back!! 

### CONVERSATION ON 04-02-2021

**Sally Bergosh**: Good morning, PC! Happy Birthday!! I think the light on 9 Mile going East toward interstate might be out of sinc from workers yesterday......Beulah Scoop will tell u all about it!!:(

**Jeff Bergosh**: Okay I’ll have it checked

**Sally Bergosh**: Thanks, Mayor Jeff!! ❤️

**Jeff Bergosh**: Loved “Thanks, Mayor Jeff!! ❤️”

**Sally Bergosh**: What do you think of this home?

**Sally Bergosh**: https://www.zillow.com/homedetails/900-Fort-Pickens-Rd-APT-914-Pensacola-Beach-FL-32561/80757916_zpid/?utm_source=email

**Sally Bergosh**: This is a comparable listing that I told you about last week. Tristan towers is so much better!!

**Jeff Bergosh**: I agree

**Sally Bergosh**: And less $$

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Going in the mail today 😎👍

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: What time will u be home, Bday Boy?! I’m near Mellowmushroom- do u want me to run in & get dinner?

**Sally Bergosh**: Or would u rather go out to dinner?!?

**Jeff Bergosh**: You don’t have to do that—but thank u!! We’re going out tomorrow night for dinner right?

**Sally Bergosh**: I ordered u a sausage/ pepp calzone!!

**Jeff Bergosh**: Thank you!!

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Loved “Agree. So Jeff Donald and I think you should run for mayor!!!   I always told you that you would be our mayor one day!!!”

### CONVERSATION ON 04-05-2021

**Jeff Bergosh**: Sally-  give me a call when u have a moment it’s about the condo

**Jeff Bergosh**: I made dinner for us and Brandon and I are watching the national championship basketball game.  Come home and watch with us! 😎👍❤️

**Sally Bergosh**: Awwww- okay just finished agenda for tomorrow’s lunch & learn for volunteers! Will leave in 10 minutes

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: Alright I’m fading fast.  Food is in the fridge — love u❤️❤️

**Sally Bergosh**: Ugh!! I’m getting so much done & have this presentation due to United Way next week!!

### CONVERSATION ON 04-06-2021

**Jeff Bergosh**: Sally our loan processor needs you to fill out electronically and sign a document please open your email and sign that document her name is Roberta and she sent it a couple hours ago thanks love you

**Sally Bergosh**: Got it!!

**Sally Bergosh**: Done!:)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Guess what came in today’s mail for Tori?

**Sally Bergosh**: Finally!!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Heading to bed, exhausted.  Love u!!

### CONVERSATION ON 04-07-2021

**Sally Bergosh**: I want you to check that thing that shows when I got home last night! Literally 7 minutes!!

**Jeff Bergosh**: I went to bed at 9:30 and was out like a light— thought u had late night clinic

**Sally Bergosh**: I literally set the alarm at 9:21 pm last night! I have a tennis makeup match from that rain out last week tonight at 6 pm- I’m playing with Tonya Chase at RS

**Jeff Bergosh**: Okay maybe I’ll come and root for you all ❤️❤️👍👍

**Sally Bergosh**: Yaaaay!! I would really love that!!❤️❤️

**Jeff Bergosh**: 😎❤️👍

**Sally Bergosh**: Yes, JP Whibbs through Gary. 

**Sally Bergosh**: I think that is reasonable

**Sally Bergosh**: Liked “Thanks, Sally. I agree. It assures you of getting the full repair credit to which the seller has committed and you get to select the HVAC provider of your choice for service so you’re satisfied with the work. ”

### CONVERSATION ON 04-08-2021

**Sally Bergosh**: This is the 2nd text I’ve received- do you think it’s spam or about our pantry door?!?

USPS: the arranged delivery  for the shipment 1z81030 got changed. Please confirm here: w7fzc.info/fU6LLMiAaG

**Jeff Bergosh**: Yes it is

### CONVERSATION ON 04-09-2021

**Jeff Bergosh**: Please send me Sarah and John Davy’s address so I can send the thank yous 

**Sally Bergosh**: 5527 Oakmont Drive, Pace, FL 32571

**Sally Bergosh**: Send one to your brother, too!

**Sally Bergosh**: We need to lead by example with G & C. I have on good authority that they don’t do Thank You notes

**Jeff Bergosh**: ❤️👍😎

**Sally Bergosh**: Send one to Gary & Carissa, too!! Thank them for our bday dinners!:)

**Jeff Bergosh**: Ran out of stamps

**Sally Bergosh**: I’ll bring home some stamps- write the card, please!!

**Jeff Bergosh**: Okay will do.   Making dinner for us ❤️❤️

**Sally Bergosh**: On my way home!

**Sally Bergosh**: Liked “Happy Friday Jeff and Sally, If you are in agreement with the $1000 in lieu of repairs, please sign and date the addendum. However, if you have any questions or concerns regarding it, please feel free to give me a call and we can discuss.”

**Sally Bergosh**: Loved “Damn , be still my beating 💓 ”

**Sally Bergosh**: Laughed at “Damn , be still my beating 💓 ”

### CONVERSATION ON 04-10-2021

**Jeff Bergosh**: They carry it at Walmart but it’s sold out according to the guy they can’t keep it in stock

### CONVERSATION ON 04-12-2021

**Sally Bergosh**: Beulah Rd & 9 Mile light is not working correctly- sits for 11 minutes so peeps are just running it!!

**Jeff Bergosh**: Okay I’ll forward to staff

**Jeff Bergosh**: Is it on Beulah scoop?

**Sally Bergosh**: Yep!’

**Sally Bergosh**: They tagged you!!

**Jeff Bergosh**: Just called it in

**Sally Bergosh**: Liked “Just called it in”

**Jeff Bergosh**: Love u, just finishing American Idol and I’m fading fast!  Heading to bed—Love you !!  ❤️❤️

**Sally Bergosh**: Love you- finishing FAFCC grant reporting due on Thursday!! 😥

### CONVERSATION ON 04-13-2021

**Sally Bergosh**: https://apple.news/A-_ExvgzxTkOkFuZ42jq5OA

**Jeff Bergosh**: Getting ready to hit the sack-- big day tomorrow.  Love u!!❤️❤️

### CONVERSATION ON 04-14-2021

**Sally Bergosh**: Yes!! They just had to take out the SIM card & reset

**Sally Bergosh**: Phew!!

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: Good luck in your presentation!

**Sally Bergosh**: Awwww- love you BIG!!:)❤️

**Jeff Bergosh**: ❤️👍

**Sally Bergosh**: Anna was probably taking a call & didn’t change the slides fast enough so we didn’t get to finish- they called time. No notice- nothing!! Grrrr Overall it went well! 

**Jeff Bergosh**: Congrats!

### CONVERSATION ON 04-15-2021

**Sally Bergosh**: Doug Snider just sent me a message saying he thinks he saw u on your bike yesterday at NAS! I told him it probably was u & that next time he needs to give you a holler!❤️❤️ (Sam’s dad that spent Easter with us 1 year- friend of Nicky’s)

**Jeff Bergosh**: LOL small world!

**Sally Bergosh**: Loved a movie

**Sally Bergosh**: Tracy Chapman”Fast Car”!!

**Sally Bergosh**: Yaaaaay!! Love!!❤️❤️

### CONVERSATION ON 04-16-2021

**Sally Bergosh**: https://www.thrivetimeshow.com/april-conference/

**Sally Bergosh**: Go to www.Rhema.tv and live stream it
This conference is going on right now in Oklahoma. You need to watch or listen to it. It is soooo good!!!! Lots of awesome speakers too. Lin Wood, Michael Flynn, Sydney Powell

**Sally Bergosh**: https://www.thrivetimeshow.com/april-conference-itinerary/

**Sally Bergosh**: Here is the itinerary for today and tomorrow in case you wanted to see who was all talking
I’m listening as I’m driving!! I’m going to be watching this conference all day tomorrow as well.

**Sally Bergosh**: All of this is from Debbie DeGroote

**Sally Bergosh**: Sorry, I can't talk right now.

**Sally Bergosh**: Come home!!!!!!❤️❤️

**Sally Bergosh**: We have the place to ourselves tonight!!

**Sally Bergosh**: 😘😘

### CONVERSATION ON 04-18-2021

**Jeff Bergosh**: Sally I just checked with Publix and Brandon’s medicines are ready for pick up any way that you can grab them on the way home from the office? They are only open until six at 9 Mile Rd. though let me know if you can’t then I will go Brandon is stuck at work still

**Sally Bergosh**: B can pick up tomorrow- I was 45 minutes late & knee deep in audit!!

**Jeff Bergosh**: No worries I’m on way to get it

**Jeff Bergosh**: Dinner ready when u r❤️😎

**Sally Bergosh**: On way home

### CONVERSATION ON 04-19-2021

**Jeff Bergosh**: We’ve almost made it all the way through day one I’m getting ready for bed and I haven’t had a thing to eat all day hopefully you had a good day and I hope that you come home soon love you!❤️❤️

**Sally Bergosh**: We just finished nurse meeting. Carol was rushed to ER tonight cuz she can’t keep anything down & starting almost fainting during our nurse meeting tonight

**Jeff Bergosh**: Oh no, I hope she’s alright!

### CONVERSATION ON 04-20-2021

**Sally Bergosh**: Carol was admitted at WFH & they are waiting for the surgeon....more to follow. Oh my goodness.....

**Jeff Bergosh**: I’ll keep her in my prayers🙏🙏

### CONVERSATION ON 04-21-2021

**Jeff Bergosh**: *time sensitive

### CONVERSATION ON 04-22-2021

**Sally Bergosh**: I have a hair appointment at 5:30 pm. I left u my check. Can u make sure and move over funds? Also- did u sign that new document from Jennifer Mogdaham’s closing lady?

**Jeff Bergosh**: Not yet it has to be amended to cover new purchase price so she will be sending over a new statement.  I didn’t get your check but no biggie I’ll move money over just please put the check on the table where I normally sit and I’ll take it to the bank this afternoon when I get home ❤️

**Sally Bergosh**: I did put the check where u normally sit last night before I went to bed.

**Jeff Bergosh**: Oops I didn’t look.  No worries I’ll grab it today

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Was B’s car here when u left this morning?

**Jeff Bergosh**: No

**Jeff Bergosh**: In mtg bcc

**Sally Bergosh**: We need to sit B down tonight & discuss his future- he started telling me last night that now he’s not sure he wants to go to college.......we know a degree opens doors & equates to higher salary!! WTF?! He said he has a 2 year & that’s good enough! Ugh! I trained the most popular girl from his high school Isabel (who is still dating Justin Schubeck & she said they have wonderful (1) bedroom apartments down the street from UWF & she would love to be B’s tour guide & get him excited about school!

**Sally Bergosh**: She just started at the clinic today!

**Jeff Bergosh**: Dinner is served!👍👍❤️❤️

**Sally Bergosh**: On my way!!

**Jeff Bergosh**: Awesome!  BTW I had a talk with Brandon

**Jeff Bergosh**: It was a really good positive conversation

**Sally Bergosh**: K

**Jeff Bergosh**: Started out real mellow and that’s what made it positive 

**Sally Bergosh**: Did u chat about his casual stay out all night gig?

### CONVERSATION ON 04-23-2021

**Jeff Bergosh**: Met this golden doodle on my lunchtime walk today ❤️❤️👍👍

**Sally Bergosh**: Omg!! It’s time, Jeff!! We need another SMALL Goldendoodle or Cockapoo!!❤️❤️❤️

**Sally Bergosh**: I always ask about what kennel they got their dog from-

**Jeff Bergosh**: It was a female and she was super spastic that’s why I couldn’t get a good picture with her but she was cute reminded me of Rocky —-brought a smile to my face

### CONVERSATION ON 04-26-2021

**Jeff Bergosh**: Danny is at front door

**Sally Bergosh**: I am at work

**Jeff Bergosh**: No one answering phone to open door

**Jeff Bergosh**: Brandon opened door

**Sally Bergosh**: Liked “Brandon opened door”

**Jeff Bergosh**: Look what came in today’s mail!

**Sally Bergosh**: Wowza!! That was FAST!!

**Jeff Bergosh**: Yep.  I just put it in the safe.  So him, you, and I are all good.  Nick and Tori are handling their own

**Sally Bergosh**: Did Tori & Nicholas confirm they have their passports & they are up to date? 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Getting ready for bed—love u!!

**Sally Bergosh**: That really is great news!! I just ate an apple- I was starving!! 🙃

**Jeff Bergosh**: Well it could be worse it could’ve been a snickers bar or a ice cream sundae LOL

**Jeff Bergosh**: Tomorrow’s a juice day

**Sally Bergosh**: Yes!!

### CONVERSATION ON 04-27-2021

**Sally Bergosh**: Want to be my date for this event on  May 3rd? I want to support new girl so I still get invited to Blues Brunch with Blue Angels!!

**Jeff Bergosh**: Sure it’s the same day I am meeting with Corey out at the condo at 1 o’clock

**Sally Bergosh**: K- I’m in meeting- I’ll call u back!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Sally I’m getting ready for bed.  Love you, see you when you get home ❤️❤️

**Sally Bergosh**: Nice!!

### CONVERSATION ON 04-28-2021

**Sally Bergosh**: During finals!!😂

### CONVERSATION ON 04-29-2021

**Sally Bergosh**: Did u ever send me the choices for transition with our floors?

**Jeff Bergosh**: Love you Sally— home now and headed to bed.  See you when you get here— bible study 6:00 AM tomorrow...

**Sally Bergosh**: B- are u at work?!

### CONVERSATION ON 04-30-2021

**Sally Bergosh**: When u are done with Bible study, please call me

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: Advise B to turn the tv off & go to bed!!

**Jeff Bergosh**: Will do

**Sally Bergosh**: Yes

**Jeff Bergosh**: That requires time whereas this one above matched the wood and is in stock

**Sally Bergosh**: K!

### CONVERSATION ON 05-01-2021

**Sally Bergosh**: Fantastic!! We are on our Uber ride to Dickie Brendan’s restaurant!! Google it! The only thing better- if you were here!!

**Jeff Bergosh**: We just finished dinner— now we’re at a rooftop bar called the “Monkey Board”

**Sally Bergosh**: Loved “We just finished dinner— now we’re at a rooftop bar called the “Monkey Board””

### CONVERSATION ON 05-02-2021

**Sally Bergosh**: So we are at our fab tea in lobby & they are playing all my show tunes including Annie!! They are holding our luggage at front desk & comping our parking while we are at our tea!! Happy Birthday Tori!!🎈❤️

**Jeff Bergosh**: Perfect me and Brandon found a breakfast restaurant around the corner and we’re gonna have breakfast

### CONVERSATION ON 05-03-2021

**Sally Bergosh**: 👍

**Jeff Bergosh**: I got a call from our long-lost window guy he’s coming to put the five windows in this Wednesday!!

😎😎❤️❤️👍👍

**Sally Bergosh**: Yay!!

**Jeff Bergosh**: Thought you’d be happy about that😁😁

**Sally Bergosh**: Totally!!

**Jeff Bergosh**: Alright I’m getting ready for bed, I’ll see you when you get here.  Love you!!

**Sally Bergosh**: Love this picture!! So much fun!!

### CONVERSATION ON 05-04-2021

**Sally Bergosh**: Love you, Jeffrey Wayne!! Try to remember today that you have a family that adores you! I, for one, enjoyed last night!❤️

**Jeff Bergosh**: Love u most, and I enjoyed last night the most!  

**Jeff Bergosh**: Sally we have been invited to this party— do you want to attend?

**Sally Bergosh**: Yes- we have early dinner with Susan & Bruce at The Yacht Club- we can go afterwards!! Where is it?

**Jeff Bergosh**: Vinyl

**Sally Bergosh**: Yay!! That will be fun!!

**Jeff Bergosh**: What time is dinner?

**Sally Bergosh**: 5 or 5:30 dinner

**Jeff Bergosh**: Ok I will RSVP for us 😎

**Sally Bergosh**: RSVP for (4)!!

**Jeff Bergosh**: No— that would be poor form

**Sally Bergosh**: Gary & Carissa?

**Jeff Bergosh**: Folks who get the invites have to RSVP

**Sally Bergosh**: You’re so right!

**Jeff Bergosh**: Otherwise we’re low class Vince Vaughn party crashes

**Sally Bergosh**: 😂

**Jeff Bergosh**: *crashers

**Jeff Bergosh**: But it will be awkward telling Bruce and Susan we have to leave dinner early to get to our next party—— without elaborating or offering an invitation...........🤨🤨🤨🤨🤨🤨

**Sally Bergosh**: It’s at Vinyl, which implies large gathering! RSVP for (4)!

**Jeff Bergosh**: Not going to be that guy

**Sally Bergosh**: Tori made a reservation for 6:30 at The District- I told her to change to 6 pm! Remember- I’m splitting this bill with you!:)

**Jeff Bergosh**: I’m busted — it will go on my capital one card.

**Jeff Bergosh**: Wait— I thought u budgeted for this?? LOL

**Sally Bergosh**: I’ll give u $ to pay it off quick- I get paid this Friday

**Jeff Bergosh**: That money is spent

**Jeff Bergosh**: We’ll work it out

**Sally Bergosh**: Nope- I paid cards last check so all I have is jewelry Bill- & that’s not due till the end of the month

**Jeff Bergosh**: 😐

### CONVERSATION ON 05-05-2021

**Jeff Bergosh**: Now I’m booking Nick’s flight

**Sally Bergosh**: Oh that’s fantastic news!! I’ve been kinda worried

**Jeff Bergosh**: Great price!!

**Jeff Bergosh**: Got Nicholas’ ticket booked as well!!

**Sally Bergosh**: Show me the entire flight for Nicky

**Sally Bergosh**: How much?

**Sally Bergosh**: When does he arrive in Seattle on July 1?

**Jeff Bergosh**: Interesting and kind of cool that we will all be in Denver for a layover at the same time 😁 we can have dinner or snacks together in Denver before we depart for Seattle

**Sally Bergosh**: The only thing left is booking the hotel- I vote close to the cruise boat loading area

**Sally Bergosh**: Holiday inn type place since we are literally just crashing

**Jeff Bergosh**: Yep

**Jeff Bergosh**: I’ll get it done

**Sally Bergosh**: No window peeps yet. I have to leave at 8:40 am

**Jeff Bergosh**: They just called and cancelled 😫

**Jeff Bergosh**: Will try to re schedule Monday

**Sally Bergosh**: Told you!!

**Jeff Bergosh**: It’s BS

**Sally Bergosh**: I’ve cleaning bathrooms & declutteeing all morning!!

**Jeff Bergosh**: Here’s what I’m doing

**Sally Bergosh**: Yet the rest of the world still goes to work

**Jeff Bergosh**: Testing vibration of massive chiller equipment

**Sally Bergosh**: Wowza!! You are doing big things over there! I’m proud of you to possess those skills! You’re like a scientist- testing vibrations!!👍❤️

**Jeff Bergosh**: LOL I’m just observing my engineer employee that actually has the skill.  But nevertheless it is an interesting day and a big learning experience!

**Jeff Bergosh**: Check your email there is a document u need to sign to keep the closing on track

**Sally Bergosh**: Is Escambia county’s COVID going up?

**Sally Bergosh**: I signed docs!!:)

**Jeff Bergosh**: Not going up—stabilized

**Jeff Bergosh**: Which is interesting

### CONVERSATION ON 05-06-2021

**Sally Bergosh**: Jeff- I need some advocacy with West Florida Hospital! At one point 2 years ago Kendrick Doidge kept telling me he wanted to set up a tour for Gay to come take a tour of H & H Clinic- but he is such a flake! Can you help me set this up?!

**Sally Bergosh**: Maybe do an introduction of us in an email? Then I can take it from there? Or maybe I can just call her? 

**Jeff Bergosh**: I will

**Sally Bergosh**: It is what it is at this point!!

**Jeff Bergosh**: Heading to bed, see u when u get home.  Big afternoon for us tomorrow!!!  Love u!!

**Sally Bergosh**: We love you, Tori Bear!!

### CONVERSATION ON 05-07-2021

**Jeff Bergosh**: This is where our closing will happen today at 3:30. It’s right across the street from the Chili’s on 9 mile road on the north side of 9 Mile Rd.

**Sally Bergosh**: R u sure? I wrote everything down & had a Palofox address

**Jeff Bergosh**: I’ll double check but that’s the address Brigette gave me

**Jeff Bergosh**: We’re ready to go!!!!

**Sally Bergosh**: Loved an image

### CONVERSATION ON 05-08-2021

**Jeff Bergosh**: Wal Matt has them today!

**Sally Bergosh**: Yay!!

**Jeff Bergosh**: Where are you??

**Sally Bergosh**: Mother’s Day lunch for Bree

**Sally Bergosh**: This will put a smile on your face- B & Nicky are already at a brewery having a great time in Milwaukee! Love you, PC!!❤️❤️

**Jeff Bergosh**: Wish I was too

**Jeff Bergosh**: So fucking frustrated 

**Sally Bergosh**: I know. Call Corey & ask for a suggestion

**Jeff Bergosh**: He did his part already this has nothing to do with him

**Jeff Bergosh**: Can u believe this??????????   

**Sally Bergosh**: Absolutely amazing!!

**Sally Bergosh**: Happy Mother’s Day!! ❤️❤️

**Sally Bergosh**: Thank YOU guys for my most amazing surprise at closing of our condo yesterday!! It was like the perfect day!! Then my realtor gifted us hundred dollar gift cards to all our favorite beach restaurants by the condo!! Thank you, thank you!!❤️❤️ We have gone through all the rental dates & it looks like it is open in August & September!! Do u guys want to look at your calendar & let us know when u can come out?❤️❤️

**Sally Bergosh**: Brandon turned 21 Tuesday & we took him to a fancy restaurant called The District Steakhouse- his first drink was a smoked old fashion that came in a dome!!

**Sally Bergosh**: ?!!?

**Sally Bergosh**: Ohhhhh - u mean u DO want to come visit us!! Yay!! So let’s calendar it soon!!

**Sally Bergosh**: No- it’s when school starts so it’s between summer ‘ long term winter rental time!:)

**Sally Bergosh**: Long term winter renter at that point. End of September should be cooled down

**Sally Bergosh**: Thank you so much Brigette for your amazing professionalism & expertise!! We also love our awesome gift cards!! You ROCK!!❤️❤️


### CONVERSATION ON 05-09-2021

**Jeff Bergosh**: 👍👍

**Sally Bergosh**: Loved an image

### CONVERSATION ON 05-10-2021

**Sally Bergosh**: Tori just opened her bday card from Gary & Carissa. B’s cars had $21 in it for his 21st Bday...Tori, apparently was not worthy. Her feelings were kinda hurt. I told her not to worry about it.

**Jeff Bergosh**: That’s shitty

**Jeff Bergosh**: Aren’t you glad we got flowers now?

**Sally Bergosh**: Oh yes!! I cut them out of the spider web plastic holder & put them in a beautiful vase!

**Jeff Bergosh**: I wish they weren’t so damn cheap.......

**Jeff Bergosh**: I gave Alex and Ben $50 each

**Sally Bergosh**: I wonder if he’s mad at you for not selling Ben your brand new truck

**Sally Bergosh**: Should I reach out to Gaye Nord or do you want to set up for the clinic?

**Jeff Bergosh**: I’ll do it.  I’ll go through Kendrick.  When are you looking to do it, and what is the goal of the meeting?

**Sally Bergosh**: It was actually Kendrick’s idea when Gay Nord first got to West Florida to introduce her to H&H Clinic & introduce her to our services so when they get their frequent flyers in the ER they will know we are providing primary care for people with no health insurance & saving West Florida Lots of money!!

**Jeff Bergosh**: Okay got it

**Jeff Bergosh**: When?  Can u work around their schedules?

**Sally Bergosh**: Yes- tell her to give us (2) possible 30 minute times that she might be able to come by for a tour of the clinic that is in the backyard of her hospital

**Jeff Bergosh**: Okay I’ll see what I can do to make it happen👍😎❤️

**Sally Bergosh**: You will never the hero of our clinic if u could make that happen!!

**Jeff Bergosh**: I think I can make it happen.

**Sally Bergosh**: Loved “I don’t see $200?”

### CONVERSATION ON 05-11-2021

**Sally Bergosh**: You need to download gas buddy on your phone

**Sally Bergosh**: It’s pretty accurate about who has gas & where

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: Danny still not at the house. Did u end of rsvping for 4 peeps or just us for Saturday?

**Sally Bergosh**: At Vinyl for Bears party after dinner at Yacht Club

**Jeff Bergosh**: Only us— I did not feel comfortable doing that

**Jeff Bergosh**: But hey in the good news department I just got to the condo and it didn’t even take me an hour to get here all the way from the base

**Sally Bergosh**: What’s Carissa’s diagnosis?

**Sally Bergosh**: The name of it?

**Jeff Bergosh**: Ataxia

### CONVERSATION ON 05-12-2021

**Sally Bergosh**: Todd said the art teacher just found these in her closet at Beulah ES

**Jeff Bergosh**: That’s awesome!!❤️❤️

**Jeff Bergosh**: Found our AC......It’s a museum piece

**Sally Bergosh**: Oh geez!! Maybe we should get our same air guy that put our unit in since he is our neighbor & we have access to him & we have had zero issues since the new unit was put in!!

**Jeff Bergosh**: He’s expensive

**Jeff Bergosh**: It was blowing cold, I set it at 68 and it got it cool fast.  So I’ll probably just cancel the service call and wait and see......

**Sally Bergosh**: K

**Jeff Bergosh**: Flight 2602 from Nashville landing in Pensacola 10:45

**Sally Bergosh**: WTF?!!?

### CONVERSATION ON 05-13-2021

**Sally Bergosh**: Can u follow up with Gay Nord’s tour of H& H? Rusty is bringing vip’s tomorrow from Studerville- lol

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: I just spoke to Kendrick he’s going to set something up for next week with he and Gay at the clinic

**Sally Bergosh**: Perfect!!

**Jeff Bergosh**: What time is your tennis match?

**Sally Bergosh**: 6 pm- warm up with Paul is at 5:30 pm

**Sally Bergosh**: Come watch, Boxer!! I miss you!❤️❤️

**Sally Bergosh**: Okay- now Mario wants u to call Grover & see if he wants to play next Saturday with all of us at 4:00 at Bayview.....Grover’s daddy used to play with Mario

### CONVERSATION ON 05-14-2021

**Sally Bergosh**: Brandon just just entered the house via sliding glass door & went straight to his room to sleep off his hangover.....I’m worried about this boy of ours!!

**Jeff Bergosh**: Me too

**Jeff Bergosh**: Tori move your car to the opposite side of the cul-de-sac by Mike’s house do not park in front of the mailbox where we won’t get our delivery. Move the car to the opposite side of the cul-de-sac please so that these guys and their giant trucks have a place to park and so they don’t pull into the lawn and rec my sprinkler pipes again!

**Sally Bergosh**: Do u want me to just order a dinner to go from mcguires?

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: No I’m cooking

**Jeff Bergosh**: Stir fry

### CONVERSATION ON 05-16-2021

**Sally Bergosh**: Loved an image

### CONVERSATION ON 05-17-2021

**Sally Bergosh**: Add (1) more Salvation to the #’s for encouragers- we had a Salvation this morning!!

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: Kelly Murray, RN

**Sally Bergosh**: Can u send me final newsletter for edits before sending out to the world?

**Jeff Bergosh**: Yes I will. I’m in the field right now but when I get back to my office I will do that love you

**Sally Bergosh**: Thank you!!

**Jeff Bergosh**: 😁👍❤️

**Sally Bergosh**: Where is the newsletter?!?

**Sally Bergosh**: When is West Florida coming to the clinic?

**Jeff Bergosh**: Sent it

**Jeff Bergosh**: I’m waiting to hear back from Kendrick

**Sally Bergosh**: To health & hope?

**Sally Bergosh**: Kendrick will never call you back- you will have to follow up with him for a scheduled day/ time!!

### CONVERSATION ON 05-18-2021

**Jeff Bergosh**: Wow— good for her

**Sally Bergosh**: Any word from Kendrick or Gaye Nord?!

**Jeff Bergosh**: Not yet

**Jeff Bergosh**: I’ll call kendrick back today

**Sally Bergosh**: Thank you!:)

**Jeff Bergosh**: I booked it for you 1:00 on Monday, June 7th with Gay Nord touring the Health and Hope Clinic

**Sally Bergosh**: Perfect!!:)

**Jeff Bergosh**: 👍

**Sally Bergosh**: I have a tennis match tonight at 6 pm- if u want to come watch!:)

**Jeff Bergosh**: Where at?

**Sally Bergosh**: RScott

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-19-2021

**Sally Bergosh**: This is Ann Scott’s recipe

**Jeff Bergosh**: I can’t eat sweet potato

**Sally Bergosh**: She said the combo does not taste sweet potato

**Jeff Bergosh**: Yeah right

**Sally Bergosh**: It’s a spicy soup- no sweet taste at all

### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Full on casual tonight!!

**Sally Bergosh**: Told u!!

**Jeff Bergosh**: 5:00 at the house right?

**Sally Bergosh**: Yes- I’m racing!!

**Jeff Bergosh**: 
Me too

### CONVERSATION ON 05-22-2021

**Sally Bergosh**: On way home 

### CONVERSATION ON 05-24-2021

**Sally Bergosh**: Are u playing tennis this Saturday?

**Jeff Bergosh**: Yes

**Sally Bergosh**: Did u confirm u r doing the parade Saturday with the county?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Nick Kelsey and Alex szaffan are also coming😎

**Sally Bergosh**: K

**Sally Bergosh**: On way home!:)

**Jeff Bergosh**: 👍

**Sally Bergosh**: Go Padres!!❤️

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: LOL

**Sally Bergosh**: Why are u the only one with a beer in your hand?!!? Why?!?

**Sally Bergosh**: Laughed at “I just happened to be taking a sip ”

### CONVERSATION ON 05-26-2021

**Jeff Bergosh**: Heading to bed love u and I’ll see u when u get home.  I talked to Brandon tonight

**Sally Bergosh**: Loved “Heading to bed love u and I’ll see u when u get home.  I talked to Brandon tonight”

### CONVERSATION ON 05-27-2021

**Sally Bergosh**: Loved “We are on the way. Already into Indiana”

### CONVERSATION ON 05-28-2021

**Sally Bergosh**: $400 leather sofas on Wayfair for biggest sale of the year this weekend for beach condo

**Jeff Bergosh**: Not yet- plus we have to get sleeper sofa

**Sally Bergosh**: It is a sleeper sofa

**Jeff Bergosh**: Can u send a pic?

**Sally Bergosh**: No- go on Wayfair

**Jeff Bergosh**: Send me a link please 

**Sally Bergosh**: Search sleeper sofa leather

**Jeff Bergosh**: What color?

**Sally Bergosh**: Brown

**Jeff Bergosh**: I’ll call 

**Sally Bergosh**: Let’s go to a nice dinner instead!!

### CONVERSATION ON 05-30-2021

**Sally Bergosh**: Does it matter? It’s not like u stick to it anyways

**Sally Bergosh**: No

**Sally Bergosh**: Shoot us the address- we will be there at 10:40

**Sally Bergosh**: We r off the bridge & getting in the 110- see u in 13 minutes

**Sally Bergosh**: Here!:)

### CONVERSATION ON 06-01-2021

**Jeff Bergosh**: I have a congratulations card for Sean Moore how much should we send him? 50 or 100?

**Sally Bergosh**: 50?! I can’t remember what we did in the past

**Jeff Bergosh**: Me neither

**Sally Bergosh**: Awwww- so sweet!!:)

**Sally Bergosh**: Just go right up to clay courts- walkway is under construction

**Jeff Bergosh**: Ok

**Jeff Bergosh**: SALLY I just thought of it I’m on the way there but you have a couple of rackets you could use to warm up with until I get there with your good racket

### CONVERSATION ON 06-02-2021

**Sally Bergosh**: Hey- I’m on my way to hair appnt. Am I good in my account?

**Jeff Bergosh**: Yes u have $500 in there ❤️😎👍

**Sally Bergosh**: K- thank you!:) today I just took control at the clinic & told staff that we do not have “bad bolunteers” but rather bad leadership & we need to own the problems at the clinic more & appreciate the many volunteers that come faithfully every week

**Jeff Bergosh**: Good for u!!  Way to go!!

### CONVERSATION ON 06-03-2021

**Sally Bergosh**: Oh Jeff!! It’s absolutely beautiful!! Love, love, LOVE!!❤️❤️❤️❤️ Happy Anniversary, PC!!

**Jeff Bergosh**: ❤️❤️❤️❤️

**Jeff Bergosh**: Pink Gold and Topaz— it really stood out to me.  So happy you like it!!

**Sally Bergosh**: I don’t just like it....I LOVE it!! But.....I also love my “love letter”! Of course, you didn’t open yours!!?!?

**Jeff Bergosh**: I’m saving it for when I come home

**Jeff Bergosh**: Thank you for the Awesome Anniversary gifts and card!  Love u❤️

**Sally Bergosh**: Love you, PC!! What happened to your 10:30 pm meeting?!?

**Jeff Bergosh**: It got over at 9:00 LOL

### CONVERSATION ON 06-04-2021

**Sally Bergosh**: From Michelle Salzman:

Karen Bradley’s son, Terrell has passed away.. he was sick - they took him to doc a couple days ago cuz he couldn’t breathe... the doc gave him a prescription and sent him home.  He felt better yesterday, then early this morning he woke up unable to breathe.. Karen called 911, but between her and the emt, they couldn’t revive him.

**Jeff Bergosh**: That is horrible

**Jeff Bergosh**: Thank you card Friday! ❤️👍

**Sally Bergosh**: Gratitude Friday!!

**Jeff Bergosh**: Yes

**Sally Bergosh**: Don’t forget that Bonnie & Hillary & I are going to George’s at 5:45 pm tonight. Do I have $ in my account?

**Jeff Bergosh**: Yes $1044.00 in checking

**Sally Bergosh**: Thank you!!:)

### CONVERSATION ON 06-05-2021

**Sally Bergosh**: This from Susan Jason for dinner & bourbon event at her house:

Since Sara and John can’t make the 17th, can everyone make Tuesday the 15th?

**Sally Bergosh**: So far everyone has said yes & they are waiting on our reply since Friday

**Jeff Bergosh**: Dealing with the AC which just went out again😫😫😫

**Sally Bergosh**: Call our guy

**Jeff Bergosh**: Already did

### CONVERSATION ON 06-07-2021

**Sally Bergosh**: I was already going to take off Saturday from tennis to be at this event! Now Rusty wants us to attend as his guests!

**Sally Bergosh**: As in Jeff Bergosh, CC for District 1!!

**Sally Bergosh**: So no response about them coming today?

**Sally Bergosh**: Should I email her directly?

**Jeff Bergosh**: Just got this from Kendrick 

“Yes. We will be there at 1. We look forward to seeing you all there.”

**Jeff Bergosh**: They’ll be there

**Sally Bergosh**: K

**Jeff Bergosh**: Sally, Unfortunately I won’t be able to make it due to this re-compete and Tony coming down. Please give my apologies to Kendrick and Gay

**Jeff Bergosh**: Dying to know how the meeting went today with WFHospital??

**Sally Bergosh**: I looked up the article.......totally ridiculous! 

**Jeff Bergosh**: Yes it is

**Sally Bergosh**: Who do u think was the “mole”?!?

**Jeff Bergosh**: No idea

**Jeff Bergosh**: I’m getting ready for bed I love you getting tired I’ll see you when you come home love you. ❤️❤️

**Sally Bergosh**: Just finished my thank you letters for May contributions & packing up!:)

**Jeff Bergosh**: Love u

**Sally Bergosh**: Love u right back!!❤️

### CONVERSATION ON 06-08-2021

**Jeff Bergosh**: Good luck in your tennis match tonight!  Love u!!❤️❤️❤️

**Sally Bergosh**: Love u right back! Hope today went well with da boss!!

**Jeff Bergosh**: It did, great and productive day!

**Jeff Bergosh**: Pretty cool right?!?

**Sally Bergosh**:  Sry!!👍

**Jeff Bergosh**: 👍👍

**Sally Bergosh**: Yes!!

**Sally Bergosh**: Thanks! Brigette kinda gave me the dates already as a heads up!:)

**Sally Bergosh**: Miss u most!! I hate all this Pam Childers stuff going on- I consider her a friend & really like her & hate that she thinks I’ll of Jeff😢

**Sally Bergosh**: *ill

### CONVERSATION ON 06-09-2021

**Jeff Bergosh**: Dinner is served!  Pasta with red sauce!

**Sally Bergosh**: On my way!!:)

**Jeff Bergosh**: Thx Tanya!

### CONVERSATION ON 06-10-2021

**Jeff Bergosh**: My lunchtime walk visual today—-with “Pat Benetar’s” greatest hits as the soundtrack.  We’re blessed to live and work here——-I just wish u were here with me to enjoy this beautiful day!!❤️❤️

**Sally Bergosh**: Me too!! My HUGE Pfizer Audit is starting right now......wish us well!!:)

**Jeff Bergosh**: 🙏🙏🙏🙏🙏🙏🙏🙏

### CONVERSATION ON 06-11-2021

**Jeff Bergosh**: The story was on the news last night it’s about Narcan very interesting I think you’ll like it

**Sally Bergosh**: I wishwe could get them to add us as a place to go to get free Narcan

**Jeff Bergosh**: Just tried to call u back

**Jeff Bergosh**: I had a good talk with Randy wood from Channel 3 his reporter John Roppolo a new guy has been given your number the office and the cell and he is going to probably do a story on it for Monday so answer your phone

**Sally Bergosh**: K

**Sally Bergosh**: When is the soonest I could help me move the fridge/ freezer?!

**Jeff Bergosh**: I thought you were going to fix it?

**Sally Bergosh**: Operation Fridge Rescue is completed!:)

**Jeff Bergosh**: Way to go!!!

### CONVERSATION ON 06-15-2021

**Sally Bergosh**: No call from the news guy about Narcan.....

**Jeff Bergosh**: I’ll call him

**Sally Bergosh**: I don’t even care about them doing a story as much as the news should WANT to tell them how u can save a life with the opioid epidemic in our county!!

**Jeff Bergosh**: Agree

**Sally Bergosh**: And where they can get Narcan for FREE

**Jeff Bergosh**: I can’t do that event on the 18th

**Jeff Bergosh**: Recovering

**Sally Bergosh**: I’ll tell Rusty

**Sally Bergosh**: He keeps reminding me

**Jeff Bergosh**: Just tell him I’ll be recovering from a procedure

**Sally Bergosh**: Got it!

**Jeff Bergosh**: But please don’t go into detail as it’s not his business

**Jeff Bergosh**: Please

**Sally Bergosh**: Totally

**Jeff Bergosh**: ❤️👍

**Jeff Bergosh**: And I’m not the guy they want to hear from on this topic believe me

**Sally Bergosh**: Maybe that’s why they have invited u to attend

**Sally Bergosh**: 😇

**Jeff Bergosh**: They picked the wrong day

**Jeff Bergosh**: Sorry- pocket dialed u

**Sally Bergosh**: Just finished interview- I made Carol do the interview too & she shared that opioid epidemic overdose is personal! 

**Jeff Bergosh**: 👍

**Sally Bergosh**: From Hillary:

Hey there. 
How are you? 
My mom is looking at trying to rent a place at the beach this year (or we can look at next year). Can you share any open dates and your pricing? 

**Jeff Bergosh**: On way home

**Sally Bergosh**: Had a BLAST! Thanks for an amazing dinner & bourbon tasting, but most of all- thanks for the laughter & friendship!❤️❤️

**Sally Bergosh**: Feel better, Bruce!!

### CONVERSATION ON 06-16-2021

**Sally Bergosh**: Great job this morning! Great info- I didn’t know about the veterans grant!👍

**Sally Bergosh**: Apparently, they showed another segment on the Narcan at the clinic this morning!

**Jeff Bergosh**: You did watch!!  Thank you ❤️❤️

**Jeff Bergosh**: That’s great the clinic is getting some extra exposure

**Sally Bergosh**: Yes!

### CONVERSATION ON 06-17-2021

**Sally Bergosh**: Do I have money in my account?!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: ❤️👍

**Sally Bergosh**: How’s your meeting going? Did everyone like your tie?

**Jeff Bergosh**: It was a long meeting.  Janice Gilley fired 

**Jeff Bergosh**: So when I get Tories watermelon I’ll probably get some strawberry Aveda as well I’ll need it tonight lol

**Sally Bergosh**: Did u talk at the meeting?

**Sally Bergosh**: Specifically - I am referring to your feelings about Janice?

**Jeff Bergosh**: Yes but we didn’t air dirty laundry

**Jeff Bergosh**: It was dignified and professionally done

**Sally Bergosh**: 🙃

**Sally Bergosh**: Go look in B’s room- did he clean up his vomit that he disrespected me & laughed about this morning?

**Jeff Bergosh**: There’s no vomit

**Sally Bergosh**: ❤️❤️❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: Brandon- I hope for your sake u cleaned up your vomit from your bedroom floor today!

**Sally Bergosh**: I agree! When u r declaring u r ready to try again at living independently & pull crap like that.....not very convincing at all!:(

### CONVERSATION ON 06-22-2021

**Jeff Bergosh**: I edited the newsletter, shortened the NARCAN story, added a “Donate” button on the bottom and sent it out to your distribution list this morning. 👍👍❤️❤️love u!

**Sally Bergosh**: Love you MOST!! Thank you, PC!❤️❤️

**Jeff Bergosh**: ❤️❤️

### CONVERSATION ON 06-24-2021

**Sally Bergosh**: We need to charge more for Blue Angel Week at the beach!!


**Jeff Bergosh**: Damn!! Are those for this year’s show dates??!!??

**Sally Bergosh**: Yes!!

**Jeff Bergosh**: We bumped the price during blues week next year from $250 a night up to $300.   Do u think that needs to go up?

**Jeff Bergosh**: This year was already booked at $250 per night

**Sally Bergosh**: I would go up to $350 p/ night

**Jeff Bergosh**: Okay I’ll plug that cost in for next year

**Sally Bergosh**: Yes!!

**Sally Bergosh**: B got sick again last night from partying & food! I’m so worried  about him!!

**Jeff Bergosh**: What is his deal??????????????????

**Jeff Bergosh**: I’ll talk to him today

**Sally Bergosh**: This from Tonya Chase

I’m shocked anyone has any rooms left. 

Oh no!!!!  I think I’m getting $695, but we reduced it for an old friend of Jim’s. My normal goal is to get between $5&$6 k for the week. I’ve got it listed next year at $900.  Next year is BIG. Blues & 4th fall within 7 days. BIG$$$. 

You WAY under sold.  😩

**Jeff Bergosh**: Oh well- we live and learn

### CONVERSATION ON 06-25-2021

**Sally Bergosh**: Donna bought her ticket & is coming! Only $230!!

**Jeff Bergosh**: That’s awesome!  You all are going to have a blast!

**Sally Bergosh**: It’s kinda weird that she is only coming Tues-Friday!?!

**Jeff Bergosh**: Yes but at least she’s coming out!  Now I just have to get Debbie and Becky on board.

**Jeff Bergosh**: Wow, that is relevant and timely!

**Jeff Bergosh**: Our bible study was John 14 today.  Heavy

**Sally Bergosh**: Love you & hope your day is much better!!❤️❤️

**Sally Bergosh**: Do u have the condo listed for long term winter rental yet?

**Jeff Bergosh**: Not yet because Ed Fleming wants it he told me.  But if he doesn’t I’ll be listing it soon

**Jeff Bergosh**: Love u most

**Sally Bergosh**: I would give him a deadline to make the decision, because while all these peeps are vacationing, they might also want to browse what’s available for winter

**Jeff Bergosh**: Yes I will

**Sally Bergosh**: Perfect!! Should I text her & find out her next availability for a Saturday night or Sunday morning brunch?

**Jeff Bergosh**: Yes but let’s put it out a couple of weeks I’m drowning

**Sally Bergosh**: Gotcha!!:)

**Jeff Bergosh**: Andy’s latest.........

**Sally Bergosh**: So now you’re corrupt?!?

**Jeff Bergosh**: LOL

**Jeff Bergosh**: .........,they’re corrupt

### CONVERSATION ON 06-27-2021

**Sally Bergosh**: On my way home!:)

**Jeff Bergosh**: ❤️❤️

### CONVERSATION ON 06-28-2021

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/06/blog-post_28.html?m=1

**Sally Bergosh**: This is awesome & I appreciate your advocacy on behalf of RScott Tennis facility! Donna Underdonk was very grateful & has been calling all commissioners to support this

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 06-29-2021

**Sally Bergosh**: Will u ask your bro today about an estate lawyer referral for my dentist that has an inheritance house in Louisiana? He already has a Louisiana lawyer, but also needs a Florida lawyer.

**Jeff Bergosh**: I will.  He is in veteran’s court

**Sally Bergosh**: Well 2 weeks ago he said he would send me the contact info & never did.

**Jeff Bergosh**: He is sending it to u right now

**Jeff Bergosh**: 😎👍

**Sally Bergosh**: He still hasn’t sent

**Jeff Bergosh**: Okay I’ll nudge him 

**Sally Bergosh**: Got it from him- he sounded under water which is what I am

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Me too!

**Sally Bergosh**: This looks like a FUN night for our entire family!! Let me know who wants to play & who can get that night off of work & I’ll make sure we RSVP!

### CONVERSATION ON 06-30-2021

**Sally Bergosh**: Yes! 

**Jeff Bergosh**: Right on

### CONVERSATION ON 07-01-2021

**Sally Bergosh**: When will u be bringing this item as an agenda item?

**Sally Bergosh**: http://jeffbergoshblog.blogspot.com/2021/06/blog-post_28.html?m=1

**Jeff Bergosh**: I’m meeting with Mayor Robinson on  the 8th at 3:00.  It will more than likely be brought forward to our following meeting on 7-22-21

**Sally Bergosh**: Nice!!❤️❤️

**Sally Bergosh**: I’m racing to my match, starts at 7:30

**Jeff Bergosh**: Good luck on the match!!

**Jeff Bergosh**: Maybe we could tagteam it along with our trip to Cabo

**Sally Bergosh**: Oh my goodness!! I thought I’d missed my chance

**Sally Bergosh**: I won, I won!! I beat my nemesis!! Rematch from the other night & we won!!

**Jeff Bergosh**: Congrats!!

**Jeff Bergosh**: Falling asleep.  Love u!!

### CONVERSATION ON 07-02-2021

**Sally Bergosh**: I just got home! Do not go home on the interstate- huge wreck both directions on I-10!

### CONVERSATION ON 07-03-2021

**Jeff Bergosh**: I’m taking Brandon’s car from him for two weeks.  It will be parked downtown at my parking spot upstairs.  He will be buying his own insurance. He is no longer on my policy.  For the next two weeks he will have to rely on others for rides.  I’ll drive him to work today, he will take an Uber home.  In two weeks, depending upon how he reacts to all this, I’ll let him drive my car again.  If I ever even think he has driven intoxicated, I’ll take the car from him  permanently and drive it myself to Milwaukee and give it to Nick for the last two years of the lease

**Jeff Bergosh**: I discussed it all with him today, he understands he fucked up, he knows what he has to do

**Sally Bergosh**: Back to back traffic on I10

**Jeff Bergosh**: Okay don’t sweat it I’ll get our table

**Jeff Bergosh**: Just drive carefully

### CONVERSATION ON 07-07-2021

**Sally Bergosh**: Are you planning to attend the gulf coast kids house know child abuse breakfast event at PYC on 8/18? Michelle wants us to be at her table!!

**Sally Bergosh**: Let me know- I’m attending!!

**Sally Bergosh**: The GCKH event on 8/18 is a breakfast from 7:30 am- 9 am at PYC and we will be sitting at Michelle Salzman’s sponsored table. 👍

**Sally Bergosh**: K!!

**Sally Bergosh**: Why don’t u reply to my stuff? 

**Sally Bergosh**: I’m picking up dinner for Donna & her daughter- she just got out of hospital from surgery. I’m about an hour late & counting!! Ughh

**Jeff Bergosh**: Okay

**Sally Bergosh**: Perfect!:)

### CONVERSATION ON 07-10-2021

**Sally Bergosh**: Not sure this far out but we can make some calls to see if anyone knows anything.

### CONVERSATION ON 07-11-2021

**Sally Bergosh**: My phone just read that I missed Malcolm Thomas’ phone call under my “recent calls missed”. Is his # 712-6922?

**Sally Bergosh**: It says he called at 11:52 am

**Jeff Bergosh**: What the hell is he calling for?

### CONVERSATION ON 07-12-2021

**Jeff Bergosh**: Sorry— my date and days were mixed up;  we have our condo for our use from 10:00AM Saturday through 3:00PM Sunday.....not Friday.  LOL. Love u!

**Sally Bergosh**: Liked “Sorry— my date and days were mixed up;  we have our condo for our use from 10:00AM Saturday through 3:00PM Sunday.....not Friday.  LOL. Love u!”

**Jeff Bergosh**: Hey I just noticed that you wash the comforters for me thank you for doing that!

**Jeff Bergosh**: It was on my to do list for tonight :-)

**Sally Bergosh**: We’re u trying to send me a picture? It’s just black & says “digital touch message”

**Sally Bergosh**: *Were, not we’re

**Jeff Bergosh**: No, just texts thanking you 

**Jeff Bergosh**: Falling asleep, love u!  R u on way home soon?

**Sally Bergosh**: Yep

**Sally Bergosh**: Love you!!❤️

### CONVERSATION ON 07-13-2021

**Sally Bergosh**: I wonder if we can take our airline tickets use to get to San Diego, stay a few days, then take cheap flight to Cabo?

**Sally Bergosh**: Everyone else have bought their tickets for Thursday- Monday in Cabo

**Jeff Bergosh**: That sounds like a good idea! 

**Sally Bergosh**: Match tonight at 6 pm at RScott

**Jeff Bergosh**: Okay I’ll come and root for you!!

**Sally Bergosh**: Today our air condition, refrigerator & now ceiling from the leaky air condition all broke while I was trying to accounting Tuesday with accountant, Carol & Jim at emergency & another doctor not coming to the scheduled shift & us having to rearrange all their patients to tonight from this morning!! Grrrrrr plus all grants we receive want their end of the year days reporting this month!!

**Jeff Bergosh**: Well, that’s what tomorrow is for 😂😎👍

### CONVERSATION ON 07-14-2021

**Sally Bergosh**: His vmail is FULL & he didn’t take the call🙃

**Jeff Bergosh**: Oh well I texted him too so maybe he’s just in the midst of something.  I believe he will follow up

**Jeff Bergosh**: He’s going to have someone from his training office call

**Sally Bergosh**: No one has called me from sheriff office

**Sally Bergosh**: I’m doing an emergency dry run rehearsal since our final, final audit for Merck that was pushed up to tomorrow instead of Friday

**Jeff Bergosh**: Wow I’m surprised they didn’t.  I’m sure they will tomorrow

**Sally Bergosh**: No but it will be available the 12-15!! Why don’t u change your return dates & I’ll take u back to Mississippi airport

**Sally Bergosh**: Pooh!

**Jeff Bergosh**: Right on

**Sally Bergosh**: Love you, Nicky!!

### CONVERSATION ON 07-15-2021

**Sally Bergosh**: Do I ha e money in my account?!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Sav

**Sally Bergosh**: Thank u!

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love u right back!!

**Jeff Bergosh**: ❤️

**Sally Bergosh**: Apparently u were in a cartoon last week in the Santa Rosa Press Gazette

**Jeff Bergosh**: Oh really I missed it what was it?

**Jeff Bergosh**: Justin Witkin sent this invite to me— do you want to do this next Friday evening downtown at 6:30?

**Sally Bergosh**: Of course!! I just saw Bonnie Witkin today at tennis!

**Jeff Bergosh**: Okay I’ll rsvp

**Sally Bergosh**: 4 hour audit today!! Nightmare! Ugh!!

**Jeff Bergosh**: Did you pass it?

**Sally Bergosh**: Brandon & I found 3 beds we really liked at Hanks Fine Furniture & Rooms to Go! At the end of our hour shopping trip, he said he wanted to work out a trade with Tori

**Sally Bergosh**: I guess we passed- she wants us to find (2) more documents for 2 patients and upload in her stupid portal. She works for a 3rd party Conduent- total ball buster!!

**Sally Bergosh**: We have (1) week to complete the task

**Jeff Bergosh**: Well u just have to play ball and do it

**Jeff Bergosh**: I love u — I’m fading fast though and am falling asleep.  I’ll see u when u get home! ❤️❤️❤️❤️

**Sally Bergosh**: I got this messenger text from Sue Nast’s hubby Kit-

Hi Sally!  I'm trying to get a big group together for this - it would be great if you guys could join us.  Wed, Aug 4th, is Sue’s birthday!  I’m taking her to dinner that night, and I thought it would be fun to get a bunch of people together afterwards to watch Karaoke at Seville Quarter at 8PM (as a surprise to Sue!)  Little known fact…Sue loves to watch Karaoke!  I hope that you’ll consider joining us.  Write it on your calendar, and don’t tell Sue.

**Jeff Bergosh**: I fell asleep but was happy to see the Bucks pulled it out!!

**Sally Bergosh**: Loved “I fell asleep but was happy to see the Bucks pulled it out!!”

**Sally Bergosh**: My intern just sent this to me!!?!😂

**Jeff Bergosh**: That’s my Friday at 4:30 dance LOL

**Sally Bergosh**: Hmmmm

**Sally Bergosh**: Love those pictures, Carissa!! I guess our waitress at McGuires’ son is there too! She went to elementary school with Nicholas!❤️ Enjoy those cooler temps! We are all melting in P’Cola.😂

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Loved an image

### CONVERSATION ON 07-16-2021

**Sally Bergosh**: Slipcover sofa in any color & material you want- washing machine safe 

**Sally Bergosh**: What I’m thinking for OUR next couch! Reclining movie theatre seats! Comes in other colors & can come in leather!:)

**Sally Bergosh**: Do u know how long we get to talk at BOCC when Anna presents? 5 minutes- 10 minutes?

**Jeff Bergosh**: I think you all get 5 min

### CONVERSATION ON 07-17-2021

**Sally Bergosh**: 6-4
7-5
1-0(10-5)
Winner, winner-Chicken dinner!! Gail Tilley & I won again!!

**Jeff Bergosh**: Congratulations!!

### CONVERSATION ON 07-19-2021

**Jeff Bergosh**: Remember I RSVP’d for us to attend this event Friday Night at Vinyl Downtown 😎❤️👍

**Sally Bergosh**: Yes!! Thank u for the reminder!❤️

**Jeff Bergosh**: I think it will be pretty neat!

**Sally Bergosh**: Carol just tested positive for COVID- ugh I have nurse meeting tonight that I am now in charge of tonight

**Jeff Bergosh**: Wait, what??  Wasn’t she fully vaccinated????????

**Sally Bergosh**: We are getting LOTS of reports of fully vaccinated peeps getting COVID

**Sally Bergosh**: Nurse meeting is at 6 pm

**Sally Bergosh**: Going to be a long one!!

**Jeff Bergosh**: That is scary!!

**Jeff Bergosh**: Hate to hear that

**Sally Bergosh**: Yes- just got off my bod admin meeting & Anna reported that insurance companies are reporting lots of  Covid cases with peeps that have been vaccinated!

**Jeff Bergosh**: Wow here we go again........ I hope lockdowns aren’t next up

**Jeff Bergosh**: Have u been able to hang in there with me on fast day?

**Sally Bergosh**: The doctor that just saw Carol said half the patients that are testing positive for the Delta variance are vaccinated- they are putting her on blood thinners cuz one of the side affects is blood clots in the lungs. They have her in isolation & said if they can give her antibodies they will send her home

**Jeff Bergosh**: Wow this is concerning!  Did she take the Moderna Vaccine like us?

**Sally Bergosh**: Yes!!

**Jeff Bergosh**: Wow-  we have to be careful

**Jeff Bergosh**: Sally I’m exhausted I’m heading to bed I love you I’ll see you when you come home. ❤️❤️❤️👍👍👍

**Sally Bergosh**: This is just so frustrating

### CONVERSATION ON 07-20-2021

**Jeff Bergosh**: Oops! I screwed up and am just realizing that our next guest comes in on Saturday—-not Sunday!  So we won’t have the condo this Saturday to Sunday like I thought we would....sorry for the mixup.  I’ll get down there right after tennis and get the changeout done prior to these next guests’ arrival!

**Sally Bergosh**: I’m now roped into doing another Julian MacQueen health fair at AADixon School with Rusty again Saturday, 9am- 1 pm- no tennis for me!!

**Jeff Bergosh**: Tell them NO LOL

**Sally Bergosh**: In the newspaper this morning it indicates Escambia County had an 87 percent increase in new cases of Covid over the past seven days through Saturday with a 48 percent increase in hospitalizations.  Santa Rosa County had a 91.89 percent increase in Covid cases and an 85 percent increase in new hospitalizations.  Do we need to go back to more stringent measures to protect our volunteers and patients?

**Jeff Bergosh**: I think so, sadly

**Jeff Bergosh**: Not enough people getting vaccinated locally

**Sally Bergosh**: I had 2 fully vaccinated volunteers test positive with Covid 

**Sally Bergosh**: Yesterday

**Jeff Bergosh**: Wow!  That is alarming.  Are they asymptomatic, or are they sick???

**Sally Bergosh**: They are both sick-shortness of breath, cold symptoms- both went to hospital & were given chest X-rays & antibodies, then sent home

**Sally Bergosh**: I’m panicking-the receipt u send via email for Cabo shows weird dates booked

**Jeff Bergosh**: No I thought that too

**Sally Bergosh**: Yes!! Watching is a very loose term. Your dad has the tv on & is cheering them on mentally through his closed eyelids!😂

**Sally Bergosh**: Goooo Bucks!!

**Sally Bergosh**: I woke him up!! 

**Sally Bergosh**: Yes! Go bucks, Go!!

**Sally Bergosh**: Where r you, Brandon?!!?

**Sally Bergosh**: Holy cow! Your city has some serious Buck Spirit!!

**Sally Bergosh**: 😂

### CONVERSATION ON 07-21-2021

**Jeff Bergosh**: He’s a POS

**Jeff Bergosh**: Outstanding job!!!

**Sally Bergosh**: Love you!! Thanks for not saying anything when we were called- Anna was so nervous!!

**Jeff Bergosh**: She did fantastic

**Sally Bergosh**: Hey, PC. What is the name of the place &/ or guy that helps us with computer issues on Davis?

**Jeff Bergosh**: Love u!❤️

### CONVERSATION ON 07-22-2021

**Sally Bergosh**: Love you, PC!! Represent classy today for all the people that elected you!! ❤️❤️

**Jeff Bergosh**: Love u too, and will do!

**Sally Bergosh**: How’s it going?

**Jeff Bergosh**: It’s over, we finished at 11:11

**Jeff Bergosh**: Discussion on 401a got dropped

**Sally Bergosh**: Well that’s good. Is That person fired?

**Jeff Bergosh**: No

**Jeff Bergosh**: Bye bye Rayme Edler 👌👌

**Sally Bergosh**: 👍

**Jeff Bergosh**: 👍yep.  It’s like the SNL flight attendant skit.   “Buh- Bye!!!”

**Sally Bergosh**: I think she wasn’t fired 

**Jeff Bergosh**: Not technically but she’s not going to be around any longer, and she’s not the medical director anymore so

**Jeff Bergosh**: ...... there’s that

**Sally Bergosh**: Gotcha

### CONVERSATION ON 07-23-2021

**Sally Bergosh**: I loved this one this morning!!

**Sally Bergosh**: Looking forward to my hot date tonight!!❤️❤️

**Jeff Bergosh**: Me too!!

**Sally Bergosh**: So I just googled casual cocktail attire!! U should do the same!!❤️

**Jeff Bergosh**: I’m afraid to LOL

**Sally Bergosh**: Dark jeans, blazer or untucked, rolled up sleeve collar shirt

**Jeff Bergosh**: Okay I can do that LOL

**Jeff Bergosh**: I mailed your envelope at the base post office today 😎👍❤️

**Sally Bergosh**: Registered right?

**Sally Bergosh**: I mean certified

**Jeff Bergosh**: Certified

**Sally Bergosh**: Thank you!!❤️❤️

**Jeff Bergosh**: 👍👍❤️❤️

### CONVERSATION ON 07-25-2021

**Jeff Bergosh**: ......meanwhile, though, I did get a lot accomplished

**Sally Bergosh**: Good- yes, I’m wrapping things up- see you in 20 minutes!:)

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you MOST

### CONVERSATION ON 07-26-2021

**Sally Bergosh**: See if Gary has any interest in attending?

**Sally Bergosh**: RSVP is due tomorrow

**Jeff Bergosh**: I will ask I would go but I will be in a meeting at that same time and it’s a very important meeting about 0LF8 and a public hearing

**Jeff Bergosh**: I just texted and asked him

**Sally Bergosh**: Got it

**Jeff Bergosh**: Do you want to Meet me at rooms to go?

**Jeff Bergosh**: Or are you still super busy

**Sally Bergosh**: No good tonight! I’m under water!! Can we meet a different day this week after work?

**Sally Bergosh**: Tomorrow?

**Jeff Bergosh**: Sure! Tomorrow.  Love u!!

**Sally Bergosh**: Love you right back!! 

**Jeff Bergosh**: Gary just called and he for sure wants to go to that event with Kenneth Starr so please RSVP for the two of you.

**Jeff Bergosh**: And of course I would go if I didn’t have a regular county commission meeting that same time

**Sally Bergosh**: Got it!:)

**Jeff Bergosh**: It’s interesting that I walked into Brandon’s room just now, empty, and just got a rush of sadness; they’re all growing up and moving out.  As I looked around that room the memories of their first day there with the bunk bed and the blue starfish light came rushing back.  Wow, how 17 years goes by fast...

**Sally Bergosh**: You just brought tears to my eyes!! So precious!! Tell him! They think you are a hard ass when u r really the sentimental one deep down! Have we helped him with rent yet? Use that as your guide to call❤️❤️

**Jeff Bergosh**: He’s not here but I will 

**Jeff Bergosh**: I miss our kids

**Sally Bergosh**: I know he’s not there - call him

**Jeff Bergosh**: I will tomorrow

**Jeff Bergosh**: Falling asleep, love u!!

**Sally Bergosh**: Love you right back!:)

### CONVERSATION ON 07-27-2021

**Jeff Bergosh**: So true!!

**Sally Bergosh**: Now let’s go find that couch!! Lol

**Jeff Bergosh**: LOL

**Sally Bergosh**: Marie Orf died over the weekend- we need to send flowers- Nicky called me this AM about it

**Sally Bergosh**: Chris Orf’s address: 6114 east shore drive

**Jeff Bergosh**: Absolutely.  I’ll handle it 

**Sally Bergosh**: Thank you! We have our first CATC committee meeting today & everyone has been dropping out of today’s meeting like flies! Tara was “exposed to Covid” on Saturday- has not been vaccinated. Susan Bonsignore is traveling. Christine Rush has jet lag from her trip to Santorini with hubby, Gay Overholtz is in Dallas, etc, etc-ugh!!

**Jeff Bergosh**: Re schedule it for two weeks out

**Jeff Bergosh**: 😎❤️👍

**Jeff Bergosh**: I just sent the flowers to the Orf family.  I’ll text you the picture once they send it to me. ❤️

**Sally Bergosh**: Oh that’s fantastic news, Jeff. Can u imagine what her husband must be feeling?! So, so sad!!

**Jeff Bergosh**: Going to be delivered right now to their house

**Sally Bergosh**: Perfect- thank you!!❤️

**Jeff Bergosh**: ❤️❤️

**Sally Bergosh**: Maybe we can work on newsletter tonight

### CONVERSATION ON 07-28-2021

**Sally Bergosh**: Send me the picture of the new couch please!

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Just sent u the test email

**Sally Bergosh**: I sent u one quick change for newsletter- 👍

**Sally Bergosh**: Gmail

**Jeff Bergosh**: Okay

**Sally Bergosh**: Thank you!!

**Sally Bergosh**: What do u want me to tell Mario about tennis tourney Saturday at 4:30? Tori said she can go with you since I have a ticket to see Adrianna’s dance showcase with Susan Jason

**Jeff Bergosh**: What??? I’m not going if you’re not 

**Jeff Bergosh**: Just tell him I’ll come to the next one LOL— can’t make this one 

**Sally Bergosh**: Gotcha! I thought you’d want to still play since Tori can play

**Jeff Bergosh**: Nah I only like to play if you were there with me

**Jeff Bergosh**: 👍🙂👌

**Sally Bergosh**: K

**Jeff Bergosh**: I just sent out the July August newsletter so check it out in your inbox❤️❤️❤️❤️👍👍👍👍👌👌

**Sally Bergosh**: Yay!! Thank you!

**Jeff Bergosh**: 👍👍👍

**Sally Bergosh**: Mike just forwarded me the same text! How cool is that?!!?

**Jeff Bergosh**: Who is that guy?

**Jeff Bergosh**: Very nice compliment!!

**Sally Bergosh**: https://secure.img1-fg.wfcdn.com/im/13719842/resize-h800-w800%5Ecompr-r85/1239/123917347/Daulton+20%22+Wide+Velvet+Side+Chair.jpg

**Sally Bergosh**: Bingo!!

### CONVERSATION ON 07-29-2021

**Jeff Bergosh**: Sally-  can u pleas grab the package at the front door that UPS guy just dropped off?   Thanks!

Love, me

**Sally Bergosh**: It was already grabbed by Tori

**Jeff Bergosh**: Thx

**Jeff Bergosh**: It’s an incredibly important package!

**Sally Bergosh**: What is it?

**Jeff Bergosh**: Top secret

**Jeff Bergosh**: No matter what u do, DO NOT open it

**Sally Bergosh**: Really?!!? Now I’m opening it!!

**Jeff Bergosh**: They are little plastic/silicone buffer tabs— so I can fix the cutting board at the condo tomorrow  🤪🤪

**Jeff Bergosh**: Top secret LOL

**Sally Bergosh**: Wellllll.......I’m certainly glad I didn’t violate your trust over buffets!! They were left unscathed & your package is completely in text!!

**Sally Bergosh**: My dental facilitator just tested positive for COVID......here we go!!

**Jeff Bergosh**: Uh oh, spaghetti o’s!!!  Now what do u do??

**Jeff Bergosh**: Who can back fill for her??

**Sally Bergosh**: The lady that retired, Teresa. But she is checking her availability to see what days she has open. What a fricken mess!!

**Jeff Bergosh**: Sorry you’re having to deal with this.  Worst case— push the appointments out three weeks

**Jeff Bergosh**: A plane just crashed in front of Blue Angels Elementary School.  No students or staff involved, no injuries on the ground— but three occupants in the plane were injured and will be transported to the hospital

**Sally Bergosh**: Oh geez!!:(

**Jeff Bergosh**: Sad right

**Sally Bergosh**: Super sad!!:(

**Jeff Bergosh**: I’m going into my meeting right now with John Peacock any questions you want me to ask him? Lol

**Jeff Bergosh**: Okay, it’s almost 9:00 I have early morning tomorrow so I have to go to bed.  Love u, come home soon and drive safe.  Love u❤️❤️❤️.  Goodnight!

**Sally Bergosh**: My mom might have Parkinson’s disease 

### CONVERSATION ON 07-30-2021

**Jeff Bergosh**: I’m praying for her!

**Sally Bergosh**: Love u!!❤️❤️

**Jeff Bergosh**: Love u most!

**Jeff Bergosh**: That piece of shit

**Sally Bergosh**: Why, why, WHY?!!?

**Jeff Bergosh**: Because he’s a piece of shit

**Jeff Bergosh**: And that paper is to

**Sally Bergosh**: Stop- what did Peacock say?

**Jeff Bergosh**: He just wants to do consolidation he also wants a strong elected county mayor which I told him I would never support

**Jeff Bergosh**: We agree on one thing each commissioner should be voted with all residents voting for each district that’s the way it is most places and it’s dysfunctional the way it is down here

**Sally Bergosh**: Barry feels like his part of town would never be represented if we had to rely on a commissioner from in town that doesn’t get their needs

**Jeff Bergosh**: Still has to be a person that lives in the district

**Jeff Bergosh**: But I already brought that before the board and there was not support for it so status quo will win the day

**Sally Bergosh**: Disenfranchised from what?

**Jeff Bergosh**: From voting on a commissioner that makes decisions on all county issues but is only voted in by 1/5 of the county’s voters

**Jeff Bergosh**: Don’t u see this? 

**Sally Bergosh**: So in our homeless coalition zoom yesterday Connie Bookman said we were voting on buying a hotel with some of the $3 million federal funding & Michael Carro was already looking for a place to create a (1) stop shop for the homeless

**Jeff Bergosh**: Great

**Sally Bergosh**: Did he donate to your campaign last go around?

**Jeff Bergosh**: Who?

**Jeff Bergosh**: Carro?

**Sally Bergosh**: Yes

**Jeff Bergosh**: Not this last election, no

**Jeff Bergosh**: The two prior, yes

**Sally Bergosh**: Hmmmm- he needs to come out & support Health and Hope this year!!

**Jeff Bergosh**: I agree

**Jeff Bergosh**: I’ll ask him to

**Sally Bergosh**: If you give me his email address I’ll send him the CATC Gala Sponsorship package after you talk to him

**Jeff Bergosh**: Okay 

**Jeff Bergosh**: I haven’t spoken to him yet but I will

**Sally Bergosh**: Marie Orf’a funeral is today at 2 pm at St. Anne’s Catholic Church. I’m in charge of a huge retirement party that is being catered at the clinic......

**Jeff Bergosh**: I can’t be there 

**Jeff Bergosh**: I’ll be at our Condo— 

**Sally Bergosh**: I know

**Jeff Bergosh**: We have guests coming in at 3:00

**Jeff Bergosh**: We sent flowers

**Sally Bergosh**: True dat!!

### CONVERSATION ON 08-01-2021

**Sally Bergosh**: https://www.wayfair.com/furniture/pdp/mercer41-daulton-20-wide-velvet-side-chair-w005404819.html

**Sally Bergosh**: https://www.wayfair.com/furniture/pdp/gold-flamingo-gregory-26-wide-tufted-velvet-side-chair-w001362479.html

**Sally Bergosh**: https://www.wayfair.com/furniture/pdp/andover-mills-euart-30-w-tufted-polyester-armchair-w004553505.html

**Sally Bergosh**: https://www.wayfair.com/furniture/pdp/lark-manor-mohn-29-wide-polyester-armchair-w005483167.html

**Sally Bergosh**: This is actually my first choice that would blend the blue couch with the grey kitchen & grey curtains!!

**Sally Bergosh**: https://www.wayfair.com/furniture/pdp/wade-logan-hoboken-38-w-tufted-polyester-armchair-w004899065.html

**Sally Bergosh**: This is on sale & would be amazing with the new couch, too! It’s also polyester so u could scrub it down between rental

**Sally Bergosh**: On way home!

**Jeff Bergosh**: Right on!  Love u

**Jeff Bergosh**: Drive safe— storming along I-10

**Sally Bergosh**: Big 4 car accident going the opposite 

### CONVERSATION ON 08-02-2021

**Jeff Bergosh**: Tristan towers thermostat this morning:

**Jeff Bergosh**: I just happened to speak with our head of public safety Eric Gilmore and he related to me that the hospitals are now up to 216 COVID-19 patients as of this morning.  (Friday it was 160) ——-It’s exploding geometrically at this point so be safe and stay away from people if u can!

Love u!!

Me

**Sally Bergosh**: Thank you for the great intel!:)

**Sally Bergosh**: Do u have a picture of B’s drivers license?

**Jeff Bergosh**: I don’t think I do but I’ll look.  

### CONVERSATION ON 08-03-2021

**Jeff Bergosh**: 
I’m falling asleep I can’t stay awake I love you I’ll see you when you come home❤️

**Sally Bergosh**: I’m in Clinic hell

**Jeff Bergosh**: Sorry 😫

**Sally Bergosh**: Volunteers are disappearing to Covid, Carol & Jim has another medical emergency today, my head nurse volunteer just left for her 3 week vacation in Oregon, My newly hired APRN is in Africa for another week & My hired facilitator of dental is home with COVID. I worked in every department today & now at 9:47 pm am working on my grant due Friday

**Sally Bergosh**: Pm

**Sally Bergosh**: Nicky- I will be available for dinner with you every night! We can chat when u get in to town Wednesday night! Love you!!❤️

### CONVERSATION ON 08-04-2021

**Sally Bergosh**: Look on Bell Ridge HOA

**Sally Bergosh**: Facebook page

**Jeff Bergosh**: What is it?

**Jeff Bergosh**: What happened?

**Sally Bergosh**: Turn lane to turn left from our subdivision is waaaaay too short! The ECUA garbage truck got smashed trying to turn left by a red car.....everyone is commenting that people are going to die using that exit strategy!!!!!

**Jeff Bergosh**: I’ll have engineering look into this.  Personally I think having that little Lane is safer than just having it an open space like over at Nature Trail. The problem is that garbage truck should never have pulled out unless it was clear both directions they will be charged and cited

**Jeff Bergosh**: And always remember Denise Watson has no friend of mine she constantly bashing me on citizens watch and also Kim Perdue has been known to do the same

**Sally Bergosh**: Who knows what REALLY happened but it’s all on Facebook HOA

**Jeff Bergosh**: Yes, I read it

**Jeff Bergosh**: He’s at the house rn

**Sally Bergosh**: Yay!! I’m on my way home!:) I do need a shower cuz I got called to clinic this am for an emergency

**Jeff Bergosh**: Okay I’m going to try to get out of here at 5

**Jeff Bergosh**: Where did u all go??

**Jeff Bergosh**: I’m at the table

**Sally Bergosh**: Walking 10 feet in front of us, so of course u didn’t notice that someone yelled out to us & I kept walking....not cool!!🙃

**Sally Bergosh**: You kept walking

### CONVERSATION ON 08-05-2021

**Sally Bergosh**: Hey, guys. Our new couch chairs for our new beach condo we’re delivered and sitting on front porch. Very heavy, but need to be brought in the house please, in case it rains later this evening. Very heavy- Nicky- u might need to go get Steve Woodcock👍

**Jeff Bergosh**: Thx Nick

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 08-07-2021

**Sally Bergosh**: Christie just sent this:

Double yippee!!! As I pointed out a bit earlier, you won’t be charged until Jan.3😊!

**Sally Bergosh**: So our all inclusive resort won’t charge us until Jan3, so I think we need to buy our airline tickets to Cabo ASAP

### CONVERSATION ON 08-08-2021

**Jeff Bergosh**: I’m our current guest! :-)

**Sally Bergosh**: That’s awesome but I thought we were going to raise our prices not offer discounts on top of the cheap price they are already getting!?!

**Jeff Bergosh**: I’ve already raise the rates for next year these last three guests are the final carryovers from Coreys low and pricing. Next year’s rates are significantly higher so we can afford to offer 10% to returning guests and still make more than we made this year.

**Jeff Bergosh**: They left a bunch of beers and stuff should I A. bring it home B. toss it out or C.  leave it for the next guest?

**Sally Bergosh**: Bring home- what if the next guests are anti alcohol?

**Jeff Bergosh**: True

**Sally Bergosh**: Not that I drink that kind of beer! Ugh

**Jeff Bergosh**: They also left a half a case of bottled water in the fridge should I leave that for the next guest?

**Sally Bergosh**: Yes!

**Jeff Bergosh**: They also bought and left beach toys in my closet :-)

**Sally Bergosh**: Hotels provide (2) complimentary bottled waters

**Jeff Bergosh**: These are the kind of guests I wanna cultivate

**Sally Bergosh**: 👍❤️

### CONVERSATION ON 08-09-2021

**Sally Bergosh**: Lol!!

**Sally Bergosh**: This is fantastic news, Nicky!!

**Sally Bergosh**: Make sure you give your dad 5 stars rating, Nicky!!

**Jeff Bergosh**: LOL

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: This morning’s model projections....

**Sally Bergosh**: Oh nooooo

**Jeff Bergosh**: So yeah, It might be Time to fill up the gas cans again

**Jeff Bergosh**: But hopefully it maintains that track which is east of us which would be a good thing

**Sally Bergosh**: Routine is counter creativity!!

**Jeff Bergosh**: ?

**Sally Bergosh**: Nicholas & I are having coffee together & want Hong Chef’s Table/ the creation of Alinea’s - #1 restaurant in the country!! This is just one of his quotes! Dream to be the BEST! I’m so mad we didn’t go with Susan Jason!!

**Sally Bergosh**: Watching The Chef’s Table

**Jeff Bergosh**: Oh, okay

**Sally Bergosh**: Who was Janice Gilley’s mentor

**Jeff Bergosh**: Jerry Maygarden

**Jeff Bergosh**: Why?

**Sally Bergosh**: Oh I was sharing a little about the Janice Gilley thing right now with Don McLoughlin from our BOD

**Jeff Bergosh**: Making a pasta dinner with garlic bread hopefully you can come home and join us love you!

**Sally Bergosh**: Oh thank you, Jesus!!

**Sally Bergosh**: https://www.wayfair.com/home-improvement/pdp/orren-ellis-leni-59-wall-mounted-double-bathroom-vanity-set-oris2036.html

**Sally Bergosh**: Do u like this one?

**Sally Bergosh**: https://www.wayfair.com/home-improvement/pdp/wade-logan-annice-60-double-bathroom-vanity-set-w005017863.html

**Sally Bergosh**: https://www.birchlane.com/bathroom/pdp/cape-cod-60-double-bathroom-vanity-set-bl23095.html

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: Still at base but leaving in 5

**Sally Bergosh**: We are just getting seats- no pressure & defintely no worries!:)❤️❤️

### CONVERSATION ON 08-12-2021

**Jeff Bergosh**: I forgot to get your check so I could deposit it into NFCU.  Do u want me to just move the money over and make it like payday today, and I’ll just deposit the check tomorrow morning?  Let me know, or I could just do it tomorrow morning.  Either way please bring the check with you when u come to the beach later today.  Love, me

**Sally Bergosh**: Yes- please deposit so I can mail my jewelry payment today & I’ll bring check to beach condo tonight

**Jeff Bergosh**: Will do.  Love u!

**Jeff Bergosh**: Okay, done 

You’re good to go.  Current balances 

Chk.   $1169.52
Sav.     $625.15

❤️ 

Me

**Sally Bergosh**: BTW- in all your mood swings I forgot to tell u I got a raise- 

**Jeff Bergosh**: Congratulations!!!! And whatever amount it was—-you’re worth double and your board and I and everyone else knows it!!!!!!

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: From Carolyn Grawi:

Hi Sally. I hope all is well with you. We have a request. Do you know where today (Thursday 8/12) there are free rapid covid tests? Carolyn Grawi

**Jeff Bergosh**: I’m in workshop for BCC is everything okay— I missed a call from u

**Sally Bergosh**: Yes- long story- we’ll chat when u can- Peeps are losing their minds over Covid right now!!

**Jeff Bergosh**: It’s blowing up

**Sally Bergosh**: Carolyn Grawi just brought over an ECSD bus driver & 2 peeps from her staff & they all tested positive & refuse to get vaccinated

**Sally Bergosh**: At my Clinics 

**Jeff Bergosh**: Why not get the shot???

**Sally Bergosh**: Everyone is frustrated that no one knows who is doing what right now for testing

**Sally Bergosh**: We need to have some county coordination- THAT is what u guys should be working on!! Not injustices of the world done to some end guy that sounds like he loves filing grievances since forever in his career in Escambia! I just finished reading that doc u sent over!!

**Sally Bergosh**: I’m calling around and finding out who is doing what right now!!

**Sally Bergosh**: This is from (850) 206-1326

Hey sally this is Leigh Berryman - is there anyway you can get your husband to give me a call today?  This is commissioner stuff.  Thank you.

**Sally Bergosh**: 206-3216!!

**Jeff Bergosh**: Okay

**Sally Bergosh**: Thank you! She is a big wig with tennis community

**Jeff Bergosh**: I’ll call her rn

**Sally Bergosh**: Thank you!

**Jeff Bergosh**: Our beautiful beach condo is now officially cleaned and ready for our 3night stay😎❤️👍

**Sally Bergosh**: Oh my.....that looks fabulous! I’m almost on my way! Do I need to stop & get some wine?

**Jeff Bergosh**: Sure!  I have Abita Strawberry

**Jeff Bergosh**: 😎❤️

**Sally Bergosh**: https://m.facebook.com/beachviewcondocleaningllc/

### CONVERSATION ON 08-13-2021

**Sally Bergosh**: https://m.facebook.com/beachviewcondocleaningllc/

**Jeff Bergosh**: Brennans gonna come out and join us Sunday!

**Sally Bergosh**: Loved “Brennans gonna come out and join us Sunday!”

**Jeff Bergosh**: Are you going to stop by the house before you come to the condo?  If so— grab a bottle of red wine and some snacks from the closet (plus your coffee creamer)

Love,

Me

**Sally Bergosh**: Yep- that’s the plan but I won’t be able to leave until 5

**Jeff Bergosh**: No worries.  I’m going to stop on way and grab us some goodies as well 😎❤️👍

### CONVERSATION ON 08-14-2021

**Jeff Bergosh**: Pastor Ron asked to see our condo after the match at 9:45 so just please be dressed.  Love me

**Sally Bergosh**: I’ll be leaving before then to do vaccinations at PSC

**Jeff Bergosh**: Ok thx

**Jeff Bergosh**: Just finished

**Sally Bergosh**: On my way to condo!

**Jeff Bergosh**: Awesome!  I just got back and I brought the bikes

### CONVERSATION ON 08-16-2021

**Jeff Bergosh**: Do we still have the breakfast for Gulf Coast kid’s House this Wednesday morning at 7:30?

**Sally Bergosh**: No- it was cancelled!!

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 08-17-2021

**Jeff Bergosh**: I made homemade chicken noodle soup for dinner tonight and it’s amazing ——-love you. ❤️❤️

**Sally Bergosh**: On way home

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: Starting to fade and fall asleep.  Big day tomorrow with 6:00AM Bible Study,  Love u, see u when u get home!  ❤️❤️❤️❤️. Me

**Sally Bergosh**: Love you- just finishing up

### CONVERSATION ON 08-20-2021

**Sally Bergosh**: Hey!! Did u remember to plug our upcoming Christmas Gala and sponsorship with Andrews Foundation?

**Jeff Bergosh**: Still here

**Sally Bergosh**: Yaaaaaay!! Come on Ashton- hook us up!!

**Jeff Bergosh**: He said he would.  He mentioned Nix Daniel and he was aware Nix is on the board.  He told Nix he was having lunch with me today.  Small world 😎👍

**Jeff Bergosh**: ....... don’t want to look desperate

**Sally Bergosh**: Okay.....thank you!!❤️

**Jeff Bergosh**: ❤️❤️👍👍

**Jeff Bergosh**: Sally I stopped at the store on the way to the condo I’m on the way to the condo right now. I got dinner for tonight breakfast for tomorrow treats champagne orange juice snacks and even your coffee creamer so we’re good to go. I love you and I’ll see you later at the condo

**Sally Bergosh**: Loved “Sally I stopped at the store on the way to the condo I’m on the way to the condo right now. I got dinner for tonight breakfast for tomorrow treats champagne orange juice snacks and even your coffee creamer so we’re good to go. I love you and I’ll see you later at the condo”

### CONVERSATION ON 08-21-2021

**Sally Bergosh**: So JD & Sara are coming between 5-6 pm. They r bringing a nice bottle of champagne to cheers the new condo & then we can go to dinner after cocktails!:)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Brining the bikes too so we can go for a ride befor John and Sara get here 😎👍

**Sally Bergosh**: Perfect!!

**Jeff Bergosh**: Almost there ❤️👍

**Sally Bergosh**: Yay!! Love you!!❤️

**Sally Bergosh**: I’m on the patio enjoying sun, book & champagne!

### CONVERSATION ON 08-23-2021

**Jeff Bergosh**: Falling asleep soon — can’t stay awake.  Love u and I’ll see u when u get home.  Love, me ❤️❤️

### CONVERSATION ON 08-24-2021

**Sally Bergosh**: Of course, it was changed to Tuesday, August 24th!

**Jeff Bergosh**: That’s today

**Sally Bergosh**: Yes

**Jeff Bergosh**: Today’s date is 8-24

**Sally Bergosh**: I know-if u read the invite it had said Monday, August 24.....of course we know that’s Tuesday

**Jeff Bergosh**: Oh okay.  Do u think they had it last night??

**Sally Bergosh**: Noooooooo- I sent u their email that says it is TUESDAY

**Jeff Bergosh**: I get that— but did they mean Monday night and d just screw up the date??

**Jeff Bergosh**: We don’t want to show up and they said— “Yeah, we said it was Monday.”

**Sally Bergosh**: I’m forwarding you AGAIN their latest email to gmail- please read & then don’t go cuz I’m tired of fighting u on this 

**Jeff Bergosh**: I’m going!

**Jeff Bergosh**: On way there

**Sally Bergosh**: Just now leaving my office

**Jeff Bergosh**: K I’m here 

**Jeff Bergosh**: The others are here also— I’m parked outside the compound and I’ll wait for u

**Sally Bergosh**: I’m stuck at light on Bayou & 12th

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: 😀

**Jeff Bergosh**: Falling asleep.... love u!!! See u when u get home❤️❤️

### CONVERSATION ON 08-26-2021

**Sally Bergosh**: Hey why did you tell dad that this dog is coming sooner?? He literally woke me up and is pissed off for literally no reason at 9am .. stop spinning dad up. Stop telling dad crap that you know will get him spun up

**Sally Bergosh**: That was Tori’s text

### CONVERSATION ON 08-27-2021

**Jeff Bergosh**: Intense rain thunderstorms and lightning are coming through right now: they’re going from east to west and just went through the base , now headed north word to the I 10 area where you’ll be driving so be extra careful driving to work until this goes through. Love you❤️

**Sally Bergosh**: Love you right back! Obviously tennis in OB was cancelled so I’ll head into work. Tori came home & told me all her troubles were MY fault cuz u told her I called u yesterday AM & got u all spun up about her dog coming early. She then ran over & took my phone & looked at the call list cuz she knew I had called u yesterday in the AM. I explained u erupted all on your own & that u called me. She threw my phone down & said she was beyond tired, cramping & was going to bed.

**Sally Bergosh**: Remember, Jeff.....when u erupt there are often unintended consequences. I now have a daughter that hates me & I believe will be moving out very quickly. This could alter her route in life.....

**Jeff Bergosh**: She doesn’t hate you. She must be held accountable When she is blatantly disrespectful

**Jeff Bergosh**: Like we discussed this morning it doesn’t appear that she’s paying down debt it appears she saving money on rent and playing and planning trips and purchasing things we don’t want to be enabler’s and oh by the way she’s not in school and can’t be bothered to find a time to complete her test

**Sally Bergosh**: Speaking of careless spending.....look what just arrived from FEDEX- another package for Tori

**Jeff Bergosh**: Hey Sally I’m here at the unit I’ve been here about an hour and a half and I’ve just about got it totally clean I’m sweeping and just about ready to mop I’ve got all the bathrooms and the kitchen cleaned up so on my way here I stopped and got a bunch of snacks and dinner for us so come on down love you

**Jeff Bergosh**: ❤️❤️❤️

**Sally Bergosh**: Love you right back.....glad u don’t sound grumpy tonight!❤️

### CONVERSATION ON 08-28-2021

**Sally Bergosh**: I see u r at home- can u make sure u move stuff from washer to dyer? Thank u!:)

**Sally Bergosh**: Where r u?!!??????

**Jeff Bergosh**: Just got here I’m bringing up your blue chairs right now

**Sally Bergosh**: ❤️❤️❤️

**Jeff Bergosh**: Just got done taking the couch to the dump I’m at Gary’s house helping him move all his patio furniture then I’ll be heading back that way love you

**Sally Bergosh**: U owe me a nice date night!!

**Jeff Bergosh**: I will I’m at Publix text me your list

**Sally Bergosh**: Yes

**Jeff Bergosh**: Shish Kebabbs, Caesar Salad, Rice Pimaf

**Jeff Bergosh**: Pilaf

**Sally Bergosh**: Drumsticks or chocolate cake from frozen

**Jeff Bergosh**: K

**Sally Bergosh**: Love you & wishing u the BEST adventure ever!! ❤️❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: Love!!

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Yes It hit about 250 miles to the west of us so we got some wind and rain but we’re OK

**Sally Bergosh**: Oh my!! Take lots of photos!

**Sally Bergosh**: Pretty awesome!!

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: Hey Sally—drive extra careful today it’s windy and rainy and it was kind of a mess getting to work. Also Kevin Adams Michelle Salzman and I are canceling our event this afternoon however Michel has stated that she is still having the mental health task force meeting. Drive safely love you❤️

**Sally Bergosh**: Love you- everyone from the clinic is calling about weather we should be open or not.....is it bad out there? In Pensacola?

**Jeff Bergosh**: Yes it is

**Jeff Bergosh**: The counties close the school district is closed you might consider closing for the day it’s gonna be difficult for people to get there with the wind

**Sally Bergosh**: I’m glad I went to the meeting, but I’m like hunched over & in so much pain!! Ugh

**Jeff Bergosh**: I’m sorry u don’t feel good... you should go in to be seen

**Jeff Bergosh**: On my lunch break I went to Wal mart to get some things for us at the condo;  I got the HDMI cables, fingernail polish, laundry detergent, Diet Coke, paper towels, toilet paper, and a replacement can opener 🙂

**Sally Bergosh**: Perfect- thanks! The hair dryer wouldn’t work this morning! Ugh! Always something! I

### CONVERSATION ON 08-31-2021

**Jeff Bergosh**: Let me know and if so I’ll go by there today and they’ll put my they’ll put the money back on my card and we can start all over

**Sally Bergosh**: Refund

**Jeff Bergosh**: I’m trying to stay awake but I’m falling asleep I love you I’ll see you when you get home to the condo!

❤️❤️

**Sally Bergosh**: Love you right back! Heading home now- got a lot done for the clinic today!:)

**Sally Bergosh**: Worst of hurricane is happening now- big showers, heavy winds, tornadoes popping up, etc

**Sally Bergosh**: More pictures please!

### CONVERSATION ON 09-01-2021

**Jeff Bergosh**: We could get it by Wednesday, free shipping

**Sally Bergosh**: Sold!:) The lighter color please!

**Jeff Bergosh**: I’ll order it right now are you cool with that it’s light gray

**Sally Bergosh**: Perfect

**Sally Bergosh**: Hopefully this is their Labor Day sale price- 

**Sally Bergosh**: You’re on a roll- see if u can find our kitchen table that is not high seating

**Jeff Bergosh**: Okay I will

**Sally Bergosh**: Grey or wood or that walnut with white like our tv console & coffee table

**Jeff Bergosh**: Done

**Sally Bergosh**: I have been feeling so much better and then I had my morning coffee with CREAMER & am sick again!! I wonder if that small creamer went bad?

**Jeff Bergosh**: I doubt it— But toss it just to make sure I’ll get another one

**Jeff Bergosh**: I want to get this one!  It’s perfect, off white and grey cushions.  We can get this-and the couch I just got- both for less than the one couch at Rooms to Go!!

**Sally Bergosh**: Noooooo- it’s off white & will clash with the table & console- keep looking

**Jeff Bergosh**: Okay

**Sally Bergosh**: Nope- grey, wood or white

**Jeff Bergosh**: This one?

**Sally Bergosh**: Hmmmm- I like the bench one better

**Jeff Bergosh**: That’s Dawn’s email 😎👌

**Sally Bergosh**: Do u need anything from Walgreens?

**Jeff Bergosh**: Q-tips please❤️❤️❤️

**Sally Bergosh**: That’s so weird- I just put those in my cart!:)

**Jeff Bergosh**: LOL that’s awesome

### CONVERSATION ON 09-02-2021

**Jeff Bergosh**: I remember that one

**Sally Bergosh**: R u at the condo yet? I can either start a new project right now or come home. I don’t want to race to the condo if u r just going right to bed

**Jeff Bergosh**: Still in BCC meeting

**Sally Bergosh**: Will u text me when it’s ending- not when u r in your car, but when the meeting is ending?

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Okay— done and heading to the house to get mail, then the condo.  Love u!  And oh, by the way, we voted to censure Doug’s ass tonight for his shitty treatment of staff.  4-1 vote.  I made the motion 😎😎

**Sally Bergosh**: Yes!!👍

**Sally Bergosh**: When u get to the house, can u grab me some clothes? I’m out of work clothes. I can tell u where everything is when u get there just call me

**Sally Bergosh**: This brings tears to my eyes!!😢😘

**Jeff Bergosh**: Sad and bittersweet

**Jeff Bergosh**: 6352. Bicycle combination 

**Sally Bergosh**: Where are your pictures, Tori from Chicago? Are you in Oregon yet at Manny’s wedding?

### CONVERSATION ON 09-03-2021

**Sally Bergosh**: I’m playing hooky today with Teri Aulger at the condo- beach side!

**Jeff Bergosh**: Right on!!!

**Jeff Bergosh**: Use the new beach chairs!

**Sally Bergosh**: I told my office manager that I was working from home today🥂

**Jeff Bergosh**: 👍

**Jeff Bergosh**: “Tele-working”

**Sally Bergosh**: Yes!

**Jeff Bergosh**: 👍

**Sally Bergosh**: I went downstairs to put our # on the bikes & u had already taken care of it!:)

**Sally Bergosh**: Are u at the house again?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Stopped to get our dining room table that arrived 

**Sally Bergosh**: Will u grab my refrigerated Wagu pins in the vegetable drawer?

**Jeff Bergosh**: Now I’m headed to Wal mart to grab food for us for dinner

**Sally Bergosh**: Noooo- I want u to take me to Peglegs

**Sally Bergosh**: Date night

**Jeff Bergosh**: That’s tomorrow— we’re going to angelinas

**Sally Bergosh**: Terry left to beat traffic

**Jeff Bergosh**: Cannot tonight please be a relaxed night

**Sally Bergosh**: Yes

### CONVERSATION ON 09-06-2021

**Sally Bergosh**: On way back!:)

**Jeff Bergosh**: Kin epic bike ride.  I’ll turn around

**Sally Bergosh**: I’m on my way- really this time!  Are u at Portofino!

**Sally Bergosh**: Guess where I am?!


**Jeff Bergosh**: Guess where I am?

**Sally Bergosh**: Beach!! R u sti there? Should Tori & I come see u?

### CONVERSATION ON 09-07-2021

**Sally Bergosh**: So Brittney Cruise just had the same thing happen to her glass front door & asked for recommendations on Beulah Scoop- here is what we found out:

Yes, it can be replaced. The cost for that window will likely exceed the cost to replace the entire door from the hinges. We've had replacements range from $250-$1000 depending on the glass, designs etc.
Both panes will have to be replaced as if only 1 is, it will condensate and fog until the entire glass is white fog.

**Jeff Bergosh**: Okay So we won’t waste money doing that!

**Sally Bergosh**: We will just replace the entire door- ugh! If I get home early enough can we take a stab at doing a newsletter?

**Jeff Bergosh**: Yes- but full disclosure I’m starting to not feel well.  I didn’t do my walk today— just feeling unwell and it’s worsening as the day goes on.  I’m supposed to have first budget workshop at 5:30 but we’ll see how I’m feeling.  I may need to take Tylenol and go to sleep early

**Sally Bergosh**: I need u to go to your budget workshop for health & hope clinic- take an aspirin & u can still go to bed early tonight. I love you- do u think it’s COVID

**Jeff Bergosh**: Don’t know.  This isn’t final mtg.  So I want to be cautious.  Final is later this month.  H&H is on the list for 30K— good to go.  I just want to play it safe— especially since this isn’t a final

**Sally Bergosh**: What r ur symptoms?!

**Jeff Bergosh**: Cold clammy, a little dizzy and nauseous

**Jeff Bergosh**: Just not right— you know?  You know when something’s not right.  So we’ll see how I’m feeling over the next few hours.  I’ve also got my coffee tomorrow so that will happen no matter what as it’s virtual

**Sally Bergosh**: I’m sorry u aren’t feeling well. I wonder if it’s cuz we were out & about over the weekend! Check in with your bro - we were just around all of them

**Jeff Bergosh**: Also sore throat on one side

**Jeff Bergosh**: I will

**Sally Bergosh**: I can have u tested after 3 days of symptoms.

**Jeff Bergosh**: Ok

**Jeff Bergosh**: Meeting at 5:30 will go on without me more than likely

**Sally Bergosh**: Gotcha!

**Jeff Bergosh**: 😐👍

**Jeff Bergosh**: Negative for COVID. 🙂

**Sally Bergosh**: Oh good/ 3-5 days of symptoms for it to pop up-

**Jeff Bergosh**: I took Tylenol— taking it easy and going to bed early

**Sally Bergosh**: If u r only day 1 of symptoms- I would have advised to do the test on Th or Friday

**Sally Bergosh**: Gotcha! Love you!! 

**Jeff Bergosh**: I think I might’ve overreacted

**Jeff Bergosh**: Love you the most

**Sally Bergosh**: About the dog? I agree!! Lol! Guys tend to be more over reactive about illness!!😂

**Jeff Bergosh**: LOL

**Jeff Bergosh**: LOL

**Sally Bergosh**: That is so sad

### CONVERSATION ON 09-08-2021

**Jeff Bergosh**: Just emailed u first rough draft ❤️😎👍

**Sally Bergosh**: Hold a spot for my volunteer highlight! She is getting me her interview & picture tomorrow!:)

**Jeff Bergosh**: Okay will do

**Sally Bergosh**: I sent u a couple of edits suggestions- I totally missed your calling- looks great!❤️

**Sally Bergosh**: How are u feeling?

**Jeff Bergosh**: I feel great, heading to bed soon though.  Love u, will make the edits ❤️❤️

**Sally Bergosh**: Best Buy for the Ring!! 

**Sally Bergosh**: ?!?

**Jeff Bergosh**: Yes

**Sally Bergosh**: Thank you. I’m getting out right now! Love you!!

**Jeff Bergosh**: Love u most!!

### CONVERSATION ON 09-09-2021

**Jeff Bergosh**: He wishes he was still 27 LOL

**Sally Bergosh**: Lol!! Blond moment- lol

**Jeff Bergosh**: 😀👌

**Sally Bergosh**: Yay!! He’s alive!!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Hey for the multi factor authorization I think you need to have it on your cell phone Sally that way if I’m working on the newsletter I can get it from you Madison may not be available and if it’s under her name we could be stuck waiting so put your cell phone number in there that way even if I’m working remotely I can text you and ask for it and it won’t slow us down

**Sally Bergosh**: This is our highlight Volunteer of the month!!

**Jeff Bergosh**: 👍

**Sally Bergosh**: I sent you her interview

**Jeff Bergosh**: Okay thx I’ll add it

**Jeff Bergosh**: I’m heading to the house because our couch arrived in a box and it’s too heavy for Tori to move so I’ll grab it and throw it in my truck do you want me to get your statement for the jewelry if it’s there or anything else while I’m there? Just text me if you do I’m gonna head that way in about 10 minutes

**Sally Bergosh**: I was teaching an orientation class with a bunch of new volunteers!! I’m headed towards Publix on 9 Mile to get meds- do I have that card or do I need to swing by the house & get it?

**Jeff Bergosh**: I just updated the newsletter and added the demographic information from your email I just sent it to you I think it looks pretty good but let me know love you ❤️❤️

**Sally Bergosh**: So how does our couch look?

**Jeff Bergosh**: I don’t know I haven’t put it together yet there’s no room for it I’ll have to wait till we move the other couch first

### CONVERSATION ON 09-10-2021

**Jeff Bergosh**: I just transferred the money into your checking for paying off the jewelry bill $601.24

**Sally Bergosh**: Got it!:)

**Jeff Bergosh**: Hey I was just texting back and forth with Nicholas do you have any interest in going to see him in mid November? I found some tremendous prices on flights if you’d like to do it we could set it up if you can get away from the clinic for a couple of days

**Jeff Bergosh**: Like Thursday through a Tuesday

**Sally Bergosh**: My event is November 30th! How about EARLY December

**Jeff Bergosh**: October?

**Jeff Bergosh**: We’ll look at calendar together

**Sally Bergosh**: How about October 7-11

**Jeff Bergosh**: I’ll look at flights

**Sally Bergosh**: Book it!! I’m all in!!:)

**Sally Bergosh**: Be sure & give Nicholas those dates ASAP

**Jeff Bergosh**: Already did

### CONVERSATION ON 09-11-2021

**Jeff Bergosh**: That opens the box and the key to the lock is inside

### CONVERSATION ON 09-12-2021

**Sally Bergosh**: Okay......where r u?!!?

**Jeff Bergosh**: 👍👍

**Sally Bergosh**: Hey, everyone!! Grandma & Boppa are really looking forward to their vacation in Pensacola starting THIS Wednesday night at 6 pm! They will be here until the following Wednesday, 9/22. Please make an effort to free yourselves up & spend some quality time with them. We will all be staying at the beach condo! Your dad & I have been fixing it up all weekend. Sunday dinner is at 6:30 pm tonight! Try to come!❤️❤️

**Sally Bergosh**: Liked “Bobby sent the email!!  💕”

### CONVERSATION ON 09-13-2021

**Sally Bergosh**: Madison is trying to get into constantcontacts & needs an authentic I still Code

**Sally Bergosh**: Authentication code

**Jeff Bergosh**: Okay I haven’t got one yet 

**Jeff Bergosh**: Then when I get it I’ll forward it to you

**Sally Bergosh**: Gotcha

**Jeff Bergosh**: Constant Contact: Your verification code is 890504.  This code is valid for 5 minutes.  We'll never contact you to ask for this code.

**Jeff Bergosh**: Just got this second one 

**Sally Bergosh**: There is a big problem that I have forwarded to you in Facebook messenger- it’s just starting to gain momentum so now would be a good time to address the concern.

**Sally Bergosh**: It’s on Beulah Scoop & other forums

**Jeff Bergosh**: Okay I’ll check it out ..  love u!  Going to bed, see u when u get home

### CONVERSATION ON 09-14-2021

**Sally Bergosh**: Hey- try & remember to send me the newsletter with changes so we can send it out into the world this afternoon- anytime between 10-2 they say is best for newsletters

**Jeff Bergosh**: Will do I just didn’t know if you still wanted the section in there about O’Briens

**Jeff Bergosh**: I’m on the radio right now with Andrew MCKay on a M 1620

**Sally Bergosh**: It’s fine!:)

**Jeff Bergosh**: See how these meetings drag out????

**Jeff Bergosh**: You’re good

**Sally Bergosh**: K

**Jeff Bergosh**: Love u

**Sally Bergosh**:  I am in my car now but I was so paranoid to text after what happened in past with peeps over peeps shoulders.......you kept saying “we” and it’s funny Doug called u out.  Try to remain “honorable” with interactions with DOug. It makes u look small when u say things as bad as he does. You want to stay above the fray-

**Jeff Bergosh**: Our texts are not public record

**Jeff Bergosh**: As you saw

**Sally Bergosh**: Yes- but fight like hell to rise above the hate

**Jeff Bergosh**: Difficult

**Sally Bergosh**: I hate that u were having to draw a red circle around H& H. I wanted to fly under the radar

**Jeff Bergosh**: You did 🙂👍

**Sally Bergosh**: Of course I appreciate your advocacy

**Jeff Bergosh**: 😎

**Sally Bergosh**: Did u send out the newsletter?

**Sally Bergosh**: Make sure u hit “all” as we are adding everyday to community & general interest

**Jeff Bergosh**: Doing it in 5 min

**Jeff Bergosh**: I’ll proof it one last time first

**Sally Bergosh**: By the picture of the cross please put the following: An important part of what this clinic does is offer HOPE to our patients. In the month of August we engaged with 99 patients through prayer, engaged in 9 gospel conversations & had 3 salvations. A special THANKS to our wonderful Encouragement Team that every day before every clinic offers words of hope & prayer with our volunteers! 

**Sally Bergosh**: This is what Mike said about Tori’s direction:

Do the bridge program - this is a great guaranteed opportunity to get to the Bsn 

**Sally Bergosh**: If she retakes the hesi and passes then she can apply for the nursr program and just not
Complete lpn 

**Jeff Bergosh**: Okay I’ll let her know

**Sally Bergosh**: Tell her to do the Cares App now / we can pay for all her tuition 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Just sent the newsletter 😎👍

**Sally Bergosh**: Thank you!!❤️

**Jeff Bergosh**: 👍👌

**Sally Bergosh**: Tori wants to see if we can plan to go to nice dinner Sat night with my mom & dad instead of Fri night?

**Jeff Bergosh**: Okay well can we discuss that?  I thought we’d go to dinner Friday and have a barbecue cook out at the condo Saturday

**Sally Bergosh**: At my hair appointment

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Tori is good for Friday at 6:30’for dinner— so I’ll make the reservation for 6:30 for you, me, Tori, Brandon, and your Mom and Dad for dinner Friday

**Sally Bergosh**: Tori said she would make it work no matter what we do- she has the weekend off but has appointments all afternoon & evening on Friday. She said she would make it work whatever we come up with

**Sally Bergosh**: Thank u- that’s perfect

**Sally Bergosh**: They always love McGuires, too

**Jeff Bergosh**: Saturday afternoon-early evening I want to do a cookout and invite my aunt Mary to come out if that’s cool?

**Jeff Bergosh**: Saturday cookout at 3:00 okay with you?

**Sally Bergosh**: Sure

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Now we just have to find a place to have dinner Friday maybe we can do Mcguires on Friday?

**Sally Bergosh**: Or Flounders! Great atmosphere

**Jeff Bergosh**: Okay I’ll do that for Friday 🙂👍

**Sally Bergosh**: Have I told u how much I love you?!?

**Jeff Bergosh**: Love u most!

**Sally Bergosh**: Oh mannnnn! Just looked at weather forecast for when mom & sad are here & it’s supposed to rain all weekend!:(

**Jeff Bergosh**: Not the whole time I don’t think

**Jeff Bergosh**: I love you I’m heading to bed I’ll see you when you get here ❤️❤️

**Jeff Bergosh**: Wow!  That’s sad

**Sally Bergosh**: So sad!!:(

### CONVERSATION ON 09-15-2021

**Sally Bergosh**: It’s getting pretty windy on our balcony. Do u think I should bring in the bbq or chairs in our room?!

**Jeff Bergosh**: I don’t think you need to

**Jeff Bergosh**: They’ll be fine

**Sally Bergosh**: The blue chairs already blew into the bbq which got my attention

**Jeff Bergosh**: Maybe just stack the blue chairs

**Jeff Bergosh**: Constant Contact: Your verification code is 259786.  This code is valid for 5 minutes.  We'll never contact you to ask for this code.

**Sally Bergosh**: Did u send to Mike?

**Jeff Bergosh**: No— what’s his number

**Sally Bergosh**: Mike Kenney 

**Sally Bergosh**: I’m assuming

**Sally Bergosh**: Based on his email yesterday

**Jeff Bergosh**: Okay I have his number

**Sally Bergosh**: Bam! Don’t get too excited, PNJ will just say u guys are bullies!😡

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Did u read it though?!?  Pretty damning

**Sally Bergosh**: I totally agree

**Jeff Bergosh**: I’m cleaning our house right now

**Sally Bergosh**: Love you!!❤️❤️

**Sally Bergosh**: I’m heading over at 3 pm for George’s to do vaccines for the community. Their plane arrives at 6 pm but they are supposed to call me from Atlanta when they know if things are running on time

**Sally Bergosh**: AT&T Free Msg: August bill processed. Thanks, Sally! Here's a little freebie for you: l4bsn.info/C2Lx3oh6GW

**Jeff Bergosh**: Drying the couch now

**Sally Bergosh**: How is our couch looking?!! 

**Jeff Bergosh**: It looks clean.  Turned out good

**Sally Bergosh**: Lol!!

**Sally Bergosh**: Loved an image

**Sally Bergosh**: More importantly, do u like my new plant?

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: We just passed the $1.3 Million Commitment to upgrade Roger Scott — unbelievably it was unanimous.

**Sally Bergosh**: Wow!  Our tennis community will be thrilled!❤️

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Finished meeting on way back

**Sally Bergosh**: We are done looking at the new kitchen in Beulah. Are u hungry and want to meet somewhere for a light appetizer & drink?

**Jeff Bergosh**: Peg leg Pete’s?

**Sally Bergosh**: Sure

**Sally Bergosh**: Get a head start and get our name on the wait list

**Jeff Bergosh**: I’ve got to go home and change my suit so you’ll probably beat me there

**Jeff Bergosh**: Oh it looks like Peg leg Pete’s is closed we need to go to a Plan B

### CONVERSATION ON 09-17-2021

**Sally Bergosh**: Baltic Sea 

**Sally Bergosh**: Boppa told me to write that! Lol! I think he was half 💤 

**Sally Bergosh**: Yes and rain storm😂

**Sally Bergosh**: So you’re headed to Germany?!? How FUN!!

**Sally Bergosh**: How exciting! Just remember to fit in some studying!👍

**Sally Bergosh**: 🤔 hmmmmm

**Sally Bergosh**: Laughed at “Wow— no passport—-sounds like America’s southern border LOL”

**Sally Bergosh**: Lunow, Germany near UR River which is Northeast of Berlin is where grandma’s father side of the family is from!! Go see the Berlin Wall!!

**Sally Bergosh**: Grandma & Boppa’s favorite place in all of Europe is Herrenchimsee (Man Island)- lake looks like an ocean - near Munich & border of Austria!

**Sally Bergosh**: Near Lake Chimsee

### CONVERSATION ON 09-18-2021

**Sally Bergosh**: This from Tori:

**Sally Bergosh**: https://setup.icloud.com/family/messages?aaaction=showFamilyInvite&inviteCode=EFI_6bb2jXDHF8S6BQrjBhdMvBP_nv19XzdMgo6pEqo-g6ifL-43TBVGxxodW0x0rgi_R03QNgCplJsaEkJZCug0D83A17BOdi5asDfaf6FRgtYDNlhC7Undd4w_3V8YeGCBALdhSpSFsoiZUFJU4BRQfsZETr34UvR419Wn2S6v0ooq5dSAb0hO60FT1Qv6UT3d0YCWj74tXp_2ULLcBuxb_WxXZnmuolJqnCl5rYuWVnGBRuFIVblfqfRYZIcJGENWNmrInaVDW0ryNbGqUVLiJ_WV4zTo_FavFbPW&clientAppContext=TVChannels&actionUrlKey=acceptFamilyInvite.v2

### CONVERSATION ON 09-19-2021

**Sally Bergosh**: Miss u guys!!

### CONVERSATION ON 09-20-2021

**Sally Bergosh**: My meeting is 4-5 pm and then I’ll rush to the condo & then we can all go to McGuires

**Jeff Bergosh**: Okay I’ve got reservations at 6:00 in the tap room ❤️👍😀

**Sally Bergosh**: K

**Jeff Bergosh**: Do u want us to meet u there?

**Sally Bergosh**: I’m leaving right now

**Jeff Bergosh**: 👍

**Sally Bergosh**: Here!:)

**Sally Bergosh**: Today!!??!!

**Sally Bergosh**: Beach condo lazy days!!❤️

### CONVERSATION ON 09-21-2021

**Sally Bergosh**: We are at Flounders in IPC if u get out of your meeting anytime soon - just text us when u r heading back

**Jeff Bergosh**: It’s running long.  Have fun👍🙂

**Jeff Bergosh**: Better?

**Sally Bergosh**: We are doing great- miss u!!❤️

**Jeff Bergosh**: Remember to put this on our number ——294

**Sally Bergosh**: Duhhhhhh😇

**Jeff Bergosh**: LOL

### CONVERSATION ON 09-22-2021

**Sally Bergosh**: Really?! Your mailbox is FULL?!!? Bad- u r an elected official and what u r telling your community is that u r too busy to help them so they will not re-elect u!:( I am trying to get a hold of you/ please call me!!

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: Shelf is in!

**Sally Bergosh**: That’s awesome!!

**Jeff Bergosh**: I’m going to finish it Saturday morning.  I got a lot done today here at the condo❤️👍

**Sally Bergosh**: I’m impressed. I’m still putting out fires- more peeps tested positive for COVID- key people- I’m almost finished.😩

### CONVERSATION ON 09-24-2021

**Sally Bergosh**: Just trying call u! U DO want me to close screens before leaving and turn air on? It’s so nice and cool- sure I can’t just leave as is?!

**Jeff Bergosh**: U can just leave it as is and I’ll turn it on when I get home

**Jeff Bergosh**: I’ll call u right back after this phone conference I’m on

**Sally Bergosh**: I’m leaving- I’ll leave screen doors open

**Jeff Bergosh**: I just missed your call and tried to call you back

**Jeff Bergosh**: Come home boxer!  The weekend is starting!!

**Sally Bergosh**: Ummm- I had to pick up my (10) gift cards from Nail Lounge, so of course I had to get a pedicure! Lol😂

**Jeff Bergosh**: LOL I guess I need one too

**Sally Bergosh**: Yes!! I’ll be there about 6:15 pm ish!

**Jeff Bergosh**: 👍👍😎❤️

**Jeff Bergosh**: Okay I’m starting dinner

**Sally Bergosh**: I’m on the interstate

**Jeff Bergosh**: LOL looks good

**Sally Bergosh**: I used to crave those at University of Arizona in Tucson. They had a place that would deliver!! Delicious but really, really bad indulgence! Enjoy now with your metabolism!! 😂

**Sally Bergosh**: Loved an image

### CONVERSATION ON 09-25-2021

**Jeff Bergosh**: Are u on way back yet??  Day is 🔥 burning

**Jeff Bergosh**: I’m making a picnic lunch for us to take across the street to the 🏖 🙂🙂👍👍

**Sally Bergosh**: Have I told u I love you today?!!? I’m on interstate heading your way!!❤️❤️

**Sally Bergosh**: Here

### CONVERSATION ON 09-26-2021

**Sally Bergosh**: Have they picked a name?! Absolutely beautiful, healthy baby!! Mom & dad look pretty happy, too

### CONVERSATION ON 09-27-2021

**Sally Bergosh**: Replacing bulky built-in tubs with streamlined freestanding ones rejuvenates these bathrooms

**Sally Bergosh**: https://www.houzz.com/magazine/before-and-after-5-bathroom-remodels-that-free-the-tub-stsetivw-vs~152718609

**Jeff Bergosh**: But they are in anachronism nobody uses them so I build one? We use the shit out of our closet we need a bigger one we use the hell out of the shower let’s make a great one if I need a bath I can use the kids bathroom

**Jeff Bergosh**: I’ve literally use that bathtub three times since 2004

**Sally Bergosh**: Look at the 1st remodel before & after. It’s almost our exact same scenario minus the closet. Dark brown walls, bulky   Built in tub & shower- I love the “after” results! Light & airy

**Sally Bergosh**: Don’t forget about Jackie Summers classroom today!

**Jeff Bergosh**: I have it on my calendar👍😎👌

**Sally Bergosh**: Can u send me the stuff Jackie sent u to my health & hope email? She has not sent me anything and I’ve lined up a dentist & hygienist for tomorrow

**Jeff Bergosh**: Just forwarded it to you ❤️👍

**Sally Bergosh**: Thank u!

**Jeff Bergosh**: 👍❤️👌

**Jeff Bergosh**: Sally I’m falling asleep.  I got a lot done today at the condo.  I miss u and I’ll see u when u come home.  Love you!! Come home soon boxer!!❤️❤️

**Sally Bergosh**: Will do!

### CONVERSATION ON 09-28-2021

**Jeff Bergosh**: Sally—I already RSVP’d for us to attend this for Michelle

**Sally Bergosh**: I’m trying not to get offended that she goes after every name in town except yours for this invitation......🤔

**Jeff Bergosh**: I’m not

**Jeff Bergosh**: There’s a lot of pressure on the hosts to round up money

**Sally Bergosh**: Gotcha! It lets u know who is wanting “favor” from Michelle

**Jeff Bergosh**: Right

**Jeff Bergosh**: Any word on when Donna flies in??

**Sally Bergosh**: Yes, 6 pm. Tori is on standby but it looks like my tennis match is going to be a rain out! What do u think?!

**Jeff Bergosh**: Yes— looks like it might be a wash out

**Jeff Bergosh**: It looks like you might be playing after all the clouds are clearing in East Pensacola by the tennis courts will Tori just bring Donna to your match?

**Sally Bergosh**: I guess

**Sally Bergosh**: My match just got delayed until 7 pm

**Sally Bergosh**: Perfect- thanks, PC!!❤️

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Love u

**Sally Bergosh**: Love you right back! Tori is a bitch! I’m done with her once & for all! Everything that comes out of her mouth to me is hateful & mean & sarcastic!!

**Jeff Bergosh**: What happened?

**Jeff Bergosh**: Going to bed love u!  Have fun with Donna, see you all when u get home❤️❤️

**Sally Bergosh**: Love u right back!!❤️❤️

### CONVERSATION ON 09-29-2021

**Sally Bergosh**: Love you, PC! Thanks for coming to my aid this morning!! I’m back in action with my phone. U were right - the manager was there & said I could come get it early! Now I have a rain make- up at 1:00 pm😂

**Jeff Bergosh**: Love you— glad you got it sorted out.  Good luck in the match!

**Jeff Bergosh**: Sally don’t drink and drive no matter what you do. I’m going to be leaving work here in a few minutes and I’m gonna head to the house to unload all the stuff in my truck. Then I’m going to head back to the beach if you all need a ride I can pick you up and drive you to the condo and we can pick up your car in the morning. Just let me know if you need a ride if you’ve been drinking. Love you❤️❤️👍👍

**Sally Bergosh**: Love u right back!!❤️

**Jeff Bergosh**: ………so, yes to the ride?

**Sally Bergosh**: I’m at the condo with Donna! We are safe & sound!!

**Jeff Bergosh**: Okay I’m unloading at the house

**Jeff Bergosh**: cejsouth@gmail.com

**Sally Bergosh**: Huh?!

**Jeff Bergosh**: That’s the email for Chris Jensen who owns family funeral and cremation

**Jeff Bergosh**: I also spoke to Freddy Donovan JR today as well.  Send him a package

**Sally Bergosh**: I already sent Freddy Donovan JR & senior a package but I’ll resend!!:)

**Sally Bergosh**: Thank you!! Donna & I are heading to the dock in the backyard!❤️

**Jeff Bergosh**: Do u want me to fix the wine bottle?

**Sally Bergosh**: Loved “Do u want me to fix the wine bottle?”

### CONVERSATION ON 09-30-2021

**Sally Bergosh**: Did u read the email I forwarded you from Cindy Bonner Bear? Do you think I responded appropriately?

**Jeff Bergosh**: I think it was perfect.

**Sally Bergosh**: Loved “I think it was perfect.”

**Jeff Bergosh**: 226474

Constant contact code

**Jeff Bergosh**: Just came in

**Sally Bergosh**: New code?

**Sally Bergosh**: ?!!? 

**Jeff Bergosh**: Someone is trying to log in to your HHC constant contact

**Jeff Bergosh**: So I’m forwarding u the code

**Sally Bergosh**: We are heading to dinner with Brandon to McGuires! Can u meet us in 30 minutes?

**Sally Bergosh**: Can u call IPC? 

**Sally Bergosh**: We were just seated at McGuires

**Jeff Bergosh**: Just finished the condo and I have a bunch of perishable food in the car so I have to take it home and put it in the fridge and the freezer

**Jeff Bergosh**: You should take Brandon by the condo after and just do a spot check and show it to him it’s the cleanest it’s ever been

### CONVERSATION ON 10-01-2021

**Sally Bergosh**: What year is Tori’s car?

**Jeff Bergosh**: 2020

**Jeff Bergosh**: If so ———-they just need to come and put the temporary tire on for Tori and then she can take it to the Kia dealership to have the tire repaired or she could take it to Vannoys up the street

**Sally Bergosh**: Vannoys up the street!!

**Sally Bergosh**: 👍

**Sally Bergosh**: Gary Sapp will be our AAA peeps & it will be an hour

**Jeff Bergosh**: 👍

**Sally Bergosh**: Guess what?!!? Tori does NOT have a spare tire so this has to be a tow to Van Noys

**Sally Bergosh**: Vannoys

**Jeff Bergosh**: Really??

**Sally Bergosh**: Yep!!

**Jeff Bergosh**: Where’s her spare???

**Jeff Bergosh**: Wow—why no spare??  I’ll call KIA

**Sally Bergosh**: It’s not considered “necessary”! U can get a spare tire as an “optional” choice

**Jeff Bergosh**: Wow

**Sally Bergosh**: Please call Vannoys & let them know our tow truck will be bringing Tori’s car

**Jeff Bergosh**: Okay

**Sally Bergosh**: Nail is in sidewall! Tell them to put tire on it- I’m sending u a picture so they can start working on it. 

**Jeff Bergosh**: Okay

**Sally Bergosh**: Tire size is 205/55 R16 91H

**Jeff Bergosh**: OK I called him got it all set up they’re going to get the tire they don’t have it in stock but they’re going to get it and they will be able to complete the repair by the end of the business day today and I’ll pay them over the phone with my charge card

**Jeff Bergosh**: So when I get home from work today I’ll drop Tori off so she can get her car meanwhile today she just will be without a vehicle but she probably needs to sleep anyway

**Sally Bergosh**: Got it!:) 

**Sally Bergosh**: I just called Vannoys to see if Tori’s car was ready & they said yes.....can u advise how you want me to pay for this? Donna is officially at the airport & I just got home

**Jeff Bergosh**: I’ll pay for it

**Jeff Bergosh**: Should be $119

**Sally Bergosh**: K! Love you!!

**Jeff Bergosh**: Love u most 

**Sally Bergosh**: I thought it was $149

**Jeff Bergosh**: They told me 119 but whatever

**Jeff Bergosh**: LOL

**Sally Bergosh**: I’ve been dying to ask u about your doctor visit yesterday

**Jeff Bergosh**: I’m all good

**Jeff Bergosh**: Are you all going to pick up the car right now? Or I can take Tori when I get home from work

**Sally Bergosh**: We are going right now!!

**Jeff Bergosh**: Okay just text me the total 👍❤️😎👌

**Sally Bergosh**: It was $144.47

**Jeff Bergosh**: Got it

### CONVERSATION ON 10-03-2021

**Jeff Bergosh**: Love u!!

### CONVERSATION ON 10-04-2021

**Sally Bergosh**: Can u send me the link to our beach condo for Morgan?

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Sally I love u—heading to bed.  I stuck to the diet today👌👍😎

**Sally Bergosh**: Me too! We had a nurses meeting that started at 6 pm- I’m finishing my minutes/ notes/ etc then heading home!! Long ass day- no time to eat! Water, coffee, diet cokes!

**Jeff Bergosh**: Also— make sure you send the package to Chris Jensen 

**Jeff Bergosh**: And drive safe the storm woke me up —— it’s  storming here so bad

**Sally Bergosh**: I sent the packet and am heading home!:)

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: Great meeting tonight— Doug didn’t even show up.  Love u and I’ll see u when u get home.  Love, me!

### CONVERSATION ON 10-06-2021

**Sally Bergosh**: ❤️❤️❤️

**Jeff Bergosh**: I jump through all the hoops to get us checked in and after entering all the information passports and everything it says we can’t check in online you have to check in with an agent at the airport so we definitely need to get there early in the morning

**Sally Bergosh**: Liked “I jump through all the hoops to get us checked in and after entering all the information passports and everything it says we can’t check in online you have to check in with an agent at the airport so we definitely need to get there early in the morning”

**Jeff Bergosh**: I tried calling customer service as well…..no luck

**Jeff Bergosh**: We’re going to have to get in line at the check in desk first thing tomorrow morning— not going to be able to just go straight to TSA screening line ……..

**Sally Bergosh**: What time are u coming?

**Jeff Bergosh**: Here

**Jeff Bergosh**: At Davis and olive now

**Sally Bergosh**: I need u sooner then later

**Jeff Bergosh**:  In waiting room

**Jeff Bergosh**: Sally— David Bear foundation will do $5K

**Sally Bergosh**: We yay, yay, yay!!:) thank you, thank you!! Now - who do I get their 1/2 page ad due by November 5th from?! Mary Asmar?

**Jeff Bergosh**: No— it’s online

**Jeff Bergosh**: Just click it

### CONVERSATION ON 10-07-2021

**Jeff Bergosh**: https://doc-10-50-docs.googleusercontent.com/docs/securesc/02v8efjh62og606udqtammruj9c9363e/f6uqsl0k4d0cii80ojg77jhobftaqjh6/1633612950000/01167618859071257828/01167618859071257828/1ckHVaNaXU1_a8mtGCreptfd2REcnqj7p?e=download&authuser=0&nonce=8gtqq6eptco96&user=01167618859071257828&hash=nmdr9jg7bpf3fugvaehb5gcg38ontbrq

### CONVERSATION ON 10-08-2021

**Sally Bergosh**: We left Thursday at 10 am & we are now eating breakfast in London waiting for our flight to Denmark! Long-ass travel days! Then they had some BS rule in London that u could only have (1) sandwich plastic bag per passenger & u had to take it out of your luggage. I got it all in except hairspray & mouse. Oy Vey! We still haven’t slept but it’s an adventure! Travel now kids while you’re young!!❤️❤️

**Sally Bergosh**: We have landed

**Jeff Bergosh**: Okay thx Nick!

**Sally Bergosh**: Liked “I’ll grab you guys some metro passes while I wait ”

### CONVERSATION ON 10-09-2021

**Sally Bergosh**: Denmark, Baby!!

### CONVERSATION ON 10-10-2021

**Sally Bergosh**: Your dad had first shower and is still showering, we may be running “late”......

**Sally Bergosh**: Did u sleep better last night?

**Sally Bergosh**: 9:15? What time works best with your schedule?

### CONVERSATION ON 10-11-2021

**Sally Bergosh**: We are ready a little early if that helps you any!:) If not, then no worries......breakfast before class?

### CONVERSATION ON 10-12-2021

**Jeff Bergosh**: I’m sorry

**Jeff Bergosh**: No not really.  We ended up clearing customs quickly the waiting at the gate

**Sally Bergosh**: Love you, Nicky & Miss u already!! Thank u for quickly saving the day this morning & calling us a taxi! Way to think quick on your feet & not give your dad time to think of a “cheaper way”!! Oy vey!!😂

### CONVERSATION ON 10-13-2021

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you right back!!❤️

**Jeff Bergosh**: Going to bed —love u!!

### CONVERSATION ON 10-14-2021

**Sally Bergosh**: U still at your meeting?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: It’s running really long

**Sally Bergosh**: I’m still at clinic finishing some things up. 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: On way home— love u

### CONVERSATION ON 10-15-2021

**Sally Bergosh**: Can u send flowers to Sara Hayes Family? She was the queen of Roger Scott Tennis & such a huge inspiration to me! She played tennis until she was 85!!
This is her granddaughter’s email address:
Aphillips@premierworkforcesolutionsllc.com 

This is her address:Mr. Hayes is still alive & grieving-
5715 San Gabriel Dr.  32504

**Jeff Bergosh**: Okay will do it

**Sally Bergosh**: Loved “Okay will do it”

**Sally Bergosh**: Thank you! Her husband’s name is Bill Hayes! ❤️

**Jeff Bergosh**: Also I sent the flowers to the Hayes‘s And I will send you a picture when they send it to me from the flower shop what it looks like when it’s delivered

**Jeff Bergosh**: This is what is getting delivered today to Mr Hayes with a card from us expressing our condolences ❤️❤️

**Sally Bergosh**: Love!!❤️

**Sally Bergosh**: Oh my goodness!! Absolutely we will be there! I wouldn't miss it for the world! Love you guys!!❤️❤️

### CONVERSATION ON 10-16-2021

**Sally Bergosh**: Herr

**Jeff Bergosh**: In stadium?  

**Jeff Bergosh**: U

**Sally Bergosh**: We are flying to San Diego on December 23-28.........grandma & Boppa will be so excited to see you! ❤️

**Sally Bergosh**: Loved “They are! I called them the other day to tell them. They’re going to pick me up from the airport ”

**Sally Bergosh**: That’s awesome!!❤️

**Jeff Bergosh**: Have fun and be safe!  Don’t get “Taken” like in the Liam news on movie lol

### CONVERSATION ON 10-17-2021

**Sally Bergosh**: Jeff- I need market value of the beach condo “in kind” donation & restrictions plus dates they can use. Thanks! Does the condo cost about $300 p/ night x’s 4 nights in August or September which would equate to $1200 value?

**Jeff Bergosh**: 250 night in August- 4 nights equals $1000 value

**Jeff Bergosh**: Available any 4 days in August (between August 7th and August 31st)

**Sally Bergosh**: Must book dates by January 1st with Jeff Bergosh,  Jeff Bergosh@gmail.com

**Jeff Bergosh**: Perfect

### CONVERSATION ON 10-18-2021

**Jeff Bergosh**: I made great progress today on your newsletter and I should have it finished by tomorrow. I worked on it tonight but I got really tired so I’m heading to bed. Also made numerous phone calls I’ll fill you in tomorrow on what I learned love you❤️

**Sally Bergosh**: Love u right back! Still working on fitting our budget categories in the Bear Foundation budget categories......ughhhhhh

### CONVERSATION ON 10-19-2021

**Sally Bergosh**: Tennis dues- do u know if I have funds/ balance?

**Jeff Bergosh**: $259.54 in checking

**Jeff Bergosh**: I just called called Troy Rafferty’s office and actually got through to his secretary who took a message I’m waiting for his callback LOL

**Sally Bergosh**: Thank you for checking- love you!! I have on my calendar that we are going to a fundraiser for Michelle Salzman NEXT Thursday- is that still correct?

**Jeff Bergosh**: *cold

**Jeff Bergosh**: I think people are on to what I’m calling them for LOL

**Sally Bergosh**: Wow! Thanks for checking in with peeps! It is what it is at this point. Love you!!❤️❤️

**Jeff Bergosh**: I’m going for more😎👍

**Jeff Bergosh**: I just sent Newsletter draft

**Sally Bergosh**: Hey- it looks fantastic- now we just need the headline “Health and Hope Clinic Takes Care to the Community changed to takes Care of the Community

**Sally Bergosh**: Weren’t my stats just for the month of September? Not for the entire year

**Jeff Bergosh**: Call me I have some good news 😁👍

**Jeff Bergosh**: The scene at our front door right now Carson trying to put a leash on Izzy in front of our door camera LOL

**Sally Bergosh**: Classic!!😂❤️❤️

**Jeff Bergosh**: Hey I just sent the revised newsletter.  Please proofread it and let me know.  Headed home now.  Long day😎👍

**Sally Bergosh**: It looks fantastic! Send it!  Woohoo!

**Jeff Bergosh**: Okay I’ll send it out first thing tomorrow morning.  Heading to bed— love u!!

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 10-20-2021

**Jeff Bergosh**: Sally- Got slammed at work and couldn’t get that email out but on my lunch break I’m gonna try and do it. Will you give me one more time that verbiage you want me to add about the breast Cancer walk?

**Jeff Bergosh**: Time place etc.

**Sally Bergosh**: No- I sent our reminder to volunteers about event earlier today- let’s just send out the newsletter! Thank you!!❤️

**Jeff Bergosh**: Too late— I added the blurb and sent it

**Jeff Bergosh**: Found info online

**Sally Bergosh**: Great! Thank you!

**Jeff Bergosh**: 🎩👍

**Sally Bergosh**: Code for constant contacts?!

**Jeff Bergosh**: 35391

**Jeff Bergosh**: Sally there are several Uber charges hitting your account—- are they legit?

**Sally Bergosh**: Noooooo!! I let the clinic set it up under my name- this needs to be changed if I’m getting charges! We have 500 Uber free vouchers, but our patients don’t have cell phones to get the app so we opened an account at the clinic. Ughhhhh

**Sally Bergosh**: No good deed goes unpunished!:(

**Jeff Bergosh**: You need to shut it down

**Jeff Bergosh**: Looks awesome Nick!  What about school this week though???

**Sally Bergosh**: Exactly- I’m really starting to worry!☺️

**Jeff Bergosh**: Oh— that’s awesome!  Wow this semester I’m Copenhagen is looking better all the time LOL🎩🎩

**Sally Bergosh**: Phewwww!!😘

### CONVERSATION ON 10-21-2021

**Sally Bergosh**: Yes!! 

**Jeff Bergosh**: Perfect advice walking into a BCC meeting

**Sally Bergosh**: Loved “Perfect advice walking into a BCC meeting”

**Sally Bergosh**: Do u know Jack Williams at Seville? Buck Mitchell said yes to the gift card for our event but told Gaye to get it from Jack Williams!! Ugh!!:(

**Jeff Bergosh**: Yes I know him but not too well

**Jeff Bergosh**: Got a call back from Kendrick today.  He was out of town….He and Gay are coming to the event and will support— awaiting approval from their HQ in Tallahassee for dollar amount 😎❤️👍

**Sally Bergosh**: Oh my goodness - tell him I just need to know the amount of sponsorship so we can get them in the program and on the billboards by Nov 5

**Sally Bergosh**: Yay!!

**Jeff Bergosh**: He’s waiting on that figure

**Sally Bergosh**: Gotcha

**Sally Bergosh**: Gay wants u to text Buck Mitchel or the other dude & give a gentle nudge

**Jeff Bergosh**: I love these bullshit excuses about dodging calls when we’re “ out of town”. As if cell phones don’t work out of town

**Jeff Bergosh**: (Amway reference)

**Sally Bergosh**: You’re in a funny mood!!

**Jeff Bergosh**: Had a great BCC mtg

**Jeff Bergosh**: 🎩🎩😎😎

**Sally Bergosh**: Really!?!

**Jeff Bergosh**: Epic

**Jeff Bergosh**: I made our reservation for tomorrow night at McGuires at 6:00👌👍

**Sally Bergosh**: Yay!! Thank U!!

**Jeff Bergosh**: Remember don’t drink and drive tonight!!

**Jeff Bergosh**: Going to bed, love u!! Don’t drink and drive!!

### CONVERSATION ON 10-24-2021

**Sally Bergosh**: What time does our flight to San Diego get in on the 23rd of December?!

**Jeff Bergosh**: I’ll check rn

**Sally Bergosh**: K

**Jeff Bergosh**: I’ll send u the flight info

**Sally Bergosh**: Thank you!

### CONVERSATION ON 10-25-2021

**Jeff Bergosh**: ❤️❤️👍👍

**Sally Bergosh**: That’s fantastic news!! We’re we able to use our vouchers for anything so far?

**Jeff Bergosh**: Yes-  the San Diego trip

**Jeff Bergosh**: *kick it down the road like kickball

**Sally Bergosh**: She has not told us what they are doing this year for the clinic and she is on my list to “get an update”- maybe thank them for their support last year & their dedication to the community!?!

**Jeff Bergosh**: Okay will do.  They are very interested in the counties investment in a broadband Ntwrk to the northern part of the county they have a lot to gain from it.  That’s a great idea I’ll thank them for all their support for Health and Hope Clinic that’s how I’ll start the conversation LOL

**Jeff Bergosh**: 😊👌👍

**Sally Bergosh**: Kristin just told Susan Bonsignore COX is for sure doing $2500, but is seeing if they can do more this year!

**Jeff Bergosh**: 🎩👍

**Jeff Bergosh**: The timing was perfect they requested a meeting and we’re so thankful for my time LOL

**Sally Bergosh**: Classic synergy!!❤️❤️

**Jeff Bergosh**: 😎

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: ❤️❤️

**Sally Bergosh**: I’m home!! Do not fall asleep yet!!😂

### CONVERSATION ON 10-27-2021

**Jeff Bergosh**: Okay got it!

**Sally Bergosh**: Love you & hope u are enjoying the campaign party! When u get a second, can u check my balance for my hair appointment

**Sally Bergosh**: Never mind I’m good

**Sally Bergosh**: Do u need a ride home? I can come get u if u change your mind!:)

**Jeff Bergosh**: I’m sorry I missed these texts I was talking and I did not feel the vibration of the phone. I stayed for about an hour and I’m already at home I didn’t have anything to drink so I don’t need a ride. And you have about 300 bucks in your checking so I think you’re probably good for your appointment. Love you

### CONVERSATION ON 10-28-2021

**Sally Bergosh**: U can’t meet at the house at 5 pm tonight?

**Jeff Bergosh**: Yes— I can do that if it’s more convenient

**Sally Bergosh**: Wayyyyy more- Tori is not working tonight & wants to attend Michelle’s fundraiser at Yacht Club, too

**Jeff Bergosh**: Okay I’ll come get you both

**Sally Bergosh**: Yay!!:)

**Jeff Bergosh**: Tori’s coming in to crash the party

**Sally Bergosh**: She’s in!!

**Jeff Bergosh**: I have a door chick at the door so I didn’t try

**Jeff Bergosh**: Have fun love u!!

**Sally Bergosh**: Come here!! Door girl is my friend!! I’m coming to get u!!

**Sally Bergosh**: Cathy Brown is my friend at the door

### CONVERSATION ON 10-29-2021

**Sally Bergosh**: Do I have enough money to go to lunch with my team?!

**Sally Bergosh**: Never mind- I’m good!

**Jeff Bergosh**: Yes u do!

**Jeff Bergosh**: FYI— Sidoti

**Sally Bergosh**: Anything from Ashton at Andrews or Billy from Subaru? I don’t need their money by Next Friday just their commitment of sponsorship level & logo!

**Jeff Bergosh**: Not yet

**Jeff Bergosh**: I’ve reached out but waiting to hear back

**Sally Bergosh**: Baskerville Donovan?

**Jeff Bergosh**: I’ll hammer them again Monday

**Jeff Bergosh**: Tried today no call back

**Sally Bergosh**: Hmmm🤔

**Jeff Bergosh**: I ordered pizzas for us for dinner tonight!  😊👍👌

**Sally Bergosh**: Yay!! Are u home yet?

**Jeff Bergosh**: Yes I’m here

**Jeff Bergosh**: Food’s here where r u boxer?!?

**Sally Bergosh**: On route!!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-30-2021

**Jeff Bergosh**: Where r u?

**Sally Bergosh**: On my way home

**Sally Bergosh**: Remember I had a match that started at 1 pm at RS

### CONVERSATION ON 11-01-2021

**Sally Bergosh**: I just saw this on some mail I received from another non profit. Who do I talk to about getting the same deal?

**Sally Bergosh**: Here’s another one I just got from GCKH. I’m calling Stacey Kosivecky today about this! I’m paying top dollar

**Jeff Bergosh**: Mike knows all about it they don’t get any kind of special deal it’s just a bulk mailing and if you’re bulk mail more than 1000 pieces I think they give you like five cents off it’s not worth the effort the juice won’t be worth the squeeze

**Sally Bergosh**: Gotcha!

**Jeff Bergosh**: Love you —heading to bed——huge day and meeting tomorrow..  I’ll see u when u get home.   Love,  me❤️❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: Woohoo!!

### CONVERSATION ON 11-02-2021

**Jeff Bergosh**: Sally— call Kayla at Anderson Subaru

**Sally Bergosh**: I emailed her & blind copied you

**Jeff Bergosh**: 👍

**Sally Bergosh**: Praying for ur meeting tonight

**Sally Bergosh**: On my way to calverts on Scenic

**Jeff Bergosh**: Have fun— love u!

**Sally Bergosh**: How’s the commissioner meeting?!

**Sally Bergosh**: Is Underhill behaving himself?!!?

**Sally Bergosh**: Really?!!? J just got the alert that u r home!! We are only 1/2 way through this event- why would u not come here after your meeting

**Jeff Bergosh**: 3 hour meeting just wrapped up 

**Jeff Bergosh**: Exhausted

**Sally Bergosh**: But you’re home! How did it go?!

**Jeff Bergosh**: We got everything we wanted

**Jeff Bergosh**: 🎩😎👍

### CONVERSATION ON 11-03-2021

**Sally Bergosh**: You spelled Tonya’s name incorrectly- it’s not Tanya, it’s Tonya! Can you edit & send back to me?

**Jeff Bergosh**: Sure will!

**Sally Bergosh**: Thank You!!

**Jeff Bergosh**: Just sent it to you 😊

**Sally Bergosh**: Call me

**Jeff Bergosh**: Got it!  I’ll put it together and forward it to you in the morning if that works?

**Sally Bergosh**: Yep- it’s due Friday to Mike for Program!

**Jeff Bergosh**: No problem I’ll get it done tomorrow

### CONVERSATION ON 11-04-2021

**Jeff Bergosh**: Okay you’re all set on your money now;   $900 in checking and $475 in savings

Love u!!

**Sally Bergosh**: Thank you- love you! Remember be “classy” and give your position the dignity and respect it deserves & people didn’t even know they VALUED until living through the “Trump Era”!😘

**Jeff Bergosh**: Always!

**Sally Bergosh**: Here are all those details for the sail boat ride from Tara.......

**Jeff Bergosh**: Okay great sill do it first thing in the morning— already at BCC meeting

**Jeff Bergosh**: Love u!!

**Sally Bergosh**: Love you right back!! Please invite the peeps you like to attend the event as our distinguished guests!! I would love to see Lumon’s, Robert & Barry attend!:)

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Okay well thanks for heads up!  Don’t drink and drive— be responsible 👍

**Sally Bergosh**: Liked “Hey pretty sure I’m going to be staying out here at Madison’s. Just giving a heads up”

**Sally Bergosh**: Yayyyyyy!! Win for tennis peeps across America!!

### CONVERSATION ON 11-05-2021

**Jeff Bergosh**: I got invited to play as a sub in the over the hill tennis league this Wednesday at Roger Scott at 5:30 😊👌

**Sally Bergosh**: Yay!!😘You definitely said YES I hope!

**Jeff Bergosh**: Yes— I did!  Cool right??

**Sally Bergosh**: Of course!!

**Jeff Bergosh**: I’m working on your fun day with friends flyer is it a $300 bar tab at Calvert’s along with the dinner or is it a $500 bar tab?

**Sally Bergosh**: I wrote it all out for you- no bar tab reference- just say total value=$1200. We are going to buy $300 of gift cards to cover wine for their evening but we don’t need to put that on the flyer.:)

**Jeff Bergosh**: Okay I’ll make the change and re send it to you when I get home.

❤️❤️👍👍

**Sally Bergosh**: Thank you!!

**Jeff Bergosh**: Just sent the revised one!

**Sally Bergosh**: Thank you- I’m sending to Mike right now!!

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-06-2021

**Jeff Bergosh**: Will be home 11:15

**Sally Bergosh**: Fine!

**Jeff Bergosh**: We’re on the 30 minute countdown will be leaving at 11:30 sharp

**Sally Bergosh**: What happened to leaving at 11 am? I’m ready! Jeff always gets HZiS way

### CONVERSATION ON 11-07-2021

**Sally Bergosh**: Oh man/ bittersweet! He had a good life & by all accounts, lived a great life!!❤️😢🙏

### CONVERSATION ON 11-08-2021

**Sally Bergosh**: I’m at work still but just got this text from Janet

**Jeff Bergosh**: Love u—heading to bed.  See u when u get home!❤️❤️

### CONVERSATION ON 11-09-2021

**Jeff Bergosh**: 👍

**Sally Bergosh**: That’s fantastic news! How many peeps were there in protest?

**Jeff Bergosh**: 3

**Jeff Bergosh**: Then we voted for my map, 4-1 vote

**Sally Bergosh**: Yaaaaay!! Now let’s sell everything and move to Perdido! Haha!! 😂

**Jeff Bergosh**: LOL we can now, legally!

**Sally Bergosh**: New sponsor again this morning!  Ugh! I’m up to $118,800 in sponsorships for the year! Woohoo!

**Jeff Bergosh**: That’s Awesome!!!

**Sally Bergosh**: From Susan Sanders:

Hey Sally! This is Susan Sanders.  I don’t have Jeff’s number. Can you remind him our Veterans Day parade is tomorrow if he wants to come check it out?  It starts at 8:30. 😊

**Jeff Bergosh**: Okay I can’t make it tomorrow but I gave money and so did Steve Barry

**Jeff Bergosh**: Love u— see u when u get home ❤️❤️

### CONVERSATION ON 11-10-2021

**Sally Bergosh**: Love you!!

**Sally Bergosh**: I do not! 

**Sally Bergosh**: We are on a road trip to Orlando for my conference and your is driving!

### CONVERSATION ON 11-11-2021

**Jeff Bergosh**: I found a store right across the street— going to get your toothpaste and hairspray.  Anything else you need or forgot?  Just let me know.  Love u!

**Sally Bergosh**: After cocktail hour we have reserved the water taxi on the premise that takes us directly to downtown DISNEY! Team building for dinner tonight.

**Jeff Bergosh**: Okay cool!

**Jeff Bergosh**: I couldn’t get a t time today they’re booked solid

**Sally Bergosh**: Tennis tomorrow!:)

**Jeff Bergosh**: So I took one tomorrow morning at 0730

**Sally Bergosh**: Golf tomorrow?!

**Sally Bergosh**: Yay!!

**Jeff Bergosh**: So while you’re in conference I’ll golf 

**Sally Bergosh**: Yes

**Jeff Bergosh**: Then we can play tennis before we leave maybe?

**Jeff Bergosh**: If we can fit it in

**Sally Bergosh**: Perfect- sounds great

**Jeff Bergosh**: I also got parking taken care of

**Sally Bergosh**: Awesome

**Jeff Bergosh**: We need to request a delayed checkout

**Jeff Bergosh**: Hey could we stay an extra day at the group rate if we pay?  I’m thinking I’d like to do that if you’d like to 😀

**Sally Bergosh**: Go to the front desk & ask!:)

**Jeff Bergosh**: Would u be good with that?

**Jeff Bergosh**: I’m heading to the Jacuzzi

**Sally Bergosh**: Love you!!

**Jeff Bergosh**: Love u most!

**Jeff Bergosh**: Are you coming up to the room before the happy hour?

**Sally Bergosh**: Yes! We are at our ANNUAL MEMBERSHIP MEETING. Mike is running for being on the BOD for FAFCC

**Jeff Bergosh**: Okay, I’m
Going to start getting ready

**Sally Bergosh**: Perfect!!:)

**Jeff Bergosh**: Please stop by the registration desk and let them know we want to stay an extra day they wouldn’t let me do it officially they need to see your ID

**Jeff Bergosh**: So we can stay an extra day at the same rate

**Sally Bergosh**: We will do together

### CONVERSATION ON 11-12-2021

**Sally Bergosh**: Come down to the ballroom for lunch!! Starts at 12:30

**Sally Bergosh**: U still golfing?!

**Jeff Bergosh**: Just got done.  I’m a sweaty wreck

**Jeff Bergosh**: Are we still going to play tennis?

**Sally Bergosh**: Of course after my conference is over

**Jeff Bergosh**: Ok

**Jeff Bergosh**: I’m good — will hold out for dinner

**Sally Bergosh**: On my way up

**Jeff Bergosh**: 👍

**Sally Bergosh**: Loved an image

### CONVERSATION ON 11-15-2021

**Jeff Bergosh**: Heading to bed, I’ll see u when u get home— love u!  Big day tomorrow, I take over as chairman again!

**Sally Bergosh**: So proud of you!! I’m grinding away making up for our absence in Orlando! Had a crazy chat with B tonight around 8:30 pm! He promised me he would find time to come by the house this week & discuss his new future plans with you!

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: Wrong date on cover of program.  Yikes!!

**Sally Bergosh**: He left of the “0”- I’m so devastated! I also caught another missed letter at the end of the program we thank Marty Stanovich & the Ballet Pensacola for their performances-the word is missing a letter

**Jeff Bergosh**: Oh well— mistakes happen

**Jeff Bergosh**: Is it too late to fix 

**Sally Bergosh**: I’m kicking myself that I didn’t catch it on the road to the conference!! Ugh!!

**Jeff Bergosh**: Don’t worry— They’ll know what day it is because it’ll be the date they get their program the date of the event

**Sally Bergosh**: https://chickennpickle.com/kc/about/

**Sally Bergosh**: This is the place I was telling you about. Would love to have them build at by NFCU HQ! Who does the site selection manager need to contact? 

**Sally Bergosh**: This is from girl on tennis team- btw

**Jeff Bergosh**: Hey you’re on the channel 3 news at six tonight about Narcan!

**Jeff Bergosh**: Great job!

### CONVERSATION ON 11-17-2021

**Sally Bergosh**: I have my paycheck but dental lady has an emergency & needs to borrow $20- do I have money in my account?

**Sally Bergosh**: Never mind- I was able to come up for air for 30 seconds and look it up!:)

**Jeff Bergosh**: Sorry I didn’t see this till just now but yes you have like 260 in your account as of this morning

### CONVERSATION ON 11-18-2021

**Sally Bergosh**: Hey, kids! We are all invited to attend this wonderful Christmas service at Marcus Point Church! They have special seating for us & are providing lunch afterwards! Sunday, December 12th at 9:30 am! Anyone that can attend needs to be at our house by 9 am so we can all ride together. Love you guys!!

### CONVERSATION ON 11-19-2021

**Sally Bergosh**: Pictures please!! What country is that in?!

**Sally Bergosh**: Pictures please!! I would like to see what it looks like since I doubt I will ever get there!:)

**Sally Bergosh**: How much for a beer?

### CONVERSATION ON 11-20-2021

**Sally Bergosh**: “It’s like a Virgin”


**Jeff Bergosh**: Have fun!  Love u!

**Sally Bergosh**: “I want to know where love is”❤️❤️

**Jeff Bergosh**: 👍

**Sally Bergosh**: “I want you to show me”!!

**Sally Bergosh**: “You’ve got a fever of 103”!!

**Sally Bergosh**: Hot blooded

**Jeff Bergosh**: 👍👌

**Jeff Bergosh**: Okay be safe!

**Sally Bergosh**: Love you, Tor-Tor!!❤️❤️

### CONVERSATION ON 11-22-2021

**Jeff Bergosh**: Grover and Jill Robinson are coming to Christmas at the clinic!

**Sally Bergosh**: That’s fantastic news!! Yay!! Thank you for checking!

**Sally Bergosh**: What’s his email or cell #?

**Jeff Bergosh**: He’s on vacation in Arizona but I gave him the date and he and Jill are coming as our guests. 😎👍👌

**Sally Bergosh**: That’s awesome!!:)

**Sally Bergosh**: Hey, Tori. You need to go see Debra Hooks at the office of CTE (Career Technical Education) & tell her you are over 25 years old and you’ve been displaced due to COVID & need financial assistance for this LPN rapid program........they will cover everything, including books!! Take care of this tomorrow so you can not be stressed out!

**Sally Bergosh**: This is on the Pensacola campus!!

**Sally Bergosh**: You also need to go online PSC and apply for the COVID Cares Grant application- it takes like 5 minutes! 

### CONVERSATION ON 11-23-2021

**Sally Bergosh**: I would confirm they are open Friday

### CONVERSATION ON 11-24-2021

**Jeff Bergosh**: I got sent a screen shot of this comment directed toward Michelle by Doug.  Can u believe this creep??

**Sally Bergosh**: Unbelievable! He’s an ass-hat!

**Jeff Bergosh**: That’s too polite of a characterization

**Sally Bergosh**: Does Michelle know?

**Jeff Bergosh**: I asked Michelle why this happened she has no idea he’s just attacking her she thinks he might be gearing up to run against her

**Jeff Bergosh**: She’ll beat the shit out of him if he runs against her

**Sally Bergosh**: Ugh!!

**Jeff Bergosh**: It’s going to be an ugly year get ready

**Jeff Bergosh**: More for tomorrow👍❤️🎩

**Sally Bergosh**: Yummy!!❤️

**Jeff Bergosh**: Herb roasted turkey in the oven!

**Sally Bergosh**: Yummy!! Love you, PC!!

**Jeff Bergosh**: Love u most!  

**Sally Bergosh**: B just called and he wants to do EARLY Thanksgiving with us since he has to work a double! He will be at the house in about 30 minutes

**Jeff Bergosh**: Awesome!

### CONVERSATION ON 11-25-2021

**Sally Bergosh**: Happy Thanksgiving!! We are so grateful for our family & love you guys!! Sally- please send on to Mary!! 

**Sally Bergosh**: ❤️❤️❤️

### CONVERSATION ON 11-26-2021

**Jeff Bergosh**: Dress rehearsal at our house 👍👍😎❤️

**Sally Bergosh**: Yay!! Remember this video needs some edits we are waiting for

### CONVERSATION ON 11-27-2021

**Jeff Bergosh**: Scored you two jumbo packs 

**Sally Bergosh**: Awesome!! 

**Sally Bergosh**: Thank you!!

### CONVERSATION ON 11-28-2021

**Sally Bergosh**: From who? Get their # or give them dad’s #! As an elected official, it’s published! 

**Sally Bergosh**: I have not been getting these calls-hmmmm🤔

**Sally Bergosh**: Brandon!! We are doing grilled steaks tonight- come on over & enjoy some FAMILY time!!

### CONVERSATION ON 11-29-2021

**Sally Bergosh**: ❤️❤️❤️

**Sally Bergosh**: I just forwarded you the email about the link to the newly edited video!:)

**Sally Bergosh**: (2) emails

**Jeff Bergosh**: Okay thx!  Love u!

**Jeff Bergosh**: I got asked to sub tonight after tennis group so I’m going to play at 7 PM tonight they were really desperate for a sub

**Sally Bergosh**: No problem- just confirm if you have what you need from video dude before this day gets away from us please

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Love u

**Sally Bergosh**: Have u coordinated with Marty? He has not acknowledged that I sent him his script......can you make sure he has it? 

**Jeff Bergosh**: Will do!

**Jeff Bergosh**: I just talked to Marty he got the script looks good we coordinated we’re gonna meet there we got it all handled it’s all covered. Love you!

**Sally Bergosh**: Love you right back! 

**Jeff Bergosh**: I’m just working late in my office since I’m playing tennis at 7— no point in driving home to turn around and drive back to Roger Scott.  It’s a good thing I have my workout clothes and Raquet with me!

### CONVERSATION ON 11-30-2021

**Jeff Bergosh**: Sally— you asked this morning about your account.   You have $346.45 in checking acct.   

Love,

Me

**Sally Bergosh**: Thanks! I think I should get Marty Stanovich a gift card as a token of my appreciation. Apparently he just had another surgery

**Jeff Bergosh**: He did— hip replacement surgery.

**Sally Bergosh**: I just tried to use both health cards and it said it was not authorized at Publix Pharmacy....?!!?

**Jeff Bergosh**: How much?

**Sally Bergosh**: $25

**Jeff Bergosh**: Use the keel point one

**Sally Bergosh**: Too late- I used debit after trying 2 cards & feeling very embarrassed

**Jeff Bergosh**: Sorry that happened — I’ll pay you back for it 😕

### CONVERSATION ON 12-01-2021

**Sally Bergosh**: READ today’s verse!

**Jeff Bergosh**: Will do after my meeting this morning

**Jeff Bergosh**: Celebration dinner steaks are going on the grill!!  Love u!!

**Sally Bergosh**: Yummy!!

**Sally Bergosh**: On my way

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: From Mark Faulkner

**Sally Bergosh**: Too sweet! Send this to him!

**Jeff Bergosh**: Will do

**Sally Bergosh**: Love you! ❤️

**Sally Bergosh**: Did u already deposit my check?

**Jeff Bergosh**: Love u too

**Jeff Bergosh**: And yes— u have $1000 in chk

**Sally Bergosh**: Tori is devastated- she just found out her New Years trip was cancelled AGAIN!! 3 years in a row!

### CONVERSATION ON 12-04-2021

**Jeff Bergosh**: Way to go Tori!

**Sally Bergosh**: Picture please!!

### CONVERSATION ON 12-05-2021

**Jeff Bergosh**: 👍👍👍😀😀😀. Way to go Brandon!

**Sally Bergosh**: Loved “Catch me behind the bar today!”

**Sally Bergosh**: Loved “Lotta bloodies & mimosas haha”

### CONVERSATION ON 12-06-2021

**Sally Bergosh**: I just got this message from Branson and he is at your clinic right now:

Hey mom, bad news..

**Sally Bergosh**: Did he test positive for COVID?

**Jeff Bergosh**: I have no idea……

**Jeff Bergosh**: He’s at the employee clinic??

**Sally Bergosh**: I guess- he sent me that text , I called him immediately, he told me he was at the clinic & he would call me back......?!!?

**Jeff Bergosh**: I’ve texted him

**Jeff Bergosh**: Just spoke to him

**Sally Bergosh**: Did u say meet at parking lot at 4:30!!

**Jeff Bergosh**: 4:15

**Jeff Bergosh**: Here

**Sally Bergosh**: Heading your way

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I left mine at house—- it’s pouring

**Sally Bergosh**: 
Sorry- I have an umbrella- I had to wait for the accountant to get here

**Jeff Bergosh**: 👍

**Sally Bergosh**: Here

**Jeff Bergosh**: I got to “catch” a police dog today at the luncheon LOL

**Sally Bergosh**: Oh my!!😂❤️

### CONVERSATION ON 12-07-2021

**Jeff Bergosh**: We meeting at the house to drive together?  Say 5:15 ish?

**Sally Bergosh**: I’m still at clinic and heading on the road now! 

**Jeff Bergosh**: Okay I’m still at work but I’ll be heading that way in 15 min

### CONVERSATION ON 12-08-2021

**Sally Bergosh**: Kelly applie- Campbell? Or Kelly Cambell- Appplie? 

**Jeff Bergosh**: Kelly aeppli Campbell

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Oh my!!

### CONVERSATION ON 12-09-2021

**Jeff Bergosh**: I’ll call u right back

**Sally Bergosh**: Do I have $ in my account? I have my hair appointment right now

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I’ll text u exact amt

**Sally Bergosh**: K

**Jeff Bergosh**: $380.88 in checking

**Jeff Bergosh**: I stamped all the cards you finished and I’ll mail them tomorrow in my way to work after Bible Study.  Love you and I’ll see u when u get home.  I’m fading fast as the 4:30 alarm comes early.  Come home soon Boxer!!❤️❤️❤️

**Sally Bergosh**: I had a few on the list circled for you to confirm addresses- like Mary Bloch for example- please review!

**Sally Bergosh**: Love you back!!

**Jeff Bergosh**: Ok

### CONVERSATION ON 12-10-2021

**Jeff Bergosh**: Cindy Barrington is at the front door ring the doorbell

**Sally Bergosh**: I motorized a document for Civitan

**Jeff Bergosh**: Motorized LOL

**Jeff Bergosh**: What’d you do, attach the document to a fan and hit the switch LOL 😂😂😂😂😂😂😂😂😂😂

**Sally Bergosh**: Lol! Notorized! Lol!

**Sally Bergosh**: Okay- today is my de-briefing luncheon with our Christmas Gala Committee- I’m putting food in my clinic tab & don’t u think I should pick up drinks?!

**Jeff Bergosh**: No

**Jeff Bergosh**: Make each person pay for their own alcohol

**Sally Bergosh**: No- Sallycredit card 

**Jeff Bergosh**: Still give liability on I

### CONVERSATION ON 12-11-2021

**Jeff Bergosh**: Sally this car shows almost over—then I’m coming home to take it to go to Wal mart before the parade.  Can u please make sure the list is done and ready?  Thanks— love u!!

**Sally Bergosh**: It’s BEEN ready! 👍

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: What I just sent to Tori

**Sally Bergosh**: Jeanette & Rob’s new bar outside!!


**Jeff Bergosh**: Wow!  That’s awesome!

**Jeff Bergosh**: I’m subbing at Roger Scott tonight in case you want to come and root me on LOL

**Sally Bergosh**: U know I would but I had a BOD meeting & a once a year dental meeting tonight!!

**Jeff Bergosh**: ❤️👍

**Sally Bergosh**: So HCA clearly says for Tori’s enrollment it was on November 1-19 for her annual benefits package. It says if you do not enroll you will be automatically enrolled in the default coverage listed for u on the BConnected website & will not be eligible for the $650 discount on medical coverage - there is a mailer I’m leaving on table that is very clear on how to see what kind of coverage you do have!!

**Sally Bergosh**: HCAhrAnswers.com click HCA Rewards or call (800) 566-4114

**Jeff Bergosh**: Okay so she is covered!! Whew— that’s a relief!!

**Jeff Bergosh**: I thought it was odd Because that most companies you have to specifically sign a waiver declining coverage and if she didn’t do that that leads me to believe that you’re correct and that she is default it into a plan. Which is a good thing

### CONVERSATION ON 12-14-2021

**Sally Bergosh**: I need your flyer skills to create Sara’s Surprise 60th Birthday Party Invitation. It’s so late that I think we can accomplish this by email & text invitations! I want it to look fancy like Huntley’s- is this something you can help me with? 

**Sally Bergosh**: Surprise party is for Sara Davy is turning the BIG 60! Gag gifts only please!

Sake Cafe on 9th Avenue-Dec 29. Arrive at 5:30. Park in the Dentist office to south. We will be in the room in the back   Appetizer @5:45. I'll tell Sara we are meeting y'all for dinner.

**Sally Bergosh**: That last sentence is to us from John Davy!:)

**Sally Bergosh**: The ladies want me to ask u to stay & make us French 75’s tonight! I’m bringing all the ingredients!

**Jeff Bergosh**: Okay— I don’t want to crash the party though!!

**Sally Bergosh**: No- you’re being totally & completely invited!!❤️❤️

**Jeff Bergosh**: Okay cool!

**Jeff Bergosh**: Just tell Stacey I’ll go in the other room and watch news while you all party LOL

**Sally Bergosh**: Loved “Just tell Stacey I’ll go in the other room and watch news while you all party LOL”

**Jeff Bergosh**: You still going to meet me there at 5:15?

**Sally Bergosh**: Oh myyyyy!😩

**Sally Bergosh**: Do u at least get to watch movies?

**Sally Bergosh**: Nicky- where are you now?

**Sally Bergosh**: Wow!! Worth the wait!!❤️❤️

**Sally Bergosh**: I’m going to send her your contact info. If she can come get u!! Christie & Keith Bonham!!

**Sally Bergosh**: Poor Nicky!! Love you, buddy!!❤️

### CONVERSATION ON 12-15-2021

**Jeff Bergosh**: I’m fading fast, headed to bed.  Love u!!  Come hone soon boxer!!

❤️❤️❤️❤️

**Jeff Bergosh**: Glad you all liked Sally's favorite drink!!

**Sally Bergosh**: Loved “Thank you Sally for the best most awesome bartender in town!!! 😁❤


Also..you guys want to do Bonelli's sometime .. the end of January ???”

**Sally Bergosh**: Yes- we would love to join you & Rob at Bonelli's in January! Let's find a date!❤️

**Sally Bergosh**: As in a date on the calendar, of course! Lol!

**Sally Bergosh**: Jeanette- what u all doing for New Years?

**Sally Bergosh**: Yes! Last year we stayed in New Orleans & went out for a nice dinner. I was thinking maybe a nice dinner at Jackson’s or The District? 

**Sally Bergosh**: Yay!!

### CONVERSATION ON 12-16-2021

**Sally Bergosh**: On my way home

**Sally Bergosh**: Today is my Thank You lunch to Janet for running the digital platform for our silent auction. Did u deposit my che k?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: $700 in sav

**Sally Bergosh**: I REALLY need the invitation for Sara’s party.....can u send to me in text & email whenever u get a second today?

**Jeff Bergosh**: Will do

**Jeff Bergosh**: https://www.google.com/amp/s/www.hollywoodreporter.com/tv/tv-news/chris-noth-accused-of-sexual-assault-1235063596/amp/

**Jeff Bergosh**: Sally I talked to Gary there’s no way he can get there by eight because of the event that he’s at but I just wanted to let you know that so you didn’t wait or save the vaccine

**Sally Bergosh**: Thank you- love you!

**Jeff Bergosh**: Love u most!!

**Sally Bergosh**: Can u check on Bear Foundation Sponsorship check? I’ve still not received as of today & just trying to tie up loose ends before we fly out of town Wednesday. Thanks for checking!👍

**Jeff Bergosh**: Okay I Will

**Jeff Bergosh**: Also please don’t forget to bring home my card!

**Sally Bergosh**: Will do! Thanks for all your hard work on Sara’s invitation! Everyone loves it!❤️❤️

**Jeff Bergosh**: You get the credit for all that!

**Jeff Bergosh**: I’m going night night sleepy love you!

**Sally Bergosh**: I’m over it- coming home now!

**Sally Bergosh**: Loved “Rob said he is good with dinner....either place is good..😁”

**Sally Bergosh**: Let's do The District at 6! That way if we feel up to it we can go upstairs and keep the party going or across the street to Seville! Lol! Like we said, Jeff usually doesn't do double digits! 😘

**Sally Bergosh**: I am good with either spot & really appreciate you getting this for our FUN group!!:)

### CONVERSATION ON 12-17-2021

**Sally Bergosh**: I got Bear Foundation check today!:)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Going to bed— love u!!  Drive safe, don’t drink and drive!!❤️❤️❤️

### CONVERSATION ON 12-18-2021

**Sally Bergosh**: ❤️❤️

### CONVERSATION ON 12-20-2021

**Jeff Bergosh**: Okay— plan change for our flight out of New Orleans Thursday.  Turns out when I went to confirm our hotel/parking they had no record of it— so It looks like fraud according to NFCU who I called and they have already refunded the charges.  So instead of heading to New Orleans Wednesday night— we will sleep at our house Wednesday and leave at 7:00-7:30AM Thursday and park in the airport lot for our flight which leaves at 1:40 PM.  This will give us plenty of time. I already talked to Brandon; he’s going to come over Wednesday night and spend the night, and we’ll get ready and go first thing in the morning.

Love,

Me

**Sally Bergosh**: K

**Jeff Bergosh**: Are the floor guys still working at the clinic?

**Sally Bergosh**: Yep

**Sally Bergosh**: Still doing the floors

### CONVERSATION ON 12-21-2021

**Sally Bergosh**: Can u check with IPC for New Years for 8 peeps?

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Your dinner awaits!  👍❤️

**Sally Bergosh**: On my way

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-22-2021

**Sally Bergosh**: Please call Mike Wood today about this fraud crap! I’m going to head over there right when they open and see if I can get some help!
Do u know who this Christmas card is from? Tim Myers on Deerfield?

**Jeff Bergosh**: Will do.  Yes— Tim Myers is that friend of Gary’s that used to come over to our house to watch UFC fights.  Nice guy

**Sally Bergosh**: I’ll send him a Christmas card back today!

**Jeff Bergosh**: Okay thx

**Sally Bergosh**: Is there a way to link our newsletter on our Facebook page?

**Jeff Bergosh**: Let me look into that— I believe there is

**Jeff Bergosh**: OK Mike has talked to the store manager his name is Hayden so when you get there ask for the store manager his name is Hayden he will help you close the account love you!

**Sally Bergosh**: I’m with him right now & they are saying that we for sure need to call equifax because they said we want them to “Credit Blocking” since someone has my ss # and date of birth

**Sally Bergosh**: That’s how they were able to open this account! 

**Sally Bergosh**: Of course- it was done over the phone!:( 

**Sally Bergosh**: Super awesome customer service!! 

**Sally Bergosh**: I’m also going to file a police report in case these fraudulent peeps try to do anything else to me!!:(

**Sally Bergosh**: So he’s getting all the bs from his own Cust service peeps so he just went in the back so he could scream at the huge amount of bullshit!!!!!!!

**Jeff Bergosh**: Did they get it resolved?

**Sally Bergosh**: Did u get me a police/ sheriff # to do our report about phones?

**Jeff Bergosh**: ?????

**Sally Bergosh**: I’m dealing with fraud & trying get my report-

**Sally Bergosh**: I had to run down to Rusted Arrow and get the gifts for Coronado Hotel gift exchange before they closed- I’m in your parking spot- leaving now!:)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: The new matrix movie is out in theaters today it’s also on HBO max so we can watch that tonight with our pizza if you guys want to!

**Sally Bergosh**: Tori at least made a showing and did Christmas at McGuires with our other local relatives- even Alex, Joey, Tyler Sanders & Ben made it to our Christmas!! 

### CONVERSATION ON 12-24-2021

**Jeff Bergosh**: I’m at Macy’s where are you?

**Sally Bergosh**: We’re coming

### CONVERSATION ON 12-25-2021

**Sally Bergosh**: Merry Christmas, Tori Bear!! Not the same without you! Love you!!❤️❤️🎄🍾🥂

### CONVERSATION ON 12-26-2021

**Jeff Bergosh**: Look who I met going up the mountain! His name was Finley

**Jeff Bergosh**: I’m in lobby waiting…..

**Sally Bergosh**: OMG!! This is rediculous!!

**Jeff Bergosh**: I know

### CONVERSATION ON 12-28-2021

**Sally Bergosh**: Can u lighten this picture for my dad? 

**Jeff Bergosh**: Have a fun and safe trip Tori—-love you!

**Sally Bergosh**: Love you, Tori! T’Amo!!❤️

### CONVERSATION ON 12-29-2021

**Jeff Bergosh**: Will do

**Jeff Bergosh**: By the way I just spoke to Debbie Kenney and she has Covid and sodas Caleb our intern luckily they’re both doing OK but it’s pretty scary the way this thing is spreading so quick!

**Sally Bergosh**: Yikes!!

**Jeff Bergosh**: Crazy right???

**Jeff Bergosh**: Debbie had all shots too

**Sally Bergosh**: Here’s one for $1000 from Alto Products Corporation, David & Wesley Landa!

**Jeff Bergosh**: That’s fantastic!

**Jeff Bergosh**: On way home rn

**Sally Bergosh**: Oh.....okay I’ll come home now too!

**Sally Bergosh**: Yay!!


**Sally Bergosh**: No- you are Birthday Girl, Sara Sue!!🎈❤️

### CONVERSATION ON 12-30-2021

**Jeff Bergosh**: I’m making dinner for us are you on your way home soon?

**Sally Bergosh**: I’m leaving in 20 minutes to go home!:)

**Jeff Bergosh**: Okay it’ll be ready for u when u get here!  ❤️

**Sally Bergosh**: Love you!

### CONVERSATION ON 12-31-2021

**Jeff Bergosh**: Ali on your way to work today be very careful with your speed there have literally been three Highway patrolman with radar guns on a chain that I’ve spotted already do the speed limit they’re out and I just got passed by another Sheriff just now as I’m talking to you they’re out in force today do not speed love you

**Sally Bergosh**: PC- I need more Apple Vinegar gummies & all- around vitamin gummy for women!:) Champagne too, pretty please! 

**Jeff Bergosh**: Okay I’ll put them on the list— not shopping today, doing it tomorrow

**Jeff Bergosh**: I just did a major purge on my clothing I got rid of four bags of clothes I don’t wear anymore and two old suits I took it to teen challenge and got a receipt for our taxes now I’m gonna watch some football and relax love you!

**Sally Bergosh**: I’m still cleaning & organizing the medical closet labeling syringes & every size needles- Oy vey!!

**Sally Bergosh**: I’m the last one still at the clinic!:)

**Jeff Bergosh**: You are dedicated!!

### CONVERSATION ON 01-02-2022

**Sally Bergosh**: Unfortunately it’s already rented out until the end of March with our current long term renter- Pensacola Opera!:( We have it the first 10 days in April & all of September!:)

### CONVERSATION ON 01-04-2022

**Sally Bergosh**: Can u send me that excel sheet all on one page for printing purposes?

**Sally Bergosh**: 
BTW- those were the easiest boiled eggs to de-shell! Thank you- quite yummy!❤️

**Jeff Bergosh**: Yes I will.  Love u!

**Jeff Bergosh**: Just sent it back to you— check it out and let me know if that works.  Each “tab” on the spreadsheet ( individual sheets tabbed on the bottom) will now each print on one page.

Love, 

Me

**Sally Bergosh**: Thank you so much!!:)❤️

**Jeff Bergosh**: Absolutely!  Love u!

**Sally Bergosh**: I got this from Brad Woods at Hillcrest Church just now:


**Sally Bergosh**: Happy New Year Sally! 

I hope you and yours are well. We’ve missed you! 

We’re launching a new year of worship choir next Wednesday night, Jan 12, and I hope you’ll be able to rejoin us. We are looking for faithful worshippers to fill up the loft each Sunday and lead our church family in dynamic praise & worship. We’ve got some super exciting music on the horizon. Will you be able to serve with us?

**Sally Bergosh**: This from Cabo group!

If you want some help coordinating hotel transfers I need your itinerary's. Keith's office manager will do this for you but I need your info. Or you can do it yourself. I recommend Cabo360s.com. Or transcabo.com

**Jeff Bergosh**: Employee of the month!!  Are you coming home soon??

Love,

Me

**Sally Bergosh**: I’m in hell!!

**Jeff Bergosh**: What’s going on?

**Sally Bergosh**: I’m coaching a student

**Jeff Bergosh**: Ok I’m worried about u

### CONVERSATION ON 01-05-2022

**Sally Bergosh**: Got it! Thank you!

### CONVERSATION ON 01-06-2022

**Jeff Bergosh**: Sally I got home from the meeting and I’m exhausted.  Going to bed so I can be rested for Bible study.  I’ll see you when you get home—love you!!❤️❤️

**Sally Bergosh**: I’m exhausted, frustrated, trying to hold this clinic together but very, very hard right now!!!!! 😢

**Jeff Bergosh**: I’m sorry Sally 😕

### CONVERSATION ON 01-07-2022

**Jeff Bergosh**: I just fixed that spreadsheet and sent it back to you as well.

Love

Me

**Sally Bergosh**: Liked an image

**Sally Bergosh**: Thank you! 

**Jeff Bergosh**: ❤️

**Sally Bergosh**: Tori started her first day of school today! Let’s make a big deal of her this evening! She needs to feel supported and confident to continue her education journey!❤️

**Jeff Bergosh**: Got it!

**Jeff Bergosh**: I found the sleeping pills they were in my overnight kit from our trip so I’m bringing them home now they were at my office

**Sally Bergosh**: Loved an image

**Sally Bergosh**: Loved “Free stay and wine tasting in Tuscany anyone? ”

**Sally Bergosh**: At West a Florida HS?

**Jeff Bergosh**: Spider Man!!

**Sally Bergosh**: That’s so funny! B said he went somewhere and all these peeps thought he was Spider Man actor!!😂I think B is much better looking then him!

**Sally Bergosh**: I’m coordinating two trainings for CPR all day Saturday at the clinic until 5 pm- I’m out😢

**Sally Bergosh**: We are open on Sunday!:)

### CONVERSATION ON 01-08-2022

**Jeff Bergosh**: Sally— I’m taking the table and stools to teen challenge to donate them. 😎👍

**Sally Bergosh**: Cool

**Sally Bergosh**: I’ve got 2 pizzas untouched from CPR classes that I’m bringing home this evening for dinner!:)

**Jeff Bergosh**: Thank you!!

**Jeff Bergosh**: Going to Wal Mart rn so text me if there is something you want me to add to the list 😎👌👍 

**Sally Bergosh**: Tori is cooking for us Sunday evening and letting us sample some of her new wine exported from Italy! I think she had some ingredients she needs I to purchase

**Jeff Bergosh**: She’s sleeping though and I don’t want to wake her

**Sally Bergosh**: I would love some snack packs of diet light salted almonds, small oranges, and Greek Yogurt, English muffins, skinny cows, fancy coffees for keurig please

**Jeff Bergosh**: Are u coming home employee of the year??

**Sally Bergosh**: On my way with your pizza! 

**Jeff Bergosh**: Love u!

### CONVERSATION ON 01-09-2022

**Sally Bergosh**: We will be watching! ❤️

**Sally Bergosh**: Super sad about Bob & Betty.😢

**Sally Bergosh**: Brandon- you are missing one of dad’s best Sunday night dinners- ever!!

**Sally Bergosh**: Hmmm- I’m quite positive you know we do Sunday night cookouts EVERY Sunday night!!

### CONVERSATION ON 01-10-2022

**Jeff Bergosh**: Hey check the computer I left the article up on the screen. It’s the electronic version of the hard copy paper so if this is what it will look like in the newspaper that gets delivered today to people. Also I made a healthy lunch for you and Tori they’re both on the dining room table. You might wanna check I think she starts school early real early so if she’s not up by now you should probably check on her love you

**Sally Bergosh**: She up!

**Jeff Bergosh**: I love you I’m falling asleep I’m heading to bed I’ll see you when you come home. Love,

Me

### CONVERSATION ON 01-11-2022

**Jeff Bergosh**: I have to get up at 4:40 tomorrow for my coffee with the commissioner so I’m gonna be going to bed soon but I’m working on your speech right now before I go to bed and I will email you a draft tomorrow mid morning. Love you!  ❤️

**Sally Bergosh**: Invest in yourself (education)! It’s the best decision you will ever make! It’s a higher level and forward thinking, but it will open doors & set you up in the future......it’s hard balancing school & work, but you will never regret it. Grind it out- challenge yourself! You’ve got this, B!❤️❤️

### CONVERSATION ON 01-12-2022

**Sally Bergosh**: From Sharon Godwin today: 

Ok, mums the word I promise 🤫
What else is going in the 9 mile rd crossing? Is there a cure m chic fil a? 🤞

**Sally Bergosh**: https://apple.news/ArVc_sOBPSGCgoec01mNiPw

**Jeff Bergosh**: Gary will get a kick out of this!

**Sally Bergosh**: Maybe he’s on to something!!

**Sally Bergosh**: After all!

**Sally Bergosh**: I think it’s time to let Brandon know if he thinks classes are expensive.....wait till his parents quit paying for his phone, car, and help with rent because he couldn’t keep himself in school & focus long enough to complete some classes!!

**Jeff Bergosh**: I just sent you a draft speech for tomorrow night take a look at it I think that you’ll like it you might need to polish off the rough edges but I think it’s pretty good and would give you 8 to 10 minutes running time. It’s in your email.

Love,

Me

**Sally Bergosh**: I’m STILL under water- now the damn big guy is on his way here to help me get rid of the bugs! Ughhhhj

**Sally Bergosh**: Big guy

**Jeff Bergosh**: No worries.  Kill the bugs!!!

**Sally Bergosh**: Big

**Jeff Bergosh**: Big

**Sally Bergosh**: Bug 

**Jeff Bergosh**: Bug

**Sally Bergosh**: Yes- bug guy

**Jeff Bergosh**: Good.  Not Chris Noth

**Jeff Bergosh**: Don’t worry I’ll have a delicious French 75 ready with your name on it when u get home ❤️👍

**Sally Bergosh**: All those people are telling me they are coming tomorrow to hear me speak- so I really need to rehearse my damn speech!!

**Jeff Bergosh**: Read through it a few times.  Print it out.  It’s a good one I put some time into it

**Sally Bergosh**: I’m coming home!

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-13-2022

**Jeff Bergosh**: Good luck on your speech! Love you

**Sally Bergosh**: That’s very smart, Brandon! You will never regret getting a good education & investing in yourself. You’re meant for great things & it’s time for you to believe in yourself & put in some hard work! You’ve got this!!❤️❤️❤️❤️

### CONVERSATION ON 01-14-2022

**Sally Bergosh**: U forgot to kiss me goodbye this morning! I love you!😘❤️

**Jeff Bergosh**: No I didn’t forget!!  I gave u a kiss u we’re out of it

**Sally Bergosh**: Hmmm🤔

**Jeff Bergosh**: Swear to God

**Sally Bergosh**: Did u deposit my check?

**Jeff Bergosh**: Yes

**Sally Bergosh**: U left a lunch for someone- is that for Tori or me?

**Jeff Bergosh**: You

**Jeff Bergosh**: Tori is at home today

**Sally Bergosh**: Thank you!

**Jeff Bergosh**: Love u!

**Jeff Bergosh**: You have $1100 checking $700 savings

**Sally Bergosh**: Got it!

**Sally Bergosh**: Can u tell me how to respond to Sharon Godwin’s text I forwarded to u?

**Jeff Bergosh**: I already responded to her she sent me the exact same text that same day LOL

**Sally Bergosh**: Oh- here I was feeling so bad about not responding!:(

**Jeff Bergosh**: Your pizza’s ready!!

**Sally Bergosh**: Loved “Homemade pizza night—- yours is going in the oven right now…Mozzarella onion and fresh garlic!”

**Sally Bergosh**: I spoke at The Grand Marlin last night & guess who I met at the bar?

**Sally Bergosh**: Yep!!

**Sally Bergosh**: Nope- Madrina was all over him!!

### CONVERSATION ON 01-16-2022

**Jeff Bergosh**: Tough penalty to take

**Sally Bergosh**: To Brady is dominating this game!!❤️ Tori is making her gourmet lasagne for Sunday din-din & letting us open one of her newly delivered bottles of Italian wine from Italy! Brandon- come on over!

**Sally Bergosh**: *Tom

### CONVERSATION ON 01-17-2022

**Sally Bergosh**: I just received this text from BugMeisters- how do u want me to respond?!

**Sally Bergosh**: Hi Sally! This is Elaine with Bugmeisters. I have an opening for pest service at your condo on Ft Pickens on Thursday 1-27-22 arriving between 10:45 and 12:45. Will that work for you?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I’ll let tenants know

**Sally Bergosh**: I’m not going to tell her yes until u get confirmation that tenants will be there, right?!

**Jeff Bergosh**: No tell them yes—I can give them a code to let them in

**Jeff Bergosh**: If the tenants are there

**Sally Bergosh**: K

**Jeff Bergosh**: Thx👍

**Sally Bergosh**: From the bug people:

Our records show the gate/lobby code is #0916 and the unit code is 2296. Are those still correct codes?

**Jeff Bergosh**: Yes

### CONVERSATION ON 01-18-2022

**Sally Bergosh**: Can you cook dinner for Susan & Bruce at our house on the 29th? Saturday? That’s when they are free next

**Jeff Bergosh**: Sure can.  6:00?

**Sally Bergosh**: Sure or 5:30 so we can start cocktails?

**Jeff Bergosh**: I’ll need til 6:00 please

**Jeff Bergosh**: Cocktails at 6:00– dinner at 7😎👍👌

**Sally Bergosh**: So well serve French 75’s at 5:45! Perfect! I think they are bourbon peeps!

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Did Ben get tested at HHC today?

**Sally Bergosh**: It’s at our house!

**Jeff Bergosh**: I know LOL

**Sally Bergosh**: Go on the government site- and request our (4) free Covid tests! It only takes a minute right now!! It’s per address!!

**Sally Bergosh**: Never mind- I just ordered it!:)

**Sally Bergosh**: Brett ———- - who is the old Principal from BB Middle School & Ransom Middle? I need the last name please!!

**Jeff Bergosh**: Brummett

**Sally Bergosh**: Yes!!

**Jeff Bergosh**: Love u!  I’m exhausted and going to bed

**Jeff Bergosh**: ❤️❤️❤️

**Sally Bergosh**: I’m doing end of year tax letters so I’ll be here late

**Jeff Bergosh**: 😕😕

**Jeff Bergosh**: Be safe lock yourself in and look at those cameras before you walk out

**Jeff Bergosh**: We love u!!

**Sally Bergosh**: We love you & are all very confident that the perfect job is waiting for you! ❤️

### CONVERSATION ON 01-19-2022

**Sally Bergosh**: From Christie & Keith:

It’s looks like your going to have a private shuttle as no one else arrives around you guys. It’s 75.00 each way for both so a total of 150.00. If that sounds good I will confirm and have them send you a confirmation as well!

**Jeff Bergosh**: Yes— do it

**Jeff Bergosh**: I can give them a charge card number if necessary

**Sally Bergosh**: She said we can pay at the time of transport!:)

**Jeff Bergosh**: Okay perfect

**Sally Bergosh**: Christie said Friday or Sunday would be best for an excursion. Friday may be hard because we are just all getting there the night before but then Donna has to leave on Sunday.

**Sally Bergosh**: Our smaller group wants to deep sea fish, at least Becky & Ev & us! Let’s plan for Sunday!

**Sally Bergosh**: Hey, Fellow Cabo Adventurers! I’m thinking it would be REALLY great to charter a deep sea fishing boat for Sunday! Does this sound like something you’d all be interested in doing? I believe Donna leaves Sunday but Friday will be good hectic & Saturday are the retirement festivities. This is a group text for an open discussion- ❤️

**Sally Bergosh**: Okay- Donna said Christie thinks  Friday might be better for our deep sea fishing day, and Sunday to be a snorkeling day?! I guess we will play this by ear by the sound of it.

**Jeff Bergosh**: I just put in a request to Minerva‘s Baja tackle that’s the charter company I’ve used in Cabo multiple times on trips down there and I’m waiting to hear back but I put in a request for Sunday so we’ll see what they come back with

**Sally Bergosh**: Perfect!👍

### CONVERSATION ON 01-20-2022

**Sally Bergosh**: Looks like I’m going to the prayer breakfast next Saturday! Michelle Salzman has a table and asked me join her!:)

**Jeff Bergosh**: I’m not going this year—- have a function in Perdido Key

**Jeff Bergosh**: Enjoy it!

**Sally Bergosh**: On my way!

**Jeff Bergosh**: Right on

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Sally— I went ahead and booked the trip for four (4)people on Sunday, 6 February. If any of your friends want to join us they can pay their proportionate share.  If they don’t join us —-that’s fine too—it’ll just be the two of us and will get the whole boat to ourselves. 

It’s $220 per person for those who want to join us —-and that includes everything lunch drinks and fishing licenses tackle and everything love you!

**Sally Bergosh**: I think if you book it for only two, it’s less expensive. Do we get charged for 4, or will they only charge us for how many come that day?

**Jeff Bergosh**: I’ll work it out with them just wanted to lock down for so they didn’t add other people to our boat and it’s $160 more for four to be booked then just two

**Jeff Bergosh**: Brandon’s coming over for dinner Sunday!!❤️👌👍

**Sally Bergosh**: Fabulous!!

**Jeff Bergosh**: Sally unfortunately Sunday got booked so the only times they have available or Monday or Saturday Monday we’re leaving so can I book this charter boat for early in the morning on Saturday?

### CONVERSATION ON 01-23-2022

**Sally Bergosh**: I would remind him! He’s getting old!:)

### CONVERSATION ON 01-24-2022

**Jeff Bergosh**: Monya from Sherwood wanted me to tell you hello! Guidance counselor.

**Sally Bergosh**: Love me some Monya!! She “gets it” and is a doer!!

**Jeff Bergosh**: She was super complementary of you!

**Sally Bergosh**: Had my meeting with Jules, Chandra & Michelle! She told all of us that she’s running for Doug’s seat and is just waiting for Doug to decide if he wants her or Frank White, who has also met with republican chairman & asked to be the new candidate for D1. She told everyone at our meeting that the candidate WILL be either her or Frank White. Period. Jules asked about Andrade and Michelle said Broxson will be picking his successor and Andrade was totally shot down!! 

**Sally Bergosh**: She was so errogant & full of herself!!

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: You guys aren’t even political people

**Sally Bergosh**: No.....it was supposed to be about mental health but her & Jules went down that road....

**Sally Bergosh**: They are now BFF’s!!

**Jeff Bergosh**: Wow

**Sally Bergosh**: Jules doesn’t “get” Michelle yet!? Or hasn’t been burned by her yet!!

**Jeff Bergosh**: Just a matter of time till that happens

**Sally Bergosh**: Yep- give some peeps enough rope & give them time to hang themselves- Jules said she is the lobbyist for Sacred Heart & spends a lot of time in Tallahassee.

**Jeff Bergosh**: Sounds like a meeting I’m glad I missed LOL

**Jeff Bergosh**: Mini egos in the room sounds like a county commission meeting LOL

**Sally Bergosh**: She also explained to get all her funding she has been SOooo successful getting she asks for it under categories that have nothing to do with it & then thinks of a clever way to justify it!! Jules said she is still trying to learn from Michelle on this trick! Lol

**Jeff Bergosh**: That sounds unethical to me

**Sally Bergosh**: Reread this today & thought of you, Nicky!

**Jeff Bergosh**: Awesome!!!! We will be there!!!!!

### CONVERSATION ON 01-25-2022

**Jeff Bergosh**: I love you I’m getting sleepy and I’m heading to bed I’ve got a Rotary meeting in the morning but I’m speaking at come home soon I love you!

**Sally Bergosh**: Love u right back- 30 minutes later I’m home and u r sound to sleep! What a gift u have- so, so envious!!

**Sally Bergosh**: I told Fabero’s we could do this famous Bonelli’s Italian on Saturday, Feb 19! Please add to your calendar!
Jeanette’s text:
Can ya'll do Bonelli's Feb. 18 or 19th?

**Sally Bergosh**: We now have a family membership at RS for clay & hard courts! You & Tori should play after she gets out of school!:)

**Sally Bergosh**: Loved an image

**Jeff Bergosh**: Not sure who all will be coming but I hope they will be!

**Sally Bergosh**: I think for organizing, Tori & Brandon need to ask for dates off soon, if this does not conflict with school.

### CONVERSATION ON 01-26-2022

**Sally Bergosh**: They were complaining on Beulah Scoop that no one asnswers phones at the government agencies & then said they need to vote them out and get peeps in office that WANT to serve & that WILL respond!! 

**Jeff Bergosh**: We answer our phones!

**Jeff Bergosh**: Sally I transferred money over to your checking account to get you through as I think you said you have a hair appointment today.  Your balance is now $186— after the $95 Mary Kay check cleared— so you should be good to go!

Love,

Me

**Sally Bergosh**: Love u right back!! Love it- team work!!😂👍

**Jeff Bergosh**: 👍

**Sally Bergosh**: Please send me Michael Kimberl’s contact # please!:( I have an injured migrant worker that was taken from the construction site and dropped off at a motel! I can’t treat him without a picture Id!

**Jeff Bergosh**: Going to bed— exhausted.  Love u!  See u when u get home!!

**Sally Bergosh**: Love you!!❤️

**Sally Bergosh**: Love that you all got out and played tennis. Remind me why I’m not currently playing? Oh yes, I’m still at work at the clinic! Ugh!!

### CONVERSATION ON 01-27-2022

**Jeff Bergosh**: Okay You’re back in business:

$900 in checking
$900 in savings acct

**Sally Bergosh**: Sure!!:) Punch & cake on the lawn and no hard copy invite......let’s discuss!😂😇

**Jeff Bergosh**: LOL I know

### CONVERSATION ON 01-28-2022

**Jeff Bergosh**: Your boy Marlette going after Troy Rafferty, Lumon May, Steven Barry, and Robert Bender.  Incredibly—- he left me out of this hatchet job article……

**Sally Bergosh**: Well stay out of it for once!! None of them ever defend you! I’m so tired of this!!

**Jeff Bergosh**: I’m not involved in this one

**Jeff Bergosh**: 😀👌👍

**Sally Bergosh**: Did u see my edits for the newsletter? It needs to go out ASAP

**Sally Bergosh**: ?!!?

**Jeff Bergosh**: Didn’t get any email from you yet.  Please re-send 

**Jeff Bergosh**: And I’ll get it out

**Sally Bergosh**: I resent

**Jeff Bergosh**: Got it this time.  The reason I didn’t get the first one is because you replied to the email “news@healthandhopeclinic.org”

**Jeff Bergosh**: LOL

**Sally Bergosh**: Whoops!! Are u okay to make those changes?!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Okay I sent it out to all the distribution lists 👍😀👌

**Sally Bergosh**: Yay!! Thank you! I’m trying to wrap things up at the clinic!

**Jeff Bergosh**: Perfect.  I’m making rice and garlic/herb chicken for dinner!👍👍😀😀

**Sally Bergosh**: Can’t u come late to the prayer breakfast tomorrow?

**Jeff Bergosh**: No— I have to be in Perdido Key tomorrow morning I volunteered to be a labor for the installation of a demonstration garden of seagrass and see oats

**Sally Bergosh**: It would be really great for Michelle to feel your support & might also go a long way with your buddy Broxson

**Jeff Bergosh**: It’s a real big deal and I had it on the calendar before this prayer breakfast anyway

**Jeff Bergosh**: I had an hour and a half meeting with Broxson today on a different issue and things went fine

**Sally Bergosh**: They won’t do that tomorrow- I’ll bet they call it off- even our Saturday Tennis ladies ain’t playing tomorrow due to the cold!!

**Jeff Bergosh**: No it’s a go

### CONVERSATION ON 01-29-2022

**Jeff Bergosh**: ???????

**Sally Bergosh**: No- It is not on table

**Jeff Bergosh**: Okay I thought I left it there somewhere because when I got to Walmart it wasn’t with me.  Okay— we’ll I did the best I could from memory

**Sally Bergosh**: K

### CONVERSATION ON 01-30-2022

**Jeff Bergosh**: Okay so here’s the latest on Brandon…..

Love

Me

### CONVERSATION ON 01-31-2022

**Sally Bergosh**: Tori has still not come out of her room this morning. She just told me “ I already emailed my teacher that I’m going to be running late”!

**Jeff Bergosh**: She’s got to focus on what is important.  I hope she has the staying power to finish this year and finally become a nurse

**Sally Bergosh**: It’s beyond crazy and yes, she does have a test today!!

**Jeff Bergosh**: Heading into my Perdido town hall.  Looks like a big crowd!  Wish me luck!  It will be streamed live on Escambia County’s Facebook in case you want to watch. 

Love!

Me

**Sally Bergosh**: I’m on YMCA zoom meeting but will do! Love you and just remember to be calm, classy & positive! Do not say any discerning remarks about Doug!!!! Be “presidential & Christian! 

**Sally Bergosh**: Praying for you

**Jeff Bergosh**: Thanks it went very well!!

**Sally Bergosh**: Cabo temps!

### CONVERSATION ON 02-01-2022

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I think it’s a great story I just read it I think it’s outstanding

**Jeff Bergosh**: If that guy has a problem he should call the author not you and it wasn’t you that said they were closed

**Sally Bergosh**: He did call Bella & they had Allison McCreary call me already! I explained I was in journalism & totally get it but to be clear: we did not start as a dental clinic, we said we took on all his patients while St. Joseph’s was closed during the pandemic, and I never said we RENTED a location on Chemstrand, little nuances that can be big to donors apparently at St. Joseph’s! Oy vey!!

