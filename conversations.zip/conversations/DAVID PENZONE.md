

## CONVERSATIONS WITH DAVID PENZONE

### CONVERSATION ON 06-29-2021

**Jeff Bergosh**: It’s an interesting listen.........

**Jeff Bergosh**: Thanks — got it

