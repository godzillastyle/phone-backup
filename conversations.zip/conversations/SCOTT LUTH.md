

## CONVERSATIONS WITH SCOTT LUTH

### CONVERSATION ON 12-12-2019

**Scott Luth**: Need to move forward with motion to vote today if you can

**Jeff Bergosh**: Trying

**Jeff Bergosh**: Don’t want to lose it

**Scott Luth**: Doing great - I believe Allison is correct, it is net new 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: What is the total number of jobs committed to date

**Scott Luth**: I don’t have it with me.  However, If the base line is blank.  You can work with company to identify that number before closing and confirm they can’t double dip.

**Scott Luth**: https://www.navyfederal.org/pdf/publications/campus_expansion.pdf

**Jeff Bergosh**: Are they giving directory information to other state entities?

**Jeff Bergosh**: Salty banding, etc?

**Scott Luth**: The state and NFCU negotiated the delivery confidential  of employment information.  I have not been given that detailed information. 

**Jeff Bergosh**: Moot point now.......We got it done, it’s approved

**Scott Luth**: I hate this was so tough. Great job keeping it moving 

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Incremental forward progress is good

### CONVERSATION ON 08-18-2020

**Scott Luth**: 👍 way to go. 

**Jeff Bergosh**: Thanks Scott!!

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: R u watching this garbage presentation??

**Scott Luth**: I am, when can you get together to talk now that the election is over ? 

**Jeff Bergosh**: I’ll call u today to set it up

**Jeff Bergosh**: They want a residential real estate project

**Scott Luth**: That’s all DPZ does, they don’t know anything different. I am working on my own data assessments. 

**Scott Luth**: We need to ask DPZ if they have assessed our community on a Economic risk assessment. Comparing retail, service, and residential to wealth generating projects like GE, NFCU, and others. 

**Jeff Bergosh**: I’ll ask

**Scott Luth**: Like the Great Recession   

### CONVERSATION ON 10-12-2020

**Jeff Bergosh**: I’m doing an interview with channel 3 at 11:15 about DPZ, Charettes, and OLF 8.  I’d like to talk about the survey results you shared from the polling.  Any issues with that?

**Jeff Bergosh**: ....and if so, can you send me those results electronically?

**Scott Luth**: I think it should be fine, I will send them to you. 

**Jeff Bergosh**: Okay great thanks!

**Scott Luth**: Just sent 

**Jeff Bergosh**: Thx

### CONVERSATION ON 10-13-2020

**Scott Luth**: Who told the consultant that tax value per acre is the primary measure of success. I have never seen Urban3 or anyone on the team show a 3D map of economic impact per acre. People with jobs pay taxes.

**Jeff Bergosh**: Exactly

### CONVERSATION ON 12-08-2020

**Scott Luth**: Good directions to DPZ today. When you get a chance I would like to see the economic impact model they sent. Thanks

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Thx

### CONVERSATION ON 01-18-2021

**Scott Luth**: Good afternoon Jeff, I wanted to give you a heads up that we may have members of the Beulah  Coalition and Nature Trail attend the PEDC meeting tomorrow to talk about OLF8. It is our plan to let them speak for 2 or 3 minutes each during our public comment period. OLF8 is not on the agenda so the PEDC has no plans for discussion. Call if you have any questions. Thanks

### CONVERSATION ON 01-21-2021

**Scott Luth**: Jeff, what is Travis Peterson getting paid for? I though his job as a sub for DPZ was to manage the communication on this project. 

**Jeff Bergosh**: I agree.  There were several of them all spun up at our public forum.  I diffused the bomb and let them know there is no “fight” to be had.  We all want the same thing!  Amenities, parks, a post office, some retail, and restaurants.  And good high paying jobs in attractive facilities.  No need for a fight!

**Jeff Bergosh**: That’s my new mantra!

**Scott Luth**: I agree, I watched and you did a great job. Thanks for the positive message. 

**Jeff Bergosh**: Thanks Scott!

### CONVERSATION ON 01-26-2021

**Scott Luth**: Jeff, I hope my email to Marina this evening is in line with your thoughts. Thanks

**Jeff Bergosh**: Looks good to me!  Thanks for weighing in Scott!

**Scott Luth**: Liked “Looks good to me!  Thanks for weighing in Scott!”

### CONVERSATION ON 02-01-2021

**Jeff Bergosh**: In a meeting will call u back

**Scott Luth**: Thanks 

### CONVERSATION ON 02-08-2021

**Scott Luth**: I continue to wonder what “Market Analysis”DPZ did.

**Scott Luth**: https://www.al.com/business/2021/01/amazon-may-build-45-million-spanish-fort-distribution-facility.html

**Scott Luth**: https://www.bizjournals.com/birmingham/news/2020/07/21/aldi-regional-hq-alabama.html

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Wow—we could have had this.  Would these jobs have qualified for triumph gulf coast grant?

**Scott Luth**: I am sure some of them would have. With Triumph we can’t cherry pick the high wage jobs.

**Scott Luth**: The project announced back in July but they had the ground breaking yesterday.

**Jeff Bergosh**: Thanks for this information— It will help me in my presentation  today at Nature Trail

**Scott Luth**: Good luck, and I think it’s great you are doing it. 

**Jeff Bergosh**: Thanks Scott— the info you provided will help a lot

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: Exciting opportunity

**Scott Luth**: Looking forward to it 

### CONVERSATION ON 02-22-2021

**Scott Luth**: Wow 

**Jeff Bergosh**: Too harsh?

**Scott Luth**: No, her lack of a response. 

**Jeff Bergosh**: Yeah I thought her response was arrogant. 

### CONVERSATION ON 03-12-2021

**Scott Luth**: Wow nice PNJ article. 

**Jeff Bergosh**: Andy’s hit piece??

**Scott Luth**: Yes, apparently the attacks haven’t ended.  Just gotten worse and more personal. 

**Jeff Bergosh**: Yep

**Jeff Bergosh**: It’s called fake news media controlled by a large advertising patron and Navy Federal credit Union both of them want what they want

**Scott Luth**: Let’s talk next week. Not sure how best to move forward. 

### CONVERSATION ON 03-13-2021

**Jeff Bergosh**: FWIW—take a look at the PNJ Facebook post of Andy Marlette’s hatchet job.  It backfired on him spectacularly and the commenters are beating the crap out of Andy and the PNJ.  It happened because like dummies, they mixed up the messages, talked crap about MATT Gaetz, put my picture up, and threw in the hashtag #freeBrittney.  Then, in their final act of stupidity, they locked the post for “subscribers only” so nobody could get the real context which was a hit on me.  A spectacular failure on their part which elicited a bashing to PNJ which they deserve.  A real, complete failure on their part here!👍😎

**Scott Luth**: Good deal, now only if the advertisers would follow. Lewis said the only ad he sees is Rooms to Go, 😀

### CONVERSATION ON 06-24-2021

**Scott Luth**: Just sent it to you. Call with any questions, thanks 

**Jeff Bergosh**: Thx

**Scott Luth**: Thanks again for your time. When do you all get a copy of the agenda. Was wondering when D2 would see it. 

**Jeff Bergosh**: Typically Friday late afternoon

**Scott Luth**: Amos two weeks in advance?

**Jeff Bergosh**: No— the Friday before the mtg

**Jeff Bergosh**: Next Friday

**Scott Luth**: Okay that’s why I was confused, thanks 

**Jeff Bergosh**: No problem

### CONVERSATION ON 07-07-2021

**Jeff Bergosh**: 850-469-6122

Terry St. Cyr

**Jeff Bergosh**: Thanks!

**Scott Luth**: Sound good, I forgot to say. No one plans to discuss the Cantonment project tomorrow. But if it should come up you have the background info. Thanks

**Scott Luth**: You need me at the meeting tomorrow on the OLF8 item?

**Jeff Bergosh**: I don’t think so Scott— thanks for offering to be there though!

**Scott Luth**: Liked “I don’t think so Scott— thanks for offering to be there though!”

### CONVERSATION ON 07-20-2021

**Scott Luth**: Jeff, I was looking at the online PowerPoint for the budget review and did not see PEDC listed. I did see PEDC listed on the full print out budget but we were moved back to general funds instead of LOST. Do you know why it was changed? Thanks 

**Jeff Bergosh**: Hey Scott I saw that too and I’m not sure why they did that but I know you’re on the list and I know that you guys are going to get funded

**Scott Luth**: I figured we were good, just thought it was an odd change. Thanks for letting me know 

**Jeff Bergosh**: Absolutely

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-13-2021

**Scott Luth**: Jeff, call back when you can. Wanted to known if you had time to meet with a prospect early Wednesday morning.

**Jeff Bergosh**: Stacked up in meetings all day will call you after 

**Scott Luth**: Liked “Stacked up in meetings all day will call you after ”

### CONVERSATION ON 10-08-2021

**Jeff Bergosh**: I’m in Copenhagen Scott— everything alright?

**Scott Luth**: Nothing urgent/ enjoy 

**Jeff Bergosh**: Okay great I’ll call u when I get back Wednesday

### CONVERSATION ON 11-29-2021

**Jeff Bergosh**: In mtg will call u after

**Scott Luth**: Liked “In mtg will call u after”

**Scott Luth**: Jeff and Ed, we are all good for a call tomorrow at 11:15. I will call your cell phones and set up the 3 way call. Thanks

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: Hey Scott we’re on our way to your event but we’re running a few minutes late hopefully that’ll be all right?

**Jeff Bergosh**: I mean hopefully it’s not a set program that starts right at 4:30

**Scott Luth**: No sir come and go 

### CONVERSATION ON 01-04-2022

**Jeff Bergosh**: Hey Scott quick question project citron that group is coming to Marcus pointe right? Is that where they’re building their facility? Thanks

**Scott Luth**: Citron is the DNA project downtown off garden. 

