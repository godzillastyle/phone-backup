

## CONVERSATIONS WITH BLAYNE ALEXANDER

### CONVERSATION ON 12-07-2019

**Jeff Bergosh**: Got it thanks Blayne

### CONVERSATION ON 12-08-2019

**Jeff Bergosh**: All--NAS Pensacola's Facebook site just posted the pictured advisory, stating the base will be open to those who possess DoD issued ID cards only--which is applicable to us.  So we will work our normal schedule tomorrow unless we are directed otherwise.  We will have our 0730  weekly meeting as well.  I do anticipate heightened security so keep this in mind and plan your commute timing accordingly to account for this.  I'll see you all in the morning.

Jeff B

**Jeff Bergosh**: The blog post has photos in and out of the unit as well as capabilities in case you are interested

**Jeff Bergosh**: Sure thing Blayne—just an Interesting sidenote of how Escambia county is putting all of our resources at the disposal of the entities that are investigating this tragedy

