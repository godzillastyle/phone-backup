

## CONVERSATIONS WITH DAVID PEADEN

### CONVERSATION ON 10-23-2019

**David Peaden**: Gospo and Gumbo is this Sunday at 5 Eleven Palafox at 4 pm. It is for the Michael E. Green Prescription Fund for the St. Joseph’s Clinic. Sally and you are welcome to be my guest. I just need to know for sure if you want to go and I will put you on the list. I spoke to Sally about it last night and told her I would follow up with you.

**Jeff Bergosh**: That sounds fantastic thank you David—is it formal dress?  Or business casual?

**David Peaden**: Great. It’s casual. Button down shirt, khaki pants type thing. You can google and see photos from past events. 

**Jeff Bergosh**: Okay I’ll be there and I’ll check with Sally—she may have choir practice but maybe I can talk her into skipping😎.  I can let you know for sure for her tomorrow if that works

**Jeff Bergosh**: And thank you very much for coming last night and bringing friends it was a great event and I really really appreciate your help and support!!

### CONVERSATION ON 10-24-2019

**David Peaden**: You’re welcome. Just following up to see about Sunday if you’re good to go.

**Jeff Bergosh**: Sally is going to be at a conference up in Atlanta for the Health and Hope Clinic—but I’m planning on coming-I really appreciate the invitation!

**David Peaden**: Ok. Great. 

**Jeff Bergosh**: See you Sunday

### CONVERSATION ON 10-30-2019

**David Peaden**: I'll call you right back

**Jeff Bergosh**: Thx

### CONVERSATION ON 11-25-2019

**David Peaden**: He read the book: how to make friends and influence people!

**Jeff Bergosh**: LOL.  And he wonders why he can’t get the board behind his initiatives, can’t get anything done, and also why he is consistently on the bottom of 4-1 votes.  Abracadabra—there it is!  BS posts like this one!

### CONVERSATION ON 11-26-2019

**Jeff Bergosh**: Wow!  Is this even legal?

**David Peaden**: Don’t know.  He’s been on a rampage. 

**Jeff Bergosh**: What a guy.......so angry and abrasive all the time.  He needs to take a chill pill LOL😂

**David Peaden**: Never have seen anything like it. Strange. 

**Jeff Bergosh**: That’s for sure!

**David Peaden**: Anonymous donations to an elected official? Now that has to be illegal! 

### CONVERSATION ON 11-27-2019

**Jeff Bergosh**: That’s what I’m saying too??  How will he be able to report that on his quarterly report of gifts??

**David Peaden**: David Bear gave $5! Lol. Posted on Facebook and said I hope he appreciate my support!

**Jeff Bergosh**: LOL

**David Peaden**: Doug responded! This is too much entertainment!

**Jeff Bergosh**: LOL

**Jeff Bergosh**: He’s going to have one hell of a Thanksgiving!  Peaceful, relaxing, .............NOT

**David Peaden**: Maybe we should invite him to this!

**Jeff Bergosh**: He wouldn’t fit in

**Jeff Bergosh**: .....made himself one

### CONVERSATION ON 12-17-2019

**David Peaden**: Call me when you have a minute. 

**Jeff Bergosh**: Will do

### CONVERSATION ON 12-26-2019

**David Peaden**: I don’t know what I did to deserve this at 10 pm last night. I will assume you didn’t get one!

**Jeff Bergosh**: LOL I got one too

### CONVERSATION ON 01-07-2020

**David Peaden**: I hear J Owens is filing on Thursday.

**Jeff Bergosh**: Yep

**David Peaden**: Wow! Good job. 

**Jeff Bergosh**: Thx

### CONVERSATION ON 01-08-2020

**David Peaden**: You have some editing to do! 

**Jeff Bergosh**: LOL

### CONVERSATION ON 01-10-2020

**David Peaden**: Mic drop! Impactful statement that will resonate! 
"Doug and Jonathan are best friends at work and outside of work, and I just don't think District 1 wants to turn over District 1 to District 2," Bergosh said. "And I think this (Owens' candidacy) sends a signal that that duo wants to run two-fifths of the county. And I don't think the voters of District 1 are going to go for it."

**Jeff Bergosh**: You like?

**David Peaden**: Liked “You like?”

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**David Peaden**: That looks great. One question about Gary. That job pays the same he is making now. Why take the headache of running the whole operation?

**Jeff Bergosh**: I’m not sure he’s going to run or not I just wanted to know where he would land in a race against Marcile—that’s why I ran one of those questions on my poll just so I would know. Gary-had no idea I was going to do it!  I do think he enjoys the results however😎👍

**David Peaden**: You are trying to ruin your brother’s quality of life! He’s a good man. 

**Jeff Bergosh**: LOL

**David Peaden**: Would you like share that poll with Owens? 

**Jeff Bergosh**: Nope

**David Peaden**: 10-4

**Jeff Bergosh**: ThanksI want him to go spend his own money and get the same result LOL

**David Peaden**: Brutal! 

**Jeff Bergosh**: 😎He’s the one who chose to step in to the octagon

**David Peaden**: Old school! Whooo!

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 02-27-2020

**David Peaden**: You see this?

**Jeff Bergosh**: Yeah that’s pretty funny

**David Peaden**: Had a long talk with the Judge yesterday. Ran into him at the coffee cup. He’s good people. I told him he had balls to sign that warrant!

**Jeff Bergosh**: Thanks David-the funny thing is I think when he signed it he treated it just like any other juvenile —I don’t think he even knew the kid was Doug’s son......although I believe he would have signed it anyway 😎

### CONVERSATION ON 03-20-2020

**David Peaden**: https://www.thegatewaypundit.com/2020/03/us-coronavirus-mortality-rate-already-down-to-1-4-when-will-who-director-be-held-to-account-for-setting-off-global-panic-with-his-faulty-numbers/

**David Peaden**: This is a good conservative website. 

**Jeff Bergosh**: Meanwhile the department of health website their ——state wide dashboard ——says that Escambia County has only conducted 18 tests. It is unbelievable the ineptitude that is happening right now with these tests and more importantly getting the results back. 

And yet we are supposed to make decisions based on phantom projections with nobody giving us the real data??

People of lost their minds

**David Peaden**: I knew you’re a data guy and would appreciate this. 

### CONVERSATION ON 03-22-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/test-results-starting-to-trickle-in-at.html?m=1

### CONVERSATION ON 03-30-2020

**David Peaden**: Gary has to do it now! 

### CONVERSATION ON 03-31-2020

**Jeff Bergosh**: I wish he would!

### CONVERSATION ON 04-01-2020

**David Peaden**: In light of Doug’s statewide email to the Florida Legislature, County Commissioners the voters of Escambia County, and the PNJ article, as your friend, I would strongly encourage you to reconsider your position of opening up the beach or even having a discussion about it. The number one reason is you do not want to be associated with Doug. Right or wrong, facts or not, the public is not going to be on your side about this. Plus you do not need to be on the same side as Doug Underhill, Mike Hill and their followers. Think about that. By advocating opening up the beach, you will come across as a loon. There is no way around that. You may be 100 percent right with the data, but in the eyes of the community, you will be wrong. Everyone has sacrificed to keep the virus in check. If the beach business people are in your ear, they don’t have the political capital to get anything done. If they did, we would have roundabouts by now and Karen Sindell would be District 1 commissioner. Those beach people promised her $100k to run. They did not follow through. She regrets putting her trust in them to this day. In an election year, you must not make self inflicted mistakes that will hurt you. In my opinion, Bender, Barry and May will not vote to open it up. Jeff, be strategic. If you asked for it to be on the agenda, ask to remove it. Let Doug be the one who does it. The long and short of this is that you do not, under any circumstances, want to be associated with Underhill and to lose credibility with the voters of your district. 

**Jeff Bergosh**: I agree David!

**Jeff Bergosh**: It’s only on the agenda because we only closed it until April 2nd the first time—so we either have to extend the ban or let it expire.

**David Peaden**: Ok, good. Thanks, man!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Governor’s EO from today

**David Peaden**: Thank you!

### CONVERSATION ON 04-08-2020

**David Peaden**: https://neighbors.ring.com/n/n9OoWLA4OE

**David Peaden**: 
Gulf Breeze stealing trump flag. 

**David Peaden**: He’s a Sacred Heart doctor! How embarrassing!

**Jeff Bergosh**: Wow!!

### CONVERSATION ON 04-09-2020

**Jeff Bergosh**: Was it really this doctor??

**David Peaden**: It is on the Facebook page of Cathy Pfeiffer Ikner. This doctor lives close to attorney Terry Gross. His wife is a doctor too. They had walked down to Terry's neighbors and was having wine on the deck and on their way back home is when they did it. 

**Jeff Bergosh**: This is the kind of story that typically goes viral.  Surprised it hasn’t already

**David Peaden**: Bridget Jensen is not going to run. Sure wish Gary would do it! 

**Jeff Bergosh**: Me too.  But he can’t commit economic suicide—And nobody stepped up to put him to work for eight months so he could run and not go bankrupt

**Jeff Bergosh**: To Destin

**David Peaden**: That’s what I hate. We’ve lost our congressional seat and now this. 

**Jeff Bergosh**: Me too.  Gary would win big, polling indicates that

**Jeff Bergosh**: Maybe the “real” powers that be locally want this seat over in Okaloosa 

**David Peaden**: He would win. I really believe that. He has the name recognition, military credentials and the know how and smarts to do it. 

**David Peaden**: I don’t think that’s it. She is getting it by default. We have the voter base to beat her. She has no ties over here.  And she has no record of success. 

**Jeff Bergosh**: .................an opportunity missed for Escambia County 

### CONVERSATION ON 04-14-2020

**David Peaden**: The flag stealing people!

**Jeff Bergosh**: Wow

**David Peaden**: They smiled!  That’s a good idea for a mug shot

**Jeff Bergosh**: So it was real

**David Peaden**: Yes. 

**Jeff Bergosh**: Not smart

**David Peaden**: Sacred heart doctor

**David Peaden**: He may need a respirator!

**Jeff Bergosh**: 
......and a ventilator LOL

**David Peaden**: Yeah! I am always messing up my words! Just ask my wife and kids! Lol

**David Peaden**: It’s out there nationally now!

**Jeff Bergosh**: Boom!

**David Peaden**: Tucker, Hannity and Ingram will be all over it. 

### CONVERSATION ON 04-16-2020

**David Peaden**: Just saw your blog. Backstory to the block party. Lawrence Powell, who now works as director of Constituent and Neighborhood Services for the city, and Councilwoman Jewell Cannada-Wynn were called by the city police to go and ask the party goers to disperse so the police would not have to go. They went and were unsuccessful. No one would listen to them. Then the cops came in and no one would listen to them. It took two hours for the cops to get them to leave. 

**Jeff Bergosh**: It was a terrible optic for the city.....terrible

### CONVERSATION ON 04-29-2020

**David Peaden**: This has teeth. 

**Jeff Bergosh**: Wow!  Did that go public somewhere?

**David Peaden**: Not yet. Outzen has it since last Friday. Hasn’t posted. PNJ May get it today.

**Jeff Bergosh**: Wow

**Jeff Bergosh**: How could any “so-called” news outlet sit on this?  Seems like news.........

**David Peaden**: You have to send it to your email and read it. It is hard to read off your phone. It’s very well done. Tallahassee law firm put it together. 

**Jeff Bergosh**: It will Be interesting to see if anything comes of it

**Jeff Bergosh**: Doug seems to be made out of Teflon

**David Peaden**: Yes he does. But he seems to be getting more agitated. Aggressive. Calling a citizen a pussy on Facebook is one of many examples. 

**Jeff Bergosh**: I agree.  

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good afternoon David—-as a person that has helped me in my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday David!

**David Peaden**: Very good. Keep the hammer down. And calling him Doug Underhill’s Secretary! Lol. 

**Jeff Bergosh**: That’s what he is 😎

**David Peaden**: What were Salzman’s numbers? 

**Jeff Bergosh**: 53-47 Hill

**Jeff Bergosh**: 75-25 Simmons over Alexander

**David Peaden**: Good for Michelle.  She’s almost there. Very nice of you to do that. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-19-2020

**David Peaden**: 
We believe that the absence of term limits on Board Members has created a sense of complacency and has fostered an overreliance on the executive director and attorneys. An amendment to the Special Act should be considered that would place term limits on Board Members.

In his testimony, we found Odom to be both unprofessional and unprepared. We make these findings because they are important and should be considered by the Board in future decisions.
• We recommend that the employment contract for the executive director be renegotiated every two years with no automatic renewal provision. The current contract has been in place since 2004.

### CONVERSATION ON 05-29-2020

**David Peaden**: As I always say, North Korea is more transparent than ECUA!

**Jeff Bergosh**: Yeah— they stepped in it on this one.  If it was so immaterial as Bowers says—- Then why did the attorney administrator any district commissioner not have that information?

**David Peaden**: A little history 

### CONVERSATION ON 07-01-2020

**David Peaden**: https://www.thegatewaypundit.com/2020/07/now-even-common-cold-counted-positive-covid-19-result-cdc-says/

**David Peaden**: Ask Lanza if this could be increasing the numbers. 

**David Peaden**: Directly from the CDC website 

**Jeff Bergosh**: Wow!

### CONVERSATION ON 07-02-2020

**David Peaden**: How much does eminent domain costs? My gosh. 

**Jeff Bergosh**: Crazy right??

**David Peaden**: He keeps mentioning Super Majority meaning Doug your thoughts don’t matter. 

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: 4-1 coming

**David Peaden**: You leaned back in your chair and looked at the roof! Cracked me up! 

**Jeff Bergosh**: LOL

**David Peaden**: Bender seems a little agitated tonight too.

**Jeff Bergosh**: I get a migraine when Doug tries to act like the expert in all things.....

**David Peaden**: Bankruptcy Doug loves to lecture about finances. 

**Jeff Bergosh**: Lecturing us as if he is an expert

**Jeff Bergosh**: .......wonder if he ever paid them all back once he got in his feet again after?

**David Peaden**: Yeah. Ask Hancock bank. 

**Jeff Bergosh**: *on

**Jeff Bergosh**: Yeah and NFCU took a hit too

**David Peaden**: Didn’t know that with NFCU

**Jeff Bergosh**: Like $29K if I remember right 

**David Peaden**: Dang

**Jeff Bergosh**: Yeah- crazy right?

**Jeff Bergosh**: ....meanwhile Doug presumes to lecture us on fiscal austerity and responsible budgeting

**David Peaden**: Yes on Gulf Coast for sure. I don’t know what he would be doing with NFCU. 

**Jeff Bergosh**: Maybe it was a personal loan or something

**David Peaden**: Probably so. Don Gaetz is going to have a field day on the ethics commission with him. 

**Jeff Bergosh**: I sure hope so!!

### CONVERSATION ON 07-14-2020

**Jeff Bergosh**: Wow!!

### CONVERSATION ON 07-15-2020

**David Peaden**: Like napalm in the morning, a lecture from Doug! 

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I’m already getting a migraine

**David Peaden**: Haha! Lol 

### CONVERSATION ON 07-24-2020

**Jeff Bergosh**: He is a sleazebag.  He brings this up again with some sort of righteous indignation I’ll bring up his bankruptcy.  In excruciating detail

**David Peaden**: Call me when you can. Doesn’t have to be right now. I’ll let you drink your coffee! 

**Jeff Bergosh**: Will do

**David Peaden**: I’ve thought about this mask stuff and based on the numbers. The numbers may very well be right, that 2/3, or even 1/2 people support an ordinance. However, given the political climate and that Santa Rosa is not even going to talk about a mandatory ordinance, Escambia not doing one yet is not going to rile the people up to pitchforks on primary, but it will energize and motivate the also large portion of people who do not support an ordinance to make their one mission in life beating you in a primary. Plus Doug will make it his life’s mission to rub your nose in it. My overall concern is that you will mobilize a base of haters that you do not need. If you do nothing until August 18 you will win. Think about it.

**Jeff Bergosh**: That is very wise advice that I will take

**David Peaden**: Thank you! 

**Jeff Bergosh**: 👍

**David Peaden**: The great Dr Fauci

**Jeff Bergosh**: “Do as I say, not as I do!”

**David Peaden**: Merry Christmas! He’s the gift that keeps on giving! 

**Jeff Bergosh**: What a tool

### CONVERSATION ON 08-06-2020

**David Peaden**: Y’all just Grover packing! 

**Jeff Bergosh**: We did it politely and reapectfulky

**Jeff Bergosh**: Respectfully

**David Peaden**: Me thinks he didn’t like that too much. Did not expect that from Robert because I thought Grover influences him a lot. 

**Jeff Bergosh**: Grover correctly placed his finger on Grover’s Jugular vein:  when Keith and Grover were with the County— they were actively opposed to lump sum restore act dumps to the city— instead they wanted the county to control the money and accept projects from the city.  But now Keith and Grover are at the city—- they don’t want to follow the protocols they established while they were both with the county as it pertains to this cash windfall and CARES act.  Why the change of heart?  Well, we know why.  And It looks situationally expedient and hypocritical.  Yeah, they probably didn’t like Robert pointing that out.  

**David Peaden**: I love watching this stuff!

### CONVERSATION ON 08-12-2020

**David Peaden**: So, a Owens supporter said he has the election rapped up because nature trail is on his side. I bet a bottle of wine that he will come in third! 

**Jeff Bergosh**: They are smoking crystal meth!  Nature Trail is a lock?  BS I have a ton of friends that live there.  You are right, Jonathan comes in 3rd with 18-19 points tops.  His biggest issue now is trying to catch up to Jesse Casey—-who leads Jonathan by 15 points...........for 2nd place LOL

**Jeff Bergosh**: LOL

**David Peaden**: I mean to think it’s wrapped up. Jeeze. Also, Navy fed leadership is not your friend either. 

**Jeff Bergosh**: 
Yeah I know they’re not there gave money to Owens through Willard Dagnall

**Jeff Bergosh**: They’re upset we didn’t do the mandate for the mask

### CONVERSATION ON 08-18-2020

**David Peaden**: So far, 13,000 votes have been cast today. 

25k votes have been cast by mail

11k early voting.

**Jeff Bergosh**: 29%

**Jeff Bergosh**: ?

**David Peaden**: Escambiavotes.com>elections>voter turnout>select precinct and type from drop down menu

**David Peaden**: Sweet!!!! Congratulations!!!

**Jeff Bergosh**: Thanks David!!

**David Peaden**: You should call all your anti Jeff people tomorrow and tell them you appreciate their involvement in the political process and you hope that you can work together to find common ground etc. That will bring you good will and impress the losing side that you are willing to work together for the common good. Even though you can’t stand them, it will make a positive impression.

**Jeff Bergosh**: That’s a great idea David!

**David Peaden**: It will blow their minds! 

**Jeff Bergosh**: Yes it would

### CONVERSATION ON 08-19-2020

**David Peaden**: Owens is telling people that if Jesse would have gotten out he would have won. Yeah. No

**Jeff Bergosh**: He’s full of crap!  I would have issued a beat down to him

**Jeff Bergosh**: ..... a job for which he’s suited

**David Peaden**: Cracks me up! 

**Jeff Bergosh**: 😂😂😂😂😂😂

### CONVERSATION ON 09-08-2020

**David Peaden**: Jeff, you know I have a lot of respect for you so please hear me out. I strongly encourage you not to go down the same road as Underhill. He is not liked by Tallahassee folks both elected and unelected and he can’t get anything for his district for infrastructure from the state. His TPO priority list continues to get dropped. 

Please try another angle to get your point across with DOT. Yes there are problems but I would encourage you to be a statesman and build relationships with the DOT people. Going to the media helps you in the eyes of your constituents short term but in the long run you will be hosed by the people you need help from the most... DOT. Work behind the scenes to get answers. You will get more accomplished and then you can hold a press conference with the DOT people by your side when great news is warranted. As of now, they absolutely will not be helpful with the way you are publicly calling them out. Try to tone it back and I truly guarantee you that you will get better results. If you need my help to get a meeting with someone, give me a name and let me see what I can do. 

**Jeff Bergosh**: Thanks David. I’d like to discuss this with you.  Lots of Blackfoot Jui-Jitsu going on. 

**Jeff Bergosh**: LOL

**David Peaden**: You are the first to use Blackfoot ju-jitsu in a text! Cracks me up!

**Jeff Bergosh**: Yeah that was supposed to be back room LOL

**David Peaden**: United Nations guidelines for Brace?

### CONVERSATION ON 09-09-2020

**David Peaden**: I hear you made some peace today with DOT and you are willing to meet with them. That’s a good sign and I bet they are willing to help you. Good progress without ju-jitsu! You did well!

### CONVERSATION ON 09-10-2020

**Jeff Bergosh**: Thx David.  I just want them to finish their damn project

### CONVERSATION ON 10-01-2020

**David Peaden**: Jeff, you are much, much more savvy than to call out DOT in public. I urge you to do your work behind the scenes. You must understand that they will screw you six ways from Sunday and you will get nothing that you want accomplished. I know this as 100 💯 fact. They have hosed Underhill for years. Being in Underhill’s camp on this is truly political suicide. Please try a different method.

**Jeff Bergosh**: I know but I’m sick of them hiding out in Chipley

**Jeff Bergosh**: They need to own this problem——-it’s theirs!

**David Peaden**: But, you’ve got 4 more years! 

**Jeff Bergosh**: Yes I do.  Plus 2 months LOL

**David Peaden**: Laughed at “Yes I do.  Plus 2 months LOL”

**David Peaden**: When the beach is charging $400 a night a penny isn’t going to hurt.

### CONVERSATION ON 10-12-2020

**David Peaden**: Please call me when you get a minute. Tomorrow is fine too.

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: Will do David

### CONVERSATION ON 10-21-2020

**David Peaden**: FYI. Your planning board member’s term expires on 11/20. Either you have to put him up for renewal or have someone else submit an application.

**Jeff Bergosh**: Okay thanks for the heads up

### CONVERSATION ON 12-10-2020

**David Peaden**: That is absolutely a humble servant offer you did for Luman. I truly believe that it builds good will... and will have long lasting repercussions of nothing but positive outcomes in the future. 

**Jeff Bergosh**: Thx

### CONVERSATION ON 12-29-2020

**David Peaden**: https://www.reuters.com/article/us-health-coronavirus-hospitals-aid-insi-idUSKBN29310X

### CONVERSATION ON 01-11-2021

**David Peaden**: Please call me when you get a minute. 

**Jeff Bergosh**: Will do

**David Peaden**: FYI 

### CONVERSATION ON 01-13-2021

**David Peaden**: Fantastic job today! Immediately made a positive impact with folks at DOT. District secretary will be setting up a meeting with you soon.

**Jeff Bergosh**: Thx!

### CONVERSATION ON 01-21-2021

**David Peaden**: Biden already making it go away with less positivity numbers! 

**Jeff Bergosh**: Presto-chango!

### CONVERSATION ON 01-26-2021

**Jeff Bergosh**: Doug is getting savaged by the comments on the PNJ Facebook site.  Ouch!

**David Peaden**: Lol! I’ll take a look!

**Jeff Bergosh**: It’s like a UFC ground and pound beat down..... brutal

### CONVERSATION ON 01-27-2021

**David Peaden**: Tim Pyle will not run. Said nasty political climate, money needed while trying to grow his real estate business,  etc. 

**Jeff Bergosh**: So who’s going to run for that seat now?

**David Peaden**: Would not be surprised if Vicki Campbell did it. Other than that, I don’t know. 

**Jeff Bergosh**: Doug’s going to run again

**Jeff Bergosh**: Or have Jonathan try

**David Peaden**: You know as crazy at this sounds, you’re better off having Doug there because he can’t get a vote to do anything. So all you have to negotiate is the other 3 commissioners to get what you need. And from the looks of it, you get along well with the others who vote for your stuff and you vote for their stuff. Add in a 5th commissioner, then things go sideways! 

### CONVERSATION ON 01-30-2021

**David Peaden**: https://www.pnj.com/story/opinion/2021/01/30/editorial-escambia-county-residents-deserve-more-their-commissioners/4281936001/

**David Peaden**: Go get ‘em, Jeff. This is ridiculous. 

**Jeff Bergosh**: LOL

**David Peaden**: Have you seen where Andrade got into a fight in a Tallahassee bar? 

**David Peaden**: That editorial talks about the county’s policy, ignoring that the county had a policy against posting on social media at the time all these things happened, but why let the truth obstruct the point that you’re trying to make? Report the news!

**Jeff Bergosh**: Exactly!

### CONVERSATION ON 01-31-2021

**Jeff Bergosh**: So PNJ wrote a garbage editorial today.  I’m working a cartoon response.  What should this rat’s caption say?

**David Peaden**: “Hear ye hear ye bow before the king of the internet trolls” or “.... king of social media bullies” or “..... king of social media” and I’d love to see a pin or lapel on andy and lisa that says “Main Street Media”.
Reference to Studer influence on the paper, and play on “main stream media” phrase.  

**David Peaden**: The rat could also say “Sire, I have assembled the Main Street media to receive your royal decree”

**Jeff Bergosh**: That is funny!!!!

**Jeff Bergosh**: What is the significance of “Main Street media?”  Did you mean to say mainstream media?

**David Peaden**: It’s Main Street because that is where Studer has the baseball stadium and coffee shops etc. I think people would get that reference. 

**Jeff Bergosh**: Oh got it.  Clever.  

**David Peaden**: And it looks great!

**Jeff Bergosh**: Thanks!  What about this:  “someone told them Q stands for Quint!”

**David Peaden**: I took Q as Quanon for Doug and his followers. I would not write out the word quint. 

**Jeff Bergosh**: Yeah they might be a bit much

**Jeff Bergosh**: But it is funny though

**David Peaden**: Lol. You’re funny!

**Jeff Bergosh**: 😎👍

**David Peaden**: Bawahawhaahahaha! You’re right. That would “rattle some cages” as Dale Earnhardt used to say. 

**Jeff Bergosh**: Lol

**David Peaden**: That puppet master arm could be used. That’s strong. 

**Jeff Bergosh**: Funny right?

**David Peaden**: Yes. Especially with the Main Street reference. 

**Jeff Bergosh**: Yep!  I like it.  It’s, cerebral!

**Jeff Bergosh**: “Variations on a theme”

**David Peaden**: I think too many of them takes away from the brilliance of one powerful one. 

**David Peaden**: Or save your ammo for the next go around. 

**Jeff Bergosh**: Good point

**David Peaden**: “This piece of garbage smells worse than their last offering directed our way.  It smells so bad, it's like a pile of rotting fish marinated in a blend of sulfur, dog feces, and vomit.  And it's off-base, to boot.”

This is so damn funny! Pure Gold! 

### CONVERSATION ON 02-01-2021

**Jeff Bergosh**: Thanks David!

### CONVERSATION ON 02-02-2021

**David Peaden**: I applied for the Escambia County Children’s Trust. My commissioner, Bender, has already picked his two people. I certainly understand that this a tough decision, and I would appreciate your consideration for one of the five. Please review my application. It truly would be a privilege to serve the community on this all-important body. Thank you and please let me know if you have any questions. Good to see you today. I also sent in my application for the PEDC appointment. I have Benders support for that.

**Jeff Bergosh**: Thanks for the heads up.  I believe we each get a vote for five that’s my understanding and then the top five go forward

### CONVERSATION ON 02-09-2021

**David Peaden**: Hoskins got a promotion. Don’t know if he’s leaving the area. Kara will be the new person in charge. Should hit the press soon. Don’t say anything. 

**Jeff Bergosh**: I won’t. Thx for the heads up

### CONVERSATION ON 02-10-2021

**David Peaden**: https://ricksblog.biz/dpz-teams-emails/

**David Peaden**: Have you seen these? Even coaching the PNJ on how to frame an article! 

**Jeff Bergosh**: Yeah I’m not surprised but glad they got busted 

**Jeff Bergosh**: Not professional at all and something I suspected was happening all along

**David Peaden**: Stayed on the sidelines! This is from today’s online PNJ article.

**Jeff Bergosh**: 
Yeah I caught that too. Maybe he did but none of his employees did including Bill Pearson

**Jeff Bergosh**: *Email dump too

**David Peaden**: You will have plenty to post about the PNJ. Especially after the hit job editorial. And there is a. Email from Lisa Savage throwing her own employee under the bus. She writes that she hope Maddy gets it right! I’m sure that doesn’t make Maddy feel like a valued Gannett reporter! 

**Jeff Bergosh**: I saw that one

**Jeff Bergosh**: I like Maddison Arnold

**David Peaden**: Only wish that Outzen would have waited a little longer. Now they will clam up. 

**Jeff Bergosh**: I’m all over it

**Jeff Bergosh**: ...especially for Travis Peterson

**David Peaden**: Lol! What about navy feds non profits status. Isn’t that lobbying? 

**Jeff Bergosh**: Not sure

**Jeff Bergosh**: But it sure does seem unethical to me

### CONVERSATION ON 02-11-2021

**David Peaden**: It doesn’t matter who is asking for public records. She said she didn’t know who Rick was so they didn’t make it a priority. 

**Jeff Bergosh**: Good point

**David Peaden**: DPZ presents hybrid OLF-8 design, but commissioners delay decision after ethics questioned

**David Peaden**: https://www.pnj.com/story/news/2021/02/11/olf-8-decision-delayed-county-questions-designers-ethics/6725429002/

**Jeff Bergosh**: Damn right I’m questioning their ethics.  They were working against our interests.  I’m going to seek restitution for this tainted product

**David Peaden**: From Scarface. Guy on the left looks like Peterson in his shirt 

**Jeff Bergosh**: LOL

### CONVERSATION ON 02-18-2021

**David Peaden**: Thank you for your vote for the trust. I appreciate it and I will chip in for the cost overruns for the library that Bender cares so much about!

### CONVERSATION ON 02-19-2021

**Jeff Bergosh**: Absolutely David!  It’s weird the way he brought that up

### CONVERSATION ON 02-20-2021

**David Peaden**: Another ghostwritten piece. No one cares what he thinks anyway.

**David Peaden**: https://www.pnj.com/story/opinion/2021/02/20/hold-escambia-county-commissioners-accountable-guestview/6787966002/

**David Peaden**: someone is obsessed with protecting DPZ, travis, etc. 3x mean income, 27k. Bluffs isn’t even close to online yet. The Main Street media strikes again. 

**David Peaden**: Citizens watch page

**Jeff Bergosh**: Yeah I saw this hatchet job this morning.  Ghost written by PNJ and their downtown “Patron”.  As for Peacock, his opinion is rubbish and he is irrelevant.

**Jeff Bergosh**: What he says about me means nothing.  He’s like one of the hundreds of love-bugs I smash when driving my big truck around the county in the summertime.  The I rinse off the remnants with a pressure wash job

**David Peaden**: Freaking hilarious!

**Jeff Bergosh**: He’s simply being used like a stringed marionette to put out someone else’s talking points.  It’s painfully obvious who it was.  He’s very malleable.  It’s Walden-esque. “.....most men lead lives of quiet desperation...”. That’s Peacock.  Desperately seeking relevance.  He isn’t relevant though

### CONVERSATION ON 03-05-2021

**David Peaden**: Who is in charge of drawing district lines? 

**Jeff Bergosh**: We are, the BCC, and School Board Members

**David Peaden**: You think the bcc with draw Jonathan’s house into D2? 

**Jeff Bergosh**: No— I think they are referring to Vicki Campbell.  She is on the D2 D1 border.  Her area will probably revert to D2

**David Peaden**: Jonathan and Vicki are not close. I think he’s talking about himself. 

**Jeff Bergosh**: That would be great, he will lose again.  Twice in 2 years.  Ouch

### CONVERSATION ON 03-13-2021

**Jeff Bergosh**: FWIW—take a look at the PNJ Facebook post of Andy Marlette’s hatchet job directed at me and Florida West/Scott Luth.  It backfired on them spectacularly and the commenters are beating the crap out of Andy and the PNJ.  It happened because like dummies, they mixed up the messages, talked crap about MATT Gaetz, put my picture up, and threw in the hashtag #freeBrittney.  Then, in their final act of stupidity, they locked the post for “subscribers only” so nobody could get the real context which was a hit on me.  A spectacular failure on their part which elicited a bashing to PNJ which they deserve.  A real, complete failure on their part here!👍😎

**David Peaden**: I saw that but figured you did it too so I didn’t send it. Funny how they are advocating for apartments on the maritime park too. He loses credibility when he does all of that and calls you an idiot. Can’t wait to see your response on your blog! 

**Jeff Bergosh**: Thanks.  And you know it’s coming

**Jeff Bergosh**: A preview:

**David Peaden**: Gold! 

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Congratulations on your appointment David

**David Peaden**: Thank you, sir. I will need your counsel from time to time. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-02-2021

**David Peaden**: Happy Birthday from “a son of a plumber” the American Dream Dusty Rhodes and the 17 time world heavyweight championship, the nature boy Ric Flair.  Whoooooo!

**Jeff Bergosh**: Thanks David!

**David Peaden**: I hope I have the right day and 2) you watched these guys back in the day! 

**Jeff Bergosh**: Yep.  The day is today.  I must admit I was never a huge fan of pro wrestling— but when I did watch I always liked Jake the Snake Roberts and Randy Macho Man Savage

**David Peaden**: Your birthday on Good Friday. Facebook Citizens watch heads would explode if they knew. How can the devil have a birthday on Good Friday!!!!

**Jeff Bergosh**: LOL

**Jeff Bergosh**: They’d go apoplectic if they knew!

### CONVERSATION ON 04-20-2021

**David Peaden**: Jim little is contacting me. Have you talked to him? Have you explained that this is for OLF8 or a Tax Increment Financing? And if anything of concurrency? My understanding is that the school board wants more infrastructure spending from the county when a school is built. Any thoughts would be appreciated. 

**Jeff Bergosh**: Sure.  I’ll call you

### CONVERSATION ON 05-01-2021

**David Peaden**: Is the end of the world today? Did I wake up in a different time? The PNJ Editorial praised the evil Jeff Bergosh? Sally needs to hide the kids, something weird is going on!

**Jeff Bergosh**: I know I saw it to David I couldn’t believe it I think they’re on drugs

**Jeff Bergosh**: LOL

### CONVERSATION ON 05-21-2021

**David Peaden**: Hey, I would like to catch up with you. IPC lunch. I’m available June 2, 14, 17, or 18. Thanks.

**Jeff Bergosh**: Sure thing- sounds great. I’m in the field rn but I’ll check calendar when I get to the office

### CONVERSATION ON 05-24-2021

**Jeff Bergosh**: How about the 18th at 11:30?

**David Peaden**: Yes sir! Book it. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-16-2021

**Jeff Bergosh**: Good Morning David—- I have had an issue arise at work that will prevent me from making our lunch we had set for this Friday.  My apologies for the short notice.  Can we reschedule it for the same time, 11:30 at IPC on the following Friday, June 25th?  Just let me know.  Hope your week is going well!

**David Peaden**: No problem. Can’t next Friday. June 28,29,30, July 1,2 are open.

**Jeff Bergosh**: How about July 1st at 11:30?

**David Peaden**: That will work. 
Have fun tomorrow! 

By the way, the last time the clerk made an opinion on her own, it costs the city $500k in legal fees to lose on the lease for the fish house Seville harbor. It was her opinion that Fish House had a “sweetheart deal”. Now she inserts herself into the retirement issue.

**Jeff Bergosh**: I agree.  I think she’s attempting to exert control over something that she has no sway on.  She hasn’t said it was illegal and she’s not a contract attorney so why is she attempting to overturn a contract the board enacted?

**Jeff Bergosh**: It will be an interesting day if nothing else

### CONVERSATION ON 06-19-2021

**David Peaden**: Pure Gold! 
“Why make me pry it out of the clerk’s attorney like a pearl diver opening a clam?” “…problematic… what the hell does that mean!”

**Jeff Bergosh**: Thx

**Jeff Bergosh**: But of course nobody will call her on that

**David Peaden**: Who is she listening to? Her husband legal advice?

**Jeff Bergosh**: ........except me

**Jeff Bergosh**: It’s not good advice to take

**David Peaden**: Well, you handled that issue and the others, I’m sure, appreciated it. And Steve handled the awkwardness of the administrator and the others didn’t say anything (except you). So between the two of you, I’m sure you gained a lot of good will from the other (useful) board members. 

**Jeff Bergosh**: Thanks.  It was sloppy and unnecessary for that item to be put on the agenda like that by the clerk.  Somebody had to say it, so I did 😎

### CONVERSATION ON 06-28-2021

**David Peaden**: We have lunch at 11:30 am on Wed. The ST Engineering Project Titan Groundbreaking Ceremony is at 10:30 am. Are you going to that? Want to move lunch back to noon?

**Jeff Bergosh**: Yes, you read my mind.  I’ll be there and speaking on behalf of the county.  Lets go ahead and do that and say 1200 for lunch at Mcguires.  Thanks David!  

**David Peaden**: 10-4

**Jeff Bergosh**: Thursday at 1200– the first of July right?

**David Peaden**: Yes. I made a reservation. 

### CONVERSATION ON 07-01-2021

**Jeff Bergosh**: On way there now

**David Peaden**: Ok. Me too. 

### CONVERSATION ON 07-02-2021

**Jeff Bergosh**: David it was great catching up yesterday. I have a PowerPoint I’d like to send you Discussing concurrency versus mobility fees.what is the best email to use?

**David Peaden**: dpeaden@hbawf.com

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-03-2021

**David Peaden**: Have you been invited to this? 

**Jeff Bergosh**: Yes

**David Peaden**: Good

### CONVERSATION ON 08-25-2021

**David Peaden**: Are you paying attention on the marlette scuffle with the Gov press secretary? 

**Jeff Bergosh**: Yes!  It’s awesome!  I’m going to do a blog post on it 

**Jeff Bergosh**: Glad folks are noticing that racist piece of crap

**David Peaden**: The same cartoon you have been posting now has made it worldwide! 

**Jeff Bergosh**: Good

**Jeff Bergosh**: I knew it was just a matter of time it’s got to get to the right person

**David Peaden**: Do you have a Twitter account?

**Jeff Bergosh**: Yeah but I don’t really use it much

**Jeff Bergosh**: I’ve already re-tweeted it though

**David Peaden**: I use Twitter just to read stuff. I don’t post. But what he did with the me too movement totally crossed the line. But someone in the governor’s office ask Michelle Salzman to call him today. And she did. That was a dumb move. No one has enough influence to get him to stop.  Except the Main Street man.

**Jeff Bergosh**: Yep

**Jeff Bergosh**: That guy calls all the shots

### CONVERSATION ON 09-02-2021

**David Peaden**: Way to go!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: It was time

**David Peaden**: Absolutely!

### CONVERSATION ON 09-03-2021

**David Peaden**: Well said. You are a 100,000 watt blow torch! 

**Jeff Bergosh**: Thanks I was trying to be very subdued and reserved

**Jeff Bergosh**: 😂

**David Peaden**: I’m glad you guys are on the offensive. Crazy watch is in total defcon meltdown!

**Jeff Bergosh**: They can spin around in their own echo chamber of hate. I’m spending the weekend at my beach condo and I’m going to have a coconut cocktail with an umbrella in it like Thurston Howell from Gilligans island. Those losers will spend their entire weekend at the keyboard angry sweaty and out of sorts

**David Peaden**: That hilarious! Lol!!!! 

**Jeff Bergosh**: Going full Thurston Howell mode this weekend!

### CONVERSATION ON 11-17-2021

**David Peaden**: Your latest blog post just cracks me up! 

**Jeff Bergosh**: About Doug or the Doctor?

**David Peaden**: Doug! The whole exploding drag racing theme! 

**Jeff Bergosh**: LOL thanks.  His life is one big explosion of crap

**David Peaden**: As for the Covid email. The doctor is right. Look up Mountain Bike Champion Kyle Warner who was diagnosed with Pericarditis after taking Pfizer vax. 

Or look up 52 year old Cardiologist Dr. Sohrab Lutchmedial who got his 3rd shot and died. He had a tweet saying he wouldn’t cry at the funeral of people who didn’t get the shot. 

It happens a lot and it’s not being reported.

**Jeff Bergosh**: Thanks I will look at that.  She is smart, I had a great conversation with her.  She’s going to be on my coffee with the commissioner next month.  It’s going to be epic

**David Peaden**: You should look at the website: Gateway Pundit. That’s where I got those two  from. 

**Jeff Bergosh**: I’ll check it out

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: Wow that’s awesome!  Great work and thanks for what you do to serve our community!

**David Peaden**: It’s on now

