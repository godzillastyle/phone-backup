

## CONVERSATIONS WITH MIKE GODWIN

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Mike-- arbitration and the name "bay center". What else is wrong with the contract

**Jeff Bergosh**: Not at all Mike I appreciate the heads up we ended up approving it but we asked Allison to go back and get some changes from the the conference

**Jeff Bergosh**: Thank you Mike I greatly appreciate your help!

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: Hey Mike hope all is going well. I just wanted to let you know we are having our coffee event tomorrow morning at 6:30 AM at the McDonald's on blue Angel and Highway 98. I hope you can come out and join us!

Jeff Bergosh

### CONVERSATION ON 11-18-2020

**Jeff Bergosh**: Hi Mike!  Thank you so much for the kind words, and yes we will have lunch soon.  Looking forward to it!

