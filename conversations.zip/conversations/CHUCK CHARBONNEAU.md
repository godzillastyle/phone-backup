

## CONVERSATIONS WITH CHUCK CHARBONNEAU

### CONVERSATION ON 02-12-2020

**Chuck Charbonneau**: How is it going?  When are your signs going up to win District 1??

**Jeff Bergosh**: Hello Charles--I just got them today so they will be going up soon!! How are things going with you?

**Chuck Charbonneau**: Things are going well!  Go Bergosh District 1!  Beat Underhill's lap dog!

**Chuck Charbonneau**: Hope you guys help with the sewer in Innerarity Island I have friends and patients that live out there.  Lots of concerned folks.

### CONVERSATION ON 02-13-2020

**Jeff Bergosh**: I intend to beat him like a drum.  And yes, I know about Innerarity and I'm speaking with several of those guys now trying to come up with a better plan for them

**Chuck Charbonneau**: Sweet!  Looking forward to seeing your victory!

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-22-2020

**Chuck Charbonneau**: Is District one all of the 32506 zip code or does it include any other zips?

**Chuck Charbonneau**: These are all rental properties, but feel free to put your signs.  7009/7011 Lillian hwy and 4910 Lillian hwy are both on a medium high visibility street.   117 Elm St is in a neighborhood.   I will have to look to see if I have any other houses in District one

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Charles that is awesome!!!!!! Thank you very much!!

### CONVERSATION ON 03-03-2020

**Chuck Charbonneau**: Bergosh 2020 baby!

**Jeff Bergosh**: Yes Sir!!!  Thanks for the great location!!

### CONVERSATION ON 03-19-2020

**Chuck Charbonneau**: I was just reviewing,  I own 4901 W Jackson and 10761 Jolyne if you wanted to put up signs there.

**Jeff Bergosh**: Thank you Charles I will!! 

### CONVERSATION ON 04-11-2020

**Chuck Charbonneau**: I called all the hospitals yesterday and was told their census is low and they don't need any help. 

**Jeff Bergosh**: That's great news!

### CONVERSATION ON 04-23-2020

**Chuck Charbonneau**: This is the health care crisis of our lifetimes,  doctors and nurses are getting laid off, hospitals won't be able to survive much longer.  We are on the edge of total destruction of our society,  our country,  for a virus that almost everyone survives.

**Jeff Bergosh**: Things are going to open up

**Jeff Bergosh**: I'm convinced of it

### CONVERSATION ON 08-18-2020

**Chuck Charbonneau**: Congratulations on your victory!  

**Jeff Bergosh**: Thank you Chuck for all your help!

**Chuck Charbonneau**: No problem!  

**Jeff Bergosh**: !!

### CONVERSATION ON 10-04-2021

**Jeff Bergosh**: Okay thanks Chris we will re send it.  Much appreciated!

