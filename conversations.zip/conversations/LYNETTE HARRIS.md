

## CONVERSATIONS WITH LYNETTE HARRIS

### CONVERSATION ON 05-25-2021

**Jeff Bergosh**: Hi Lynette,

Are we having our 1300 today?  I know Conor won’t be on it and I don’t have anything to pass— so we could postpone or cancel if you all would like-just let me know.  Otherwise I’ll be on the call at 1300 today.   Thanks!

Jeff Bergosh

