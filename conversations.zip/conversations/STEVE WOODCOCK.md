

## CONVERSATIONS WITH STEVE WOODCOCK

### CONVERSATION ON 04-25-2020

**Steve Woodcock**: Do you have and coke or Pepsi we can borrow?  Just 6 oz

### CONVERSATION ON 04-26-2020

**Jeff Bergosh**: Steve--of course.  Sorry I didn't see this last night

**Jeff Bergosh**: I have caffein free Diet Coke 

**Steve Woodcock**: Oh thanks Jeff.  We have that too, but we were looking for real sugar :).  We made it work last night.  Thanks and we hope you guys have a good day

**Jeff Bergosh**: Right on!  Have a great Sunday

### CONVERSATION ON 09-14-2020

**Steve Woodcock**: Hey Jeff...gm.  Your left rear taillight is out.  Brake light worked fine though.  

**Jeff Bergosh**: Thanks for the heads up Steve I'll get it fixed!

**Steve Woodcock**: 👍

### CONVERSATION ON 09-19-2020

**Steve Woodcock**: Jeff do you need help cutting that tree down?

**Jeff Bergosh**: The large one I'm paying a guy to do, the two small ones I'm going to do.  I'd love to borrow your electric chainsaw for the two small ones though if that'd be alright

**Steve Woodcock**: Ok sure.  We still have quite a bit to do, but I'm happy to let you borrow it.  We may need to sharpen the chain.  I'm not sure how to do that but I think David and Mike both do

**Jeff Bergosh**: Thx Steve!!

### CONVERSATION ON 09-21-2020

**Jeff Bergosh**: Never mind-  they delivered it late today after I got home.  Looks like we all got our mail today👍

**Steve Woodcock**: Hey Jeff.  Yea Ashley just got it

### CONVERSATION ON 09-24-2020

**Steve Woodcock**: Jeff I out your gas can outside the garage.  I will fill it up for you when you're ready

**Steve Woodcock**: Thanks for letting us borrow it

**Jeff Bergosh**: No problem Steve!

### CONVERSATION ON 01-02-2021

**Steve Woodcock**: Hi Jeff I hope you're having a good vacation.  Just wanted to let you know your garage light is on.  It was on last night too but I forgot to tell you today

**Jeff Bergosh**: Okay thanks-- I'll tell the contractor to cut it off.  Happy new year!

**Steve Woodcock**: You too!!!

### CONVERSATION ON 04-08-2021

**Steve Woodcock**: I'm going to order sod from up the street.  It's 200 a pallet and it's a one time 85 delivery fee if you're interested in filling in any spots and want to join in on the fun :)

**Jeff Bergosh**: Thanks Steve I'll take a look when I get home today

**Steve Woodcock**:  Ok.  Basically you just get any leaves out if the way and drop the squares right over any bares spots.  It takes about an hour per pallet I think and a pallet covers 400 sqft

### CONVERSATION ON 05-18-2021

**Steve Woodcock**: Are you renting your condo yet?  If so we may be interested for a couple of nights

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: Hi Steve!  Yes we are!  It's booked through the first week in August-- but after that it's open.  You can see the listing on VRBO or AirBNB here, below.

**Jeff Bergosh**: http://Airbnb.com/rooms/49674927

**Steve Woodcock**: That's amazing.  How did you get it booked so fast

**Jeff Bergosh**: In the purchase agreement with the seller it was stipulated that I'd pick up his bookings and that he'd facilitate that which he has been doing.

### CONVERSATION ON 08-28-2021

**Steve Woodcock**: You have a package that looks like it may get wet.  Want me to hold it?

**Jeff Bergosh**: If you don't mind that would be awesome thanks Steve!!

**Steve Woodcock**: Sure.  I out it in our garage

**Jeff Bergosh**: Thx Steve!

**Jeff Bergosh**: Steve do you by chance have an appliance Dolly I could borrow?

**Steve Woodcock**: Not a fridge one, but a regular one

**Steve Woodcock**: It doesn't have a strap on it

**Steve Woodcock**: David has one with a strap

**Jeff Bergosh**: Do you think the one you have would move a clothes dryer?

**Steve Woodcock**: Yes with 2 people

**Jeff Bergosh**: Steve can I borrow that from you would that be OK?

**Steve Woodcock**: Sure

**Steve Woodcock**: When do you need it?  We're going to have a picnic at the American legion downtown

**Jeff Bergosh**: Awesome.  Can I grab it when I get my package?  On way there now

**Jeff Bergosh**: Will be there at 11:10

**Steve Woodcock**: Ok sure.  

**Steve Woodcock**: We will be here another 2 hours

### CONVERSATION ON 10-28-2021

**Steve Woodcock**: Hey Jeff... Do you know if they are going to fix the drainage for this sidewalk going west on 9mile before you get to the pond?  This was taken the other day where it hadn't rained for a couple of weeks.  It never stops draining over the sidewalk.  
https://photos.app.goo.gl/1rpwHwYBsXQYYogP7

**Jeff Bergosh**: I'll check on that. I've noticed that same issue even on sunny warm days. And then when you ride over it on your bike it puts brown muddy muddy stains all over the back your shorts it looks at that point like a person has had a problem LOL

**Steve Woodcock**: Haha.  Yea it's a little embarrassing in publix.  Thanks Jeff.  It's nitpicky but hopefully the road contractors will fix it before they hand it over to the county

### CONVERSATION ON 11-01-2021

**Jeff Bergosh**: Awesome

### CONVERSATION ON 12-11-2021

**Steve Woodcock**: Sally said you are going to judge the car show.  We were checking on when you're going to start so we can go see

### CONVERSATION ON 12-12-2021

**Jeff Bergosh**: I would have but I thought he’d be working

