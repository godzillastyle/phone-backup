

## CONVERSATIONS WITH MADISON ARNOLD

### CONVERSATION ON 04-23-2020

**Jeff Bergosh**: Good question—I’m not sure.  I would imagine each individual food truck would do their own advertising on social media which would allow folks to know who was going to be there

**Jeff Bergosh**: It’s either going to be 10-6 or 10-7 I believe.  Suggest you call Michael Rhodes the parks and recreation director 850-554-2797

**Jeff Bergosh**: He will have all specifics

**Jeff Bergosh**: No problem—have a great one!

