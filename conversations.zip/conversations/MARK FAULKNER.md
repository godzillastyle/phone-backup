

## CONVERSATIONS WITH MARK FAULKNER

### CONVERSATION ON 04-22-2020

**Mark Faulkner**: Good morning again Commissioner Bergosh. Thanks again for the great dialogue we shared this morning. I wanted to alert you to a couple of emails in your inbox regarding your request for an ethics professor. Mark Faulkner.

**Jeff Bergosh**: Thank you so much Mark—great discussion and I really appreciate your willingness to come on so early.  I will check my email—thanks again!!

### CONVERSATION ON 07-01-2020

**Mark Faulkner**: Thanks again for the invitation. I hope it was helpful. Nice to have constructive and thoughtful dialogue on this important topic. Call me if you need anything.

**Jeff Bergosh**: Thank you so much Mark!  It really helps me in decision making to hear from you all—can’t thank you enough!

### CONVERSATION ON 08-04-2020

**Mark Faulkner**:  If you have a moment, can we talk briefly about masking?

**Jeff Bergosh**: Absolutely— when is a good time for you Mark?

**Mark Faulkner**: Any time before 2

### CONVERSATION ON 08-18-2020

**Mark Faulkner**: Congratulations on your successful campaign!

**Jeff Bergosh**: Thank you Mark!!!!

### CONVERSATION ON 09-17-2020

**Mark Faulkner**: Good morning. Letting you know that structurally, Baptist fared well in the storm. We are pretty much fully operational at the hospitals. However, we have unoperable water pressure at the main campus. Any influence you can exert on ECUA to press on this as a very high priority would be very much appreciated.

**Jeff Bergosh**: Thank you for the update and we will work that issue.

### CONVERSATION ON 09-28-2020

**Jeff Bergosh**: Hi Mark I looked at the calendar and got the dates mixed up —-it’s not this Wednesday it’s the following Wednesday, October 7 the first Wednesday of the month.  I hope that you can make that date and I apologize for the mixup. I will shoot you an invitation and again it’s actually one week from this Wednesday, October 7. Thank you!

**Mark Faulkner**: No problem! Yes, I can make it on the 7th. Looking forward to it.

**Jeff Bergosh**: 👍.  Right on thanks very much!

### CONVERSATION ON 01-05-2021

**Mark Faulkner**: Got time for a call today?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: I’m traveling but I’ll call you during my layover in Houston this afternoon if that works

**Mark Faulkner**: That would be great. I’ve got some gaps between noon and 1, 3 - 3:30, or after 4

**Jeff Bergosh**: Okay 

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: Mark:  I don’t know if you were able to catch our meeting on vaccinations and the payment to the hospitals for uninsured residents— but we had that discussion this morning.  I’ve asked the county attorney to modify the currently-proposed contract to Sacred Heart that we will approve tonight to indicate that the 3.5 million is the total pool of dollars available and that it is not exclusively for sacred heart Hospital but for any county approved, licensed-provider to draw down on.  This will not slow down sacred heart or community Health but also  makes it very clear that we are not giving an exclusive,  sole-source contract to one hospital over the other two......So after we approve it if either Baptist or west Florida wants to participate —-you all will be able to do so under the same terms and conditions and at the same terms, conditions, and reimbursement rate.

**Mark Faulkner**: Thank you so much. We are certainly an active participant already in the vaccine distribution to the public. Support as you suggest in this text would be very much appreciated and valued. We are in frequent communication with county department of health and the state to acquire additional vaccine as we extend our efforts deeper into the community.

**Jeff Bergosh**: Thanks Mark!!

**Mark Faulkner**: No, thank you!

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-08-2021

**Mark Faulkner**: Thanks again for your leadership. I just want to confirm any misinformation. Baptist is absolutely willing to provide vaccines. We’ve already provided almost 2000 to the public.  I know you validated that already with me and with Kendrick but I just wanted to confirm. There seemed to be some misinformation that I just wanted to clarify.

**Mark Faulkner**: And I also shared that with Dawn. I think she wants the same clarification.

**Jeff Bergosh**: Fantastic.  The more the better and to the extent we are able we are willing to provide reimbursement through cares act funds.  Curiously, though, Sacred Heart backed out last night of the modified, non-exclusive agreement at the eleventh hour last night.....

**Jeff Bergosh**: Without a cogent explanation as to why

**Mark Faulkner**: I’m not sure. We are actually thinking we may never bill the county a cent regarding vaccines. Such is true with testing as well.

**Jeff Bergosh**: That would be great.  We were made aware last night that Sacred Heart was wanting to charge the county $100 per test for uninsured residents.  This seemed high to the board, and for many reasons associated with that We didn’t approve their CARES act testing contract.  We want to know what their cost is for that———especially since we only pay Community Health $37 for testing the non-insured.   Seems fishy to me

### CONVERSATION ON 01-20-2021

**Mark Faulkner**: Good morning. Logging on shortly. You typically ask if there are any questions to avoid. My only suggestion this round would be to avoid directly asking the participants if they’ve had the vaccine yet. While I believe all participants are willing to become vaccinated, it might create confusion or inconsistencies if the answers differ. Just a suggestion.

**Jeff Bergosh**: Great point and I will not ask that.  Thank you Mark!

### CONVERSATION ON 03-24-2021

**Mark Faulkner**: Good morning.  Do you have a couple minutes to talk today?

**Jeff Bergosh**: Sure Mark

**Mark Faulkner**: Would you mind just calling my cell when you are available? I’m clear until 10 AM. Thank you!

### CONVERSATION ON 07-14-2021

**Mark Faulkner**: I jinxed us.  We increased from eight Covid positive inpatients to 13 in the last 24 hours. Again, no cause for alarm. Just keeping you informed.

**Jeff Bergosh**: Thanks for the heads up.  I appreciate it Mark.  Hopefully this is just a one off anomaly

**Mark Faulkner**: Agree. Perhaps just a July 4 spike that will subside on its own.

**Jeff Bergosh**: I hope it is

### CONVERSATION ON 12-02-2021

**Mark Faulkner**: My wife and I really enjoyed Tuesday nights event. Please convey our regards to Sally. It was great to see you. PS, nice job on the audiovisuals!

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: Thank you very much Mark, for coming out and supporting that event!  I appreciate the kind words— and I hope you all have a great weekend!

**Jeff Bergosh**: Thanks again to both of you for attending and for your support!

### CONVERSATION ON 12-14-2021

**Jeff Bergosh**: Yeah it’s a bunch of BS!

**Mark Faulkner**: I can confirm that we had one physician prescribing ivermectin back in the timeframe you described. His physician extender also did so. Since then that has ceased from happening in accordance to our formulary as adopted by our medical staff..  During the late summer/fall wave, the recommendations from medical societies came out against its use unless part of a clinical trial, which we do not do.

