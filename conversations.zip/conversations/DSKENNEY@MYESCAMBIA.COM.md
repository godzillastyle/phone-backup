

## CONVERSATIONS WITH DSKENNEY@MYESCAMBIA.COM

### CONVERSATION ON 11-01-2019

**dskenney@myescambia.com**: Here is a copy of the text I just sent Tim. He did not answer his phone

**Jeff Bergosh**: Thx

### CONVERSATION ON 03-27-2020

**dskenney@myescambia.com**: I am at a doctor appointment and will set up the zoom account and get everything finalized as soon as I get home this morning

**Jeff Bergosh**: K

### CONVERSATION ON 04-08-2020

**dskenney@myescambia.com**: Are you on yet

**dskenney@myescambia.com**: Don’t see you

**dskenney@myescambia.com**: It’s ok

**dskenney@myescambia.com**: Please place your coffee cup down softly it’s being picked up on the Mic  david. asked me to tell you that

**dskenney@myescambia.com**: You might want to re-introduce your guests for people who are coming in later

### CONVERSATION ON 04-15-2020

**dskenney@myescambia.com**: Your screen is not as big as it should be because you’ve got information on the right hand side so it’s not giving you a full screen

**dskenney@myescambia.com**: Looks good now 

### CONVERSATION ON 04-22-2020

**dskenney@myescambia.com**: Close the right part of your screen

**dskenney@myescambia.com**: Are you live 

**dskenney@myescambia.com**: Close the right side of your screen

**dskenney@myescambia.com**: Your volume is low

### CONVERSATION ON 04-28-2020

**dskenney@myescambia.com**: Jeff please call this guy he is the youth minister at Saint Luke Methodist. He’s the one that you need to record with for the national day of prayer

**Jeff Bergosh**: Okay I will

### CONVERSATION ON 04-29-2020

**dskenney@myescambia.com**: Are you live?

**dskenney@myescambia.com**: Everything’s ok

**dskenney@myescambia.com**: Sam is trying to get in

**dskenney@myescambia.com**: You are hard to hear. 

**dskenney@myescambia.com**: Your sound is deteriorating 

**dskenney@myescambia.com**: Wrap it up

### CONVERSATION ON 06-09-2020

**dskenney@myescambia.com**: I left my phone at work and Sharon has it so if you need me before tomorrow just call me on my county phone which is 377-3097

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: Debbie— I can’t log in to civic clerk can u please have them send someone up from IT?  Thanks

### CONVERSATION ON 11-10-2021

**dskenney@myescambia.com**: RE: [EXTERNAL]:
Phil,
Tim and Debbie,
That is Danielle's case and she was out last week for training.  She had asked me about the owner allowing the front to become naturally vegetative and he cannot.  She noticed the owner for overgrowth with summary abatement so she can move forward and send it to be county abated this week.  I am not sure how backlogged abatements are currently.

Don't hesitate to call if questions.

Sgt. Angelique Parker #668
Central District - Environmental Enforcement - Natural Resource Management - Escambia County
(850) 554-2758    ahparker@myescambia.com
M-Th 7:00 am - 5:30 pm






-----Original Message-----
From: 8502931459@mms.att.net <8502931459@mms.att.net>
Sent: Tuesday, November 9, 2021 1:47 AM
To: 8502915776@mms.att.net; District1 <District1@co.escambia.fl.us>
Subject: [EXTERNAL]

WARNING! This email originated from an outside network. DO NOT CLICK links or attachments unless you recognize the sender and know the content is safe.

Florida has a very broad public records law. Under Florida law, both the content of emails, email addresses and IP addresses are public records. If you do not want the content of your email, your email address, or your IP address released in response to a public records request, do not send electronic mail to this entity. Instead, contact this office by phone or in person.

