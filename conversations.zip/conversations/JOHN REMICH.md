

## CONVERSATIONS WITH JOHN REMICH

### CONVERSATION ON 01-30-2020

**Jeff Bergosh**: John—-good morning this is Jeff Bergosh across the street. We’re putting all hands on deck for this estimate for building 633. When you have a moment can you please call me because I have a concern about the level of detail we need to put into this estimate. There’s very little time and I want to discuss this with you thank you.

**Jeff Bergosh**: Yes—got it thanks John

### CONVERSATION ON 01-31-2020

**Jeff Bergosh**: Sending it over right now John.  $900K

Hope you have a great weekend.

Jeff Bergosh 

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-06-2020

**Jeff Bergosh**: Okay- appreciate that John.  John Campbell must have got through to him after I left.  Thank you.

### CONVERSATION ON 09-14-2020

**Jeff Bergosh**: Okay sounds good

**Jeff Bergosh**: I’ll be in it

### CONVERSATION ON 09-15-2020

**Jeff Bergosh**: Nope, not to my knowledge

