

## CONVERSATIONS WITH JUDGE TOM DANHEUSSER

### CONVERSATION ON 11-04-2019

**Judge Tom Danheusser**: Among other things ie carcinogens ...I think this statement is a lie;

Keep in mind that in recent months, commissioners voted unanimously to use the county’s bonding capacity to help the private, billion-dollar corporation refinance up to $10 million in debt. The vote did absolutely nothing to help average Escambia taxpayers. The only result was to provide financial benefit to a private, multi-billion dollar, non-local company.

**Judge Tom Danheusser**: Don't think it impacts bonding capacity 

**Jeff Bergosh**: Thanks Tom.  Yes this guy lies a lot and he gets away with it because he is a "cartoonist"

**Judge Tom Danheusser**: A bad one

**Jeff Bergosh**: Yes that too 

### CONVERSATION ON 11-12-2019

**Judge Tom Danheusser**: 😂


 I know Andy hates it....  I know Andy hates it....

### CONVERSATION ON 11-13-2019

**Jeff Bergosh**: You like that touch?  Thx.😎

**Judge Tom Danheusser**: Should be your meme after every article:)

**Jeff Bergosh**: Maybe it will be👍....great suggestion!

**Judge Tom Danheusser**: Escalate his BDS, bergosh derangement syndrome 

**Jeff Bergosh**: 😁

### CONVERSATION ON 11-15-2019

**Judge Tom Danheusser**: What a fool...if victim had been Obama? John lewis? Pelosi?¿¿https://www.pnj.com/story/opinion/2019/11/15/marlette-gaetz-call-jail-drink-thrower-neither-conservative-nor-christian/4200887002/¿

**Judge Tom Danheusser**: It was an act of civil rights violence because of a public officials views

**Jeff Bergosh**: Exactly.  Andy would have a different answer if Bernie got "milkshaked"

**Judge Tom Danheusser**: Death penalty 

**Jeff Bergosh**: Right!

**Judge Tom Danheusser**: And sure...hes a "real" Christian.   
Not to mention such reckless acts could get someone killed because security has no idea what's being thrown...ask London 

### CONVERSATION ON 11-22-2019

**Judge Tom Danheusser**: Yeh marlette... "sincere" remorse 

### CONVERSATION ON 11-25-2019

**Judge Tom Danheusser**: What triggered sunshine explanation 

**Jeff Bergosh**: Freaks on Escambia Citizens Watch

**Judge Tom Danheusser**: All 19 of them?

**Jeff Bergosh**: LOL 4 of the 19

**Judge Tom Danheusser**: :)

**Judge Tom Danheusser**: If a tree falls in the forest...

### CONVERSATION ON 12-12-2019

**Judge Tom Danheusser**: Why would city pay 1$? Certainly they performed daily backups

**Jeff Bergosh**: Insurance will probably cover it

**Judge Tom Danheusser**: If they have backups... there's no need to pay anyone anything 

### CONVERSATION ON 03-20-2020

**Judge Tom Danheusser**: Says Jeff Burns...2 cases? News to me...

**Jeff Bergosh**: Me too

### CONVERSATION ON 03-22-2020

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/test-results-starting-to-trickle-in-at.html?m=1

**Judge Tom Danheusser**: Any covic patient on a respirator here yet?

**Jeff Bergosh**: Unknown

**Judge Tom Danheusser**: Seems as of your meeting input there werent any ..hope that maintains 

### CONVERSATION ON 03-26-2020

**Judge Tom Danheusser**: I agree, you absolutely need to know ventilator data, its the bottom line info to measure severity

**Judge Tom Danheusser**: If they resist,  that tells you alot

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: They won a lot from us they should be very forthcoming with that information in real time

**Judge Tom Danheusser**: And doesn't the county give them $?

### CONVERSATION ON 03-29-2020

**Judge Tom Danheusser**: ....but how many of those 39 are due to corona?

### CONVERSATION ON 03-31-2020

**Judge Tom Danheusser**: Wow, US has 5 times per capita the number of respirators that great Britain does,  ain't socialized med great??

### CONVERSATION ON 04-02-2020

**Judge Tom Danheusser**: Best covid precautions explanation 


https://youtu.be/IBC3G0e3YVQ

### CONVERSATION ON 04-19-2020

**Judge Tom Danheusser**: You're prescribed steps for beach opening are doable.¿¿Health bureaucrats who say no should be asked...well then when?¿¿ Not reasonable to keep beach closed until no new cases, which may never happen 

**Jeff Bergosh**: I know -- tough call 

**Judge Tom Danheusser**: Not with your steps...logical and reasonable 

**Jeff Bergosh**: Thanks Tom I think they're reasonable too.  But we'll see....

### CONVERSATION ON 04-22-2020

**Judge Tom Danheusser**: Just curious.  What is the goal?? I thought it was clearly stated as making sure critical medical facilities weren't overrun...

**Jeff Bergosh**: That's the question I asked--Didn't really get a good answer it was real mushy and squishy from the president of Baptist Hospital-- who I like.  It's almost like a loaded question these days a litmus test left or right

**Jeff Bergosh**: Super right wingers liberty and everything open and a constitutional rights restored

**Judge Tom Danheusser**: Don't know how yall answer the question,  if you don't know what the question is..

**Judge Tom Danheusser**: Open beaches when no one gets covid?? 50 years from now?

**Jeff Bergosh**: Strange as it is I think Some would be fine with that

**Jeff Bergosh**: Not me though

**Judge Tom Danheusser**: My parents will never be safe until herd immunity,  which we are artificially inhibiting 

**Jeff Bergosh**: Yes we are--very few discussing that

**Judge Tom Danheusser**: Which gets back to,  if beaches aren't opened now, what is specific measure to open?

### CONVERSATION ON 04-23-2020

**Judge Tom Danheusser**: All to the beach!   :)¿¿Coronavirus Dies Fastest Under Light, Warm and Humid Conditions¿https://www.bloomberg.com/amp/news/articles/2020-04-23/coronavirus-dies-fastest-under-light-warm-and-humid-conditions#aoh=15876838428344&referrer=https%3A%2F%2Fwww.google.com&amp_tf=From%20%251%24s

**Jeff Bergosh**: That sure makes her decision that much easier on Tuesday

**Judge Tom Danheusser**: Her?

**Jeff Bergosh**: *our

**Jeff Bergosh**: The BCC's decision

**Judge Tom Danheusser**: Gotcha...

### CONVERSATION ON 06-18-2020

**Judge Tom Danheusser**: Spot on!

**Jeff Bergosh**: Thanks!

### CONVERSATION ON 06-20-2020

**Judge Tom Danheusser**: Hi Jeff

Do you know what % of recent covid "positives" in Escambia are asymptomatic?

Thx

Tom

**Jeff Bergosh**: No I don't but I'll ask the question.  It's a good question

**Judge Tom Danheusser**: Thx :) I've seen reports of significant asymptomatic in other areas

**Judge Tom Danheusser**: You would think that would be a standard component of the reports...

### CONVERSATION ON 06-22-2020

**Judge Tom Danheusser**: Good grief! I hope he's wrong!

### CONVERSATION ON 06-25-2020

**Judge Tom Danheusser**: Death rate unchanged or slightly lower 

### CONVERSATION ON 07-08-2020

**Judge Tom Danheusser**: Where can I get Escambia deaths by day for each day june and July?

**Jeff Bergosh**: Good question Tom -- I'll ask

**Judge Tom Danheusser**: Our health department data is pathetic 

**Judge Tom Danheusser**: Isn't he retiring sokn?

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Yes he is and yes it is

**Judge Tom Danheusser**: Can't even find out deaths!!

### CONVERSATION ON 07-20-2020

**Judge Tom Danheusser**: In my view the young people at bars probably generated the inevitable but necessary spread that will result in earlier herd immunity...Sweden did this on purpose,  NYC did it by accident,  both of their rates are down to very low

**Jeff Bergosh**: I don't disagree.  But I think it's interesting the "experts" tell us 18 year olds frolicking on the beach is a major health risk--- but 18 year olds on a crowded bus will be "perfectly fine".   Both scenarios are risky--not just the one they used to close the beaches.......

**Judge Tom Danheusser**: They say whatever is convenient that day :)

**Jeff Bergosh**: Yep

**Judge Tom Danheusser**: Mask bad...mask good...wipe on..wipe off 

**Jeff Bergosh**: LOL

**Jeff Bergosh**: The amazing thing to me is how they deliver some of this garbage with a straight face.  I'm convinced they are making this up as they go along........

**Judge Tom Danheusser**: Absolutely..breathtaking arrogance. 
Fauci "oh...i was just lieing to you before but now I'm telling you the gods honest truth...pinky swear

**Jeff Bergosh**: Exactly

**Judge Tom Danheusser**: Oh and remdisavir is wonderful (despite minimal evidence) and hydrox is voodoo, despite ford health center major study showing 50% death refuction 

**Judge Tom Danheusser**: Reduction 

**Jeff Bergosh**: Exactly- I asked Lanza about that and he dodged the question at our meeting

**Judge Tom Danheusser**: We're so fortunate he's retiring

**Jeff Bergosh**: Amen!

### CONVERSATION ON 08-18-2020

**Judge Tom Danheusser**: Congrats!

**Judge Tom Danheusser**: Have a nice drive tomorrow:)

**Jeff Bergosh**: Thank you Tom!!!

### CONVERSATION ON 08-27-2020

**Judge Tom Danheusser**: Seriously? Who's marketing firm would get this $?¿¿https://www.pnj.com/story/news/2020/08/27/pensacola-asks-cares-act-funds-mask-order-no-citations-issued/5646977002/¿

**Judge Tom Danheusser**: Enought to Fund 8 full time officers for masks?????

### CONVERSATION ON 08-28-2020

**Jeff Bergosh**: Crazy right?

### CONVERSATION ON 10-07-2020

**Judge Tom Danheusser**: My 2 cents...¿I'm all for privatizing government services.  Santa Rosa privatized EMS in the 80s. But I would submit that denying the lowest paid..and hard working..custodial workers basic benefits to the exclusion of all other higher paid employees is not sound or fair..¿¿Just my thoughts 

**Jeff Bergosh**: I don't disagree but benefits are expensive

**Judge Tom Danheusser**: And more expensive for fire,  ems, road depth, legal etc...

**Judge Tom Danheusser**: The custodial are easy pickins...no voice, no union

**Judge Tom Danheusser**: Highest minority %

**Judge Tom Danheusser**: But are the nicest, humble hard working folks i know 

**Judge Tom Danheusser**: Not but...and are ...

**Jeff Bergosh**: Agreed.  The county custodians are unionized though-- SEIU.  Just the contracted ones aren't 

**Judge Tom Danheusser**: Well.. their union is not serving them well :)

### CONVERSATION ON 10-26-2020

**Judge Tom Danheusser**: Did the school board vote on that letter??

**Jeff Bergosh**: Good question, I'm not sure.

**Judge Tom Danheusser**: Well...the letter says its from the "board"

### CONVERSATION ON 11-27-2020

**Judge Tom Danheusser**: Ask your bro.. 99% of all guns used in crimes we see in court were stolen. .you can go buy one within 30 minutes..any cop could take you to it..

**Jeff Bergosh**: I believe that

**Judge Tom Danheusser**: And the issue isn't international students...its radicalized students from one religion who were not even monitored...not even social media

**Judge Tom Danheusser**: It's like arguing that pornstach kills...

**Jeff Bergosh**: Yes.  But that would never be presented in that way due to political correctness' sake (and also for the sake of $Billions in arms sales to a particular nation-----including training

**Jeff Bergosh**: Pornstach=red herring

**Judge Tom Danheusser**: Yep...but the military's pc will kill people 

**Jeff Bergosh**: .....it's kind of along similar lines of why after 9-11 (16 of 19 terrorists from one nation we consider an ally and know as a huge "customer") we went after different nations 😁👌

**Jeff Bergosh**: ...... and business interests, and donor interests

### CONVERSATION ON 12-13-2020

**Judge Tom Danheusser**: Yep...pnj is a dieing blog...kept on life support by a handful of "johns"

**Judge Tom Danheusser**: Thing is...a real newspaper dedicated to journalism would do well

**Judge Tom Danheusser**: Amazing that they NEVER have a story reflecting this community's values.. never

### CONVERSATION ON 12-14-2020

**Jeff Bergosh**: A terrible organization.  If Rooms to Go ever decides to pull their advertising, PNJ would fold

### CONVERSATION ON 12-30-2020

**Judge Tom Danheusser**: ?? Why would the county pay 1$ for vaccines? 

Are hospitals saying they won't dispense without 4 mill?

### CONVERSATION ON 12-31-2020

**Jeff Bergosh**: They are estimating this cost as a "not to exceed" figure for paying for the uninsured residents to be vaccinated.  But my contention is this should not come from local funding.  If the hospitals "MUST" be paid for this-- why isn't the state or FEDS funding them directly?

**Jeff Bergosh**: I'll have lots of questions for staff on this topic on the 7th

**Judge Tom Danheusser**: I was pretty sure feds already paid for vaccines...

**Judge Tom Danheusser**: Hospital crony capitalism?

**Judge Tom Danheusser**: DOH already has online appointment process

### CONVERSATION ON 01-08-2021

**Judge Tom Danheusser**: Good idea..

**Jeff Bergosh**: Which one? I'm full of them LOL😁👌

**Judge Tom Danheusser**: Diversify vaccine providers...

**Jeff Bergosh**: Yep.  Sacred Heart wanted the whole enchilada.  

**Jeff Bergosh**: They didn't get it

**Judge Tom Danheusser**: Their process at olive Baptist is unreal...was 2 hour line..so my mother will wait...

**Jeff Bergosh**: Meanwhile they are publicly Pat and themselves on the back about how great they are

**Jeff Bergosh**: Wait am I allowed to say that?

**Judge Tom Danheusser**: Yes you are :)

**Jeff Bergosh**: 👍

**Judge Tom Danheusser**: And you're correct,  one provider can't physically handle 

### CONVERSATION ON 01-11-2021

**Judge Tom Danheusser**: Ahh, come on Commissioner...the ascension execs live paycheck to paycheck ...you must blindly pay them whatever they say...no questions asked  :)

**Jeff Bergosh**: Right.

### CONVERSATION ON 01-28-2021

**Judge Tom Danheusser**: Thanks for the tour yesterday.

**Jeff Bergosh**: Thanks for coming along!  It will be good to get this facility opened!

**Judge Tom Danheusser**: Absolutely!

### CONVERSATION ON 01-30-2021

**Judge Tom Danheusser**: Kids murdering kids every week and pnj has a cry fit over 22k legal bill..

**Jeff Bergosh**: Yes they miss the big picture, plus we are easier targets.  Another hatchet job.....

**Judge Tom Danheusser**: But nothing to chop..

**Judge Tom Danheusser**: Just bitter dying paper 

**Jeff Bergosh**: Yes

**Judge Tom Danheusser**: I only knew about it because friend sent it...pnj=tree falling in forest that no one hears

**Jeff Bergosh**: LOL that's right.  Readership in free fall

### CONVERSATION ON 02-04-2021

**Judge Tom Danheusser**: Yall about to compete with att cox verizon??

**Jeff Bergosh**: No

**Judge Tom Danheusser**: Hmmm

**Judge Tom Danheusser**: Who is "Magellan Advisors "?

**Jeff Bergosh**: Salesmen trying to sell us their service

**Jeff Bergosh**: On a sole source basis

**Judge Tom Danheusser**: Apparently succeeding:)

**Judge Tom Danheusser**: Seems a bit unusual...

### CONVERSATION ON 02-11-2021

**Judge Tom Danheusser**: Bravo

**Jeff Bergosh**: Thx!

**Jeff Bergosh**: This crap must stop

**Judge Tom Danheusser**: It's unbelievable 

**Jeff Bergosh**: Really a black eye for staff, DPZ, and NFCU

**Judge Tom Danheusser**: PNJ is a joke,  glad the curtain has been drawn back

**Jeff Bergosh**: Their corporate office is smashing my blog today, downloading files

**Judge Tom Danheusser**: Ha!! You should print that 

**Jeff Bergosh**: Maybe I will.  Got someone's attention I think!

**Judge Tom Danheusser**: :) "oh lisa , we need to get a drink"

**Jeff Bergosh**: Yeah that was great

**Judge Tom Danheusser**: Kissy kissy ...blechhh 

### CONVERSATION ON 02-18-2021

**Judge Tom Danheusser**: btw.. the court covid delays are self imposed by the courts...no one else's fault 

**Jeff Bergosh**: Good to know-- can't wait till this is all over and we get back to normal.  Meanwhile- ABC World News last night reported that as a nation we have had a record low rate of seasonal flu this year-- almost nonexistent at only 165 recoded hospitalizations for seasonal flu nationwide from October to January.  165.  Imagine that?

**Judge Tom Danheusser**: Exactly 

### CONVERSATION ON 02-19-2021

**Judge Tom Danheusser**: Fyi, sacred heart gives to less than 65 with medical conditions 

**Jeff Bergosh**: Thx for heads up

**Judge Tom Danheusser**: The lack of universal info dissemination is unfortunate

**Jeff Bergosh**: Yes it's bad.  I said that in a polite and diplomatic way yesterday to health department director Marie Mott 🙂

### CONVERSATION ON 02-26-2021

**Judge Tom Danheusser**: Shadow banned?  :)

### CONVERSATION ON 02-27-2021

**Jeff Bergosh**: No-- did you comment again? 

**Judge Tom Danheusser**: Nope...I was wrong:)

### CONVERSATION ON 03-03-2021

**Judge Tom Danheusser**: Now..that's a realistic photo!!

**Jeff Bergosh**: LOL

**Jeff Bergosh**: That's like the home alarm commercial by Adt that shows a white fashion model with a scruffy beard and a hoodie kicking down the door yeah right that's the guy who's going to do it

**Judge Tom Danheusser**: Yeh...these gangs of little girls with matching outfits brutalizing the schools

**Jeff Bergosh**: LOL

### CONVERSATION ON 03-04-2021

**Judge Tom Danheusser**: Does the county have a power cleaner?? :)

**Judge Tom Danheusser**: Kinda gross..

**Jeff Bergosh**: That's unsightly I'll see what we can do to fix it

**Judge Tom Danheusser**: Wouldn't covid have been a good time to replace parking lot?

**Judge Tom Danheusser**: I realize yall probably don't want to put a lot of $ in it..

### CONVERSATION ON 03-09-2021

**Judge Tom Danheusser**: It) is disconcerting, to say the least, that the only person who reviewed the withheld documents to determine whether they are public records was Underhill," Cannon wrote. "At the evidentiary hearing, Underhill’s lawyers admitted they did not review all the documents; rather, they reviewed only a sample. Likewise, the ECBCC's (Escambia County Board of County Commissioners') lawyers admitted they did not review the documents. The County’s in-house staff of attorneys also did not review the documents."

**Jeff Bergosh**: I know, a pretty devastating observation

**Judge Tom Danheusser**: Why was that task farmed out???

**Judge Tom Danheusser**: I did it all the time...guess she was scared to piss off a commissioner

**Jeff Bergosh**: Apparently Alison and Charlie felt "conflicted" and said they couldn't represent us Because they knew too many intimate details from Doug

**Jeff Bergosh**: They farm out anything that's controversial that way if they lose it can't be held against them they blame the contracted lawyer

**Judge Tom Danheusser**: Well...that's on them

**Jeff Bergosh**: I agree really disappointing and costing the taxpayers a lot of money

**Judge Tom Danheusser**: If only you had 4 or 5 attorneys already on the payroll:)

**Jeff Bergosh**: Oh wait – we do!

**Judge Tom Danheusser**: Yup

### CONVERSATION ON 03-12-2021

**Judge Tom Danheusser**: ???

https://www.starlink.com/

**Jeff Bergosh**: Never heard of it

**Judge Tom Danheusser**: Some Elon musk guy..

**Judge Tom Danheusser**: :) rural service 

**Jeff Bergosh**: Oh yeah-- satellite internet.  I have heard about it

**Judge Tom Danheusser**: :)

### CONVERSATION ON 05-01-2021

**Judge Tom Danheusser**: Uh ohhhh...pnj agrees with you, I'll have to reassess my support of you  :)

**Jeff Bergosh**: LOL I know right!

### CONVERSATION ON 05-14-2021

**Judge Tom Danheusser**: Maybe the antiscience courts will join you one day!

**Jeff Bergosh**: Hopefully!

**Jeff Bergosh**: Wow!  Is that what you're getting when u go to my blog??

**Jeff Bergosh**: That's odd-- it's hosted on Google!

**Judge Tom Danheusser**: Just on my android chrome.. they're on to you :)

**Jeff Bergosh**: LOL

### CONVERSATION ON 05-20-2021

**Judge Tom Danheusser**: Viewpoint: More fathers equal less prisons – Rick’s Blog
https://ricksblog.biz/viewpoint-more-fathers-equal-less-prisons/

**Jeff Bergosh**: Awesome, and right on point!  You should send it to the PNJ!

**Jeff Bergosh**: ......love the analogy to cigarettes and lung cancer

**Judge Tom Danheusser**: Sent to pnj...Nelson didn't bite...must be too much truth

**Jeff Bergosh**: They can't handle the truth

**Judge Tom Danheusser**: Fo sho

**Judge Tom Danheusser**: Promoting fatherhood damages their business model...

### CONVERSATION ON 05-22-2021

**Judge Tom Danheusser**: The "crooks and cowards " are the dishonest individuals like the pnj "board" that have no shame to make this an anti republican rant....and no mention of the real issue.  A single mother who knowingly let's an 11 year old girls go out on her own.....and then plasters her glamor shot on the front page for every predator to see


Girl's escape from kidnapper underscores dangers for kids | Editorial
https://www.pnj.com/story/opinion/2021/05/22/florida-girl-escape-kidnapping-dangers-kids-editorial-alyssa-bonal/5170605001/

### CONVERSATION ON 06-03-2021

**Jeff Bergosh**: Do u have time for a quick call?

**Judge Tom Danheusser**: In 20 min?

**Jeff Bergosh**: Perfect

**Jeff Bergosh**: Thx

### CONVERSATION ON 06-04-2021

**Judge Tom Danheusser**: What does 2+2=?

Well I don't know but it would bring scrutiny..

**Jeff Bergosh**: I asked

**Jeff Bergosh**: .......which I doubt she will do

**Judge Tom Danheusser**: But she already told the EC 2+2=5

**Jeff Bergosh**: Yes but it was more like she relayed a message from the ethics board that "they" said 3 + 3 = 7

**Jeff Bergosh**: It had arms distance comfort for her

**Judge Tom Danheusser**: Based on her math input

**Jeff Bergosh**: What I've requested of her won't allow that

**Jeff Bergosh**: Garbage in garbage out

**Judge Tom Danheusser**: She put her math students in a very bad position 

**Jeff Bergosh**: I clarified a lot of it last night

**Jeff Bergosh**: Yes she did

**Judge Tom Danheusser**: Yes you did...call whenever..no rush

**Judge Tom Danheusser**: You're right...it says Senior management...NOT elected officials!

**Judge Tom Danheusser**: Oops...it does add elected 

**Jeff Bergosh**: Now that its under the microscope my prediction is it goes away due to the political gravity

**Judge Tom Danheusser**: Agreed

### CONVERSATION ON 06-11-2021

**Judge Tom Danheusser**: Bergosh also asked the county attorney to investigate if there was a legal way to charge newly built homes a higher fire fee than existing homeowners...


no there isn't, except for impact fees 

**Judge Tom Danheusser**: Fast free legal advice  :)

**Judge Tom Danheusser**: I wonder how % of Santa Rosa volunteers compare with Escambia?,

**Jeff Bergosh**: Thx.  I know Gulf Breeze is all volunteer--most of the rest of coverage is independent fire districts (= super high taxes)

**Judge Tom Danheusser**: True...some have assessments some have millage

**Judge Tom Danheusser**: The shut down has been a historic failure and disaster 

**Judge Tom Danheusser**: https://weartv.com/news/local/escambia-county-fatal-drug-overdoses-increase-over-60-in-past-year-medical-examiner-says

**Jeff Bergosh**: Yes it has been

**Judge Tom Danheusser**: Great that you had her on your show 

**Jeff Bergosh**: Yes she is a great guest and that info was compelling-- weird that Channel 3 is just now looking at it

**Jeff Bergosh**: Next week's coffee will be equally compelling; I'm going to have two cyber security experts on the show.

**Judge Tom Danheusser**: Good stuff...

**Jeff Bergosh**: Thx

### CONVERSATION ON 08-25-2021

**Judge Tom Danheusser**: Thank you for showing the incompetence of court administration...bravo!

**Jeff Bergosh**: You heard about that huh lol

**Jeff Bergosh**: They're not happy with me right now😎👍

**Judge Tom Danheusser**: About as Happy as  they are about me :)

**Judge Tom Danheusser**: asked them to take some useless plexiglass down so I could actually hear witnesses.. she declined.. I brought my power driver in and solved the problem  :)

**Jeff Bergosh**: That's awesome Tom!! 

**Judge Tom Danheusser**: Gary needs to be chief judge..

**Jeff Bergosh**: 👍

**Jeff Bergosh**: He wouldn't let those guys play power games like they do right now

**Judge Tom Danheusser**: They'd be private citizens already..

**Judge Tom Danheusser**: Instead of arrogant bureaucrats

**Jeff Bergosh**: Amen to that!

**Judge Tom Danheusser**: Amazing that Wes can actually fix a damn simple issue that Robin refused for a year.. insanity 

**Jeff Bergosh**: Agreed!  And then she called him on it!!

**Judge Tom Danheusser**: She's a fool,  worse than useless...obstructionist 

**Jeff Bergosh**: Yes

### CONVERSATION ON 01-06-2022

**Judge Tom Danheusser**: God forbid that the public actually sees what happens in our schools:

https://www.pnj.com/story/news/local/education/2022/01/06/escambia-county-school-district-wants-instagram-remove-beulah-middle-school-fight-videos/9107791002/

**Jeff Bergosh**: I saw the videos-- horrible

**Judge Tom Danheusser**: I couldn't find them...did it look out of control?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I saw them this morning before Instagram took them down

**Judge Tom Danheusser**: I expected better from tim..

### CONVERSATION ON 01-25-2022

**Judge Tom Danheusser**: Is it accurate that elementary teachers don't have regular parent teacher conferences???

**Jeff Bergosh**: It depends on the school and it depends on the grade level when we were desperately trying to improve third grade reading scores on the F cat when I was on the school board we mandated parental conferences and got a lot of pushback from the union.  Ironically it improve the scores for our third graders but the program eventually died because of pushback from parents and the unions who felt it was too much work for the teachers

**Judge Tom Danheusser**: How about voluntary...can parents insist on conference with their child's teachers?

### CONVERSATION ON 01-26-2022

**Jeff Bergosh**: Will do it thanks Ray!

**Jeff Bergosh**: Yes

**Judge Tom Danheusser**: Great...I've been told, maybe incorrectly that such a conference would be on teacher's own time..

**Jeff Bergosh**: Nope.  They typically get planning periods or get a sub.  I'm sure some do it on their own time but my recollection from their contract is that they get comp time or a sub for when they schedule these

**Judge Tom Danheusser**: Thx!

