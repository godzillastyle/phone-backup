

## CONVERSATIONS WITH BILL SPAIN

### CONVERSATION ON 09-19-2020

**Jeff Bergosh**: Thank you Jennifer!

