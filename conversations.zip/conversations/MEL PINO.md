

## CONVERSATIONS WITH MEL PINO

### CONVERSATION ON 10-24-2019

**Jeff Bergosh**: In back to back meetings I'll call u after

**Mel Pino**: Awesome

### CONVERSATION ON 10-25-2019

**Mel Pino**: Morgan just settled the Laura Montoya case for gender discrimination and workplace harrassment

**Jeff Bergosh**: That's great for Laura! Fantastic to hear that

### CONVERSATION ON 10-28-2019

**Mel Pino**: Danielle Hopkins FB.

### CONVERSATION ON 11-01-2019

**Mel Pino**: Wonder if the fifth cent is on the agenda.

**Jeff Bergosh**: No- probably a competing civic center arena proposal.  Ron is shopping it to commissioners

**Mel Pino**: Another one??

**Jeff Bergosh**: A different/competing concept 

**Mel Pino**: You mean a different one from Patel?

**Mel Pino**: I just got very tired.

**Jeff Bergosh**: Yes

**Mel Pino**: Rusty is trying to figure out what I know I didn't play :)

**Jeff Bergosh**: In mtg

**Mel Pino**: No worries left a message no need for call back. Have a great weekend!

### CONVERSATION ON 11-02-2019

**Mel Pino**: So as far as I can make out that fiasco of a late breaking Stormwater project--all conducted with maximum double secret probation, of course--is because there is a funding gap on the signalage. So cook up a half baked Stormwater project in an area with bad gas lines, grab some grant money, shuffle the grant money to the lights and dump unteeated storm water off a highway into the bayou. No.

### CONVERSATION ON 11-04-2019

**Mel Pino**: Scott Miller's appeal went in friday

**Jeff Bergosh**: Great news!

**Mel Pino**: YES

### CONVERSATION ON 11-07-2019

**Mel Pino**: Maybe we can get a map of the safes for the backup tonight

**Jeff Bergosh**: LOL -- and combinations as well please.  And the alarm code

**Mel Pino**: Just put one in the octopus garden and call it a day

**Jeff Bergosh**: LOL

**Mel Pino**: Oh my god I wish steven would just say "you aren't going to be on it long."

**Mel Pino**: JEFF SHE JUsT SAID U GUYS DONT HAVE TO PAY

**Mel Pino**: Don't pay it now!!!

**Mel Pino**: Jeff Steven is trying to kill it!

**Mel Pino**: Let him kill it!

### CONVERSATION ON 11-11-2019

**Mel Pino**: Check email.

**Jeff Bergosh**: Which email?  What is it?

**Mel Pino**: Doug losing his mind and accusing you guys of collusion with Scott Miller and bears

**Mel Pino**: Jeff I thought there was a cow this Thursday the 14th but instead that is gone and there is a regular meeting on Monday the 18th?

### CONVERSATION ON 11-12-2019

**Jeff Bergosh**: Doug is unhinged.  Yes, COW cancelled no meeting til next Monday

**Jeff Bergosh**: Because several commissioners are going to FAC in Tallahassee or Orlando or wherever it is 

**Mel Pino**: Ok thank you

### CONVERSATION ON 11-14-2019

**Mel Pino**: Sorry I was draining pasta. Check your Facebook voicemail.

### CONVERSATION ON 11-15-2019

**Mel Pino**: The End.

**Jeff Bergosh**: Crazy shit

### CONVERSATION ON 11-17-2019

**Jeff Bergosh**: Yes I saw this.  David Bear sent me a screen shot.  How does Doug expect to get anything accomplished if all he does is run us down, insult us, and lie about us?

**Mel Pino**: Jeff you do understand that he is lying about the outcome of my hearing, right?

**Mel Pino**: I didn't get any injunctions put on me.

**Jeff Bergosh**: He lies about lots of things

**Mel Pino**: Omg Jeff thank you thank you thank you

**Mel Pino**: Finally figured out how to submit a comment. :)

**Mel Pino**: We have passed 50 signatures for censure in a half day

### CONVERSATION ON 11-18-2019

**Mel Pino**: Jeff thank you so much for that. You have no idea how much that meant to staff. You now have 2 of stories that are LEGION and this is why the crisis at that position. 

**Mel Pino**: A dozen stories would start to cover it but that would be no means be all of it.

**Mel Pino**: I never exaggerated anything Jeff. If anything. I didn't even tell you how bad it really was.

**Mel Pino**: And it's way worse than anything that has been shared.

**Mel Pino**: You have no idea what it was like for me to see that smug coward come back into chambers today like a returning Prince. I wanted to puke.

**Jeff Bergosh**: He is a smug coward

### CONVERSATION ON 11-19-2019

**Mel Pino**: Not Escambia, Lynn haven. Not BP, but FEMA fraud.

**Mel Pino**: Call when you can. Have more paperwork proof.

### CONVERSATION ON 11-20-2019

**Jeff Bergosh**: Can I call you later?

**Mel Pino**: Yep just wanted a quick follow up

### CONVERSATION ON 11-25-2019

**Mel Pino**: Heres a thought. Ask Alison if any other attorney at the county wrote and opinion on whether edler was outside of her purview and see what she says

### CONVERSATION ON 11-26-2019

**Mel Pino**: Check email

**Mel Pino**: Check email again

**Mel Pino**: I just donated to defense fund

**Jeff Bergosh**: Got it

**Jeff Bergosh**: Why?

**Mel Pino**: Read my reason

**Mel Pino**: 5 bucks

**Jeff Bergosh**: LOL $5

**Mel Pino**: Read my reason. Go to the page

**Mel Pino**: Check email again 

### CONVERSATION ON 11-27-2019

**Mel Pino**: Left mssage

**Jeff Bergosh**: Called, he didn't pick up.  Mailbox full.  Texted him.  Do you think he wants to talk to me?

**Jeff Bergosh**: It was a 619 area code number

**Mel Pino**: Yes he really does. He had to get off phone with me...he's at work at the airport so prob had something come up

**Jeff Bergosh**: Ok

**Mel Pino**: That's the right number.

**Jeff Bergosh**: 👍

**Mel Pino**: His box is always full up there

**Mel Pino**: Maybe he had to deal with the anti violence sit in haha

**Jeff Bergosh**: LOL

### CONVERSATION ON 11-28-2019

**Mel Pino**: PLEASE WIN THAT TREE!!!!!!!!

**Mel Pino**: I'll go halves

**Jeff Bergosh**: LOL

### CONVERSATION ON 12-03-2019

**Mel Pino**: Jeff fyi WEAR mis reported on the "public corruption" charge, it looks like to me. Escambia site has "public order crimes" and three other charges but not public corruption.

### CONVERSATION ON 12-05-2019

**Mel Pino**: ?????

**Mel Pino**: How many committees does doug have

**Jeff Bergosh**: 1 I think

**Mel Pino**: Yup. I figured :)

**Mel Pino**: Jeff tell him he is right and the county is going to start maintaining and put some sidewalks in

**Mel Pino**: Sidewalks!!! :)

**Jeff Bergosh**: What is the muscle memory phrase mean?  I'm trying to understand where Kevin is coming from with that

**Mel Pino**: Oh Lord it's from rescue -. Will explain.

**Jeff Bergosh**: LOL

**Mel Pino**: Omg Jeff is Steven gaming navy federal? In a smart way?

**Jeff Bergosh**: I don't think so--not sure what's up with this

**Jeff Bergosh**: Crazy

**Mel Pino**: Pretend back then it was about mixed use but now it's about flexibility if we don't like the plans we won't accept. Force them to give options and then swing it more towards business than residential

**Mel Pino**: Wtf she couldn't even answer that question? Are you kidding me?

**Jeff Bergosh**: This discussion is BS

**Jeff Bergosh**: So frustrated

**Mel Pino**: Actually it sounds like legal fucked this up.

**Jeff Bergosh**: They didn't

**Jeff Bergosh**: This has been known for quite some time

**Mel Pino**: Who cleared up the title? Who identified the problems? She dodged that

**Jeff Bergosh**: NFCU

**Mel Pino**: The title stuff she pretended she didn't remember?

**Mel Pino**: Okay yeah right. So she didn't do due diligence and it put them in the upper hand for negotiating

**Jeff Bergosh**: These guys are paying $1.5Million for our master plan

**Jeff Bergosh**: Created 8,400 jobs

**Mel Pino**: I'm talking about something different than what lumon is

**Jeff Bergosh**: This is bullshit

**Jeff Bergosh**: And it's embarrassing

**Mel Pino**: I'm talking about Roberts concerns on the  contract

**Mel Pino**: I would agree this over the top from lumon but I will tell you honestly Jeff I am sick to death of these companies who won't disclose real numbers with jobs and Scott luth's dance is getting old

**Mel Pino**: Why do you think Steven is stepping down

**Mel Pino**: Notice that Allison has not refuted that her dept missed the last title problems.  

### CONVERSATION ON 12-06-2019

**Mel Pino**: Are you ok???

### CONVERSATION ON 12-09-2019

**Jeff Bergosh**: Sailor Jerry Monday?

**Mel Pino**: Burns my ass to see her trash talking EMS after friday

**Jeff Bergosh**: Me too

**Jeff Bergosh**: Lunacy

**Mel Pino**: The longer the county let's this problem run along with no correction and no firm statement, the greater the liability.

### CONVERSATION ON 12-10-2019

**Mel Pino**: CEU's available at a house party.

**Mel Pino**: Limited space for these CEUs so RSVP.

**Jeff Bergosh**: In mtg will call u back

**Mel Pino**: 👍

### CONVERSATION ON 12-11-2019

**Mel Pino**: Please call when done :)

**Mel Pino**: Steven just confirmed he is going to allow public input at the special meeting. I am going to address ems response. Nothing specific. If there is a commissioners forum and you think there is anything you need to add I would be grateful.

**Mel Pino**: Check your email. 

### CONVERSATION ON 12-12-2019

**Mel Pino**: OMG Jeff a guy named gre Allen is claiming Doug's son assumed his child and they are flipping it on his kid. I of course can't know what happened but he claims the school district is covering it up for underhill

**Mel Pino**: Sorry assaulted

### CONVERSATION ON 12-13-2019

**Mel Pino**: Good morning, will you be doing any blogs today?

**Jeff Bergosh**: Nope

**Jeff Bergosh**: ... is what I'm doing today😎

**Mel Pino**: Ok I will tell people everybody is watching for it

**Jeff Bergosh**: They haven't sent it to me yet either so I have to wait till they do

**Mel Pino**: Oh that's right. Thank u. Have fun!

### CONVERSATION ON 12-14-2019

**Mel Pino**: Fyi Wilson's surgery went well and he went home yesterday.

**Jeff Bergosh**: Good to hear

**Mel Pino**: Did they release the doc? Inquiring minds want to know

**Jeff Bergosh**: No response from Janice or Alison about whether or not I can release it.  

**Mel Pino**: Mike and  I headed to Atlanta today for pcw Christmas party.

**Mel Pino**: Unbelievable.

**Jeff Bergosh**: I have asked

**Jeff Bergosh**: I'm going to ask MATT Selover if either of them gave him a final verdict by the due date yesterday

**Mel Pino**: They hadn't reached out to him when I talked to him yesterday morning

**Mel Pino**: He asked me "aren't they supposed to be meeting with me?"

**Mel Pino**: It just goes on and on.

**Mel Pino**: Thank you so much Jeff. Nice relief headed into a corporate party. :)

**Mel Pino**: THANK YOU again and merry Christmas from atlanta

### CONVERSATION ON 12-15-2019

**Jeff Bergosh**: Merry Christmas!

**Mel Pino**: Jeff fyi when u hear my message it's okay. He doesn't care about that text.

**Mel Pino**: THIS IS TOTAL AND COMPLETE BULL SHIT.

**Mel Pino**: Absolutely cannot imagine what they are thinking. Increasing liability at every turn they can.

**Mel Pino**: You know that whole 'draft" bullshit is setting it up so they don't have to address the admin initial complaints...the 5 others that got ignored.

### CONVERSATION ON 12-16-2019

**Mel Pino**: 850-712-4889 leon

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: No worries left a message

**Mel Pino**: Anything yet?

**Jeff Bergosh**: They had no new documents and said that there were documents but produced none.  Total waste of time

**Mel Pino**: Lying. 

**Mel Pino**: Probably cooking the docs up.

**Jeff Bergosh**: I hope not for their sake

**Mel Pino**: Jeff just as soon as you get that doc forward it to Jim also so he has it while writing his story

**Jeff Bergosh**: He will have it

**Jeff Bergosh**: Does Matt have it yet???

**Mel Pino**: I called him and left a voicemail to shoot it to you just as soon as he gets it

**Jeff Bergosh**: 👍

**Mel Pino**: Check email for a firm date on "updated" QA policy being sent out. 

**Mel Pino**: I think Kelly is out today.

**Jeff Bergosh**: Got that

**Mel Pino**: In other words another thing cooked up as justification.

**Mel Pino**: Ed probably has a copy of it. I doubt he would have had Matt's jump drive and not made a copy of the doc. 

**Mel Pino**: Jeff don't forget to get that to jim

### CONVERSATION ON 12-17-2019

**Jeff Bergosh**: 👍

**Mel Pino**: Hey I think I forgot to mention to you that Paulette Stallworth put her notice in. 

**Mel Pino**: Jeff u up? Important

**Mel Pino**: Very

### CONVERSATION ON 12-18-2019

**Mel Pino**: Call me back! :)

**Mel Pino**: Ignore this call leaving you a message.

**Mel Pino**: Omg in Teresa hill's new video a civil engineer calls doug Underhill a circus act

**Mel Pino**: This is making me nuts. 8 months I have been dealing with this problem and I feel like they are going to drop some backdated crap today. I'm so sick of it.

**Mel Pino**: ?

**Mel Pino**: I just talked to Joey kerman and he told me that the county is losing 5 more emt's and paramedics over the course of the last 2 weeks. One of them was up for promotion and doesn't care--just wants out. I asked him to get the hard numbers for me when he is back in the office tomorrow.

**Mel Pino**: Okay the firm numbers are 3 emt's and 1 paramedic in the last two weeks. 

**Mel Pino**: The medic was going to be promoted to captain but is leaving for sacred heart instead.

### CONVERSATION ON 12-19-2019

**Mel Pino**: Paulette did NOT resign somebody got that going on her.

**Mel Pino**: Oh also doug got served.

**Mel Pino**: In 2009 JM made 2.5 M from Baptist. That was just one hat.

**Mel Pino**: 82K in supplemental retirement plan

**Mel Pino**: Sorry the 2.5 was divestment

### CONVERSATION ON 12-20-2019

**Mel Pino**: Hodgkin's statement dated 11-25. He resigned from the county 11-15 and was no longer a county employee from the moment of his resignation, as I understand it.

**Mel Pino**: Hopkins

**Mel Pino**: I wonder if she is going to try to sell training at the county with that LLC?

**Jeff Bergosh**: Who knows

**Mel Pino**: Posted a comment.

**Jeff Bergosh**: Published it

**Mel Pino**: Check email

**Mel Pino**: Yeah!!!!!!!!!!!! I've been waiting for one person to flip :) it only takes one

### CONVERSATION ON 12-21-2019

**Mel Pino**: She added Keith Morris to that email. So apparently there will be somebody ex IG and fdle in the mix.

**Mel Pino**: Jeff also compare Anne's letter, where she explains what the doh is there for, with the answers you got to your questions. Smh.

**Mel Pino**: Kevin suggests that you put on a swat uniform for the next bocc meeting.

**Jeff Bergosh**: LOL

### CONVERSATION ON 12-23-2019

**Mel Pino**: Jeff I posted my comment and forgot to add my name...can you add it? --Melissa Pino

**Jeff Bergosh**: Just re add it and add your name and I'll approve the second one only

**Jeff Bergosh**: Can't edit comments just delete or publish

**Mel Pino**: Okay

**Mel Pino**: Done. I consulted an HR expert on it whose mind is blown by what HR is laying down.

**Jeff Bergosh**: Yeah it's a bunch of garbage

**Mel Pino**: Fyi I had to double check. It was Kate Kenney and Rebecca brownfield she accused of "sabotaging" her protocols she had to pull back.

**Mel Pino**: Can you imagine a paramedic sabotaging protocols. It defies imagination.

**Jeff Bergosh**: That's BS

**Mel Pino**: That was out of the gate. One of the reasons the harassment claims went in 2 months after she came on. She hit the ground running.

**Mel Pino**: Another question to ask Janice is why there is no QA person on the org chart. Which is, I believe, against state statute. I pointed that out to her but I have not heard of the position being filled. Maybe I just haven't heard but it was empty with an actual question mark behind it to draw attention to how bad it is to have that not filled.

**Mel Pino**: Posted again.

### CONVERSATION ON 12-25-2019

**Mel Pino**: Merry Christmas to you guys!!

**Mel Pino**: Nice!!

**Mel Pino**: This was Christmas Eve:) 

### CONVERSATION ON 12-27-2019

**Jeff Bergosh**: Nice

**Jeff Bergosh**: From Nick Gradia

**Mel Pino**: I was jus[ going to call you on that. Check my response

**Mel Pino**: This is getting out of hand Jeff: (

**Jeff Bergosh**: I agree

**Jeff Bergosh**: I called Chips and he is putting together some data

**Mel Pino**: Don't know what the answer is but it has to stop

**Jeff Bergosh**: The post is greatly exaggerated

**Mel Pino**: Chip or chips?

**Jeff Bergosh**: Chips

**Jeff Bergosh**: I told Chips what would you do if a waiter at dharma blue Was online saying the food sucks here the drinks are overpriced the service is terrible but here's where I work and they should pay me more

**Mel Pino**: Yep and he will take it straight to Janice and ask her what to do.

**Mel Pino**: Keep an eye on that string. Nick just came back at me with threats of proof.

**Mel Pino**: I understand Janice has a ton on her plate but she has got to take a firm hand with this before it blows up into something worse. Nick Gradia can be canned right now for his Facebook activity. He thinks he is safe by posting anonymously on that fire page but he brings it over to his personal page also. That is against county policy. It is more than time to clean house.

**Mel Pino**: We lost another EMT and another medic in the last two days.

**Jeff Bergosh**: 2 Medics and an EMT

**Jeff Bergosh**: According to Matt Selover

**Mel Pino**: This will only get worse Jeff unless something changes :( the good news is I just confirmed with public safety that admin has directed them to put together stats

**Jeff Bergosh**: I asked Chips to get some stats together

**Mel Pino**: Yep and they are on it but Lindsay Ritter is out today. Not a bad thing somebody else will be compiling them.

**Jeff Bergosh**: Yep

**Mel Pino**: Remember there are people in that department who were willing to manipulate how call times were logged to make the argument for more fleet. With our fire chief trying to run that and our medical director aware of it.

**Mel Pino**: Did they get you the stats?

**Jeff Bergosh**: Haven't been home to check my email yet

**Jeff Bergosh**: I'll check when I get home

### CONVERSATION ON 12-28-2019

**Mel Pino**: Thank you for the blog. It shouldn't be this hard or this time consuming. Public safety needs fixed coming out the gate in 2020. It needs a reorg plan that combines the depts, cleans house of current leadership, and starts listening to medics about what changes might help

**Mel Pino**: I'm talking about logistical changes not leadership changes. Those are obvious enough for most people.

**Jeff Bergosh**: Thx Mel

**Jeff Bergosh**: .....for them

**Mel Pino**: Unfortunately Jeff there are a LOT of citizens who are buying it :(

**Mel Pino**: I don't understand why an employee of the county is allowed to run on against admin and the bocc the way he does. He wasn't just posting from the union page yesterday. He was throwing down from both accounts. 

**Mel Pino**: Also, the county could just shut down that page. Or demand transparency with no shut down. It boggles my mind the union busting tactics that are happening in the with ecat--some of which might prove to be dangerously overboard--while they let our firemen run fear mongering tactics on the citizens to try to scare the bejesus out of citizens. That kind of inconsistency is very, very weak. And it shows.

**Mel Pino**: Hey Jeff I just went to copy and paste that chart of "holding calls" onto the fire page and stopped when I realized they cut short on the 24th. Why didn't they provide you with data all the way through the day before yesterday, when the fire is claiming the chaos happened?

**Mel Pino**: I really don't like that they have set this up to look badly by not having a way to filter out "on hold" but okay. Stopping at the 24th?

**Mel Pino**: Matt, Kate, and Joey were all off. Who was the supervisor on duty during this?

**Jeff Bergosh**: Maybe that's where the info cuts off?  Don't know but I will ask

**Mel Pino**: You should because they are going to go after that. The period nick was blogging about you didn't get info on. Late night 26th into early morning 27th. It might have been worse and they are protecting the department :( I don't mean this on the medics, of course. 

**Mel Pino**: Jeff I would be a little more careful as those stats look to me to be tailored for you for averages and ball parks. More info that we had, but there might have been a 40 minute call time--its possible. While fire is exaggerating things badly, our ems is struggling immensely so don't go too far out on a dead limb until you check concrete information. Hopefully that will ne forthcoming

**Mel Pino**: Just did 2 part comment

**Mel Pino**: Posted

### CONVERSATION ON 12-29-2019

**Mel Pino**: Posted a comment

**Mel Pino**: Also maybe you should embrace "The Berg"

**Mel Pino**: Except drop the "the" like they did with "the Facebook"

**Mel Pino**: T shirts that just say BERG :)

**Jeff Bergosh**: LOL

**Mel Pino**: Bergosh Expects Responsible Government

**Mel Pino**: With an icon of you pushing on an iceberg haha

**Jeff Bergosh**: I like it!

### CONVERSATION ON 12-30-2019

**Mel Pino**: Wow Jeff pay very close attention to some of those last comments that came in and it will give you the exact picture of what has been going on. With the history of past chiefs and where things took a wrong turn. All under Jack brown and his longevity games.

**Mel Pino**: Just posted a couple more.

**Mel Pino**: Comments in brought in from the Fire page.

**Jeff Bergosh**: Thanks Mel

**Mel Pino**: Check this. Just in from a firefighter. These are the element they were so desperate for

**Mel Pino**: These are ones on a brush truck this is just one station 

**Mel Pino**: He estimates they easily ordered a hundred too many.

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Leadership vacuum

**Mel Pino**: Yep.

### CONVERSATION ON 12-31-2019

**Mel Pino**: You have a funny way of taking the day off :)

**Jeff Bergosh**: Motivated!

**Mel Pino**: Happy New Year:)  bittersweet for you guys I know. Get out of that house!

**Jeff Bergosh**: In New Orleans French Quarter 😎👍

**Mel Pino**: Oh that's AWESOME. Well done! Happy New Year!!

**Mel Pino**: Jeff pleases my last social media foray before heading out for new years. Sorry to bug you but honestly I want that out there  just click the button :)

**Mel Pino**: Just take 10 second to post. :) I won't bug you again

### CONVERSATION ON 01-02-2020

**Mel Pino**: Why in the he'll isn't the current county harassment policy part of the backup? Diversion tactics to federal regs.

### CONVERSATION ON 01-03-2020

**Mel Pino**: I'm getting ready to drop that email. U done with meeting yet?

**Mel Pino**: Jeff if you are still up I posted a short response to blog.

### CONVERSATION ON 01-04-2020

**Mel Pino**: Post on Dr. Edler's Facebook page set for Facebook friends.  about a hundred likes but only 4 of them are current EMS staff. 

### CONVERSATION ON 01-05-2020

**Mel Pino**: Sorry about the Sunday morning negativity. He's out of the gate already, and getting worse. Should get real interesting by mid afternoon.

**Jeff Bergosh**: He's a nut

**Mel Pino**: And getting nuttier. I just posted to your blog. Nothing from PNJ yet :(

**Jeff Bergosh**: It's in the hard copy paper today

**Jeff Bergosh**: Not electronic version 

**Mel Pino**: Oh crap I was gonna go out this morning for one but didnt want to be disappointed! Headed out...

**Jeff Bergosh**: I have good quotes in the Selover story and also in the appointed superintendent piece😎👍

**Mel Pino**: Jim did a good job! It's maddening to see it laid out so he said she said, but he was just being balanced and doing his job.and I think the headline and story was very good on your leadership. So relieved it is all finally getting out there. Thank you

**Mel Pino**: Sorry misdial

**Mel Pino**: Walking through this doc again I just saw the thing where she switched the story to Matt bringing harassment charges against her BEFORE the qa board. Smh.

### CONVERSATION ON 01-06-2020

**Mel Pino**: Now it's PAO's fault.

**Jeff Bergosh**: LOL unhinged 

**Jeff Bergosh**: He is so fixated with "Bears"--I wonder if he sleeps with his own personal "care bear"

**Mel Pino**: Yes and it's first name is Jonathan. 

**Jeff Bergosh**: LOL Jonathan the human "care bear"

**Mel Pino**: That heart isn't in the money shot spot though.

**Jeff Bergosh**: Ha ha ha--right!  It would be on his lower back

**Mel Pino**: Courtesy of kevin.

**Mel Pino**: 😂

**Jeff Bergosh**: LOL that's awesome

**Mel Pino**: Please check email

**Mel Pino**: https://www.statter911.com/2016/02/09/scathing-resignation-letter-from-medical-director-says-people-are-dying-needlessly-in-nations-capital/

**Mel Pino**: https://www.nola.com/news/politics/article_70d60c25-7c66-5d74-85df-20866fd541d1.html

**Mel Pino**: Coming to the meeting tomorrow

**Mel Pino**: https://www.nola.com/news/politics/article_70d60c25-7c66-5d74-85df-20866fd541d1.html

**Mel Pino**: Please check my query email

### CONVERSATION ON 01-07-2020

**Mel Pino**: 1 hour ago. 

**Mel Pino**: Heads up on an email on LET Jimmie just sent the board

### CONVERSATION ON 01-08-2020

**Mel Pino**: https://www.pnj.com/story/news/2020/01/08/paramedic-sue-escambia-county-over-forgotten-harassment-complaint/2843698001/

**Jeff Bergosh**: Call me when u have a minute

**Mel Pino**: Please do not share Jeff. This is Kate's. Leon signed one also. Let me find out others. Edler refused.

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-09-2020

**Jeff Bergosh**: Where is that from?

**Mel Pino**: I'm assuming ecw but haven't checked yet

**Mel Pino**: Yep ecw

**Mel Pino**: https://www.facebook.com/groups/446794355356335/permalink/2676204085748673/

**Mel Pino**: Jonthan filing tomorrow

**Mel Pino**: Congrats on your filing. In case you think people haven't recognized the strategy, it was all diagnosed a long time ago. I hope you have recognized that we I have kept my word to stay clear of taking gloves off with anything having to do with you in my battle against doug (which I will win). Keep it clean against Jeff and I will honor that commitment. If things get dirty, it will be Katy bar the door Jonathan.

**Mel Pino**: Sent that to Jonathan.

**Mel Pino**: 2A forum at Pine Forest Baptist Church is where Jonathan is tonight.

**Mel Pino**: Sitting behind Michelle Salzman to try to look like there's proximity

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Left message.

### CONVERSATION ON 01-10-2020

**Jeff Bergosh**: Super-slammed at work.  Will call later this afternoon once I come up for air

**Mel Pino**: Good...news.

**Jeff Bergosh**: 👍

**Mel Pino**: Done 

**Jeff Bergosh**: Thanks!

### CONVERSATION ON 01-11-2020

**Mel Pino**: Let me know if you see that piece of shit hit their Facebook page.

**Jeff Bergosh**: I will.  Watching for it

**Mel Pino**: Just posted to your blog.

**Jeff Bergosh**: Got it thx

**Jeff Bergosh**: Pnj editorial just went live on their Facebook site

**Mel Pino**: Thnx

### CONVERSATION ON 01-12-2020

**Mel Pino**: Jeff when does redistricting happen? Can't remember the date

**Jeff Bergosh**: 2021 after census

**Mel Pino**: Tnx!

**Jeff Bergosh**: 👍

**Mel Pino**: Jeff I really think you should hold a town hall down in country club soon. D2 has been orchestrating a takeover down there. 

**Jeff Bergosh**: Probably will.  Very small precinct though

**Mel Pino**: Yes but it is being watched.

**Jeff Bergosh**: Which probably will go to D2 after re districting

**Mel Pino**: Yep but they are going to try to run a headline of "Jeff doesn't care" and holding a town hall to here their concerns will offset it. They are going to bank on a strategy of claiming neglect. Every vote will count this race.

**Mel Pino**: "Bergosh doesn't care" will be one of their through lines. As ridiculous as that is.

**Jeff Bergosh**: Yes I know

**Jeff Bergosh**: Go look at PNJ--no cartoon at least

**Mel Pino**: Paper version?

**Jeff Bergosh**: Yes---surprised Marlette didn't do a cartoon.  Good!

**Mel Pino**: Jeff he didn't write that article. Trust a literary critic who spent 25 years professionally analyze zing the written word. That's not his idiom.

**Mel Pino**: There are ghost writers  penning op eds for the PNJ. I can spot Andy Marlette anonymous from a mile away and that ain't it. And Lisa savage isn't that strong of a writer either.

**Jeff Bergosh**: Lazy and weak PNJ

**Mel Pino**: When they rip off one of those hit pieces these days it is coming from a ringer.

**Mel Pino**: No, I suspect it is coming from Snyder's author team. You know. The one that constantly churns out books that land on the best seller list.

**Mel Pino**: Studer

**Mel Pino**: Not saying that Andy is never involved. Just saying that one came from high Upstairs.

**Jeff Bergosh**: For what though--what purpose?  I don't think he will support Jonathan or Jesse--why would he.  I think he will stick to downtown.  I don't see him getting in my race

**Mel Pino**: New worlds to conquer. It's about destabilizing the board as a whole to solidify power base for the city.

**Mel Pino**: Whoever wrote that article is way smarter politically than either Lisa or Andy. Knew just what to put in and what to leave out. Very skilled pro. And a far better writer than either of them.

**Jeff Bergosh**: Hopefully not as sinister as that

### CONVERSATION ON 01-15-2020

**Jeff Bergosh**: Phone tag

**Mel Pino**: Sorry will call in a minute there is a depo happening right now

**Mel Pino**: Jeff we posted the filing publicly. Ask Gary if you could post it to your blog with no comment. :)

### CONVERSATION ON 01-16-2020

**Jeff Bergosh**: I will.  Congrats

**Jeff Bergosh**: Where is it posted, the filing??

**Mel Pino**: On Escambia public forum. 

**Mel Pino**: That new site. In the "files" section

**Mel Pino**: It's a PDF and should be at the top of the list

**Mel Pino**: "Files"link over on the left of the landing page

**Mel Pino**: If they are really wanting more real proposals and get that tech park involved you guys have to put it out for more than 60

**Mel Pino**: This is actually a real discussion about solving multiple problems and if people are going to wrap that text park in they will need a he'll of a lot more than 60 days to plan it

### CONVERSATION ON 01-17-2020

**Mel Pino**: Jeff first thing to figure out is whether Janice and JD ever even got that letter. Backdated and cooked up?

**Mel Pino**: Ask them for it. 

**Mel Pino**: Why in the hell did that come to Matt from Jim going through a text editor. And there is NO DATE on the letter. 

**Mel Pino**: The letter only says "this  responds to your email to me dated July 8 2019" but it was presented in text editor style with NO Date and NO letterhead.

**Mel Pino**: Oh. My. God. This letter is horrible.

**Jeff Bergosh**: Call me

**Mel Pino**: 1. Please call JD and ask him if he got that letter and what exact date he got it. (When you have time)m 2. Please ask Janice when she received this letter.

**Mel Pino**: Jeff my computer screen was cutting off the text editor. Jim's note at the top says July 11 memo

**Mel Pino**: https://ricksblog.biz/robinson-gilley-next-speakers-for-civiccon/

### CONVERSATION ON 01-19-2020

**Mel Pino**: New phone! Fyi I am messaging on signal app now, on Kevin and Mike's advice. Not for encryption, but security. Least hackable messenger. You might want to check it out. More important, is ems in the Sunday paper?

**Jeff Bergosh**: Nope

**Jeff Bergosh**: Surprisingly

**Mel Pino**: Good!! Maybe he is doing diligence

**Mel Pino**: Or maybe he realized what is up, tried to report on it and got told no.

**Jeff Bergosh**: I hope so.  If done improperly it could be horrific.  If done right it could be very important and beneficial

**Jeff Bergosh**: Maybe

**Mel Pino**: Exactly.

**Mel Pino**: Or maybe someone at the county reached out to studio and asked him to kill it.

**Jeff Bergosh**: Not a bad theory

**Jeff Bergosh**: Still want to know who released the memo

**Mel Pino**: Yup. Well at least poor Matt doesn't have his name smeared in the Sunday rag. Thank God.

**Jeff Bergosh**: 👍

**Mel Pino**: Yes I think that might have been illegal? At any rate the county needs to get to the bottom of it. Which won't happen.

**Jeff Bergosh**: I and the courts will work it out 

**Jeff Bergosh**: Too bad it had to come to that

**Mel Pino**: I don't know at what point people are finally going to realize this can't be contained any longer. Thank you so much Jeff.

**Mel Pino**: I'm free to talk more but have to be careful in tone and content because she can technically open it back up.

**Mel Pino**: Teresa Hill is incensed about it but they couldn't touch my suit because Elder brought it as an individual. Matt's is different.

**Jeff Bergosh**: No problem.  Choices have consequences.  Janice should have made a better choice here.  Instead, she listened to the HR greenhorn and Maygarden--and for that the court system will now have to fix it for Selover

**Mel Pino**: I've provided her with all the docs that are public so far and she is waiting for the filing to go live on the clerk site

**Jeff Bergosh**: 👍

**Mel Pino**: Has Alison shared the filing with you guys yet?

**Mel Pino**: Or did they sit on it over the weekend,

**Jeff Bergosh**: Nope

**Mel Pino**: Unbelievable.

**Mel Pino**: Just posted a comment to your blog.

**Mel Pino**: Hey do me a favor and text me a heads up when you post a new one. I can't get it to alert me and other people have the same thing. I never know til somebody tells me.

**Mel Pino**: Just saw admin heralded for transparency in the civiccon article.

**Mel Pino**: Et tu Patel?

**Jeff Bergosh**: Will do

**Mel Pino**: Wow. The county administrator is now the equal of the mayor of Pensacola.

**Mel Pino**: Omg Jeff Kevin just saw the blog about her dropping the suit!!!! I missed it!! THANK YOU

**Jeff Bergosh**: Absolutely.  No problem!

**Mel Pino**: I saw the one above it but not that one.

### CONVERSATION ON 01-21-2020

**Mel Pino**: Well you had a busy day yesterday! Did my heart good to see it. Give me a call when you have time.

**Jeff Bergosh**: Read it, all of it.  Devastating.  Should not have come to this.

**Mel Pino**: Take that and multiply it by the six more we know of, all of whom had even LESS due process.

**Mel Pino**: One of them blocked from putting in a claim, at all.

**Mel Pino**: Jeff have your friends with videogame make sure to get a direct pan on your signs. Businesses also. Then when Doug and Jonathan employ their operatives to run around and move your signs so they are in violation, you can hopefully capture an instance on video. They will hit this every night, in streaks, and move your signs to the ROW or just remove them. We retrieved about a couple hundre signsn if memory serves, from the dump during the McMillan campaign...Sava was friends with someone there.

**Mel Pino**: Video camera

**Mel Pino**: Let's switch to Signal https://signal.org/install

**Mel Pino**: And think about that messenger, not to encrypt but because it is most secure in market. Very easy to install and use. Kevin and Mike insisted I get on it after my last phone got hacked.

**Jeff Bergosh**: In PEDC meeting will call u after

**Mel Pino**: K

**Mel Pino**: Check email when you have time for a letter on the county paying the lawyers fees.

**Jeff Bergosh**: Well written

**Mel Pino**: And should have been necessary. Like so many other things.

**Mel Pino**: Jeff pass you parade situ through Stanford's office, ask them for verbiage and pertinent statute, get written clearance--ask them for that--and the write a brief DISPASSIONATE blog on it. :) as if you were writing an interface communication at work. Information only: clearly up a misconception.

**Mel Pino**: You could even do it like a spoof memorandum. To Doug Underhill. And keep the language as if he were an employee you need to convey important clarification to.

**Jeff Bergosh**: LOL that would be funny

**Mel Pino**: Posted to your blog.

### CONVERSATION ON 01-22-2020

**Mel Pino**: Just posted. SAY SOMETHING NICE about Jacqueline corrections and don't make it a left hand compliment! :)

**Mel Pino**: I'm serious...simply thank her for injecting. Don't rub it in her face. That will look very well on you.

**Mel Pino**: The Truth Revolution is here.

### CONVERSATION ON 01-23-2020

**Jeff Bergosh**: Hatchet piece on Selover, lionizing Edler, posted this morning

**Mel Pino**: GODDAMIT good thing I am coming in armed with docs

**Mel Pino**: Ask him why it's okay to have him on the road for regular but not overtime?

**Mel Pino**: What is the logic on that?

**Mel Pino**: Please get that in. He's a serial killer so it's okay to be there for 30 hours but just not overtime?

**Mel Pino**: Told you Horace and Alison were acting for jeff.

**Mel Pino**: Sorry, for Doug.

**Mel Pino**: After he pressured Horace to the breaking point on both instances.

**Mel Pino**: Probably on agricultural lands but absolutely on dollar code. He did that.

**Mel Pino**: Dr. Lanza is the backup medical director who automatically subs in when necessary for Escambia medical director/ems director

**Mel Pino**: Ask Doug where his boat is

**Jeff Bergosh**: LOL

**Mel Pino**: Jeff look at that article with Jerry Maygarden saying he brokered a deal to get Matt out on the road

**Mel Pino**: Also it seems like they couched up complaints to jj not sure he is in depos

**Mel Pino**: Kilgore aide who was quitting 20 plus year got tapped for interview

**Jeff Bergosh**: By who? Jim little?

**Mel Pino**: Yes Jerry claiming he got Matt back on the road

**Mel Pino**: We didn't have a good chance to read it go back again it's a fucking Maygarden circle jerk

**Jeff Bergosh**: Also no mention of your suit getting dismissed

**Jeff Bergosh**: Jim lied 

**Mel Pino**: I don't think he was lying. I think it was in there and Lisa took it out.

**Jeff Bergosh**: Maybe......possibly........

Probably!

**Mel Pino**: He was really insistent it was in there. I think it's possible he turned over a balanced piece and she gutted it.

**Mel Pino**: He was so hurt

**Mel Pino**: I mean, he was really shocked I was coming for him

**Mel Pino**: He said "Mel you missed it it's in there"

**Jeff Bergosh**: Did he read the final piece?

**Mel Pino**: I think he realized it then and that's why he said "you can write to my editor"

**Jeff Bergosh**: Call me

### CONVERSATION ON 01-24-2020

**Mel Pino**: Check email.

**Mel Pino**: Finally got that post up.

**Jeff Bergosh**: Got it!

**Mel Pino**: Jeff whatever you are doing please take a second to post my last comment

### CONVERSATION ON 01-25-2020

**Mel Pino**: Please get my comment up tickets split! :)

**Mel Pino**: Lickety split

**Mel Pino**: Sorry it might have sent twice. Same version

**Mel Pino**: Hey actually I had to correct the "three" to "two" so I did sen a corrected version. Go with that last one

**Mel Pino**: Just posted a follow up comment

**Jeff Bergosh**: Posted

**Mel Pino**: Thanks! Kevin bringing it in.

### CONVERSATION ON 01-26-2020

**Mel Pino**: Commented.

### CONVERSATION ON 01-27-2020

**Jeff Bergosh**: In mtg will call back

**Mel Pino**: Yup. Very first question out of the gate was consolidation. Surprise.

**Mel Pino**: Dispatch mentioned as a consolidated service.

### CONVERSATION ON 01-29-2020

**Mel Pino**: Check email.

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Jeff Bergosh**: Please keep it under wraps

**Mel Pino**: WOOOOOOOOO HOOOOOOOOO!!!!!!!!!

**Jeff Bergosh**: 👍😎

**Mel Pino**: I'm in the planning meeting getting ready to dismantle the sector plan

**Jeff Bergosh**: Go get em'

**Mel Pino**: Just won a rezoning with Larry first. :) poor guy has been boxed out of using his property for a year and a half with 200k of improvements on it and download to ldr

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-06-2020

**Mel Pino**: He SAID there was going to be a grant. Imminent

**Jeff Bergosh**: For the sewer?

**Mel Pino**: Yep

### CONVERSATION ON 02-12-2020

**Mel Pino**: Check email when u can

### CONVERSATION ON 02-13-2020

**Jeff Bergosh**: I saw the response too.  Weak

**Jeff Bergosh**: Very weak

**Mel Pino**: Fyi that wasn't a set up with Larry..had no idea he was writing that email. He had a friend with a mother having a stroke who had to wait 8 hours for an ambulance. 

**Mel Pino**: STILL laughing

**Jeff Bergosh**: 😎

**Jeff Bergosh**: "Jibberish"

**Mel Pino**: I can't wait to watch it again.

### CONVERSATION ON 02-14-2020

**Jeff Bergosh**: Wow!  Saw the email.  

**Jeff Bergosh**: .......and the attachment 

### CONVERSATION ON 02-16-2020

**Mel Pino**: Posted a comment

### CONVERSATION ON 02-18-2020

**Mel Pino**: Box full. Call when you can.

### CONVERSATION ON 02-19-2020

**Jeff Bergosh**: In a mtg will call u back

**Mel Pino**: Sorry misdial

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Big front page today!  Awesome!

### CONVERSATION ON 02-22-2020

**Mel Pino**: EMS got pummeled today and they are so short staffed they could only put 14 trucks out. Calls waiting for hours. Maybe if we could just manage to fire or force out a few more medics we could fix our public safety.

**Mel Pino**: Rebecca Brownfield and her wife Megan have one child of their own and their two adopted foster children are special needs on the autism spectrum.

### CONVERSATION ON 02-23-2020

**Mel Pino**: Though you'd like that :)

**Mel Pino**: Sending this all commissioners except doug

**Mel Pino**: https://m.facebook.com/notes/wendy-kinton-underhill/i-just-cant-let-the-lies-go-un-answered/10156472878577242/

### CONVERSATION ON 02-24-2020

**Mel Pino**: Lutimothy is running against lumon

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: Crazy turn of events

### CONVERSATION ON 02-26-2020

**Mel Pino**: Call when you can about the lawyer discussion

**Mel Pino**: You got the firm's mixed up

**Mel Pino**: Indest is the one suing you

**Mel Pino**: Anne Bittinger is representing the county staff

**Mel Pino**: Fyi voicemail full

**Mel Pino**: They are doing it rush.

**Jeff Bergosh**: Awesome!!

**Mel Pino**: Check Doug's page.

**Mel Pino**: Check email

**Mel Pino**: Please call important. Very

### CONVERSATION ON 02-27-2020

**Jeff Bergosh**: In a conference will call u back

**Mel Pino**: Check voicemail when u can.

**Mel Pino**: Did you know they suspended Mike Lowery?

**Mel Pino**: And can we post that? :)

**Jeff Bergosh**: Didn't  know that

**Mel Pino**: Figures. Out of control.

### CONVERSATION ON 02-28-2020

**Jeff Bergosh**: Good for him!

**Jeff Bergosh**: Someone should ask him If he supports raising the MSBU to fund additional fire fighter salary increases and benefits. They asked me this during my interview and I told him flatly I do not support tax increases or an increase to the M S Beau I support more efficiency and growing the volunteers to offset the costs. I'm sure he went in there and told him he would raise taxes and that's why they supported him. But now someone needs to ask him

**Mel Pino**: I am so passed off that damn Owens sign is back up across the boat ramp

### CONVERSATION ON 02-29-2020

**Jeff Bergosh**: What is that?

**Jeff Bergosh**: Another 95 signed petitions came in.  Doug and Jonathan would kill for this LOL--puts new over 600 so far!

#Bergosh2020

**Mel Pino**: Fantastic!!!

### CONVERSATION ON 03-02-2020

**Mel Pino**: Check for a new comment

**Jeff Bergosh**: Got it just approved.  He makes good points!

**Mel Pino**: This isn't his first time through the "privatize ems" rodeo.

### CONVERSATION ON 03-03-2020

**Mel Pino**: Jeff what the he'll is going on with that first opt out being removed from the agenda?

**Mel Pino**: Something about remnant

**Mel Pino**: I can't tell if they just pulled a fast one. If it was pulled because it's not going be allowed or for timing.

**Jeff Bergosh**: I don't know?  Sounds fishy

**Mel Pino**: Can you find out?

**Mel Pino**: What the status is

**Mel Pino**: Debbie just left

**Mel Pino**: I want to find out if Doug got something done

**Jeff Bergosh**: I'll ask

**Mel Pino**: Thank you nobody knows what the hell is going on that I can see. 

**Mel Pino**: Staff said "we were requested to drop it." By whom?

**Mel Pino**: According the Horace the applicant pulled it because they realized they would be inviting a lawsuit due to the remnant on the land development code. A suit by whom? 

**Jeff Bergosh**: ?

**Mel Pino**: Jay Ingwell just read an absolute paean to stealing private property for the communal good

**Mel Pino**: Said that he believes the people of Beulah wish that they were in the sector plan. It was straight from jacquelin Rogers playbook

**Jeff Bergosh**: Disappointing but not entirely surprising

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Who wrote that Doug?

**Jeff Bergosh**: Does this mean he's finally going to publicly admit that he's a fucking dip shit that knows nothing and has been bullshitting his way through his job the last six years?

**Mel Pino**: Thats an Edler post she made Sunday night and Doug's response

**Mel Pino**: Yeah right

**Mel Pino**: Have you seen the shit he is throwing down?

**Jeff Bergosh**: Oh OK I got it wrong it was Edler

**Mel Pino**: Yes but Doug responded

**Jeff Bergosh**: No I'm not paying attention to any of that shit there's no benefit nor is there any value to me in watching them dance around with her fucking foil hats on

**Mel Pino**: Something obviously afoot but of course the Super Secret Double Probation Administration isn't saying

**Mel Pino**: It's pretty bad Jeff it is what he is doing to county staff :(

**Mel Pino**: Called the ones who left cancer that needed to be cut out

**Jeff Bergosh**: I expect no less from him

**Mel Pino**: He has been on a tirade against staff

**Jeff Bergosh**: People just need to get on the blogs and beat the shit out of them I can't do it right now though not for 5 1/2 more months

**Mel Pino**: JJ and I meet with SAO at 1 today

**Jeff Bergosh**: Awesome!!  Hopefully some forward progress!

**Jeff Bergosh**: How did the mtg go?

**Mel Pino**: VERY well. I have Kevin at an eye appt will call u after.

**Jeff Bergosh**: K

### CONVERSATION ON 03-05-2020

**Mel Pino**: So after he strong arms Horace then he throws him under the bus.

**Jeff Bergosh**: Yeah

**Jeff Bergosh**: Presto-chango 

**Mel Pino**: Jeff I checked and the role with that park is if that fly bt night contractor doesn't pay his subs then that risk transfer to the county

### CONVERSATION ON 03-06-2020

**Mel Pino**: Lutimothy got made the fleet chaplain at the yacht club

**Mel Pino**: Mike has been invited to sit the advisory counsel for UWF business

### CONVERSATION ON 03-08-2020

**Mel Pino**: Posted to your blog and Kevin brought it in. When you put up a blog give me a text because I'm always catching them late...I can't get notifications on them to work

**Jeff Bergosh**: Okay will do Mel!

### CONVERSATION ON 03-09-2020

**Mel Pino**: Please call when u can it's on the news

### CONVERSATION ON 03-10-2020

**Mel Pino**: Check email

**Jeff Bergosh**: I'll call u right back

**Mel Pino**: Gotta jump in the shower...you got 2 minutes? They are voting on the beach money at TDC today

**Mel Pino**: Pulled in a unanimous vote on tdt for beach access

**Jeff Bergosh**: Nice!!

**Mel Pino**: So glad you made time for that meeting Jeff. That Dept ran like a well oiled machine back then :(

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-11-2020

**Jeff Bergosh**: I'm in a meeting I'll call u after on my way back to my office

**Mel Pino**: OMG check rick's new post

**Jeff Bergosh**: Awesome

**Mel Pino**: Jeff I let chip know about the meeting...He said you should call the sheriff and then he'll ask him about it so he can attend

**Jeff Bergosh**: I'll do that 

**Jeff Bergosh**: Left him a voicemail

**Jeff Bergosh**: The endorsement won't move the needle on either race; Chip was going to win with or without it, Jonathan will get third place with it, and would have done the same without it 🙂

**Mel Pino**: I let chip and Ronnie know.

**Mel Pino**: Guess you weren't so stupid after all on the coronavirus

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 03-12-2020

**Mel Pino**: We will be late but we will be thwere

**Jeff Bergosh**: ?

**Mel Pino**: I was ui was up til 3 getting that doc in. Will be there for harassment. 

**Mel Pino**: Karen will be there for harassment pleas call her to podium

**Mel Pino**: Karen Stewart wood

**Mel Pino**: I sent the docs late late last night. Over a hundred pages redacted

**Jeff Bergosh**: In executive session

**Mel Pino**: Yes I forgot

**Mel Pino**: You can just glance at doc to confirm I sent the complaints in and other broken due process

**Mel Pino**: Karen Stewart wood is across from me on the other side. Blonde curly long hair. She is the one who put in sexual harassment on Rusty.

**Mel Pino**: Next to her is Rebecca brownfield she and her wife are the ones with special needs kids who was terminated with no notice recently

**Mel Pino**: You can call me also to say what's in the doc. I can say that in 30 seconds

**Mel Pino**: Why don't you social distance the fuck out of this county

**Mel Pino**: Underhill is commenting on FB right now that this presser is a train wreck. 

**Mel Pino**: I personally love that Laura Cole is leaning against a wall with a dumb smile while the Mic is out.

**Jeff Bergosh**: Yes--that should be fixed

**Mel Pino**: She cant. She has no fucking clue.

**Mel Pino**: Call Karen Stewart wood. She is the blonde with wavy hair across from me and one back.

**Mel Pino**: She is ready and wants to tell her broken due process.

**Jeff Bergosh**: Okay thx

**Mel Pino**: If you call me to clarify what I put out last night I will do it in 30 seconds and sit down

**Jeff Bergosh**: Where did that get sent

**Mel Pino**: Email

**Mel Pino**: Took me 12 hours last night to redact

**Mel Pino**: https://www.nytimes.com/2020/03/12/world/coronavirus-news.html

**Mel Pino**: https://www.nytimes.com/2020/03/12/world/coronavirus-news.html

**Mel Pino**: Sorry for double send

**Mel Pino**: Bill Hopkins posted this after Karen spoke.

**Jeff Bergosh**: He doesn't work here anymore so what does that mean?

**Mel Pino**: It means they should put a guard at public safety. That guys is a fucking lunatic and many employees have been worried about their safety per him for a long time. He has a damn arsenal and is completely wigged out. Can't get a job anywhere.

**Mel Pino**: He and his wife post photos of guns on Facebook at key moments.

**Mel Pino**: Oh, last thought. Edler was running around public safety today telling people that there are still people with no certs out on calls. And that's what is known as "game on"

**Mel Pino**: Go back to the discussion about the funding for merit protection board and you will see Alison advocating for him. When did the language get changed so complaints had to be closed? And why wasn't that attorney at the podium today?

### CONVERSATION ON 03-13-2020

**Jeff Bergosh**: LOL😎.  I'll make mine a double shaken not stirred

**Mel Pino**: Absolutely amazing response. Wow. I'm so glad this country is still capable of doing something like that.

**Jeff Bergosh**: I thought so too

**Jeff Bergosh**: Hope it all goes as planned

### CONVERSATION ON 03-14-2020

**Mel Pino**: https://lifehacker.com/dont-use-tor-right-now-if-youre-working-from-home-1842318515

**Mel Pino**: Jeff Kevin just sent me that to ask if you should pass along to make sure Bart knows about it

**Mel Pino**: Big vulnerability in tor right now

**Mel Pino**: Can you allow longerosts? Otherwise I will have to do three parts and it's all necesarry

**Mel Pino**: I will submit as three and if you can combine do it

**Mel Pino**: Okay all 3 parts in and text me when they are up because Rick is going to get with people

**Mel Pino**: If you can please get up tonight so it's not a Sunday morning time stamp

**Jeff Bergosh**: Just approved them

**Mel Pino**: Got it

### CONVERSATION ON 03-15-2020

**Mel Pino**: Gonna leave a message don't worry about picking up on a Sunday morning. Just don't want to lose track of the thought.

### CONVERSATION ON 03-16-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Left message no need for a call back

### CONVERSATION ON 03-17-2020

**Jeff Bergosh**: I just put up a blog post and Facebook post  on the subject of the beach, Spring Break, and whether or not It is past time to schedule a special meeting to discuss Taking more drastic measures to meet the current guidance regarding gatherings of 10 or less

**Jeff Bergosh**: The governor just announced that all bars and nightclubs will be closed for the next 30 days

**Mel Pino**: Thank God. Thank you for your leadership Jeff. Truly

**Mel Pino**: Fyi the life guard union over in Volusia is threatening walkout

**Jeff Bergosh**: Yes I saw that

**Mel Pino**: McDonald's closed all company owned sites.

**Mel Pino**: You guys should be social distancing. You are crammed together like sardines. Bad lesson.

**Mel Pino**: Mics aren't working

**Mel Pino**: Unless they are just transmitting to cameras

**Mel Pino**:  Left a message and then just found out that the elbow room CANNOT stay open hahahaha

**Jeff Bergosh**: LOL

**Jeff Bergosh**: No more crack a Roni and cheese😎👍

**Mel Pino**: Laughed my ass off.

**Jeff Bergosh**: But in all seriousness they do serve food there so they shouldn't have to close right I mean you're just joking right?

**Jeff Bergosh**: Or are they considered a bar because they have a 2COP consumption on premise license

**Mel Pino**: No. The definition of restaurant is food 50 percent of sales

**Mel Pino**: David got it from Alison.

**Mel Pino**: He's going to have to close but he will probably try to cook the books and everybody will just let him.

### CONVERSATION ON 03-19-2020

**Jeff Bergosh**: Special meeting tomorrow, tentatively, at 11:00

**Mel Pino**: Call when you can. I need to convey a phone call

**Jeff Bergosh**: Will do

**Mel Pino**: Rick Scott calling to shut them down

**Mel Pino**: Well sort of.

### CONVERSATION ON 03-20-2020

**Mel Pino**: New York State in lockdown. All workers except essential vital services told to stay home. We aren't getting help from DeSantis. It's in your hands, Jeff.

**Mel Pino**: And what I was trying to get across is that you aren't going to get the data on cases because it doesn't exist yet. That was the whole point of it. The data on local hospitals you should be able to get, but they aren't going to cough that up easily.

**Mel Pino**: He is spot on Jeff. The decision has to be made without data. We can't wait that long.

**Mel Pino**: This is what I was trying to say. They are not ready. That is why we cannot deal with this influx of population.

**Mel Pino**: Ask her what exactly the screening process is

**Mel Pino**: What questions are they asking and who gets to testy from the answers

**Mel Pino**: This is the problem they don't have the data because the federal government tried to stall and cover up. It's not their fault. But we can't wait.

**Mel Pino**: He is looking for the body's help to get those parks closed down to car traffic

**Mel Pino**: Banks in Oregon are closing lobbies and restricting drive up

**Mel Pino**: This is pathetic. Forcing the lifeguards to deal with this situation.

**Mel Pino**: Pathetic.

**Mel Pino**: God I hope he is swinging this right

**Mel Pino**: Thank God for your leadership today. All of you. 

**Jeff Bergosh**: 👍

**Mel Pino**: https://time.com/5805953/home-covid-19-test-everlywell/

**Mel Pino**: La county gave up on containment :( they are advising doctors to test only if they think treatment will do any good.:(

**Mel Pino**: A pence staffer has it.

### CONVERSATION ON 03-21-2020

**Mel Pino**: https://www.sciencemag.org/news/2020/03/new-blood-tests-antibodies-could-show-true-scale-coronavirus-pandemic

**Mel Pino**: FEMA is taking over the corona task Force and the generals are wrestling command away from Trump. Never thought I could find something like that hopeful.

**Mel Pino**: New York changed testing to only the critically ill

### CONVERSATION ON 03-22-2020

**Mel Pino**: https://techcrunch.com/2020/03/19/open-source-project-spins-up-3d-printed-ventilator-validation-prototype-in-just-one-week/

**Mel Pino**: Please have Sally get this out to the hospital admins so they can get in the pipeline as quickly as possible

**Jeff Bergosh**: Interesting will do

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/03/test-results-starting-to-trickle-in-at.html?m=1

New Escambia county case has been announced today to county staff

**Mel Pino**: Thank you

**Mel Pino**: Jeff we really should be shutting down more to get in front of this. With one more confirmed case that can be the reason. We cannot wait until the situation is dire to do that. We would be in okay shape if we took steps now.

**Mel Pino**: https://www.miamiherald.com/opinion/editorials/article241403236.html

### CONVERSATION ON 03-23-2020

**Mel Pino**: Medical testing group out of Louisiana with office at south paradox releasing a 4 second finger prick test for covid! They have sent to white house and are distributing to local hospitals! Also about ready to releas an 8 hour hand sanitizer

**Mel Pino**: I asked Jeff Hinkle and Scott Miller how many antibodies it screens for.

**Mel Pino**: Mike thinks only two but it's still an important advance

**Jeff Bergosh**: That's great news!

**Mel Pino**: Italy's numbers dropped on the two days since the lockdown. Too early for a trend but the first hope they have had.

**Mel Pino**: Uk on lockdown

### CONVERSATION ON 03-24-2020

**Mel Pino**: Jeff are you live? I got 3 notifications but can't see it

**Jeff Bergosh**: No, my phone is acting up

### CONVERSATION ON 03-26-2020

**Mel Pino**: Okay Mike just saw this published. Keep in mind this is from days ago..it was already happening. Not posting online just sending for awareness

**Mel Pino**: Our numbers are probably higher than Spain because Spain is using the WHO model and testing the dead. CDC won't recommend that.

### CONVERSATION ON 03-27-2020

**Mel Pino**: https://www.mediaite.com/trump/fox-news-doctor-rejects-trump-dismissing-need-for-ventilators-to-hannity-we-need-as-many-as-we-can-possibly-get/

**Mel Pino**: https://www.rawstory.com/2020/03/expert-epidemiologist-explains-why-dr-deborah-birxs-coronavirus-analysis-might-be-way-off-base/

**Mel Pino**: DeSantis closes vacation rentals and orders check points

**Mel Pino**: https://www.miamiherald.com/news/coronavirus/article241487396.html

**Mel Pino**: https://www.washingtonpost.com/politics/trump-raises-prospect-of-ordering-gm-ford-to-manufacture-ventilators/2020/03/27/92f82db6-7043-11ea-aa80-c2470c6b2034_story.html

**Mel Pino**: https://www.washingtonpost.com/politics/2020/03/27/alabama-governor-wont-order-shelter-in-place-because-we-are-not-california-by-population-its-worse/

**Mel Pino**: Check those numbers

### CONVERSATION ON 03-28-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: No worries left a message.

### CONVERSATION ON 03-29-2020

**Mel Pino**: https://www.state.gov/the-united-states-announces-assistance-to-combat-the-novel-coronavirus/

**Mel Pino**: Trump sent 17.8 tons of PPE out of our federal stockpile to China.

### CONVERSATION ON 03-30-2020

**Mel Pino**: Jeff you should get with Grover on how to handle the messaging if Josh Rothman calls you. It so tricky because we don't want Trump backlash on federal aid but it might apply some pressure to get us PPE

**Mel Pino**: People hate the new Yorker here but it *might* help to get some exposure

**Mel Pino**: https://www.nytimes.com/2020/03/30/us/coronavirus-prisons-jails.html

### CONVERSATION ON 03-31-2020

**Mel Pino**: That email string is serious. You think that was annoying? Wait til the death rate sets in here. 

**Mel Pino**: Don't like this late night text? Wait til they are rolling into your phone all night long. PLEASE get in front of this.

**Mel Pino**: And I am sending that to everybody. But Doug obviously

**Mel Pino**: Trump just acknowledged that this is gonna be a lot worse than he thought. Birx gave a modest number of 100 to 200 thousand dead IF the entire country shelters at home .

**Mel Pino**: If irresponsible states like ours continue to let people run amok, who knows what the numbers will be.

**Mel Pino**: Let's do it right here.

**Mel Pino**: I think Trump is gonna flip on DeSantis, throw him under the bus, and demand he shut the state down.

### CONVERSATION ON 04-01-2020

**Mel Pino**: Thank God. I will shut up now.

**Jeff Bergosh**: Saw it

**Mel Pino**: Im sorry I have been so brutal I've just known all this for 3 weeks Jeff.

**Jeff Bergosh**: 👍

**Mel Pino**: Jeff I am sending this message to everybody. Please ask Steven to switch this meeting to online . People are concerned about all of you guys staying well but I am particularly  worried about lumon health as he is exhausted

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Thats ok left a message

### CONVERSATION ON 04-02-2020

**Mel Pino**: https://www.reuters.com/article/us-health-coronavirus-new-orleans-idUSKBN21K1B0

**Mel Pino**: Im not posting that publicly. 

**Mel Pino**: Well of course this text is public but I just meant I'm not headlining it on facebook

**Jeff Bergosh**: Being in good shape, now more than ever appears to be extra protection!

**Mel Pino**: Yes but Jeff please encourage Steven to pull this thing online. Nobody is going to prosecute Escambia county for taking care of its people. That agenda was the height of absurdity to begin with.

**Mel Pino**: BAM. Thank you :)

**Mel Pino**: You do get that those two were high school friends and it was another fake national search.

**Mel Pino**: Don't know about the guy.

**Mel Pino**: And this is exactly why I said to come in with sound legal advice from somewhere else. Yet again a bunch of talk talk with no solid answers from admin ad legal

**Mel Pino**: This should not be you guys figuring this out in real time.

**Mel Pino**: Happy birthday!!!!!!!!!

**Jeff Bergosh**: Thanks!

**Mel Pino**: So Randy Cudd came up with the bingo statute during the meeting but you county attorney can't. 849.0931

### CONVERSATION ON 04-03-2020

**Mel Pino**: Jeff great news. Both Grover and the other possible case were negative. Thank God.

### CONVERSATION ON 04-05-2020

**Mel Pino**: https://www.sciencenews.org/article/coronavirus-covid-19-breathing-talking-enough-spread-airborne

**Mel Pino**: The reason Kevin took off from that horrid press conference. This has been known for a long time. The CDC was refusing to acknowledge it.

### CONVERSATION ON 04-06-2020

**Mel Pino**: Kevin brought your blog in and I posted a comment

**Jeff Bergosh**: Thx

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: https://www.nytimes.com/interactive/2020/us/coronavirus-us-cases.html

**Mel Pino**: Scroll down to where you see the yellow, orange, and red bars. Those are what show accelaration

**Mel Pino**: So Florida only had one yellow band, as opposed to new York having 5

**Mel Pino**: We then had more orange bandstand they did, which was good.

**Mel Pino**: But unfortunately we then reached our red band of acceleration first. ;(

**Mel Pino**: And we are only one or two behind them already ;(

**Mel Pino**: So although are numbers are way lower (because we are barely in the process), or acceleration is already faster).

**Mel Pino**: https://covid19.healthdata.org/

**Mel Pino**: Please take a look at these latest projections. And keep in mind these predictions are based on total,  100 percent compliance, which we aren't doing, and what DeSantis did implement came too late

**Mel Pino**: So it will be worse here than these projections. Hit the drop down arrow at the top next to "United States" projections and you can compare state by state. Compare new York and florida

**Mel Pino**: And remember that is BEST case for Florida, if everything locked down and everybody stayed home. Which is not and will not happen under our governor.

**Mel Pino**: https://www.tampabay.com/investigations/2020/04/04/florida-saw-a-pandemic-coming-and-prepared-then-state-leaders-started-to-cut/

**Mel Pino**: Last one. That's the piece on how underfunded and manned our DOH and other agencies are.

**Mel Pino**: Oh, and they need money bad. REAL bad. Think on that per other contexts.

**Mel Pino**: Boris Johnson moved to icu

**Mel Pino**: Goddamn it Doug just put up a homemade graph showing people the spike is over. Check my tag or his homepage. I put it up against the IHME

### CONVERSATION ON 04-07-2020

**Mel Pino**: https://www.nytimes.com/interactive/2020/04/03/us/coronavirus-county-epidemics.html

**Mel Pino**: Good morning. According to that model the chance for Escambia county experience an epidemic are 100 percent. 

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2020/04/covid-19-in-escambia-county-ventilators.html?m=1

Here's what I'm watching:  Ventilators locally and the percentage available for use by patients.  We've gone from 86% available Saturday Morning down to 74% three days later------and we added an additional 14 ventilators to our total in the 3 hospitals locally.  This, I believe, is the important metric we need to be watching daily here locally.  This is the canary in the coal mine........

**Mel Pino**: Thank you for the heads up!

**Mel Pino**: Kevin pulling in

**Mel Pino**: Posted

**Mel Pino**: Hey have a bunch of info give me a call when u can

**Mel Pino**: https://www.nytimes.com/interactive/2020/us/coronavirus-us-cases.html

**Mel Pino**: Florida now neck and neck with new York per acceleration and 7th in total cases. 

**Mel Pino**: Another one of those emails circulated and it's big increases again. Don't pay any attention to the cdc's politicking. Or this doctor group claiming there is great information during the president's briefing. 
Snort. 

### CONVERSATION ON 04-08-2020

**Mel Pino**: Underhill just sent out another mass email that is a survey on opening beaches back up to locals.

**Mel Pino**: Sanders just dropped out

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Follow up to my voicemail. Maybe rather than worrying about how she can get even more reckless by agitating to open our beaches with a hospital administrator sitting cross the table, Janice could focus on the fact that our jail workers don't have masks and aren't being allowed to social distance. Or that fleet, waste, facilities, and roads are getting increasingly nervous about their unsafe working conditions. Or the fact that Escambia county scored a big fat C on preparation nationally and wouldn't have gotten that if it weren't for Grover or lumon. Or that if the bus drivers had any sense they would go on strike. Or that she is lining up more lawsuits against the county. Or the a huge number of people are looking at her tenure recognizing that Janice does not care about the well being of her staff or the citizens of Escambia, and is actually so proudly ignorant and I'll informed she thinks this is still a hoax. Perhaps you could purchase her a TV out of discretionary.

### CONVERSATION ON 04-09-2020

**Mel Pino**: Posted a comment.

### CONVERSATION ON 04-10-2020

**Mel Pino**: Thank God finally the voice of reason. Thank u

**Mel Pino**: Posted

**Mel Pino**: Good press in PNJ. Be gracious about it! :)

**Mel Pino**: You did the right thing today Jeff. People aren't dumb. They see what's going on. And people won't forget who put information out there and who tried to hide it.

**Jeff Bergosh**: Thx!

**Mel Pino**: Just like always. Ain't nothin different now than I've been saying these offices act for 2 years. It's just in a context now where it matters enough that more people are looking and care. 

**Mel Pino**: People are really thirsty for informationa DNA very grateful for it. 

### CONVERSATION ON 04-13-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 04-15-2020

**Mel Pino**: Jeff those rooms weren't even donated by innisfee. They were purchase by national health associations and societies for healthcare workers to use.

**Jeff Bergosh**: Wow

**Mel Pino**: I sent the emails to the press.

**Mel Pino**: Just posted the flyer.

**Jeff Bergosh**: It's all over PNJ now

**Mel Pino**: Hahaha that was quick

**Mel Pino**: Rick also reported the nursing home so that's p bic now. Good day for transparency whether Janice wants it or not.

### CONVERSATION ON 04-17-2020

**Mel Pino**: Jeff here is covid compared to other common deaths. This is what It looks like when you do not use logarithmic scale. That scale makes it easier to tack because it takes the power of 10 out because when you are dealing with things on such a large scale in a short period of time it makes it easier to fit when it's bending. Take out the logarithmic scale and it looks like a roller coaster headed straight up and it's BS about how it compares to other deaths. THIS is why you do not open yet. We have got to give our hospitals a fighting chance against this when it hits here.

### CONVERSATION ON 04-18-2020

**Mel Pino**: Jeff call as soon as you can. Important for campaign

**Mel Pino**: Needs a blog

**Mel Pino**: Jeff listen to my message when you have a chance

### CONVERSATION ON 04-20-2020

**Mel Pino**: Jeff hang in there and thank you for providing the transparency. In eight days it may be very obvious this is a bad idea. In the meantime yes just keep listening to all sides.

**Mel Pino**: Also I won't go into it too much because I know you are on the ecw wagon but let me just say Doug is getting the shit beat out of him there daily

**Mel Pino**: On the beach and covid. I mean, it's bad. Long time people turning on him and jar can't do a damn thing to stop it...it's a deluge

**Mel Pino**: Yep it just got so bad Jacqueline had no choice but to close another string down. She can't contain it any more.

**Jeff Bergosh**: LOL glad he's gettin' some

**Jeff Bergosh**: I'm 51 days "clean" from that shit site

**Mel Pino**: Not encouraging you to go there just trust me it's so bad he had to address "this angry little band of women" and that just got him pummeled harder

**Jeff Bergosh**: LOL

**Mel Pino**: I have been laughing til I'm crying it's so wonderful to see and I don't have to do a thing :)

**Jeff Bergosh**: LOL

**Mel Pino**: They're calling him out as a drunk crazy liar. Literally

**Jeff Bergosh**: 😂😂😂😂😂

**Jeff Bergosh**: Ha ha ha

**Mel Pino**: Were also beating the shit out of him on what's happening Pensacola which has over 6000 and the moderator is kicking off covid deniers

**Jeff Bergosh**: That's great

**Mel Pino**: https://owensdistrict1.com/we-deserve-better-bridges/

**Mel Pino**: Fyi Jim fax is being an asshole claiming you are hiding from you own post. I told him he was ridiculous and called him an asshole because he is being an asshole

### CONVERSATION ON 04-21-2020

**Mel Pino**: Hey before I forget io did check in on that thing last Thursday through two channels and it was a nothing Burger. 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: That's what I figured

**Mel Pino**: Jeff call me later when you can because I have to talk to you about the nursing homes.

**Jeff Bergosh**: Okay I will

**Jeff Bergosh**: On my lunch break

**Mel Pino**: The employee death in the nursing home is out now. Rick's blog.

**Mel Pino**: Cropped call me back if u have time

**Mel Pino**: You would not believe what attorney has done this time.

### CONVERSATION ON 04-22-2020

**Mel Pino**: Fucking unbelievable. Even our hospital administrators will sell out for money. Just pathetic.

**Mel Pino**: So how does it work that Faulkner knows we don't have enough testing but he is still advocating for opening. What a schizo mess of logic.

**Mel Pino**: Jeff I can't comment on Facebook live videos (bug)m can you PLEASE ask the followiong

**Mel Pino**: Will the hospitals still be on board for this if numbers continue to increase int the next week?

**Mel Pino**: What if we are headed into a spike? What if there are bigger numbers of deaths and infections before the 28th? Will they feel the same way in the hospitals?

**Mel Pino**: What in the HELL does code have to do with this

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Hey Jeff having a bit to think about your coffee: they are counting on them on the regular now and playing them against you.

**Mel Pino**: You need to drop a surprise and rattle their cages or maybe just kick one or two off at the last minute next time so they don't get their press

**Mel Pino**: Do NOT take their rec for an ethics perso. We can hook you up with somebody stellar I bet

**Mel Pino**: They used your coffee to leak that letter the day before the Santa Rosa bocc complete with fake impromptu touches by sam

**Mel Pino**: Jeff sorry to bug you again but call when you can. Very high importance

**Jeff Bergosh**: Okay will do

**Mel Pino**: Wth Jeff Trump just said he told the governor of Georgia to walk back his opening

**Mel Pino**: I just posted the letter online and blasted the admins. Call when u can.

**Mel Pino**: Reports people in perdido are crashing through barriers don't know if it's true

**Mel Pino**: Did we lose at large positions off the planning board and BOA? If so why?

**Mel Pino**: Did Bill stromquist leave??

**Mel Pino**: I dont Walker Wilson stepped off.  Those are the two at large.  On the planning board it is the new Gulf power guy (past exec) can't think of the name is it Gary Ammons? But ten to one Reid rushing stepped off .

**Mel Pino**: Unless it's just time to vote it again. Sorry didn't think of that. I just cant believe that all this continues to happen in the middle of a plague.

### CONVERSATION ON 04-23-2020

**Mel Pino**: Governor of georgia walking back in response to trump

**Mel Pino**: Sorry not quite yet but repulican rep Doug Collins is applying the screws for Trump so it will come soone

**Jeff Bergosh**: Did u see this one yet???

**Mel Pino**: Yes that is part of what oi wanted to talk to you about at lunch :)

**Mel Pino**: AND that party on river road

**Mel Pino**: We have been taking that viral all day

**Mel Pino**: Jeff who sent that email?

**Mel Pino**: Or Facebook post

**Mel Pino**: W.T.F. with th( press conference. She is so fucking out of control

### CONVERSATION ON 04-24-2020

**Mel Pino**: https://m.hugelol.com/lol/668707

### CONVERSATION ON 04-26-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: You absolutely would not believe the email I am reading pertaining to rescue 1 procurement. 

**Mel Pino**: Call when u can. Important.

### CONVERSATION ON 04-27-2020

**Mel Pino**: Bill stromquist the at large on BOA passed away.

**Jeff Bergosh**: That's sad

**Jeff Bergosh**: Nice guy

**Mel Pino**: Fyi today was Stephan's last day with the county. Pam has loaned someone from the clerk of court to run the budget at the county temporarily named Sharon Harrell.

### CONVERSATION ON 04-28-2020

**Mel Pino**: Check email. I just laid down basic questions that Everybody should be asking the administrators. It doesn't matter the email is 3 hours before the meetingn because everybody on the dais should have already been prepared to get answers to these questions IMO.

**Mel Pino**: Posted

**Mel Pino**: Yep she cut the comment off at 330 so mine and I'm sure others won't be in there. Was this posted somewhere? I did a follow up comment

**Mel Pino**: New research from Columbia University suggests immunity from COVID-19 is short lived. 
https://www.technologyreview.com/2020/04/27/1000569/how-long-are-people-immune-to-covid-19/

If this proves to be true, a vaccine won't help much if at all. And the better short term strategy is getting people used to having to quickly mobilize into shelter in place, and wear masks for some length of time, and be subjected to regular rapid testing for successful monitoring and tracing (if vaccines or anti-virals prove to be dead ends). No worries. I'm sure Escambia administration and EOC is working on that.

**Mel Pino**: From a veteran nurse with mega specialities

**Mel Pino**: The number one thing the hospital workers are seething about is why no clinicians have been consulted. Only bean counters with no medical degrees

**Mel Pino**: Also the hospital staff are not being screened.

**Mel Pino**: So people who stayed at home PER THE CURRENT GOVERNOR ADVICE don't get to participate in comment.

**Mel Pino**: There was NO pubic forum ability for something off the agenda unless you are there in person. Unbelievable.

**Mel Pino**: Think this commentary and camera time is going to be biased much? SMH.

**Mel Pino**: Glad this is backfiring on you'll wth a Doug fest.

**Mel Pino**: This is the asshole creeping on my house and posting against you for doug

**Jeff Bergosh**: Yeah I figured 

**Mel Pino**: Nicely played on Barry handing over the meeting to Doug. Smh.

**Mel Pino**: Of course they aren't going to maintain them

**Mel Pino**: It's not real anyway, so why bother.

**Mel Pino**: Jesus god this is such a waste of time and looks so stupid. Just have him make the damn motion and vote and be done with it

**Mel Pino**: Blah blah blah blah blah

**Mel Pino**: Lays their infant in the sand

**Mel Pino**: Seriously ask hm for a motion. He has it ready anyway this is torture

**Mel Pino**: This is such am embarrassing joke. I'm done reporting this

**Mel Pino**: What a waste of time.

**Mel Pino**: He is lying through his teeth

**Mel Pino**: Making shit uo

**Mel Pino**: WOW way to split that hair.

**Mel Pino**: Hahahahah of course he won't answer

**Mel Pino**: Because we are not descending we are ascending and he just admitted it

**Mel Pino**: That was literally the most pathetic dog and pony show I have ever seen orchestrated on that dais. Thank God you were not part of that end shit show.

**Jeff Bergosh**: Yep

**Mel Pino**: Is this the little kids sports???????????

**Mel Pino**: Nooooooooo

**Mel Pino**: Honestly god help us all. I can't even watch this. I can't. This is a horror show. We are so lost.

### CONVERSATION ON 04-29-2020

**Mel Pino**: https://www.tampabay.com/news/health/2020/04/29/florida-medical-examiners-were-releasing-coronavirus-death-data-the-state-made-them-stop/

### CONVERSATION ON 04-30-2020

**Mel Pino**: Check Kevin's request for the drive in!!

**Mel Pino**: https://thehill.com/policy/international/russia/495474-russias-prime-minister-has-coronavirus-report

### CONVERSATION ON 05-01-2020

**Jeff Bergosh**: In a meeting, I'll call you after

**Mel Pino**: Left a voicemail about the press conference at 9 that you will want to hear

### CONVERSATION ON 05-02-2020

**Mel Pino**: Oh my god Jeff. I don't like to bug you on weekends but PLEASE call me on this reorg she has on agenda.

**Mel Pino**: There isn't a lot of time

**Mel Pino**: Jeff please call me after tennis. This is a disaster.

**Mel Pino**: https://www.businessinsider.com/florida-nursing-homes-have-accounted-for-1-in-3-deaths-2020-5

**Mel Pino**: Great timing on Janice's after hours opening announce yesterday that  the county is being Monday....which some upper level county staff didn't even know about prior to the social media annoiunce. Trump would be so proud.

**Mel Pino**: https://www.msn.com/en-us/news/us/7345-coronavirus-cases-in-alabama-up-277-overnight-mobile-adds-68-new-cases/ar-BB13vMZn

**Mel Pino**: Think anybody might be here from mobile for the beach this weekend?

### CONVERSATION ON 05-03-2020

**Mel Pino**: So it was interesting  DeSantis's remark in his presser today that "the hospitals had to demonstrate they weren't going to come running back to the state for PPE" if they opened back up for electives. Maybe that's why the administrators have been hording it and our hospital workers are going without proper protection.

**Mel Pino**: https://www.alreporter.com/mapping-coronavirus-in-alabama/

**Mel Pino**: Mobile is exploding.

### CONVERSATION ON 05-04-2020

**Jeff Bergosh**: Nursing homes--like Pensacola

**Mel Pino**: Stating "nursing homes" like a talisman will not contain the problem to nursing homes.

**Mel Pino**: There are neighbors of southern Oaks documenting the workers coming and going from eh facility--arriving, going to lunch and coming back, and going home--in the same PPE.

**Mel Pino**: And the National Guard is not there. At least nobody has seen them, so it's an awfully stealth operation.

**Mel Pino**: I just got confirmation in writing that the checklist for PRRS includes the PIO reviewing before they are released.

**Mel Pino**: Putting together this PRR for money spent on hires and promotions.

**Mel Pino**: This is a fantastic article explaining why the models don't fit reality: https://nymag.com/intelligencer/2020/05/what-the-coronavirus-models-cant-see.html

**Mel Pino**: https://www.nytimes.com/2020/05/04/us/coronavirus-updates.html

**Mel Pino**: So now we are getting to the part where they can't fake it any more

**Mel Pino**: Mike is on the team that developed this. 

https://www.pwc.com/us/en/products/check-in.html

### CONVERSATION ON 05-05-2020

**Jeff Bergosh**: Doug’s secretary raised a whopping............wait for it................
Drumroll....................................$250
In his April report.    Conor MacGregor would say “That’s It!?!”

**Mel Pino**: Hahahaha omg thank u I am putting that under my post about the ethics complaint that is AWESOME

**Mel Pino**: Yeah!!!!!!!!!!!!

**Jeff Bergosh**: LOL

**Mel Pino**: Done. On my page, David's page gonna add it to the post on free speech, and it's pending approval on what's happening pensacola

**Jeff Bergosh**: Where is Ch 3?

### CONVERSATION ON 05-06-2020

**Mel Pino**: Infection tied to blood type

https://www.livescience.com/why-covid-19-coronavirus-deadly-for-some-people.html

**Mel Pino**: Hey on my voicemail ji$m little got it wrong. Natch.

**Mel Pino**: The letter says MAY lose license. Not will. Please note that this sets up the people charged as if they are all guilty even though the letter makes clear that there is no admission of guilt. So why is the county accepting a letter of reprimand prior to any outcome? Did DOH provide an outcome that isn't being made public?

**Mel Pino**: Hey I feel a ot better about that thing you guys are signing as I had a chance to talk with JJ about it and he explained it. One less thing on my worry plate :) he said pro forma.

**Mel Pino**: It does get them out of having to prove anything though so the county isn't the only one getting off the hook. Past ems heads say it is ridiculous how the county has nobody left who knows how DOH plays. But I am not worry about the deal like I was.

**Mel Pino**: Ought to be a fun meeting tomorrow.

**Mel Pino**: He has been rolling all day.

**Jeff Bergosh**: LOL he's a nut

**Mel Pino**: They are in total fucking meltdown and he is a mess. I HATE it that we can't come to the meeting. How is the fire?

**Jeff Bergosh**: 20 Escambia FF on it, 4 Florida Fire Service bulldozers clearing fire breaks.  It hasn't threatened homes- so we have dodged a bullet

**Mel Pino**: Thank god

### CONVERSATION ON 05-07-2020

**Mel Pino**: Jeff so sorry about the fire. Hope it continues to be manageable :(

**Jeff Bergosh**: Pop up drive in owner

**Mel Pino**: Nice to know the commissioners don't have any better idea of how stuff gets to the backup than the citizens do. 

**Mel Pino**: This is a new low. You have got to be kidding me. He is such a liar. And making fun of people in masks because they braved a pandemic. Only 6 people this time? How about last time. He lied to you guys, he lied to the residents, and he is lying about so much else. It needs to be stopped and investigated :(

**Mel Pino**: Fyi I have spoken with all these folks and they are ready to sue the county. They are not bluffing.

**Mel Pino**: Hahahahahahahahaha

**Mel Pino**: What. The. FUCK.

**Mel Pino**: What is this 538k? And they will sue the county.

**Mel Pino**: It was NOT the county's choice to take it. 

**Mel Pino**: Alison doing Doug's business for him again.

**Mel Pino**: And here we go. The truth finally comes out

**Mel Pino**: Alison and Jack fucked them

**Mel Pino**: And they did it ALL the time this is what I have been trying to say.

**Mel Pino**: Thank you

**Mel Pino**: More like the very first time Doug and Jack did a deal against the rest of the board

**Mel Pino**: With Alison help

**Mel Pino**: Even better Colby was in on it. Perfect

**Mel Pino**: Oh joy will straighten it out

**Mel Pino**: Maybe somebody could ask her why she is giving it to chips when she told me that she new he wasn't a great card but that she wasn't holding a very good hand.

**Jeff Bergosh**: LOL

**Mel Pino**: Is that why he doesn't get a raise? He just gets diplomatic immunity in return.

**Jeff Bergosh**: Diplomatic immunity and witness protection

**Mel Pino**: Hahahahaa

**Jeff Bergosh**: 😁

**Mel Pino**: Wait a second. Did she just say that there is room in chip's budget? I thought she said he wasn't getting a raise. What is coming out of China's budget.

**Mel Pino**: Where is the backup? Why under separate cover? More and more does not get put on the agenda.

**Mel Pino**: OH MY GOD we are giving navy federal another 1 million in economic incentives??????

**Jeff Bergosh**: $500Million annual payroll and $1.2 Billion invested in facility construction

**Jeff Bergosh**: So yes

**Mel Pino**: I was talking about it in terms of that whole conversation you guys had about more incentives. I didn't realize this was for past deal because Janice does such a shit job with backup

**Jeff Bergosh**: Oh, okay

**Jeff Bergosh**: 👍

**Mel Pino**: You literally can't figure out what is going on with a lot of the agenda

**Jeff Bergosh**: I know.......this meeting is all over the place

**Jeff Bergosh**: Bender just voted against my discretionary allocation.......odd

**Mel Pino**: I don't understand what just happened. 

**Mel Pino**: Oh on William banks

**Jeff Bergosh**: Yeah

**Jeff Bergosh**: It still passed but...... passive aggressive

**Mel Pino**: Wtf? 

**Jeff Bergosh**: Right?!?

**Mel Pino**: I didn't understand because Steven said "3 0 with Robert in dissent"

**Mel Pino**: Then it should have been 4 1

**Jeff Bergosh**: 3-1

**Jeff Bergosh**: Doug disappeared

**Mel Pino**: Doug was off the dais? He hates cadicllac

**Jeff Bergosh**: Disappearing Doug

**Jeff Bergosh**: He was busy with Jonathan

**Mel Pino**: Maybe Robert thinks Cadillac is scamming the money but he should say so

**Mel Pino**: Sharpening crayons.

**Jeff Bergosh**: LOL

**Mel Pino**: Do you really not know?

**Jeff Bergosh**: Nope

**Mel Pino**: Gene valentino

**Mel Pino**: He went down the pole on a facilities visit and broke his arm

**Mel Pino**: I shit you not

**Jeff Bergosh**: Wow-- I didn't know that

**Jeff Bergosh**: LOL

**Mel Pino**: Yep

**Jeff Bergosh**: I bet that hurt like hell

**Jeff Bergosh**: Physically and pride-wise

**Mel Pino**: Almost as bad as the time he was supposed to come in on a helicopter and it didn't happen

**Jeff Bergosh**: D'oh

**Mel Pino**: Seriously lots of drama back then

**Jeff Bergosh**: I guess so

**Mel Pino**: Quintet road no backup

**Mel Pino**: THANK YOU Jeff. God that needed to be said.

**Jeff Bergosh**: 👍

**Mel Pino**: Because nobody with a brain in their head care about their damn hair  while plaque buildup correlates to heart disease. I understand what you are getting at but to equate a shave with a teeth cleaning is just no.

**Mel Pino**: They had it teed up to send an email announce when the vote went through on caps and Wes. Went out county wide during the meeting. This is a response I got from a friend.

**Mel Pino**: Who in the fuck is he even putting this show on for? Jonathan?

**Jeff Bergosh**: Yes

### CONVERSATION ON 05-08-2020

**Mel Pino**: I cc'd you on a request for shade meeting and other transcripts and documents.

**Mel Pino**: I cc'd you on a request for shade meeting and other transcripts and documents.

**Mel Pino**: February 18 2014 Alison says there was a second of 2 shade meetings on county taking receivership.

**Mel Pino**: I also asked for documents on whatever bullshit happened after that with "Jack's decision" to hold onto the sewer.

**Mel Pino**: Whether it is true gene wanted to keep it or no it is clear that lumon and Steven did NOT know that had happened because if they had Alison wouldn't have been crawling out of her skin. She got busted and this is going to get bad.

**Mel Pino**: Ne York Times wrestled public records out of the state of Florida. Medical examiner reports show in part how data is getting manipulated to make it look like we are weeks beyond our worst: https://www.nytimes.com/2020/05/08/us/coronavirus-florida-medical-examiner-records.html

### CONVERSATION ON 05-09-2020

**Mel Pino**: https://www.tampabay.com/news/health/2020/05/08/florida-adds-71-coronavirus-deaths-as-state-prepares-for-first-weekend-of-reopening/

**Mel Pino**: https://www.pnj.com/story/opinion/2020/05/08/editorial-desantis-still-hiding-data-covid-19-deaths/5181080002/

**Mel Pino**: It is a very real possibility that at some point the bocc and mayor's office are going to be visited with the fallout from these homicidally reckless and unethical decisions. Thats why I keep sending these. Not to hit people over the head but to try to pierce through the Foxthink that is running this state right now.

**Mel Pino**: https://apnews.com/9c4d5284ba4769d3b98aa05232201f88

**Mel Pino**: Im not a tin foil hat Jeff. This thing is getting ready to blow up. Naples slamming shut it's beaches. FDA and CDC heads see quarantining

**Mel Pino**: https://sports.yahoo.com/put-on-a-mask-dana-white-and-tighten-up-your-act-before-the-coronavirus-spreads-165436490.html

**Mel Pino**: That's for Larry's next text.

### CONVERSATION ON 05-10-2020

**Mel Pino**: Jeff I started a string on the drivethrough and am going to try to get a bunch of share outs. Michael is on there. Can you guys make a showing even for a bit so you can wave to people etc. Awesome line up with grease and wizard of oz and dirty dancing.

**Mel Pino**: If you can come on that string and tell people which one you and Sally are looking forward to. I will share it to your page also

**Mel Pino**: I just tagged a crap ton of people to that string. I can't share to your page sent the link to your Pm you should check string to see if you want to make an appearance there :)

**Jeff Bergosh**: Will do

### CONVERSATION ON 05-11-2020

**Mel Pino**: Jeff THE most important thing is to tell Janice to put a halt to that damn project today. Full stop. Because Doug will whip this thing into a lather it's always the way he works...he wil have 3 roads torn up by 5 today

### CONVERSATION ON 05-12-2020

**Mel Pino**: Jeff I hadn't seen your follow up that you had all the transcripts. THANK YOU. Sounds like the county might be able to enact that court decision after all. Woops.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Janice disagrees......................

**Mel Pino**: Oh I have no doubt. I'm writing a comment for your  blog. She and Alison Rogers are full of shit and driving this county into the ground and you can print that. Nothing I haven't been saying publicly for weeks. 

**Mel Pino**: I Cant believe that about the ban. 10 to 1 Underhill has something to do with it. He usually does with Janice.

### CONVERSATION ON 05-13-2020

**Mel Pino**: Excellent, balanced article on De Santis decisions so far.   https://www.washingtonpost.com/lifestyle/does-florida-gov-ron-desantis-know-what-hes-doing-were-about-to-find-out/2020/05/08/8bf6537c-9135-11ea-a9c0-73b93422d691_story.html

**Jeff Bergosh**: Got my poll back today Mel.  Keep this between us.  



**Mel Pino**: Thank God. 

**Jeff Bergosh**: 😎👍

**Mel Pino**: You're looking at one of the only hopes for this county Jeff. 

**Jeff Bergosh**: Thanks Mel

**Mel Pino**: No thank ou. There s nobody else trying to get to the truth of anything.

### CONVERSATION ON 05-14-2020

**Mel Pino**: He posted them then delete them. People got screen shots though and are printing out

**Mel Pino**: His story is that he talked to Alison after he posted

**Mel Pino**: I don't believe that farther than I can throw it.

**Mel Pino**: They will share the posts with you.

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Trouble

**Mel Pino**: Yep especially as people pulled down copies.

**Mel Pino**: He is set to argue he didn't know

**Mel Pino**: Ask him about it in commissioners forum. Ask him if he posted the 5 transcripts somewherre

**Mel Pino**: It's a lose lose whether he answers yes or no get him in the sunshine on it.

**Mel Pino**: BAM.

**Mel Pino**: Call him on it.

**Mel Pino**: Yes we need to invest in solutions other than just growing the damn dump bigger.

**Mel Pino**: It's very hard to tell whether they really are on this emergency timeline. 

**Mel Pino**: They don't bring any true data and I don't trust Pat johnson

**Mel Pino**: Be careful on shortleaf some things are clicking together for me from times ast

**Mel Pino**: Past

**Mel Pino**: Janice asking me to dig on it for her

**Mel Pino**: Before she even got to the county

**Mel Pino**: Oh yeah let Alison handle it. You see how quickly Vicki jumped on letting your counsel work for Ecua.

**Mel Pino**: Go back to the table after a fine tooth comb on the whole damn agreement

**Mel Pino**: Don't trust anything and don't take alisons word for anything

**Mel Pino**: That's two questions dodged. Looke how often she changes the subject

**Mel Pino**: "Do you have the plans" is a yes or no answer

**Mel Pino**: "Do you have the plans" is a yes or no answer

**Jeff Bergosh**: I've seen the drawings

**Jeff Bergosh**: I have them

**Mel Pino**: Wonder how many times they have changed since then. They are famous for that

**Mel Pino**: Why is all that damn money getting spent for the same building? What the he'll does it matter what the trucks are there for at 5 am? "They're not new trucks"

**Mel Pino**: Ecua is failing to pick up garbage ALL OVER TOWN right now.

**Mel Pino**: GOOD. Sounds like Freedom of property rights to me.

**Mel Pino**: I'm sure the people looking to make money on the tax write offs will have some things to say about land use zoning and where they can go. Lots and lots of money to be made.

**Mel Pino**: Bingo. Doug shilling for scape.

**Mel Pino**: You have no idea what a damn disaster it is that Terry berry was put on this.

**Mel Pino**: David Forte has had her yanked off projects for running them for Doug too hard.

**Mel Pino**: She literally allowed staff to curb over Sara's driveways.

**Mel Pino**: And wouldnt do a damn thing to correct it. David had to kick her off and that's how she got moved over to natural resources where she could get better used as a pawn by chips.

**Mel Pino**: Dps loves marina khoury as a spokesperson because she is so grating and awful in her speaking people immediately tune her out.

**Mel Pino**: She is impossible to follow even if you wanted to, and nobody does.

**Mel Pino**: And they will have an even easier time of jamming in whatever they have had planned for years with a pandemic as extra duck and cover. 

**Mel Pino**: Here we go.

**Mel Pino**: Who exactly is Horace taking direction from?

**Mel Pino**: I just learned that Keith Morris apparently gained access to everyone's email but legal. And probably the bocc, although I'm not sure. He went to IT and asked for access and they wouldn't give it to him. So he went to Alison and it seems--i am getting this through channels, obviously--she told IT to give him access but they couldn't have access to the legal department.

**Mel Pino**: I just learned that Keith Morris apparently gained access to everyone's email but legal. And probably the bocc, although I'm not sure. He went to IT and asked for access and they wouldn't give it to him. So he went to Alison and it seems--i am getting this through channels, obviously--she told IT to give him access but they couldn't have access to the legal department.

### CONVERSATION ON 05-15-2020

**Mel Pino**: https://apnews.com/0cae34376380ab4150002a58bd9934b9

**Mel Pino**: What the military has known.

### CONVERSATION ON 05-18-2020

**Mel Pino**: Check your email and read the whole thing! :)

**Jeff Bergosh**: Ok will check it out

### CONVERSATION ON 05-19-2020

**Mel Pino**: Sorry I missed you! Outside mowing

**Mel Pino**: https://www.foxnews.com/us/georgia-health-department-apologize-coronavirus-data-gaffe-processing-error

**Mel Pino**: "Processing error." 🤣🤣🤣

**Mel Pino**: https://www.sun-sentinel.com/coronavirus/fl-ne-coronavirus-dashboard-creator-complains-of-secrecy-florida-20200519-jhwgp5bcdnab7ljhznd6uvdema-story.html

**Mel Pino**: And I'm sure this is all just a misunderstanding.

### CONVERSATION ON 05-20-2020

**Mel Pino**: It's nothing Jeff...just a parking spot somebody didn't pay for at la playa

**Mel Pino**: The listing makes it look like more. But Tim agrees we have to stay vigilant on beach access 1 and is writing an email reinforcing it

**Mel Pino**: Need to talk with you. I have some docs I want to release

**Jeff Bergosh**: Okay I'll call u when I come up for air

**Mel Pino**: Sorry I told Randy to slow down but you can't tell him anything.

**Mel Pino**: Holy shit nuts day

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Slammed at work

**Mel Pino**: Trying to get to reading those docs. All 5 of them.

**Jeff Bergosh**: Which docs?

**Mel Pino**: The docs I have now. :)

**Mel Pino**: That's what I want to talk to you about

**Mel Pino**: And working on getting that new tenant into the place!

**Mel Pino**: He will be calling you. Ex military officer, working with Joe ward. He can explain on docs.

**Mel Pino**: Call me if you want the quick rundown I have it

**Mel Pino**: Jeff I have called Steven about this also. Check that LOST funding on the bullshit inlet management plan. Car 11.20 

**Mel Pino**: I think they are trying to slip LOST funds on you guys when that is supposed to be Doug's discretionary

**Mel Pino**: They have it set up very nebulous though so they can get out of it by claiming that LOST is a "header" for his discretionary. That general LOST fund center number does not belong on those breakdowns anywhere and there is zero indication of what portion on either cost is coming out of his slush.

**Mel Pino**: In addition to the funding for that inlet management plan item, why is the B part of the recommendation circumventing the board to allow the chair to sign anything having to do with the grant?

**Jeff Bergosh**: Will look at that

**Mel Pino**: Also if you check the working on the initial resolution he got passed while chair he was boxing you guys in from the start on paying for this project

**Mel Pino**: Alison sent me the timeline. I assume you have that?

**Jeff Bergosh**: Yes

**Mel Pino**: Nothing wear yet.

**Mel Pino**: Fyi the docs they pulled down from the county contain and email exchange that cuts off important dialogue don't include peppler's amended motion for joint receivership after shackleford came back with the ruling. That might have been in the backup somewhere just mention it while I'm thinking of it...not to lose track of what was in that amended motion that they never followed up on.

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: Are you awake?

**Mel Pino**: Btw Doug's ads for the inlet management plan are getting top billing on ECTv for the second meeting in a row

**Mel Pino**: I can't believe they didn't give them the report. Alison gave it to me. I passed to Steve and Joe yesterday because I thought they had it.

**Mel Pino**: You just heard your county administrator laugh about the cost of masks and say they are at a premium (int the next of human lives) and your emergency manager Google the cost of masks as if this is the first time anybody thought of it. It's downright embarrassing Steven. Why does the bocc have to have a lengthy discussion to get administration to protect people after all these weeks into this? 

**Mel Pino**: Jeff this is teed up

**Mel Pino**: Lumon is fucking passed at Doug right now

**Mel Pino**: "Black and white" are you kidding me how damn racist can he get??

**Mel Pino**: It's really a good time. Here we go

**Mel Pino**: !!!!!!!!!!!!!!!!!

**Mel Pino**: Remember Doug tried to dish that property to mirabile

**Mel Pino**: I just forwarded the email of Doug trying to dish that property around the jail to mirabile to bocc and Alison.

**Mel Pino**: Please note that she came up with the exact answer I pointed out was built in. When you arrange stuff like that on the backup there is room for any way to work it. There could have been 10 different answers but I figured that would be it once it was asked. Why not just list the figured? Why isn't it broken down which cost centers are contributing what? It's not hard.

**Mel Pino**: And here we start out of the gate with staff interference on public safety.

**Mel Pino**: Are you fucking kiddie me.

**Mel Pino**: Jeff  what was the first charity

**Jeff Bergosh**: Boy Scouts of America

**Mel Pino**: Oh and in answer to you question about who that second guy is: Doug's new stooge but he really doesn't know what the f is going on. He's new to the area. Clueless. Just the way Doug likes them

**Mel Pino**: There is a meeting in 45 minutes

**Mel Pino**: This is a fucking nightmare. Who does this during a pandemic?

**Mel Pino**: Jeff are you aware your aide Allison contacted Michael Kimberl and read him some playbook from Tim day. And some Cynthia person in code that Allison admitted she didn't even know who it is.

**Mel Pino**: Not saying she did anything wrong, at all. There are just a LOT of people being commandeered right now and I want to make sure you directed her

**Mel Pino**: Hey tried to leave a message but it erased. Been on calls all day about the raid.

**Mel Pino**: https://www.al.com/news/2020/05/montgomery-running-out-of-icu-beds-as-coronavirus-cases-double-in-may.html

**Mel Pino**: Joe ward told Alison Doug released that shit last Friday. She's such a liar

**Mel Pino**: Also I was wrong that ethics complaint is on this.

**Mel Pino**: Wear covered the ethics investigation at 4

### CONVERSATION ON 05-22-2020

**Mel Pino**: Check PNJ!!!!!

**Mel Pino**: Jeff I don't need to know who it was but take a moment to reflect hard on who it was that was preparing you to release those transcripts and what the timeline was. If it happened after Doug posted those are not friends.

**Mel Pino**: Check your email. 

**Mel Pino**: For a forward

**Jeff Bergosh**: Didn't get it

**Jeff Bergosh**: From who?

**Mel Pino**: I was on the phone with Steve when you called in so I got off. He can fill you in on that

**Mel Pino**: Fyi ecw is howling and I am going to take care of but Doug isn't on there. He may have made a post I can't se

**Mel Pino**: Just talked to Chorus call me super important

**Mel Pino**: Be careful with that Facebook group dnt know who all is in it

### CONVERSATION ON 05-24-2020

**Mel Pino**: https://www.nytimes.com/interactive/2020/05/24/us/us-coronavirus-deaths-100000.html

### CONVERSATION ON 05-25-2020

**Mel Pino**: The 7 am news on memorial day on site from Pensacola beach and in real time. There were no images of our beaches with crowds on them yesterday but they were interlacing with the stories of super spreading from that high school swim party in Arkansas (which is increasing cases at 50 percent)and the 2 hairstyles in a single facility who have exposed hundreds of people. It closed bt .

**Mel Pino**: Sorry this was on CNN. The anchor asked her if authorities herer were concerned and she said that "she spoke to the county commissioner in charge of the beach and he said of course I am concerned but we are opening per De Santa's plan."

**Jeff Bergosh**: Bender said that??

**Mel Pino**: I have no doubt it sounded just like him

**Mel Pino**: She didn't mention him by name but the close as quote as close as I can come is "he said of course he was but they were following De santis's careful plan for phased openings"

**Mel Pino**: I'm sure she got it very close it was a serious non sensational approach. They are very somber on that channel these days. Probably, you know, because a shit ton of people are dead with way more on the way.

**Mel Pino**: This is the type of thing happening in places that aren't trying to pretend like the pandemic is over.  https://www.cnn.com/2020/05/17/us/nj-man-donates-ipads-trnd/index.html

**Mel Pino**: She is reporting the umbrellas being put out at a social distance now. For the most part good press tis round.

**Mel Pino**: "The county here he says followed the rules set forth by the Florida governor"

**Mel Pino**: Thats the exact quote from the repeat.

**Mel Pino**: Quote confirmed.

**Jeff Bergosh**: 1809 Amos circle Pensacola

**Mel Pino**: That came to me by mistake probably cause of my dogs name :)

**Mel Pino**: Now I want to steal that sign

**Mel Pino**: https://weartv.com/news/local/social-media-posts-show-commissioner-underhill-leaked-confidential-meeting-transcripts

### CONVERSATION ON 05-26-2020

**Mel Pino**: Sorry will call you back asap!

**Jeff Bergosh**: 👍

**Mel Pino**: I am waiting to ask a question about something that he just said about you ion the Bernie Thompson show

**Mel Pino**: He just spewed really dangerous crap all over the panhandle about you guys. Alison should be asking for the transcript to this. It is just completely out of hand.

**Jeff Bergosh**: What did he say?

**Mel Pino**: He lied about the timeline on when you asked and said you lied about it

**Mel Pino**: And that all of you are basically in a conspiracy to keep info from the public

**Jeff Bergosh**: What a lunatic!

**Jeff Bergosh**: Nut job 

**Mel Pino**: If Alison were really the attorney for the corporate board she would be asking for that transcript

**Mel Pino**: This is just too much Jeff.

**Jeff Bergosh**: He's digging himself a really deep hole

**Mel Pino**: Alison needs to put in an ethics complaint on him

**Mel Pino**: For the rest of the board. 

### CONVERSATION ON 05-27-2020

**Mel Pino**: Just went by a Burnie Thompson billboard and he is live local 103.7 Winn every night from 5 to 7. I didn't realize he was being pushed locally. So all that crap he said about you guys and David and old money happened during evening drive time all across the panhandle.

**Jeff Bergosh**: Oh well

**Mel Pino**: Well with an "oh well" attitude what's the point of anything. :(

**Mel Pino**: You guys need to find your fight against this guy Jeff. He is a fucking lunatic.

**Jeff Bergosh**: He will get what's coming to him

**Jeff Bergosh**: And it won't be pretty

**Mel Pino**: It needs to be soon. He is growing more dangerous 

**Mel Pino**: And it s not about giving him back what he gives. It's as simple as a mentally unwell man who can't help himself.

**Mel Pino**: He's sick Jeff.

**Mel Pino**: Check email and my page. Doug going def con and now roping Alison in.

**Mel Pino**: Oh I know I bet he is giving Eddins and the Sao some bad press

### CONVERSATION ON 05-28-2020

**Mel Pino**: I called county attorney and got Alaine and asked him to relay to Alison to explain to me why she does not have to file an ethics complaint on Underhill when she has told me twice she would be bound by bar and statute to report him if she ever witnessed unethical activity.

**Jeff Bergosh**: Wow!

**Mel Pino**: It won't do anything. Just keeping you in the loop. 

### CONVERSATION ON 05-29-2020

**Jeff Bergosh**: LOL

**Jeff Bergosh**: But he's just a fish flopping around on the boat try to get back in the ocean

**Mel Pino**: Yes but why know ethics complaint from Alison.

**Mel Pino**: No

**Mel Pino**: Hey these protests are building all across the US after the new video with 3 officers on top of him. I am going to take a chill and work on things over the weekend and see if things calm down

**Mel Pino**: they are setting Cop cars on fire around the corner from Mike's office in atlanta

### CONVERSATION ON 05-30-2020

**Mel Pino**: Doug, Jacqueline, and Doug's newest fan boy and literal Q Anon cult adherent are using janice's failure to issue a resolution to the investigation to great effect. Doug is having his cake and eating it too by calling all of you corrupt, saying that the county attorney is doing your bidding to hide things (if only the county attorney actually did represent her board as a whole, what a concept), and using the fact that Janice is quite clearly working for him--against the rest of board--to represent it as a nothing Burger.

**Mel Pino**: He is also using his supporters to collect together documents and lying narrative making it look as if all of you lied and colluded in hiding the transcripts. 

**Mel Pino**: Now that he has that accomplished he is dog whistling an ethics complaint on the rest of the board.

**Jeff Bergosh**: He's a nut and the fact he is still obsessing over this is the victory.  In his head, renting space

**Mel Pino**: Please call very very important not about doug

**Mel Pino**: Word is they are going to start blood letting on the drum majorette side of the county.

**Mel Pino**: Jeff please don't be mad at me saying this I am trying to be a friend. I KNOW you are just working hard and you get tunnel visioned in a good way to accomplish goals so I get it. But honestly just try to be mindful not to appear tone deaf. Police are firing rubber bullets in LA, they are marching through times Square arresting people, there are hundreds of people gathered down at graffiti bridge. Not sure people have it in them to get excited about a campaign right now but I could be wrong.

**Mel Pino**: The country is absolutely melting down and Trump is tweeting about the "unlimited power of our military"

**Mel Pino**: The situation in LA is getting out of control

### CONVERSATION ON 05-31-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Jeff remove your account from the Escambia public forum. One of the administrators has gone ballistic and posted a photo of five flags. Believe me I get the debate but this isn't a time for an elected official to be on a site with a moderate flag at the top.

### CONVERSATION ON 06-01-2020

**Mel Pino**: Look at the PNJ article on the transcripts.

**Jeff Bergosh**: Saw it.  It was in the hard copy Sunday edition.  Makes Underhill look terrible

**Mel Pino**: With the end of the article the first amendment foundation saying that is looks like you guys have something to hide?

**Jeff Bergosh**: That is misleading, and it wasn't in the hard copy piece

**Mel Pino**: Well it is sure as he'll in this one and they end the article throwing roses at Doug's feet

**Jeff Bergosh**: You have to parse what she says:  "the COMMISSION could release it". Yes there are ethics rulings that say we could--and we could.  But 1 Commissioner alone doesn't have the authority to do it.  That's the point.  He did it anyway-- over our objections 

**Mel Pino**: I don't think anybody is parsing the part about how Underhill did the right thing because the rest of you look like you have something to hide.

**Mel Pino**: More great advice from Alison. She's a real winner.

**Jeff Bergosh**: Nobody reads it that way, only a simpleton would

**Mel Pino**: I don't think you saw the last paragraph Jeff. Scroll down.

**Mel Pino**: I almost missed it myself because of the Baptist ad.

**Mel Pino**: "And wouldn't it look as if the rest of the county officials wanted to hide something if they reprimanded commissioner Underhill for wanting to disclose the transcript in the interest of transparency?" 

**Mel Pino**: Who is Pamela marsh and who is she friends with.

**Jeff Bergosh**: I saw it, just not concerned about it.  He is a tool, and everyone knows it.  Dishonest and deceitful and a coward--otherwise why would I have to call him out to make him admit it was him?  And why did he wait until now to fess up-------why not one of the previous two meetings?  Answer:  because he is dishonest and deceitful 

**Jeff Bergosh**: ..........and the article frames him as such

**Mel Pino**: Trump is propelling us into civil war. 

### CONVERSATION ON 06-02-2020

**Mel Pino**: Jeff call and find out whether those mattresses are there yet and text me yes or no on it

**Mel Pino**: I conveyed all that. You realize that with Underhill sharing that Contractor on the firehouse he will get his work done first. 

**Jeff Bergosh**: Nope--not there yet

**Jeff Bergosh**: Unbelievable

**Mel Pino**: Nope that's how she rolls.

**Mel Pino**: Word. Is they have already backed off Tamika. On Friday she was told she was being investigated for stealing Medicare money and today was told it was unsubstantiated. Maybe they figured out how the billing actually works. Or it was just intended as a scare tactic to rattle her. There won't be any paper on it, that's for sure.

### CONVERSATION ON 06-03-2020

**Mel Pino**: Sorry medial! I'm streaming your video on my page.

**Mel Pino**: Sorry medial! I'm streaming your video on my page.

**Mel Pino**: Email sent

**Mel Pino**: And fixed it

**Mel Pino**: https://m.youtube.com/watch?v=cdcesJW-Zlk

**Mel Pino**: This ought to be good. Second appearance in two weeks. Last one he trashed you guys David bear and old money during drive time.

**Mel Pino**: This is the worst hit piece he has ever done.

**Mel Pino**: If you guys actually had a county attorney she would be spitting nails over this and going to the rails for you guys. It is ABSURD.

**Mel Pino**: He just set it up by asking very slowly who is up for re election. He said all your names and insinuates its a witch hunt

**Mel Pino**: "When Steven Barry was telling the staff we needed to get to the bottom of an investigation my light was on. I was trying to tell him that I'm the one that disclosed it"

**Mel Pino**: "I don't know if he just didn't notice that"

**Mel Pino**: "He always notices but this time he did not"

**Mel Pino**: "Maybe he was just concerned that if I had the microphone I might get to more about why I released them"

**Mel Pino**: "If I ever have to lie or kiss hands to keep this job then I don't deserve the job any more"

**Mel Pino**: Burnie says that Alison did it because she knew at least 3 and maybe 4 of you want her to help you keep it secret.

**Mel Pino**: "They put her on the spot though."

**Mel Pino**: Jeff I just had somebody ask me about the investigation on ferry pass. I forgot all about it. Is that anywhere?

### CONVERSATION ON 06-04-2020

**Mel Pino**: We won't be at the meeting we are reporting from home. Ain't gonna let the covid denying county infect me with cases exploding. Nope.

**Mel Pino**: Jeff ask where the investigation on ferry pass is

**Mel Pino**: We just watched the video of the last meeting and Doug turned his Mic away from Stevens side and put it on

**Mel Pino**: He made no mention he wanted to talk

**Mel Pino**: You asked if steven had objection on the investigation and he supported it and Doug just sat there. Never said anything. As soon as steven recognized Robert up next for commissioners forum he flipped it off.And kept chewing his peanuts

**Mel Pino**: Chewing peanuts the whole time. Flipped more in his mouth just after he flipped his light off.

**Mel Pino**: ASK ALISON AND JANICE IF EITHER ONE KNEW ABOUT THIS POLICT. MAKE THEM ANSWER YES ORNO

**Mel Pino**: I can't believe you guys aren't asking them whether they knew. 

**Mel Pino**: Ow whether anybody had contacted them. Did Janice and Alison receive NO word of this? Give me a break.

**Mel Pino**: Did you hear that word many

**Mel Pino**: Many costs

**Mel Pino**: Well if nothing else perhaps now you will believe me when I use the word corrupt for ECUA

**Mel Pino**: He wants to know the size of the hot dogs

**Jeff Bergosh**: LOL

**Mel Pino**: He's making a big deal about this can't go on David's beer

**Mel Pino**: Doug got sent in to trash the bay center and cry up blue wahoos

**Mel Pino**: She set it up for people to complain.

**Mel Pino**: This is Doug and Janice shilling for studer dc Reeves etc

**Mel Pino**: Get food trucks the craft beer comes with it

**Mel Pino**: And Jonathan contributors like hip pocket deli

**Mel Pino**: Yep thanks Debbie. I love how this was orchestrated as if it was spontaneous from underhill

**Mel Pino**: This is the formula over and over. Janice is knee deep in all of it.

**Mel Pino**: Imagine that UWF got a cut.

**Mel Pino**: Right? Or did they pay

**Mel Pino**: What was the UWF invovlement

**Mel Pino**: Did sba/uwf get a cut of this? Honest question. She was pretty squirmy.

**Mel Pino**: She hates to use the word "blind" because they weren't but she will drop that word and leave people with the impression.

**Mel Pino**: Check email. Can you have Debbie send me the map and whatever else got distributed today that should have been in the backup?

**Mel Pino**: Wow they are taking over Artel as well as the bay center. Why on gods green earth is she back doing that space without the board knowing about it.

**Mel Pino**: Terry said they were talking for a week

**Mel Pino**: Hahahahahahahahahahahaha wtf

**Mel Pino**: Wow so studer is taking over the bay center and artel

**Mel Pino**: You can't write this.

**Mel Pino**: I just sent Doug an email calling him a liar on innerarity sewer with a transcript I just did attached. Look at the yellow

**Mel Pino**: Like the discussion I sent the transcript for where he said he was getting a grant and downplayed the cost.

**Mel Pino**: CENSURE HIM

**Mel Pino**: Ask Alison if you can

**Mel Pino**: Just ask about it

**Mel Pino**: Just say you want to know the options

**Jeff Bergosh**: Bender was strong tonight

**Jeff Bergosh**: I'm proud of him

**Mel Pino**: Just ASK her

**Mel Pino**: Me too it's about time

**Jeff Bergosh**: Timing not right

**Mel Pino**: Ask Alison "if commissioner Underhill continues..."

**Jeff Bergosh**: He got his ass kicked

**Mel Pino**: He doesn't care. He's going off to Facebook against you guys. 

### CONVERSATION ON 06-05-2020

**Mel Pino**: Hey here's my morning thought. People aren't going to like it but Rod was right...msbus's need to come to an end.

**Mel Pino**: Not during the election cycle hahaha

**Mel Pino**: It's just another way of imposing taxes without having to impose taxes on everybody. That's not fair

**Mel Pino**: Also, hemmer is now strongly partnered with studer and they are going to push west hard simultaneously wit scape down here and across 9 Nile and kingslfiled

**Mel Pino**: Hemmer up north. Don't know who the developer darling for scape will be yet.

**Mel Pino**: But they are coming for navy point park. 

**Mel Pino**: Hey I was just trying to leave a message but your box is full. I can call back when it's empty if u give me the heads up. 

**Mel Pino**: I went and researched George Floyd's history because it's important to know both sides. He grew up in an awful ward in Houston and had bad come on his record. But his last act was 2007 and he was charged and jailed 2009 and spent five years in jail. He moved to Minneapolis to get out of Houston and his first job was salvation army. Nothing on record that I can find in metropolis? Seriously, please tell me if I am wrong because I want the facts for real.

**Mel Pino**: I'm no Pollyanna and a club was probably not a great choice for him. Not a lot of job opps however.

**Mel Pino**: Here's a prediction: that cop was running kickbacks at the club

**Mel Pino**: You tell me what the fuck a pin dick cop with a pathetic career over years in the dept was doing with a house in Windermere of all places.

**Mel Pino**: Something ain't right in the water. It will not surprise me if it turns out the two of them were in on something that got away from the cop so he set that shit up and killed him.

**Mel Pino**: I'd bet money on it.

**Mel Pino**: That's just a guess though. Just remember as a skeptic I am statistically advantaged to predict correctly :)

**Mel Pino**: https://www.wsfa.com/2020/06/05/multiple-alabama-football-players-test-positive-coronavirus/

**Mel Pino**: Must have been red shirt for 50 years or so.

**Mel Pino**: Jeff did the company go bankrupt? I honestly don't remember. 

**Jeff Bergosh**: Yeah I think they did

### CONVERSATION ON 06-06-2020

**Mel Pino**: I just emailed the shade transcripts to Jacqueline and asked her to post them on ECW. Put the email up and made sure people understood it is her choice to provide them to people or sit on them.

### CONVERSATION ON 06-09-2020

**Mel Pino**: Sorry call me when you can! Stuff I have to tell you

### CONVERSATION ON 06-10-2020

**Mel Pino**: Man they are covering Grover in the pnj

**Mel Pino**: Clobbering

**Jeff Bergosh**: It's a tough issue

**Mel Pino**: The orchestrated a multi faceted hit on him

**Jeff Bergosh**: It's a no win situation

**Mel Pino**: Jim little special. Took the credit away on Florida square and gave it to Ann Hill and made it lookike Grover is punting to council

**Mel Pino**: Yep but the Pnj managed to make it even worse.

**Mel Pino**: Studer is an asshole and lisa is a piece of shit

**Mel Pino**: https://www.espn.com/racing/nascar/story/_/id/29293767/nascar-bans-confederate-flags-racetracks

**Mel Pino**: https://sports.yahoo.com/over-1400-athletes-coaches-executives-sign-players-coalition-letter-to-end-police-immunity-150408851.html

### CONVERSATION ON 06-11-2020

**Mel Pino**: https://www.palmbeachpost.com/news/20200611/statewide-coronavirus-cases-skyrocket

**Mel Pino**: Please be careful out there Jeff. This thing isn't just going to disappear no matter what the narrative is. The county is doing a horrendous disservice to its staff with this denial business and Florida in particular is going to get walloped because of the messaging of unconcern from the state government. Hopefully our hospitals can handle it but please take personal care and do not buy in to the "it's all good" PR campaign. That messaging is going to kill a lot of people.

**Mel Pino**: An appeal to a national QAnon site. This stuff is unfortunately for real and taking root here fast. He is also dog whistling David bear as antifa and tying him to the monument coming down on sites with lots of trumpers who own a whole gotta guns.

**Jeff Bergosh**: Wow!

**Mel Pino**: Yup. I literally had Randy Cudd in my texts today telling me to back off. People are truly losing their minds over this stuff and that is why I react so aggressively when you mention these sources that are feeding these people all their "facts"

**Mel Pino**: I'm worried about David's safety more than mine. This stuff is whipping up anti semiticism and tying it to antifa through Soros. It's completely fucking insane.

**Mel Pino**: Joan Carnley accused me of being a Soros operative.

**Jeff Bergosh**: Holy cow really??

**Mel Pino**: Yes Jeff. It's an incredibly powerful fiction when a whole lot of people are looking for anyone to blame.

### CONVERSATION ON 06-12-2020

**Mel Pino**: https://inweekly.net/inside-innerarity-sewer-takeover/

**Mel Pino**: Arson threw Jack under the bus hahaha

**Mel Pino**: Can somebody working for the D2 office accept a campaign contributions from roads Inc?????

**Mel Pino**: How is that not an ethics violation?????

**Mel Pino**: Can he pay his own business for providing the meeting roo for a campaign meeting?

**Jeff Bergosh**: Yes

**Mel Pino**: Even roads Inc??

**Jeff Bergosh**: Roads contributes to lots of campaigns

**Jeff Bergosh**: Jon Gingrey
Escambia County
SOE IT
850-595-3900 x 4510

This is the guy to call and request the .txt file for all registered Democrat voters

**Mel Pino**: Weird. I guess you can't block out anybody who ever contracted for the county from contributing. 

**Jeff Bergosh**: He'll send Lumon a link to a Dropbox file

**Mel Pino**: Thank you!!!

**Jeff Bergosh**: Sure thing

**Jeff Bergosh**: Lumon has to make the request

**Mel Pino**: Ok thank you. 

**Jeff Bergosh**: 👍

**Mel Pino**: Here is decommissioned ladder truck someone is trying to hide from Bergosh 

**Mel Pino**: Trying to buy a brand new one. County wants to restore it. It is a pile of crap and we have been spending thousands just trying to keep it running 

**Mel Pino**: That is a follow up 

**Mel Pino**: I can't follow this I called and asked for a phone conversation. Here are a couple more

**Mel Pino**: (this is me) Jeff is trying to restore it? Sorry I am not feigning being obtuse. Who at the county wants to restore it? Jeff?

**Mel Pino**: (him) Yes and Gilley it was up at fleet the road camp so they brought it here to get it out of sight 

**Mel Pino**: So he is saying that (1) you are wasting money on an old fire truck that (2) Gilley is hiding from you. It makes no sense to me but im willing to bet it does to you and those photos will be helpful. She is clearly up to no good

**Mel Pino**: Hiding fucking trucks at the road camp?

**Mel Pino**: What the he'll is a truck doing at the road camp?

### CONVERSATION ON 06-13-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: That okay I just Ned confirm that that lisa Myers site isn't you hahaha I'm serious Jeff I was getting ready to blast on jacquelines for allowing fake accounts to post

**Mel Pino**: I also missed a call on that fire truck earlier so still figuring that out. I think they are saying Janice and fire are hiding that truck?

**Mel Pino**: Oh hey: protests were peaceful. The brick stories are set ups, Jeff.

**Jeff Bergosh**: Glad to hear that!

**Mel Pino**: Our cops are doing a great job with this. It's a great moment for this community, truly. Let's hope it holds. 

**Mel Pino**: God we will have that at the county soon. A police force we don't have to be scared of for the first time in God knows how long.

**Mel Pino**: https://ricksblog.biz/school-bond-ratings-revised-to-negative-outlook/

**Mel Pino**: Hey Jeff those crazy meltdown comments on your blog are aimed at me. They are happening across various sites but saving the worst one for anonymous on your site.

**Mel Pino**: Also keep an eye peeled for a post on taxes for the child referendum. The person is a Jonathan supporter but I have been talking with him a lot. A good guy just very new and still under the say of the early "teachings" on jacquelines site. I'm trying to help him with information and such as I think the more he understands the more it helps. He responds really well to kind answers that take his questions seriously.

**Mel Pino**: https://www.washingtonpost.com/national/protests-antifa-absent/2020/06/13/7f14b8fa-ab80-11ea-9063-e69bd6520940_story.html

**Mel Pino**: The sad thing is, they will never stop pumping out this disinformation and fragile people are losing their minds over it :(

**Mel Pino**: Never mind...I hadn't seen that you went there on the monument blog. That went about as  well as I figured it would. Now you have some of the literally most idiotic and racist commentary public on your blog that is being printed in Escambia county. I can't tell what's worse: the horrendous metaphor of the mouse and milk or the sussed up academic "illustrations" which are so horribly misapplied to the context. A little learning is a dangerous thing. Simply letting some of those heinous statements live on a blog you host and saying "pray for peace" isn't good enough, Jeff. If you weren't prepared to decry pernicious racist and dangerously inflammatory statements then you should have addressed the topic at all.

**Mel Pino**: Jeff. You allowed anything woman who is literally having such a meltdown she actually believes I am a Soros operative bait you into a very ill advised post by screeding a come apart fueled by racism in anonymous comment.

**Mel Pino**: I'm going to have to pen a counter to that now and pull you out of this. I don't care how well you think this sort of thing may play to your constituency. I think you may underestimate a lot of people if mouthing this is what they want and need to be hearing right now :(

### CONVERSATION ON 06-14-2020

**Mel Pino**: Steve Bursey said he sent in his tax question to your blog. They are also discussing it on ECW and Jacqueline actually gave you a compliment with putting it up before the agenda is up. It might be good to get some of the tax discussion out there before as fire is going on the spending. Fyi Steven wouldn't believe that you would post a comment against the spending. I told him you post everything unless it is against Facebook rules.

**Mel Pino**: Jeff I'm going to let that stuff lie. The best thing that can happen is that it gets as few more looks as possible. There's nothing I can do to make any of that anonymous shit show less horrible than it is. One specific thing is that you might not want to leave the lunatic delusion that there is a network of people standing by to kill people who have different opinions in Pensacola with what's happening Pensacola giving the signals for the hits.

**Mel Pino**: I'm afraid that anonymous poster might think that the symbol for getting blocked from that site is actually a "hit." It's sad.

**Mel Pino**: I am going to pass that thought on to the moderators there as I don't control content there any more than any other board I've used to post.

**Jeff Bergosh**: That's a smart play Mel

**Mel Pino**: It's very dangerous to allow a bunch of comments from a person who has clearly lost her grip on reality just hang there Jeff. But having me correct it won't help.

### CONVERSATION ON 06-16-2020

**Mel Pino**: I am really really hoping you are going to frame this as a courtesy only.

**Mel Pino**: Other people refused to bring it

**Mel Pino**: Best description of an oncoming train wreck I've ever heard.

**Mel Pino**: Ask him how much navy federal is donating back from the millions in tax breaks they get.

**Mel Pino**: God it sucks when Doug is on the right side of a 4 1

**Jeff Bergosh**: This is not an affirmation of the program.  It is for allowing the citizens decide.  Period.  He's on the wrong side of the 4-1

**Mel Pino**: They'll have the words apple pie and God loves America in the language and it will fly through. 

**Jeff Bergosh**: That's a separate issue, the vote November 3rd

**Jeff Bergosh**: Separate.  2 separate issues.

**Mel Pino**: Keep telling yourself that :)

**Jeff Bergosh**: The issue today is should we allow citizens to decide,  I say yes 🙂👍

**Mel Pino**: So would a lot of people who don't know how the ballot gets written.

**Mel Pino**: And that thing of two abstaining is rigged.

**Mel Pino**: Maybe you guys can try to get this thing better before it goes on the ballot. This should require a very hefty ordinance not written by Allison at Ron Ellington direction.

**Mel Pino**: Unfortunately he is hitting the nail on the head.

**Mel Pino**: These issues have been raised for very good reason

**Mel Pino**: And the sad thing is that the one guy on the podium who couldn't give a shit less about poor kids is actually speaking the truth about it.

**Mel Pino**: That's how you guys should turn this right back around on this. Hand them an ordinance that actually makes those dollars go to real help.

**Mel Pino**: You better watch this money like a hawk. She has a lot of holes to fill and this is why it is not accident we don't have a budget manager.

**Mel Pino**: Because some counties have competent administrators.

**Mel Pino**: Jeff check out from that what's happening Pensacola group. That is the last time I am ever going to make the mistake of trying to post on a page of somebody else's making with high numbers. It never ceases to amaze me how quickly these things go bad. It is too volatile you don't want your name associated. I'm sorry for the invite.

**Mel Pino**: First verified bus driver case of covid. 

**Mel Pino**: Probably came into contact with about a hundred people that day, 60 to 75 of them ecat workers.

### CONVERSATION ON 06-17-2020

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Left a message

**Mel Pino**: Jeff you have got to get out in front of the ecat bus driver.

**Mel Pino**: She tested positive yesterday and is so far waving her hippa rights to let people know. 

**Mel Pino**: She was floater that day so could have come into bedroom contact with 60 to 75 employees 

**Mel Pino**: Nobody is wearing masks any more or social distancing in the building since they fired Mike. Bus drivers wearing them on buses but nobody taking precautions off.

**Mel Pino**: A group of 16 young people who went out to a bar together in Florida ALL tested positive for it

**Mel Pino**: It wasn't a "leak" Jeff, which would indicate there is an active cover-up at the county. An employee with covid has EVERY right to let co-workers know. And should. God know the county won't do it.

**Mel Pino**: I have confirmation. They have already moved everybody out of the building.

**Mel Pino**: Call me if you want what happened. 

**Mel Pino**: Call Janice and ask her what's happening then let me know so I can count up the lies.

**Mel Pino**: Doh contact team coming.

**Jeff Bergosh**: In meeting will call after

**Mel Pino**: Look at that awful shit going down on lumons string :( :( h(

**Mel Pino**: In case you needed any other proof this wasn't orchestrated. This is going to rip that family to shreds

**Mel Pino**: If there really is a he'll Doug better rot in it.

### CONVERSATION ON 06-18-2020

**Mel Pino**: I hope you are hearing hi because I have been trying to tell you this for MONTHS

**Mel Pino**: She is not recommending masks

**Mel Pino**: Is she going to roll a wagon of puppies in next?

**Mel Pino**: He just literally encouraged another lawsuit on the county. Rather than the county going back to court with Ecua. And Alison will just let that roll for him.

**Mel Pino**: And all of this grief because Doug has a vendetta on the island because he thought gene lived on it. And because he is Land banking for mirabile

**Mel Pino**: Hahahahahahahahahaha

**Mel Pino**: I just circulated the transcript again from the portion of the msbu meeting where Doug lied about grants and cost to your email.

**Mel Pino**: And there is the moment this all went bad when Doug made them reassess at higher cost to scratch Lois Benson's back and get at gene and the other residents.

**Mel Pino**: Oh my god don't let him get away with this

**Mel Pino**: Or you could just make Ecua pay for it if you had decent legal representation who isn't playing politics.

**Mel Pino**: Because Jack Brown and Alison Rogers orchestrated this for Doug.

**Mel Pino**: Here we go with the speech on how great grinder pumps are because he makes so much money fixing them.

**Mel Pino**: But of course that would screw up the plans for Doug's developers.

**Mel Pino**: Hahahahaha that's exactly why he was banking it.

**Mel Pino**: Did Wendy's company appraise them? I don't know just wondering who got paid to over appraise them.

**Mel Pino**: Unbelievable. So Doug got to the language of that too.

**Mel Pino**: https://www.pnj.com/story/news/2020/06/18/florida-shatters-record-new-covid-19-cases-escambia-adds-2-deaths-37-cases/3213560001/

**Mel Pino**: Did Janice tell you she just cancelled the labor negotiations for tomorrow?

### CONVERSATION ON 06-19-2020

**Mel Pino**: https://6abc.com/philadelphia-phillies-coronavirus-covid-19-clearwater-players/6256108/

**Mel Pino**: https://www.theverge.com/2020/6/19/21296975/apple-close-stores-again-florida-arizona-north-carolina-south-carolina-coronavirus-spike

**Mel Pino**: Watch how quickly covid outpaced other causes of death. https://public.flourish.studio/visualisation/2562261/

**Mel Pino**: https://www.si.com/.amp/college/2020/06/19/clemson-athletics-coronavirus-tests-positive

### CONVERSATION ON 06-20-2020

**Mel Pino**: Posted my email.

### CONVERSATION ON 06-23-2020

**Mel Pino**: Check out this article from Pensacola News Journal:

U.S. Attorney Larry Keefe running office remotely after coronavirus diagnosis

https://www.tallahassee.com/story/news/local/2020/06/23/u-s-attorney-larry-keefe-announces-he-has-covid-19-running-office-remotely/3241871001/

**Mel Pino**: https://www.palmbeachpost.com/news/20200623/coronavirus-donrsquot-report-covid-patients-in-icus--surgeon-general-tells-hospitals

**Mel Pino**: I've been saying that they have been manipulating the data for months. This is literally the last move they had left, to simply stop reporting icu beds in any meaningful way. 

**Mel Pino**: Now the only place to get numbers that are anywhere close to reality is from the alternate dashboard from ther employee got fired.

**Mel Pino**: According to that dash we have 7 available ICU beds by the standard way of counting. The state blew that away today.

**Mel Pino**: We being Escambia county.

**Mel Pino**: Santa Rosa has 8.

**Mel Pino**: But you will see bigger numbers on the DOH board because they changed how they count capacity to"how many people can you cram in" and they are also blowing away the category of covid in icu if they don't get shamed into not doing it.

**Mel Pino**: And they have no shame.

### CONVERSATION ON 06-26-2020

**Mel Pino**: The division of alcohol just shut down sales at bars

**Jeff Bergosh**: At all bars?

**Jeff Bergosh**:  Or just some?

**Mel Pino**: I think so chec my page. Working on getting the order

**Mel Pino**: All I have is that tweet from the head of the DBPR.

**Mel Pino**: Because that's what we get these days. Government by Twitter.

**Mel Pino**: https://ricksblog.biz/gilley-games-and-sds/

**Mel Pino**: Her administration will be responsible for the worst public health failure in the county's history.

**Mel Pino**: https://ricksblog.biz/pensacola-mandates-masks/

**Mel Pino**: And Janice won't even mandate masks on buses.

**Mel Pino**: https://ricksblog.biz/escambia-only-has-12-icu-beds-available-10/

**Mel Pino**: Baptist only had one at the time of reporting. And the fire Department is telling symptomatic people to work along with people who are living with a positive case.

### CONVERSATION ON 06-27-2020

**Mel Pino**: Kevin and I are going to suspend our Facebook accounts for a while. We got a Q "militia" drive by the house today. I'm worried for my dogs safety.

**Jeff Bergosh**: Wow!! Are u kidding me?!?

**Mel Pino**: Left a message

**Mel Pino**: Here is the 4K washer

**Mel Pino**: This what you got when you peel back the 4K label 

**Mel Pino**: Now the other side

**Mel Pino**: Here is the company selling these 

**Mel Pino**: This what a real extractor washer looks like from a Fire equipment company and the real cost

**Mel Pino**: Those texts were from someone in fire. There is *supposed* to be an investigation on it. Did procurement get played or were they in on it?

**Mel Pino**: Keep this on the low down for a bit with Janice but ask somebody you trust at the Beulah fire dept to check theirs

**Jeff Bergosh**: Okay I will thank you for the heads up Mel!

### CONVERSATION ON 06-28-2020

**Mel Pino**: This stuff about the Russians is unreal. We are in so much trouble with that man in office. I canno believe he has come out with a denial of knowledge and stating that our troops have never been under attack. This is a nightmare:: (

**Mel Pino**: https://www.pnj.com/story/news/nation/2020/06/25/fauci-covid-19-why-two-weeks-critical-florida-texas-arizona/3249748001/

**Mel Pino**: https://www.pnj.com/story/news/nation/2020/06/25/fauci-covid-19-why-two-weeks-critical-florida-texas-arizona/3249748001/

**Mel Pino**: Sorry meant to send a different one

**Mel Pino**: https://www.pnj.com/story/sports/college/2020/06/26/coronavirus-college-football-hopes-tempered-rise-positive-tests/3253683001/

**Mel Pino**: And yet kids are still practicing in escambia county :(

**Mel Pino**: https://www.washingtonpost.com/nation/2020/06/28/coronavirus-live-updates-us/#link-2JA4NGLQFFHM7K34BA2K2PTIRY

**Mel Pino**: Houston administrators got rid of the problem by simply removing the icu counts from database. 

**Mel Pino**: Hospitals in Pensacola are gaming it 3 ways. 1, with DOH giftin them with the ability to not count covid admissions separately. 2 with DOH telling them to revise their definition of icu beds to how many people they can cram in other places. 3. By not telling the public that they are coming up with different non ICU ways to treat, with more covid patients being treated with drugs rather than ventilators. 

**Mel Pino**: Unbelievable this asshole came here to whitewash the situation for tourism. This is why Florida is exploding.

**Mel Pino**: This is what you are up against.

**Mel Pino**: Everything this man is saying is going to kill more people.

**Mel Pino**: Government by gaslighting.

**Mel Pino**: This is homicidal negligence.

**Mel Pino**: So he is basically saying "if you keep doing what you are doing we will continue to explode in cases." Knowing that it won't change a thing and the cases will continue to explode. 

**Mel Pino**: Oh great now we get a bunch of lies from the hospital money. Perfect.

**Mel Pino**: Oh great now we get a bunch of lies from the hospital money. Perfect.

**Mel Pino**: This will be good.

**Mel Pino**: Dawn Rudolph: thank you healthcare workers as we prepare to throw you under the bus.

**Mel Pino**: So Peter Jennings trying to get across how important masks are knowing people aren't doing it because they believe it's a left wing conspiracy.

**Mel Pino**: That poor man knows how screwed we are.

**Mel Pino**: Thank God Jason foland is going to speak the truth.

**Mel Pino**: Oh right now DeSantis just intentionally conflated heart/stroke with elective surgeries. How disgusting.

**Mel Pino**: "We need to keep doing those knees and elbows because hear attacks." What a crock.

**Mel Pino**: "We have plenty of capacity."  I guess that's why people are waiting for hospital beds in recovery for 6 hours and Baptist only had 1 real ICU bed available. 

**Mel Pino**: So basically DeSantis is going to be the press for the hospital administrators. How wonderful he can wear so many hats. What a gem.

**Mel Pino**: So basically DeSantis is going to be the press for the hospital administrators. How wonderful he can wear so many hats. What a gem.

**Mel Pino**: Some reporting just holding a hand in the air in protest hahaha

**Mel Pino**: So you're going to get it if you live in a multi generational family scenario...of you're poor. So we'll go ahead and pack our kids into Petri dishes with sports schools and clubs.

**Mel Pino**: So Janice is at the press conference? Huh.

**Mel Pino**: Did you get advance notice of this Jeff?

**Mel Pino**: https://www.washingtonpost.com/politics/with-trump-leading-the-way-americas-coronavirus-failures-exposed-by-record-surge-in-new-infections/2020/06/27/bd15aea2-b7c4-11ea-a8da-693df3d7674a_story.html?hpid=hp_hp-banner-main_virusfailure-735pm%3Ahomepage%2Fstory-ans&itid=hp_hp-banner-main_virusfailure-735pm%3Ahomepage%2Fstory-ans

**Mel Pino**: In case anybody is in the mood for the truth for once.

**Mel Pino**: Keep this to yourself because I didnt have permission to share...Matt Selovers wife has covid. :(

**Mel Pino**: So now she is quarantined and sick and he has no choice but to drop their daughter of at summer camp because they don't have anybody else to take care of her. Thus risking her catching it there and infecting him or infecting his wife.

**Mel Pino**: He told me that he is having to argue with people at work--medics-- who actually believe the fox news misinformation that masks don't help.

**Mel Pino**: Palm Beach County just announced on CNN they are closing beaches for fourth

**Mel Pino**: So glad that DeSantis honored us with his presence today so he could throw us to the wolves up next: a bg announce we are finally going to get our aid money?

**Mel Pino**: Mississippi removing confederate symbol from flag
https://apnews.com/1d4969cb533fb6ab7fe381fb5855c256

### CONVERSATION ON 06-29-2020

**Mel Pino**: https://www.pnj.com/

**Mel Pino**: Jeff, please take time to read this carefully so you understand what I have been trying to convey about this particular monument. I agree with you these things can get out of hand and we need a process to decide carefully on a case by case. But this one has Got to be put somewhere that the context renders it a historical artifact and not something to emulate.

**Mel Pino**: https://www.foxnews.com/politics/florida-doctors-to-jacksonville-mayor-hosting-republican-national-convention-is-medically-disrespectful

**Mel Pino**: https://youtu.be/LkyXhPYbX0c

**Mel Pino**: Please watch this when u have time. It's about 10 minutes long...you might have to swipe away a couple of rounds of ads.

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Nothing urgent I left a message.

**Mel Pino**: I'm so sorry about the funding Jeff. :(

**Mel Pino**: This is solid. Someone tested positive in the clerk's office at 221 palafox. The employee is quarantining. They required people to get tested. I don't know if Clerk put anything out but there was no county announce or warning to people in the main 221 paradox building.

**Mel Pino**: This is NOT solid yet. Awaiting confirm. I believe there was a positive up at the parks facility on 9 mile road. Trying to get confirm. This came from info at the roads camp.

### CONVERSATION ON 06-30-2020

**Mel Pino**: Take a listen to my message on the monument when u can.

**Jeff Bergosh**: Will do.  Buried at work

**Mel Pino**: 👍

**Mel Pino**: I am headed outside for a while to get away from all this craziness. I"'ll be available again in a couple hours

**Mel Pino**: https://www.politico.com/states/florida/story/2020/06/30/desantis-kills-online-learning-program-amid-virus-resurgence-1296178

### CONVERSATION ON 07-01-2020

**Mel Pino**: Heather Lindsay on CNN

**Mel Pino**: Hey I just heard about Doug's response to the hospital administrators. Gonna put in a request for it can you ask Debbie to keep an eye out?

**Jeff Bergosh**: Okay

**Mel Pino**: Just emailed

**Mel Pino**: He's such an asshole and now the hospital administrators are using Underhill as an excuse not to show up

**Mel Pino**: They make enough money they need to show.

**Mel Pino**: This is the QAnon garbage that you guys are going to be bombarded with because Janice didn't provide a way for reasonable people who are staying home to publicly comment like the city does.

**Jeff Bergosh**: I have no responses from Doug to the video

**Jeff Bergosh**: Just checked

**Mel Pino**: No to the hospital letter from the admins

**Mel Pino**: He sent back an email trashing them

**Jeff Bergosh**: I haven't seen a response-- he didn't copy me

**Mel Pino**: Oh of course he didn't. Asshole

**Mel Pino**: Running Doug's program for him. Have no idea if he really has a lawyer. Maybe ed.

**Mel Pino**: I am seeing suggestions of making masks mandatory in businesses and in pic buildings just not outside. 

**Mel Pino**: Sorry public

**Mel Pino**: Posted by arduini

**Mel Pino**: Can u talk on your way home?

**Jeff Bergosh**: Sure.  It will be at 5:30

**Mel Pino**: https://www.pnj.com/story/news/2020/07/01/escambia-county-down-three-icu-beds-area-hospitals/5357371002/

**Mel Pino**: Jim quotes from your coffee

**Mel Pino**: I just got it from a pretty good source that there are 7 positive cases among jail staff but they aren't telling people.

**Mel Pino**: https://weartv.com/news/local/escambia-countys-three-major-hospitals-voice-support-for-citizens-wearing-masks

**Mel Pino**: https://myfox8.com/news/coronavirus/president-trump-says-he-is-all-for-masks-and-that-he-likes-the-way-he-looks-in-one/

**Mel Pino**: You're free Jeff. Desantis will fall in line now

**Mel Pino**: That is in reference to me suspending facebook

**Mel Pino**: This is really what is going on with these crazies Jeff. And this shithead is going to be coming full tilt tomorrow unless the Trump announce took the wind out of his sails.

**Mel Pino**: Email sent. She will now start twisting it around on you guys. That's what she does. She has been doing it her whole life and that's why she has no support in Tallahassee.

### CONVERSATION ON 07-02-2020

**Mel Pino**: Good morning, 52' k new cases in US yesterday :(

**Mel Pino**: https://www.sciencedaily.com/releases/2020/06/200612172200.htm

**Mel Pino**: There are new studies that show it doesn't just protect others but yourself also

**Mel Pino**: https://www.ucsf.edu/news/2020/06/417906/still-confused-about-masks-heres-science-behind-how-face-masks-prevent

**Mel Pino**: That one explains HOW we got so screwed up on masks and has links to other research

**Mel Pino**: https://www.cdc.gov/coronavirus/2019-ncov/prevent-getting-sick/cloth-face-cover-guidance.html

**Mel Pino**: Last one. That CDC page has a bunch of studies listed on why even cloth masks help stop the spread. Whatever you do Jeff, you do not want to go down on video saying you haven't seen any compelling evidence and that you aren't convinced masks work :( you will sound like an alt right conspiracy theorist because that is where that garbage is coming from! The size of the particles etc is all nonsense being pumped out of those horrid conspiracy sites.

**Mel Pino**: Jeff I am listening to your radio interview. There is a BIG BIG difference between being a caregiver that requires an N mask because they are in very close, sustained contact with very sick patients who are coughing, spitting, puking spraying and they have to intubate etc

**Mel Pino**: Totally different scenario than a context of a cloth mask, even ill fitting, to help contain spray and spittle in casual contact such as passing in and out of a store. The cloth masks DO cut down on Transmission in those circumstances. Even talking can pass this stuff with no cloth mask but the cloth CAN be a barrier to letting the virus transit both out and in

**Mel Pino**: For God's sake don't mention the micron thing that is garbage pumped out of alt right sites :(

**Mel Pino**: It doesn't matter the size of the micron if it is carried by a gob of snot or spit. The micron is HOOEY

**Mel Pino**: God that guy is such a dipshit. This is not a "social" issue. What a moron. 

**Mel Pino**: Looks like fire is headed in tonight. Great.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Their message will be muddled and smashed together 

**Mel Pino**: Fucking idiots

**Jeff Bergosh**: 👍

**Mel Pino**: Larry isn't coming today.

**Mel Pino**: https://ricksblog.biz/what-escambia-commissioners-need-to-know-before-covid/

**Mel Pino**: Why are Janice and Alison properly distanced by you guys sitting next to each other with plenty os pace to spread out :(

**Mel Pino**: See how I told you Doug keeps focusing on lanyard now

**Mel Pino**: You forgot shandra smiley

**Mel Pino**: He's so full of shit

**Mel Pino**: I wonder if the jail presentation will fess up to the Z covid cases among county staff.

**Mel Pino**: That's ecat lifeguard and jail I have busted her on.

**Mel Pino**: Is he actually laughing about covid cough? Are you kidding me?

**Mel Pino**: Are you fucking kidding me he actually has a cough? 

**Mel Pino**: https://www.bloomberg.com/news/articles/2020-06-30/florida-covid-19-cases-at-long-term-care-facilities-hit-record

**Mel Pino**: Oh how cute he has a little sheet.

**Mel Pino**: Jeff PLEASE ask him about the science on the masks

**Mel Pino**: This is complete bullshit on this 9 day certainty.

**Mel Pino**: That CDC number of the shedding of replicant virus Is in MILD cases. And they aren't sure.

**Mel Pino**: People hospitalized with serious covid 19 can emit for up to three weeks

**Mel Pino**: People hospitalized with serious covid 19 can emit for up to three weeks

**Mel Pino**: He's lying.

**Mel Pino**: Updated on the CDC website for days ago THEY DONT KNOW. The CDC has some studies showing in Mild cases that 8 or 9 day thing, but they still say they don't know the 14 days is recommended ballpark. And patients in hospital have emitted for us to 3 weeks

**Mel Pino**: It is reckless irresponsibility for him to stand there and twist this at the podium so Robert can shill for tourism

**Mel Pino**: It was also ridiculous that the state DOH told ECAT to only quarantine for 5 days. Why??

**Mel Pino**: Notice that red rising line he skipped right over stopped at June 21

**Mel Pino**: Those were hospitalizations for covid or covidlike he got off that one quick.

**Mel Pino**: Watch him lie.

**Mel Pino**: Hahahaha

**Mel Pino**: See how this goes?

**Mel Pino**: Ask him if the virus is morphing to become more contagious

**Jeff Bergosh**: Lumon asked

**Mel Pino**: Yep and he won't answer unless you guys get him to

**Mel Pino**: https://www.nytimes.com/2020/06/12/science/coronavirus-mutation-genetics-spike.html

**Mel Pino**: It is mutating for the protein spikes to enter cells more easily. It genetically mutated from an absorb acid molecule to a glycine molecule and it became more virulent

**Mel Pino**: Because it is becoming more contagious as well and he damn well knows it.

**Mel Pino**: In other words, just throw caution to the wind and let the kids and coaches get each other sick

**Mel Pino**: Jeff do you understand how absurd this is. Just the height of absurdity.

**Mel Pino**: Lumon is destroying ANY idea these kids should be playing

**Mel Pino**: Fuck him.

**Mel Pino**: Hahahahahahahahaha

**Mel Pino**: He took so many questions with being unprepared that I could answer all of them better as a layperson than he did as the head of Escambia DOH.

**Mel Pino**: He just set it up to close water access points with fake crime

**Mel Pino**: This is a fucking disgusting spectacle. Shame on them I can barely watch thism

**Mel Pino**: They don't have, won't say numbers of county staff positive. And laughing about the lifeguards. Disgusting

**Mel Pino**: Ask about the washing machines!!!!!!!!!

**Jeff Bergosh**: I already have that being worked

**Mel Pino**: See? Busted her cover-up on ecat, lifeguard and now jail and it will continue. And those aren't slips of language that is intentional deception.

**Mel Pino**: Oh awesome

**Mel Pino**: 10k+ new cases in fl today

**Mel Pino**: They aren't seeing them just now. They hide it until we get it busted and then they do a transparency show.

**Mel Pino**: Bam. Ones and twos the last few months. Powell can never stick to the thru lie for her.

**Mel Pino**: Masks are not an issue for us. He'll we don't even use the ones that we have.

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Back at work and we have an underground utility strike in dealing with.....

**Mel Pino**: https://www.texastribune.org/2020/07/01/texas-day-care-coronavirus-cases-rising/

**Mel Pino**: No worries I left you a message 

**Mel Pino**: BLUE ANGELS CANCELLED

**Mel Pino**: Jeff before speaking any knee jer talking points PLEASE consider the direction this is taking. It's basically Robert, crooked DOH and hoteliers now who are still spinning of web that is NOT based in reality

**Mel Pino**: Texas Gov just mandated masks

**Mel Pino**: The count today is WFH 41, SHH 23 and BHC 17. This is the first day ever that the unincorporated hospital had more than the two city hospitals combined. 

**Mel Pino**: Here is what they had playing before the meeting. Very informativem

**Mel Pino**: Doesnt look like he has been caught up in cult conspiracy does he?

**Mel Pino**: She's right about the masks. Everybody in there should be wearing masks.

**Mel Pino**: See what this looks like?

**Mel Pino**: Charlie is absolutely lost to the Q alt sites he probably doesn't even know what he is reading

**Mel Pino**: This is why I am always so desperate that you don't repeat stuff that is being proliferated from those sites. 

**Mel Pino**: Yep. He told you guys it would happen and it did.

**Mel Pino**: Hire him as county administrator.

**Mel Pino**: Waaaaaaaa

**Mel Pino**: Looking around with our own eyes while the kaleidoscope spin in them. Who makes more sesnse. Her or the lifeguards?

**Mel Pino**: Volunteer firefighter who is HUGE in Q stuff

**Mel Pino**: Wait is he professional I always thought he was volunteer

**Mel Pino**: Wait is he professional I always thought he was volunteer. Good Lord even worse on what he posts online

**Mel Pino**: Notice the glowing unreality coming from all of them.

**Mel Pino**: The best place to live during the pandemic. Wow. 

**Mel Pino**: What kind of fucking koolaid do these people drink.

**Mel Pino**: The add campaign should have been running two months ago :(

**Mel Pino**: Mobile county mask ordinance

**Mel Pino**: Sharon Pitts has touched god knows what so you better not wipe your mouth or rub your nose not to mention covid that hasn't been sterilized off with alcohol can live for 78 hours

**Mel Pino**: Sandra smiley

**Mel Pino**: Talking onto their heads

**Mel Pino**: No spit happening there.

**Mel Pino**: This county does not get it, anywhere. 

**Mel Pino**: How do you like the Hitler haircut on my Qanon stalker. Doug feeds him all this.he writes it for him 

**Mel Pino**: Don't get me wrong I loathe this tax grab and will lobby against it

**Mel Pino**: Arduini is also the one that posts anti Semitic materials on David bear.

**Mel Pino**: And then we will include the American flag for yes and dead puppies for no in the ballot language.

**Mel Pino**: No kidding.

**Mel Pino**: Look at the audience with their heads down. They no he's right.

**Mel Pino**: God I hate it when Doug is right.

**Mel Pino**: Oh my god did he really not get that? Haha

**Mel Pino**: I might not understand entirely what exactly will appear on the ballot. But I think she might ave lied in her response to lumon. And I see now Doug got it that was all a set up so he could talk against it and then vote for Julian.

**Mel Pino**: Is Doug pulling.a fast one?? Did you even know about thi Jeff?

**Mel Pino**: Why isn't anybody asking the question how this went on the agenda as d2. This is the stuff that has been going on since Kevin and I aren't paying attention to planning agendas

**Mel Pino**: Lumon just did a huge solid what the hell is up with Jay 

**Mel Pino**: Youre welcome

**Mel Pino**: That was your colleagues helping you people see what's going on jeff

**Mel Pino**: Jeff this is a multi item orchestrated hit on you

**Jeff Bergosh**: Sure but it's not working 

**Mel Pino**: It seems your colleagues recognize it. Now is the time so state how this item has dragged and then the surprise solicitation

**Mel Pino**: No because they are coming to your assistance. They see it.

**Mel Pino**: She is trying to put Doug's firehouse before his

**Mel Pino**: You need to get a commitment right here and now yours goes first

**Mel Pino**: Their eyes are open

**Mel Pino**: Do you see???

**Jeff Bergosh**: It's already done--just that Caro-syrup didn't know it

**Mel Pino**: You have that commitment? Yours first? 

**Mel Pino**: So you see Doug has recruited this guy in my absence.

**Mel Pino**: She knows we won't come to meetings while there are no protocols in place

**Mel Pino**: Oh there we go Wesley job

**Mel Pino**: To act like Tonya needs an escort.

**Mel Pino**: It is just sad what she has done to divide this board.

**Mel Pino**: So many budget and real estate diggers on a sudden with Doug like questions

**Mel Pino**: She has seriously overplayed her hand this meeting.

**Jeff Bergosh**: Been a great meeting for me

**Jeff Bergosh**: Getting everything I want, the way I want it

**Mel Pino**: Like I said you're welcome :)

**Jeff Bergosh**: Not good night for Doug and his secretary

**Jeff Bergosh**: 😎👍

**Mel Pino**: Who do you think filled them in on what they were going to bring? :)

**Mel Pino**: In terms of  bullshit.

**Mel Pino**: Steven has worked so hard on this for so long

**Mel Pino**: Outskirts and under them

**Mel Pino**: Omg :(

**Mel Pino**: Alison just made eye contact with Doug while Steven was talking

**Mel Pino**: PUBLIC SAFETY ISSUE

**Mel Pino**: PUBLIC SAFETY ISSUE

**Mel Pino**: This is missing. 

**Mel Pino**: Alison and Doug are texting back and forth like mad

**Mel Pino**: That's why she won't turn around when she is talking with steve

**Mel Pino**: Nice.

**Mel Pino**: Janice happened as of late

**Mel Pino**: JEFF BE ON BOARD

**Mel Pino**: Lumon brought it

**Mel Pino**: End of the meeting https://photos.app.goo.gl/yTJqnfPWaVQMG61aA

**Mel Pino**: Doug and janice

### CONVERSATION ON 07-03-2020

**Mel Pino**: Jeff this is the last I will bug you over the holiday but this was too important not to pass on immediately. I just learned this morning for the first time that the city has been running their own dashboard with accurate local data that they are getting from daily communication with local hospitals. I don't know WHY Grover never told me this. Maybe he figured I knew. I don't know of anybody who was aware of it. I emailed it in to the board and Gilley.

**Mel Pino**: https://ricksblog.biz/escambia-county-has-81-covid-patients-in-local-hospitals/

**Mel Pino**: This finally reveals the game that Gilley and lanza have been running. This is why the county Cant get info out of the hospital admins. Gilley has been blocking the information and lanza and DOH have been conducting a terrible cover-up so Escambia would stay open as long as possible.

**Mel Pino**: https://ricksblog.biz/covid-cases-exploding-in-panhandle-esc-157-sr-67-okal-50/

**Mel Pino**: You and Sally PLEASE BE SAFE this weekend. This thing is for real Jeff and it is going to get very bad.

**Mel Pino**: There is another positive case at ecat

**Mel Pino**: In addition I think the deputy transit manager (whatever the he'll that is) is also sick and quarantining

**Mel Pino**: Sorry Jeff just tacking this on the the info that I think this has spread all over Public safety. I know you are trying to be on holiday but I also know you don't want to be caught unawares again

**Jeff Bergosh**: Thx

**Mel Pino**: This is as firm as I have public safety so far. 1 positive fire. 1 quarantining with positive wife. Ems has a few positives and as many as 10 quarantining awaiting results. 2 fire companies were exposed with Gilley doing nothing. Rogers jumped in and handled it. Williams is out sick. Some dispatchers sent home.

**Mel Pino**: From a good source; I have information from a friend at the Sheriffs office - units are running on skeleton crews like the drug enforcement unit.  Under cover unit for Drugs is closed.  Deputies are being sent home.  My source is a 20+ vet.  Now they are pushing people to wear a mask - finally....

**Mel Pino**: Catholic priest in Foley testd positive and dispensed communion  this past weekend.

**Mel Pino**: Hundreds of people starting to pack in to Mount Rushmore to give each other coronavirus and celebrate the Republican party transforming into a cult. Q flags proudly waving.

**Mel Pino**: Jeff PLEASE for once listen to me. This thing is raging out of control. City first responders in trouble. ECSO 20 men down and going. Ems at breaking point already. Spreading like wildfire in public safety.  DO NOT post any personal celebration photos. Not at home, not out. Nothing showing you guys raising drinks or relaxing. For God's sakes not relaxing. I hope you get what I'm saying. No grill out photos, no happy "here we are having fun photos" let Robert answer for this you don't need to produce documentation of unconern. 

**Mel Pino**: This post something somber, reflective, prayerful. If its a personal photo of you and Sally great but just make it reflective not joyous.

**Mel Pino**: I can't see what you are posting on your personal site any more since I  put my account on suspend. I hope there aren't a bunch of "hey it's great to get the the fourth" photos

**Mel Pino**: Also these are the memes circulating. I did not make this

### CONVERSATION ON 07-04-2020

**Mel Pino**: Jeff Alex arduini has posted your commissioner page as being related to one of his q pages. Alex and Dana arduini discovering the TRUTH is the name. You need to get your page blocked from his sites. He roped chip in as well.

**Mel Pino**: FYI - Arduini's watch party for Trump's speech last night, included Jacqueline & Mike Hill.  
And read those 2 screenshots, they truly thought trump was going to announce JFK Jr as his running mate 🤣🤣🤣

**Mel Pino**: Sorry to bother you on fourth. Somebody just passed that to me and I will lose track as fast as my phone is blowing up. Yes they actually believe that crap.

**Mel Pino**: https://www.forbes.com/sites/jackbrewster/2020/06/20/eric-trump-promotes-qanon-conspiracy-on-instagram-while-plugging-tulsa-rally/

**Mel Pino**: Doug actually believes some of this crap. That's why it popped out of his mouth that Dianne is antifa. He is reading on those sites all the time and that is how he hooked up with arduini.

### CONVERSATION ON 07-05-2020

**Mel Pino**: Check out this article from Pensacola News Journal:

38 more inmates at Escambia County Jail test positive for COVID-19

https://www.pnj.com/story/news/2020/07/05/covid-19-38-more-inmates-escambia-county-jail-test-positive/5380022002/

**Mel Pino**: I was pounding on this in the background which is probably why Janice brought Powell to try to damage control. There is no more controlling this. :(

**Mel Pino**: You guys need to remove Gilley from being in charge of public safety and advance Jason Rogers to being autonomous. This situation needs an emergency meeting immediately :( I hear excellent things about him from staff. 

**Mel Pino**: https://www.nbcmiami.com/news/local/florida-health-officials-say-antigen-test-results-will-be-included-in-future-covid-reports/2258039/

**Mel Pino**: Of course. They don't have many data corruption and manipulation plays left. So now they are going to include antigen tests in the mix rendering the count for live positives effectively useless, if they don't separate the two things out. It could also mess with the percentage of positives and drive it down. The antigen tests are not reliable in any case. 

**Mel Pino**: Or, they just slipped that bit in on the antigen tests to make the numbers less serious and they aren't even doing it. Who the hell  knows

**Mel Pino**: Heads up

**Mel Pino**: Edler and Haines arguing

**Mel Pino**: https://www.miamiherald.com/news/local/community/miami-dade/article244014172.html

**Mel Pino**: South Florida worst in nation for food scarcity as a result of the coronavirus

**Mel Pino**: So arduini is stepping his toe in the water of being a Q prophet now.

### CONVERSATION ON 07-06-2020

**Mel Pino**: Call when u can vert importabt

**Mel Pino**: 2 confirmed cases of covid beyond the initial case at ECAT. 1 of them a bus driver at the beach who was very ill. The other they have not released for staff knowledge the positive test and are not contact tracing as far as I know. 2 more employees out sick with covid symptoms and are waiting to be tested today. 1 probable in ITL who transported southern Oaks patients among other facilities. Home quarantined awaiting test results. Still no mask mandate at the county.

**Mel Pino**: Hospitals are now telling positive cases they will not be admitted to the hospital for any other symptoms than dire difficulty breathing.

**Mel Pino**: https://www.nbcmiami.com/news/local/restaurants-gyms-shutting-down-again-in-miami-dade-due-to-florida-covid-spike/2258327/

**Mel Pino**: :HR dept is empty today?

**Mel Pino**: https://www.pnj.com/story/news/coronavirus/2020/07/06/florida-coronavirus-cases-deaths-hospitalizations/5382351002/

**Mel Pino**: Scroll down for this graphic. Number of deaths in Florida.

**Mel Pino**: https://www.clickorlando.com/news/local/2020/07/06/gov-ron-desantis-in-central-florida-after-record-weekend-of-new-covid-19-cases/

**Mel Pino**: "Since the outbreak began, 30 Florida's have died per day from the virus--and that number has been rising, averaging 43 deaths per day over the last two weeks.

**Mel Pino**: https://www.pnj.com/story/news/2020/07/06/healthy-milton-teen-fighting-her-life-covid-19/5384780002/

**Mel Pino**: 16. No underlying conditions. Has been in a medically induced coma on a ventilator for 9 days.

**Mel Pino**: Pensacola little theater just cancelled summer production.

### CONVERSATION ON 07-07-2020

**Mel Pino**: If they can't strike they may just quit so the salaries were enticement to stay. He already knew he was going to do this then and he is running a Trump playbook for desantis 2024. Good luck with that.

**Mel Pino**: The driver at ITL paratransit was positive.

**Mel Pino**: Desantis has forbidden mayors  from hiring their own contact tracers. Only DOH can contact trace.

**Mel Pino**: So let me get this straight. We paid blue Arbor 2.2m since October 1 of last year. Gilley sole sourced the contract on a quarter of a million dollar awareness campaign that came three months too late. (What is the connection with the woman who got the contract?). There had been an offer for FREE training on specialty infections that never made it to an agenda item. Then a mess of an RFP to just beef up janitorial? Sounds about right.

**Mel Pino**: Also, neighborhoods does share a suite with HR and they were not notified there was a positive covid case in the suite. Instead Jana had her own staff stay home and neighborhoods showed up to work unawares. 

**Mel Pino**: Here is what I know about Covid and HR. One employee there tested positive. Employees were given option of taking leave, working from home or coming in. I understand 2 employees have volunteered to come in and bare bones staff office. I do not know how long folks will be out to complete the 2 week isolation

**Mel Pino**: WHY WERENT NEIGHBORHOODS OFFERED THE SAME?? They share a suite! Does risk management know?they are in there too

**Mel Pino**: We could be 20 cases in mobile Wal-Mart staff and 5 in Creighton. We are completely at the mercy of Doug in district 2 with no ordinances

**Mel Pino**: I am being sent these they aren't my marks

**Mel Pino**: Doug put a video of you bashing the press at the last meeting because he knows they were right. He's acting like he applauds you but the video is there now as this gets worse. Doug knows exactly how bad this thing is going to get now. He is already pivoting and will be saying soon that he forecast how bad it was going to be.

**Mel Pino**: Rick Outzen has posted the numbers for the county as of the day of the last meeting. They are of course higher already, but what Janice didn't want to say publicly on Thursday was that we already had 22 positives, 44 waiting for results, 17 quarantine, and 15 on extended leave. He also posted the astronomical rate of spread in different areas of the county. North Escambia has seen a one hundred percent rise in one week. West Pensacola 92 percent. Etc. Okaloosa medical director just sounded the alarm bell that they are out of room in their hospitals. WEAR reporting 2 new deaths and 41 inmates positive with "most" not exiting symptoms. They made sure to underline that the county says they aren't testing asymptomatic inmates. Stories popping various places about teens dying. People's immunity might be falling off after 3 weeks with the potential to get reinfected. The case positivity rate is skyrocketing. We have the highest cases among 0 to 19 ever. 

**Mel Pino**: On Rick's post about county staff covid numbers.

**Mel Pino**: Icu's in 43 Florida hospitals full

**Mel Pino**: For some people it seems like the linke is broke.

https://www.youtube.com/channel/UCM0ZF1oYz619gsZl2I_kp9Q

**Mel Pino**: Here is what you have on your hands, Jeff. You can start looking with your eyes or you can keep drinking the koolaid. At some point, a real leader's responsibility is to figure out when he is being lied to. Accepting the words of liars and hiding behind them won't afford plausible deniability on this. You are being lied to. All of us are. Until people understand desantis is running this game for Trump and silly does not care about the death and chaos that ensue, we will never get anywhere.

### CONVERSATION ON 07-08-2020

**Mel Pino**: https://ricksblog.biz/covid-escambia-hr-animal-shelter-have-it/

**Mel Pino**: I do not know what Rick is going to post. But I am going to continue to make use of it when I can, because I am trying to save lives. A lot of people are trying to save lives.

**Mel Pino**: This on the CDC page
https://www.cdc.gov/coronavirus/2019-ncov/community/office-buildings.html
Guidelines for even HVAC inspection and certification

**Mel Pino**: Mike is a member of ACS. This is the best infographic overview of COVID-19 testing
https://cen.acs.org/analytical-chemistry/diagnostics/Periodic-Graphics-guide-COVID-19/98/i25

**Jeff Bergosh**: Thanks for forwarding this!

**Mel Pino**: I put it through some people who really get this stuff and they said it's spot on (including Mike, who used to be a chem major)

**Mel Pino**: https://ricksblog.biz/escambia-county-government-8-more-positives-12-more-waiting-results/

### CONVERSATION ON 07-09-2020

**Mel Pino**: Check email, call chip and get your administrator and attorney under control. Jeff.

**Mel Pino**: Janice's number 1 fan kicks off the budget talks.

**Mel Pino**: https://www.nytimes.com/2020/07/09/world/coronavirus-updates.html

**Mel Pino**: Gee I guess the WHO finally figured out there's no appeasing Trump so might as well tell part of the truth. Here's the more accurate rundown of where this stuff is airborne: EVERYWHERE. Including outside. It absolutely defies common sense that it would be airborne indoors and not be carried on the wind. Of COURSE it is. Never in my life did I ever dream I would see so many smart people just loose all touch with common sense.

**Mel Pino**: Today EMS is running 8 ALS and 4 BLS tricks. They are supposed to have 17 ALS trucks. 

**Mel Pino**: https://news.yahoo.com/florida-sheriff-wins-battle-with-de-santis-administration-over-coronavirus-data-174305203.html

**Mel Pino**: Do you know why he had to go to war with him? Because desantis is lying and hiding and manipulating data.

**Mel Pino**: https://www.pnj.com/story/news/crime/2020/07/09/71-escambia-county-jail-inmates-had-tested-positive-covid-19-thurs/3286835001/

**Mel Pino**: Powell at a loss for words to describe how contagious this is. Maybe you guys will believe him, now that his smug swagger is out the door? Because I distinctly remember calling his complete bullshit on "we've dealt with cholera" months ago. I told all of you that the fact that he would even say such a thing showed he had NO idea what he was dealing with. THIS IS NOT ROCKET SCIENCE.

**Mel Pino**: Escambia county ems can't staff tomorrow. Santa Rosa lifeguard sent the call out for volunteers from over there to work in Escambia tomorrow. They cannot sustain this. Even with 17 to 19 trucks that was already putting them on hold times some time and they couldn't keep enough medics to put more trucks out because nobody wanted to work for Escambia and everybody who could get out did. They are now running only 8 to 12 als trucks on average and the lowest of 6. Now the only hope is that Santa Rosa lifeguard can sustain both counties. The answer to that is not for long.

**Mel Pino**: Just suspended road crews. 
That will be at least another 30 before all is said and done, if they don't lie like some other departments are doing.

### CONVERSATION ON 07-10-2020

**Mel Pino**: Laura and Janice need to make the presser AVAILABLE LIVE TO THE PUBLIC ON ECTV. There is no reason they can't limit the QA to the credentialed press but make it live viewable to the public on ectv. There is still time.

**Mel Pino**: Jeff, I am not blowing smoke. One of the things people truly love about you is transparency. You are known as the transparency commissioner. PLEASE don't lose that trait when we need it the most. Don't ask, demand that they facebook live that press conference. Then you can put up a blog with the link and say that you ordered it. That is a huge win.

**Jeff Bergosh**: Working it

**Mel Pino**: THANK YOU

**Mel Pino**: We are in

**Mel Pino**: I understand why Rogers has to do this but it is bullshit. They were at 8 yesterday and the lowest 6.

**Mel Pino**: Oh great. So keep advancing people to medic. Because we can't hire them.

**Mel Pino**: "Wasn't that important to do that." Right.

**Mel Pino**: "None of us could have even remotely imagined." Then they all need to be fired.

**Mel Pino**: Tell Gilley there are people videoing this so she can do it right or it can get released through other channels

**Mel Pino**: They have continued to work in life threatening conditions because she made them.

**Mel Pino**: Robert covering.

**Mel Pino**: Bullshit. You know that's bullshit about the offices

**Mel Pino**: Why is Janice laughing? Is this funny?

**Mel Pino**: Because there aren't enough medics. Already.

**Mel Pino**: "We don't think this is going to end any time soon." That's an understatement.

**Mel Pino**: Oh Andrew gets a second one!

**Mel Pino**: The company that will be acquiring our EMS if it falls apart.

**Mel Pino**: You can't contact trace jail.

**Mel Pino**: Thats a lie. Those tests were not all negative.

**Mel Pino**: That's it. I'm done. Good luck with it, Jeff.

**Mel Pino**: Thank you, Jeff.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Was it on Facebook?

**Mel Pino**: No but they did announce they are making it public. Thank u

**Mel Pino**: I sent a follow up email responding to the presser.

**Mel Pino**: This is Corpus Christi. Port and military town with similar population to Escambia. The naval air station receives many of ouflight students and a lot of interchange with Whiting field and NAS. https://www.myhighplains.com/news/texas/coronavirus-deaths-overwhelm-texas-morgue/

**Mel Pino**: https://www.krgv.com/news/despite-warnings-about-the-coronavirus-south-padre-island-beaches-packed-on-fourth-of-july-weekend/

**Mel Pino**: https://weartv.com/news/local/escambia-county-partnership-ensures-no-shortage-of-first-responders-amid-covid-19

**Mel Pino**: See how that works?

**Mel Pino**: https://floridapolitics.com/archives/348125-ethics-elections-complaints-filed-on-cris-dosev-in-hd-2

**Mel Pino**: I sent a last email for now on that big string. Who knows how many people will take the time to read. I covered the misinformation in WEAR. I found out just after that they are having to offer incentive pay in addition to the overtime to get medics to come staff Escambia county. There are a number who couldn't be bought with gold to come over here right now.

**Mel Pino**: Think on the irony that Escambia county is now begging all the people it chased off to Santa Rosa to come back and help. It makes me sick.

**Mel Pino**: City is shutting down community centers.

**Jeff Bergosh**: Yeah I saw that

**Mel Pino**: But we are going to send our kids back to school with mounting evidence of lung damage in seemingly asymptomatic kids.

**Mel Pino**: I sent a follow up addressed to Jacqueline.

### CONVERSATION ON 07-11-2020

**Mel Pino**: Jeff I am getting ready to post a three parter on your blog in which I praise your leadership but tell you I don't agree with your mask stance and why.

**Mel Pino**: 4 parts posted. I really hope you will put it all up as soon as possible because this thing is going to require hashing and arduini is probably going to bomb the comments.

**Mel Pino**: Thank you. We are running out of time, Jeff. It may be too late already.

**Mel Pino**: I answered Jimmie. This is so incredibly painful.

**Mel Pino**: You liked a post from a person you know has stalled my house?

**Mel Pino**: Wow.

**Mel Pino**: Stalked.

**Mel Pino**: And put up anti Semitic imagery against David bear and talks about him being a corrupt money lender?

**Mel Pino**: I am so hurt, sickened, disgusted, and angry I am beside myself right now. I am in utter disbelief you would do that.

**Jeff Bergosh**: ????? What post??

**Mel Pino**: On the post where it seems like you just hid Kim Carmichael 's posts. 

**Jeff Bergosh**: I don't hide any posts-- she must have used a word my settings didn't allow

**Jeff Bergosh**: I'll in hide it if it's hidden

**Mel Pino**: Know she didn't Jeff. She used to be a supporter and think the world of you. What is happening to you?

**Mel Pino**: I am just heartsick. I have cried off and on today since I saw your like. And now this. On a day I publicly praised you for being the transparency commissioner and wrote and email to the PNJ telling them they needed to be focused on Gilley.

**Jeff Bergosh**: I don't like that guy-I believe he is trouble.  I know he supports Owens.  But I can "like" a comment?? Sheesh?!? Come on???

**Jeff Bergosh**: Think of all the likes you gave a guy like Derek Cosson-- a guy who constantly ran me down and called me "bought and paid for". Think.  I can't get ruffled by that.  I can think of other examples as well. 

**Mel Pino**: He is a dangerous petty criminal and meth addict. He is the avowed member of a cult that has been deemed domestic threat by the FBI. He has stalked my house, he has sent a Q train by it, and he has repeatedly posted anti semitic comments to David. Why do you not have him blocked from your pages already?

**Mel Pino**: I told you why I was liking Derek's posts. Derek may be a POS but he didn't stalk your house, post anti semitic comments, and post threatening call outs on you nationally like he has done with David, me, and others.

**Mel Pino**: ALEX ARDUINI IS DEFINED AS A DOMESTIC TERRORIST BY THE FBI. Why do you allow a terrorist to post on your page?

**Mel Pino**: I just posted. My faith is shaken and I really need you to put it up with no foot dragging. Jeff.

**Mel Pino**: Jeff they understand Facebook algorithms better than you do. By allowing arduinis comments and liking them look what shows up on the right. "Related pages" are Alex arduini and Jonathan Owens. They are gaming you. I am a faithful friend Jeff and I am TRYING to get across to you how badly you are being played. You do not have this.

**Mel Pino**: Please listen to my messages. Very important.

**Jeff Bergosh**: Having dinner at Yacht club

**Mel Pino**: Great for you. Congrats.

**Jeff Bergosh**: ???????

**Mel Pino**: Hopefully you won't get covid there because we really need you to live.

**Mel Pino**: I mean, really need it. 

**Mel Pino**: Over in St John's county, near Jacksonville, county commissioner who voted against mask ordinance in hospital with COVID-19

https://www.newsweek.com/florida-county-commissioner-who-voted-against-masks-hospital-covid-1517121

**Mel Pino**: Hope nobody in the kitchen has it. Hope your server doesn't have it. Hope the buoys dont have it. Hope the bartender doesn't have it.

**Mel Pino**: I am a full voting member there and havent been in since covid. I recently begged Alan to do something about the club staying open.

**Mel Pino**: This isn't a game Jeff. This is coming from a friend who loves you and a citizen who needs you. 

**Mel Pino**: Thank you for posting. I will leave you alone now and just hope to god you and Sally don't run up against covid tonight. Hopefully we can talk tomorrow.

**Jeff Bergosh**: 👍

**Mel Pino**: I forgot one of the most important ones Jeff. Cops. Please post my follow up on our deputies and "natural selection"

### CONVERSATION ON 07-12-2020

**Mel Pino**: I just posted. I am trying to help you but asking questions that will allow you to articulate your position outside of this mask nonsense, which could bite you in the ass in the end.

**Mel Pino**: Help you BY asking questions.

**Mel Pino**: Just posted my last response to the blog. BTW the medical examiner is backed up and can't maintain the 78 hour turnaround and they are refusing autopsy demands on "natural causes" by families. There's another effective way to try to stem the death rate. Won't matter in the end.

**Mel Pino**: And I meant my final response on that post. 

**Mel Pino**: Jeff Please post my comment. This juncture has been very painful for me. I just want it over with. Once you post it and I let you have the last word, I am going to copy our back and forth and Send it in to the bocc. As painful as it was for me, I still think it's an important exchange and people should consider it.

**Jeff Bergosh**: Got time for a call?

**Mel Pino**: I responded to theresa

**Mel Pino**: Put it up it helps

### CONVERSATION ON 07-13-2020

**Mel Pino**: Morning, can you hold my comment to Theresa? It was a drunk dial. Whatever the he'll I said, I can say it better later :)

**Jeff Bergosh**: Didn't see it yet unless I approved it last night

**Mel Pino**: Woops already up no worries. It's not as bad as I thought it might be haha

**Mel Pino**: I'm responding to the anonymous comments

**Mel Pino**: Posted. I think it's a really good thing for people to see some amicability between Theresa and me on your board right now. It speaks well to it being an important forum. That had to be a tough pill for her to swallow doing that.

**Mel Pino**: Take the second one corrected a typo. Thank u!

**Jeff Bergosh**: 👌

**Mel Pino**: Matt Selover has covid symptoms. He is scheduling his test

**Mel Pino**: https://www.wfla.com/community/health/coronavirus/florida-records-more-new-covid-19-cases-than-all-of-europe-combined/

**Mel Pino**: Personal thoughts from someone close to me.

Immunity is short lived. We need to contain the spread of the virus vector and put more energy toward antivirals, new filtering technologies for HVAC, and protective coverings for mouth/nose/eyes for people who have to be out and about (face shield, masks)

https://www.technologyreview.com/2020/07/13/1005103/immunity-to-covid-19-could-disappear-in-months-a-new-study-suggests/

**Mel Pino**: And you need to check Rick's blog as soon as you have time :(

**Mel Pino**: The USA is now the scourge of the world. All it took Trump was one term.beyond being heartbreaking this also has immediate and grave military ramifications. If this keeps going it may not just be civil war we have to worry about.

https://www.commondreams.org/news/2020/07/13/extremely-regrettable-okinawa-governor-rips-us-letting-covid-19-infections-surge

**Jeff Bergosh**: That ricks article is a bullshit deal that ZIP Code is the largest ZIP Code in Escambia county therefore it's proportional

**Jeff Bergosh**: By all means feel free to check out what I've told you and then hopefully you'll tell him

**Mel Pino**: So respond to the blog, Jeff. I'm tired of having arguments about how this is personally affecting you while Escambia goes up in flames.

**Jeff Bergosh**: Nah, not worth my effort.  Propaganda rag is what that blog is.

**Mel Pino**: Not much does seem worth the effort these days, Jeff. If you ever read what I post there, I have always put the heat towards Gilley. But the citizens are starting to boil over right now. And if what is important to you right now is the campaign, you might want to start doing the arithmetic on the covid impacts to your district by the primary. I truly believe you fail to grasp the depth of the screaming crisis we are in right now. It does not get better from here.

**Mel Pino**: https://www.pnj.com/story/news/2020/07/13/pensacola-attorneys-seek-pause-person-court-proceedings/5416398002/

**Mel Pino**: There is a Dept shut down from corona at Eglin. DOH coronavirus testing booked out today. 

**Mel Pino**: Arduini is claiming conflict of interest on health and hope Clinic and rattling on about it in advance of the absurd budget meeting that is taking place unnecessarily.

**Jeff Bergosh**: I'll have to recuse and it won't be a conflict of interest

**Mel Pino**: Of course. He is beating it nonetheless.

**Mel Pino**: Allegedly the story for the budget meeting is that no staff will be required and Janice is going to handle it with Wesley the ecat enforcer and drum marjorette. Ought to be a hoot. Apparently new budget woman isn't starting til august. Total waste and risk for nothing.

**Mel Pino**: Wesley won't wear masks in meetings.

### CONVERSATION ON 07-14-2020

**Mel Pino**: https://www.msn.com/en-us/video/news/with-hospitalizations-rising-florida-governor-calls-in-3000-nurses-to-help-manage-covid-19-cases/vi-BB16Iscl

**Mel Pino**: So now we are going to swing it from beds to nurses. 

**Mel Pino**: It would be more emblematic of his leadership if he sent a clown car to dump out at the entrance of every emergency room in the state of Florida.

**Mel Pino**: With my comment on today's budget workshop

https://ricksblog.biz/covid-continues-to-spread-in-county-government/

**Mel Pino**: Feel like I got hit by a truck. Gotta take Tylenol every 4 hours just to keep my fever down. 

**Mel Pino**: Matt selovers response to me asking how he was doing this morning

**Mel Pino**: Be careful that range sends bullets into people's back yard

**Mel Pino**: A staff member upstairs can't get the meeting up. Texted me to see if it was even on.

**Jeff Bergosh**: Thx-- thought we were live

**Mel Pino**: You are. At least one staff member can't get it upstairs who needs to be watching it. Please say something

**Mel Pino**: Its fixed

**Mel Pino**: You guys better expect freezer trucks for bodies added into the budget.

**Mel Pino**: OMG SHE IS RUNNING DOUG'S DISCRETIONARY ATTACK FOR HIM??

**Mel Pino**: Hahahahahahahahahahaha

**Mel Pino**: A purposely inefficient system

**Mel Pino**: Yep. Choke staff and grow the salaries for managers.

**Mel Pino**: OMG. Theft.

**Mel Pino**: He is going to do everything he can to blow this board up.

**Mel Pino**: Doug. 

**Mel Pino**: Yep. Just keep pushing those EMT's up because we can't hire medics into Escambia county.

**Mel Pino**: How about the fraud with the 700 dollar washing machines purchased for 4000 dollars?

**Mel Pino**: Oh great. Real estate under Wes Moreno. That bodes well.

**Mel Pino**: Remind Doug there is no money for bridges because he wiped it out on corry field bridge

**Mel Pino**: Maybe the city is behind on permitting because they are focused on covid. Nasty move on Roberts part.

**Mel Pino**: Another deputy director. 

**Mel Pino**: This is the worst display of ineptitude I have ever seen at a county meeting.

**Mel Pino**: Or we could just have staff that give a shit.

**Mel Pino**: Here are the current Sacred numbers

76 in patient for covid 
2 others they are monitoring 
13 of them in ICU
6 of those on vents. 
 I also know one of the patients is only 6 days old 😥

**Mel Pino**: https://ricksblog.biz/wfh-statement-to-ensure-our-readiness-as-we-monitor-the-capacity/

**Mel Pino**: 38 year employee of the county who had just done his buyout and retired. 

Dear Brothers & Sisters,

Today I spoke with James McIntyre's wife Carol today.  Sadly she's reported to me he is in ICU on a ventilator at Sacred Heart Hospital with COVID-19.  His condition is extremely serious.  I first ask each of you to send prayers and keep your thoughts with James, his wife, and his family.  I also ask that we as members cover his last 3 months Union dues that he was scheduled to pay prior to becoming a Union pensioner and going forward as well.  Therefore allowing him and wife to continue to maintain his Union death benefit.  Without objection the Union will deduct this from our General Fund.

Again, our thoughts and prayers are with Brother James.

With deepest concerns,

Mike

**Mel Pino**: Sacred and ascension will apparently keep up the misinformation campaign for elective surgeries until their staff is on their last leg.
 https://ricksblog.biz/category/news/politics/

**Mel Pino**: https://www.pnj.com/story/news/2020/07/14/pensacola-federal-courthouse-closed-public-indefinitely-due-covid-19/5434674002/

**Mel Pino**: 99 percent sure this is the guy that led the QAnon parade arduini dog whistled past my house.

**Mel Pino**: I'd imagine he is probably against a mask ordinance.

**Jeff Bergosh**: Wow!

**Mel Pino**: https://www.wsj.com/articles/this-is-not-a-normal-recession-banks-ready-for-wave-of-coronavirus-defaults-11594746008

**Mel Pino**: 28B doesn't even begin to scratch the surface.this is just the first round of ten percent as bad debt.

**Mel Pino**: The Latin American banking system could collapse.

**Mel Pino**: You just can't write this.

**Mel Pino**: Why do I get the feeling there won't be any behind the scenes coverage of how they are dealing with this.

### CONVERSATION ON 07-15-2020

**Mel Pino**: https://www.fox35orlando.com/news/at-least-31-percent-of-children-tested-in-florida-are-positive-for-covid-19-report

**Mel Pino**: Because they have to because they won't get help from desantis because he doesn't want more testing.

**Mel Pino**: That woman is angry and can barely stomach having to talk with you guys as if you had some sense, Jeff.

**Mel Pino**: These poor people who are down in the trenches against this with zero understanding help or policy.

**Mel Pino**: She just touched the podium after Connie was at it and the reached under her glasses to rub her eye. 

**Mel Pino**: We are so very, very far behind here in understanding how this disease transmits

**Mel Pino**: Tightening our belt by allowing Janice to build up hundreds of thousands of dollars of bureaucracy of self protective layers of accountability.

**Mel Pino**: Fyi I just retained will Dunaway and Meredith Crawford to protect navy point park.

**Mel Pino**: https://ricksblog.biz/teachers-afraid-of-dying/

**Mel Pino**: And another 30 percent for passenger trains. He ought to have a car named for him.

**Mel Pino**: 🙂

**Mel Pino**: DAMN HIM

**Mel Pino**: That was awesome.

**Jeff Bergosh**: Thx

**Mel Pino**: https://www.wsj.com/articles/walmart-to-require-face-masks-in-all-u-s-stores-starting-july-20-11594824256

**Mel Pino**: Notice she only said the support of commissioner may.

**Mel Pino**: "Increase visitation to the county" what a splendid idea.

**Mel Pino**: We have to figure out ways to transition our economy jeff. This thing isn't going away

**Mel Pino**: The fascist, dictatorial, criminal misinformation and data manipulation continues.

**Mel Pino**: Hahahahahahaha perdido fish tank

**Mel Pino**: What else does Doug get besides expensive fish tanks?

**Mel Pino**: After he scuttled the last one for the insurance money.

**Mel Pino**: Love watching that guy stand up to doug

**Mel Pino**: Oh great. Another speck in Doug's grey matter.

**Mel Pino**: Thank goodness. Somebody at the base must have gotten hold of him.

**Mel Pino**: Poor Cadillac right as he was gaining steam :(

**Mel Pino**: I love it when she talks to Doug like he is 12

**Mel Pino**: Doug knows this. He is just problematicizing because he is getting ready to flip his script and be the covid superhero

**Jeff Bergosh**: He's a moron

**Jeff Bergosh**: Not fooling anyone.  Being in his presence gives me a migraine

**Mel Pino**: Cadillac is right

**Mel Pino**: Jeff an honest question. If he brings in 500k (I don't know what the numbers are) who cares if 150k in taxes supported it? I don't get this.

**Mel Pino**: Doug can even be behind and alongside at the same time.

**Mel Pino**: THANK YOU

**Mel Pino**: https://ricksblog.biz/pensacola-msa-in-top-20-metro-hot-spots-for-covid/

**Mel Pino**: I love this new visit guy

**Mel Pino**: Have any questions left that she is team Underhill?

**Mel Pino**: Have any questions left that she is team Underhill?

**Jeff Bergosh**: Team "unemployed" if it's true

**Mel Pino**: It's true. And at this point with the way everything is going there won't be an aspect of her employment that doesn't require termination. And yes I can say that without it being tortious interference, as the courts have ruled, because she if a government official and I am a citizen exercising my free speech.

**Mel Pino**: https://dothaneagle.com/news/government/update-alabama-to-require-face-masks-as-coronavirus-surges-in-state/article_0ff51205-18fe-5dae-9a44-93d39e5c031b.html

**Jeff Bergosh**: Somebody needs to tell Alex his boy, Doug's Secretary, is trailing Jesse Casey by 15 points.............for second place 😎

**Mel Pino**: Tracy Olson McAdams is making mince meat out of him. 

**Jeff Bergosh**: Good!

### CONVERSATION ON 07-16-2020

**Mel Pino**: I just skimmed the rest of the agenda. Maybe it could be discussed affording Jason Rogers more autonomy during the extension of the state of emergency. Janice should not be in charge of our public safety any longer.

**Mel Pino**: Oh I see she has Eric Gilmore in charge of of the quarterly grants to ems. Is that normal? (Honest question)

**Mel Pino**: God we somehow forgot about public forum. Who just spoke?

**Mel Pino**: Wow

**Mel Pino**: They don't even know if the vaccine is going to work. There might not be enough immunity to it

**Mel Pino**: We're doing great! We just have an 800percent increase need for plasma.

**Mel Pino**: We're doing great! We just have an 800percent increase need for plasma.

**Mel Pino**: Yes you have the antibodies which can save lives but the antibodies are disappearing in some people as soon as three weeks and average immunity might be three months

**Mel Pino**: Jeff who was that speaker you were addressing when we turned on?

**Mel Pino**: "Admit to what race they are" ??????

**Mel Pino**: Fucking liar.

**Mel Pino**: Really? Because Powell just said that they WERENT reporting

**Mel Pino**: Did you hear that? They count multiple negatives but only 1 positive.

**Mel Pino**: Lie lie lie lie lie

**Mel Pino**: Bed space doesn't matter. They are closing off whole floors and regardless of bed space those beds cannot be used for anything but covid.

**Mel Pino**: https://www.newsweek.com/antibody-coronavirus-immune-response-months-1517528

**Mel Pino**: Immunity may not last more than a couple of months which threatens the efficacy of a vaccine and herd immunity

**Jeff Bergosh**: Nick Gradia

**Mel Pino**: Figures

**Mel Pino**: What a loser

**Mel Pino**: Watch him dance. 

**Mel Pino**: So much good news

**Mel Pino**: So much good news. I'm glad he is going down with all these lies. It is not the BOCC's fault he has been lying

**Mel Pino**: Oh my god

**Mel Pino**: "When I reach out to black community when I am campaign because that is the only damn time I ever do"

**Mel Pino**: Told you he was going to flip his script. Now he's a damn covid hero.

**Mel Pino**: https://www.foxnews.com/health/over-31-percent-florida-children-tested-florida-positive-covid-19-report

**Mel Pino**: He's messing with the denominator

**Mel Pino**: He's fucking with the difference between mortality and morbidity

**Mel Pino**: That's not what is says. The opinion is that the risk to their overall health is greater than the risk of covid

**Mel Pino**: They rarely transmit PROVIDED THEY FOLLOW SOCIAL DISTANCING GUIDELINES and take account of transmission in their community

**Mel Pino**: I just love it when everybody laughs at his criminal negligence

**Mel Pino**: Please note those guidelines he was talking about say MANY not ALL schools can repoen safely if they social distance. Which is impossible in most public schools

**Mel Pino**: It breaks my heart in two listening to this discussion when this county threw down 2200 feet of Oyster shells along our beaches in navy point.

**Mel Pino**: Personally good for him when he is violating the ordinances that are there behind his house with his jet ski parties

**Mel Pino**: (1) Coronavirus hospital data removed from CDC website following Trump plan to reroute information
https://www.cnn.com/webview/world/live-news/coronavirus-pandemic-07-16-20-intl/h_a2f3cf2d40ea823e143aa4222f25e0d7?adobe_mc=TS%3D1594914566%7CMCMID%3D77700992796870384576019936933792298429%7CMCAID%3D2F6B6E6A8515BF15-40000B6800DB344B%7CMCORGID%3D7FF852E2556756057F000101%40AdobeOrg

**Mel Pino**: Cover-up nearly complete.

**Mel Pino**: Rick just reported chips has covid.

**Mel Pino**: He is also reporting that some staff are concerned that Janice may be holding her own results from you guys. I am not saying that's true I have no idea

**Mel Pino**: Janice and her staff are playing Robert to convince him to align with a position that votes with what Doug wants.

**Mel Pino**: Lord. What a rep.

**Mel Pino**: Marie mott's mother in law dates the numero uno Doug boolicker Glenn Conrad. 

**Mel Pino**: She was always a shoe in anyway but there's another one to watch.

**Mel Pino**: Parkinsons Law of Triviality, circa 1957:"The time spent on any item of the agenda will be in inverse proportion to the sum [of money] involved." 

Administrators still use this trick to divert attention from how they spend the big bucks

**Mel Pino**: And we lost Meredith Crawford out of the county because they asked her to hide her analysis. And when she put in her notice Alison didn't get her her 90 days.

**Mel Pino**: Chips does have covid and has been out and ill. Janice didn't report it. What else is she not reporting? Did any of you come into proximity with him recently? Why did she not tell you?

**Mel Pino**: Jeff pleas please put my comment up asap

**Mel Pino**: https://www.pnj.com/story/news/2020/07/16/fwb-woman-dies-after-going-work-respiratory-symptoms/5450077002/

**Mel Pino**: Get ready. Because there will be no end of these stories in your district, Jeff. The same constituency who is demanding no masks right now will turn on you and  ask why you didn't do anything.

### CONVERSATION ON 07-17-2020

**Mel Pino**: While it was sure fun to listen to a son of the Confederacy cry about having to mask up going into his favorite Tom Thumb, this is the real narrative. Escambia county is putting its own staff and the public who come into its buildings at the same risk. Also, please note the games the hospitals are still playing with keeping numbers down on covid. That is happening here as well.

https://abc7.com/coronavirus-florida-cases-desi-rae-mcintosh-test/6320393/

**Mel Pino**: https://ricksblog.biz/escambia-has-covid-epidemic-outbreak/

**Mel Pino**: Jeff I left a voicemail please listen when u have the chance. Malcolm Thomas has GOT to push the school opening until after labor day like they are doing in mobile and so many places in florida

**Mel Pino**: CNN is breaking a couple of things on Florida data manipulation. One is what lanza fucked up and said yesterday about how you only go in positive once but as many negatives as you get go in. The second is that they are only doing primary condition. If you are pregnant with covid, your pregnancy is reported but not covid.

**Mel Pino**: Children in Escambia are testing 50 percent positive right now. 55.7 for 5 -14

https://ricksblog.biz/child-covid-cases-up-50-as-escambia-epidemic-continues/

**Mel Pino**: See my comment on what a liar lanza is

**Mel Pino**: Sorry was trying to text. Posted.

**Mel Pino**: Jeff, please be fair and put my comment up as an answer to joan's

**Mel Pino**: Because what I am saying is no kidding government attorneys shortcut here all the time. Costs the taxpayers a lot of money.

**Jeff Bergosh**: I did I was driving

**Mel Pino**: I saw that thank you. Because whether Gary's ruling stands or not, I am sick to fucking death of government lawyers costing the taxpayers money.

**Mel Pino**: So this is out there :(

Adam Parkhomenko (@AdamParkhomenko) Tweeted: This is the ad that Republicans falsely reported in droves (and automatically through bots) to twitter today in an attempt to have censored. Keep retweeting it far and wide. https://t.co/d7MfdsDaSS https://twitter.com/AdamParkhomenko/status/1283986447444443137?s=20

**Mel Pino**: Are. You. Fucking. Kidding. Me.

All of you local officials who are backing DeSantis's lunacy in backing this lunatic have some lan in place for where we just draw the line, right?


https://www.newsbreak.com/news/0Pdfk1z8/white-house-portraits-of-bill-clinton-and-george-w-bush-moved-from-prominent-space-to-rarely-used-room

### CONVERSATION ON 07-18-2020

**Mel Pino**: Jeff, are you really going to let that "democratic Klan with a tan" comment stand?

**Mel Pino**: I would really, really hate somebody like lumon or any of our black staff at the county see that comment standing on your page Jeff. There is zero reason to host that kind of garbage.

**Mel Pino**: By continuing to post this stuff and let the comments run unchecked, do you realize your blog page becomes a haven for some of the most racist commentary anywhere in Escambia? And people are talking about it, Jeff. Even elected officials in the city. 

**Jeff Bergosh**: Free speech Mel

**Jeff Bergosh**: If they use the N-word I would not allow that though

**Mel Pino**: Yep. Go it. You are fine with letting your blog become a racist haven. And the whole town is watching.

**Jeff Bergosh**: I think you should challenge that comment with a comment of your own and I will post it

**Jeff Bergosh**: Perhaps I'll go in and make a comment of my own and explain free speech

**Mel Pino**: Jeff that's not the point. Nowhere else is that kind of stuff allowed. Nowhere. So your blog is getting worse and worse. And people are getting seriously passed about it. It's awful, Jeff it looks like a haven for it. As if you condone it. 

**Jeff Bergosh**: Nobody ever said free-speech was always violets tulips and roses

**Jeff Bergosh**: Nobody has a problem with any of that right

**Mel Pino**: Yes and I wouldn't allow that on the other side. There was a reason I got kicked off of what's happening Pensacola because I was calling for an end to rioting

**Jeff Bergosh**: Free-speech is the bedrock of this country you either believe that or you don't I believe that with exceptions of course you can't yell fire in a theater and you can't threaten someone's life but everything else is pretty much fair game

**Mel Pino**: I agree that there are thugs in black lives matter but that is not what is happening here, Jeff.

**Jeff Bergosh**: I just posted your comment and I like it it's the perfect way to challenge that sort of speech

**Jeff Bergosh**: I'm going to go in there and make a comment

**Mel Pino**: Jeff you are such a smart man but sometimes you are not very savvy about optics. Your blog doesn't look like supporting free speech right now. It looks like supporting racism. 

**Jeff Bergosh**: That's your opinion and you're entitled to it I disagree

**Jeff Bergosh**: 😎👍👌

**Mel Pino**: No it's not because I saw marshmallow balls for any race, black or white. In fact I regret using that metaphor now because it looks like I meant color and I didn't. I meant no sac

**Jeff Bergosh**: I got a run to Walmart I'll talk to you later have a great weekend Mel

**Mel Pino**: Whatever Jeff if you are going to equate not apologizing for being white with allowing racism to run amok on your page, then there's nothing for it.

**Jeff Bergosh**: Remember one thing Mel there are racists of many colors in this nation and in this community. Remember that

**Jeff Bergosh**: Have a great day

**Mel Pino**: I agree that some black people are racist. That doesn't make it right for you to foster racism, Jeff. Which is how many WHITE people are viewing your monument blogs.

**Jeff Bergosh**: They are entitled to their opinion

**Jeff Bergosh**: Funny how no one else is complaining?

**Mel Pino**: Well thank goodness for them they have one place in the entire county they can talk like that. Bravo.

**Jeff Bergosh**: Are you fucking kidding me Mel? Go look at the fucking comments on the PNJ Facebook page and the fucking WEAR Facebook page are you kidding me?

**Mel Pino**: You would be surprised, very surprised, by the people who are disgusted with this right now.

**Jeff Bergosh**: People are pissed off and this act of rational stepping back is actually being very well received do the arithmetic on the emoticons and do the percentages it's 70% positive for taking a step back and following the fucking law

**Mel Pino**: I wasn't talking about sinking to the level of Facebook. 

**Jeff Bergosh**: If they're disgusted they need to read the fucking constitution and suck it up

**Jeff Bergosh**: I'm turning my phone off we disagree on this issue I respect you you're entitled to your opinion but we obviously disagree on this have a good day

**Mel Pino**: Jeff if they didn't follow the law then I agree. 

**Jeff Bergosh**: 👍

**Mel Pino**: Doug's public Q Anon oath.

**Mel Pino**: (A friend just sent the below. I agree entirely. And am done trying to impact this situation with lobbying. I spent all day on the phone yesterday on the school opening. That's the last frontier. There aren't any more battles left for us to lose. Nothing more to do than post a comment here and there but switch focus to taking care of our own. This county has left us every man for himself.):

There's a new page someone invited me to join that's for Covid "long haulers" & I made the mistake of reading a few of the stories. I closed the page & got off the Internet after. Some of these people wish it would of killed them instead of leaving them with long term affects. At this point all we can do is protect ourselves & prepare ourselves, because the worst is yet to come & I'm not just referring to Covid 

**Mel Pino**: I'll leave it on this.

### CONVERSATION ON 07-19-2020

**Mel Pino**: I'm not going to argue for the county to take covid seriously any more. It's too late for that and I'm swinging to putting up fencing and beefing up security on our properties. I will just send info when it seems important. Eglin getting ready for huge shutdown. Pilots, captains, lots of rank coming down with covid and it is spreading like wildfire. People have been told they won't be coming back until August 15th. Maybe longer.

**Jeff Bergosh**: Look at my blog post about schools starting prematurely.  I believe you and I agree that this is premature.

**Mel Pino**: Thank you. The hospital administrators have Got to go down on paper or I don't know if there is a third vote on the school board. I hope so. One school board member told me getting a rec from a local health expert would '"Change everything"

**Jeff Bergosh**: They just need to use common sense.  How can they say it's dangerously unsafe for 19-year-old spring breakers to be together on the beach without masks and without socially distancing in one breath and then the next breath say but it will be perfectly fine for 18-year-olds on the high school bus to be an even closer proximity without masks and no chance of socially distancing? There are either both unsafe behaviors or neither is

**Mel Pino**: How can you say a mask won't stop the spread? I gave up trying to figure out how such smart people could be so deluded for so long, Jeff. I know how it has happened. Never thought I'd see it in this country. Mike is pursuing his dual citizenship in Italy and if Trump gets re-elected we are moving there. There are ill trained squads of goons in full battle gear grabbing protesters and throwing them in unmarked rental vans with no probable cause and nobody knows where they took them.

**Mel Pino**: Posted

**Jeff Bergosh**: You obviously did not read my post.  It's not about masks, 

**Jeff Bergosh**: One thing is safe but one thing isn't but that cannot be true when both are the same do you not see that? How can intelligent people not see that?

**Mel Pino**: Jeff how can intelligent people not have seen than Escambia was going to become an epicenter if we didn't do the right things months ago? How can a county administrator put people's lives at risk because of her delusional politics? How can the head of our DOH tell lies that will kill people? How can you really believe that nanopartcile gobbledygook coming off those alt right sites? The answer is we are devolving quickly into fascism and only half the country is aware of it. This is how it always happens, Jeff. Talk to Rita Kershaw. She saw this in Cuba and was in the first wave. And now has to watch it happening here in her last days.

**Mel Pino**: Fyi I disregard most of the garbage but I thought you should see this one

**Jeff Bergosh**: Ralph's a lying sack of dog shit

**Jeff Bergosh**: If he was almost fired- it's because he violated policy-- Not because of any closed-door meeting he alleges happened

**Mel Pino**: Of course not but I just give you the heads up when the lie is about something serious instead of the usual horseshit.

**Jeff Bergosh**: What site was that posted on?

**Mel Pino**: ECW

**Mel Pino**: I scan it once a day

**Jeff Bergosh**: When was that posted?

**Mel Pino**: 9 hours ago. Under the OP by JAR 3 days ago that's the big red block with white letter about 10 fire trucks.

**Jeff Bergosh**: Thx

**Jeff Bergosh**: I've got it now

**Mel Pino**: K. I'm sorry because I know how aggravating it is. But the serious stuff needs to be flagged.

**Jeff Bergosh**: Thx

**Mel Pino**: https://www.scpr.org/news/2020/07/16/93588/georgia-hospital-worker-sounds-alarm-i-have-never/

**Mel Pino**: Jeff, this is real, and it is getting ready to hit here like a freight train. Janice, Gilmore, lanza, the hospital admins, De Santis and his entire administration, and Trump and the federal administration have been lying to the American people since day one. At the same time we have a president that is harnassing a cult and bringing them in to his administration. This is actually happening. It is not liberal news spin. We have a president who has no skills for the office but he is a master of media. This country is on the precipice. Remember. I couldn't vote for Hillary either. I am not a liberal. We are in so much trouble Jeff. This lunatic won't be satisfied with exploding our country into civil war. He will drag us into a world war if this situation at our bases doesn't get under control fast. And the sad fact it, it's probably already too late :( I know you don't want to face that or believe it but that is the god honest truth about what is going on here. These people will kill kids to try to keep up a fantasy about the election. That is what we are dealing with.

**Mel Pino**: Please, please just keep you mind open and stop listening to the conspiracy theory. You are one of the smartest people I know. So are some of the other people who fell prey to this. Our country is done--done-- if something doesn't come along to help. I couldn't even say what it is. The November election will be too late to save another 50 thousand Americans from dying. If not more. 

**Mel Pino**: We did this in April on the shop.

**Mel Pino**: This is an honest question, that you don't have to answer. What do you think is going to happen in this county if the food lines collapse and can't feed people any more? I'm not saying it will happen. But what if it did?

**Mel Pino**: Where are the resources going to come from? And our bases all over the world are succumbing to this because of Trump's politics. Eglin is why I have been BEGGING you to take this seriously at your job. And then you guys sit up on the dais like nothing is going on. No masks. No social distancing. Drinking out of water bottles that have been handled by God knows how many people.

**Mel Pino**: Escambia county is now one of the epicenters of the entire country, Jeff. What do you think can stop it now? There is only one battle left that can have any material effect and that's the schools. Those of us who recognized and tried to get a proper response won't have any other frontier to lose, Jeff. There's nothing left.

**Jeff Bergosh**: I think they will delay the school opening

**Mel Pino**: I hope to God. And even that won't be enough. But at least it will give parents a delay to realize this thing isn't a hoax. So many people here still think this is an overblown hoax and they actually believe it was made up NY the liberal media for the election. Jeff :(

**Mel Pino**: Made up by. Not NY

**Mel Pino**: I live on the west side in unincorporated. Very little awareness. A lot of delusion.

**Mel Pino**: Last thought. I have been trying for a week to get a copy of the internal plan. Not the damn PR job I posted from (which is bad enough) but in other places the internal plans have been leaking and they set down contingencies, in black and white, for teacher staff and student death

**Mel Pino**: I think I got a copy finally waiting. 147 pages. It is supposed to be public record and posted but Malcolm has been keeping it under tight wraps

**Mel Pino**: Just had cops at my house off Doug dog whistle this morning. They know it's bullshit

**Mel Pino**: Just hammered Malcolm in email. But honestly Jeff this thing will come back to the bocc not doing anything. People are just beyond pissed off

**Mel Pino**: https://mobile.twitter.com/benhowe/status/1260225009592741888

**Mel Pino**: This is what is happening Jeff. Please wake up.

### CONVERSATION ON 07-20-2020

**Mel Pino**: They are independent. They have every legal right to vote against that bullshit executive order. It's not worth the paper it's printed on but desantis will tie them up in court anyway or just choke their funding. That's why they are scared not to close

**Mel Pino**: Nimble enough

**Mel Pino**: Paul's on the phone.

**Mel Pino**: Oh yeah buddy that is going to be wiped right out. That was the whole point.

**Mel Pino**: Jeff can you get me that study I want to get it to the media

**Mel Pino**: Rick will probably be the only one but maybe chorus or renee

**Jeff Bergosh**: Okay I'll send u the link

**Jeff Bergosh**: In your gmail inbox 

**Mel Pino**: "Too many glitches" on phone call Ins my ass. They took almost 50 calls at the city meeting the other night

**Jeff Bergosh**: I have it- read it-- it's intriguing

**Mel Pino**: Thank you. They just won't be able to get it together to take public comment in written form for tomorrow. Imagine that.

**Mel Pino**: "We would not have broken even if we hadn't shut down."

**Mel Pino**: Would have been 2m down it sounds like.

**Mel Pino**: I'll read after the workshop.

**Mel Pino**: Thomas is "splitting the difference. Keeping millage rate and they will advertise a tax increase. 

**Mel Pino**: Patty is arguing to expand the semi finalist list to try to fight against this shoehorn attempt on Keith leonard

**Mel Pino**: Adams went against shilling. Edler is backing Patty.

**Mel Pino**: Elder presented an alternate list. Fetsko says do the 9. Slayton shilling for Leonard with adams

**Mel Pino**: Patty is getting it battled up in numbers so Kevin and Slayton can't Jack with the scoring as easily

**Mel Pino**: Edler is on fire talking about how fucked up this process has been. Talking ethics.

**Mel Pino**: She is getting right down to it.

**Mel Pino**: Talking about a guaranteed 3 votes for a particular position. She is firebombing this

**Mel Pino**: Holy shit this is amazing jeff

**Mel Pino**: "To continue to play these little games. If there is truth that people have already made up their minds ,I will file ethics charges

**Mel Pino**: Kevin responds like an idiot outing himself 

**Mel Pino**: Slayton jumps in behind him. Both of them nicely illustrating exactly what is happening

**Mel Pino**: She just pointed out that she didn't name names. Told them the she didn't need their permission if she thinks something unethical happened and she isn't pulled by their aggressive tone. Just basically smacked Slayton right into the ground.

**Jeff Bergosh**: In safety meeting will call back

**Mel Pino**: Thomas just fell all over himself congratulating lanza for the great job he has done.

**Mel Pino**: Fucking lanza

**Mel Pino**: https://www.foxnews.com/us/florida-pediatricians-letter-desantis-reopening-schools-coronavirus

**Mel Pino**: https://www.news4jax.com/news/local/2020/07/20/floridas-largest-teachers-union-to-announce-legal-action-on-state-reopening-schools/

**Mel Pino**: Dear God what a disaster. I had NO idea how dysfunctional this really is when I was advocating for appointed super intendent. I was going off principle. Now I've seen the reality

**Mel Pino**: I just PRR'd him back to back records requests on secret docs. Check email

**Jeff Bergosh**: Will do

### CONVERSATION ON 07-21-2020

**Mel Pino**: Malcolm is delaying football.

**Mel Pino**: Jeff a thought...you will have to wear a mask if you go and take it off if you want while you are speaking if there is room to social distance. Slayton, Patty, and Dr Edler are wearing them but Kevin and Malcolm aren't.

**Mel Pino**: Jeff check Pnj Malcolm is delaying schools by 2 weeks

**Jeff Bergosh**: Yes I heard.  That's a good decision!

**Mel Pino**: Yes. It's not long enough but maybe desantis will pull his head out and realize he still has a smidge of time before he's a one and done or people get seriou s about a recall.

**Jeff Bergosh**: On a conf call I'll call u back

**Mel Pino**: Ok Collier County passed a mask mandate 3 2

**Mel Pino**: Are you watching public forum? 

**Mel Pino**: This teacher is making your argument for you.

**Mel Pino**: These poor teachers. I wonder how many of them have already quit or taken leave. Never going to get that out of him.

**Mel Pino**: God these poor people are so lost.

**Mel Pino**: "We hated virtual learning....but it is better than death"

**Mel Pino**: Jeff these pediatricians just handed it to you. Amazing

**Mel Pino**: Malcolm Thomas going against pediatricians. Good job bud. Jeff send out a special meeting request now and ask to have those pediatricians as speakers. This isn't going well for the covid denial

**Mel Pino**: All the teachers will come.

**Mel Pino**: People who have lost family will come.

**Mel Pino**: Please not that the absolutely heartless and sterile tone is not the right thing.

**Mel Pino**: Dipshit Adams just 1 4'd on millage

**Jeff Bergosh**: Did they mandate masks??!!??

### CONVERSATION ON 07-22-2020

**Mel Pino**: https://ricksblog.biz/board-approves-opening-delay-mask-rules/

**Mel Pino**: "Stopped short of mandating" but they did include language that said masks will be worn "as instructed." So basically the continuation of hot posting the responsibility continues, with nobody really responsible and this virus will continue to rage.

**Jeff Bergosh**: On a conf call

**Mel Pino**: No worries left a message

**Jeff Bergosh**: 👍will call when I come up for air

**Mel Pino**: Owner of the floribama

**Jeff Bergosh**: BOA denied Seafarer appeal for Conditional Use Permit for County to complete Beach Access # 4
😎😎😎😁😁😁👍👍👍👌👌👌

**Mel Pino**: Oh that was today??????

**Mel Pino**: Call when you can!!

**Mel Pino**: It was the appeal of the DRC approval that got denied. Hahahahahaha 

**Jeff Bergosh**: Yep!  Doug's hair is on 🔥 

**Jeff Bergosh**: LOL

**Mel Pino**: We still need the damn hearing set on the conditional use. But Tim's gonnakeep going :)

**Mel Pino**: About sums it up

**Mel Pino**: Fuck, Rick is on his way to the ER. Covid-19 attacked his heart.

**Mel Pino**: From a friend.

**Jeff Bergosh**: Whoa-- Rick Outzen??

**Mel Pino**: No. Another friend with covid in the family. Her husband tested negative so they made him go back to work and he went to a clinic for kidney pain and they imaged him and covid was attacking his heart. They rushed him to ER. Contractor.

**Mel Pino**: After they cancelled his insurance

**Mel Pino**: https://twitter.com/DavidBegnaud/status/1284314400250265602

### CONVERSATION ON 07-23-2020

**Mel Pino**: (this is my friend whose husband was rushed to ER by community clinic. What the hell is going on in those hospitals. Thank God he is back home.) He's okay. He didn't get home until around 1:30 last night. All they did was put him on blood pressure medication and told him to go back to his doctor. He went to Baptist ER. None of us will ever go there again. He said everyone in the waiting room was fitted for a hemlock. Everyone! People were sitting around for hours with those in their arms! Some wanted to just leave, because nobody was being seen at all for hours upon hours, so they were asking to have their hemlock removed. However, they didn't want to remove them, so a few took them out themselves! It was like Baptist was holding people hostage!

**Mel Pino**: https://www.srpressgazette.com/news/20200722/covid-19-testing-nonprofit-ceo-florida-department-of-health-reporting-inaccurate-results

### CONVERSATION ON 07-24-2020

**Mel Pino**: The wall of moms in Portland were attacked by trumps gestapo dressed in gear that is above their pay grade. 
The movie Aliens called and wants its costumes and sets back.
Fuck Randy Cudds ameriKKKa 
https://twitter.com/Infantry0300/status/1286673400061140992?s=09

**Mel Pino**: That was from Kevin.

**Mel Pino**: Please check comments. This is not a concerted effort. I had to look up Julia Pearsall and I have no idea who blalock is.
 https://ricksblog.biz/county-administration-disputes-10-covid-deaths/

**Jeff Bergosh**: Dealing with a utility locate emergency at the moment will check when I get back to office

**Jeff Bergosh**: Thx

**Mel Pino**: Greg Evers' widow. Permanent lung scarring

**Mel Pino**: That's one of Kim carmichael's mom's best friends. Kim's daughter is headed to the emergency room.

**Jeff Bergosh**: In the field will call u back

**Mel Pino**: Ok I know you are having a horrible day. But I had to report that death threat on me that appeared under your mask post. Please do not take it down and please post my response as soon as you can.

**Jeff Bergosh**: Done

**Mel Pino**: Thank you no rush on talking about that but at some point we need to because that is not going to stop and they will continue to escalate it

**Mel Pino**: https://www.tallahassee.com/story/news/politics/2020/07/24/anonymous-state-workers-say-theyre-not-safe-coronavirus-work/5502107002/

**Mel Pino**: On this nutjob site with 5000 people on it.

**Jeff Bergosh**: Wow--desperado

**Mel Pino**: Https;/wwwmfacebook.com/groups/729427697215088/permalink/1619085468249302

**Mel Pino**: Game on. That's 1 of a dozen sites fyi and Kevin tweeted it to Rick Wilson who got the dildo Doug viral to tens of thousands of people.

**Mel Pino**: Https;/wwwmfacebook.com/groups/729427697215088/permalink/1619085468249302




















Check voicenaik

### CONVERSATION ON 07-25-2020

**Mel Pino**: https://www.cnn.com/2020/07/24/health/covid-19-symptoms-last-long-term-study-wellness/index.html

**Mel Pino**: Another positive driver

**Mel Pino**: At ecat

**Mel Pino**: Watched the WEAR. That's a Sinclair hit job. Kevin says Sinclair NATIONALLY ran a piece that highlighted that hoax "plandemic" and tried to discredit Fauci

**Mel Pino**: Came in on top of Kim's on what's happening

**Mel Pino**: https://www.usnews.com/news/best-states/florida/articles/2020-07-25/floridas-top-regulator-looking-at-how-to-open-bars-safely

**Mel Pino**: Sigh.

**Mel Pino**: Posted a comment

**Mel Pino**: This is why WEAR is so boxed in locally, Jeff. Was that guy in the video about Escambia masks even a local reporter? (Honest question)

**Mel Pino**: Jeff do you have 5? Pretty important

**Mel Pino**: Check email

**Mel Pino**: They've detected the camoflaging technique in SARS-CoV-2, meaning they can start to develop and reverse engineer an antiviral
https://www.nature.com/articles/s41467-020-17496-8

### CONVERSATION ON 07-26-2020

**Mel Pino**: https://www.wfla.com/news/9-year-old-florida-girl-dies-from-coronavirus/

**Mel Pino**: No underlying conditions

**Mel Pino**: https://mobile.twitter.com/RebekahCastorTV/status/1287503879131758596

### CONVERSATION ON 07-27-2020

**Mel Pino**: Lincoln Project going on desantis now. Maybe we can put them on to Doug.

**Mel Pino**: Left a message

**Mel Pino**: https://ktla.com/news/nationworld/child-hospitalizations-from-covid-19-rise-23-in-florida-weeks-ahead-of-school-reopenings/

**Mel Pino**: https://www.newsweek.com/deathsantis-sign-creators-say-florida-governor-letting-coronavirus-flourish-1519454?amp=1

**Mel Pino**: Those deathsantis signs are going up in Florida.

**Mel Pino**: https://www.pnj.com/story/sports/2020/07/27/milton-track-and-field-coach-joe-austin-dies-sunday-covid-19/5517863002/

**Mel Pino**: https://ricksblog.biz/bender-shrugs-off-city-mask-resolution/

**Mel Pino**: Check my comment

**Mel Pino**: Robert obriens office just found out he had covid from CNN.

**Jeff Bergosh**: Still at my office on base just trying to come up for air

**Mel Pino**: Oh thank goodness. Just wanted to make sure you were ok

**Jeff Bergosh**: Will call u on my way home

**Mel Pino**: 👍

**Jeff Bergosh**: 2 key employees called out today so I've been covered-up all day long

**Mel Pino**: Sorry to be up your butt these days it's hard not to worry

**Jeff Bergosh**: .... earning my check today 😁

**Jeff Bergosh**: No problem👌

**Mel Pino**: I really want to wallop Faulkner with some questions for Wednesday morning

**Mel Pino**: https://www.cnn.com/2020/07/27/us/florida-health-mask-trnd/index.html

### CONVERSATION ON 07-28-2020

**Mel Pino**: Rick just posted the mask options

**Mel Pino**: https://www-fox13news-com.cdn.ampproject.org/v/s/www.fox13news.com/news/university-faculty-call-on-desantis-to-call-off-in-person-classes-this-fall.amp?amp_js_v=a3&amp_gsa=1&usqp=mq331AQFKAGwASA%3D#aoh=15959701123722&referrer=https%3A%2F%2Fwww.google.com&amp_tf=From%20%251%24s&ampshare=https%3A%2F%2Fwww.fox13news.com%2Fnews%2Funiversity-faculty-call-on-desantis-to-call-off-in-person-classes-this-fall

**Mel Pino**: https://www-news4jax-com.cdn.ampproject.org/v/s/www.news4jax.com/news/florida/2020/07/28/desantis-urges-hospitals-to-allow-end-of-life-visitors-despite-covid-19-restrictions/?amp_js_v=a3&amp_gsa=1&outputType=amp&usqp=mq331AQFKAGwASA%3D#aoh=15959711252139&csi=1&referrer=https%3A%2F%2Fwww.google.com&amp_tf=From%20%251%24s&ampshare=https%3A%2F%2Fwww.news4jax.com%2Fnews%2Fflorida%2F2020%2F07%2F28%2Fdesantis-urges-hospitals-to-allow-end-of-life-visitors-despite-covid-19-restrictions%2F

**Mel Pino**: There is no more denying it. Desantis is practicing eugenics. Nobody could be this stupid.

**Mel Pino**: The man is literally insane.

https://www-wflx-com.cdn.ampproject.org/v/s/www.wflx.com/2020/07/28/desantis-coronavirus-patients-experiencing-improved-outcomes/?amp_js_v=a3&amp_gsa=1&outputType=amp&usqp=mq331AQFKAGwASA%3D#aoh=15959712482650&csi=1&referrer=https%3A%2F%2Fwww.google.com&amp_tf=From%20%251%24s&ampshare=https%3A%2F%2Fwww.wflx.com%2F2020%2F07%2F28%2Fdesantis-coronavirus-patients-experiencing-improved-outcomes%2F

**Mel Pino**: This is that crazy ass Qer acting as underhill's handmaiden

**Mel Pino**: Please, please get my comment up with questions

**Mel Pino**: I would have had it in earlier but I have been dealing with Doug trying to blow up the county

**Mel Pino**: Check email for my blast on school

### CONVERSATION ON 07-29-2020

**Mel Pino**: Jeff Please hold off on posting my questions....need to retool since you didn't see them in time

**Jeff Bergosh**: On conf call

**Mel Pino**: Jeff watching your coffee and it is EXCELLENT. Everybody is this county needs to hear those doctors. Along with the numbskull docs in Milton still prescribing that crap. I can't believe doctors are falling prey to politics. What the hell is wrong with this country right now.

**Mel Pino**: Posted to your blog

**Mel Pino**: Janice is so full of shit.

**Mel Pino**: The AAMC issued a warning that if we don't do something big, and soon, we could have hundreds of thousands more deaths than what was originally predicted when nobody could have imagined the Republican leadership would devolve into a covid denying cult.

https://www.aamc.org/covidroadmap

**Mel Pino**: https://thehill-com.cdn.ampproject.org/v/s/thehill.com/homenews/state-watch/509696-florida-to-close-state-run-coronavirus-testing-sites-starting-friday-due?amp_js_v=a3&amp_gsa=1&amp&usqp=mq331AQFKAGwASA%3D#aoh=15960682377423&referrer=https%3A%2F%2Fwww.google.com&amp_tf=From%20%251%24s&ampshare=https%3A%2F%2Fthehill.com%2Fhomenews%2Fstate-watch%2F509696-florida-to-close-state-run-coronavirus-testing-sites-starting-friday-due

**Mel Pino**: Just when you think desantis can't come up with another way to Jack with our data. 

**Mel Pino**: Kim carmichael's mom threw away her dinner tonight because she couldn't taste it. She can't get tested now until Tuesday.

**Mel Pino**: I just met with an Fdle agent today.

**Jeff Bergosh**: Wow!!  That's not good!!

**Mel Pino**: Especially because he wouldn't put a fucking mask on.

**Jeff Bergosh**: I just met with the local Realtor's Association Representative locally:  They interviewed all four candidates in my race two weeks ago and today they announced that they are endorsing me for county commissioner district 1. I think this is profound because my opponent Johnathan Owens and his wife are both licensed Florida realtors

**Mel Pino**: It's the FIRST meeting and I mean the FIRST I have gone to since April. 

**Jeff Bergosh**: Bad timing, bad luck

**Jeff Bergosh**: Tomorrow at 11:30AM---candidate forums at Marcus Pointe Baptist Church for CC races and State Rep Races.  Could get interesting

**Mel Pino**: Jeff that shit about Fdle is not true one of my friends was fucking with me. Not funny.

**Jeff Bergosh**: Uncool

**Jeff Bergosh**: Goodnight

**Mel Pino**: What will be really interesting is how many people get infected with covid from it about 3 weeks from now :(

### CONVERSATION ON 07-30-2020

**Mel Pino**: https://apnews.com/d203eaa406dc5e7362dfa9e33522195e

**Mel Pino**: In case there is any doubt that Trump is a fascist.

**Mel Pino**: Sherri Myers went off on Jacqueline Rogers on saying that the mask ordinance in the city was a political sham. She brought it. Hahahahahaha

**Mel Pino**: 1 corrections officer no mask. The other has a mask around the chin. The inmates have gotten hot now so one took his mask off and another has his around his chin. Woking side by side with county workers, one of whom already had coronavirus and understands it's possible he may not hold his immunity on it. 

**Mel Pino**: Out in front of my house right now putting in a bench. 1 corrections officer no mask. The other has a mask around the chin. The inmates have gotten hot now so one took his mask off and another has his around his chin. Woking side by side with county workers, one of whom already had coronavirus and understands it's possible he may not hold his immunity on it. 

**Mel Pino**:  Believe me I feel for these guys working in the heat. There are cooling masks that can be purchased for them, Steven. This is renegade recklessness.

**Mel Pino**: This I can take a photo of. They just repositioned the truck so we couldn't see them.

**Mel Pino**: Just started watching the video. I'm so fucking pissed those bitches had people bunched with not proper distancing and no masks. I knew they would pull that shit.

**Mel Pino**: Holy crap Michelle knocked it out of the park. She hammered Mike. Listening to this sexist asshole Chris dosev right now.

**Mel Pino**: McConnell just rejected trumps call to delay the election.

**Mel Pino**: Jeff I can't find video of the second debate segment anywhere :( I don't know if studio 850 stayed but it's not up. Did you have somebody there to Facebook it? I'm hoping this isn't a planned thing to help the non incumbents.

**Mel Pino**: Realtors endorsed lutimothy

**Mel Pino**: Jonathan can't even keep Beulah and bellvue straight. He is the definition of a tool. 

**Jeff Bergosh**: He is a tool!  Glad u found that video!!

**Mel Pino**: Hahahaha I have to agree with Megan Walters. You guys need a woman on that board for more emotional intelligence. It's a key component in decision making. That why wome are better in emergencies.

**Mel Pino**: Unless they are trumplican covid deniers. Most women have instincts guys just don't have. There is a such thin as email intuition and right now you've got it working against you instead of for you.

**Mel Pino**: Studio 850 posted second part

**Jeff Bergosh**: Okay great!  Thanks!!

**Mel Pino**: Please check email just as soon as you can. Doug Alex and Megan at the bridge.losing their minds

### CONVERSATION ON 07-31-2020

**Jeff Bergosh**: Meetings all morning.  Will come up for air later this afternoon 

**Mel Pino**: No worries. When you have time, watch that video of Doug coming unglued at graffiti bridge.

**Jeff Bergosh**: No thanks! LOL

**Jeff Bergosh**: He's a POS

**Mel Pino**: Jeff Please you need to watch it. Because it shows how insane he is becoming and there's no bottom to it. It's not a joke.

**Jeff Bergosh**: I'll take your word for it.  Too busy today to expend one ounce of brainwave on that 

**Mel Pino**: https://www.pnj.com/story/news/2020/07/30/ecso-florida-man-threatened-grocer-ax-when-asked-wear-mask/5550212002/

**Mel Pino**: Ok I get it just please understand that I am not exaggerating the lunacy that is taking root here

**Mel Pino**: It's very dangerous Jeff. You need to be aware and start watching your back.

**Mel Pino**: I just handed Doug his ass in an email. He was stupid enough to write me back.

**Mel Pino**: Posted to the arduinis "TRUTH" local QAnon page. (He also has a national Q page that he took over)

**Mel Pino**: Arduini has also been painting you as a liberal in hiding for "bringing" the mask options on ecw.

### CONVERSATION ON 08-01-2020

**Mel Pino**: https://www.vanityfair.com/news/2020/07/how-jared-kushners-secret-testing-plan-went-poof-into-thin-air#intcid=recommendations_vf-trending-legacy_caf2a6d7-20e9-4632-9889-3fd0a42b15c4_popular4-1

**Mel Pino**: Game changer and must read. Lays out in specific detail how trumps administration intentionally derailed a federal response because they actually thought it would be visited worst on states with democratic governor and high population urban areas that tend to have democratic mayors. Except these idiots are too stupid to even run surgical genocide, which isn't that hard if you're really intent on doing it. Genocide is a metaphor. I don't know what an intentional attempt at the whole sale killing of the opposing political party and their constituents is called...maybe just "war" or "slaughter." We will probably have to invent a new word for what we are witnessing. This article is extremely well researched, detailed, unsensational, and unemotional. And anyone who reads it that still refuses  to see the truth of it will still be blaming the democrats if our stock market crashes and we have massive outbreak of crime because people can't feed their kids.

**Mel Pino**: Here is what's really going on in the hospitals. A nurse came on to JAR's site to try to convince the whack jobs there that covid was real and our hospitals are stretched to the breaking points. What one idiot didn't understand is that, as I conveyed to you guys almost a month ago, a covid "unit" is now and entire floor of at least one hospital. She is saying four whole floors of the hospital are filled with covid patients.

**Mel Pino**: This is how hospital workers who are risking their lives to treat covid patients and trying to get the word out about the truth are getting kicked in the head for it.

**Mel Pino**: https://www.militarytimes.com/opinion/commentary/2020/07/30/3-questions-on-us-troops-rebasing-from-germany/

**Mel Pino**: Meanwhile that psychotic SOB continues to undermine our military. Probably because he realizes that they will drag him out of that white house at some point if this continues, or if he isn't able to fuck with the USPS enough to voter suppress a rejection for himself. Meanwhile McConnell continues to try to distance from Trump and tell others up for re-election to do the same. While Trump forced a dozen sheriff's and his idiot supporters to stand on the blazing tarmac in Tampa yesterday and one sheriff wet down from heat exhaustion. Headed off to a fundraiser. 5600 got you in the door, 35k got a photo and 100k got you a roundtable discussion on how to MAGA. Thats the end of the bad news for this round. Except that Janice did a "state of the county" for THE CITY CHAMBER and threw you guys under the bus, particularly lumon.

**Mel Pino**: Fyi errand boy is hosting a community gathering at the rose cottage farm today. 4 going (which probably includes the 3 organizers which include Johnny himself) and 5 interested.

**Mel Pino**: Btw, even Derek Carson was forced to admit Jonathan had a weak performance at the debate.

**Mel Pino**: Btw, even Derek Carson was forced to admit Jonathan had a weak performance at the debate.

**Jeff Bergosh**: Wow-- that's hard to believe!

**Mel Pino**: Yup. He was flaunting how Jonathan was his own man then he got up and did nothing but Doug talking points, talked about perdido key, and accidentally said Beulah for Bellevue (where he lives). Scott trotter came back and pointed that out and Derek said something like "I wasn't a very strong performance lol"

### CONVERSATION ON 08-03-2020

**Mel Pino**: https://ricksblog.biz/local-healthcare-leaders-discuss-marathon-covid-fight/

**Mel Pino**: Check my comment. I also did a follow up in which I called the PNJ out for meddling in the D1 race and stuck it under the wrong blog.

**Jeff Bergosh**: I think the article in the news journal today was very favorable to me I'm quite happy that they published it and they also linked my next for Escambia plan

**Mel Pino**: I am too but the left it on Jonathan saying he wasn't like Doug and gave him the last word. That's what passes me off. They did the nest they could for him out of a pass poor performance. And the picture they had running before of you leaning back as if you were taking it easy. They are still doing what they can. But that hospital post is very important with those charlatan fucking administrators trying to flip the script now and I blasted them in the comments section and asked them if they were ready to get real yet.

**Mel Pino**: https://ktla.com/news/nationworld/2-more-teens-in-florida-die-of-coronavirus-complications-bringing-states-total-number-of-juvenile-deaths-to-7/

**Mel Pino**: Left you an important message

### CONVERSATION ON 08-04-2020

**Mel Pino**: https://www.tampabay.com/florida-politics/buzz/2020/08/03/five-who-attended-same-sheriffs-meeting-as-ron-desantis-test-positive-for-coronavirus/

**Mel Pino**: Call on your way in?

**Mel Pino**: Please check email when you can for some data on why we are not ready to open brick and mortar here and an appeal to our delegation for support.

**Mel Pino**: Jeff just looking for a yes or no text if you have a chance. Did they really give you a chart with only 22 of the 67 counties on it? 

**Mel Pino**: For the mask "data" on your blog.

**Mel Pino**: 4 more deaths fyi. We are over a hundred and that doesn't count, of course, all of the deaths that were probably covid that weren't classed as such because they never got a test.

**Mel Pino**: Ive got a post to upload to your blog but I just want to make sure that piece of shit chart is what it is before I go off on it.

**Mel Pino**: Its actually 10 deaths between Santa rose and Escambia.

**Mel Pino**: https://thehill.com/policy/healthcare/510393-trump-on-coronavirus-death-toll-it-is-what-it-is

**Mel Pino**: In all seriousness, that is a phrase to avoid like the plague until the primary.

**Mel Pino**: Look at this shit. This is to make you laugh. Blow this photo up.

**Mel Pino**: I shit you not look how far my dry cleaner got today before I stopped him in his tracks. He is still trying to bring things in the house like he used to. This is  4 month old battle. He is a trumplican denier spreading germs all over town. That coat rack I tired to outsmart him wife had a note. "Please leave clothes here Werner." He read it and barrel up the drive. Said he did want to leave the clothes in the heat. Told him to drop that shit and not take another step hahaha

**Jeff Bergosh**: LOL

**Mel Pino**: Pnj reporting 5 deaths in Escambia for 11. Escambia had 137 new cases. Only 11 in nursing homes. Median age 43. Positivity 12.7 percent on roughly a thousand tests.

**Mel Pino**: Death in Florida from March 17 to today

### CONVERSATION ON 08-05-2020

**Mel Pino**: https://ricksblog.biz/fact-check-when-did-county-administration-write-pandemic-plan/

**Mel Pino**: Jeff you have got to make some time today to read that. Rick dropped the bomb on janice's games and there is no denying it any longer. My comment makes it very clear the divide and conquer she has been running on county staff and the board itself.

**Jeff Bergosh**: I'll check it out once I get through my morning meetings thx for forwarding

**Mel Pino**: Cool it's very important especially in the context of the meeting tomorrow. I'm probably going to have to move to an undisclosed location in idaho. I hope it went well last night!

**Mel Pino**: Rick put up another monster blog on the medical director in Oskaloosa and laying down the gauntlet on Marie Mott, asking if she'll do better than lanza

**Mel Pino**: https://www.pnj.com/story/news/2020/08/05/escambia-county-commission-unlikely-change-stance-mandatory-masks-ordinance/3291210001/

**Mel Pino**: 105 new cases, 6 more deaths. Hospitalizations up 28 percent. (Added 25 bringing total to 491) . Etc. Per the DOH thru Rick's blog

**Mel Pino**: Like I keep trying to tell you, I have no idea who the he'll is feeding you this bad data ("hospitalizations are down") but it's just dead wrong and they are laying you, Jeff. And have been. THAT is why I get emotional.

**Mel Pino**: https://www.washingtonpost.com/business/2020/08/05/florida-coronavirus-aid-congress/

**Mel Pino**: https://thehill.com/policy/finance/510733-desantis-blames-rick-scott-for-pointless-roadblocks-in-florida-unemployment

**Mel Pino**: https://ricksblog.biz/still-no-cares-budget-for-the-public-to-review/

**Mel Pino**: It's a very dangerous game she is playing with the delay tactics so she can spend like a drunken sailor on whatever she wants with a tightened window on deadline. And Rick is right...she is trying to box you guys in to a corner so you'll take anything as long as she finally gets it moving. 

**Mel Pino**: https://www.pnj.com/story/news/2020/08/05/santa-rosa-county-sheriff-bob-johnson-positive-covid-19-attended-florida-sheriffs-association-confer/3300455001/

**Mel Pino**: Morgan was on lying about how they get test results the next day. 

### CONVERSATION ON 08-06-2020

**Mel Pino**: Jeff I do not know if the admins are coming this morning haven't had the chance to ask you. But please look at this stat. Politically, and for the good of public awareness, you have got to stop positioning this as a thing where only oldies die. While the death rate is higher for them, people of all ages die and here is the kicker. A lotof people who don't die but Evolve to long haulers *wish* they would just die. It's that bad. The multi organ damage in many cases is crippling and irreparable. This is the direction the understanding and rhetoric has to be swung, because it is the truth and the public doesn't understand that.

**Mel Pino**: On other general thought. If you guys pass that stuff to allow Janice to do whatever she wants with cares, to have proxy power ti di it without you approval, and to continue in her autonomy during this pandemic, allowing that to happen today will result in a nightmare that will take this county countless years to dig out of.

**Mel Pino**: Sorry, one more thought. I don't know if you saw Morgan's self congratulatory thing on how he has handled covid on wear last night. I confirmed fact from fiction from a reliable source. NO, they are NOT getting their testing results in 24 hours. No, of course they didn't mask up until it was far down the road. Yes, he really does understand now how serious it is (because they of course are not doing as well as he represented) and even went so far as to bitch about the fact that this virus was misrepresented to him as less dangerous than it really is, "like N1H1". (Which he understands now it is not, to his credit). They badly need to be put to the front of the line for rapid testing if it ever gets here along with the rest of our front liners. Janice is boxing them outof any CARES discussing it and misrepresenting how it works to Enrique.

**Mel Pino**: 1. SHE DOES NOT NEED TO HIRE ANOTHER FRIEND AS A CONSULTANT ON CARES. It is too late for that anyway...the money is running out. 2. SHE SHOULD NOT HAVE THE ABILITY TO DO EMERGENT SOLE SOURCE CONTRACTS WITHOUT APPROVAL FROM THE BOARD. I cannot believe I just had to even say that.

**Mel Pino**: Nothing about how the faculty unions are fighting reopening all over the state. 

**Mel Pino**: Ask what the position of faculty is

**Mel Pino**: That median age is key. That's what I sent you this morning.

**Mel Pino**: Thank God she is doing so much better she is right where she needs to be on these stats

**Mel Pino**: Kevin is very close with the motts

**Mel Pino**: Remember the data is only as good as the hospital are providing her. She has been spot on with the data that is outside hospital control.

**Mel Pino**: What fucking peak. Do you see a peak on that chart?

**Mel Pino**: Saying "peak" doesn't mean it's a peak.

**Mel Pino**: Pretty easy to keep those numbers nice and low when you're not testing everybody at the jail.

**Mel Pino**: A memo. How quaint. Corona just loves memos. It eats them for breakfast.

**Mel Pino**: You probably realize that the reason the city is here is that Janice is boxing them out of money and lying to them about how CARES works. Those 3 city people are no dummies on how stuff works yet she is supremely confident she can game them all. That is NOT what the county is supposed to downtown . You guys sit over the city not to starve them of funding but to foster the appropriate funding. They are desperate with how this EOC is functioning under her. 

**Mel Pino**: We get the other 75 percent by her gifting a consulting friend to come up with a plan we should have had months ago and then gifting Janice with full atuomous proxy to do whatever she wants and sole source contracts.

**Mel Pino**: Please note the pushback.

**Mel Pino**: What other communities have done is get together with their partner agencies and taken public input and come together with a community plan. Early. And they already have their money.

**Mel Pino**: According to the agenda she is going to have emergent sole source power. Is that just for vendors? Or is is for sub recipe? Look at the language of what you guys are supposed to vote on. It looks to me like if you guys vote that language she does whatever the he'll she wants. Very little restraints. She can move money around at will.

**Mel Pino**: Jeff are you going to help? Amor just sit there?

**Mel Pino**: Or just sit there. You lack of participation is glaring. 

**Mel Pino**: Let Doug sit back. Steven and robert and lumon are trying to drive at what's going on and we need your voice also.

**Mel Pino**: Steven is pushing back. Everybody else needs to also. Please.

**Mel Pino**: You see? Please give voice.

**Mel Pino**: I hope you are taking it all in to come in after. Here what Robert just said? The tide is turning.

**Mel Pino**: Rolling app but the main thing is Jeff you guys have to get back control of the spending. She will not care about this pushback. She will still do whatever she wants. Remember Maygarden.

**Mel Pino**: Please, Jeff, your peers need your voice. 

**Mel Pino**: BAM.

**Mel Pino**: Did she put out an RFP?

**Mel Pino**: THANK YOU

**Mel Pino**: This Firm that she just trashed...I will be asking Mike if it's true.

**Mel Pino**: Oh my god she is trying to stall in a COW. Unbelievable

**Mel Pino**: Looks like integrity group blog was up and coming in DC in 2015 and hasn't updated their blog since 2016. Grant Horton is Th in the world.

**Mel Pino**: This is so fucking unnecessary and Janice has driven this division.

**Mel Pino**: There is no TIME for that bureaucracy.

**Mel Pino**: Jeff do not beat Grover up. The optics of this is TERRIBLE. This is awful this division. Be the one to step in and heal it. Extend a hand and shake it don't give him the back of it.

**Mel Pino**: You do not want to align with Doug and robert in this talking to. It's fucking ludicrous.

**Mel Pino**: Talking down to. THANK HIM for what he has done

**Mel Pino**: It will be such a good look.

**Mel Pino**: Really. To start out by taking him and Keith would be such a nice look Jeff. Not a single person has thanked him

**Mel Pino**: Thank you. The problem is that Grover can't trust Janice. She will take it. She won't implement etc. He is trying to make sure he can get it autonomously because she won't deliver.

**Mel Pino**: Btw I have been working on the homeless problem with chip and Michael Kimberl but we can't get anywhere because Janice. And Tim day. It is very frustrating.

**Mel Pino**: Pathetic.

**Mel Pino**: Across the board.

**Mel Pino**: Ohio Gov Mike DeWine tested positive.

**Jeff Bergosh**: In mtg will call back

**Mel Pino**: Left you a message primarily on that holding company sole source consulting BS

**Mel Pino**: And her trashing that other reputable company

**Mel Pino**: This is exactly what I have been told is going on at the jail through numerous sources.

**Mel Pino**: 4 more deaths in Escambia (56, 66, 72, 74 years old) and 2 more in Santa Rosa (76, 89). 

**Mel Pino**: Which is their every right.

**Mel Pino**: Oh you know what he's right. Fuck it. Let whoever is gonna die die. What have I been thinking. Weed em out.

**Mel Pino**: Don't let him rile you and rise to the bait. Fuck him. 

**Mel Pino**: Hahahahhahahahaa

**Mel Pino**: QAnon alert.

**Mel Pino**: So why are they just telling him? These games are so tiring.

**Mel Pino**: This is nothing more than Doug fucking with him and Alison helping.

**Mel Pino**: Steven is starting to step in. Thank God.

**Mel Pino**: I understand Robert it worried about liability. He should be. You all should be. She is opening this county to crippling liability on so many fronts.

**Mel Pino**: https://www.buzzfeednews.com/article/laurenstrapagiel/north-paulding-high-school-suspensions-for-hallway-photos

**Mel Pino**: https://www.pnj.com/story/news/2020/08/06/michelle-salzman-files-complaint-over-mike-hill-ad-implying-she-supports-defunding-police/3310197001/

**Mel Pino**: One of Alex's buds.

**Mel Pino**: Hahahahhahahahahaa

**Mel Pino**: That is complete and utter bullshit. I have practiced eastern medicine for 20 years and she is full of shit.

**Mel Pino**: All of my friends who practice any form of alternative medicine are laughin our asses off.

**Mel Pino**: How nice that janice's plan of failing to test Escambia staff adequately and making their quarantine pay uncertain has resulted in such a low rate of infection. It's magic.

**Mel Pino**: You know Larry and Alice had covid right? And he was down bad from it despite what he says online.

**Jeff Bergosh**: I did not know that

**Mel Pino**: Jeff  I don't know anything about this next item getting denied. Wasn't at meeting and don't have an opinion. But fyi Anthony Baraco is Doug's long suffering next door neighbor (separated by a lot) who has threatened to sue him on that jet ski course. He has been ill so wouldn't surprise me if he himself is not there. Just wanted you to have the heads up on the acrimony.

**Jeff Bergosh**: Getting dropped

**Mel Pino**: Why am I not surprised Doug is messing

**Mel Pino**: And bringing up ex parte

**Mel Pino**: Post vote. They know what's up. Nobody is fooled. Stall tactic. Trust me on that. Eyes open.

**Mel Pino**: And that even helped you in your district cause it looks like you died on your sword when you didn't.

**Mel Pino**: Trust me, there are eyes wide open up there tonight. 

**Mel Pino**: Check voicemail

**Mel Pino**: Hahahahahahahahaahha consultancy

**Mel Pino**: What consultants? Is this forgone?

**Mel Pino**: Look how that fucking hypocrite won't touch the podium now because he doesn't want the germs but he has no mask to blast his own covid germs all over the chambers

**Mel Pino**: By the way what the fuck is the exact name of his company.

**Mel Pino**: There is no "integrity group" on sunbiz

**Mel Pino**: "Much like a FEMA grant process" that's reassuring.

**Mel Pino**: Oh he did Medicaid. Great.

**Mel Pino**: He is a system brought in by Janice jeff

**Mel Pino**: Shyster

**Mel Pino**: This is fucking ludicrous

**Mel Pino**: Ask him why he isn't touching the podium

**Mel Pino**: None of you are following CDC guidelines right now. Your board is a fucking joke

**Mel Pino**: MORGAN WENT ON THE NEWS LAST NIGHT AND SAID HE WAS PISSED  PEOPLE LIED TO HIM ABOUT THE VIRUS

**Mel Pino**: Oh for fucks sake. Are you serious.

**Mel Pino**: That's it. I'm done. Good luck to you Jeff. Godspeed.

**Mel Pino**: Honestly. This is so fucking pathetic. I'm done. Good luck. .My phone is open if you ever want to have a serious conversation. You guys look like idiots right now. Good night and good luck. I'm done.

**Mel Pino**: And I mean completely done.

**Mel Pino**: What the FUCK is wrong with you

**Mel Pino**: Get on the right side Jeff You do NOT want to be on the wrong side if this

**Mel Pino**: Sack up and do the right thing

**Mel Pino**: You always say that nobody has any guts. Well there is is. This is history deff. You will always be on record with what you vote. You are worried about the primary. Nut your vote on this is how many people live and die

**Mel Pino**: Jeff I am still a total supporter on you getting re-elected. But on this issue; you should be ashamed. And you will be. I believe you have this election and fr that I am grateful. But on covid,  I'm done talking with you on it any more. Call if you want. I'm pretty much finished with all of you pansy assing. Over and out.

### CONVERSATION ON 08-07-2020

**Mel Pino**: Mr. May, 

I just want to say thank you for the huge, admirable effort you put forth tonight to protect EC residents & business owners. 

The Doctors have been pleading with the County, yet it s fallen on deaf ears - except yours. None of you guys have a medical degree, yet you chose to ignore the strong pleas from medical professionals, citizens, county employees, & city officials. We all knew Underhill would refuse to help us, but there was hope for the other commissioners. Yet you all took the cowardly route & let politics take precedence over a humanitarian issue. 

You all really should be ashamed. I have no idea how any of you sleep at night, knowing you didn t do a damn thing to help minimize the spread to protect us. Mr. Bergosh, I had hoped you were taking your blinders off, yet it s obvious that was all just a facade. Mr. Bender, you brought up the letter from the Doctor s that are asking for help, yet bailed & left Mr. May to fight for us by himself. You all bailed out on doing your part to help save lives during a pandemic. Really let that resonate! 

Mr. May, I truly hope you re re-elected because you ve shown how hard you re willing to fight for your constituents. I hope the rest of you are voted out, especially you Mr. Bergosh! 

You're all a bunch of cowards! 

**Mel Pino**: Email sent to me. 

**Mel Pino**: And I agree with Every statement made.

**Jeff Bergosh**: So you hope I'm voted out?   That's what he said.  Is that your hope?  That letter is shit, and so are you if you agree with it!

**Jeff Bergosh**: Later

**Mel Pino**: No I don't hope you are voted out, Jeff. And that's not what the letter said.

**Mel Pino**: Thank you for calling me shit, though. Please know I consider you a friend and I respect you which is why I am so distraught with your inaction.

**Mel Pino**: My letter wasn't calling for your removal. Read it again. I clearly stated you would be re elected and set it up for two weeks til the next meeting when something will have to be done.

**Mel Pino**: If you were collected right now you would realize I set you up to come in and do something two weeks from now.

**Mel Pino**: I did not call you out in particular. I called the board out for its inaction. Out the because YOU proceed on emotion far more than you realize you didn't see that. I have a longer post pending on northescambia but I don't know if William will print it. It does not call you out in particular. Truly the failure of this board is across the board Jeff.

**Mel Pino**: My phone WA literally pummeled with disgust lat night over that bullshit circus sideshow all of you participated in last night. Don't blame me that you guys looked like a bunch of dipshits. I'm trying to deal with the fallout.

**Jeff Bergosh**: You said "That letter was sent to me, and I agree with every word". The letter you referenced said "I hope the rest of you are voted out, especially Mr. Bergosh"

**Mel Pino**: Jeff, this is off record because it is not about county business. I really love you, as a friend. I care about you.

**Jeff Bergosh**: Your words.  

**Mel Pino**: No! Hat was an email forwarded to me! Not my words!

**Jeff Bergosh**: Anyway-- I've got lots of work to do today- taking a break from the drama.  Shutting down for a weekend. You should consider doing likewise.  Bye!

**Mel Pino**: I was forwarding to make sure you saw it!

**Mel Pino**: That was Kim c

**Jeff Bergosh**: You said you agree with every word.  Do you?

**Jeff Bergosh**: Take a weekend off

**Mel Pino**: Im sorry I truly did not mean I agreed with the statement made on you. I apologize for tha Jeff...Truly. I meant globally. Of course I do not agree you need to be voted out. I am so sorry, truly, I left you with that impression and it is not your fault that I did.

**Jeff Bergosh**: Thanks.  We should all attempt to turn down the drama and rhetoric

**Jeff Bergosh**: We will never get it the way we want it all the time-- never.  It's not Burger King we don't get to "have it our way". Life's not like that.  Have a good weekend

**Mel Pino**: Jeff people are on a razors edge because there is very little time. I am honestly so sorry I left you thinking I agreed with that statement that must have felt horrible. Trust I'm sorry.

**Jeff Bergosh**: I have stacks of work to do

**Jeff Bergosh**: Going to get on it.  I'll talk to you next week

**Mel Pino**: Ok.

**Mel Pino**: I have stacks of work to do

**Mel Pino**: I was trying to play that back and say "I have stacks of work to do too" on submitting evidence to the navy on Doug but I sent too early. I sent a second round on my repopened complaints yesterday

**Mel Pino**: Also, I believe that the county is paying Dr Edler's legal fees in th Selover suit not just in her professional capacity but also her personal capacity. I hop you will verify. A terrible precedent for obvious reasons if that is true.

**Mel Pino**: I wonder if they are also paying for Doug now in his personal capacity in the bear suits.

**Mel Pino**: I honestly don't know that was a true wonder.

**Mel Pino**: Sorry Jeff I only plague you with that page when I feel like you really need to know about something.

**Mel Pino**: And they are running with the fantasy that there was a conspiracy behind their sons charges again. Pathetic.

**Mel Pino**: Fyi this slug who spoke last night is the guy who led the QAnon parade in front of my house and later painted "BLM R FAGS" on the back of his pickup truck.

### CONVERSATION ON 08-08-2020

**Mel Pino**: Keep this to yourself but we are working to get Jacqueline kicked off willies site. It might not work but we are trying.

**Mel Pino**: Ok Willie is on a truck today but said he will remove her later today. Again please keep that to yourself and Sally and keep fingers crossed because Willie may chicken out if Underhill gets to him. She violated community standards by bringing those posts to her own site.

### CONVERSATION ON 08-11-2020

**Mel Pino**: Hi Jeff, I might not keep going too hard on the L
"Jonathan is nowhere in this race." I was worried when I saw that and sure enough the Jessie people are passing that around and trying to peel Jonathan voters to Jessie with it. Tracy is a firm supporter of yours the problem is there is so much bashing on Jonathan and of course nobody saying a word about Casey. Makes me nervous even some of those firefighters will secretly flip if they don't think Jonathan has a chance.

**Mel Pino**: Whatever Larry. I will look forward to reading the criminal complaint and the this charges on Lumon. Surely you will be following up with filing them after all the accusations you have thrown down about it. Can't wait for the investigations to clear him on that and maybe the discovery will go a little further past lumon.

**Mel Pino**: Criminal complaint and ethical charges. We are all expecting that. And will Sean be filing a criminal complaint against Bergosh? I'm sure you guys have thought this through per your own accountability and reputations. So get crackin and let's see the result of those investigations.

**Mel Pino**: Been fighting with that asshole via text off on on for hours. Done with it. If he and Sean want to keep spreading shit then put you money where your mouth is and file the complaints.  Which will end up in zero.

### CONVERSATION ON 08-12-2020

**Mel Pino**: I've pretty much given up on moving anyone to reason or action on covid. There have been 5 things a day I've thought about forwarding since Thursdays meeting and realized, what's the point. Doubt this one will phase anyone, either. Just the DOH admitting to hiding all those cases I said they were hiding leading up to the fourth of July. Oh, except it was the lab that didn't report them. Yeah, right.

**Mel Pino**: https://www.pnj.com/story/news/crime/2020/08/12/mom-says-daughters-room-sacred-heart-hospital-crawling-bed-bugs/3344710001/

**Mel Pino**: So when I have been calling the conditions in the hospitals "horrendous" I have been speaking to the very obvious thing that of course they can't keep up with basic sanitary and sterilization. There's no way these sorts of things aren't going to happen with as chaotic and understaffed as they are. But I had no proof just confidences from hospital staff who are too job scared to even go on anonymous record for fear the accounts will be traced back. Tonight our neighbor friend told us his wife, who is a nurse at sacred, has 17 of 22 out on her team. This will get worse. And of course the more serious thing than bedbugs is that they have been lying about the strain on non covid care. How could there not be?

### CONVERSATION ON 08-14-2020

**Mel Pino**: According to WaPo, at least 671 USPS mail sorting machines have been removed across the country since June. Represents a reduction in national mail sorting capacity of 21.4 million pieces of mail per hour. 
https://www.washingtonpost.com/local/md-politics/usps-states-delayed-mail-in-ballots/2020/08/14/64bf3c3c-dcc7-11ea-8051-d5f887d73381_story.html

### CONVERSATION ON 08-15-2020

**Mel Pino**: Hey if you got 15 minutes today and feel like talking I have info on that EMS bullshit. She is gearing up to privatize, Jeff. As part of her ripping down the functionality of the county to hand the power over to the city. Peacock is making the rounds on charter for studer. I am not against charter and actually agree with what you have said on it but NOT at the expense of the county getting raped and losing its power base.

**Mel Pino**: Reading you blog....this is why I was urging you to look at the docket because Alison has been lying to you guys on various cases and how they are going for the county.

**Mel Pino**: She is running the same games on the bear cases fyi

**Mel Pino**: Put up a two part response to your blog that gets to some of what I was wanting to convey about what has been going on. 

**Mel Pino**: They're barn burners :) and ithank you on that merit system protection language and make VERY clear how important that was and that you were the only one willing to deal with it.

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-16-2020

**Mel Pino**: Jeff I just had a ball responding to the anonymous flying monkey. Please post as soon as you can hahahaha

**Mel Pino**: Hahahahaha omg I just figured out what U Vuit is....laughing so hard I am crying. Posted a follow up 🤣🤣🤣🤣

**Mel Pino**: Still laughing...god I needed that they are SO fucking nuts

**Jeff Bergosh**: That posts getting crushed with hits today

**Mel Pino**: Good they will all see my comment thanking you for getting the MSPB straight, addressing you as commissioner elect and putting it into your hands as the only one who can and will fix public safety once for all. I am still laughing my ass off people's skulls are literally cracking in. Kim Carmichael could not be any more real for God's sake...they are losing it haha

**Mel Pino**: I want to get somebody to come under fire's Owens post on "response time matters" and make a joke about premature ejaculation.

**Mel Pino**: Btw Jesse is posting hot and heavy there with willies blessing of course. 

**Mel Pino**: Hes digging his political grave that is for sure.

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: Here's the way it's going to play out:

12,500 votes D1 total= 29.5% turnout......

Bergosh.     40%
Casey.         35%
Owens.        18%
Trotter.         7%

You heard it here first

**Mel Pino**: Oh god I hope so Yakima black is running her fucking trap non-stop and that might shut it for a while

**Jeff Bergosh**: It's my prediction based upon the six polls Run in my race combined with historic voting patterns in the primary over the last 15 years combined with trends I've seen in these polls combined with what momentum I feel when I am out waving and  a gut feeling based upon my experience.   But hey, the only poll that counts is Tuesday's, right?  Jesse is my only threat in this contest, Jonathan finishes a distant third-- you can take that to the bank!!

**Mel Pino**: Oh I need no convincing of that he is nowhere. I just don't trust these idiots not to vote for somebody who can't even show up for a debate. Scares the shit out of me. The masses that actually mobilize themselves to the polls have never been more willfully self deluded. This will be one for the record books and I want it over bad.

**Jeff Bergosh**: Yes me too.  That's the troubling aspect of it all.  The electorate is powerful, yet quite fickle and apathetic and often ignorant of the salient issues that are actually important. So if they like a person's smile-- they often (particularly in these local county races) will vote for him/her regardless of actual qualifications, achievements, experience, etc.   But if they were going to toss me out--- I do not believe I would have been in the lead in all 6 polls.  But this year's like no other with COVID and a collapsing economy so we shall all see on Tuesday. I stand by my prediction.  I win by 4-7 points and 450-700 votes.  😎👍

**Jeff Bergosh**: Yes.  What email do u want me to send it to Vicki

**Mel Pino**: God help us. I don't think the economy is collapsed enough yet for it to be precisely that. I think covid concerns are still foremost and I have zero sense of where that all falls out between the people livid there has not been enough response and people who are thumping their constitutions for more freedom. I know where all that will be in two or three months. We just haven't hit the pivot point. Still chaos.

**Mel Pino**: Hey that message to Vicki sent to me

**Mel Pino**: Dont miss texting her.

**Jeff Bergosh**: Thx

**Jeff Bergosh**: She needs the polling place list

**Mel Pino**: I hate like hell that piece of crap didn't have to run much because of covid but she will will handily. Makes me puke but there is nothing for it.

**Mel Pino**: She needs a hell of a lot more than that.

### CONVERSATION ON 08-17-2020

**Mel Pino**: You just could not possibly understand how much I hate this bitch.

**Mel Pino**: Weak last ditch.

**Mel Pino**: Voila the opposite of an October surprise.

**Jeff Bergosh**: Means nothing.  Too little, too late.  You'll see tomorrow

**Jeff Bergosh**: I'll get by Jesse, and it will be close----but Jonathan gets nowhere near the leaders.  He's 15 points back of me tomorrow at 7:00.  Watch and see😎👍

**Mel Pino**: That's why I sent it--look Ma, nothing left in the tank. Amateurs. Doesn't mean I don't still hate her evil heart. Larry is another one I have about had enough of. Spent the last 4 days beating him down on his lousy choices

**Mel Pino**: I CANNOT WAIT

**Mel Pino**: It's Michelle I'm worried about we are fanned out across various sites doing what we can to get last minute voters. Kim C is working on the cancel culture kids I've got Rick's blog and Charlotte is dealing with willies.

**Jeff Bergosh**: What did Larry do?

**Jeff Bergosh**: I cannot wait either

**Mel Pino**: He's out of his mind and spinning like a top. Had Jesse at a fight 2 nights or so ago. Supporting lutimothy, posting in support of Q
Anon.

**Mel Pino**: I put the fear of God into him as much as I could to try to keep him from opening his big mouth at all this week.

**Jeff Bergosh**: Supposedly he is endorsing me

**Jeff Bergosh**: So we will see

**Mel Pino**: Put up a photo of him and Jesse leading up to primary. I've got him sulking in a corner and wondering if he fucked up. He even whined to me "why won't you leave me alone." Are you fucking kidding me.

**Jeff Bergosh**: I knew about the photo but he's not endorsing Jesse

**Mel Pino**: He literally doesn know which end is up or what day of the week it is these days. 

**Mel Pino**: He's playing both sides all over the place and just scrambled. It's not a plan or anything.

**Mel Pino**: Honest question: did he come out and officially endorse you anywhere? I hope he did I honestly don't know.

**Mel Pino**: He's so fucking irritating these days I don't pay much attention until he goes way out of line and I'm the only one that will try to take him to task. But no fyi I haven't spoken to him about your race at all. Just keeping tabs.

**Jeff Bergosh**: Yeah he did, I have a big sign up on his property and he let me enter this quote on my website

**Mel Pino**: Okay good

**Jeff Bergosh**: Yeah in the end it doesn't matter anyway

**Mel Pino**: Not for the primary but this shit with him and arduini and the growing qanon stuff won't end with the primary. Lutimothy won't be able to find a barber chair after the last few days though. He just needs to slink away into a hole and get back to being the scumsucking POS everybody knows he is. 

**Mel Pino**: He ought to be in jail after all that contempt forgery and extortion.

**Mel Pino**: I was very difficult sitting on all that knowledge for all those months and thank God it is out there now and the black community is dealing with it. Lumon will be on gerald Graham tonight at 6 and if lutimothy knew any better he would have already packed his bags.

**Mel Pino**: Just got sent this...on 10 oclock

### CONVERSATION ON 08-18-2020

**Mel Pino**: This fucker. I am telling you Jeff there is a very, very bad political element in this town that has taken root and will not be over after the primary. Thank God they will have three incumbents with four more years to fight it bit this nexus of lunacy will have to continue to be dealt withm

**Mel Pino**:  I'm serious about this: call Larry and ask him if he will help on Willie's page today with supporting you. Not just for the support which will help but it's a litmus if he doesn't do it. He is over there throwing down on lumon so if he is there anyway why isn't he countering the owens posting. Not one fucking word that I have seen lately. Serious as a heart attack give him a call and ask for him to do some support there today and let's watch the results. You don't need it but it would still be good for you all told and I want to see if that fucker wil do it. I got Kim to lay off you in advance of the primary but we need somebody posting pro Jeff there today and ten to one that asshole won't do it.

**Mel Pino**: Wow over 32 now Jeff you have to tell me when you know just a single text "I got it"

**Mel Pino**: Jeff PLEASE tell me this is right

**Mel Pino**: Please

**Jeff Bergosh**: Yep-- I won by 8 points!!!!

**Mel Pino**: Wooo hooooooooooooooooooooooooooooo

**Mel Pino**: Michelle won!!!!!

**Mel Pino**: I told ya :)

**Mel Pino**: Yeah!!!!!!!!!!!!!!!!!!!!!

**Mel Pino**: ♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️♥️

**Mel Pino**: Woooooooo hoodoo!!!!!!!!!!!!!!

**Jeff Bergosh**: She really pulled an upset!!

**Mel Pino**: I TOLD U SHE COUKD hahahaha

**Jeff Bergosh**: Yep

**Mel Pino**: Maybe you will start believing me hahahha

**Mel Pino**: Love love love love to you and Sally WOOOO HOOOOO

**Jeff Bergosh**: 👌👍

### CONVERSATION ON 08-19-2020

**Mel Pino**: Posted to your blog



**Jeff Bergosh**: K

**Jeff Bergosh**: Out picking up signs

**Mel Pino**: Okay I don't have anything just happy :)

**Jeff Bergosh**: 👍

**Mel Pino**: https://inweekly.net/winners-losers-8-20-20/

**Mel Pino**: Hahahahaha look at the last loser. 

**Mel Pino**: Also why is there no congratulations to commissioners elect on the county Facebook page? 😡

**Mel Pino**: https://ricksblog.biz/two-biggest-primary-losers/

**Mel Pino**: I'm afraid they are going to get a lot of traction back with you not being at the meeting tomorrow Jeff :(

**Mel Pino**: BAM


https://ricksblog.biz/pastor-may-cited-for-acts-of-contempt-claims-bribery/

### CONVERSATION ON 08-20-2020

**Mel Pino**: Jeff fyi you were supposed to have the invocation and Steven called out to the audience but nobody was there :(

**Mel Pino**: They scheduled a special meeting for after you're back on the cares stuff and the accenture procurement

**Mel Pino**: Lumon got it kicked and dug into Janice on that damn consulting

**Mel Pino**: Quote of the day "we havent really had those discussions yet." Janice Gilley on how much we are paying the consultants for the portal. No shit.

**Mel Pino**: Lumon got the public hearing on the fifth cent onto the agenda for the first meeting in oct

**Mel Pino**: Steven was very irritated with Janice throughout the meeting.

**Mel Pino**: Apparently we (Lifeguard) now have a COPCN to not only run all of the ALS and BLS trucks but also to put 3 ALS 911 ambulances in Escambia county to run calls now. 

**Mel Pino**: Did you know that?

### CONVERSATION ON 08-21-2020

**Mel Pino**: https://www.pnj.com/story/opinion/2020/08/21/lincoln-project-between-hurricanes-and-covid-desantis-failures-make-perfect-storm/3408231001/

**Mel Pino**: https://www.pnj.com/story/news/2020/08/21/pensacola-dlux-print-owner-gerald-mandel-sentenced-over-fake-invoices/3412315001/

### CONVERSATION ON 08-22-2020

**Mel Pino**: In WSJ today, a group of dozens of Republican National Security Officials -- basically every GOP luminary of the last 30 years -- took out a full page ad to say “enough” to Trump. 
https://www.defendingdemocracytogether.org/national-security/

**Mel Pino**: That Soros fuelled conspiracy just gets bigger

### CONVERSATION ON 08-24-2020

**Mel Pino**: I posted back to "somebody's" toothless QAnon delusions. Been getting that same crap into my email for a half a year.

**Mel Pino**: https://ricksblog.biz/pastor-may-cited-for-acts-of-contempt-claims-bribery/

**Mel Pino**: Check my comment there.

**Mel Pino**: https://www.tampabay.com/news/gradebook/2020/08/24/school-reopening-lawsuit-judge-rules-in-favor-of-florida-teachers

Florida teachers win lawsuit against state on reopening.

**Mel Pino**: Thank God there is one sane person left in this state.

### CONVERSATION ON 08-25-2020

**Mel Pino**: https://ricksblog.biz/category/news/politics/escambia-county/

**Mel Pino**: Check messages when you can. Trying to help get the pregnant females out and public defenders office is stonewalling natch

**Mel Pino**: Gee, I wonder where she got that idea from. No way would she lay something down I have been saying since everything I say is mean politics and conspiracy. This is coming straight from Doug and he oughtta know.

**Mel Pino**: Gigi Owens was one of edler's besties and the woman she made other medics give an IV to in her office off paper while she was there (admitted in court that I did not lie about that in my DOH complaint). There was a falling out and Gigi went to SR LG and is now speaking out against jacqeline and saying it's not about the money.

**Mel Pino**: Jeff 1. A judge can order those pregnant prisoners released. 2. If they can't afford their ankle bracelets then there are JAG grants possibly and I can't see why cares money cat apply. 3. If any of them are in for serious crimes then we need to find money to have them housed in a separate facility that is set aside for all pregnant females for the duration of covid. We need some ad hoc facility for at risk patients including elderly with separate wings.

**Mel Pino**: Where they can get processed from. No holding in the jail so they can catch covid while clearing.

### CONVERSATION ON 08-26-2020

**Jeff Bergosh**: Swamped 

**Jeff Bergosh**: Will call u later

**Mel Pino**: Cool take a listen to my messages. 

**Jeff Bergosh**: Already did 

**Mel Pino**: Going to leave you a message with another piece to this puzzle.

**Mel Pino**: https://ricksblog.biz/females-inmates-continue-to-speak-out/

**Mel Pino**: This blog is the catalyst Jeff. This is actually what is happening. Please don't fool yourself this is fake news or prisoners making stuff up. This is real.

**Mel Pino**: Can u please forward that to your brother so he sees it?

### CONVERSATION ON 08-27-2020

**Mel Pino**: According to the American Academy of Pediatrics and the Children's Hospital Association, 74,000+ US children diagnosed with COVID-19 in August. 

Though they show fewer symptoms, and require less hospitalization, they are a key vector to spread events. The lack of testing & tracing will not show how broad this will go, but it could take education offline as teachers get sick and are quarantined.

https://www.forbes.com/sites/carlieporterfield/2020/08/26/coronavirus-cases-in-us-children-rose-21-in-august-study-finds/?

**Mel Pino**: The rate of childhood coronavirus jumped over twenty percent over a two week period as a result of schools opening back up. That's even with a low rate in kids getting tested because a lot of them don't show symptoms even though they may be incurring lung damage.

**Mel Pino**: Hey no need to call back but left you an important message please listen before the meeting. On consultants.

**Mel Pino**: Per my voicemail I think it was "Neighborly software" that neighborhoods JUST brought the last meeting. Budget finance consent agenda II.25. Robert made the motion and lumon seconded. No sooner got passed than neighborhoods got told to rewrite all their shit for the consultant portal and then they got blamed for the consultants. I hope this shows you what it is like to be Escambia staff right now. Day in and day out it is a crying shame. I get what you are saying about not coming after "staff" publicly but when you don't hold these upper management accountable publicly it is the worker bees who suffer. Berate them behind the scenes and they will act like it impacts them then laugh about it over drinks after the meeting. And that is no lie.
One or more media attachments were removed.

**Mel Pino**: Woo hoo!!!!! Doug's not there

**Mel Pino**: Fyi Robert has been tepid and even somewhat snarky on races and he acted like he was the damn chair last meeting.

**Mel Pino**: Every single thing he acts now like he is leading.

**Mel Pino**: Oh Lord Jacqueline is in the house. She is on a tirade about EMS don't know if she will slide it in.

**Mel Pino**: Oh he'll no. Not more documentation. We certainly wouldn't want that.

**Mel Pino**: Jeff remember the thing about that dollar amount on rent is that the landlords will take the quick cash then just boot people as soon as they can. Ask Meredith about that.

**Mel Pino**: Or the savvy landlords might not take the money because it will be more complicated to evict. There's only so much control the county will have but it is at least good that people understand these things

**Mel Pino**: Meredith is of the opinion that these caps will just end up pissing some amount of the money away

**Mel Pino**: There aren't any good answers :( so at least you guys should have that discussion up front so you can be aware of the pitfalls

**Mel Pino**: Exactly. There need to be some case by case.

**Mel Pino**: THANK YOU

**Mel Pino**: Consult staff!

**Mel Pino**: You guys need input from neighborhoods not this continued fiasco of the clerks office dictating bocc budget

**Mel Pino**: BINGO hire some foot soldiers instead of hire salary admins

**Mel Pino**: He's right Jeff that's how the system gets gamed and squeued to the people who game it

**Mel Pino**: I agree don't assess the apps until they are all in but longer window

**Mel Pino**: Kill the consultant and hire more support staff to assess apps and verify

**Mel Pino**: A longer window with a lot of outreach

**Mel Pino**: Jeff it would be a nice gesture if you guys all agreed to a certain percentage of that Levin money to go to this. Vote it while Jeff gone

**Mel Pino**: Let the Pnj try to attack THAT

**Mel Pino**: Sorry while Doug is gone

**Mel Pino**: End around that SOB

**Mel Pino**: NICE

**Mel Pino**: On call center

**Mel Pino**: This is so awesome to see you guys working together like this Jeff. Her days of dividing and conquering need to be over.

**Mel Pino**: I wonder who texted Alison that she had to run off the dais and call.

**Mel Pino**: And that's why Alison left the podium off a text.

**Mel Pino**: He's complicating this to argue for consultancy

**Mel Pino**: We have no idea if he just recommended what Meredith spoke to him.

**Mel Pino**: If Janice cared about best practices in other counties we wouldn't be in this mess right now.

**Mel Pino**: Meaning not the discussion today which is great but the money sitting fallow to be snapped up by consultants

**Mel Pino**: Right and yet Robert is demanding staff to do one of interventions on evictions for people in his district. And that is the stone cold truth.

**Mel Pino**: And Janice and chips blew off Keith's plan that Robert asked for. He told them that all that had to do was lay out the ask including money and they didn't even respond to the email.

**Mel Pino**: City has had it with even trying to work with her as had ECSO. The latter is done with it.

**Mel Pino**: People will already be on the streets by the 15th. She is such a fucking joke.

**Mel Pino**: He is speaking the truth Jeff. It is getting reall bad out there already but there is a time lag on understanding.

**Mel Pino**: Jeff we have been all over those databases for a long time. I finally told Kevin to stop looking at it because all it did was piss him off.

**Mel Pino**: https://www.tallahassee.com/story/news/2020/07/08/florida-ppp-loan-recipients-database-coronavirus-pandemic-search-full-list-businesses-covid-19/5397392002/

**Mel Pino**: It has been out for a long time.

**Mel Pino**: Maybe Janice awarding the grants before you guys voted on it might have helped. 

**Mel Pino**: Notice the knee jerk to just defend defend defend anything she does by a particular commissioner.

**Mel Pino**: Is it a not for profit that provides public health and safety and human services?

**Mel Pino**: Who is he shilling for?

**Mel Pino**: Is it a not for profit that provides public health and safety and human services?

**Mel Pino**: I am going to Non profit myself and put in for a grant for support in dealing with the long term effects of Janice.

**Mel Pino**: CDC IS NOW DIRECTING ALL INMATES TO BE TESTED. PERIOD.

**Mel Pino**: 1 fucking positive in the entire jail. Do you understand how implausible this is Jeff??

**Mel Pino**: "If we decide to test the entire population." Who the fuck is we?

**Mel Pino**: Surely you can see what bullshit this is.

**Mel Pino**: Is the directive to also test all the road camp?

**Mel Pino**: It's a miracle.

**Mel Pino**: https://www.nytimes.com/2019/11/27/technology/verizon-att-collusion.html

**Mel Pino**: https://mississippitoday.org/2020/08/20/mississippi-lagging-in-high-speed-internet-uses-pandemic-relief-funds-to-expand-access/

**Mel Pino**: The reason you guys can't get shit done on anything is because your upper level support is inept and completely suck. It's embarrassing how ignorant and inept they are.

**Mel Pino**: She has jaded senior level staff against you all to assume you are misers and impossible.

**Mel Pino**: And the de facto chair steps in to close.

**Mel Pino**: I tried to encourage chip for him and Morgan or Enrique to come for cares discussion but Morgan won't deal with Janice. Refuses.

**Mel Pino**: In other words she is calling Janice out for her bullshit.

**Mel Pino**: Honestly I hope you realize how horrible this looks beating the city up for doing the job on covid that the county has failed to do.

**Mel Pino**: So I guess cops don't get paid unless the are writing citations

**Mel Pino**: This is STUPID coming from a board against defending the police

**Mel Pino**: Robert is making an ass out of himself and making you guys look like dopes

**Mel Pino**: Quite frankly this county looks retarded schooling the city on anything per covid with the non performance on doing anything at the county.

**Mel Pino**: Chemical plant on fire in LA. They think it's bleach.

**Mel Pino**: Oh surprise more backup the public didn't get to see!

**Mel Pino**: I wish you would support Steven in getting him calmed down.

**Mel Pino**: It's going to be a long year next year I think with a new chair.

**Mel Pino**: Remember when I told you that the cutting staff bullshit was disinformation coming down from desantis?

**Mel Pino**: Well without you there Robert stonewalled for over two hours kicking and screaming and so they finally dropped it. Now the whole damn thing got kicked, has to be gone through again, it just gave Janice a chance to bolster her position, and Doug will be there.

**Mel Pino**: Robert wouldn't take the gavel.

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Two items on the agenda we should've been able to do it in three hours

**Mel Pino**: Jeff honestly you have got to start scheduling around. What is going on right now is too important for you to miss really important votes on back to back meetings :(

**Mel Pino**: It is not a good look despite whatever truth there is to the time waste. That's two meetings in a row and it had serious impacts both times they need you there.

**Jeff Bergosh**: Efficiency

**Mel Pino**: Robert has become a Janice handful. I think that they got it fixed in a way where they directed Janice and got around a vote but of course you can't trust her.

**Mel Pino**: Participation.

**Jeff Bergosh**: Efficiency

**Mel Pino**: You don't do us any good if you're not there Jeff: (

**Jeff Bergosh**: I'm typically there- 

**Jeff Bergosh**: The last weeks been busy

**Mel Pino**: Jeff this last two weeks has been badly--and I mean badly--hurt by your absence.

**Jeff Bergosh**: ..........and let's not get started on Lumon's attendance habits

**Mel Pino**: If you had been there that item would have been over in a half hour.

**Jeff Bergosh**: I don't think so

**Mel Pino**: Yes I know but I expect more from you.

**Jeff Bergosh**: I couldn't get a word in edgewise

**Jeff Bergosh**: Anyway will get it next week have a good afternoon

**Mel Pino**: And Jeff since April you have said to me over and over "Mel just wait until the day after the primary. The day after the primary I PROMISE." Member?

**Jeff Bergosh**: That's underway as we speak

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 08-28-2020

**Mel Pino**: Leftamessageon that item yesterday.

**Mel Pino**: It dropped 

**Mel Pino**: https://ricksblog.biz/how-did-county-government-become-so-callous/

**Mel Pino**: Check my comment there. Meredith will be under fire and needs support to get that software here as soon as possible and get people hired.

### CONVERSATION ON 08-29-2020

**Mel Pino**: http://www.northescambia.com/2020/08/three-escambia-students-covid-19-positive-at-ransom-jim-bailey-and-ensley-113-students-possibly-exposed

**Mel Pino**: See my comment.

**Mel Pino**: Idiots.

**Mel Pino**: Corporations cant afford to fool themselves about the duration of the pandemic. This is a mild first adjustment compared with what will continue as the pandemic rages on unabetted due to all levels of government grossly mishandling this pandemic, one of the worst response, if not the worst response, in the world by any developed country. In addition many companies nationwide who had planned to bring their workforce back around labor day are cancelling the plans and keeping as many people as possible remote.

https://www.wsj.com/articles/new-covid-19-layoffs-make-job-reductions-permanent-11598654257?mod=mhp

**Mel Pino**: Jeff I have the BEST idea dying to share it with you. Will leave a message. Might have to leave two. Want you to be able to think about it before next meeting.

**Mel Pino**: Check your messages!!! Hahahahahahaha

### CONVERSATION ON 08-30-2020

**Mel Pino**: Want to make sure you got told road crews shut down again and confirmed covid in road camp. BS "one case" game again.

**Mel Pino**: Btw even though I am on that list serve I didn't get that county announce. It was forwarded to me.

**Mel Pino**: I did end up getting the announce. Server delay.

### CONVERSATION ON 08-31-2020

**Mel Pino**: Hey call when you can...excited to talk to you about that voicemail I left

**Mel Pino**: Going to leave you a couple of voice messages with more information

**Mel Pino**: Last one

**Mel Pino**: This asshole.

**Mel Pino**: This is the "trashy" area that Doug made staff clear out.

**Mel Pino**: I sent an email laying out what the actual updated CDC guidelines are for prisons and posted the PRR in the comments section of this blog post. If Janice is actually following CDC best practices the plans I requested should be available and should not take any time to fulfill.


https://ricksblog.biz/more-on-covid-testing-in-the-jail/

**Jeff Bergosh**: In mtgs.

**Mel Pino**: No worries I have been trying not to bug you but so excited to talk to you about that

### CONVERSATION ON 09-01-2020

**Mel Pino**: Hey I just walked through the money asks on the agenda. Will you have time to talk today? Want to make sure I'm available when you will be free if you have time

**Jeff Bergosh**: I'll call u ltr today

**Mel Pino**: Yeah thank you

**Mel Pino**: Now they're getting somewhere. This is the same type of multi system attack that Lyme bacteria causes. Probably the autonomic nerve system is impacted also and I have seen the vascular symptoms in patients...like looking into a mirror of my Lyme symptoms. The blood brain barrier discussion is important also because if they don't take that into consideration with whether drugs they are using can cross that barrier, they won't get at some of the neurological complications that can lead to anything and everything.

https://elemental.medium.com/a-supercomputer-analyzed-covid-19-and-an-interesting-new-theory-has-emerged-31cb8eba9d63

**Mel Pino**: Left a message with confirm.

**Jeff Bergosh**: In mtg

**Mel Pino**: Left a follow up

**Mel Pino**: Jay Ingwell got the agriculture decision kicked.

**Mel Pino**: Marine advisory committee. Mark Moore awesome. May Watson not so much.

**Mel Pino**: I am headed out for a swim and will be back in an hour...will try you. School board meeting at 5 30. I had a good convo about that with a board member today.

**Mel Pino**: Rittel dropped out. 5 left. And we already have our first grammatical error, from the chair.

**Mel Pino**: Oh good Lord Kevin Adams is such an embarrassment. Jesus.

**Mel Pino**: Wait sorry down to three now

**Mel Pino**: Jeff PLEASE text Fetsko. This isn't even record it's not about county business. He is wavering.

**Mel Pino**: If you tell him you are disappointed it may sway it

**Mel Pino**: Kevin just cut off conversation and made the motion. Fetsko couldn't second fast enough

**Mel Pino**: (sent to Kevin Adams) Oh okay, so I guess that's what they call the "anybody but the black man" vote? I hope there is a discrimination lawsuit out of this the three of you will deserve it full well.

**Mel Pino**: (to Paul) Pure discrimination. And so obvious it was all pre planned. I hope there is a lawsuit in addition to an ethics complaint. 

**Mel Pino**: Cannot BELIEVE this shit they just ran for the third candidate with no discussion of his merits. Fucking unbelievable

**Jeff Bergosh**: Leaonard?

**Mel Pino**: NO they knew they couldn't get away with it so they positioned it as Leonard versus Johnson and after Kevin's motion for Leonard lost 2 3 Slayton immediately made the motion for the third candidate that got ZERO discussion and they were ready to vote him in over johnson

**Mel Pino**: It was HORRIBLE

**Jeff Bergosh**: So who is the superintendent?

**Mel Pino**: Jeff I can't even call his name to mind because he was NOWHERE in the discussion. Just call him the white guy they maneuvered to keep the black guy out. It was that fucking bad.

**Mel Pino**: And it was planned

**Jeff Bergosh**: So they picked??

### CONVERSATION ON 09-02-2020

**Mel Pino**: Left a message.

**Mel Pino**: Kind of important before meeting tomorrow

**Mel Pino**: Crap sorry Jeff my phone did something funky.

**Mel Pino**: Call me back when u can. I needed to make sure my phone wasn't conferencing on a voicemail I was leaving. It didn't.

**Mel Pino**: Fyi Lindsay Ritter is gone from EMS. She will turn on Edler now and that could get very interesting.

**Mel Pino**: It won't surprise me if she brings an (unjustified) discrimination suit against the county. She is trying to enlist jacqueline's support.

**Mel Pino**: https://www.wsj.com/articles/u-s-debt-is-set-to-exceed-size-of-the-economy-for-year-a-first-since-world-war-ii-11599051137?mod=mhp

**Mel Pino**: Is your meeting at 5 or 6?

**Mel Pino**: Check email for Powell's response to my PRR's and my replies.

### CONVERSATION ON 09-03-2020

**Mel Pino**: Situation NOT resolved we were discussing. Hornets nest to bring it Ip. Never any conclusion yet. If they are driven to conclude it they may go the wrong direction :(

**Mel Pino**: The display at 9 am sharp.

**Mel Pino**: Not online either. Maybe shade meeting running over?

**Mel Pino**: https://ricksblog.biz/once-again-county-administrator-fails-good-government-test/

**Mel Pino**: You couldn't pay me a million dollars to let them shoot me up with the shit Trump is fast tracking.

**Mel Pino**: https://www.factcheck.org/2020/09/cdc-did-not-admit-only-6-of-recorded-deaths-from-covid-19/

**Jeff Bergosh**: Surprise!  Me either on round 1 of the vaccine

**Jeff Bergosh**: .... coming from a guy who has never even taken a flu shot ever and who rarely gets sick

**Mel Pino**: Right? Also that 6 percent story got swung by a Qer that Trump retweeted and the disinformation was so dangerous even fox news rebutted it nationally

**Mel Pino**: Flu shots are a sham.

**Mel Pino**: So Kevin hasn't been able to work any cabinet jobs since covid. So he hasn't had any income but he can't apply.

**Mel Pino**: One job he can't finish is Marie mott's cabinets

**Mel Pino**: Zero income for months on end but he doesn't qualify.

**Mel Pino**: He can't demonstrate a loss because he was to get paid after the jobs and they came to a screeching halt.

**Mel Pino**: The sad thing is, and I don't say this to be a downer, this Grant money is a drop in the bucket and won't begin to touch the economic misery that will be hitting in the coming months. 

**Mel Pino**: This is what comes of Janice stalling the process out so she could box the board into what she wanted. And staff, and your reputations, pay the price.

**Mel Pino**: Oh Lord I cannot handle marina hour this early.

**Mel Pino**: Khoury

**Mel Pino**: And thus comes to fruition two years of Doug and downtown backdooring with navy federal with Teresa Blackwell actually believing she was running the show.

**Mel Pino**: You know you will be a hero if you can battle in some real public access and use 

**Mel Pino**: And even if it's futile just hearing an emphatic statement about the need for it will mean a lot to a lot of people.

**Mel Pino**: Are these guys aware there is a pandemic happening? Any thought at all to where the economy is headed?

**Mel Pino**: Blah blah blah blah blah

**Mel Pino**: Are they out of their fucking minds?

**Mel Pino**: https://www.businessinsider.com/homelessness-rising-pandemic-oakland-atlanta-nonprofit-organizations-2020-8

**Mel Pino**: This is all nonsense if the real economic circumstances aren't taken into account. 

**Mel Pino**: https://www.foxbusiness.com/economy/united-airlines-furloughs-coronavirus-pandemic

**Mel Pino**: They wouldn't dare dish out this nonsense if they were talking to corporate America.

**Mel Pino**: Amazing job Jeff. Fantastic.

**Mel Pino**: Having watched Joe mirabile rewrite the charettes

**Jeff Bergosh**: Thx

**Mel Pino**: They are so full of shit.

**Mel Pino**: "Helps people make better decisions as we lead the by the noe with the developers post boards."

**Mel Pino**: "Helps people make better decisions as we lead the by the noe with the developers post boards."

**Mel Pino**: NICE

**Mel Pino**: Maybe part of the Stormwater plan could be not cutting all the trees down.

**Mel Pino**: What's Doug gonna do, call Lewis?

**Mel Pino**: In other words shut the he'll up marina.

**Mel Pino**: https://www.washingtonpost.com/us-policy/2020/09/02/renter-eviction-lawsuit-trump/

**Mel Pino**: Alison's bullshit. THERE WAS NO FIRST APPEAL WHICH SHE WELL KNOWS. And no due process was quite obviously not followed. 

**Mel Pino**: Janice isn't coming to the meeting tonight. She is putting it off on chips

**Mel Pino**: Horace has covid.

**Mel Pino**: Rick pounding on the lack of backup for CARES.

https://ricksblog.biz/cares-housing-assistance-overwhelmed-closed-after-four-days/

**Mel Pino**: Bullshit Qer

**Mel Pino**: Maybe if Janice had made a mask mandate in county buildings Horace wouldn't have covid right now.

**Mel Pino**: 30-35% of BIG10 Athletes who have COVID-19 have myocarditis, a dangerous enlargement of the heart that can be fatal
https://amp.centredaily.com/sports/college/penn-state-university/psu-football/article245448050.html

**Mel Pino**: Good for you.

**Mel Pino**: And then there is the third category of businesses under Doug's protection.

**Mel Pino**: He is such an SOB

**Mel Pino**: This is why we really do need help Jeff. Some of this won't be reversible of we don't stop him.

**Mel Pino**: He had the dock redesigned to benefit those boat captains that are doing business off the taxpayers backs.

**Mel Pino**: "Planted a little bit better" yes he moved the swim area to saw grass.

**Mel Pino**: That son of a bitch is shutting our access down everywhere

**Mel Pino**: Making this project comletely moot.

**Mel Pino**: Going to leave you a voicemail

**Mel Pino**: Listen if you can

**Mel Pino**: Gag.

**Mel Pino**: Is is absolutely shameful that this county has not put mask ordinances on its own property and transportation to protect your staff. 

**Mel Pino**: This sent funny.

**Mel Pino**: I fail to see the humor in you guys refusing to protect your staff. Quite frankly it's disgusting.

**Mel Pino**: Pathetic lack of political courage, Jeff. 

**Mel Pino**: This will be good.

**Mel Pino**: Hhaahahahahaha

**Mel Pino**: The inmates are running the asylum that is for sure

**Mel Pino**: So wait a second. This has been the same power point for times in a row and it STILL isn't on the backup?

**Mel Pino**: Jeff you could lend a hand in pointing out this chaos. 

**Mel Pino**: So far lumon is the only one handling it. He could use your voice in support because this is an embarrassing shit show

**Mel Pino**: Great. You guys just admitted you have no idea what the he'll is in this.

**Jeff Bergosh**: Lumon's got this

**Mel Pino**: Truly I wish you could see how embarrassingly bad all this is from the viewers perspective.

**Jeff Bergosh**: He asked Alison to take a "Deep Dive"

**Mel Pino**: You could help.

**Jeff Bergosh**: Deep Diver

**Mel Pino**: Well you just lost the ability to make Gumby jokes because he is carrying this alone haha

**Mel Pino**: He looks like the only person up there who knows what's going on.

**Mel Pino**: She doesn't even have to be there to box you guys into a corner to vote her crap with no idea what's in it. And it's apparent Jeff.

**Mel Pino**: Jeff did I remember to tell you that Kevin and Mike said you guys could work connectivity in the meantime through the radio system

**Mel Pino**: It would be slow but it would be something

**Mel Pino**: I don't understand it but they know how it works

**Mel Pino**: Thirty percent of all Florida households are at least 500 dollars in debt to utilities and in danger losing electricity and water. 

**Mel Pino**:  Meredith keeps begging administration to be able to pay her staff overtime and they keep saying figure out how to do it flex

**Mel Pino**: Jeff lumon could use some help.

**Mel Pino**: Im serious

**Mel Pino**: Help him

**Mel Pino**: Janice will blow it

**Mel Pino**: Release overtime for staff

**Mel Pino**: That is immediate assistance

**Mel Pino**: They need to be working 60 hours

**Mel Pino**: They are telling Meredith to flex in ways that aren't even legal

**Mel Pino**: She needs overtime NOW

**Mel Pino**: Please help this.

**Mel Pino**: Seriously lumon is doing the right thing he deserves backup

**Mel Pino**: THANK YOU

**Mel Pino**: Call Mer and ask her how much a certain amount of overtime would help

**Mel Pino**: County staff who already know what they are doing and don't have to get trained

**Mel Pino**: If she could just get that gridlock with admin busted on overtime you have no idea how much that will help IMMEDIATELY

**Mel Pino**: She's one of my best friends Jeff. I know.

### CONVERSATION ON 09-04-2020

**Mel Pino**: Please check my comment when you have time.

https://ricksblog.biz/cares-housing-assistance-overwhelmed-closed-after-four-days/

**Mel Pino**: I also emailed some quick takes from Mark Grant's predictions on corporate bankruptcies and pension drops totaling at least 693 billion for the hardest hit states.

**Mel Pino**: So this is really something you need to digest Jeff. Desantis line item veto'd 1 B in coronavirus reserve aid from the last legislation to come through this session. Poof. He has 15 days to consider the bills but he prioritized killing that. In case anybody thinks that the state will step in to help on relief that the Senate won't act on. No ability to get more money now til next session unless the trumplicans call a special meeting during the election for a big spend.

**Mel Pino**: Something that living in a dystopian nightmare has revealed is the limits of existing vocabulary. I don't think there is a word for constantly experiencing the sensation of absolute horror simultaneously with fatalistic unsurprise.

https://thehill.com/homenews/state-watch/515130-florida-health-officials-barred-from-releasing-covid-19-data-about

### CONVERSATION ON 09-06-2020

**Mel Pino**: Posted on olf8

**Mel Pino**: Hope you like it :) Jacqueline and Teresa are going to be beside themselves because I argue for some of the things they want why pointing out their voices don't mean squat in this process.

**Mel Pino**: What they have really lost site of Jeff is that there is room for ALL the things they want per amenities PLUS a clean jobs site and the developers have played them into thinking they need residential to get that. 

**Mel Pino**: Navy fed is going to be PISSED if they don't get any residential. You might consider just a smattering of residential above shops in a town centerish thing to appease them and fuck the subdivisions the developers are flattering over. People will be slitting each other's throats to pay three times the market worst for a limited number of lofts. Just like they do at southtown. That's the way to have your cake and eat it too.

**Mel Pino**: The other thing you could do Jeff is demand that whoever buys the parcels on nine mile face inward with two main entrances, West and East, and nice greenery on the back (east nine mile) side. As I'm sure you've noted they do this a lot of other places and it looks nice, solves the traffic problem of too many turn outs onto a busy street from those businesses, and gives the mixed use junkies the nouveau riche "town" feeling they are after.

**Mel Pino**: That's it. Enjoy the day!

### CONVERSATION ON 09-07-2020

**Mel Pino**: Posted back to the single person coming on with multiple comments from various IP,s. Fyi that story is absolutely true. It was chilling, and actually worse than I represented. The army reservist I spoke with said the ports are in a mess also. I wasn't going to post that, but I can't imagine how it's impacting stevadoring.

**Mel Pino**: When you have time this week you should call David and ask him how trumps tariffs are impacting canned beer.

**Mel Pino**: Finally got appliances ordered so I can off the damn computer and get outside. Responded to Joan the last time (who does indeed have a 1950s Stove). Sent a redo please take the second as I corrected a stupid typo. This country I'd in so much trouble under this fucking imbecile.

### CONVERSATION ON 09-08-2020

**Mel Pino**: Hey tried to just leave you a message on budget hearing but it deleted I think.

**Jeff Bergosh**: In mtg

**Mel Pino**: No worries nothing urgent.

**Jeff Bergosh**: Good I'm buried

**Jeff Bergosh**: I'll call u when I come up for air at 11:30

**Mel Pino**: Hey please post that last response to Joan and then I done with it for this round.

**Mel Pino**: I do bring it back to how ridiculous dpZ was.

**Mel Pino**: Check email and have feelers out

**Mel Pino**: Nobody gives a shit.

**Mel Pino**: Nobody followed through it he backdoor it.

**Mel Pino**: Hahahahahahah

**Mel Pino**: Nothing in either PDF or electronic agenda about anything having to do with Underhill or written communication in the backup.

**Mel Pino**: I emailed the district 1 address for a copy

**Mel Pino**: Thank you!

**Jeff Bergosh**: I fill PR requests FAST

**Jeff Bergosh**: LOL

**Mel Pino**: Hahahahaha omg no wonder

**Mel Pino**: Are you kidding me you guys had an MOU with sarcoma all along??????

**Mel Pino**: You should thank her Jeff she is feeding in your district also, right?

**Mel Pino**: These people deserve voiced gratitude regardless.

**Mel Pino**: Personally I think we could save a lot of money by putting a lot of the saves out of their misery and focus the money on hungry kids.

**Mel Pino**: I have never understood why we can't shoot ducks with broken legs and eat them for dinner. 

**Mel Pino**: We are nowhere near to coming out of this pandemic. 

**Mel Pino**: We are nowhere near to coming out of this pandemic. 

**Mel Pino**: Sorry

**Mel Pino**: You guys shouldn't be spending 75 percent of your time deciphering the budget and 25 deciding on it. It should be the other way around. This is horrible.

**Mel Pino**: There is no sense whatever that you guys have any idea what is going on. Including Robert. I'll bet Janice knows.

**Mel Pino**: If Janice hadn't let Doug Chase off Stephan and then waited months on end while she managed a budget she has zero business or experience managing, you all would not be sitting up there obviously having no idea what's going on with the budget and a bunch else. It's way worse than Jack brown

**Mel Pino**: https://www.dailymail.co.uk/news/article-8711129/Sturgis-Motorcycle-Rally-responsible-260-000-new-cases-coronavirus-costing-12-2-billion.html

**Mel Pino**: Is that moving to the back side of covid? Let me know when people are done letting Tucker Carlson tell them where we are at in this pandemic.

**Mel Pino**: Also fyi, astrozenica just halted their vaccine trials for an adverse reaction.

**Mel Pino**: Wheres waldo?

### CONVERSATION ON 09-09-2020

**Mel Pino**: Is this what being on the other side of a pandemic looks like?

https://www.pnj.com/story/news/2020/09/09/covid-cases-and-exposures-escambia-santa-rosa-schools-more-than-triple-2-weeks/5748160002/

**Mel Pino**: Imagine how bad the story would be if we actually had access to decent data, we hadn't fallen off on testing, and it wasnt supremely difficult to get your child tested for covid when asymptomatic.

**Mel Pino**: How do you suppose they are keeping those hospital numbers down?

**Mel Pino**: Trump is fucking done$ Woodward has him on tape saying he was intentionally misleading the virus and playing down. His own words.

**Jeff Bergosh**: Fake news.  Don't fall for it

**Mel Pino**: Can the trumplican bot please give us Jeff back? We miss the one with eyes in his head.

**Mel Pino**: It is ON AUDIO

**Mel Pino**: The white house isn't even denying it

**Jeff Bergosh**: LOL that's a good one.  "What have you done with Jeff?"

**Mel Pino**: Because they can't. Cause, you know, its Trump saying that he fucked the American people. In his own words.

**Mel Pino**: I'm serious iit just baffles a lot of people that the remainder of you hard core trumpers can manage to try to fool yourself on this. It's just jaw dropping, Jeff.

**Mel Pino**: This is not anonymous sources. 18 named national security and higher up sources. 

**Mel Pino**: We could have a QUARTER of the cases and death count if it weren't for the Trump cult politics. 

**Mel Pino**: Let me underline that one: THREE QUARTERS OF THE PEOPLE WHO DIED didn't have to. He hid the fact that he knew it spread through the air as early as February.

**Mel Pino**: He did this after hours purging his guts to Woodward. 18 interviews. Just spilled his guts entirely. Why? Because the man is batshit, Jeff.

**Mel Pino**: He is responding by announcing his Supreme Court list hahaha. Ted Cruz. You can't write this. 

**Mel Pino**: He just admitted it

**Mel Pino**: Live

### CONVERSATION ON 09-11-2020

**Mel Pino**: Posted. Spent the day yesterday unplugged from computer and phone and news trying to (1) come to grips with the fact that people don't care what is happening, and are willing to let it run on and (2) trying to decide what to do about it. We are discussing moving someplace else in the US before deathsantis kills off waves of people before the end of the year. In the meantime I guess I will continue to post the truth for what little impact it has. I don't ever want to say that I stand quiet while this went down.

**Mel Pino**: I am very depressed to think on 9 11 and how I thought at the time that outside forces was the worst this country would ever have to worry about. I wasn't surprised by 9 11--the form, maybe, but not the attacks. It was inevitable with the direction things had been going. But never in a million years did I dream that I would witness the Republican party transform into an authoritarian cult that is the worst threat to democracy in this country--and the security of the world--imaginable.

**Mel Pino**: We are losing twice as many people every week as we lost on 9 11. And nobody in the Republican party gives a shit.

**Mel Pino**: Not going to post this to keep that topic dragging on but I can't get anything. Dishwasher is back ordered also. This is a supplement I have been using for years for my Lyme disease. That's not a form letter and you can sense the frustration. 

**Mel Pino**: https://www.healthimaging.com/topics/molecular-imaging/covid-19-mo-99-supply-shortages

**Mel Pino**: I take molybdenum to clear acetaldyhyde from my system more efficiently, particularly in my brain. By product of yeasts and highly toxic. There is a shortage due to needing it for nuclear medicine studies. Which is good--problem is our manufacturers are hampered from producing more product in the wake of high sales. There just isn't the ability to produce what we need. Or import it.

**Mel Pino**: So I need to be specific about what is happening hear Jeff, to an audience who can comprehend it. Out shipping is so hampered by trumps tariffs that other countries aren't sending things here. It's in thing that I can't get a supplement I have been taking for years, and will have a negative impact on my health. Ok...the assays are more important. But they aren't GETTING any more of this from overseas Jeff. 

**Mel Pino**: So what happens to the nuclear assays that require it? Just another thing we can't do in this country any more?

**Mel Pino**: Posted. Ecua ruling finally--just after the primaries, natch.

### CONVERSATION ON 09-12-2020

**Jeff Bergosh**: Read it yesterday.  Scathing indictment yet no charges.  Interesting

**Mel Pino**: And there won't be. :( but at least David made his point. Took him YEARS and those board members knew exactly what was up

**Mel Pino**: That SAO is so shameless. They don't even try. Dropping it on a Friday a couple of weeks after the primary. Smh. Vicki has gone poor from most online forums. We'll see if she get refused over at ecw. The Qers are losing what's left of their fool minds and are posting on me across various sites claiming I am various accounts (I'm not). Alex arduini has even started calling people out for being members of PAnon. They are so pathetic. So glad I'm out of that cesspool for now...I wish facebook would just blow to smithereens tomorrow.

**Mel Pino**: I don't know what kind of aliberal snowflake that would shoot any badly wounded bird part from a bald eagle before I dragged it to an animal sanctuary, but so be it hahaha. Especially the edible ones.

**Mel Pino**: Hey there are RUMORS nothing more than rumors that there are more warrants pending at EMS and that a certain chief has failed to keep his dick in his pants once again, this time possibly with a "higher uo" (and that term is laughable these days) at the county. I stress I have no idea whether any of that has grounds. There is a lot of shit stirring and disinformation tactics now that Lindsay Ritter's position has been eliminated. It's even making the rounds that JJ is representing her (he isn't). So don't believe anything you hear right now and those rumors could be nothing more than scare tactics and dirty pool.

**Mel Pino**: Posted on the air evacs. You will get excellent info from Steve just give him so space to tell the story and put a hard stop on the convo at the beginning. Good guy he is just a wealth of info and wants to say it all to somebody who will listen.

**Mel Pino**: The other two to consult are Matt and Joey. Matt worked for life flight (or one of them) and I can't remember if Joey did, but he will give you the straight dope and is De facto running that dept. Thank God did not put his hat in the ring to run it De jure. He ain't dumb.

### CONVERSATION ON 09-13-2020

**Mel Pino**: So I not really sure how I can write an anonymous response I until you showed me here I don't see much of Jeff's Blog. I did get to talk to Rogers the other night and regarding this suggested involve the FAA which could be handled under the safety concern section 
But to answer your question the area is saturated with helicopters and Life Flight lost there CPON in Escambia County. Air Methods is talking about shutting the base down. LF and WFH made deal that they charge ground transport fee if they would use them for transport to basically get there numbers up.  Second problem EMS is so overwhelmed due to staffing they can barely answer emergencies. So when PBER has to wait over 30 they can call LF. And probably less than 5% are critical most are just direct admits to WFH. I look at these transfers all the time on the computer 

**Mel Pino**: Jeff that's from fire, one of the good guys. I'm trying to get him to post anonymously to your blog but that's the person I got my initial information. No, bits not a conspiracy theory I just don't understand it well enough to get into details.

**Mel Pino**: Also, I just posted back at that idiot fuckhead arduini who is connected at the hip with Sean these days, sadly.

**Mel Pino**: Source gave me okay to type out his comment and post.

### CONVERSATION ON 09-14-2020

**Mel Pino**: Hey you driving in?

**Jeff Bergosh**: Already here

**Mel Pino**: Ok and sure it's hectic with hurricane. Just give me a call on ems whenever

**Jeff Bergosh**: I called-- it just rang and rang

**Mel Pino**: People who know way better than me say HIRE YOUR OWN PERSON don't go with anybody not pay to play.

**Mel Pino**: Gonna leave you a message

**Mel Pino**: Great. I make my first hair appt since end of match, against my better judgement. And half the salon has covid. Even worse, our community being completely ignorant of how serious spread is exacerbates the issue. Half the staff positive and yet they think cleaning the place will sanitize it and they don't understand people can be symptoms carriers who might not be evolved enough in their infection to test positive yet. They don't understand these things because their government has been smokescreenig them on it Jeff: ( on a federal, state, and local level.

ey girl..about half of the staff has tested positive for Covid last week.. I am letting you know bc you were worried about it. Hurst has gotten the Salon super cleaned out and everyone has been required to get tested and has to get a negative test before they come back to work. (I am negative and thank goodness I didn't work all week last week!!!) I'm good with whatever you decide..whether to reschedule or come in. Just let me know as soon as possible! 💕

**Mel Pino**: "I'm letting you know because you were worried about it." No recognition at all that the concern Is justifiable. Just continuing to be completely in oblivious denial.

**Mel Pino**: Jeff if you can call for even 5 on the way home. 

### CONVERSATION ON 09-15-2020

**Mel Pino**: Bayou out already. Baublits under there feet of water and a neighbor's lot is under there somewhere. Love the asshole who left the sailboat theroug evacuated and basically did his "good luck everybody don't look for anything out of me" sign off

**Mel Pino**: Three feet

**Jeff Bergosh**: Stay safe!

**Mel Pino**: We are going next door. That house will be fine but this one may take water this round. Are you guys cancelling meeting for Thursday or changing agenda to emergency??

**Mel Pino**: Btw now on top of everything else we can now chalk up the worst hurricane response to janice's admin also. JD must be sick watching it.

**Jeff Bergosh**: Stay safe.  Not sure about meeting- this event will be out of area by Thursday so I'm assuming we will have meeting as planned

**Mel Pino**: Thank you

**Jeff Bergosh**: 👍

**Mel Pino**: (sent to D5) Janice better not stay in her downplaying/denying bullshit as an MO for this storm Steven. The soffiting  is already blowing off our house. Nobody knows yet what this storm is going to do but if we get 90 mph winds that is no joke and it is going to sit and rain for 24 hours here. To the best of my knowledge there is NO mandatory evac happening yet. Even on the beach and the key and that might not be necessary but man if you guys don't lend VERY strong warnings at least there will be he'll to pay. That woman has zero crisis management skills other than soft shoeing and people are commenting to me that Eric Gilmore looked weak and scared which was my impression also.

**Mel Pino**: This is to you again. She talked about cancelling stuff tomorrow but nothing about Thursday. Aren't you guys on a ticking clock without having to go through a bunch of Bs in Tally on that meeting Thursday morning? Staff doesn't need to get dragged through that agenda. You guys should zoom it and just deal with hurricane and cares act and call it a day.

**Mel Pino**: (One of the new models has storm jogging east through Pensacola Bay)

https://photos.app.goo.gl/TDSYhc5h2MDvidGR7

**Mel Pino**: Blow up to see the car that just got carried in the water on baublits.  First one this storm but it won't be the last. 

**Jeff Bergosh**: Wow!!  That water is rising fast!!

**Mel Pino**: Yeah the white caps have hit now. This is pretty normal for here fyi. It wouldn't be alarming if we weren't in the path for a potential 30 inches

**Jeff Bergosh**: Yeah this is going to be trouble

**Mel Pino**: I'm afraid so Jeff. I am not worried for us but I am worried for all the people who aren't getting the message this thing turned and they should be getting to shelter...old people and poor people. 

**Mel Pino**: (from Lois) They have now pulled all of the ecua employees out of the area. Let me know our you see any. I appreciate your alerts.

**Mel Pino**: Jeff check voicemail. This woman is SUCH a horrible administrator. She has no sense of context whatever. No ability to crisis manage. Obdurate and everything political. No priorities that value safety and human health. Good that fire is getting cracked down on with OT. This is NOT the time for playing games on that note with human life. For lords sake it's only a few days. Release the OT during a storm and then slam it back down. It's not hard but these concepts completely escape her. If they start rabble routing about how bad this decision is (and it is horrible), it will come down on you guys and not her. It's never on her and she depends on it.

**Mel Pino**: "Please take the flooding more seriously than Escambia county administration takes anything."

**Mel Pino**: "Please get out while there is still time for us to continue to softpeddle the storm."

**Mel Pino**: Thank God Grover is there to speak common sense and offset janice's negligence.

**Mel Pino**: Jeff PLEASE call Randy wood and tell him to pull people. Tell him you are watching and you are worried about them being out. Chorus especially on the beach...Aaron Bridge just closed

**Mel Pino**: From a good firefighter

So don't know if you are aware but no one has made any preps about getting people to work or recalling or anything. This place is a joke. 

**Mel Pino**: Can you find out what the he'll this woman is fucking up now?

**Mel Pino**: FY- lumon went to EOC and demanded meeting get postponed. 

**Mel Pino**: Follow up text:

Apparently all to avoid overtime. And absolutely no communication 

**Mel Pino**: Text 3 

Yep I don't know where Rogers is. And of course Williams is under a rock somewhere 

**Mel Pino**: Text 4

They just dispatched for a commercial structure fire on Pensacola Beach and they evacuated the fire station this morning 

**Mel Pino**: Hi Randy, Mel Pino here. Randy what on earth is going on with WEAR people still out in the field. I am watching this and damn those people are in so much danger...what are you guys thinking? You guys aren't the weather channel. There are trees coming down everywhere...my neighbor just had a big old try come down in her front yard. We have sideways wind on navy point and it's ripping the offing off the house. Please don't take the county's lead and be callous with your workers. They are good people and should be out in this :(

**Mel Pino**: I'm so sick of the callow disregard for human life Jeff. The culture that is being fostered in this county is just horrible right now

**Mel Pino**: Enough is enough. I sent this text to Janice Gilley. There are MANY citizens who are up in arms about her failures. I am not the only citizen who has had it. This is an absolute disgrace and she is turning this county into a laughing stock at the same time she is resulting in our citizens being at hazard because she has no idea what she is doing and even if she did she doesn't care about anything but her own longevity. She need to GO.

Janice., it has been bad enough watching your ineptitude and self interest destroy this county on a general level. Then came covid and we had to watch you do your worst running your "fake news" crisis management platform resulting in such spread of this pandemic that didnt need to happen. Now you get to chalk up the worst hurricane response this county has ever had. I am fucking sick to death of watching your mismanagement, lies, special interest, and ineptitude put citizens of this county at risk. Your administration is an absolute hazard to the welfare of people you could apparently care less about. Squat up in Molino with your north county faction. I'm not the only person who is fucking done with your homicidal negligence and ready to start speaking on it and dismantling your charade. -m done worrying about covid. I may catch it in the dens you have created. OK, wish it weent the case. But if I can save a lot of lives by exposing you for the fraud you are then risking my own iis worth it. Please do forward this and cry to whoever. I guarantee you my network is bigger and I will be forwarding this text to everyone.

### CONVERSATION ON 09-16-2020

**Mel Pino**: Please understand the following is not a personal complaint. We knew this house would Flood when we bought it and we can go next door to higher ground. I am sending this to let you know how fast this is escalating. In the last half hour the water has jumped from the road to our stoop and it is climbing fast. We are 6 hours away from high tide. One friend has water streaming through kitchen roof: another has water pouring onto bed.

**Mel Pino**: There is probably little the county can do at this point but for God's sake Steven maybe you could wake from your stupor and get control from Janice. Because between covid and this storm she is literally a menace  to public health and safety

**Mel Pino**: Fyi the wind just ripped our back porch glass door off its hinges and threw it across the yard. Again we will be fine, because we knew better than to trust janice's bullshit.

**Mel Pino**: County: this is not a personal call for help. We will be fine. Our houses are iron clad and survived Ivan. I am conveying this to try to knock this administration out of its complacency. There are white caps in our drive. The trees are at the point of snapping. I have people all over the county texting me in alarm that their roofs are pouring water. Again, I am not worried about us. I am worried about the people that got caught unawares because janice's administration once gain failed to keep people safe. Old people, poor people, homeless people...And also just anybody who didn't know because of her soft peddling. THIS. IS. BAD. Mike was in Miami for Andrew. We went through Sandy in New Jersey. We aren't alarmists. Kevin has been on navy point for over twenty years and was here for Ivan. Somebody in leadership needs to remove her from being in charge.

**Mel Pino**: Great job Janice! Question. Between your fak news handling of covid and your wish it away management of the hurricane, do you have a number in your mind of how many Escambia citizens you endanger before you consider it a job well done? Why the he'll don't you just resign now because you are NOT cut out for this. And people's patience with your ineptitude  is spilling over. Can't wait to see how you try to blame this one on the board. Where's your BFF Doug?

**Mel Pino**: Janice, if we weren't hip to your games and bought the shit you shovel, if we were eldery, homeless, or just clueless, where would your "management" have us right now?

**Mel Pino**: From fire 

This place is all jacked up. No resources other than a couple national guard trucks. No task force's etc. half of communications is down and on and on town is flooded 

### CONVERSATION ON 09-20-2020

**Mel Pino**: Here's your minimal flooding at forest creek, Janice. It couldn't be any more obvious that you are still doing Doug's bidding even with people's health and lives at stake. NO stand up station between  Innerarity Point and Brownsville; Doug on Facebook barking for people to go to Brownsville. What has administration done to plug his gap? Nothing. Thank God for Grover and Lumon stepping in to fill the void, but Lumon  has the needs of his district to take care of....which he is doing beautifully. apparently by working around you. If you think people on the west side are fooled by your "better response than Ivan" PR line, you are badly mistaken. How quickly Gulf Power gets the power up has NOTHING to do with how badly your team bungled almost every aspect of this disaster possible, from downplaying the risk, not issuing mandatory evacs, messing up the FEMA paperwork, setting a general negligent tone of "pish posh ake news" in our area, boxing out the city's efforts, not getting the POPs up and adequate fast enough, and, of course, the lies you have told during your ridiculous pressers. The poor neighborhoods on the west side need your attention yesterday. Quit thinking you are fooling people. You aren't. Get a station stood up in Wal-Mart parking lot for the people in forest hills and Lexington terrace. My husband went through Andrew in Miami and we dealt with Sandy and its aftermath. We are no strangers to hurricane response and the county's ineptitude and inexperience is on full display.

https://weartv.com/news/local/pensacola-woman-escapes-flooding-by-swimming-with-grandson-on-her-back

**Mel Pino**: From a friend in the key. In case you think it's just me. I'm not even saying the worst of how people are talking about her negligence. 

I have very poor phone service but folks out here on the key say Janis should be put in jail, one to get her the hell out of the way and two because she deserves it 

**Mel Pino**: Please see my email on forest creek in the context of your interference ordinance when u have a chance.

### CONVERSATION ON 09-21-2020

**Mel Pino**: Who was briefing Rubio on covid? Trump?

https://www.wsj.com/articles/coronavirus-latest-news-09-21-2020-11600676779?mod=mhp

**Mel Pino**: https://www.wsj.com/articles/coronavirus-can-spread-by-tiny-air-particles-cdc-now-says-11600700364

### CONVERSATION ON 09-22-2020

**Mel Pino**: Underhill really needs that FEMA money

**Mel Pino**: Grover, I know you are doing everything in your power. This county is in dire straits and if people don't start getting vocal about the need for a change in administration what's happening at the county could take down the city with it. EVERYBODY I talk with knows she is an absolute disaster. And yet she is allowed to continue to drag this county down the tubes. Our bond ratings will suffer enough with the coming economic calamity. We dint need Janice helping that out further.

**Mel Pino**: Is there public forum on something other than the budget hearing? Or can we just talk on the regular meeting?

**Jeff Bergosh**: Just during the budget meeting

**Mel Pino**: Dammit so I can't speak to that garbage Doug was shoving??

**Mel Pino**: This is why I am so damn angry. We just stopped for gas near forest creek and there were two women in line talking about how they thought they were going to die in the flood and showing pictures and the guy in line says "they dont care unless you stay in Orange beach or perdido"

**Mel Pino**: From trusted source in fire

So we hear today anyone who failed to make it to work Wednesday the day of storm or was late Debra the assistant county administrator wants disciplinary action against them 

**Mel Pino**: Is he shilling for FAC now?

**Mel Pino**: This is exactly what I was reacted to.

**Mel Pino**: Jesus thank you

**Mel Pino**: Hahahaha

### CONVERSATION ON 09-23-2020

**Jeff Bergosh**: In mtgs

**Mel Pino**: No worries left you a message and nothing urgent.

**Jeff Bergosh**: 👍

**Mel Pino**: Gee. Wonder where Robert got the idea to put out what turned out to be a shared strategy with Doug. Is all this noise a distraction from something?

**Mel Pino**: Left you a message that paperwork is not on trumps desk.

**Mel Pino**: The upshot about the debris removal getting pushed forward too quickly for the optics is that it doesn't give time for proper documentation so we will end up losing money if it goes too fast.

### CONVERSATION ON 09-24-2020

**Mel Pino**: Jeff did you see that piece WEAR ran last night they worked it like they had interviewed you but it remarks they took from the meeting :( then they put up three big check boxes on you Robert and Doug saying the county was a okay and red checks by lumon and Steven saying they did not. They worked it like you all talked to the press except lumon did not respond and Doug was the only one who is on camera. Just wanted to make sure you saw it

**Mel Pino**: Also, ten to one if DeSantis was working that he was doing it for trumps reelection and I will be VERY surprised if he lays some kind of fraud ban hammer down on panhandle counties before November. It will be heartening if it happens though

**Mel Pino**: What in the fucking hell?

**Jeff Bergosh**: 👍

**Mel Pino**: Ok just please this isn't an I told you so...Trying to figure out what just happened. So the paperwork is NOT signed on individual?

**Mel Pino**: I'm not arguing about speed Jeff I'm arguing about bad communication to the public

**Mel Pino**: Is this where we are at right now? No individual yet?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: ....but it is coming

**Mel Pino**: Yes I know. That's not my argument

**Mel Pino**: I know you think I'm a nutjob sometimes but I swear I'm not :)

**Mel Pino**: In other words my rabble rousing is working.

**Mel Pino**: He's so damn lost.

**Mel Pino**: Damn the ITL is falling apart without you here :(

**Mel Pino**: Holy shit it's going down at eoc. Steven took it over from janice

**Mel Pino**:  She had to admit It about the individual and Broxson just said that "somehow" there was the narrative that this wasn't a serious storm. And people think I'm a brute because I said that very damn thing at the public forum today...that it is the look and feel tone of "it's all good" that is doing incredible damage to this county's functionality.

**Mel Pino**: They're gonna hold this shit back so Trump can ride in savior.

**Jeff Bergosh**: LOL 

**Mel Pino**: Jeff seriously you should swing by for a photo Op on the distribution center David and I got set up at navy Blvd Wal-Mart tomorrow

**Mel Pino**: Michelle Salzman chip and Ronnie will be there chip is getting a couple of cadets

**Mel Pino**: David has two thousand cases of water I donated five hundred for whatever Michelle's team needed water food hygiene

**Mel Pino**: 930 set up 1030 start pop by 

### CONVERSATION ON 09-25-2020

**Mel Pino**: https://www.pnj.com/

**Mel Pino**: Obviously you have seen it but hear this, Jeff. This is what the most pathetic bootlicking and Rod kissing looks like when a civilization is losing its democracy to autocracy. It's pathetic. And yet Trump supporters just keep licking the back of the hand whacking them. And of course you guys had to do this to get this. I'm not arguing against the letter. I'm telling you that everybody on that letter looks like a fucking putz and that's exactly what your president and his deathsantis minion want.

**Mel Pino**: Jeff, you keep telling me I don't understand what is happening and yet I keep calling, and calling, and calling it. And just as fast as I try to get in front of the fuckers they play their disinformation shit and cover it up and swing the narrative. I haven't been wrong about a damn thing but it never matters. They just find a new way to spin the tops and reposition their boots so more people can lick them harder. At what point in recent history has this kind of appeal been necessary. Every Republican on that letter should be embarrassed that you have supported this thing devolving to this point. It's a complete shit show and you guys look like neutered weaklings. Again, what they want. And yet Trump and desantis supporters will just keep kneeling and begging and being proud to do it. 

**Mel Pino**: SERT did an emergency de mobilization today without going by the guidebook of 12 hours rest before they do. Guess they are clearing out so Trump can get his bootlicking ceremony? 

**Mel Pino**: (to Janice) Well aware of the shit you and your handlers are putting out on why we don't have individual yet and I will be back to the next meeting to keep exposing your games. 

### CONVERSATION ON 09-26-2020

**Jeff Bergosh**: I disagree Mel

**Mel Pino**: I'm sorry Jeff I was so livid yesterday after seeing allow those people in hopeless need and here we are begging the asshole who is help putting them there for help. There is also a lot of maneuvering behind the scenes as you are more than aware. I don't like to bug you with phone calls on the weekend but if you had time I would love to talk. Not angry but just try to have an understanding on some of what is going on.

**Mel Pino**: I do recognize the letter had to go out and we have to do whatever we can to get that money but it just makes me sick to watch all this get set up and go down.

**Mel Pino**: This is why I am just beside myself Jeff. We can't get shit out of him for attention to these poor neighborhoods in district 2 and Janice is playing his cover-up game for him. There is every bit the poverty in our district that lumon has but Doug keeps a lid on it and people are just desperate right now. We handed out a lot of water to Mayfair people yesterday and the stories are awful

**Mel Pino**: When she is helping him to cover up what really happened in his district everywhere but perdido that is really hurting getting the truth of this storm across.

**Mel Pino**: And Andrade is playing the same game

**Mel Pino**:  I put in multiple voice mails begging him for help for these neighborhoods and it's the first time Alex hasn't returned my calls. He has let everybody know that there is no issue for the people in these neighborhoods and he is not going to do anything about it. Michelle and her team helped us distribute the water in his district yesterday

**Mel Pino**: You saw his shit show at the eoc presser.

### CONVERSATION ON 09-27-2020

**Mel Pino**: https://www.newsbreak.com/news/2048655227475/trump-looted-44-billion-from-femas-disaster-relief-fund-in-the-middle-of-a-record-setting-hurricane-season

**Mel Pino**: This is why it is so disgusting that our local leaders should have to beg for aid. Also it is all over the state how horrible the county's response was and that we were two days late on everything because Janice failed to put in for emergency in time. I would imagine Trump is going to white knight this but after he looted this money FEMA is more broke than ever.

**Mel Pino**: I posted thanking you for getting the sites public and asking if the county won't be arranging for assistance this time. Isn't that the point of the public disaster money? If Janice isn't going to spend that money getting people get the shit out of their yards then she needs to fess up and set realistic expectations. There will be a huge outcry either way so better to just be honest about if it she is actually capable of that

**Jeff Bergosh**: I'm looking into this

**Mel Pino**: Thank you Jeff. They are blowing it up on social media that the city and county will be taken care of with the disaster but not the residents. I can't believe though that the public assistance portion does not earmark for wholesale removal. Gilley will try to spin it that way. Fyi other commissioners are going straight to the FEMA secretary for answers because you can't get the straight dope from Gilley. Dint believe a word she says and people in Tally are talking about her lack of composure at the meeting the other day.

**Mel Pino**: Thank you so much...posted that on a new blog. Jesus it is like pulling teeth to get the information.

**Mel Pino**: Oh wait that was just for HOAs? Sorry. I am going to resubmit on The other post

**Mel Pino**: Ok reposted. So it looks like you asked her about whether the county was going to help clear yard waste and she gave you information on private roads and debris hauls from ROW etc. But I might be missing something in that report that pertains to individual residences that have gotten clear. 

### CONVERSATION ON 09-28-2020

**Mel Pino**: She really needs to just stop talking.

https://www.pnj.com/story/news/2020/09/28/oil-washes-up-along-johnson-beach-perdido-key-after-hurricane-sally/3556010001/

**Mel Pino**: Left an important voicemail

**Jeff Bergosh**: Okay I'll check it out when I come up for air.  Crazy day

**Mel Pino**: She could use a kind voice to put her at ease so she can actually be calm enough to get out what's happening. 

**Mel Pino**: Figure you have her cell just in case

**Mel Pino**: https://www.pnj.com/story/news/2020/09/28/mayfair-residents-struggle-after-hurricane-sally-hit-neighborhood/3555621001/

**Mel Pino**: Thos is why I was crying after the water distribution these people in Mayfair heard and started driving over for the free water and were begging for food and help clearing. Doug's district.

**Mel Pino**: No doubt administration will be right on top of reining this in.

**Mel Pino**: Left a message on individual fema

**Mel Pino**: Jeff Please make that call if you can it has been a bad day for staff

**Mel Pino**: Jeff PLEASE read the email I just sent out on ems all of it.. It gives you the entire roadmap. They are already trying to scapegoat and fire an innocent person

**Mel Pino**: Jacqueline has swung away from bocc

**Mel Pino**:  not because of my emails but because people are telling her now about the horrors of this administration

**Mel Pino**: Did you call Meredith??

**Mel Pino**: Nobody called :

**Mel Pino**: New fire truck just had an electrical fire in the bay

### CONVERSATION ON 09-29-2020

**Mel Pino**: I just sent a (briefer) ems follow up email on the potential current fix of a busted affair resulting in a promotion to office work.

### CONVERSATION ON 09-30-2020

**Mel Pino**: R u already in meetings? I just realized last night there's a meeting tomorrow. Havent even read the agenda

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Now worries was just sitting down to read agebda

**Mel Pino**: https://ricksblog.biz/gulf-power-wants-to-disconnect-customers/

**Mel Pino**: Check my comment. Janice has this lined up to throw staff under the bus, get integrity group back in there, and throw egg on the boards face. I'm sure her handlers over in the city already have the PNJ article lined up just waiting. Wouldn't surprise me if we get a Jim little hit piece before the meeting tomorrow morning.

**Mel Pino**: Doug really needs that individual so he can declare his first floor uninhabitable blowouts a total loss. But the bigger question is who is "my team" . 

**Mel Pino**: 737 200 just flew in to the base. Don't see that very often.

**Mel Pino**: https://www.pnj.com/story/news/2020/09/30/escambia-county-hotels-face-covid-19-hurricane-sally-and-now-bed-tax-increase/5871146002/

**Mel Pino**: Theres a big surprise$

**Mel Pino**: And now we know why they switched patels.

**Mel Pino**: https://photos.app.goo.gl/StSufjVbyeAk3Cvw7

**Mel Pino**: We came in on two wheels from another meeting and Kevin was scrambling to get video going. Pc had just made a very eloquent bull shit stand on how he wasn't going to tax citizens. When he interrupted me he said "I know who you are going to say."

**Mel Pino**: Pc had said he "didn't know a single elected official who would support this" and that is what I was responding to.

### CONVERSATION ON 10-01-2020

**Mel Pino**: Good morning. Rusty  this isn't a question to pressure you for into so I don't expect an answer. I just wanted to express my hope that the hoteliers are not going to pack that room with employees in the middle of a pandemic. Not just a bad look but actually dangerous to people's health :(

**Mel Pino**: (Rusty) Will you speak against the 5th cent on behalf of the staff who will lose their jobs if this item is passed? The pandemic and bridge being out is already had an immense toll and this will be the third nail in the coffin. So much more at stake here and so few see it. 

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Glad to leave a message running late

**Mel Pino**: Hey call dropped but I gotta rock and roll see u soon

**Mel Pino**: Damn dealing with tree guys can't leave til they are done

**Mel Pino**: Ill bet and dropping d2 for 2022 while they are at it

**Jeff Bergosh**: His campaign team!?!

**Jeff Bergosh**: Jonathan and Conor.....also county employees.  I think he slipped calling them his "campaign team"

**Mel Pino**: Yep

**Mel Pino**: Remember I texted that post he made and asked what team

**Jeff Bergosh**: Now u know

**Mel Pino**: We are watching on TV I gotta guard my trees the out of town guys dont understand live Oaks keep fighting them off dead stuff that isnt dead

**Mel Pino**: Hahahhahaa

**Mel Pino**: NICE

**Mel Pino**: So good to see you on fire. I have missed that :)

**Jeff Bergosh**: 👍

**Mel Pino**: I had lengthy discussions about that yesterday and got the trucks out here to the point today which is why we aren't there. Big staging at the boat ramp I have to guard my trees. This is what it takes to get response right now. You have to know the right people to contact and how things run to provide the proper info and get help

**Mel Pino**: And I don't mean I used influence. I simply called the people who need the info that they are NOT getting except piecemeal. They are trying to puzzle piece together with no effective central command or communication

**Mel Pino**: Tim has very strict guidelines on those drop sites. It's crazy

**Mel Pino**: Its environmental and safety

**Mel Pino**: Kevin took photos and made maps and sent in some of the worst sites where they still don't have power because trees down

**Mel Pino**: Mayfair is devastated and no help

**Mel Pino**: Direct people to your blog

**Mel Pino**: For the drop off sites

**Mel Pino**: Blog blog blog

**Mel Pino**: "Vegetative debris drop off sites identified for residents" is the title

**Mel Pino**: And ask Janice where the info is on the county site

**Mel Pino**: Fucking asshole

**Mel Pino**: Jeff is any of Mayfair in your district? 

**Jeff Bergosh**: No

**Mel Pino**: Thank God for small favors

**Mel Pino**: Is the list public?????

**Jeff Bergosh**: Yes I'll send it to you

**Mel Pino**: Thank you you see what he is up to. I will make a PRR via email

**Mel Pino**: No no not a cow

**Mel Pino**: Wtf.

https://ricksblog.biz/buzz-fema-bullied-county-staff-to-downplay-damage/

**Mel Pino**: Okay going to forward those texts and also I emailed about the parks list

**Mel Pino**: (my response on speaking against the fifth cent) No but not because of politicking. I don't believe for a hot second that the fifth cent will impact tourism. It's nothing but a political thing in my eyes. Just my opinion.

**Mel Pino**: I know it's easy to talk about helping people and lot of folks do that in our community. Hospitality employee 20k plus of our citizens who are the most employment vulnerable. ¿¿And it will absolutely have an effect. We are the most taxed beach on the gulf coast, GB is actively building hotels to take market share, rate v occupancy has been a major issue since 2016 and we are in the middle of the pandemic and bridge being out of service. And Ms. Gilley is actively taking money from the unified budget to pay for pet projects on Pensacola Beach. 

**Mel Pino**: I serve on mental health boards, employment boards, spent 15 years working with the employment vulnerable in this community and folks are clueless of what continually chipping away at hospitality industry is going to do to our most vulnerable citizens and honestly people with means don't really care. 

**Mel Pino**: Am I the last one to realize that "phase 3" meant they were taking away state testing?

https://weartv.com/news/local/state-covid-19-testing-sites-in-escambia-county-to-permanently-cease-operations

**Mel Pino**: (still going) By the way, I did tell hoteliers not to bring staff tonight. There will be some owners and a few senior management folks. Keeping it low because the few workers we have left are putting forward a Herculean effort daily at work and home.  ¿¿Also, since you support the 5th cent if it turns out great I will applauded you and others publicly...but if it costs jobs, revenue losses, tax losses and it generally harms our community will you do likewise? Hospitality isn't Navy Fed or ST Aerospace with millions in tax breaks & incentives, it carries the load for this county's tax base and is a stop gap for so many not being totally dependent on the system.  

**Mel Pino**: Jobs are going down Rusty. Economy is going down. People are going to be laid off. I'm so sorry it's true. You guys can try to set it up as the fifth cent doing it, but it will be obvious enough with what is headed this way. It's just the heartbreaking truth and there ar no good answers. You guys would be worse off politically if you won this because you would still have to slice and dice through no fault of your ow. We all lose. 

**Mel Pino**: I don't agree at all. 

**Mel Pino**: Of course you don't. I didn't expect you would.

**Mel Pino**: And you are incorrect. We operate in a dozen other beach communities and see how they prepare and take care of an industry they can actually have an influence over. 

**Mel Pino**: So they won't come here and won't come again because it's 15 percent rather than 14 percent. Give me a break

**Mel Pino**: Lumon is making a damn good case we need money hahaha

**Mel Pino**: I really hope that after Doug does his worst you come in and close this Jeff. Just like you fought him down this morning

**Mel Pino**: You understand lumon is putting it out there that Janice and Alison and Pam laid down a bunch of hazy crap they couldn't answer questions on per the budget. It was a shit show.

**Mel Pino**: Basically the best I understand it is staff is placeholder cash on hand pretending it is going to go to reserves. Good luck. Janice has control of it

**Mel Pino**: Did the cares get moved up and I missed it?

**Mel Pino**: Good Lord if I had to put my hands on that stuff and Mike got run over by a bus I would be screwed to come up all of it on a dime. I need to get my shit together.

**Mel Pino**: It was such a mess at Brownsville that day with the people filling out their paperwork outside they were just at a loss.


**Mel Pino**: Not because staff wasn't helping they took it outside and were asking us what this and that was. David helped some of them

### CONVERSATION ON 10-02-2020

**Mel Pino**: Thank God we got the individual!

**Mel Pino**: Meanwhile Doug is posting support for proud boys on his commissioner page.

**Mel Pino**: This shit needs to go viral

**Mel Pino**: People are posting screen shots of not being able to process an application and a couple said FEMA says it will be available tomorrow. I have a comment pending on Rick's...can that get confirmed to allay people's anxiety?

**Jeff Bergosh**: I'm not sure what the true scoop is

**Mel Pino**: I posted on Rick's and asked him to get to the bottom the scuttlebutt. I also texted Steven and said the county needs to confirm because this is just throwing people into a whole new wave of anxiety. I'm back on the phone to insurance again and have been on hold for a half hour already. Gaetz can fuck himself.

**Mel Pino**: And look how they snafu'd rapid testing. Deathsantis always manages to do the worst possible thing at the worst possible moment. He is a smart man but the most idiotic politician in the game.


https://ricksblog.biz/rapid-tests-only-for-those-showing-symptoms/

**Mel Pino**: I am only picking this up hearsay from online posters who seem to be reasonable. Can't vouch though. Another snafu seems to be that we didn't have "operation blue roof" implemented? That it's separate from the individual assistance and FEMA has to delegate the authority to army corps?

### CONVERSATION ON 10-03-2020

**Mel Pino**: Jeff this is sent in the spirit of caring and not crowing. You guys have GOT to get serious about covid in your buildings. Kevin and I have been shocked to see that the negligence is actually way worse than you can see on camera. There is literally nothing that is keeping the same thing from happening in our government. All it takes is one night infected person who may even be completely asymptomatic. Just one person in that room could wipe out our county decision makers. The pressure on staff not to mask, and the culture of this thing not being serious and being over, is a complete abnegation of responsibility. I don't give a shit what deathsantis is doing. You guys are better than that prick homicidal idiot.

**Mel Pino**: This article describes the MERV-13 to 16 filters and UV radiation needed to make buildings safe in airborne aerosol trasmissibile disease

https://www.sciencedirect.com/science/article/abs/pii/S0360132313002515

A brief mathematical tour behind mathematical modeling that assures using the Wells-Riley equation on separation droplet vs aerosol transmission

https://en.m.wikipedia.org/wiki/Mathematical_modelling_of_infectious_disease

### CONVERSATION ON 10-05-2020

**Mel Pino**: Are you on your way in? I want to talk to your about the park tech thing. Not read you the riot act on covid. :)

**Jeff Bergosh**: In mtg will call you Lett

**Jeff Bergosh**: Later

**Mel Pino**: Sorry didn't see this. When u get a chance will you ask Debbie to shoot me the doc of all the tech locations? That asshole is going to try to fuck us in D2. And if Navy point park is n that is it does not need to be. There is no building in that park ever by covenant and will never be meeting space there which I have hired Clark partington to make damn sure of. If it's on there that is a galloping 45 acres you guys don't have to pay for.

**Mel Pino**: If it's not on list then I can worry less although he may try to slide it on for future development or so he thinks.

**Mel Pino**: Christ here we go again with another possible hurricane. Maybe the Cow will get pushed out.

**Mel Pino**: According to current model winds set to hit here 8 pm on Thursday. They have us on NE with only a 30 to 40 mph band but the damn thing is tacking east again.

**Mel Pino**: Sorry Jeff should have made clear that's landfall of first winds not landfall of Hurricane. 

**Mel Pino**: Underhill much?

https://www.scientificamerican.com/article/how-trump-could-have-exposed-biden-and-others-to-covid-at-the-debate/

**Mel Pino**: Hey Jeff I know you must be worn out from hurricane prep at the base. There is something very important I need to talk with you about just as soon as you can.

### CONVERSATION ON 10-06-2020

**Mel Pino**: Are you fucking kidding me. This woman literally cannot even handle hiring contractors to pick up sticks. And yet she is somehow deemed capable of running this county. What staff will she throw under the bus on this and what Contractors made off like a bandit?

**Jeff Bergosh**: I'll call u in 5

**Mel Pino**: K

**Mel Pino**: The following texts I sent to Steven.

**Mel Pino**: Are you fucking kidding me.

**Mel Pino**: This woman literally cannot even handle hiring contractors to pick up sticks. And yet she is somehow deemed capable of running this county. What staff will she throw under the bus on this and what Contractors made off like a bandit?

**Mel Pino**: They have not even made ONE pass on the main drag in navy point and it's like that all over the West side. I can get my own mess to the dump unlike a lot of poor souls but I can't even legally remove this debris from the park that Janice let Doug whip into a lather and did NOT need to be cleared out of the park two days after the storm. All they had to do was clear the paths. But Doug commandeered staff to make it look like his bullshit Oyster project worked.

**Mel Pino**: All of that will be flying at my houses. And I can't touch it.

**Mel Pino**: And that. And it is NOT staff's fault this woman is a train wreck whose only talent is CYAing through contractors who laugh all the way to the bank. Where the fuck are they? Kevin was all over town up to nine mile road a tractor supply grabbing up more tarps and did not see ONE debris truck. This whole fucking thing looks like a scam.

**Mel Pino**: Thats it.

**Mel Pino**: https://ricksblog.biz/gilley-tells-innerarity-and-forest-creek-to-pray/

**Mel Pino**: Maybe we can contract some monasteries down in Mexico to run the beads for us. My mom could probably get Gilley the hookup. 

**Mel Pino**: https://www.pnj.com/story/news/2020/10/06/pensacola-declares-state-emergency-hurricane-delta/5903494002/

### CONVERSATION ON 10-07-2020

**Mel Pino**: Can you talk? Kind of important about fema

**Mel Pino**: Hey call back when you can in addition to letting you know about the park legal I just got of the phone with Fire.

**Mel Pino**: Just talked with my insurance Adjustor and they are evacuating people asap.

**Mel Pino**: Hopefully that will look like an abundance of caution on the other side

**Mel Pino**: Hey with the update on my Facebook account to new style it fixed the bug that kept me from commenting on live video!! Looks like I will be setting the alarm from here on out. It never mattered before because I couldn't comment anyway

**Mel Pino**: Never mattered when I watched it that is.

**Mel Pino**: Yu guys aren't even socially distancing and making in county buildings. So how can you tout "as long as we keep doing a good job" when its not even happening Jeff.

**Mel Pino**: Masking

**Mel Pino**: It's appalling how staff is running around getting up in each other's faces and standing right on top of each other with no masks. Spitting into the wind, my friend. Ask the Pentagon.

**Mel Pino**: Left you a follow up voicemail on the park issue.

**Mel Pino**: Reporting on your page. Going to get it out.

**Mel Pino**: Harris is going to annihilate that robot pence.

**Mel Pino**: She is going to slaughter him and this will be the last nail in the coffin for the Republican party.

### CONVERSATION ON 10-08-2020

**Mel Pino**: https://www.military.com/daily-news/2020/10/02/top-generals-attended-white-house-event-days-trump-tested-positive-covid-19.html

**Mel Pino**: This is why the covid downplaying program is going to crucify the Republican party in the coming elections. It didn't work for Trump and it won't work for the bocc if a super spreader occurs. Nonetheless I am very grateful for your coffees because it's the only time Gilley is forced to answer questions. I am going to pull it onto my page and tell people they have got to start tuning in

**Mel Pino**: Hey  please call if you have five before the meeting.I need to talk to you about the panhandling.

**Mel Pino**: Studer people were in and out the door and did nothing but disrupt the work flow. Which was of course janice's intent, although it may have backfired on her.

**Mel Pino**: The epitome of asinine to tie up staff training a bunch of kids who were then gone when they could have been working. Janice can't get enough of that crap.

**Mel Pino**: Jeff that letter should be coming in from will on navy point park. I wasn't pulling a fast one on timing they needed to complete the Sig. It's a 2 page letter laying out the legal argument for the county to stop messing in that park and 17 pages of exhibits indicating why the county isn't supposed to be adding infrastructure in there.

**Mel Pino**: We really did try to soft touch but Doug is not going to be happy.

**Mel Pino**: NICE

**Mel Pino**: Good thing we didn't waste all that money on consultants to process them huh?

**Mel Pino**: God this is such a relief. See how things get worked out when staff communicates the truth to you guys directly? Instead of Janice running games up and down and working her crap. Note that Steven never went back to her for comment

**Mel Pino**: Ok that email went out I think. The two page letter is the meat of the legal argument for county to stop messing in the park. The other is the exhibits.

**Mel Pino**: Please note that he doesn't even know what he is talking about. I miss the old Robert a lot.

**Mel Pino**: He gets fed this garbage and doesn't understand he is being played.

**Mel Pino**: This is nothing more than a Doug witch hunt and Alison ran his game. Eager Beaver is now providing huge amounts of mulch to home depot. It's ridiculous.

**Mel Pino**: And the coward didn't even show hahahahaha

**Mel Pino**: More Doug legal costs for the taxpayers.

**Mel Pino**: Wtf was that all about. Janice overseeing concrete crushing.

**Mel Pino**: WHY ARENT THESE SLIDES IN THE PUBLIC BACKUP

**Mel Pino**: Just asked for it via email

**Mel Pino**: Robert trying to get it in for Grover.

**Mel Pino**: Just FYI , don't know if your watching the meeting but they are discussing the panhandle thing . The guy Jeff Bergosh is referencing is harmless . He has some mental issues maybe some adult street medicine ???  and does at first look appear to be a threat but he is a super nice guy . Me and my son have talked to him before and he played a song in his guitar with my son . Can't judge a book by staring at it.

**Mel Pino**: Just got that from a medic in the city.

**Mel Pino**: Jeff Please don't let the discussion go by without mentioning the legal letter. Doug isn't even there.

**Mel Pino**: Oh thank goodness I didn't know will was coming

**Mel Pino**: Jeff I absolutely agree on the boat ramp.

**Mel Pino**: It's the rest of the waterfront I am trying to protect.

**Mel Pino**: Kevin said you guys should be asking whether these will interfere with other WI fi nearby

**Mel Pino**: Omg call as soon as you can on fire

**Mel Pino**: Check email when you can...I sent two. Another affair in upper ems management, Janice is sliding in a nepotism hire on Chief, and fire is running 5 support calls a day on the perdido helicopters. Two yesterday were a UTI and a torn Quadracep.

**Mel Pino**: https://www.nejm.org/doi/full/10.1056/NEJMe2029812

**Mel Pino**: You can check his facebook page to see his credentials.

**Mel Pino**: DMO disbanded

**Jeff Bergosh**: Yes I got the email

### CONVERSATION ON 10-09-2020

**Jeff Bergosh**: I'll call u in 5

**Mel Pino**: Cool

### CONVERSATION ON 10-10-2020

**Mel Pino**: From one of the good guys in fire. The first sentence refers to Jana still. 

Yes when you are in charge of firing and hiring are going to fire yourself. I have zero confidence in anyone down there and this is becoming not only a toxic environment but also a dangerous one. Again no leadership letting volunteers with questionable training experience or qualifications trying to run emergency scenes

**Mel Pino**: Hes not one of the hardline anti volunteers. The same thing Is happening in ems with qualification levels.

### CONVERSATION ON 10-11-2020

**Mel Pino**: Ok this was Forest Creek last night bedroom fire. Contained to one unit several more minutes would have lost entire upper floor and 4 units. 

**Mel Pino**: From fire. I don't know how much these poor people can take.

**Mel Pino**: Jeff I am going to post today on the fire chief position and am going to go live with janice's failure to solve the washing machine thing unless you wave me off.

### CONVERSATION ON 10-12-2020

**Mel Pino**: Good morning, if you have a chance I'd love to talk about what's going down in Fire.

**Mel Pino**: I put in a PRR for the fire chief advertisement.

**Mel Pino**: Jeff do you think you could get them to put the past fiscal year salaries up already? They are not going to do it without pressure.

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: I can ask

**Mel Pino**: Thank you it would be great to have that live before Thursday even though they will say they can't do it. And they don't even have the broadband on the agenda that I can seen unless I'm missing it. I suppose they plan on sliding it under janice's magical backups CARES show.

**Mel Pino**: Backupless

### CONVERSATION ON 10-14-2020

**Jeff Bergosh**: On a teleconference

**Mel Pino**: Doug just admitted he lied about the FEMA money on lake Charlene. Just like he did with forest creek.

**Mel Pino**: Check the post I just made on my Facebook page. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-15-2020

**Mel Pino**: Please, please please do not let her do this.

**Mel Pino**: Matt Posner played her took all her information and then ghosted her on an application due tomorrow on a Trump grant of 1 .m. 

**Mel Pino**: Then Doug ripped her apart online and they are probably going to miss their grant deadline as a result. Then they came back with 7 letters of support when it was too late.

**Mel Pino**: Shes telling the stone cold truth. They are too smart to hunt. They aren't deer.

**Mel Pino**: Then maybe she might not have wanted to threaten Tamika on a fake investigation claiming she was stealing money she couldn't steal she tried.

**Mel Pino**: And I'm the one throwing around unfounded allegations. I have no doubt there are always people gaming the system. But bringing this up in such a sloppy manner with no hard data?

**Mel Pino**: Ask Alison who is paying for Dr Edler in her individual capacity on the Matt Selover suit. Make her say who is paying. Maybe she fixed it.

**Mel Pino**: So who is paying in the meantime.

**Mel Pino**: So who is paying in the meantime. She is being sued in her individual capacity and the judge retained that.

**Mel Pino**: Ask what the SPECIFIC reason they turned it down was. Intent?

**Mel Pino**: The insurance company has to say WHY

**Mel Pino**: Dodging the question

**Mel Pino**: WHY are they not paying and WHO is paying in the meantime

**Mel Pino**: It will be the same answer with any firm

**Mel Pino**: They are just wasting more money on the denial. They still haven't said why it got denied.

**Mel Pino**: It's not a sexual harassment claim. It's a constitutional and due process claim.

**Mel Pino**: Jeff Please don't let her slide through the broadband item refusing to mention what it even is. Doug's not here and there is a legal question perfect opportunity to just slice it off and only do the boat ramp.

**Mel Pino**: Jeff did they take navy point off the list? Staff member says it's not on there can you confirm?

**Mel Pino**: No backup. Can't see the list.

### CONVERSATION ON 10-16-2020

**Mel Pino**: Jeff was Jonathan at the meeting yesterday?

**Jeff Bergosh**: He was watching and lurking from the back break room 

**Mel Pino**: Thank you. Sending out an email to communications asking why the audio slipped out just at that moment and can it be fixed. Going to mention that asshole. 

**Mel Pino**: Blipped

**Mel Pino**: Look at this job posting that went up that further solidifies edler's power and further blurs the lines between the jail directorship and the ems directorship, which need to split back apart because of competing state statute.

**Mel Pino**: Also check my back and forth with Aaron on my Facebook page. He is claiming ownership of Hatch volunteer position. Should be the nail in the coffin of that hire.

### CONVERSATION ON 10-17-2020

**Mel Pino**: Oh for the love of god. It's so blatant. Commerce park versus market, greenery, and village. Are you picking kidding me.

**Mel Pino**: How about the Green Commerce Village. Throw that right back at them.

**Mel Pino**: Now you know exactly why I fucking hate DPZ so much.

### CONVERSATION ON 10-19-2020

**Mel Pino**: Edler turning on one of her people she used to force her out of the Department.

**Mel Pino**: https://davidpasqualone.com/content-type-media/podcast/rpp-season-2/gene-valentino-election-2020-covid-19-the-28th-amendment/

**Mel Pino**: Please listen for where it's at

**Mel Pino**: Grass roots truth cast.

### CONVERSATION ON 10-20-2020

**Mel Pino**: Posted on debris.

**Mel Pino**: https://abc17news.com/news/health-news/2020/10/20/daily-coronavirus-case-numbers-in-the-us-are-at-levels-not-seen-since-the-summer-and-14-states-recently-have-set-hospitalization-records/

### CONVERSATION ON 10-21-2020

**Mel Pino**: Truth is stranger than fiction, 2020 edition.

Rudy Giuliani faces backlash for his role in new Borat film, in which a 15 year old removes his microphone while he starts undoing his trousers and then Borst enters and says "she's 15, that's too old for you."

https://amp.theguardian.com/film/2020/oct/21/rudy-giuliani-faces-questions-after-compromising-scene-in-new-borat-film

**Mel Pino**: Hahahahahahahahaahha this just gets better

**Mel Pino**: Jeff does Escambia County School District have a required sealed bids for procurement?

**Jeff Bergosh**: Yes-- unless they are using the CCNA

**Mel Pino**: What is ccna

**Jeff Bergosh**: It's a state sanctioned way to get out of soliciting bids And using preferred vendors

**Mel Pino**: Thank u!

**Jeff Bergosh**: For A&E

**Jeff Bergosh**: And some other professions

**Mel Pino**: Jeff one way to get at that would be to tell her you want to be looped on all communications and want everything you haven't seen yet.

**Mel Pino**: It's a doozy

**Jeff Bergosh**: Okay I'll ask

### CONVERSATION ON 10-22-2020

**Mel Pino**: Hey can u talk?

**Jeff Bergosh**: In mtgs till 11:15.  Will call

**Mel Pino**: Cool

**Mel Pino**: Well Chris Hatch has already been promoted from an assistant chief at Myrtle Grove to Head chief at Bellview

**Mel Pino**: From Fire. There's that leadership you're wanting. Another Janice friend hire in the making.

**Mel Pino**: Jeff the board needs to publicly demand of Janice that she do a real, nationwide search on that fire chief position or you guys are going to be stuck with another lap dog who doesn't have the experience for the role.

### CONVERSATION ON 10-23-2020

**Mel Pino**: Call when u can on fire

**Mel Pino**: Hey something big not fire. 

**Mel Pino**: Please make a wide path around any of these idiots. Because even if you and Sally are wearing masks, if anyone asymptomatic but contagious is near you, it can enter through your eyes.

**Jeff Bergosh**: Will do!

### CONVERSATION ON 10-25-2020

**Mel Pino**: Jeff I have a bunch of text messages I need to talk to you about. There are a lot of them. Will you have time tomorrow or can we talk today?

**Mel Pino**: They're serious.

**Mel Pino**: I assume Doug made Chris Curb post this on ECW. I hope it's not setting him up for another write up.

### CONVERSATION ON 10-27-2020

**Mel Pino**: Kevin worked like a dog chainsaw the huge piles of fallen trees and vegetative debris in the park across the street, and we hauled a half dozen huge loads over to Lexington terrace. We have never had a single pass on our street, which is the main drag along the water. Now the contractors came out on more branches in the ROW and cut up big piles and left them with a hurricane incoming. And people wonder why a lot of us are tearing our hair out over janice's mismanagement. Her ineptitude is a very real problem that impacts citizens daily. It's not a theoretical.

**Mel Pino**: Haven't gotten to your article yet I was arguing with the tree contractors. Same fucking company that cut down those healthy trees in front of Jessie rigby's house.

**Mel Pino**: 1. Check email I reference olf8 in one I just sent out. 2. Banner heading on electronic PNJ is Kevin Robinson on olf8. 3. I can't find yours!

**Mel Pino**: Ok I found it but had to do a Google search. Fuckers. 

**Mel Pino**: Hahahahahahahaha omg this is awesome

**Mel Pino**: Check my Facebook page

**Mel Pino**: Bill Cross passed. :(

**Mel Pino**: Hey was leaving you a message but it cut off. Kevin Robinson olf8 piece giving theresa Blackwell the microphone went up on their Facebook. I brought in that comment about Doug tanking the scores.

**Mel Pino**: Hahahaha the Pnj tried to block my comment but I got it screenshot and posted on my page so they put it back up

**Jeff Bergosh**: Thx Mel!  Sad to hear about Bill.  He was a great guy

**Mel Pino**: Yes that's what I hear. Check that comment in PNJ you will die laughing

**Mel Pino**: Shaun halls facebook claims both Navarre AND Escambia county fire.

**Mel Pino**: He went to Tate.

**Mel Pino**: Go to the fire page and look what those fuckers are posting and what I put up.

**Mel Pino**: Janice's inefficacy is putting massive liability on the board. She and Alison both.

**Jeff Bergosh**: Where are they posting this tripe?

**Mel Pino**: It's on the fire union page. I'm throwing down there but in a way they won't recognize as throwing down. You guys need to put a stop to this Jeff.

**Mel Pino**: If that family sees this string it could be a massive lawsuit and that is what they are trying to accomplish. 

**Jeff Bergosh**: These ffs don't care.  And there is NO leadership in admin reigning them in.  Disappointing

**Mel Pino**: Should be an interesting meeting tomorrow. Perfect springboard to ask Janice for the advertising on that position. Don't let her lie to you...tell her you want to see it, and won't support a nepotism hire. You guys gotta get her under control.

**Mel Pino**: Janice Kilgore came on the string demanded accountability from the bocc and I called her out on her bogus, worthless report.

**Mel Pino**: Surprise surprise. The guy running the charter makes an entry into the conversation encouraging suits against the county. This is the game that is being played.

**Mel Pino**: He can take that back to her city handlers.

**Mel Pino**: Oh and it came out on this string that Robert is telling people that they just need to wait for him to be chair and he will fix our public safety. God help us.

**Mel Pino**: Different John Peacock but he got the tag and responded and knows exactly what I'm talking about.

**Mel Pino**: All right, I'm done for tonight after answering Janice Kilgores claim that you guys didn't really want the real answers on public safety. I will leave it on this. While we these two still be employed by Escambia county tomorrow?

### CONVERSATION ON 10-29-2020

**Mel Pino**: I got permission to share some texts with you devoid of name and identifying context. I am not asking you to take this at face value or take up the cause from this. But I really need you to know that I'm not nuts, there are multiple people coming forward now, and I will keep trying to get the evidence solid sooner than the depositions because this situation really can't wait to get fixed. 

**Mel Pino**: This is the last one from this particular string. This is only one person trying to come forward but scared. There are others. 

**Mel Pino**: Does that sound made up to you? It's not. I knew about it all back in the day and told Janice what was going on. Her response was that "she couldn't control who people had sex with" and then she started feeding Edler evidence for the civil suit against me and lied about me not providing the names on the original complaints against Edler and nail. Supposedly someone put in a harassment complaint on Maddrey before she was fired recently but I haven't been able to confirm that and the person is somewhat erratic. 

**Mel Pino**: If I weren't so sick about what our ems is living through daily I would just sit back and wait for this to come out in depositions. The toxicity harassment and sick culture in there is making good people ill and they can't focus on their jobs. And then there is the question of whether ems can even be held together at this point. 

**Mel Pino**: The last thought on this for now is that JJ and I were going to get a lot more than this exposed but the suit got conveniently dropped right before depositions. They thought they could bankrupt us and shut me up.

**Mel Pino**: Sorry I forgot about this.

**Mel Pino**: Look at the horrible position they put Audrey in so they could have plausible deniability. That is why Janice has the public records set up this way. She knows about every PRR and manages it but can always say she doesn't know.

### CONVERSATION ON 10-30-2020

**Jeff Bergosh**: Wow-- crazy stuff

**Mel Pino**: Call when u can there is more

### CONVERSATION ON 10-31-2020

**Mel Pino**: All lifeguard employees just got a 500 dollar bonus

**Mel Pino**: How many more doe you think we will lose from the county on that? This plan is moving right along.

**Mel Pino**: Also there was another HUGE violation of due process yesterday for fire me Friday.

**Mel Pino**: Going to call and leave a message

**Mel Pino**: The type of flagrant violation that could land the bocc and taxpayers in another lawsuit. Janice, Jana, and Alison don't care. They will keep running these legalities and gutting county staff because nobody is stopping them. So why would they stop?

**Mel Pino**: Illegalities

**Mel Pino**: Fyi I am in an all out war with Doug and Wendy on Megan Walters page and I told Wendy if she doesn't stop lying about me I am going to drag her dead ass into court so fast her bowl cut will be spinning.

**Jeff Bergosh**: LOL That's a great line

### CONVERSATION ON 11-01-2020

**Mel Pino**: Fascinating interactive map right down to the counties that could decide it.

https://www.nytimes.com/interactive/2020/us/politics/battleground-states-trump-biden.html

**Mel Pino**: Wtf now. They are divorcing from the jet ski world because it is a GOB against them?

### CONVERSATION ON 11-02-2020

**Mel Pino**: Call when you can. 

**Mel Pino**: Just dropped a bomb on your blog

**Jeff Bergosh**: Ok thx I'll post it

**Mel Pino**: Doug posted another entry in his diary. This shit will be non-stop now.

https://www.floodtrends.org/escambia-leaders-utility-officials-reduce-flooding-risk-with-sewage-fix

**Mel Pino**: Posted

**Mel Pino**: Did you get an email about it? Anything that could be given to Rick anonymously to get the word out?

**Mel Pino**: Sorry that was to somebody else on covid spread at sacred high :(

**Mel Pino**: They are of course not publicly announcing. Criminal insanity.

**Mel Pino**: Nothing on their website and still have homecoming advertised :(

### CONVERSATION ON 11-03-2020

**Mel Pino**: Call when u have time

**Mel Pino**: Listen to the voicemail I left when u have time

**Mel Pino**: Sorry Catholic high. I keep saying sacred cause that's my Catholic school.

**Mel Pino**: Those job listings are a fucking mess. Different end dates; some of them already show it closed and most don't have date posted.

**Mel Pino**: Eighty percent of Florida is eight thousand for biden

**Jeff Bergosh**: Yes but the panhandle is all red-- victory lane for Trump

### CONVERSATION ON 11-05-2020

**Mel Pino**: https://ricksblog.biz/county-reallocates-cares-act-funds-away-from-households-businesses-and-testing/

**Mel Pino**: Covid back in a lot of departments at the county already but that is not being made public and there is no contact tracing. 

**Mel Pino**: Poor Marie. Notice she dodged the question of whether the county is contacting her office about positive cases in the county.

**Mel Pino**: Blah blah blah blah

**Mel Pino**: Why would she be surprised. The hospiall er's have been running this game for a long time.

**Mel Pino**: Thank you

**Mel Pino**: Yes need a couple of night

**Mel Pino**: The saliva test has been going in Canada for four months. 

**Mel Pino**: Trump administration is blocking its release here. So good luck with that.

**Mel Pino**: Wtf is the fist bumping at the podium. The lack of professionalism is pathetic.

**Mel Pino**: Worst hurricane response out of the county possible so we give them plaques commemorating it.

**Mel Pino**: Chris Curb just got an email that he has been terminated.

**Mel Pino**: Sounds like they are trying to make it sound as if he missed a meeting on it that he wasn't told about.

**Mel Pino**: Alex has spent as much time running around trashing Dianne and crying about her 46 percent than he has on the bridge.

**Mel Pino**: He told me that I need to get off Facebook because everybody knows I'm crazy.

**Mel Pino**: What about all the changes she made after you guys decided otherwise.

**Mel Pino**: Well there you have it why there was only one bid.

**Mel Pino**: Are you fucking kidding me.

**Mel Pino**: Is that an ethics violation??

**Mel Pino**: Jeff Please don't leave early. Don't trust it without you there.

**Mel Pino**: Somebody should have asked Doug why he wasn't doing the same thing with his piss poor maintenance of the access in perdido. Maybe for tonight? Ask him why they aren't being maintained and why they are out of compliance with ada

**Mel Pino**: Jeff Doug can't give that to Michelle. He has sent her threatening texts including telling her he was going to wrap me around her like a bow tie.

**Mel Pino**: Can't you give it as the committee person for the militar

**Mel Pino**: Doug, that was a disgusting display. You have a he'll of a lot of balls after those threatening texts you sent Michelle including the one where you said you would wrap me around her like a bow tie. Just remember those texts are saved. You have no shame. 

**Mel Pino**: This fucking piece of shit

**Mel Pino**: Well let Yakima black try to come at you on that one,

**Mel Pino**: That should gain you some support.

**Mel Pino**: Jesus Christ I know this is a long day but if you have it in the tank please call the ems worker that Jason Rogers is harassing the shit out of. He needs to file a complaint not quit.

**Mel Pino**: I hope you are seeing how rotten to the core this is. Look at the lies and illegality I handed you guys in that email string. 

### CONVERSATION ON 11-06-2020

**Mel Pino**: They fired Alan Bedford in traffic for Fire Me Friday.

**Mel Pino**: It might have been for wasting time and driving around.

**Mel Pino**: Posted

**Mel Pino**: Hi Gene, fyi I am seriously thinking about filing against Doug...happy to talk with you about that. I had a friendly conversation with Steve about it and told him that there wouldn't be any hard feelings if I do. I think Steve is a great guy and has some solid leadership qualities, but he's not ready to be a commissioner and has too high a bar on the business in D2. I wish he would run for ECUA! But I think you know that if both of us are on the ticket, there certainly wouldnt be any negative campaigning against him from me. On another note, we need somebody good to get Paul Fetsko out of that schoolboard seat.

### CONVERSATION ON 11-09-2020

**Mel Pino**: Jeff I forgot to ask you ifthe Sorrento project is shilling in any way. Going to forward you an excnage tracy had with Doug so you can tell me whether it's bullshit

**Mel Pino**: I just found out JJ is depoing Edler right now. 9 to 5 today. Matt tried calling me yesterday but I missed it. 

**Mel Pino**: Younger guy in code dept has been out for three weeks with covid. Today was supposed to be his first day back and to the best of my understanding he took a turn for the worse yesterday and is in the hospital with a collapse lung pneumonia.

**Mel Pino**: Left a voicemail.

### CONVERSATION ON 11-10-2020

**Mel Pino**: Have an update when you have time.

**Jeff Bergosh**: Okay I just tried to call you

**Mel Pino**: I know you are probably beat so I am cringing to call but I do have something kind of important.

### CONVERSATION ON 11-11-2020

**Mel Pino**: Left a message.

**Mel Pino**: Maddrey called out sick for his depo tomorrow.

### CONVERSATION ON 11-12-2020

**Jeff Bergosh**: Is bill Hopkins "Pineapple"

**Jeff Bergosh**: In executive session

**Mel Pino**: Already? Shoot

**Mel Pino**: Yes

**Mel Pino**: Yes

**Mel Pino**: Yes

**Mel Pino**: If there is an offer and they tell you it comes with a non disclosure I would be very surprised if they actually did it that way

**Mel Pino**: Jeff I wish you would seriously consider that if you are an asymptomatic carrier of covid right now, you will infect Lumon. I see eve Steven is wearing one. The optics of it being only you and that jughead are not good.

**Mel Pino**: There's his campaign in a nutshell.

**Mel Pino**: Oh yeah Florida is a real beacon of election standards. The only reasons there wouldn't be huge lawsuits here is that biden has too much class.

**Mel Pino**: But I absolutely agree on Escambia county Stafford is a gem.

**Mel Pino**: Hahahahaha

**Mel Pino**: WTF another sole source contract??

**Mel Pino**: That was just another move towards a combined charter with downtown in charge

**Mel Pino**: Looks like Janice and Pam will continue to move it in that direction.

**Mel Pino**: He's kind of a lumper all right

**Mel Pino**: So that just required the division lead, a deputy administrator, and an assistant administrator to pull teeth and get some straight numbers. Way too many cooks in the kitchen who don't know exactly how many eggs are in the fridge.

**Mel Pino**: What about the lack of numbers from the county? Where did that go? Continual cover-up and it is endangering everybody in this community

**Mel Pino**: THANK YOU

**Mel Pino**: Because deathsantis is running a stealth herd immunity experiment on the citizens of Florida. And just hired a qanon blogger from Ohio to muddy the waters on covid numbers further.

**Mel Pino**: You're never going to get any factual data out of state DOH you will have to go outside the state. And the hospital admins will never help you get the data you want from testing. It will just be another stall and then any data you get from DOH will be corrupt

**Mel Pino**: Is chronos being used at the city? They are gaming the hell out of you guys.

**Mel Pino**: This is such fucking bullshit.

**Mel Pino**: Mike says the question should be What capacity are you trying to create. More than fte's. And what are you going to fill that capacity with

**Mel Pino**: There is no fiduciary benefit to the county he says. This is a benefit to the employees.

**Mel Pino**: It's about capacity not fte's. And apparently they never mapped the processes to the plan source software if theyare still pushing paper.

**Mel Pino**: ( I asked Grover about chronos) No. We use Neo-Gov type. We are asking for the full neo-Gov that the county just approved. 

**Mel Pino**: If they are going to be using neo Gov rather than chronos and the county is getting neo Gov then why the hell do they need chronos?

**Mel Pino**: THE COUNTY NEEDS THE SAME HVACING

**Mel Pino**: It will keep people healthier long after covid

**Mel Pino**: This is just fucking ridiculous. You guys are allocating for what you are getting rid of. It is absolute chaos.

**Mel Pino**: He's trying to remember what Janice wanted.

**Jeff Bergosh**: LOL

**Mel Pino**: And he completely ignores that point lumon just made.

**Mel Pino**: Jesus this is going to be a long year starting.

**Mel Pino**: The point is that they are managing covid properly and the county isn't. Period, end of story.

**Mel Pino**: So many things they are asking for are crucial and it just highlights the fact Janice hasn't done it.

**Mel Pino**: The reason the county is in chaos isn't because of covid. The reason is the difference in administrators.

**Mel Pino**: The reason the county is in chaos isn't because of covid. The reason is the difference in administrators. And the fact that so much of our institutional knowledge is out the door.

**Mel Pino**: Lumon is dead on. Everything happening at the city should be happening at the county. This meeting is just such an embarrassment to watch, Jeff. The worst yet.

**Mel Pino**: From mike

https://www.nejm.org/doi/full/10.1056/NEJMoa2029717

Synptom screening--tempersture checks and questions about fevers--ineffective against younger 16-28 year old demographic.

The implications for colleges, schools, prisons, meatpacking plants, etc., are significant because these do not reduce the threat of asymptomatic or presymptomatic spread. 

Routine testing better for this age group, combined with good public health measures (mask wearing, social distancing, hand washing).

**Jeff Bergosh**: Thanks Melissa

**Mel Pino**: Can u talk?

**Jeff Bergosh**: In mtg will call u back

**Mel Pino**: K

**Jeff Bergosh**: On other line will call u back

**Mel Pino**: 👍

**Mel Pino**: Posted 

**Mel Pino**: I know what I forgot to tell you. I got told from a pretty solid source that a public safety head and an HR head were playing around with a truck up at the gun range.

**Mel Pino**: Hey Jeff don't put that one I just posted up I didn't see that you actually posted the other one...I thought it got hung up in the survey because I lost it on my end

### CONVERSATION ON 11-16-2020

**Mel Pino**: Posted.

**Jeff Bergosh**: Okay got it

### CONVERSATION ON 11-17-2020

**Mel Pino**: Nice speech I never knew you grew up on bayou Grande!!

**Mel Pino**: Sounds like wear is going to announce Morgan running for mayor on ten o'clock tonight. God help us.

**Jeff Bergosh**: WOW!  That would be a bombshell

**Mel Pino**: Hardly. He has been making the rounds for months. I told Grover a year ago after he pissed him off Morgan would run against him haha of course he did. That's how the dude rolls. He has gotten turned down on a few big money asks but that won't stop a guy like that. He can't stand not being on the news and he throw in early just to maintain access.

**Mel Pino**: Jesus Jeff look what hit Gibbs point today after I mentioned that to you...Doug is going to riprap this

**Mel Pino**: Because his stupid fucking project is not working

**Mel Pino**: And he finally admits he is gonna run janice's program of selling our ems. At least it's finally out there.

**Mel Pino**:  What a coincidence with Robert chair and ready to run janice's program.

**Mel Pino**: Michael didn't even know this happened. 

### CONVERSATION ON 11-18-2020

**Mel Pino**: Hey wanted to touch base on ems. Not urgent.

**Mel Pino**: https://ricksblog.biz/robinson-no-coordination-collaboration-or-consistency-out-of-gilley/

**Mel Pino**: Maybe this will be the juncture at which the Republican party will pull it's head out of its ass.

https://ricksblog.biz/salzman-misses-first-florida-house-session/

### CONVERSATION ON 11-19-2020

**Mel Pino**: Studio 850 is live with the fire Department on kitchen fires. I sent u the link. It's really stupid

**Jeff Bergosh**: I called you back and it went straight to voicemail

**Mel Pino**: Hey sorry I was out in the shop. I'll try you tomorrow.

### CONVERSATION ON 11-20-2020

**Mel Pino**: Check my comment back to CJ Lewis here.

https://ricksblog.biz/robinson-no-coordination-collaboration-or-consistency-out-of-gilley/

**Mel Pino**: Sorry, had to offer a counter to deathsantis's bullshit data. 

**Mel Pino**: And don't worry, Bybee time Lincoln project gets back and and starts focusing on him people will be running in the opposite direction

**Jeff Bergosh**: I predicted a Biden win.  Although I voted Trump. I predict De Santis wins re-election In 2 years.  You heard it here first😎👍

**Jeff Bergosh**: 😎👍

**Mel Pino**: Oh please you always move the goalposts and then claim you predicted it hahaha I told you Biden would win by a landslide because of covid in April. BUT I was wrong on Senate and I admit when I predicted wrong. Desantis can play his numbers games all he wants but the only number that will matter in the end is the real world number of how many people have someone they love die of covid or turn into a long hauler. And that's going to rack up tremendously in the next two months here whatever he does to jigger the stats. And hey this is only if he stays alive to run. If he does, he will be lucky to make it out of a Republican primary and it will be such an onslaught of people flipping furious about covid that all the voter fraud the Republicans can muster won't do the trick. You heard it here first! 😛

**Mel Pino**: Now post my comment!! Hahaha

**Jeff Bergosh**: LOL

**Mel Pino**: Just PM'd you a post I made about Doug's off the books rip rap

### CONVERSATION ON 11-21-2020

**Mel Pino**: I posted on the gun thing and fyi those are honest question. I don't get I. Sounds like a clusterfuck but there may be stuff I'm not understanding

### CONVERSATION ON 11-24-2020

**Mel Pino**: Here's why we don't have real covid data and our numbers are so low across the board: testing, cases, hospitalizations, deaths.  The Orlando Sentinel had its attorneys go after the coronavirus task force's reports to desantis, who has been keeping them from local leaders. If you click through this article to the previous one, the report is viewable. 80 percent of Florida counties in bad shape with spread. They are sounding the alarm that she state is going bad fast and he is refusing to share the report. Same way he has been hiding and corrupting our covid data from the beginning. Mel loses another   bell from her tin foil jester cap. This is also why desantis is going to get crucified when the Lincoln project gets him in their sites. One and doner who will go down as the worst governor in Florida history.

https://www.orlandosentinel.com/coronavirus/os-ne-coronavirus-white-house-task-force-report-1115-20201120-ttvzwscavbgutkbc7duuocomwe-story.html

### CONVERSATION ON 11-30-2020

**Mel Pino**: Hey are you on the way in?

**Mel Pino**: Oh my Lord Jeff that "single" contributor coming from different IP addresses is just exploding gibberish into your comments. Make a new rule that you don't post comments that aren't on the subject? Good grief she is so flipping out of control.

**Mel Pino**: Im thinking about posting an entry on how awesome my dog is just to make the point haha

**Jeff Bergosh**: LOL

**Mel Pino**: Done LMAO

**Mel Pino**: You better post it hahaha 

**Jeff Bergosh**: Just did

**Mel Pino**: I know I saw hahaha omg she needs a spa day. Seriously.

**Mel Pino**: Hey I got the direct and exact skinny. Give me a quick call when u can to fill you in.

**Mel Pino**: Also I heard from fire that Hatch is on the list of people chosen to interview for firew chief.

**Mel Pino**: Well I was told he wasn't even going to apply because of his Navy Fire job and low and behold his name is on the secret list. Don't they have to make that public (From fire)

**Jeff Bergosh**: I'll call u first thing tomomorrow

**Jeff Bergosh**: *tomorrow

**Mel Pino**: K

**Mel Pino**: New hospital record for the US this week (reflecting events about 8-14 days ago). We are soon to break 100k hospitalizations. Cases are down but so is testing—likely due to holidays. 

**Mel Pino**: Hospitalizations have doubled since November 1 and tripled since October 1. We should see 100k hospitalizations in the next couple of days.

**Mel Pino**: Maybe that's why Atlas just quit while the quittin's good. He can probably get a job with desantis.

### CONVERSATION ON 12-01-2020

**Mel Pino**: Sent. The text message fiasco is 4 different forwards with the first just being a reminder of how jj thinks the county is out of compliance. The other set is just a single forward of back and forth with typical stall tactics with no reason given other than they are probably waiting for the systems to purge.

**Mel Pino**: Eavesdropping device discovered in office of Escambia County Administrator https://weartv.com/news/local/eavesdropping-device-discovered-in-office-of-escambia-county-administrator

**Mel Pino**: She's desperate

**Mel Pino**: Oh my god  I am on the phone with a new ems who just got fired Nov fifth holyshit JJ. Claiming Maddrey drug use etc. More workforce violations. Terminated. She filed multiple complaints with HR but never got anything back

**Mel Pino**: (meanwhile from fire) So we have lost 2 great firefighters this week alone related to low wages and the toxic work environment which is created by Williams. Why can no one see this 

**Mel Pino**: She ordered the sweep because a private conversation "ended up on the streets." What is this, Boardwalk? 


https://photos.app.goo.gl/exYjyWrs8TAYZUQK6

**Mel Pino**: This story was rapidly evolving from the 5 to the 6. Now it's active audio and video and she wasn't told the investigation was over. 

https://photos.app.goo.gl/TUU2DzAp93pQQ3w86

### CONVERSATION ON 12-02-2020

**Mel Pino**: Woo hoo OLF8!!!!!!!! 

**Mel Pino**: I am logging on to your coffee to ask Janice about trespassing homeless during a pandemic had a talk with ECSO about it last night

**Mel Pino**: Jeff don't miss my question to Gilley about trespassing homeless!

**Mel Pino**: Those questions were asked in concert with ecso

**Mel Pino**: Left u a message but I think it deleted.

**Mel Pino**: Check my tags on my page off your coffee

**Jeff Bergosh**: Okay thanks Mel!

**Mel Pino**: I am already laughing my ass off today Holy shit that's some good stuff sniffing dog in the middle of the night

**Jeff Bergosh**: LOL

**Mel Pino**: IT WAS THE BOMB SNIFFING DOG INTHE CONSERVATORY WITH THE REVOLVER

**Mel Pino**: Hey Jeff when you get a chance would yu just respond that you will check into the homeless thing and lake Charlene and Washburn getting written up against Tim's direction. Janice has people watching my page like a hawk.

**Jeff Bergosh**: It was colonel Mustard in the study with the candlestick

**Mel Pino**: Oh my god look at Rick's new blog he is having a field day check his disclaimer

**Mel Pino**: https://www.newsweek.com/florida-police-dog-trained-sniff-out-child-porn-electronic-devices-1459298

**Mel Pino**: What exactly did she have them looking for Jeff? 

**Mel Pino**: Answer: any dirt they could dig. She was probably also looking for answers on the current security and where the weak links are. And YOU CANT TRUST IT.

**Mel Pino**: Do NOT let that woman install some lanky shit with Chinese back doors that she can manipulate.

**Mel Pino**: Janky

**Mel Pino**: She set this shit up to make the argument for her to have more tech control

**Mel Pino**: See my comment on what the hell she was up to and call me when u can.

https://ricksblog.biz/more-on-bcc-bug/

### CONVERSATION ON 12-03-2020

**Mel Pino**: Jeff take a listen to my voicemail when u get a chance. On the covid task Force reports

**Mel Pino**: https://www.orlandosentinel.com/coronavirus/os-ne-coronavirus-white-house-task-force-report-nov22-20201202-k3h7y6vt5vdrljwjpalzxnhmgi-story.html

**Mel Pino**: They previously reported on the data from the fifteenth. I pulled all those images down and was trying to get it in a workable size. They are gunning for the 29th also but the data there needs to be on county and city agendas for discussion

**Mel Pino**: Left a message about the Cow...she is going to cut off agenda soon

**Mel Pino**: (Sent to me just now and aligns with what I'm hearing is going on in there. I'd love to know what edler's presence has been there. I'd imagine very little but proxy)

s Dr. Elder over patient care at the county jail? My granddaughter's mother was in jail recently. She said there's a woman that's been in there for a year (no family to help her) and she has breast cancer. They've ignored it and it's grown noticeably! She's literally dying of breast cancer in jail because of zero medical care. She also said there are bugs eating everyone alive. 

**Mel Pino**: https://www.orlandosentinel.com/coronavirus/os-prem-desantis-spin-coronavirus-florida-20201203-hi6tbvixxbhzlmlfn2vqcyvsym-htmlstory.html

**Mel Pino**: Jeff, plausible deniability has run out on covid now. There's no more "we didnt/couldntknow" left in the tank. This needs to go on the Cow and above everything else. Only you and or Steven could do it. Robert won't listen to lumon because he is drinking janice's washed up Trump koolaid still. It needs to be a Republican that takes responsibility now.

**Mel Pino**: So among other things in that article is that desantis ordered county DOH people to stop giving statements in advance of Trump's election. Remember when I told you Marie Mott simply could not say anything? And that chips was just bullshitting and stalling by pretending he could get with DOH for more data.

**Mel Pino**: He knew she is under a gag order.

**Mel Pino**: Reports of Skanska bridge repair crews arriving with their top engineers today.

### CONVERSATION ON 12-04-2020

**Mel Pino**: Check pm and call me on the way in if you want...I amp and out of the gate.

**Mel Pino**: Hey Jeff, I hadn't seen your blog post from yesterday when we were talking this morning. I just posted...please take the second and not the first as I corrected a typo in the second one. I do mean what I say in the post; there really isn't any further point of discussing, and it I had seen your post I wouldn't have brought all that up today. I wasn't picking a fight over the post; I didn't know you honestly held those thoughts about covid still. So that's really the last I have to say on it, and if you want to answer on it I'll let you have the last word. Although I wish you wouldn't, not for my sake but for yours. :(

**Jeff Bergosh**: I just approved the comment.  There is nothing wrong with disagreement 😁

### CONVERSATION ON 12-05-2020

**Mel Pino**: Jeff I know you maynot believe this, but my concern is for not just the people who are dying under wretched governmental policy, but your place in the history of this thing. I consider you a friend and know you are a good person. When the realization of what is going on finally hits you--and it will-- you are going to have a difficult time coming to terms with your previous opinions. And history will not look kindly on those who have gone done in print with a narrative that this thing isn't so bad. By the time this is over nobody but the worst loony toons is gonna wanna hear that. That's all. 

**Jeff Bergosh**: Mel I appreciate it and I prefer to look at areas where we agree. Number one it's dangerous. Number two it's serious. Number three people should take reasonable precautions. Number four people are dying. Number five there are different approaches to managing this pandemic. Number six it has been Weaponized and politicized I hope you can agree on that. And finally, Anyone who doubts that this virus has been politicized is smoking crystallized methamphetamine. Because look no further than the blue states where they have closed the churches but allow strip clubs abortion clinics tattoo shops and massage parlors to be open along with liquor stores as essential businesses. Yes it has been politicized I hope we can agree on that. And finally I'll leave you with this look at numbers. Look atThe deaths in New York a state that is smaller than Florida compared to the deaths in Florida which is bigger than New York. New York deaths from Covid are double what they are in Florida. The numbers tell the story Mel facts tell the story I'm not gonna discuss Covid with you any further we disagree and I feel that our approach in Florida is much more reasonable than any fucking blue state where they closed churches and leave abortion clinics and strip clubs open. Have a good weekend will talk on Monday or Tuesday

**Mel Pino**: Sounds good I agree and am relieved this topic will be a no go between us from here on out. Too stressful. 

### CONVERSATION ON 12-07-2020

**Mel Pino**: DeSantis seized Rebekah Jones' tech using State Police with drawn weapons.

https://www.tallahassee.com/story/news/2020/12/07/agents-raid-home-fired-florida-data-scientist-who-built-covid-19-dashboard-rebekah-jones/6482817002/

### CONVERSATION ON 12-08-2020

**Mel Pino**: Good morning. So here is Escambia county's very own special place in the DOH corruption. After Janie brissett was done investigating the certifications issue at the county, and turned it over to Fdle to take over, and the county had negotiated a very favorable settlement with DOH even though the verdict was still out on the cases, Janice and Keith Morris, who is ruthless ex Fdle, hired her on to Keith's office. And now Fdle is conducting sweeps of the fourth floor and people are trying to put those devices she planted on somebody "on the inside" working for me. And if you think that's tin foil hat, go watch the video of Fdle raiding rebekah Jones's house on an insignificant cyber crime, even if she did it , with guns drawn and her kids home. Then ask yourself how much you like having these people running the show at Escambia county.

**Jeff Bergosh**: Sounds dystopian

**Mel Pino**: Pfffft playing you guys all day long. Thus Janice gets Eric Gilmore in after all which I fought off the first round.

**Mel Pino**: Fyi this is Janice playing lumon. She told him nothing covid was happening today.

**Mel Pino**: That actually makes a lot of sense if the populace weren't so impatient.

**Mel Pino**: Why does it fucking matter if you turn the businesses around and have them leave trees behind along nine mile

**Mel Pino**:  Make the entries to the businesses on the flip side and have beautification on the rear and leave trees up. This is not rocket science.

**Mel Pino**: These guys are pretty pompous for a firm that wouldn't even be sitting there except Doug Underhill working for downtown 

**Mel Pino**: What. The. Fuck.

**Mel Pino**: I guess "parallel paths" is the new term for bilking it early and often. And they need catering to pretend they are choosing a board,

**Mel Pino**: Et voila how she continues to divide the board.

**Mel Pino**: Nineteen million dollars???? Did I hear that right

**Mel Pino**: Omg Thompson is the consultant?? Or a vendor? I'm not dense...there is no backup

**Mel Pino**: Wait a minute. Thompson is the consultant who is making shit tons of this money and they are consulting on these change orders?

**Mel Pino**: This is unbelievable Jeff.

**Mel Pino**: She just called covid a silver fucking lining

**Mel Pino**: Maybe she can steal it from TDT.

**Mel Pino**: Wheres the "no bid opportunities" category. 

**Mel Pino**: Guess that was number zero

**Mel Pino**: Robo call going around on Gilley.

### CONVERSATION ON 12-09-2020

**Jeff Bergosh**: On weekly call with Alison and Janice

**Mel Pino**: Janice has some shit on the agenda letting her yank a salary up ten percent when somebody changes position

**Mel Pino**: I got a call about it. I haven't found the item yet but somebody is pretty concerned about her having more ability to grow bureaucracy and silence more people with raises. Don't let her lie to you about it

**Mel Pino**: Here it is. Employee promoted or reclassified to a position with higher dBm salary will increase by AT LEAST ten percent (change from five)

**Mel Pino**: I am going to be coming at that cherry picked stuff HARD no fucking way.

**Mel Pino**: Why AT LEAST ten percent?

**Mel Pino**: Car 2 17

**Jeff Bergosh**: I'll explain it -- there is some rationale for it

**Mel Pino**: Oh I'm sure she has plenty of it. There is ZERO language for "at least"

**Mel Pino**: It should be DROPPED

**Mel Pino**: I showed it to Mike and he said Lin the middle of a fucking pandemic? And then asked if Union was involved.

**Mel Pino**: Why let her Institute this policy or any other on the way out the door? It's ludicrous

### CONVERSATION ON 12-10-2020

**Mel Pino**: Hey I know you probably already have this but just in case. Language on the statue for formulation of the votes on the trust.

**Mel Pino**: Here we go again with the appearance games.

**Mel Pino**: WHAT are they doing at the county to let people know jeff?? Anything??

**Mel Pino**: I mean Jesus Christ. 9 to 15 employees and NO explanation of what the county is doing to let people who came in contact know??

**Mel Pino**: Maybe if they provided the appropriate backup that would have saved this conversation. 

**Mel Pino**: Io have some ideas about why Janice wouldn't be the signatory HELL NO

**Jeff Bergosh**: I called it 

**Jeff Bergosh**: Without a tantrum

**Mel Pino**: No he said you need to be on it

**Jeff Bergosh**: Bullshit he did

**Jeff Bergosh**: He wants to kick it to January

**Mel Pino**: Jeff I told you he was going to large recognize where the bullets are pointed

**Mel Pino**: YES HE DID

**Jeff Bergosh**: And not vote today

**Mel Pino**: YES because he is trying to break Robert on his backdoor with julian

**Jeff Bergosh**: He wants it

**Mel Pino**: Yes that's fine he already said that you need to be on it

**Jeff Bergosh**: Said he'll vote no tonight when it comes

**Mel Pino**: In addition to you. When you get emotional you don't hear

**Jeff Bergosh**: And Barry will vote no too

**Mel Pino**: He is absolutely crushing Robert right now

**Jeff Bergosh**: It's bullshit I don't want to be in the middle 

**Mel Pino**: Right but you already have it. He is trying in addition not instead

**Jeff Bergosh**: It's a slippery slope going against chairman's recommendations

**Jeff Bergosh**: Childish

**Mel Pino**: He said he wants to serve with you and he just exposed Robert BIG TIME for running games

**Mel Pino**: That's Robert. My phone is blowing up with people saying lumon played it beautifully. Not against you but ROBERT

**Mel Pino**: No, you don't understand the undercurrents. He also just called out McQueen hard for his bullshit lying and dividing the bocc. Those fuckers need to be put in line not placed to and the Robert Janice feed from people needs to be put down Hard now. When you go back and view the tape you will see Robert said you need to be on it

**Mel Pino**: I even typed it in the moment on my Facebook page.

**Jeff Bergosh**: He said he won't vote for me.  You missed that.  He won't vote for me tonight because he knows pushing it will lead to him being appointed when Doug gets back.

**Jeff Bergosh**: Childish, self-centered bullshit and nothing more

**Mel Pino**: He said he wouldn't vote for you TONIGHT

**Jeff Bergosh**: You don't get it.  

**Mel Pino**: You can't see the forest for the trees. Meanwhile Janice just lied her ass off.

**Mel Pino**: He is trying to get two on

**Jeff Bergosh**: No vote tonight for Jeff guarantees Lumon appointment on January 7th when Doug gets back

**Mel Pino**: It's better to have TWO from bocc and if you guys vote tonight that won't happen

**Mel Pino**: Nope

**Jeff Bergosh**: Yes but he wants the guarantees slot 

**Jeff Bergosh**: It's childish tantrum bullshit

**Mel Pino**: Janice was lying about how the 15 recommendations are made to the governor.

**Mel Pino**: Janice was lying about how the 15 recommendations are made to the governor.

**Jeff Bergosh**: Red herring

**Mel Pino**: https://www.nasdaq.com/articles/ge-ends-century-old-development-program-2020-11-11

**Mel Pino**: https://www.marketwatch.com/story/general-electric-agrees-to-pay-200-million-fine-for-misleading-investors-sec-says-11607552028

**Mel Pino**: Their failures to develop leaders who spoke dangerous truths and addressed risks rather than try to hide them has resulted in the catastrophic failures in the firm. They are selling off assets to remain viable 

**Mel Pino**: Per Roberts asinine GE comparison.

**Mel Pino**: I sent an email you probably want care about now but might care about later. In lieu of coming to public forum. Maybe you could read it even if you don't want to. :)

**Mel Pino**: TAKE IT hahaha

**Mel Pino**: I don't think you had to do that :( if you really do want it don't let up Jeff keep advocating for two

**Mel Pino**: I get a kick out of it when Pam and Janice think they are going to game David. As if he's Robert.

**Mel Pino**: Hahahahaha

**Mel Pino**: What. The. Fuck.

**Mel Pino**: This will be good.

**Mel Pino**: 50k is flipping pocket change

**Mel Pino**: Robert is so gaslit he is out of his mind. Has no idea what the hell is he talking about.

**Mel Pino**: This looks so bad

**Mel Pino**: Robert has this effect on my dog.

**Mel Pino**: Actually a lot of us just have a big interest in how Janice moves money around. 

**Mel Pino**: Its just getting worse. At this point his face may fall off onto the floor.

**Mel Pino**: )ou guys ARE violating civil rights. You just don't hear about it now. They keep it quiet. That jail is an absolute nightmare and that is what lumon was trying to get on the agenda. 

**Mel Pino**: You guys are going to be in serious trouble when Biden get hold of the DOJ again and that settlement agreement is enforceable.

**Mel Pino**: And bullshit Edler spent a bunch of time there. Give me a fucking break he is so whipped.

**Mel Pino**: How about the act of refusing medical care.

**Mel Pino**: Hahaha yeah as if they are gonna give that number

**Mel Pino**: Maybe you guys will have some idea when I get back my public records request on all of Alisons outside council during her tenure.

### CONVERSATION ON 12-11-2020

**Mel Pino**: Hey no need to call back just hope you listen to my message

**Jeff Bergosh**: Will do in meetings

**Mel Pino**: Ken Canady just died of covid. Twenty five years at the county I think...I know he was nearing retirement. Engineering. I remember him getting a proclamation a couple of years ago? He had been on ventilator but they removed him from life support earlier this morning

**Mel Pino**: I just found out from someone else in engineering that there is another member of the Department home with covid but they are making his wife come in to work at the county

**Jeff Bergosh**: That's horrible news.  I'll be keeping them in my prayers Mel.  I listened to your message thanks for the kind words.  Been a long week and I'm still in my office working-- two key team members out.  Have a great weekend.

### CONVERSATION ON 12-14-2020

**Mel Pino**: On phone with JJ will call back

**Mel Pino**: Omg Kevin has been punching out a response and it's fucking brilliant hahaha

**Jeff Bergosh**: 👍

**Mel Pino**: He is blasting wah harder than I was planning on doing and calling dpZ out for their fail at the city CRA that Doug then crammed into Brownsville for another pay hahaha

**Mel Pino**: Check Kevin's comment on Rick's blog

**Jeff Bergosh**: Will do

### CONVERSATION ON 12-17-2020

**Mel Pino**: Gilley plus Robert equals Gilbert.

**Mel Pino**: Jeff you really ought to at least consider limiting the responses to your blog to ones that respond to your blog. That single anonymous poster is really bringing down the value of the comments section with all that unrelated gibberish and random linking on the same conspiracy theories over and over.

**Mel Pino**: I don't care what party a person is or where their political loyalties lie. NO elected or appointed officer should be down with this criminal neglect of public records requests. On top of that clear illegality, his reason for wanting them hidden is even worse. I say these things not to rub it in, but because people have challenged my credibility on this type of thing repeatedly and Robert did it from the dais. And I don't quit when somebody challenges my word.

https://www.orlandosentinel.com/coronavirus/os-ne-coronavirus-task-force-report-partial-release-20201216-c7jwhuchpvboljkwrbcn2uu7bi-story.html

**Mel Pino**: And you know who is putting that rumor out double overtime.

### CONVERSATION ON 12-18-2020

**Mel Pino**: Posted

**Mel Pino**: Oh and one part I left out...fuck their public records that can't be dessiminated. So sick of that shit. I don't know why you put up with it.

**Mel Pino**: I'm not going to play their game and ask for it

**Mel Pino**: There was always going to be this, but how bad it will be and the horrible press around it is squarely on Janice Gilley. First sitting on the initial funds, stalling out to box you guys in, no backup or transparency, never listening to anybody who could give her a reality check. The worst kind of political tyrant. And unfortunately you guys just passed through most of her garbage plan and that could get visited on you badly in the coming months. :( I hope not because I am still hoping to God that some miracle will save us from a horrible eviction scenario here. But the poor cops will be forced to be the face of this on the news and Janice has put them in that position WAY too early.

https://ricksblog.biz/pensacola-eviction-makes-national-news-thank-judge-kinsey/

**Jeff Bergosh**: In mtg

**Mel Pino**: No worries left a message for you to hear

**Mel Pino**: I am going to forward you some texts I have gotten. These are from two different people with intimate knowledge.

**Mel Pino**: Just read Bergosh blog and your commentary. Agree 200% with you. Also wanted to bring to your attention again that it was Craig ammons that was/is edler's right hand man on the fire side. He was heavily involved in our accusations as well as offering his advice to her on ems Qa stuff. I would t be surprised at all if he was involved in sweeping the volunteer ff fatality under the carpet. Just my opinion. 

**Mel Pino**: If anyone is part of the "good old boy" club, it's Craig ammons. 

**Mel Pino**: Agree and don't know why. He is a terrible paramedic, lazy employee. He is supposed to be the training and safety officer however offers absolutely no training opportunities to his staff. 

**Mel Pino**: How have they not fired Ammons yet at this point 

**Mel Pino**: https://slate.com/news-and-politics/2020/12/florida-covid-data-whistleblower-ron-desantis.html

**Mel Pino**: Disaster. And Maddrey going to ecso

**Mel Pino**: Some say applied others say done deal I say that won't keep me from trying to expose him for what he is.

### CONVERSATION ON 12-19-2020

**Mel Pino**: https://www.nytimes.com/interactive/2020/us/covid-hospitals-near-you.html

**Mel Pino**: Baptist and UWF at 98 percent capacity unless they instituted their surge plans which in some cases swallows up whole floors to covid. And of course capacity does not touch on the number of nurses.

**Mel Pino**: Sorry west Florida auto correct

**Mel Pino**: About ten bus drivers, a mechanic. And a supervisor have covid. 

**Mel Pino**: Fyi those may be total counts. Two new bus drivers and one in hospital

**Mel Pino**: Confirmed one bus driver in hospital with covid working on confirming second bus driver in hospital and now and working on confirming third driver with covid.

**Jeff Bergosh**: That's terrible I'll keep them in my prayers!

**Mel Pino**: So I guess other than praying the plan is to just keep ignoring it when county staff get infected, sick, and even die and how convenient there's no meeting now until January. Or you could call a special meeting and the bocc could wake up and demand Janice quit with the covid denying and start protecting staff. And maybe recognize the people who have died like Ken Canady instead of acting like they died in shame nameless like dogs.

**Mel Pino**: Because if that's the plan Jeff that's no plan.

### CONVERSATION ON 01-07-2021

**Mel Pino**: Jeff what project are they talking about so I can post the article and say you are correcting it

**Jeff Bergosh**: Paying the 236 residents who were told they were approved for $3000 in CARES money

**Jeff Bergosh**: ....... but who were subsequently told there was no money left

**Mel Pino**: Jesus.

**Mel Pino**: Of course they interviewed somebody from your district

**Jeff Bergosh**: Yeah it was a cluster

**Mel Pino**: This is going to be a very long year.

**Mel Pino**: Look at the dashboard for cases. Thats not my phone they do this suit all the time. The county's dashboard is crap and a source of disinformation.

**Jeff Bergosh**: Not true

**Mel Pino**: Oh please Jeff. Everybody knows the county dashboard is suit.

**Mel Pino**: Shit

**Mel Pino**: One of the biggest sources of Covid downplaying information in the area..And honestly Jeff I don't mean this to sound catty because that's not the intention. But yu have no idea what has been going on the last week.

**Mel Pino**: They are vaccinating sacred donors

**Mel Pino**: The surveymonkey was a smokescreen. 

**Mel Pino**: Etc.

**Jeff Bergosh**: I don't disagree with that.  

**Mel Pino**: That's why Steven is hammering on this.

**Jeff Bergosh**: I'm going to hammer the exclusive $3.5Million deal with Sacred Heart

**Mel Pino**: He knows what they've been doing. Btw you were a rock star on that fucking sole source contract and I'm putting Roberts shenanigans with trying to shut you guys up in Lights.

**Mel Pino**: He is such a shill

**Mel Pino**: Yes,  you might go down 1 3 but it's the right thing and people are PISSED

**Mel Pino**: Remember Robert spent the day with DeSantis and Janice is feeding him his talking points.

**Mel Pino**: Steven is driving at it without coming out and saying it

**Mel Pino**: Btw that vote was a guess I of course have no idea. But there hasn't been a vote against a sole source contract since Janice came to the county

**Jeff Bergosh**: There will be tonight

**Mel Pino**: Oh duh this is agenda review

**Mel Pino**: They are literally making the argument that a sole provider will mean greater volume.

**Mel Pino**: At least he just admitted this state is in total chaos.

**Mel Pino**: I have a source in Administration at sacred who has said they are picking who gets it for different goals. There is no official wait list.

**Mel Pino**: Apples and oranges he is so full of crap

**Mel Pino**: Please. That's why it's 3.5 mil

**Mel Pino**: The reason Lumon keeps mentioning pharmacies was that DeSantis cut off our testing for four and a half days except at pharmacies. Just so you know what that's about

**Mel Pino**: Look at Alison texting so she can try to find a legal argument to sole source this

**Mel Pino**: THANK YOU

**Mel Pino**: She did not just do that

**Mel Pino**: See? He just slipped up with the truth

**Mel Pino**: Of course they didn't pick that number out of the sky. It was set for a sole source contract

**Mel Pino**: Who have Janice and Alison been texting with during this conversation? Shouldnt hey be taking direction from their board rather than outside interests?

**Mel Pino**: Well that solves that mystery. Well done Jeff.

**Jeff Bergosh**: Thx

**Mel Pino**: He's so right it is a horrible project that Doug cooked up for professional boat captains

**Mel Pino**: This asshole. Doug's emissary.

**Mel Pino**: And this si exactly why I was a horrible idea to let Navy federal pay for the master planning.

**Mel Pino**: Jesus that woman is tone deaf.

**Mel Pino**: How in the he'll are yu guys supposed to decide lake Charlene without Doug there.

**Mel Pino**: Are you guys going to vote on this?

**Mel Pino**: What????????

**Mel Pino**: And you guys will still have liability for the lake?

**Mel Pino**: Because you guys have to decide whether you want to own the liability for that lake

**Mel Pino**: Nine runoff pipes already.

**Mel Pino**: Nothing but him during wasting people's time

**Mel Pino**: Wearing red is support of Doug who doesn't even support the project after he got all this riled up again.

**Mel Pino**: All the homes that flooded after Sally will still Flood with this project.

**Mel Pino**: Her house will still Flood with this project. She admitted that in print in the PNJ

**Mel Pino**: They will do this again. If the project goes they will still have houses flooding. 

**Mel Pino**: This is very sad but does not change the circumstances. Her house will still Flood in all likelihood. 

**Mel Pino**: It has nowhere to go because Doug tells them not to clean the culvert.

**Mel Pino**: How do they think they will keep it at that leve?

**Mel Pino**: According to Chris Curb Doug is lying about some of the FEMA parameters

**Mel Pino**: Chris was the one working on trying to get the money back and they fired him for sending a draft email addressed to Dean and creating public record doing it.

**Mel Pino**: Doug wouldnt accept that easement so Alison wouldn't take it. He went online and told the neighborhood that he would do the project if Dean wrote him a letter accepting his previous esement. He finally pretended to accept this one. You can see how much he cares about the project. The point is to torture that neighborhood.

**Mel Pino**: So basically she wouldn't take the easement before and this liability is even MORE because you are guaranteeing four things

**Mel Pino**: Yep that's what's going on. Doug knew it would never pass.

**Mel Pino**: Well he got what he wanted. He has destroyed relationships in the neighborhood and wasted all your time. He is probably watching this laughing.

**Mel Pino**: It keeps the lake from overflowing but it can't keep it from drying up

**Mel Pino**: Because it would have impacted the sea walls with the lower level

**Mel Pino**: It's a CRAP project we weren't lying

**Mel Pino**: Thats going to cost them even more money! Not knowing if you guys are going to vote for it!

**Mel Pino**: This is just ridiculous.

**Mel Pino**: Hahahahahahahahahahahahahahaha

**Mel Pino**: And he will. And you guys will have to hear this suit four a FOURTH time.

**Mel Pino**: We lost a 25 year employee of the county and the only person who had the slightest idea of Stormwater over that bullshit. 

**Mel Pino**: the county is in total disarray and dysfunction under Janice. It is a God awful mess. I haven't been exaggerating. Staff can't function within the chaos. It is horrible and the longer it goes on the worse it's going to get.

**Mel Pino**: He clearly said that all 4000 were pending more documents. More than once.

**Mel Pino**: Janice has "one other topic." Uh oh.

**Mel Pino**: It's only going to get worse as long as she is there. This is going from bad to worse. Its horrible

**Mel Pino**: She's trying to learn the difference between pending and approved? 

### CONVERSATION ON 01-09-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Listen to my voicemail when you can. I just released the names of the for chief candidates publiclym

**Mel Pino**: Boy are they going on this. Any way to find out?

**Mel Pino**: He is obviously putting out OPSEC orders

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I'll talk to you next week about this garbage.  I don't need you to send me screen shots of that shit site that I purposely don't visit Mel. Thanks!

### CONVERSATION ON 01-11-2021

**Jeff Bergosh**: In mtg will call back

**Mel Pino**: Please listen to voicemail if u have time before

**Mel Pino**: Jeff do you have 5 more minutes? Kind of important I promise not to keep you.

**Mel Pino**: I just sent out an email on ems staffing. Found out as soon as I posted that they were holding calls all day long today. Not surprisingly.

### CONVERSATION ON 01-12-2021

**Mel Pino**: Fred Levin has passed from Covid.

### CONVERSATION ON 01-13-2021

**Mel Pino**: Call me after TPO if you can.

### CONVERSATION ON 01-14-2021

**Mel Pino**: Jeff I am really hoping that you might make a statement during the insurance item that the you guys and the public deserve to be informed in an honest way what the he'll is going on in our Ems staffing and scheduling

**Mel Pino**: Has the board been briefed on the Selover suit lately?

**Mel Pino**: Thank you Jeff. People need to understand how many people are walking around spreading this who have no clue they have it.

**Mel Pino**: Please note that Doug has the majority of RESTORE POT 1 either in his district or in his interest. I don't lie about these things.

**Mel Pino**: On the priority list he just got off quick.

**Mel Pino**: Of course they are dragging on that.

**Mel Pino**: And here we go with another round of gaming the commission pretending they don't know what's going on.

**Mel Pino**: And there you have it.

**Mel Pino**: I tried to warn you about this.

**Mel Pino**: I have been screaming it from the rooftops for two years that your staff is playing so fast and lose with their grants and money moving that they were going to lock down on the county. I tried to want you again about that after hurrican Sally. Again I don't lie jeff, I don't make things up and I don't exaggerate.

**Mel Pino**: She is dragging this county down the toilet and every meeting it manages to get incredibly worse.

**Mel Pino**: Jeff this is really important and of course she doesn't have the slides in the backup that I can find. Do you have it available electronically? If so can you send?

**Mel Pino**: With the irony being this discussion is happening on the county taking on more responsibility for managing connectivity when her staff isn't even capable of taking a Tuesday backup in time to be functional for a Thursday meeting. Which also means that backup was two days late.

**Mel Pino**: I am SO glad that you are getting this solution but damn you better make sure she doesn't mess this up along with everything else.

**Mel Pino**: Gee, backup. What a novel idea.

**Mel Pino**: Hes not going to stand in your way he will just continue to be the biggest pain in the ass possible.

**Mel Pino**: Great so now Janice is going to lobby to blow a delegation ask on continuing to build her massive bureaucracy. 

**Mel Pino**: Thank you. Was this a sole source contact?

**Mel Pino**: Just on principle not saying anYthing bad about the company.

**Mel Pino**: Holy crap did she just get busted for setting up her biggest sole source yet that might have impacted who ultimately gets the contract? Because that is certainly what that sounded like. Of course without backup it's impossible 

**Mel Pino**: Jeff can you talk for five more SUPER SUPER important!!

### CONVERSATION ON 01-16-2021

**Mel Pino**: Check county attorney agenda

### CONVERSATION ON 01-18-2021

**Mel Pino**: https://www.pnj.com/story/news/2021/01/18/lake-charlene-residents-hope-escambia-county-approve-long-delayed-flood-project/4176062001/

**Mel Pino**: Read carefully how Alison has gotten herself positioned for Doug with "negotiating" with will as if she isn't your attorney. Ad they are going to continue to protect Doug and go to bat for him because they need him for the redistricting. 

**Mel Pino**: He has got you guys right where he wants you with the help of your Administrator and attorney once again. And it will not stop until you stop appeasing him and your direct reports stop working against the rest of the board for him. 

### CONVERSATION ON 01-19-2021

**Mel Pino**: Interesting Florida west meeting.

**Mel Pino**: Have Alison and Janice let you know yet that they are aware Doug is probably going to bring lake Charlene as an add on Thursday morning?

### CONVERSATION ON 01-20-2021

**Mel Pino**: So they switched it up to Fire Me Monday and they also fired Regina Hall in budget. 

**Mel Pino**: He 

**Mel Pino**: The are going to continue to tag you on a bunch of their shit. 

### CONVERSATION ON 01-21-2021

**Mel Pino**: There is a huge line of people out here o sign up for speaking and the line isn't moving at all.

**Mel Pino**: Here's the open trench the county put in. The woman who spoke lives right near this mess.

**Mel Pino**: He just openly invited a lawsuit onto the county.

**Mel Pino**: So you are willing to be sued the next flood

**Mel Pino**: Because THAT is what he is setting up. A lawsuit. On purpose.

**Mel Pino**: He is intentionally setting up a lawsuit on the board.

**Mel Pino**: So they come back and you are going to vote for a lawsuit. 

**Mel Pino**: And their houses will still flood with this project.

**Mel Pino**: Ask about doing the project up north.

**Mel Pino**: THAT is the only thing that will help the flooding is to divert the water.

**Mel Pino**: They just did Doug a solid and killed the feed.

**Mel Pino**: THIS PROJECT WILL NOT SOLVE THE HOUSES THAT FLOOD NOW. They will ALL still flood, and the 75 it will "Help" is ONLY for a one hundred year flood.

**Mel Pino**: So you guys can use CARES for broadband but not cameras for cops.

**Mel Pino**: Jeff if you push this and allow Doug to continue that process it wil be to absolutely no purpose except to let him continue to rip that neighborhood to shreds.

**Mel Pino**: He is trying to drain the coffers of the HOA board with legal fees as it is. Will is 350 dollars an hour so he is loving that you left because it just cost the board another 950 dollars.

**Mel Pino**: Fyi they are also calling old numbers in their hospital database. I got one from the previous owner of my 850 number and a friend had the same thing happen. 

**Mel Pino**: Hahahahahahahahahahahahahaa

**Jeff Bergosh**: 👍

**Mel Pino**: Gee looks like Robert got a talking to for not supporting Doug.

**Mel Pino**: So if they vote for it you guys are going to vote to take on a lawsuit.

**Mel Pino**: Except that other county projects don't guarantee in the easement that the county will keep the lake at a certain level. Which is impossioble

**Mel Pino**: Joy doesn't care. She'll be retired after decimating our engineering department.

**Mel Pino**: Congrats if they pass this I would expect a lawsuit in two years.

**Mel Pino**: Says one of the most hard core Qers in Escambia county.

**Mel Pino**: And he only cost us 220k and running on not throwing that suit out with the help of your county administrator.

**Mel Pino**: This is on ECW on JAR's post about the meeting today. 

Commissioner Doug Underhill - Additionally, we were making some progress toward night-time access, which would require a huge trust fall on the part of the Feds. Of course, when Bergosh and Downs and all those folks started talking about having a big, loud night-time party and dragging their coolers across the habitat the Feds pulled back on that discussion. Can you blame them? The more we talk with contempt about the "Beach Rat" and other environmental issues, the less the Feds will consider the locals a good partner in stewardship.  "Judge the tree by the fruit"...how much good fruit have we harvested with regard to beach access since the Pino crowd got involved?

### CONVERSATION ON 01-22-2021

**Mel Pino**: I commented here:

https://ricksblog.biz/pensacola-msa-where-covid-19-growing-fastest-in-florida/

**Mel Pino**: Congress just reintroduced a constitutional amendment to overturn Citizens United. Wow. 
https://www.rawstory.com/citizens-united/

### CONVERSATION ON 01-23-2021

**Mel Pino**: https://ricksblog.biz/nyt-covid-case-tracker-escambia-cases-extremely-high/

### CONVERSATION ON 01-24-2021

**Mel Pino**: The FDEM Grant for lake Charlene with the county as sub recipient will not be reinstated before it gets brought to the board, it I understand it right. Chris Curb was working on getting it reinstated whether fired him. He has tried to help them even though they fired him. So yes Fdem is still holding the money but until the successful letter goes in making the case to reinstate the grant is not officially back on. For example the Delano object has been in for a year with no approval. Even once FDEM agrees to open the grant back up....and maybe they have gotten this but nobody will produce the doc...the grant is not there. Once it is there, the county pays up front and gets reimbursed quarterly. Hazard mitigation grant program. A type of grant where the county has to got through FDEM can't connect directly with FEMA. The county will have to front load the money and then trust that they get it from Fdem, who is holding it, in a timely fashion.

**Mel Pino**: Somebody claiming to be Marcus stern is calling around digging on county projects and claiming to work for floodtrends and encouraging people to sue the county.

**Mel Pino**: Says he is "retired and working for somebody."

### CONVERSATION ON 01-25-2021

**Mel Pino**: https://www.pnj.com/story/news/2021/01/25/escambia-county-job-going-hiring-spree-needs-public-safety-employees/6673801002/?utm_source=pnj-Daily%20Briefing&utm_medium=email&utm_campaign=daily_briefing&utm_term=list_article_headline

**Mel Pino**: https://ricksblog.biz/fdle-releases-report-on-eavesdropping-of-county-offices/

**Mel Pino**: Read the first sentence of that report again, linked at the bottom.

**Mel Pino**: I'm not making up cloak and dagger stuff to entertain myself.

**Mel Pino**: Hahahaha I posted to your blog

**Mel Pino**: PNJ article making clear she informed them. In the wear article also it's clear she called them.

https://www.pnj.com/story/news/2020/12/01/escambia-county-administrators-office-illegally-bugged-earlier-year/3783517001/

### CONVERSATION ON 01-26-2021

**Mel Pino**: I would be grateful if you would check email when you have time for comments on the selection process for the new fire chief.

**Jeff Bergosh**: Doug is getting savaged by the comments on the PNJ Facebook site.  Ouch!

**Mel Pino**: Hahahaha read the comments on the fern

**Mel Pino**: Yep I got a couple in there.

**Jeff Bergosh**: Nice

**Mel Pino**: One positive comment. One. 

**Jeff Bergosh**: LOL

### CONVERSATION ON 01-27-2021

**Mel Pino**: Hahahaha Fred came on to ECW and put it in jacquelines face. That's the problem when you serve too many political masters. Poor girl loses track of sho she is supposed to be shilling for.

### CONVERSATION ON 01-28-2021

**Mel Pino**: Omg two deaths on the mcat board and one was Bonita player :(

**Jeff Bergosh**: Will call u back

**Mel Pino**: Tried leaving u a message. Check the email u got on cat per your appointment

### CONVERSATION ON 01-29-2021

**Mel Pino**: Tried to leave a message it deleted. Found out what everybodys favorite aide is after.

**Mel Pino**: SRIA

### CONVERSATION ON 01-31-2021

**Mel Pino**: https://mobile.twitter.com/jonathanturley/status/1355333442884562945?prefetchtimestamp=1612058237600

**Jeff Bergosh**: What should the rat's caption say?

**Mel Pino**: Hahaha 🤣

**Mel Pino**: Give us a minute

**Mel Pino**: Check my post on my Facebook. I also posted in willies and over on the pnj

**Jeff Bergosh**: Should I put a big "Q" on the podium as well?

**Mel Pino**: YES

**Mel Pino**: Ok gonna throw some things out

**Mel Pino**: "MORE THAN COMMERCE PARK"

**Mel Pino**: "Sidewalks to Nowhere"

**Mel Pino**: "The same rules for everybody all the time" that one Jeff 

**Mel Pino**: Doug's slogan that he was mouthing off on during the WEAR

**Mel Pino**: Either that or "The truth is the greatest act of respect"

**Mel Pino**: Please please make the rat speak one of Doug's truth slogans one of those 2

**Mel Pino**: Make two bubbles and put them both in

**Jeff Bergosh**: Ok

**Mel Pino**: He ha been blathering those two all over ALSO check out his Facebook post

**Mel Pino**: "I always take responsibility for what I say and do"

**Mel Pino**: Any combo of those three

**Jeff Bergosh**: Okay thx

**Mel Pino**: Wait look at his first line in that post also

**Mel Pino**: "A rare excellent editorial by the PNJ!" Hahahaha

**Mel Pino**: Doug wrote that shit haha

**Jeff Bergosh**: He's a fucking tool

**Mel Pino**: He's downtowns fucking tool. Always has been from the start.

**Mel Pino**: Kevin suggested "you can knock me down but make sure you give me a reach around"

**Mel Pino**: JUST KIDDING

**Mel Pino**: Oh my god they will murder you on the Swearword!! Don't do it hahaha I'm serious

**Mel Pino**: Put one of Doug's slogans in the rats mouth because they use them all the time over on ecw

**Mel Pino**: Love the Q and the patron arm!

**Mel Pino**: DOH are you really ready for that war??

**Mel Pino**: On the Q one that's like the atomic bomb haha

**Mel Pino**: Third one on Royal decree best I like the sir

**Mel Pino**: "Sire I have assembled the Main Street media to pay their homage"

**Mel Pino**: "To pay their due homage"

**Mel Pino**: Damn what's a Q word for Sire

**Mel Pino**: Hey you could use the bread bakers and breadcrumbs motif from Qanon

**Mel Pino**: "Hear Ye the Baker speak...and here are your breadcrumbs"

**Jeff Bergosh**: LOL

**Mel Pino**: "Your overlord speaks just follow the bread crumbs"

**Mel Pino**: Then put crumbs around the rat or to something funny in the background 

**Mel Pino**: Put the slogan in one line up top then put bread crumbs from the podium leading back to a line of ticky tack houses right on top of each other receding into the background or just all across the background in a row

**Mel Pino**: Oh shit Jeff "your prophet speaks just follow the bread crumbs"

**Mel Pino**: Property is a big thing in Q

**Mel Pino**: LOVE except I would kill baker unless you want that in joke for Qers that will piss them off. I love it because it shows you know what the he'll is up

**Jeff Bergosh**: Okay I think I've got a final.......

**Mel Pino**: Oh no don't kill the prophet and breadcrumbs!

**Jeff Bergosh**: Maybe I'll do them side by side in a series

**Jeff Bergosh**: 😎

**Mel Pino**: Listen the PNJ needs to sit the fuck down on him. Their first slot is on that crazy fucking Qer spouting her hate speech and the next is them beating up the board for not allowing Doug to run at the mouth

**Mel Pino**: They are fucking hypocrites and they will HATE getting that breadcrumb stuff shoved in their faces

**Mel Pino**: Combine the 2

**Mel Pino**: "Sire of have assembled the Main Street media to follow your breadcrumbs"

**Mel Pino**: John Peacock is the one going around for downtown on the combined city county charter with city in control.

### CONVERSATION ON 02-01-2021

**Jeff Bergosh**: https://ricksblog.biz/poll-voters-want-jobs-at-olf-8/

**Mel Pino**: I commented here:

https://ricksblog.biz/one-point-about-pnj-1-31-editorial/

**Mel Pino**: He just got home...went all day

### CONVERSATION ON 02-02-2021

**Mel Pino**: Studio 850 has the administrative order on the ag lands at the cabinet meeting

**Mel Pino**: Escambia county comp plan is not in compliance

**Mel Pino**: Recommended order being addressed. Amends comp plan by deleting the county's policy of deleting new rural lands. 

**Mel Pino**: (You are probably aware of this I haven't been following as closely)

**Mel Pino**: They ALJ has pretty broad scope. The county did not file any exceptions to the ALJ's findings of fact which were due in 15 days. No data or analysis etc. I think all this is retread?

**Mel Pino**: Approve option number 1. Love to adopt by majority vote.Plan not in compliance and specifies remedial action. Does not prevent from reaching by using appropriate data. No sanctions.

**Mel Pino**: Oh Lord kia is arguing Horace testimony should stand as data. Basically protesting the decision

**Mel Pino**: Asking them to set aside the ALJ hearing and finding it is in compliance

**Mel Pino**: Jacqueline up

**Mel Pino**: "We have an established Midwest sector plan"

### CONVERSATION ON 02-03-2021

**Jeff Bergosh**: Freudian Double Entendre 😂😂😂

**Mel Pino**: http://www.northescambia.com/2021/02/escambia-county-starting-over-in-search-for-fire-chief-rejecting-four-finalists

**Mel Pino**: Every once in a while. :)

**Mel Pino**: What a mess.

**Mel Pino**: They put a Q by his name  hahahahah

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Its not that important

**Mel Pino**: She isn't just sliding add on there is content being piecemeal up all the time. Impossible to keep track now

**Mel Pino**: Of course the federal government is working around DeSantis bullshit. They have to to get people vaccinated.

**Mel Pino**: Why is that PowerPoint slide not front and center on the county website?? Why isn't it up on Billboard's?

**Mel Pino**: Maybe it is and I'm not aware but the dashboard has been a jumbled disaster latery. Maybe our communications department could handle a static image

**Mel Pino**: So it's just our dipshit Ring contingency. Got it.

**Mel Pino**: Q

**Mel Pino**: My but there are a lot of one bids at the county these days. I'll be speaking to that tonight.

**Mel Pino**: Emergency my ass and this will continue as long as Janice has broad executive power with the state's of emergency. She is the worst back door culprit I have encountered in my time of paying attention to county politics.

**Mel Pino**: I honestly cannot understand why you guys continue to allow her to do this.

**Mel Pino**: "Having just gotten this." How convenient. Over and over.

**Mel Pino**: What is he going to talk to the clerk about. And why isn't the board party to it

**Mel Pino**: This type of situation is exactly why that third Thursday needs to be split back up with an official agenda review. However much it can work to the boards favor it can really put the board in a bad position also.

**Mel Pino**: Thank God it's a fucking wreck.

**Mel Pino**: Hahahahahahahahahahaha

**Mel Pino**: Oh I just can't wait

**Mel Pino**: So how much are we on the hook for beyond the discretionary? Btw NOBODY knew this was coming except Doug's cronies

**Mel Pino**: WTF. Why not get the extension just in case? What am I not understanding?

**Mel Pino**: Is there a downside to applying for the extension? That's an honest question.

**Mel Pino**: She is so unprofessional and it is embarrassing how she addresses the board. What's with the fucking attitude.

**Mel Pino**: I am so tired of watching these division leads act like they are put out when the board asks questions or gaming you guys so they don't have to answer

**Mel Pino**: Left you a message about that solar windmill

**Jeff Bergosh**: Tried calling

**Mel Pino**: Tag just tried

**Mel Pino**: It's just this. BUT guess what. It requires another 25k that will not have to come before the board.

**Mel Pino**: Which puts staff in a bad place.

**Mel Pino**: Posted the response William blocked on northescambia to your blog. Two parter.

**Jeff Bergosh**: 👍

**Mel Pino**: Sincere thanks for allowing a long response. Fyi I don't care when people roll on me there or anywhere. It gives me a chance to reply. The only thing that bums me out in the commentary on your blog is when people post pure outright Q drivel disinformation in random shotgun fashion.

**Mel Pino**: And now a taste of Miami.

**Mel Pino**: William Jennings Bryant Jr.

**Mel Pino**: Comps hahahaha

**Mel Pino**: Jeff call me so I can explain

**Mel Pino**: Please

**Jeff Bergosh**: Will do

**Mel Pino**: Nope good

**Mel Pino**: That was the last item. I needed to explain it better.

**Mel Pino**: So fyi no Doug gets staff to have to come up with 25k behind the scenes for that windmill project.

**Mel Pino**: Told ya hahahha

**Mel Pino**: Some day you'll believe me haha

### CONVERSATION ON 02-05-2021

**Mel Pino**: Jeff when you have twenty minutes PLEASE watch the video from that item last night. Please, it's worth the time. It's the 2:05:30 Mark. And keep in mind that that single item is the tip of the iceberg on what she has been running. I haven't even started on the debris removal in earnest yet. She will bring the board to grief and cannot be allowed to run on like this.

**Mel Pino**: https://www.pnj.com/story/opinion/2021/02/05/marlette-black-eyes-and-brown-noses-princes-pensacola-politics/4385275001/

**Jeff Bergosh**: I saw it

**Jeff Bergosh**: But seriously when will it be time for the cartoons of Biden and AOC?

**Mel Pino**: Hahahahahaha my friend Charlotte Paddock is Charlotte edwards

**Mel Pino**: Who cares these two are such tools I'm just enjoying the moment. 

**Mel Pino**: Looks like they are lining things up for DC

**Mel Pino**: Reeves

**Jeff Bergosh**: I've heard that rumor

**Jeff Bergosh**: That would be a tough race for DC----definitely NOT a lock.  In fact, I believe DC will not run precisely because of the fact that Andrade will be well funded and hard to beat!

**Mel Pino**: Well DC would have on his side that Alex is a prick and nobody can stand him.

**Jeff Bergosh**: I don't necessarily agree with that, but even if true it doesn't guarantee victory for a challenger.  Even a well-funded one.  Look no further than Doug's victory over McMillan

**Mel Pino**: I just got an email from Janice that you guys voted the money in last meeting. What the HELL. On the beach haven

**Mel Pino**: Please check email. She is throwing you guys under the bus.

### CONVERSATION ON 02-07-2021

**Mel Pino**: Posted to your blog

### CONVERSATION ON 02-08-2021

**Mel Pino**: This ought to be good.

**Mel Pino**: Posed to your blog.

**Mel Pino**: Hahahaha omg this great they are of course trying to land it in your lap and Chester has asked people to call and report it to you haha good old Chester.

**Jeff Bergosh**: LOL

**Mel Pino**: OMG you have to see the email sherri Meyers sent you DONT miss the photos or the owner hahaha

**Jeff Bergosh**: Saw it 

**Mel Pino**: Those photos🤣🤣 I also sent Doug a follow-up on his beach haven project.

### CONVERSATION ON 02-09-2021

**Mel Pino**: Call me when u can for an update.

**Mel Pino**: Also I posted to your homeless blog

**Jeff Bergosh**: I'm adding the update to that rn

**Jeff Bergosh**: Then he dumped it on the road like a hot rock.  No good deed goes unpunished

**Mel Pino**: Thats awesome. This is all kinda in random order...please don't let your guard down Covid we aren't out of it yet

https://www.washingtonpost.com/opinions/virus-variants-urgent-vaccine-rollout/2021/02/08/f0828ffe-67e5-11eb-8c64-9595888caa15_story.html

**Mel Pino**: Well Jeff no truer sign than he is clearly mentally ill and we have no resources to deal with it. And it's epidemic right now between that and substance abuse. You know that substance abuse is often an attempt to self medicate mental issues and numb out.

**Mel Pino**: So remember that whenyou do your update that guys is probably in need of serious mental help. Don't assume he dumped out the lunch because he is fat and happy for the day. Sounds schizophrenic.

**Mel Pino**: https://www.washingtonpost.com/opinions/virus-variants-urgent-vaccine-rollout/2021/02/08/f0828ffe-67e5-11eb-8c64-9595888caa15_story.html

**Mel Pino**: Sorry I don't know how that sent again.

**Mel Pino**: Please don't let your guard down Covid we aren't out of it yet. And that chambers is just as big a problem with recirculated air as we figured it might be.

https://www.washingtonpost.com/opinions/virus-variants-urgent-vaccine-rollout/2021/02/08/f0828ffe-67e5-11eb-8c64-9595888caa15_story.html

**Mel Pino**: Oh my god okay that one was my bad. I was trying to send that to David in advance of TDC today...good grief sorry

**Mel Pino**: I not taking my mask off to speak any more with this higher contagion variant.

**Mel Pino**: They lied to you. Paul was only one year into the drop. I tell you the are hardened fucking liars and ol-ng you every day.

**Mel Pino**: Also they lied about the backup period. Contractor named in the backup on Jan 21 there was no fucking blackout in play last meeting nor were they going to bring it at the next meeting. They had already slid it through on you.

**Mel Pino**: And Paul had four years to go on his drop and they are blaming him for me getting the documents that SHOULD BE PUBLIC. RECORD ANYWAY. Because the vendor WAS ALREADY ON THE. AGENDA. They are fucking liars and are really going to fuck you guys up if they are allowed to run on like this.

**Mel Pino**: Thanks for the opening I made good use of it hahaha

**Jeff Bergosh**: LOL

### CONVERSATION ON 02-10-2021

**Jeff Bergosh**: I'm meeting 

**Jeff Bergosh**: Are there more?

**Mel Pino**: Yes go down the string.

**Mel Pino**: Sent you the link and Jeff you had better look what I have been laying down for the last hour

**Mel Pino**: I am unleashing some serious shit

**Mel Pino**: Check pm

**Jeff Bergosh**: Where,?what site? I don't go to hate watch site

**Mel Pino**: Sorry grabbed the wrong string

**Mel Pino**: Sent another link

**Mel Pino**: I'm not talking about eco I just fucking unleashed it ALL

**Mel Pino**: The first link I sent isn't it. Check the second link.

**Jeff Bergosh**: Look at Ricks Blog!!  Oh my God!!!!

**Mel Pino**: Check email

### CONVERSATION ON 02-11-2021

**Mel Pino**: Holy shit just got caught up on Ricks posts on olf8. Wow

**Mel Pino**: So whose team is your engineering dept on?

**Jeff Bergosh**: Exactly

**Mel Pino**: Fyi there is a pattern of joy Jones putting her on stuff to run for Doug.

**Mel Pino**: David forte was always running behind fixing her Doug games. She is the one who instructed staff to put curbs on Sava's driveway.

**Mel Pino**: Sent this to him: Doug why aren't you aren't you reading your emails?

**Mel Pino**: Who in the he'll are these names on this zoom call...some look fake. How did people get access to it?

**Mel Pino**: Are all those names real? Honest question I don't know.

**Mel Pino**: Okay I guess they are real. 

**Mel Pino**: "There's an immediate need for housing now." WOW

**Mel Pino**: Fyi

**Mel Pino**: What did Teresa Blackwell just hand to Janice?

**Mel Pino**: I just put in a public records request for whatever Teresa handed to Janice and cc'd the board.

**Mel Pino**: They are just relentless. They are never going to work for the Board it appears :(

**Mel Pino**: Hahahahahahahahahahahaha

**Mel Pino**: Key west/beulah

**Jeff Bergosh**: LOL

**Mel Pino**: Hahahahahahahaha

**Mel Pino**: Omg he is not.

**Mel Pino**: WOW.

**Mel Pino**: Robert and Doug aligned again.

**Mel Pino**: Fuck this.

**Mel Pino**: Dps should return the money. Cancel their contract and start over with another firm.

**Mel Pino**: Hahahahhahaaha

**Mel Pino**: Bring up him tanking the scores for The other firms

**Mel Pino**: Now you see why gene fired them.

**Mel Pino**: He just makes it worse.

**Mel Pino**: We badly need a diversification of our tax base. Way too tilted to tourism and healthcare.

**Mel Pino**: Who is "they" that Robert says "they don't want that."

**Mel Pino**: BAM. "They" are navy federal, dpz's rel client.

**Mel Pino**: Right. Don't create jobs because the jobs market is going to crash. Jesus

**Mel Pino**: BAM there is dpz's second client, civiccon.

**Mel Pino**: Somebody might want to say that our schools don't suck.

**Mel Pino**: Discussing whether to fire DPZ ought to be discussed.

**Mel Pino**: She just admitted they draw up plans before the charettes. They do it even time.

**Mel Pino**: Ask Doug whether DPZ had secret meetings with him and Joe mirabile.

**Mel Pino**: Before or after being a commissioner.

**Mel Pino**: Give me a fucking break.

**Mel Pino**: Studio 850 did a breaking thing on dps during the eeting

**Mel Pino**: Meeting

**Mel Pino**: Hey Jeff, I wouldn't bring that to janice's ethics department. They will cook up a bunch of reasons why that's all good. 

**Jeff Bergosh**: They won't be able to

**Jeff Bergosh**: These emails are too damning

**Mel Pino**: Well never underestimate the levels she and her hires will stoop to. Wouldn't surprise me if they handed off a pile of horseshit to you.

### CONVERSATION ON 02-13-2021

**Mel Pino**: Posted to your blog

**Mel Pino**: Oh shit over the limit I'll fix it

**Jeff Bergosh**: Okay

**Mel Pino**: Done

**Mel Pino**: Let me know if you don't get it I am having internet hiccups

**Mel Pino**: Hey I also gotta convey a few things on olf8. Calling you about that not my blog comment.

### CONVERSATION ON 02-14-2021

**Mel Pino**: Ignore this Jeff and I hope you and Sally have a fantastic Valentine's day. I just needed to get it to you so you saw it first thing tomorrow.

**Mel Pino**: https://weartv.com/news/local/rescue-teams-respond-to-fire-near-pine-forest-rd

**Mel Pino**: Pensacola energy

### CONVERSATION ON 02-15-2021

**Mel Pino**: Check my comment here:

https://ricksblog.biz/dpz-codesign-and-perdido-key-master-plan/

### CONVERSATION ON 02-16-2021

**Mel Pino**: Rick just posted the second part of the transcript. This is laying out everything in black and white. 

**Jeff Bergosh**: Too wordy

**Jeff Bergosh**: Will lose the reader quickly

**Mel Pino**: It's a transcript Jeff haha you don't get to pick what words go in. I think he's putting it up so savvy people can pluck quotes. You know, like you. :)

**Mel Pino**: https://ricksblog.biz/olf-8-questions-ideal-timeline-for-build-out/

**Jeff Bergosh**: Need you to send me your info so I can give Megan Walters the "gong" a la the old "Gong Show" starring Chuck Barris-- and put you in that committee

**Mel Pino**: Hahaahaha but that's not the committee. Megan Walters is on MCAT. I want on the Marine advisory committee please!

**Mel Pino**: You could put Michael Bearden back on the mcat after Doug fired him over beach access 4 haha

**Jeff Bergosh**: Oh, that's right.  Got it.  Do you have Michael's number?

**Mel Pino**: If you think it's okay to do two people from district 2? I was just joking didn't want to lead you to perdition with your constituency. But I don't know if you have a single d1 constituent who wants to sit MTAC

**Jeff Bergosh**: LOL thanks.  Nope- just want good people to sit on these committees

**Mel Pino**: He was so pissed off when Doug kicked him off.

**Jeff Bergosh**: I'll call him

**Mel Pino**: Awesome and I will get Debbie my CV for sitting the Mac. It's your female appointee from back in the days of Wilson that is such a pill and rubber stamps all dougs crap.

**Jeff Bergosh**: She's getting the hook-- along with Megan Walters.  A double

**Mel Pino**: Mary Watson is her name. Mark Moore is awesome.

**Jeff Bergosh**: 👍

**Mel Pino**: Mark has been trying to fight Doug's crap at galvez but she gives him no help.

**Mel Pino**: https://ricksblog.biz/dpz-question-2-how-much-land-for-commerce/

**Mel Pino**: Was the county billed for the meetings staff was blocked from? Maybe Scott luth was at all of them, but ten to one they billed you guys for meetings staff wasn't invited to. Not good.

**Mel Pino**: Did they charge for all half dozen people on all those zoom calls? What was the work product associated from the people who didn't speak?

**Mel Pino**: If there is too much financial shenanigans the county could technically force Dpz into an audit with an auditor of the county's choosing.

**Mel Pino**: Honestly, I don't know that there is a single person at the county who knows what the he'll they are doing when it really comes down to it.

### CONVERSATION ON 02-17-2021

**Mel Pino**: Jeff do you have to ratify your committee changes at a meeting? If so I'm gonna put the brakes on everything else I'm doing and finish up that CV...I'm working something special up. 

**Jeff Bergosh**: Yes.  Do u just want to shoot for first mtg in March?

**Jeff Bergosh**: That might make it cleaner/easier?

**Mel Pino**: If I get it done can you add it on tomorrow?

**Jeff Bergosh**: It's just that it's getting late in the day and Debbie is out at PT

**Mel Pino**: Check my comment here if you have time

https://ricksblog.biz/some-history-on-perdido-key-master-plan-and-dpz/

**Mel Pino**: Check PM and holy shit Rick is pulling out all the stops

### CONVERSATION ON 02-18-2021

**Mel Pino**: May not make it neighbors pump broke

**Mel Pino**: Jesus Jeff are you gonna let this bullshit on the morgue stand?

**Mel Pino**: Jeff also tack on a graffiti ordinance

**Mel Pino**: There is nothing that forces businesses to clean off graffiti per sherri email

**Mel Pino**: Oh Jesus trail cams you are supposed to be a conservative Jeff!!!!!

**Mel Pino**: NOOOOOOOOOOOOOOO

**Mel Pino**: Just fyi I will drag two dozen people down to that meeting to protest trail cams. HARD. Totally behind fines for later NO TRAIL CAMS HELL TO THE NO please rethink that

**Mel Pino**: I would fight that with lawyers in my park if I had to

**Mel Pino**: Total support for litter ordinance just he'll to the no on trail cams.

**Mel Pino**: This animal will have cameras all over our district HELL NO

**Mel Pino**: Everywhere but his own fucking back yard which is where they should be

**Mel Pino**: After that single vendor hel demo

**Mel Pino**: I honestly don't know how you sleep at night Robert. Worst display of shameless dirty politics I have seen in a long time. And dont think people don't see it. 

**Mel Pino**: Sent that after the vote and it's a damn good thing I'm not there because of would have stormed that podium and lost it on him.

**Mel Pino**: You have got to be kidding me.

**Mel Pino**: I don't trust that shit he just said about the apps farther than I can throw it

**Mel Pino**: Well isn't he just having himself a field day.

**Mel Pino**: The backup is February 11th. Guess we can see why Robert doesn't think there is anything wrong with the new system. This is ABSURD

**Mel Pino**: What in the FUCK

**Mel Pino**: I told you you couldn't trust him on this.

**Mel Pino**: This is how things are going to go from here on out if the rest of you don't put your foot down on this nonsense Doug Robert and Janice are running with the backup and offline conversations. If they can GE away with this they will get much, much worse.

**Mel Pino**: This should be kicked.

**Mel Pino**: You have got to be kidding me

**Mel Pino**: News journal reporting as if you accepted the Dpz plans today

**Jeff Bergosh**: Yeah they Didn't quite get the quote right

**Mel Pino**: Took it out of context completely. I left you follow up voicemail on that.

### CONVERSATION ON 02-20-2021

**Mel Pino**: Posted

**Mel Pino**: Check email for my response to John Peacock. 

**Mel Pino**: Jeff go on the ecw string and screen shot both the comment by Don givuhcrap/brian Caro and his thumb up on Doug's comment trashing the head of the pedc and send it to Janice and ask her why he isn't being disciplined for participating on a string trashing the commission

**Mel Pino**: On tinder. Somebody just sent this to me

**Mel Pino**: Yep there is is. Jacqueline dropped the charter. 🤣🤣 I tagged you guy on a post I made about it.

**Jeff Bergosh**: What a creep.  Is that him??

**Mel Pino**: Yup pretty sure. Kevin wants to post it to grinder but I won't let him

**Mel Pino**: Somebody who hates peacock saw me going back and forth with him and sent it to me haha

**Mel Pino**: I just sent out my last email on Janice. If people can't see what's going on now, they never will.

**Mel Pino**: Check email again. I also unloaded on Jacqueline for being part of the ems cover-up and posted it to Facebook.

### CONVERSATION ON 02-21-2021

**Mel Pino**: If u can't read that check the follow up comment I made on the Peacock crap on the PNJ website.

### CONVERSATION ON 02-22-2021

**Mel Pino**: Fyi the new eco post this morning is coming after your library

**Jeff Bergosh**: LOL too bad.  It's happening

**Mel Pino**: They are so hamfisted. Guess they missed that political lesson about keeping some powder dry.

**Mel Pino**: Posted on the library

### CONVERSATION ON 02-23-2021

**Mel Pino**: Grover just made another big combined charter move by having Ortiz the head of the Florida league of cities on his press conference.

**Mel Pino**: It dropped

**Mel Pino**: Jeff it was 3.5 of federal HUD CARES money so I guess it was okay that the money went straight to open doors/pathways rather than going through the BOCC first? That's is what they are saying. That the money came straight to them and didn't need BOCC approval.

**Mel Pino**: I had a good talk with Michael...he would love to come on the coffee but he said it would be good for you guys to talk first so you can find the points of agreement and focus on the stuff you agree on...better for both of you than debating stuff you don't agree on.

**Jeff Bergosh**: Fantastic will do and thank you Mel

**Mel Pino**: Ok got the specifics. This was stand alone state money that the COCs could apply for directly. The county couldn't apply to this one it had to be a COC. People are passed about the decisions they are making with the money but it did not circumvent the BOCC.

### CONVERSATION ON 02-24-2021

**Mel Pino**: 70 townhomes on the pre app dev review for rushing plat on navy point. Says notradamus. I think they slid it on.

**Mel Pino**: They are locking the door to the hall in central complex where the pre apps are held. 

### CONVERSATION ON 02-25-2021

**Mel Pino**: Jeff I am trying to give you room to turn around and rethink this one as it is looking really bad. I know you are just looking out for your brother but even judge danheiser came on to try to warn you that it looked bad. I gave you plenty of material to consider and turn around on.

**Jeff Bergosh**: I disagree with you

**Jeff Bergosh**: I have a different vantage point

**Mel Pino**: Hey fyi there were 3 arrests for homeless trespassing yesterday, 1 at the county and 2 at the city. Now just today the county had somebody else arrested :(

**Jeff Bergosh**: What were the circumstances?

**Mel Pino**: I don't know. Michael Kimberl posted about there were 3 yesterday and I asked county or city this round. He said 1 county 2 city but that the county had just arrested another on trespassing today. I used to believe I could get something done about that. One more thing I just gave up on. Throwing homeless people in prison during Covid.

**Jeff Bergosh**: Hey is the lady on MAC Mary Watson?

**Mel Pino**: To be technical, the county is enforcing trespassing warrants on county property and then ECSO has no choice but to go do it. There is no mechanism in place for homeless advocates to go on the calls the police just run priors and arrest the people who have a previous trespass on that property and scatter the rest.

**Mel Pino**: Yes

**Mel Pino**: My idea was to form homeless strike forces which would always include a homeless expert on the call. Chip liked it but Janice got Alison to write nasty letters so Morgan said eff the county. I don't know where chip is on it now.

**Mel Pino**: Fyi the shit hit the fan during the negotiations ofor the city police chief tonight and an angry cop brought up consolidation of services. So obviously the combined charter folks are working on the PPD.

**Mel Pino**: You guys need an administrator who isn't falling and down and trying to get terminated for a big package while this is going on.

### CONVERSATION ON 02-28-2021

**Mel Pino**: Blow up top post.

### CONVERSATION ON 03-01-2021

**Mel Pino**: Larry said Michael got a new number. I told him to call Michael immediately and tell him to call you.

**Jeff Bergosh**: Just spoke to him.  He's good to go

**Mel Pino**: 👍

**Mel Pino**: Almost done and you have NO idea how excited I am o have this public to help counter all the lies Wendy and Doug have told in the past about me faking my academic experience  and how people can't track my past

**Mel Pino**: Sent to Debbie and cc'd you.

**Mel Pino**: Jeff a Mike and Kevin liked my CV but a friend just told me it was overkill for a county appointment. If you agree then I will revise it.

**Mel Pino**: I was trying to put down all my past experience because Doug has inclucated people with lies about my past for years on end, so I covered everything. Also people might view my academic stuff as elitist which is why I included my early job experience. I grew up working in the fields and pu t myself through college waiting tables so no I am not a Harvard trust fund baby. 

**Mel Pino**: Anyway I know you have had a long day if you have suggestions to make it more appropriate to a county committee appointment let me know tomorrow it won't take long to revise.

### CONVERSATION ON 03-02-2021

**Mel Pino**: Sorry Jeff I had to take that. He didn't know :(

**Mel Pino**: Jeff you have probably already thought of this but technically I think the first commissioner to speak is the only one who can. They might try to delay your feed so Underhill can talk first. If they aren't just gaming you about proper notice to begin with. What a mess. But you gotta get on there asap and ask about the notice before Doug beats it to the punch.

**Jeff Bergosh**: https://ssrnews.com/williamson-files-legislation-to-allow-recall-of-county-commissioners/

**Mel Pino**: Wow. And those comments about why not at the state level too hit the nail on the head. The state is absolutely running amok with its authority.

**Mel Pino**: She will never, ever give up.

**Mel Pino**: Why didn't they just do all of this from the very beginning.

**Mel Pino**: Hahaha she slid right out of the four story

**Mel Pino**: She's preaching now

**Jeff Bergosh**: I logged out.  Can only take so much.  What a weak turnout.  127 total.  Embarrassing

**Mel Pino**: Was that it???

**Jeff Bergosh**: Yep

**Mel Pino**: Omg marina just came unglued and looked like she laid an egg at the end

**Jeff Bergosh**: 127 out of 320,000 residents

**Jeff Bergosh**: What an embarrassment

**Mel Pino**: Girl is stressed. 

**Mel Pino**: Well the thing is that if this kind of analysis would have happened at the beginning they would have been earning their money. She also way overview the thing about astrozenica.

**Mel Pino**: Mike has done a crap ton of work with astrozenica.

**Mel Pino**: I used to be smart like Mike. Then I met Doug Underhill.

**Mel Pino**: Oh my god you are missing this hahahahahaha

**Mel Pino**: She just fell back on "it's kind of what Doug Underhill said"

**Mel Pino**: Oh for the love of God you are missing the best part of the residential performance.

**Mel Pino**: I think she just called modern schools insect factories but I am not sure. Don't know what the he'll else she would have been saying

**Mel Pino**: She is absolutely losing it.

**Mel Pino**: Andrew bluer on turning it into Dubai hahahahahaha

**Mel Pino**: "Nobody is walking to anything there" --marina hour on Dubais

**Mel Pino**: She just argued against expanding roads.

**Mel Pino**: "This is a very quick plan put together" marina

**Mel Pino**: She takes exception to the emails

**Mel Pino**: Terri berry couldn't have attended all these meeting if she wanted. She is already on 8 or 9 projects already. Travis corrected to her having 16 or 17. No doubt. Not only is the engineering department 30 people down but Terri has to be on every pro Underhill project.

**Mel Pino**: Banters. It's just funny that they were trashing the board. She stands behind the fact that they did not act unprofessionally. Dpz just pissed all over the board in good fun. And in all the years they have never been asked public record. So they are just overjoyed to do it.  Apart from the fact that regardless of sunshine you are their CLIENT and so should have a right to that per terms of a contract. But because your county attorney is also gaming you guys, every contract she drew uo in his was absolute shit.

**Mel Pino**: Holy shit she is off the rails.

### CONVERSATION ON 03-04-2021

**Mel Pino**: Jana gave Paulette covid

**Mel Pino**: Sickening.

**Mel Pino**: Ask Allison why Doug got the fire brown out plan and you guys didn't. Answer; because your attorney and your administrator are in on this coup and playing you guys.

**Mel Pino**: ******ask her where she makes these power points available to the public

**Mel Pino**: There is another one for team Doug and Janice.

**Mel Pino**: Hahahahhaahahahahaha

**Mel Pino**: You have got to be fucking kidding me

**Mel Pino**: Wonder who she will feed that consulting to

**Mel Pino**: Oh so it is already going who is the contractor??

**Mel Pino**: What the fuck? Who got the contract and how much? Was this on an agenda?

**Mel Pino**: She just said that she moved it to cares.

**Mel Pino**: SHE DIDNT SPEND IT ON PUBLIC SAFETY

**Mel Pino**: SHE DIDNT SPEND IT ON PUBLIC SAFETY

**Mel Pino**: That was awesome commentary.

**Mel Pino**: Perfect. Thank you for representing it within the context of the entire public safety issue

**Mel Pino**: She uses Robert to pit the board against staff all the time.

**Mel Pino**: BOOM. Fantastic.

**Mel Pino**: Ou have him totally scrambling hahahaha

**Mel Pino**: Hahahahahahaha he has no fucking idea what to do

**Mel Pino**: Hahahahahahaha he has no fucking idea what to do

**Jeff Bergosh**: 😎👍

**Mel Pino**: This guy doesn't know when to quit.

**Jeff Bergosh**: Wow!

**Mel Pino**: No lessons learned there at all. 

**Mel Pino**: Sitting chamber. Danheiser didn't award me any fees. Just bond of 5000 dissolved the injunction and I Get taxable fees. Pam dropped it on the clerk website an hour before the meeting

**Jeff Bergosh**: Is that a win?

**Mel Pino**: At the very least I got the dissolution of that bullshit tro and he said it should have never happened. More later.

**Mel Pino**: This is the guy who sent those emails I was telling you about

**Jeff Bergosh**: Yep

**Mel Pino**: Most horrible things I have seen in a while.

**Mel Pino**: Jeff fyi I double checked and it is NOT him. Same last name and probably related but not him on those emails

**Jeff Bergosh**: Oh, okay thx

**Mel Pino**: Legally speaking do they HAVE to?

**Mel Pino**: Do they legally HAVE to pay?

**Jeff Bergosh**: No

**Mel Pino**: PLEASE disabuse that bullshit Doug said about beach access 4 not having it's federal permit. Call Tim up for an update.

**Mel Pino**: Make sure people know he was lying about the federal permit. The federal permit was part of the original paperwork

**Mel Pino**: There's your gender warfare. As a female it makes me puke.

### CONVERSATION ON 03-05-2021

**Mel Pino**: Hey I was just hoping to catch you in the car. Nothing urgent.

### CONVERSATION ON 03-06-2021

**Mel Pino**: Okay so I won't go into a multiple text harangue, but just as with Janice, Allison does not have the best interests of the entire board at heart. The amount of taxpayer money that she has squandered with sheltering Doug is just mind blowing. And she is doing the same thing in the Selove suit. She is dragging that case out because she knows she screwed up royally in being complicit with Janice and Jana still on violating a staff members due process. And some of her legal opinions aren't worth the paper they are written on. Which is why she black balled Charlie from ever escaping that office.

### CONVERSATION ON 03-09-2021

**Mel Pino**: Hey Jeff, fyi on some of those more compressed image files there is no way we can make them all out, esp the stuff in blue. We tried every way to get them to enlarge enough without going too fuzzy. Don't know how much time you want to spend on it. The general drift is apparent. But I tried multiple browsers, enlarging from the blog page, opening a new tab and enlarging, copying them into word and enlarging. Oh wait let me try phone.

**Mel Pino**: Nope still too blurry. I can make out most of what's grey but blue is almost impossible.

**Mel Pino**: Again I can make out enough that the gist is clear just certain words and phrases 

**Jeff Bergosh**: No-- they Are looking at the lawn to give me a cost proposal for spraying to kill the weeds and fertilize the grass

**Jeff Bergosh**: I'm going to try to blow them up to make them easier to read

**Mel Pino**: Don't you dare use toxic spray to go into my bayou!!!!!! :)

**Jeff Bergosh**: LOL

**Mel Pino**: NO LAUGHING MATTER!! Haha 

**Mel Pino**: This was unprovoked by me. 

**Jeff Bergosh**: Good question-- who is she?

**Mel Pino**: A friend of mine who is super smart and follows everything that happens through my page

**Mel Pino**: Nice photo.

**Mel Pino**: Wtf is that Ed's opinion? Or is Doug off on his own with this? He is going to get held in contempt

**Jeff Bergosh**: Not smart.  When you're stuck in a hole and can't get out-  step one is stop digging......

**Mel Pino**: Meanwhile.

**Mel Pino**: Check my Facebook page Jeff. What a fricking day!

**Mel Pino**: And that is the end of this nonsense. The most important part is the very last paragraph. 

https://www.pnj.com/story/news/2021/03/09/escambia-medical-director-rayme-edler-ordered-pay-court-costs-defamation-lawsuit-mel-pino/6924051002/

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Big day

**Mel Pino**: Yeah. It was a good day for the good guys. :)

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-11-2021

**Mel Pino**: This asshole.

**Mel Pino**: See? You are not out on a limb by yourself.

**Mel Pino**: Janice just itching to get in there on the impact fees. Which is none of her business. She is not a policy maker and needs to stay out of it.

**Mel Pino**: Tell him thanks but the events of the last week show that he doesn't have the best intentions of the board at heart

**Mel Pino**: So shut the fuck up.

**Mel Pino**: Wow he knocked it out of the park for a change.

**Mel Pino**: Janice appreciates marina's "direction." Unbelievable.

**Mel Pino**: Why is there a city council meeting playing on ECTV?

**Jeff Bergosh**: ?

**Mel Pino**: Just weird...the tv next door was still playing ECTV from this morning and it was playing a city council meeting. Never seen that before

**Mel Pino**: Guess it is part of the new contract to cover city meetings.  
 https://www.wuwf.org/wuwf-tv-0#stream/0

### CONVERSATION ON 03-12-2021

**Jeff Bergosh**: What is allowed is not only condoned, it is endorsed

**Mel Pino**: Looks like somebody trying to shut it down. I have no idea who put in the complaint.

**Jeff Bergosh**: His first sentence describes himself

**Mel Pino**: Doug is the only thing Doug knows how to describe. Every word he expresses is a look into his twisted psyche which he is now completely trapped in.

**Jeff Bergosh**: Yep

**Mel Pino**: And as I always say, this will get worse.

**Jeff Bergosh**: Yep

**Jeff Bergosh**: You got a minute to chat?

**Mel Pino**: Check the post I just made on my Facebook wall.

**Jeff Bergosh**: Will do

### CONVERSATION ON 03-13-2021

**Jeff Bergosh**: FWIW—take a look at the PNJ Facebook post of Andy Marlette’s hatchet job directed at me.  It backfired on him spectacularly and the commenters are beating the crap out of Andy and the PNJ.  It happened because like dummies, they mixed up the messages, talked crap about MATT Gaetz, put my picture up, and threw in the hashtag #freeBrittney.  Then, in their final act of stupidity, they locked the post for “subscribers only” so nobody could get the real context which was a hit on me.  A spectacular failure on their part which elicited a bashing to PNJ which they deserve.  A real, complete failure on their part here!👍😎

**Mel Pino**: Oh good grief it just never ends. Going to look...check my Facebook wall on that top post for continued discussion of Doug's disinformation game on me backfiring spectacularly. 

**Mel Pino**: What in the hell IS that?? Man, I was expecting Andy to bring his A game on this round and that certainly ain't it. A triggered hot mess.

**Mel Pino**: And actually I like it both ways because I hate Matt gaetz and the hit job on you got buried. I'm not sure what to think about freeing Brittany it might be a threefer hahaha

**Mel Pino**: I hope Doug enjoys his jet ski weekend knowing code is incoming on Monday. Dipshit will never learn not to mess with me.

**Mel Pino**: Hahahahahahaha you are an absolute glutton for punishment my friend

**Jeff Bergosh**: 😎👍

**Mel Pino**: Of course so am I. Doug will have his goons over to navy point right quick.

**Mel Pino**: So janice just sent me this shit.

### CONVERSATION ON 03-15-2021

**Jeff Bergosh**: John Beroset
Kim Skievaski 
Paul Hamlin

**Mel Pino**: Thank you! On phone with JJ

**Jeff Bergosh**: 👍

**Mel Pino**: Beroset would be conflicted out because they have Edler in her never-ending custody battle. But Kim Skievaski can help and is calling tonight. Thank you Jeff!

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: https://www.wkrg.com/hurricane-sally/six-months-later-hurricane-sally-family-continues-to-struggle-with-damages/

**Mel Pino**: Left a voicemail

### CONVERSATION ON 03-18-2021

**Mel Pino**: https://www.mypanhandle.com/news/phoenix-construction-owner-james-finch-indicted-alongside-former-lynn-haven-officials/

**Mel Pino**: Everybody praising the us attorneys office this doesn't have a great concept of what went down. It was Nikki frieds office that conducted the investigation then turned over an airtight case to Keefe to prosecute.

### CONVERSATION ON 03-19-2021

**Mel Pino**: Call me the message erased

**Jeff Bergosh**: 👍

**Mel Pino**: Posted.

**Mel Pino**: Post an important follow up...that's not her on the first one. Pretty sure that handwriting is Wendy's but not one hundred.

**Mel Pino**: You might want to edit it to say it might not be the Jacqueline account that posted the letter but only her nasty emoticon about it underneath. 

**Mel Pino**: Sorry to bug you on a nice Friday night dinner...if you can please post that comment because that is not Jacqueline who wrote the letter. My guess is Wendy.

**Mel Pino**: WAIT hahaha got it nowm sending in slightly revised please post second version not first

### CONVERSATION ON 03-20-2021

**Mel Pino**: Check my new post.

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-21-2021

**Mel Pino**: Posted

### CONVERSATION ON 03-24-2021

**Mel Pino**: Hi Jeff, can you consider this an official public records request to forward me whatever email Alison just sent out on Edler versus Pino? I would appreciate it you could do it at your earliest possible convenience.

**Mel Pino**: My email address is melissawpino@gmail.com

**Jeff Bergosh**: Okay

**Mel Pino**: Edler versus Pino has nothing to do with county business so I find it strange she is updating people on it.

**Mel Pino**: Posted.

**Mel Pino**: Some off county business entertainment 

https://youtu.be/MYnGAZl3pjs

**Mel Pino**: Check email.

**Jeff Bergosh**: 👍👍👍👍

**Jeff Bergosh**: That guy is my hero

### CONVERSATION ON 03-25-2021

**Mel Pino**: This about has me in tears

**Mel Pino**: From Matt Coughlin:

Ok, thanks for asking.  Just finished press conf.  All safe

**Mel Pino**: PLEASE SUPPORT HIM JEFF

**Mel Pino**: Jeff do not leave on the body cams. You want that yes vote!

**Mel Pino**: Unbelievable. Steven CLEARLY held that item. When he said the number I looked it up and said to Kevin "oh good he held the bay center." Then Robert and Janice pretended he didn't. Clerk should have stayed in

**Mel Pino**: Stepped

**Mel Pino**: I know you might not be able to stay but I am speaking on beach haven it might be next

**Mel Pino**: And mentioning that Doug's house got PPP

**Mel Pino**: If you leave that project is going to pass and it is a mess

### CONVERSATION ON 03-29-2021

**Mel Pino**: Pensacola Mayor Grover Robinson will not seek re-election in 2022 https://weartv.com/news/local/pensacola-mayor-grover-robinson-will-not-seek-re-election-in-2022

**Mel Pino**: Sherri is going to file for mayor.

**Mel Pino**: That is not public yet!

**Jeff Bergosh**: Wow!

**Mel Pino**: Keep it close. This isn't county business so it's not public record.

**Jeff Bergosh**: I've also heard Sheriff Morgan is running as well

**Mel Pino**: Sue told sherri he was only thinking about it but I don't buy it.

**Mel Pino**: My worst fear is that chip will feel boxed in to supporting him and that will put him over the edge.

**Mel Pino**: Fyi I nailed down the lake Charlene money today. Yep joy lied but it is not as bad as going all the way back. They have not however gotten the grant reinstated by FDEM. The real kicker is Doug has an LOST Ace in the hole. Can explain tomorrow.

**Mel Pino**: Off county business just a fun song you might enjoy.

https://youtu.be/-nG6Q7MqVCo 

### CONVERSATION ON 03-30-2021

**Mel Pino**: Looks like Janice's downtown backers have had about enough of her. Remember when I complained about covenant with the community two meetings ago, and was told that "we don't have to do that on every contract that goes out." Even if that is technically true, it was a pretty piss poor response.

https://www.pnj.com/story/news/local/escambia-county/2021/03/30/policy-70-percent-escambia-santa-rosa-workers-county-projects-never-applied-community-covenant/6948455002/

**Mel Pino**: https://www.nytimes.com/2021/03/30/us/politics/matt-gaetz-sex-trafficking-investigation.html

**Mel Pino**: Jeff what is the date of the PRR?

**Jeff Bergosh**: Which one?  

**Jeff Bergosh**: Of March

**Mel Pino**: No arduini

**Jeff Bergosh**: About two weeks ago or so

**Mel Pino**: Dozens in Florida contract COVID-19 after being fully vaccinated https://www.newsbreakapp.com/n/0Z5NZDQB?pd=095IgePP&lang=en_US&s=i4

### CONVERSATION ON 03-31-2021

**Jeff Bergosh**: Well that's a scary thought 

**Mel Pino**: Yes. :(  This is why I said it's not over. The places where everybody is pretending it is are the hot beds of the variant. With Florida being the worst state for it :(

**Mel Pino**: Mother nature doesn't play politics.

**Mel Pino**: See my comment here

https://ricksblog.biz/all-five-commissioners-may-have-to-run-in-2022/

**Mel Pino**: https://www.politico.com/states/florida/story/2021/03/31/gaetzs-father-backs-up-son-matts-claims-of-extortion-over-doj-probe-of-involvement-with-teen-1370695

**Mel Pino**: Unbelievable.

**Jeff Bergosh**: Wow

**Mel Pino**: https://www.cnn.com/2021/03/31/politics/matt-gaetz-fbi-17-year-old/index.html

**Mel Pino**: https://www.washingtonpost.com/national-security/matt-gaetz-investigation-robert-levinson/2021/03/31/ebe2a9ba-923e-11eb-9668-89be11273c09_story.html

**Mel Pino**: That last one explains it well.

**Mel Pino**: https://www.washingtonexaminer.com/news/documents-detail-alleged-matt-gaetz-25-million-extortion-scheme?fbclid=IwAR0hoW7EjhRjchmL5OtbAlmv8HFPdXAI5AeSSOR6iAJnO_BP4fwISbTCAo8

**Mel Pino**: My new theory. Trump was behind any extortion attempt, if it is real, and was trying to con don gaetz out of 25M pretending to get levinson back. Wait for it.

### CONVERSATION ON 04-01-2021

**Jeff Bergosh**: That's pretty "out there"

**Mel Pino**: Hahaha I'm half joking. Half.

**Mel Pino**: My real point is, why not. It can't get any more bizarre.

**Mel Pino**: Check this out! Biden is putting a hundred billion to broadband! I sent this to Steven also

https://www.nytimes.com/2021/04/01/technology/digital-divide-rural-wifi.html#click=https://t.co/F8VSHmIc1T

### CONVERSATION ON 04-03-2021

**Mel Pino**: https://ricksblog.biz/buzz-gaetz-arrest-imminent/

**Jeff Bergosh**: Wow!

**Mel Pino**: https://twitter.com/YALiberty/status/1375545592328359940?s=20

**Mel Pino**: Theres another one viral. You're welcome everybody.

### CONVERSATION ON 04-05-2021

**Mel Pino**: Bob Kent is on CNN with an exclusive with Chris Cuomo. We are backing up and watching.

**Mel Pino**: Holy shit this unbelievable

**Mel Pino**: https://www.mediaite.com/tv/watch-chris-cuomo-questions-former-air-force-intel-officer-gaetz-accused-of-being-part-of-extortion-scheme/

### CONVERSATION ON 04-07-2021

**Jeff Bergosh**: On a conference call

**Mel Pino**: Left a voicemail

**Mel Pino**: And posted

**Jeff Bergosh**: I

**Mel Pino**: JEFF HOLD THAT POST

**Jeff Bergosh**: Okay

**Mel Pino**: https://mobile.twitter.com/peterschorschfl/status/1379906650711203843

**Mel Pino**: If it is true, couldn't happen to a nicer guy. This is the shithead who was blocking complaints against contractors at the DBPR

**Jeff Bergosh**: Trouble!

**Mel Pino**: Lots of it. Call after your meeting if you have anything left in the tank.

### CONVERSATION ON 04-08-2021

**Mel Pino**: Give me a break.

**Mel Pino**: Stuck here waiting for floor guys and had the cable go out in one house with the storm.

**Mel Pino**: We don't even know if he is telling the truth.

**Mel Pino**: As if she doesn't know.

**Mel Pino**: And this is how DeSantis is keeping the numbers down.

**Mel Pino**: Ask her where she keeps the file on all the verbal complaints she tanks.

**Mel Pino**: She is lying and she just admitted it. They throw away verbal complaints.

**Mel Pino**: Ask her for a copy of Chris curbs verbal complaint

**Mel Pino**: This is all a big lie. They all orchestrated this cover up.

**Mel Pino**: IT WAS NOT A SECRET. Janice hid the eval.

**Mel Pino**: Where was all this righteous indignation when Janice continued to hide those five complaints and lie to you guys that I didn't give her the names.

**Mel Pino**: I can't wait for public forum

**Mel Pino**: They take hand written notes on verbal complaint

**Mel Pino**: oh bullshit on Pens. That is so disrespectful staff.

**Mel Pino**: They all just filed out of the room laughing. I am not lying.

### CONVERSATION ON 04-09-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Call when you can pretty important.

**Mel Pino**: Just sent you guys the doc. It's already public record the summons went out today.

**Mel Pino**: I figured Alison wouldn't give it to you.

**Jeff Bergosh**: Thx I'll check it out

### CONVERSATION ON 04-12-2021

**Mel Pino**: Jeff you have a typo on "goverment" in you header to you new post.

**Mel Pino**: Do a search for that typo It appears again further on

**Jeff Bergosh**: Thx will fix

**Mel Pino**: Left a voicemail if you have a chance to listen

### CONVERSATION ON 04-13-2021

**Mel Pino**: Listen to two voicemails when you have a chance. Second one more important.

**Jeff Bergosh**: Listened.  Buried all day will call on a break to discuss

**Mel Pino**: No worries. I had a good convo to relay when you have time. 

**Mel Pino**: This needs to STOP.

**Jeff Bergosh**: What's the context??

**Jeff Bergosh**: I don't see it

**Mel Pino**: They might have blocked your account from being able to view. You might have to look from somebody else's. This is how they play.

**Mel Pino**: This is why all of us have a sock puppet that we can read that vile site on. I could not see anything happening there if I didn't view it from another account.

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: On a conference call will call u after

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Guess he's not paying attention to current events...The Senate version has been modified to adopt and incorporate some house language, but the provisions related to commissioner elections was specifically left out.  And the revise sent version couldn't even make it through its first committee stop today.This bill goes nowhere this year and even if it did what Doug Underhill wants in terms of rushing redistricting doesn't mean he's going to get what he wants. He'll get what he typically gets which is nothing which is put on the bottom of 4-1 votes

**Mel Pino**: Oh that is such good news! I had lost track of where things were with it. 

**Jeff Bergosh**: I haven't 

**Jeff Bergosh**: And no connections there whatsoever

**Mel Pino**: He is completely out of control and it will only get worse. He took down his commissioner page and is blowing stuff up left and right on ecw and it is very hard on staff.

**Mel Pino**: What Senate. Bill is it? 90?

**Jeff Bergosh**: SB 90

**Jeff Bergosh**: Doug wouldn't know who to call or where to go or what to do if someone gave him directions and a map he's so fucking lost in the sauce

**Mel Pino**: Excellent. Thank you. Agreed.

**Jeff Bergosh**: 👍

**Mel Pino**: It says it is temporarily postponed on the website.

**Jeff Bergosh**: That's because they got to the bill and there was a gazillion speakers and they were still debating it when the clock ran out at 2 PM

**Mel Pino**: What a fiasco.

### CONVERSATION ON 04-15-2021

**Mel Pino**: Not sure I said that right. That was supposed to be 10.m dollars Janice is sitting on that was supposed to go to ecat to help with covid specific including employee assistance

**Mel Pino**: Apparently she was awarded an extension NY lower management and Tonya ignored it. Trying to find out if that doc is available. 

**Mel Pino**: Fyi this takes us from 17 to 18 bus drivers down.

**Mel Pino**: This one hits all of janice's sweet spots. Torturing ecat workers, denying employees assistance through cares when they are fighting covid and run out of leave, and firing people at the 20 to 25 year Mark. She is decimating this county.

**Mel Pino**: This whole thing is a setup Janice orchestrated for Doug to drag the bay center through the mud. 

**Mel Pino**: I'm not saying the management isn't a mess. But as I understand it the county approached them and asked them if they need money.

**Mel Pino**: Maybe we could keep people working by not firing bus drivers who have Covid and denying county staff financial assistance when they come down with it. 

**Mel Pino**: I wish she would just bust Janice wide open.

**Mel Pino**: She knows damn well what conversation she is talking about.

**Mel Pino**: And if you think Janice didn't tell her to say that I got a bridge to sell you. 

**Mel Pino**: And here comes the translation with Janice Robert and Doug.

**Mel Pino**: They didn't think they could get it then Janice and staff told her to come for it.

**Mel Pino**: In other words he is shilling for downtown.

**Mel Pino**: Told you he is reciting from ribbons rise and fall of the Roman Empire.

**Mel Pino**: Gibbons

**Mel Pino**: I saw krokus in concert

**Jeff Bergosh**: 👍

**Mel Pino**: John peacock just let the cat out of the bag on ecw that the Sunday Pnj will have a big piece against single member districts (and I assume leaning towards consolidation). 

**Jeff Bergosh**: Interesting

**Jeff Bergosh**: Where I strongly disagree with John is his stance that the county needs a "Strong Executive" like a strong mayor.  That'd be a fucking wreck.  Been there done that for 10 years with our former broken model in the school district and the "Strong" elected superintendent.  That was a broken busted system that led to corruption and nepotism. Power corrupts-- absolute power corrupts absolutely

**Mel Pino**: I agree with you on both counts. No thanks. Can you imagine Janice with even more power than she had during the state's of emergency? Good Lord.

### CONVERSATION ON 04-17-2021

**Mel Pino**: Thank Janice for every one of these issues in the Peacock article. I could have named a half dozen more, but of course peacock has no idea of county business. Can't wait until he can add a disastrous budget planning cycle to the mix.

**Mel Pino**: Interesting that he swung this in the direction of havin an electable executive administrator. Not saying that is a good idea. But there seems to be the tacit understanding even over on ecw that Janice is failing badly.

**Mel Pino**: Oh of course. He wants a trump sitting over the BOCC haha. Guesss he doesn't realize we already do.

### CONVERSATION ON 04-22-2021

**Mel Pino**: And this is how they roll. Because nobody ever pushes them. This is the game. They know they will never get in trouble

**Mel Pino**: What a joke. The public sees through this Jeff. It's horrible. And you guys look complicit because the of game the county is allowing these developers to run.

**Mel Pino**: Its really time to stop this farce.

**Mel Pino**: He is absolutely right. The county need to stop messing around and start caring about this.

**Mel Pino**: You guys might want to get janice's runaway train wreck under control with janice's continued blood bath and ruination of staff while you are getting ready to vote yourself back money in the hundreds of thousands

**Mel Pino**: Same shit different day. What a surprise no written report

**Mel Pino**: Dance is such a fucking liar she is sitting on 10 . That atu lobbied for Escambia transit and she is SQATTING on it. Another meeting, another mile down into the hole with county function

**Mel Pino**: Janice.

**Mel Pino**: Good thing covid is over.

**Mel Pino**: There are leaving to get away from Janice and her hired thugs

**Mel Pino**: These and VETERAN staff members leaving.

**Mel Pino**: I can't believe that she let you think that inflation is behind this. Yes with FOOT SOLDIER jobs but with middle management and leadership they are leaving because of JANICE

**Mel Pino**: People aren't dumping their retirements to get the he'll out of the county because of job inflation

**Mel Pino**: Here comes Doug slobbering.

**Mel Pino**: I have a feeling this is going to get heated. Hope you support if it does. This needs heat. It all needs heat you guys look horrible the way they are playing you.

**Mel Pino**: Looke at her trying to play steven. This needs to Stop. He is bringing this probably because he doesn't believe what is being told to him offline. Or he has just quit asking because it's not worth it.

**Mel Pino**: And with Janice letting her die at the podium

**Mel Pino**: I have been trying to tell you guys this for a year

**Mel Pino**: You guys better damn well walk through every purchase order because it won't come down on Administration if the shit ever hits the fan.

**Mel Pino**: Hahahaha " a pretty stringent process"

**Mel Pino**: Her process is stringent all right. Especially offline.

**Mel Pino**: Hahahaha it's not to hide something from you

**Mel Pino**: How about the change orders being under a certain percentage or the contractor get kicked off the project

**Mel Pino**: Still with the question of whether Janice even had the right to schlep cares money to offset salaries with CARES

**Mel Pino**: Yes on finances but in terms of function it is the worst it has been for a very long time.

### CONVERSATION ON 04-23-2021

**Mel Pino**: Hey Jeff, know it's probably too late to get you...just wanted to say sorry I couldn't get back earlier. Had to get the place ready for Meredith and her son and got two loads of Lumber delivered that had to get moved into the shop before the rain. Hit me up on the way to tennis if you're free!

### CONVERSATION ON 04-25-2021

**Mel Pino**: Not exactly the stuff to be sending Sunday morning but it happened after I went to bed last night.

### CONVERSATION ON 04-27-2021

**Mel Pino**: The BOCC language in the House Bill got removed with a strike all amendment over night.  https://flsenate.gov/Session/Bill/2021/90/Amendment/107453/PDF

**Mel Pino**: Hey stranger, fyi that Roadside parking ordinance Doug sold you guys on is an absolute disaster. People revolting right now on not being able to get to the beach. Johnson closed down around 1130 and state park still closed. Condo owners taking up all the parking at each accesses. It is crippling the season down there and Doug's best longest stalwart fans are totally turning on him...something needs to give or we will lose at least a half a season down there. I posted on it.

### CONVERSATION ON 04-29-2021

**Mel Pino**: Check my comment here when you have a chance.
 https://ricksblog.biz/possible-gaming-of-procurement-under-gilley/

**Mel Pino**: Sorry I don't think he posted it yet.

**Mel Pino**: https://www.washingtonpost.com/opinions/2021/04/27/just-because-republicans-engages-skullduggery-doesnt-mean-they-are-helping-themselves/

### CONVERSATION ON 04-30-2021

**Mel Pino**: Just had a really good talk with a friend about procurement issues that was very enlightening.

**Mel Pino**: Also people are still raging about the parking problem and beach access in perdido which is costing us business and revenue. I really think it is time for the board to go around Doug and get the parking problem solved. Staff can solve it Doug just won't let them.

### CONVERSATION ON 05-01-2021

**Mel Pino**: Hey fyi your phone company is saying you are not available. Are you guys in Vegas?

**Jeff Bergosh**: New Orleans later

**Mel Pino**: Hahaha knew it

**Jeff Bergosh**: 😎👍

**Mel Pino**: https://www.pnj.com/story/opinion/2021/05/01/editorial-bergosh-right-seek-solution-pay-growth/4878660001/

**Mel Pino**: See that yet? Who would have thought that the Pnj would write a headline with the first three words "Bergosh is right" ?

**Mel Pino**: Just remember who told you it was time to throw down on concurrency haha

**Mel Pino**: Tagged you on a Facebook post about it.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-03-2021

**Mel Pino**: Hey hit me up when you're no longer under water. Got some important stuff I want to discuss with you.

**Mel Pino**: Also I dropped the ball on forwarding this to you last week. From Teri Nock. She is the president of purple heart and he husband lieut commander Andrew Deguadio has the command: 

Please have Jeff Bergosh call Andrew... we just figured out that Judge Bergosh's grandfather was a Purple Heart recipient which makes them eligible as associate members of the MOPH... 
 

### CONVERSATION ON 05-05-2021

**Mel Pino**: Jeff jacqueline is asking for documentation. Can you get it up on your blog or send to me via email so I can share with Mike?

**Jeff Bergosh**: Okay I'll send u it

**Mel Pino**: Awesome

**Mel Pino**: Got it all! That's it right?

**Jeff Bergosh**: P6

**Mel Pino**: Oh okay two more

**Jeff Bergosh**: You've got it all now

**Mel Pino**: Got it!!

**Mel Pino**: Jeff just want to make sure you knew that is the DEP sign off not fish and Wildlife. De FINALLY gave the go ahead on the building. Now Tim day can move being the agent of fish and Wildlife at the county. But TECHNICALLY fish and Wildlife could still balk at zero hour. He just doesn't think that is going to happen.

### CONVERSATION ON 05-06-2021

**Mel Pino**: Jeff Doug snuck that navy boulevard project back on, the one that might impact deliveries at Frank Patty's shipyard! That thing was supposed to be dead and now it's on for a dot easement??

**Mel Pino**: He said he was never doing this project. Now it's on for an easement. Its not the beautification but there was real question of whether big trucks could use those turn lanes. Dot would never really answer. The last public hearing was THREE YEARS ago, during the election.

**Mel Pino**: Also please ask who owns the property after the county vacates, the county or the petitioner.

**Mel Pino**: Whyare there no white men in that video???????

**Mel Pino**: What a crock of shit. One black man and a bunch of white women. They are so blatantly obvious.

**Mel Pino**: You know darn well that they don't know how effective these vaccines are. They don't know how long they will hold, there are instances of people getting covid post vaccine, and they don't know about variants. And they will probably require a booster. 

**Mel Pino**: If you don't know that, you should. And there are still people dying so you might have a LITTLE sensitivity to that. 

**Mel Pino**: Jeff will you ask who owns it?

**Mel Pino**: Why is there a reduction of people who can go out in the road camp??

**Mel Pino**: BE CAREFUL he just said a lot had happened since the last time you guys talked. 

**Mel Pino**: You are watching the beginning of the end of our ems and fire services taking over.

**Mel Pino**: This whole thing is orchestrated. When Doug Underhill makes fun of Jacqueline Rogers you can be damn sure something is up.

**Mel Pino**: They're playing you. Or trying to.

**Jeff Bergosh**: Here it comes............

**Mel Pino**: Yep. 

**Mel Pino**: I posted

**Mel Pino**: This is Kate Kenny's husband. She couldn't even come.

**Mel Pino**: Wasnt he under investigation for arsen on the skate rink? 

**Mel Pino**: He runs around posting hashtag "isupportdougunderhill" all over ecw

### CONVERSATION ON 05-07-2021

**Mel Pino**: Jeff would you help Sherri with her graffiti ordinance? 

**Jeff Bergosh**: I'll look at it

**Mel Pino**: Cool. Nobody else will probably do it because it impacts those car washes of growers but county code is very frustrated on the issue because their hands are tied. Not just on Grover but anywhere.

**Mel Pino**: That's quite a partnership Janice has going with Doug Underhill. I particularly like when she starts throwing terms like "when we hit that delta" and "scriverner's error" around. These two obviously spend a LOT of time chewing things over together. Thank goodness Lumon finally got Mike to say that she has been lying during negotiations saying that the Board was denying the three percent on the raises. 

**Mel Pino**: Posted.

### CONVERSATION ON 05-10-2021

**Mel Pino**: Jeff going to leave a voicemail.

**Mel Pino**: And a follow up.

**Mel Pino**: Last thought. He said it is so bad that it probably requires a national strike team at this point to fix. 

### CONVERSATION ON 05-11-2021

**Mel Pino**: Woo hoo!!!!! Fish and Wildlife letter!!!!!!!

**Jeff Bergosh**: 👍

**Mel Pino**: Sorry...trying to text. Just saw your blog! I am going to try to sign up for notifications again...drives me nuts. Posted.

**Mel Pino**: Hey cut my second signature off if you can

### CONVERSATION ON 05-13-2021

**Mel Pino**: According to Jimmy's blog the FBI is raiding Scott haines'house

**Mel Pino**: https://thehill.com/blogs/in-the-know/553490-bill-maher-tests-positive-for-covid-19

### CONVERSATION ON 05-17-2021

**Mel Pino**: Give me a call if and when u have time

**Jeff Bergosh**: Will do.  On other line

**Mel Pino**: GET OFF FOX hahaha

India manufacturing most of the world's covid vaccines including a billion doses of astrozenica and 700 million of novavax plus their own, Russian, and ZYcov-D (the world's first plasmid DNA vax)

https://www.reuters.com/article/health-coronavirus-india-vaccine-idUSL4N2LK1KJ

**Mel Pino**: Shipped it all out and didn't vaccinate their own population. Now they are halting distribution to keep it home and it is seriously disrupting vaccine programs around the world.

**Mel Pino**: Ask Robert if he would like you to make an equal stink on this library that he did on yours.

**Mel Pino**: You are probably aware that this is a whole lotta hustling.

**Mel Pino**: Money grab and the reason open doors had to partner with pathways is that they can't provide a continuum of care.

**Mel Pino**:  They won't even allow Michael Kimberl at the table and had already decided who was going to get the money.

**Mel Pino**: Ask him how much money Grover is paying him.

**Mel Pino**: KNIVES MEN AND PITBULLS DAMMIT you better LISTEN to these experts

**Mel Pino**: Remember I got Doug cited for a lack of land disturbance code on his own property

**Mel Pino**: Btw I was texting with chip during the meeting and Doug is so full of shit. They don't keep stats on homeless crim and chip is unaware of any uptick.

**Mel Pino**: Sorry forgot to tell you Liz Bush got out of engineering into facilities. Another one bites the dust.

### CONVERSATION ON 05-18-2021

**Mel Pino**: You have seen car III 2 on concurrency right

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: Yes.

**Jeff Bergosh**: Thought it was coming at a COW but glad it's coming

**Mel Pino**: Dropped

**Mel Pino**: If you have time please read the email I just sent and skin the linked articles.They are relevant.

### CONVERSATION ON 05-20-2021

**Mel Pino**: One more step towards privatization

**Mel Pino**: Didn't it say "for cause" Jeff?

**Mel Pino**: On the termination fee? 

**Mel Pino**: This is a pretty good tee up for concurrency

**Mel Pino**: I'm speaking on it.

**Jeff Bergosh**: Yes

**Mel Pino**: Yeah!!!!!!!!!!!!!!!!!!!!!!!!!!

**Jeff Bergosh**: 👍

**Mel Pino**: Dont miss Frank Westmark...I would imagine he will have Jacqueline on full blast.

**Mel Pino**: Consulting. Chips opened up Erso again.

**Mel Pino**: NON PROFIT CONSULTING

**Mel Pino**: NON PROFIT CONSULTING

**Mel Pino**: you might want to check Mike lowerys Facebook page when you have a chance. Gilley is getting run over by a truck.

### CONVERSATION ON 05-21-2021

**Mel Pino**: Check email

### CONVERSATION ON 05-23-2021

**Mel Pino**: Wow. So this is Janice and jana's bright idea for how to solve public safety? A damn PR campaign? Look at the starting salary! Quite frankly as long as people can keep swinging these absurd, tone deaf moves off on you guys, she will continue to make you look absurd and tone deaf. The longer she rolls the worse it is going to get :(

### CONVERSATION ON 05-24-2021

**Mel Pino**: What an absolute disaster in the making. Total shit show--Janice running budget talks for Doug and Robert. Also, staff is frustrated to furious about those two new overpriced PR positions. If there is no money for raises for current staff, where the he'll is all the money coming from for her to continue to build her oligarchy?

### CONVERSATION ON 05-25-2021

**Mel Pino**: Did Janice tell you Cassie Boatwright and Dana from CMR quit?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: In mtg

**Mel Pino**: No worries just wanted to make sure she wasn't setting me up.

**Mel Pino**: And that isn't just going to you :)

**Mel Pino**: This may be a disgruntled ex employee, but it also happens to be the stone cold truth. She and Gilmore are lying to you about the real EMS data. I'm glad to see ANYBODY calling her out, as nobody employed at the county is going to say a word about Gilley even as they trash the commission. Because they see her as far more powerful than the board.

**Mel Pino**: Please check this post on my Facebook if you have time. Fire is finally understanding that Gilley has been lying to you guys about public safety.

**Mel Pino**: Posted here that you guys really ought to consider a hiring freeze at the county so we don't get more Janice dead weight hires to have to clear out of there.

https://ricksblog.biz/boatwright-leaving-county/

**Mel Pino**: As I have conveyed, janice putting out those 27 an hour PR positions is completely demoralizing to county staff. Why pay another 52 dollars an hour for a failing CMR department? It makes zero sense.

https://ricksblog.biz/county-public-information-office-loses-new-hire/

### CONVERSATION ON 05-26-2021

**Jeff Bergosh**: LOL

**Mel Pino**: This ought to be good.

**Jeff Bergosh**: Let them stew in it LOL, all 7 of them on a Facebook chat site.  They know nothing and they mean nothing they are irrelevant. Most importantly though they are wrong and ignorant. My recommendation: stop looking at that toxic shit site 

LOL

**Jeff Bergosh**: It's a beautiful day outside go enjoy it! I'm going to!😎😎👍👍

**Mel Pino**: I will look at anything that exposes Gilley for what she really is. 

**Mel Pino**: Not urgent just for when you have time.  This is the bullshit downtown is running and Mark my words they will be coming to you guys for money...they will blow through that 3m in no time. Connie Bookman is no longer doing pathways as it used to be she is administering this mess.

https://www.pnj.com/story/news/local/pensacola/2021/05/26/pensacola-may-spend-3-million-federal-covid-relief-homelessness/7421375002/

**Mel Pino**: Fyi Meredith says they might be able to purchase that sprinkler with special funding from her office!

**Mel Pino**: https://thefloridabarfoundation.org/bookman-to-take-office-as-president-of-foundation/

**Mel Pino**: The county is an absolute shit show of a three ring circus and a complete embarrassment at this point.

https://www.pnj.com/story/news/2021/05/26/escambia-county-employee-using-anonymous-public-records-unmask-citizen/7458654002/

**Jeff Bergosh**: Yeah I heard about this earlier today

**Jeff Bergosh**: Strange stuff 

**Mel Pino**: The county is an absolute shit show Jeff. 

### CONVERSATION ON 05-27-2021

**Jeff Bergosh**: In mtg

**Mel Pino**: K call me I have important info.

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Okay now they are moving to privatize ems. Have no idea how real this is

### CONVERSATION ON 05-28-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Thats okay I just left you a voicemail. No need to call back...have a great weekend

**Jeff Bergosh**: You too!

### CONVERSATION ON 05-31-2021

**Mel Pino**: Hey doing my calendar for the week. Anything to be concerned about with the old! Item at planning board tomorrow?

**Jeff Bergosh**: Nope

**Mel Pino**: Thank God I want to sit in the comfort of home and watch whatever fiasco they bring to that and the opt out on the agenda. 

### CONVERSATION ON 06-01-2021

**Mel Pino**: Check my tag on the homeless post I just put up and the money grab aimed at county taxpayer dollars. Meredith said she probably could pay for the sprinkler system from special funds.

**Mel Pino**: https://youtu.be/CSALQn0u9z4

**Mel Pino**: DPZ presenting.

**Jeff Bergosh**: 👍great.  Glad to be through with them!

**Mel Pino**: Those are some pretty pastoral triple deckers with tiny setbacks they are presenting.

**Jeff Bergosh**: Not unexpected

**Mel Pino**: Of course not. I was excited about it six months ago. She's just as big a shit bag as the rest of them. I suppose DeSantis will respond with a bunch of executive orders stripping the dept of Ag of duties and oversight.  So sick of all of them.

### CONVERSATION ON 06-02-2021

**Mel Pino**: https://ricksblog.biz/buzz-gilleys-employment-future-up-for-discussion/

### CONVERSATION ON 06-03-2021

**Mel Pino**: Christ Almighty IT can geotrack people through their devices??

**Mel Pino**: Then why didn't they know where Jimmie Maddrey lost his county cell?

**Mel Pino**: The arduini Doug Jacqueline bridge just got me kicked off Facebook for 24 hours

**Jeff Bergosh**: Off all of Facebook? Or just ECW?

**Mel Pino**: Facebook. Clearly they have a reporting tree going because the one they reported was me calling out arduini for having Steven's social. I did not violate guidelines but they are working the algorithm. Of course that post disappears also.

**Mel Pino**: Mike lowery sent this. Ecat circulating.

**Jeff Bergosh**: Wow

**Jeff Bergosh**: Where did he post this??

**Mel Pino**: They are handing it out on the buses

**Mel Pino**: It's a flyer they are circulating. 

**Jeff Bergosh**: To riders?

**Mel Pino**: On the buses and other places

**Jeff Bergosh**: Or employees

**Mel Pino**: Yep

**Mel Pino**: Riders

**Mel Pino**: It took a lot of guts for them to do this I am proud of them. With the way she and Tonya have been playing and burning at ecat.

**Mel Pino**: Union wants her Gone.

**Mel Pino**: Slashing and burning

**Mel Pino**: I just had it suggested to me that Fdle ought to investigate that records leak. Sounds right to me. 

**Mel Pino**: There's no settlement. She's lying.

**Mel Pino**: Brian Caro;s comment on ecw after he spoke

**Mel Pino**: Are you going to answer this nullshit???

**Mel Pino**: He is costing the taxpayers tens of thousands of dollars because he won't pay the records

**Mel Pino**: Staff doesn't all put their records into that system because they don't trust admin to fulfill them

**Mel Pino**: Some staff refuse to do it because they don't know if Janice fulfills them and their name is on it

**Mel Pino**: Janice has no business forcing staff to fulfill records through her office when the request runs directly to them. Then she never tells them when they are fulfilled

**Mel Pino**: When they are emailed a request it is on them and then they don't know if she fulfilled it

**Mel Pino**: What about staff? They are in the same situation

**Mel Pino**: Sorry it wasn't going to be on that. I wanted to talk quick about the Mac grant. I will call tomorrow

**Mel Pino**: Oh btw suddenly there will be an ecat settlement. On Monday. She's such a fucking liar.

### CONVERSATION ON 06-04-2021

**Mel Pino**: How ironic that the broke today. Rebekah Jones was awarded whistleblower by the IG against DOH and two different media sources reporting her text messages with moskovich and that the DOH was indeed hiding data from the public

https://www.miamiherald.com/article251838913.html

### CONVERSATION ON 06-06-2021

**Mel Pino**: Hey just a side note quick so I don't forget about it. Jacqueline is trying to get it going that we had some knowledge of what happened in the shade meeting when you guys came out, cause Kevin said "about what we expected." Of course we had no knowledge. We just saw that Underhill was in an awful mood and he 4 1'd it so we hoped that was a good sign for somebody we had advocated for. The extent of what we knew was anything anybody with eyeballs could have seen publicly during the vote.

### CONVERSATION ON 06-07-2021

**Mel Pino**: Somebody just sent this to me...I guess it's on ecw

**Jeff Bergosh**: Yes-- this email was sent to us last night; I already addressed it on a blog post early this morning 🙂👍

**Mel Pino**: 👍

**Mel Pino**: Posted. Call when you can

**Mel Pino**: Wondering about video

**Mel Pino**: Left u a voicemail

**Mel Pino**: Posted

### CONVERSATION ON 06-08-2021

**Jeff Bergosh**: In an all day conference today and tomorrow at NAS Pensacola

**Mel Pino**: That sounds so comparatively awesome...I want to be stuck in a conference where I can't answer the phone

**Mel Pino**: Janice just said before the TDC meeting "yeah we have money now to hand out." Don't know what it referred to but she said it passing the Mic so people could hear it.

**Mel Pino**: One of the people raising he'll right now

**Mel Pino**: Check the post I just made on Facebook.

### CONVERSATION ON 06-09-2021

**Jeff Bergosh**: On a conference field trip all day

**Mel Pino**: K thanks

**Mel Pino**: Check my Facebook on that cartoon when you have time.

**Mel Pino**: David's comment onmy Facebook  post. 

Kim Nicole I take the same position as you regarding women being bullied.  I have a mother, twin sister, wife, and a daughter.  Many of my closest friends are women.  I want to put this into context of the subject of this post.  I think this whole thing was fabricated. I don't know Pam's source of this information but it sure stinks of Underhill.  Underhill is not known for being honest or being respectful toward women.  He's known for creating disinformation/propaganda about people to redirect your attention away from the real issue.  Now, let's look at the night of this alleged misconduct.  Pam inserted herself into that meeting to show dominance.  The BOCC was finished with the discussion of the retirement topic and took no action to award the back-payment of the benefits.  Still, Pam felt obligated to tell them she didn't like it and wasn't going to write a check.  She went as far as to remind them she doesn't work for them or the county attorney.  That was a BOCC meeting, not a clerk of the court meeting.  She was out of order to even speak on the subject without signing up to speak, especially considering the discussion by the commissioners was already concluded. Pam's quote in the PNJ article lays out her intention of sending the letter.  She doesn't expect an apology but wants them to back off of considering terminating the administrator.  The scheduled discussion regarding the administrator's contract is irrelevant to her accusation of the alleged misconduct.  That is only reconcilable with her motivation to help retain the administrator so she can continue to keep her influence in the county.  With a new administrator, Pam may not be awarded such access.

### CONVERSATION ON 06-10-2021

**Mel Pino**: Who the fuck are her "readers" nice Freudian slip there.

**Mel Pino**: Can you please ask her where these slides are on the county website. The answer will probably be they aren't and she needs to be directed to share them publicly and not just to ecw.

**Mel Pino**: Omg this is fucking ridiculous

**Mel Pino**: He literally sounds hysterical.

**Mel Pino**: My god I cannot believe this woman is actually arguing to increase her bureaucrats overhead. It's shameless.

**Mel Pino**: So why is she arguing for management positions when we need people to pour concrete and dig ponds.

**Mel Pino**: Tagged you guys on a post about this on my facebook.

https://ricksblog.biz/county-loses-arbitration-in-union-prez-suspension/

**Mel Pino**: Also, please check the comment I made to Bryan Caro here:

https://ricksblog.biz/pension-debate-under-covers-another-gilley-goof/

**Mel Pino**: "There was no evidence or testimony presented that established that the Grievant had been given an order to work" that day. "There was no evidence presented that established that the Grievant was guilty of insubordination."

**Mel Pino**: Guess what? The next two actions they took on the three day and the five days were even worse than the first. How many times did Janice and Alison lie to you about this? And now she pretends that the union wouldn't come to the table. I hope you recognize that's all bullshit too.

**Mel Pino**: I don't know who this woman is, but I love her.

**Mel Pino**: Are you aware Edler is out?

**Mel Pino**: Gave her a chance to remain jail director which of course she declined.

### CONVERSATION ON 06-11-2021

**Jeff Bergosh**: No--but that's good news.  Did she quit, or get fired?

**Mel Pino**: Left you a voicemail.

**Mel Pino**: Posted

**Mel Pino**: Sorry had to correct a date that was actually a point of contention through their disinformation at the trial (they were trying to say I had it out for Edler from her arriving at the county when I didn't even know she existed).

**Mel Pino**: Oh my god Jeff I just saw your blog on the misdemeanors!!!!!! Thank you!!!!!!

**Mel Pino**: I wouldn't have been so sad when we talked it I had seen that. YEAH!!!!!!!!!!!!

**Jeff Bergosh**: 👍

**Mel Pino**: Posted

**Mel Pino**: Posted. Fyi I believe Jim little might be posting an article about the recent ems happenings today.

**Mel Pino**: https://www.pnj.com/story/news/2021/06/11/former-escambia-ems-chief-steve-white-felony-charges-dropped/7653642002/

**Mel Pino**: I just responded to jacquelines bullshit on your blog. Thank you Jeff for your response. But I have been waiting today that directly to her in a public venue for a very long time.

**Mel Pino**: If you can delete my double signature

**Mel Pino**: Sorry to be a pain in the ass. I made a bad typo they are going to run with. Could you delete that last one and put up the correction I just sent? 

### CONVERSATION ON 06-12-2021

**Mel Pino**: https://www.pnj.com/story/opinion/2021/06/12/editorial-escambia-commissioners-need-sunshine-after-voting-shade/7630604002/

**Mel Pino**: Worst hatchet job yet. And that's all it is. Remember, jim little has nothing to do with Lisa and Andy's anonymous crap. And I'm really grateful to him for that article on Steve.

**Mel Pino**: Posted

**Mel Pino**: Hey just a very random thought I had lost track of. I had a super nice discussion with Jay Ingwell at the meeting that night. I get the feeling those no votes are more of a protest of this ridiculous process being foisted on that board. He did not say that, but there was just something in his manner. He seemed more like his old self.

**Mel Pino**: Left you a voicemail no need for callback gonna get off the electronics

**Mel Pino**: Sorry I was out in the shop.

**Mel Pino**: Was just closing down my machine when this popped up. Glad I caught it.

**Mel Pino**: Edited.

### CONVERSATION ON 06-13-2021

**Mel Pino**: Sorry to bother you on a Sunday with this trash steven. but Underhill and Wendy are boundary breaking. Don't be surprised if they show up in a park where the kids play, at sonnys, the mercantile, etc. The equestrian center for an event. Not trying to scare you, this is.what they do. It wouldn't even surprise me if they barely had the gas money to get to Steve's farm from perdido, so they could just be messing. But beware anything wonky in an invitation and it goes without saying anything that Megan is setting up. That poor woman has cracked completely. 

**Mel Pino**: This stupid bitch! She doesn't take care that Alex arduini is being given documents with personal info and he's a QAnon nut detached from reality, which would be a concern to most normal people - especially after Jan 6th! 

**Mel Pino**: Fyi those are the comments coming into my phone about ecw's sustained meltdown.

**Mel Pino**: She is really completely around the bend.

### CONVERSATION ON 06-14-2021

**Mel Pino**: Left you a voicemail on that grant opp

**Mel Pino**: Now Jackie has dropped so low she is letting arduini use her forum to funnel follows over to his QAnon page. How the mighty have fallen.

**Mel Pino**: Posted.

**Mel Pino**: Holy crap check the Supreme Court ruling on PRRs I just tagged you on. What the? This is why whats his name from the county attorney mentioned that option to file records with the clerk, which I asked about but was never answered.

**Mel Pino**: At the TDC sunshine talk recently.

### CONVERSATION ON 06-15-2021

**Mel Pino**: Told ya. 

**Mel Pino**: https://ricksblog.biz/childers-finds-hr-error-excess-contributions-to-retirements/

**Mel Pino**: Check my comment here

https://ricksblog.biz/mayor-stumped-why-county-not-collaborating-on-homeless/

**Mel Pino**: https://weartv.com/news/local/transit-union-votes-no-confidence-of-escambia-county-administrator-gilley

**Mel Pino**: Check email on that grant when you can. Nothing urgent.

### CONVERSATION ON 06-16-2021

**Mel Pino**: (Mike can't engage in politics but he finds a way to join the party once in a while) 

"The struggle itself to the heights is enough to fill a man's heart." Camus, The Myth of Sisyphus

**Jeff Bergosh**: LOL

### CONVERSATION ON 06-17-2021

**Mel Pino**: Alison will you please accept this as an official public record for Doug's pension docs. I would appreciate receiving them at your earliest convenience.

**Mel Pino**: Will you PLEASE put a stop to this

**Mel Pino**: And mention he is being SUED for this

**Mel Pino**: Text message betwee Rayme Edler and Matt Selover after she called him to that difficult scene where the city police could not get him under control. Matt was requested because he is strong and he left one scene and raced over there. She instructed ketamine and see her response when he told her it worked.

### CONVERSATION ON 06-18-2021

**Mel Pino**: Sorry I was on the phone with Teresa Hill in Colorado on this bullshit arduini is running

### CONVERSATION ON 06-19-2021

**Jeff Bergosh**: Do u have screenshots from social media pages demonstrating this allegation that someone took a picture of your private text messages and published them online?  If so, please forward to me I am looking into this!

Jeff Bergosh 

**Mel Pino**: Yes I will forward to you in email. I sent it to chip also

**Jeff Bergosh**: Thx

**Mel Pino**: Sent

**Mel Pino**: Please listen to the voicemail I just left as soon as you can. The county continues to harass Matt.

**Mel Pino**: Can you read that?

**Mel Pino**: Resent it via email

**Mel Pino**: Resent the attached image. Our internet is shaky because of the phone

**Mel Pino**: Hey wanna post the transcript of the shade meeting? They are all slobbering over it as Doug pretends he doesn't have it hahaha

**Jeff Bergosh**: I don't have it yet

**Mel Pino**: Oh he's not lying then.

### CONVERSATION ON 06-20-2021

**Mel Pino**: Good morning, horrible time to get I know. So sorry. Just please when you can get the responses up on arduini dangerous price of garbage on that female professor. I sent a security alert to the Kennedy school about it.

**Mel Pino**: If the local authorities are going to disregard the law, maybe they will do something about him from up there.

**Jeff Bergosh**: I just did a post on the screen shot scandal.  Plus I posted all the comments in moderation

**Mel Pino**: Thank you happy father's day Jeff. Check my Facebook for the first time I have "celebrated" fathers day since my dad passed. He was a real SOB but he was my dad, and he made me what I am for better or worse. Obviously this isn't public record.

**Jeff Bergosh**: Yes of course, and thank you!

**Mel Pino**: I'm trying to get a response down to the word limit. Almost done.

**Jeff Bergosh**: Ok

**Mel Pino**: Posted. Have a great day Jeff and THANK YOU. This only gets worse from here. These people are relentless.

**Mel Pino**: Last thought; that's interesting on the "seen" not intercepted. 

**Mel Pino**: And it's wrong.

**Mel Pino**: Posted DOJ definition.

**Mel Pino**: I hope Sally gets a good laugh over that last comment. These people will stoop to any level. Pretty sure she knows exactly what I'm talking about and agrees entirely.

**Mel Pino**: Ok made on last post and I am sitting the media down for a while.

### CONVERSATION ON 06-21-2021

**Mel Pino**: From Kevin: Put it this way.. when Arduini is not dressed 100% as a oath keeping 3٪ proud boy he is wearing tactical branded conceal carry 511 shorts and vertex conceal carry shirts

**Mel Pino**: Escambia oublic forum, 45 minutes ago. The most Q of all the local forums, although ecw and politics/issues are vying neck and neck for a close second.

### CONVERSATION ON 06-22-2021

**Mel Pino**: Posted.

**Jeff Bergosh**: Got it

**Mel Pino**: Thank you Jim. So good to finally see that record set straight. I have only ever asked that media get the facts straight. I know it has been difficult this is such a Gordian knot. A lot of us really appreciate the efforts and the truth. It's in such low demand these days.

**Mel Pino**: He corrected it. Check the update

**Mel Pino**: He straightened out the timeline and changed the word "alleged" to "stated."

**Mel Pino**: (I called and spoke with him and sent him the corroborating docs)

**Mel Pino**: It's World war III over there hahaha

**Mel Pino**: My favorite is "and you with all those god photos, MF FU"

**Mel Pino**: Hahaha sorry had to share that. 

**Mel Pino**: This sent public record because it's about my case.

**Mel Pino**: "I slandered a judge but I'll go ahead and let it stand"

### CONVERSATION ON 06-23-2021

**Mel Pino**: Hey listen to my voicemail when you get a chance. The personal appearance stuff on Jacqueline is really going to far.

**Mel Pino**: I just heard Charlie Peppler is going to the city

**Jeff Bergosh**: Check my blog

**Mel Pino**: K

**Mel Pino**: Oh my god Jeff that is amazing. I'm so proud to call you my friend. You did the right thing, in every way.

**Jeff Bergosh**: Thx!

**Mel Pino**: What a fucking mess.

https://ricksblog.biz/buzz-musical-chairs/

**Jeff Bergosh**: It'll be alright

**Mel Pino**: Posted

### CONVERSATION ON 06-24-2021

**Mel Pino**: Posted back to Bryan Caro.

**Mel Pino**: Holy shit she already has people and money. And the National donations are going to pour in.

https://www.rebekahjonescampaign.com/

**Mel Pino**: Poor Phil Ehr haha

**Mel Pino**: Hey did my posts not come through?

**Jeff Bergosh**: I just finally came up for air I got home from work and had a chance to look at them and approve them all

**Mel Pino**: Oh that's right so sorry forgot you are moderating for that now. Thank you so much Jeff.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-26-2021

**Mel Pino**: Check my Facebook.

**Jeff Bergosh**: 👍

**Mel Pino**: Posted.

**Mel Pino**: They just put it up on their Facebook page. I put the same comment there.

### CONVERSATION ON 06-27-2021

**Mel Pino**: Where in the FUCK are they getting the money for this.

**Mel Pino**: Provisioning or medical marijuana farm.

**Mel Pino**: Posted back on the ecw bullshit and then a serious two parter to Bryan Caro. His back and forth is helping me engage in serious conversations about EMS and that is very helpful to them with the traffic your blog getting.

**Mel Pino**: Posted back to Tom Jardine.

### CONVERSATION ON 06-28-2021

**Mel Pino**: https://apple.news/AdZeWLSVoRLSZUSnkpnIsng

**Mel Pino**: https://www.reuters.com/technology/us-judge-tells-ftc-file-new-complaint-against-facebook-2021-06-28/

**Mel Pino**: Hahahaha jumpsuits. Facebook just hit a trillion

**Mel Pino**: Hi Grover, we just delivered the leftover food from Kevin marchetti's memorial to the I 10 encampment. My god those people are hungry. Thirsty. And clearly low on iodine from the way everybody went for the shrimp first even over the pizza. OPEN CALEB'S SHELTER on Davis and quit pandering to big money! This does not have to be and "or." It can be an and.

### CONVERSATION ON 06-29-2021

**Mel Pino**: Posted

**Mel Pino**: Call me when you can. Will need about fifteen to lay something out.

**Jeff Bergosh**: Will do-- stacked up in mtgs

**Mel Pino**: It's not a rush.

**Mel Pino**: Hey it dropped. Call back when you can.

**Mel Pino**: And there you have it. He has ownership in a hello a lot more with that. I don't know why he had on a "make Lumber cheap again" cap...theyjust steal it from their customers anyway. Man I want to see this guy go down in flames.

### CONVERSATION ON 06-30-2021

**Mel Pino**: https://ricksblog.biz/bizarre-childers-sighting/

**Mel Pino**: https://ricksblog.biz/bus-union-prez-wins-another-arbitration/

**Mel Pino**: Check my comment on that last.

**Jeff Bergosh**: Will do

**Mel Pino**: Man Jana still and the county attorney fucked up another one BAD. I hope you see now I wasn't exaggerating on how bad it was. They were doing this all over the place Jeff.

**Mel Pino**: Janice and Jana literally   thought they could just do whatever the he'll they wanted. The didn't think any policy or law applied to them. With the county attorney helping cover for it. It's insane.

**Mel Pino**: And lying like Rugs to you about it repeatedly.

**Mel Pino**: https://www.pnj.com/story/news/local/escambia-county/2021/06/30/escambia-county-looks-uf-ems-medical-director-dr-rayme-edler/7796172002/

**Mel Pino**: This is the most amazing good news in forever. I am so impressed with the new Ems chief and Eric's plan is so solid and we'll thought out. The EMS are so excited and everybody has a lot of hope for the first time in a long time.

**Mel Pino**: Thank you Jeff. I know you may think this is an exaggeration, but I honestly believe that working together we saved Escambia EMS. 

**Jeff Bergosh**: I think we've definitely helped to do so!

**Mel Pino**: 😊

**Mel Pino**: Matt selover's new baby girl. Please keep this close, Jeff, but Judith miscarried twice over the stress of the last couple of years. New day :)

**Jeff Bergosh**: Please tell him congrats for me!!

**Mel Pino**: Well I think you could technically tell him yourself :) it's not about Litigation or county business. I know it would mean a lot he thinks the world of you.

### CONVERSATION ON 07-01-2021

**Mel Pino**: Posted. Call when you have a few want to touch base on something.

**Jeff Bergosh**: Will do

**Mel Pino**: Hey that's more great news that bill they passed on a state level NO anonymous code calls. Animal control and code will have S0 much less crap to deal with and Jonathan owensjust lost one of his favorite tools in his Arsenal hahaha

**Mel Pino**: Posted back to Caro.

**Mel Pino**: Oh and hey, one other thing: told ya trump was going to jail :)

**Mel Pino**: Did you see the triumph award to IHMC?

**Mel Pino**: Another one of jacquelines theories shot to shit.

**Jeff Bergosh**: He's not

No I didn't see it

Which theory of Jacqueline's --- they're all SHIT?

**Mel Pino**: You are going to owe me one huge steak. The theory that the county wouldn't get any more TRIUMPH because of ST. Day you guys put shovels in ground on titan studio 850 just broke more triumph money coming hahaha

**Jeff Bergosh**: LOL that's awesome!! 

**Mel Pino**: Right??? 

**Mel Pino**: Doug opened up his commissioner Facebook page. I PRRd him for his retirement benefits.

**Mel Pino**: Posted one last happy for the day under the ST blog.

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-02-2021

**Mel Pino**: Hey before I loose track of this. This is the sidenote we were talking about briefly. On medical billing there are multiple written emails reprimanding that she stop messing around and get cracking on that software, with multiple response that the focus needed to be elsewhere.

**Mel Pino**: Not trying to be a downer...Mike sent this so forwarding along an FYI. I doubt anything will put us back in masks in Escambia. Mike and I are probably going to get the moderna on top of the J and J, which is only 65 percent effective in the countries that have their shit together and are actually tracking solid data. We could have another setback following the Fourth is the point, so just passing this along before I lose track of it.

Ok, here is a pretty decent summary of the best insights from the Trevor Bedford ( who co-developed Nextstrain, a data platform used by the World Health Organization that tracks virus outbreaks ). 

(1) The number of people infected with the Delta variant has sky-rocketed in four US states:  Missouri, Utah, Colorado, and Arkansas

(2) Bedford showed the calculations behind predicting a Delta outbreak, with the parameters of number vaccinated, number wearing masks, and other community spread variables. Delta will move faster than Alpha
 
(3) Epidemiologists looking at Deltas impact on Singapore, UK, Israel, and Canada suggest that this could put us back in masks by the third week of July.

https://twitter.com/trvrb/status/1410376325303468040?s=20

**Mel Pino**: For later.  An amazing piece that nails exactly what the hell the problem in this country is right now.


https://www.baltimoresun.com/opinion/op-ed/bs-ed-op-0705-brooks-destroy-truth-20210702-6cn7poqvovgfnocf2n2zjxlw2u-story.html

**Mel Pino**: Also rethinking earlier convo. Social media deader than a doornail today. People already completely checked out. Talked with Lumon and people are heartbroken over the shooting. Probably better to wait until before the meeting

### CONVERSATION ON 07-03-2021

**Mel Pino**: Posted. Really happy at being in a process with coming to peace with what has been and looking forward to what's to come. As difficult as a lot of it will be.

**Mel Pino**: And one more post, a fun one this time.

### CONVERSATION ON 07-06-2021

**Mel Pino**: Looks like Nick is finally getting that the disinformation on ECW isn't helping. 

**Jeff Bergosh**: In mtg will call u back

**Mel Pino**: It's nothing urgent. Just a catch up.

**Mel Pino**: Posted twice.

**Mel Pino**: From a source. 

She was messing around with several
People from EMS. Apparently maddrey, hoopaugh, and several firefighters. Guy Meredith is one of them. 

**Mel Pino**: I think Lindsey ended up putting in a complaint against maddrey? 

**Jeff Bergosh**: Wow

**Mel Pino**: And there are probably text messages between Lindsay and firefighter Guy Meredith. He went so far as to set up a house and she was supposed to move in with him but backed out. I would be very surprised if Lindsay didn't have MULTIPLE spread sheets and as I understand it there were purple firefighters she was having sex with.

**Mel Pino**: Again, don't care except I would be very surprised if it wasn't happening with them on county property and during work hours. The woman never put in a whole days work. She was non-stop trouble for Kate as a supervisor but she couldn't do anything about it because she was under edler's protection. Until she flipped on her and got her canned.

**Jeff Bergosh**: Purple firefighters LOL??

**Mel Pino**: Sorry spellcheck haha they might have been purple after she was done with them. It was supposed to be multiple firefighters. Lindsay could be the nexus that blows all of this wide open. Somebody in the know said you should ask for her text messages with guy Meredith first.

**Mel Pino**: Jeff do you understand how WRONG it is that numerous county leaders knew about all of this and shoved it under the rug and got innocent people arrested instead. They KNEW, Jeff.

**Mel Pino**: Lindsay Ritter fucking lied under oath in every damn interview she didm

**Mel Pino**: Those ems people have been the targets of these fucking liars for two years running and got put in jail for it.

**Mel Pino**: Posted

**Mel Pino**: Sorry, had to PS that because I want the whole picture in one place.

**Mel Pino**: "Special services" hahahaha

**Mel Pino**: Are you editing or removing?

**Jeff Bergosh**: Based upon a written apology I received from Bryan Caro just now---- I have moved it to draft status which removes it from the public view. But I have not deleted it nor would I --/because it's a public record. Meanwhile,  Channel 3 has made a formal public records request for the 11 page document based upon my blog post.

**Mel Pino**: My phone is blowing up wondering what happened to it. Should you make a post that you removed it because you and Bryan came to an understanding? Something simple and classy. Shows you have a heart. They'll make up shit about it otherwise, also. I think people need to understand that if they act like jerks, they will be treated like jerks. And that if they are reasonable there will be reasonable consequences. I wouldn't say "because he apologized" though they will turn that into power tripping. But just a nice statement that you talked like men, which is what should have happened in the beginning. Maybe Nick will take the hint. Doubt it though.

**Jeff Bergosh**: I pulled it because everyone is in fear that Ritter's husband will get violent

**Mel Pino**: Right. Everybody is asking where it went and why. You might just make a simple statement that you spoke with one of them and came to an understanding and honored the request to take it down. It's a class act, Jeff.

**Mel Pino**: Even though I'm super bummed my comments went away and nobody believes Lindsay on her abuse stories, you still want to err on the side of caution in that.

### CONVERSATION ON 07-07-2021

**Mel Pino**: Just put up my magnum opus on the entire EMS shit show. If people don't believe me at this point, they never will.

**Mel Pino**: Hey I left you a voicemail but it's nothing urgent. On retirement benefits.

**Jeff Bergosh**: On admin call

**Mel Pino**: No worries. 3 quick catch ups

**Mel Pino**: I think Jana still got fired.

**Mel Pino**: Lmk if you confirm that. Well, resigned.

**Mel Pino**: Doubt if you are still up, but if you are please post what I just put up.

### CONVERSATION ON 07-08-2021

**Mel Pino**: Communications lost the video during the Dpz discussion right after you said no more Dpz.

**Mel Pino**: NICE. JOB.

**Jeff Bergosh**: Thx

**Mel Pino**: Hes trying to keep Clerk out of the appropriations business.

**Mel Pino**: Jeff sometimes people literally can't afford to claim the body.

**Mel Pino**: Also sometimes the family plays politics and people who would pick it up aren't authorized. I tried to help a woman with a situation like that last year. The new wife wouldn't let her pick up her dad's body :(

**Mel Pino**: This county jail doesn't provide SHIT for medical care. I know somebody they let his face rot off with skin cancer. They don't even give antibiotics for bladder infection at the work release. I'd like to know where all that fucking money goes.

**Mel Pino**: I would love to know where all that money went because it sure as HELL isn't going to medical care there.

**Mel Pino**: She is so full of shit I can't WAIT to get up on LET funds hahahahaha

**Mel Pino**: The federal grants require full size engines under the American steel grant as well. So if it's a grant sometimes there isn't anything they can do.

**Mel Pino**: Not politicking for ecat that's just the facts unless it changed

**Mel Pino**: But maybe it comes out in the wash with a better holistic plan.

**Mel Pino**: Oh that's awesome. I didn't know they allowed latitude on grants or the steel act.

**Mel Pino**: From the independent research I did on that it seemed like a racket to get government to buy overpriced trucks from particular companies who could afford the American steel. Great to know there is room to work.

**Mel Pino**: She is so full of shit.

**Mel Pino**: Damn her

**Mel Pino**: You are the bomb, Jeff. Great meeting and thank you for Matt. I am going to be speaking to that item but not coming on fire or anything. Jacqueline is already rabble rousing on him on Ecw.

**Mel Pino**: Doh starting covid testing again next week with or without symptoms. At DOH on Fairfield Mon thru Thurs 9 - 1

**Mel Pino**: How much more money are you guys going to allow this asshole to waste?

**Mel Pino**: This is setting me up nicely for what a horror show the medical in that place is.

**Mel Pino**: Hey I forgot I was supposed to lay this out for you in detail. Basically you won't be surprised to find out Janice lied to you repeatedly about what happened during blue collar negotiations

**Mel Pino**: If you guys could get concurrency and stop this clear cutting half of your agony up on the dais would stop. We cannot keep cutting down trees like this and think that we aren't just going to make our flood and drainage problems worse and worse.

**Mel Pino**: He thinks of the county as home. :) love the sound of that.

**Mel Pino**: Doug is trying to set Jana still up for a lawsuit. Good luck with that.

**Mel Pino**: He didn't even read the agenda backup on items in his district.

**Mel Pino**: Remember when I got up on this change last year and asked what the impetus and rationale was, and we had a first call at all?

**Mel Pino**: Ask him how much of his discretionary he is spending on the inlet management plan dredge to gift condo owners with beach

**Mel Pino**: Without classifying it as nourishment

**Mel Pino**: Thats all well and good that there are people abusing the system. What aboutthe people who aren't getting decent care because they don't offer it.

**Mel Pino**: Read the statute

### CONVERSATION ON 07-09-2021

**Mel Pino**: Hey sorry I missed you. Just now seeing your blog. I spent the day with Matt and Judith Selover and their new baby :)

**Mel Pino**: Posted. You know what I just realized? I do not trust Bartlett or bender on not having insurance for Selover. 

**Mel Pino**: Not one bit. Either would conveniently not look to hard to tank it.

**Mel Pino**: And if we don't have insurance for our medics, it's benders fucking fault.

### CONVERSATION ON 07-10-2021

**Jeff Bergosh**: Andy's offering today LOL

**Mel Pino**: Omg how many ways can a cartoon fail. That's wo stupid with the faces on the side. And he will NW tone deaf to the end. Ecw can chew that til their gums are bloody while everybody else ignores it

**Mel Pino**: Hey I left you a long message on a wrap with some things no need for a call back. I was leaving it on the thought that I am going to be iron clad on all information going into this meeting on Thursday. I hope you will have a reasoned, matter of fact blog post on the materials from the shade meeting etc. When that wraps - can finally have the transcripts on the depos as well. They are setting it up that there is some communication that was made by the insurance company says it couldn't support going to court because of your statements. Make sure you've seen everything Doug has had access to. I don't trust them farther than I could throw them.

**Mel Pino**: Check my comment to Andy on the PNJ site

**Mel Pino**: Posted

**Mel Pino**: Oh no!!!!!!!!!! Don't do it hahahaha seriously, just let them go down in a ball of hate over on Ecw. It doesn't matter any more

**Mel Pino**: But if you do you need to add ecw cheerleaders on top of the balloon. They just said they only thing missing from Andy's is a crazy cheerleader on top of the blimp. I am NOT encouraging this though hahaha

**Mel Pino**: I just know you might not be able to help yourself even though I think you should

**Mel Pino**: Actually if you do it you should superimpose Doug and jaqueline photos on the blimp. Not THAT would be effective jujitsu 

**Mel Pino**: Don't even come back on the PNJ turn the tables on douggites and thank Andy for the vehicle.

**Mel Pino**: Just leave the Pnj totally out of it it will drive Andy nuts. Change the caption to normal people having fun at blue angels and saying "get out of the way that hate balloon is gonna blow""

**Mel Pino**: "Oh no! Look out below! The hate balloon just crashed the show!"

**Mel Pino**: "Oh no! Look out below! The hate balloon is gonna blow!" With Jacqueline and dogs face on it and a flying monkey cheerleader on the blimp.

**Mel Pino**: You wanna really get to Andy, ignore him and use is cartoon to attack his allies. 

**Mel Pino**: Check Pm.

### CONVERSATION ON 07-11-2021

**Mel Pino**: This is from a friend in the context of us talking about the growing problem of that nutjob chance johmeyer and his Recall Florida movement that is picking up steam again.  They are represented in all counties and claim that they have a senator to run the bill. They have met with Jayer and are leaning on him to run it in the house. They are recruiting online and have 3000 plus people now and are whipping people into a lather and raising the rhetoric. They are also recruiting people through the evangelical churches here. Not sure if you are aware this is a nationwide problem of Q taking over churches but the problem is very bad in the state of Florida. Some pastors are struggling to fight back against it but the parishioners just leave to go to a Q pastor. I'm not trying to raise an alarm that something is imminent but it does need to be on people's radar. 
-------
He said something to underhill this morning on ECW that bothered me so I dug into his fb profile a little bit. He deleted his comment to underhill before I thought to take a screenshot of it. But He said "since we the people own the building where the meetings are held, pay the power bills etc, can we hold our own meeting and force the Commisioners to attend." 
I clicked on the laughing reaction and within seconds he deleted it. 

It was a real odd thing to say 

**Mel Pino**: This is me talking not my friend. Johnmayer and arduini hooked up with relevant life church and some others. One of them was even down in navy point in a van recruiting and came to my door with Qist "religious" propaganda and big smirks on their faces. I can't remember what the name of that one was.

**Jeff Bergosh**: Freak jobs

**Mel Pino**: It only takes one with a gun, Jeff. And these people are being whipped into a frenzy. I'm not concerned about them getting five hundred people down there. I'm concerned about the possibility of just one whack job.

**Mel Pino**: Posted

### CONVERSATION ON 07-12-2021

**Mel Pino**: Posted again, on me getting paid. That's going to be one of their constant strains.

### CONVERSATION ON 07-13-2021

**Mel Pino**: https://www.news-journalonline.com/story/news/courts/2021/07/12/jury-trials-suspended-volusia-st-johns-putnam-county-covid-rises/7925099002/

**Mel Pino**: So to put that in perspective, our reported positivity in Escambia was 10.2 percent in Escambia already last week, and anybody with common sense knows that was probably low due to the shit tracking in this state. I hope the judges can at least get something done to make the courthouse safe. They were the only ones to have any impact in the county the last time around.

**Mel Pino**: It probably goes without saying, but FAC and downtown are in a concerted effort to beef up Doug's PR because he is second to Robert in getting a bogus FAC search in here for an administrator who will fall in with whatever downtown wants.

https://www.pnj.com/story/sports/2021/07/13/racer-bret-underhill-teaches-kids-through-junior-stars-florida/7932374002/?utm_source=pnj-Daily%20Briefing&utm_medium=email&utm_campaign=daily_briefing&utm_term=list_article_headline&utm_content=1063NJ-E-NLETTER65

**Mel Pino**: They just need a third.

**Mel Pino**: They just need a third.

**Jeff Bergosh**: Yes I saw this earlier.  And just wait for it, in the business section of the Sunday paper under the "locals on the move" section they will feature Doug, Robert and Doug's Secretary Jonathan on their achievement of the FAC "merit badge" of achievement..........

**Mel Pino**: Yep.

**Mel Pino**: Man, you are putting yourself out on a dead limb with that post. You had better hope you are right. People will have a field day with the bravado if it smacks us here again hard. As for believing the anecdotal hospital accounts--yeah, right. Maybe you could still get Faulkner on to do another round of lies about it so they can keep cramming electives in as long as it will hold.

**Jeff Bergosh**: Read last five sentences carefully

**Mel Pino**: I read I Jeff. It looks to me like deja vu all over again. I'm glad that I have made peace with stepping out of any attempt at counteracting the GOP covid show. Just gonna sit back and watch for the most part this round. It's all gonna redux just like the last time around. Only question is how bad it's going to get--who knows. I haven't seen anybody going crazy on what's happening right now. Just people realizing that whatever does happens, it wont be addressed by county leadership. You know it and I know it. That horse has left the barn.

**Mel Pino**: https://secure.winred.com/ron-desantis/storefront/drink-a-beer-red-beverage-cooler-set-of-2/detailshttps://secure.winred.com/ron-desantis/storefront/drink-a-beer-red-beverage-cooler-set-of-2/details/

**Mel Pino**: Ron DeSantis anti mask cookies.

**Jeff Bergosh**: We disagree on this

**Jeff Bergosh**: Hey that's OK this is America! We can disagree and not hate each other I hope

**Mel Pino**: Ron DeathSantis anti mask koozies, brought to you by his campaign paraphernalia store.

https://secure.winred.com/ron-desantis/storefront/drink-a-beer-red-beverage-cooler-set-of-2/detailshttps://secure.winred.com/ron-desantis/storefront/drink-a-beer-red-beverage-cooler-set-of-2/details/

**Mel Pino**: No Jeff, I could never hate you and am in fact very fond of you. But please don't lose track of the fact that gop elected officials who blocked any effective response were some of the first people to be offered vaccines. Many, many people had needlessly died before they were able to get one. So I just hate to see you being glib about it. It's just really not a good look.

**Jeff Bergosh**: 👍

**Mel Pino**:  Check my comment here:
 https://ricksblog.biz/clerk-having-trouble-collecting-bed-tax/

**Mel Pino**: From Marcel Davis.

Okay COVID is back on the raise here in Pensacola, Fl. this morning a hospital had two Covid patients they are now up to 10  two more holding in the ER. Stay safe out there.

### CONVERSATION ON 07-14-2021

**Mel Pino**: Just posted back to Aunt Peacock.

**Mel Pino**: Oh crap too long give me a sec

**Jeff Bergosh**: 👍

**Mel Pino**: Done. Fyi I checked out of Facebook for a bit. Deactivated. Tired of the crazies and the mob mentality. Will still be doing you and Rick's blog and William of North Escambia.

**Mel Pino**: Jeff, let me remind you that I told you all this was coming the week hammer dropped his design plans for olf8 onto ecw. I didn't know what form it would take, but I knew there would be an area world war within two to three years.

**Mel Pino**: And yet you still think I'm a conspiracy theorist haha

**Jeff Bergosh**: Is she your enemy?

**Mel Pino**: She is everyone's haha

**Mel Pino**: Oh wait, you do know she is going to run for D2 if her house gets redistricting?

**Mel Pino**: https://ricksblog.biz/county-budget-buzz/

**Mel Pino**: Last one and I'm headed out into the yard. I'm not sending this out of "hysteria." It's out of awareness, and so that you understand I don't make shit up, and am not prey to leftist news sources. Just because I tell you something fox hasn't reported, it doesn't mean it's not real, Jeff. This thing could get very bad in the child population. I'm not saying will. I'm saying could.

https://abcnews.go.com/US/mississippi-health-officials-warn-delta-surge-12-children/story?id=78828192

**Mel Pino**: Don't miss this quote from a doctor: "we have had more pediatric admissions than we had early in the pandemic."

**Mel Pino**: https://www.businessinsider.com/norwegian-cruise-ceo-florida-covid-vaccine-frank-del-rio-2021-5

**Mel Pino**: Posted on being kicked off Facebook.

**Mel Pino**: Kevin's ceiling in laundry room.

### CONVERSATION ON 07-15-2021

**Mel Pino**: Just posted urging folks to get attuned to policy. It would be great if we could get some serious commentary from these smart new voices there.

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-16-2021

**Mel Pino**: I am going to forward you a string I am$ sending to local leaders with a brain in their heads. I hope you will forward to Gary. People need to be aware of this.

**Mel Pino**: I guess it would be prudent to say in every awareness text I send out about this stuff "this is not a high level orange alert this is just about awareness because these people are increasingly cracked, flirting with insurrectionist language, calling around cloak and dagger and saying their lives are in danger from the corrupt commissioners, and rubbing elbows with the white supremacist militia groups the feds are starting to make arrests on. Probably nothing will happen from this group! I get that. But it bears watching. Nonetheless because this is the particular nexus that is encouraging confrontation with the board and with particular individual commissioners and using nasty animal kingdom metaphors, Q crazy talk, and blending it with mild language about violence that then whips people into an online lather. Like I have said. I am more concerned about a lone nut job and this chance asshole is encouraging people to hunt down their commissioners in a " man on the street style" and demand answers about their corruption and money.

**Mel Pino**: This recall Florida shit and its local head whack job chance johmeyer have their toe in the water and are egging other people to take a bad turn. Jacqueline is too stupid to understand all the ramifications and increasingly disconnected with reality.i 

**Mel Pino**: He has now put up a post about me and my whateverheseesitas alerting people that the vipers are loose with a photo of rattle snakes mating. Then he was on to a tangled web spider post demanding people hold their elected officials accountable for their lies and corruption. Now he is on to bees and telling people to do to the commission what the nest of bees did to him this morning (rise up and sting them). He is also calling around all cloak and dagger asking people for secret meetings saying that "his advisors" are telling him that since he is going at the finances of crooked politicians his life will be in danger and he needs to be very careful. 

**Mel Pino**: People are sending me one off comments from around social media from local goons and fake accounts that are encouraging people to rise up in varying degrees of rhetoric. Last thought for now. Again, this is nothing different than is happening all over the country right now but the local concentration of people who believe the big lie is pretty high compared with some other places. Yesterday Mike saw a bumper sticker "stolen elections have consequences" with all sorts of right to bear arms stickers on the back of the truck. Reminder: I am a firm proponent of gun rights and am sick to death of regular citizens not being allowed to carry into government meetings.

**Mel Pino**: I even sent the following to Nick, because NO, as in ZERO, county connected people should continue posting to that forum with how it is spinning out of control.

 am sending you that string as a courtesy, Nick. Some day you will figure out that I have never been politicking you, that I have not offered bad advice, and that the advice I have offered was not for my own gain. Ecw is a pariah now anyway...there is nothing left to be worried about per their political effectiveness. I am trying to help you understand the context people are watching with anything that goes up on that forum. You guys can choose whether it's still an effective place to be posting.

**Mel Pino**: Alison opinion on Matt not being able to have a second opinion and how his only recourse is to take to court.

**Mel Pino**: Posted

**Jeff Bergosh**: 👍

**Mel Pino**: That's it. Nothing to be concerned about, just wanted you to know the impetus is pointless complaints go flying.

**Mel Pino**: This is not a hysterical call out. We have been well aware this was how this was going to roll for two months and have just been waiting for it to hit here, enjoying a reprieve of some social interaction before we had to take measures again. And I have zero plans to try to impact anything this time around. Been there done that.

**Mel Pino**: Please keep this close. This is Meredith Crawford's friend who had the j and j. Even though moderna is more effective, people are still having breakthrough infections where they are this sick. Also note the ER refusing to do the test. Because the hospitals are already full on jacking with data.

**Mel Pino**: https://www.newsweek.com/missouri-florida-hospitals-discussing-overflow-care-covid-patients-amid-increases-1610660

**Mel Pino**: Thats why I was saying not a good tack to be glib about this. When you say "well it's just the unvaccinated" that is sixty percent of Escambia county.

**Mel Pino**: And that is only 18 and older percentage. Doesn't count 0 to 17 where of course the percentage of vaxed is zero.

### CONVERSATION ON 07-17-2021

**Mel Pino**: Hey posted and mentioned maybe you would answer on that question on interference ordinance as I do NOT want to start speaking for you in that space, or even the hint of it.  If you have time and thoughts, I really think people like it when you come back in and dialogue in the comments section when it's something worth your time. Even if it's just a short response.

**Mel Pino**: Left you a longish voicemail on a couple of heads up no need for a call back

**Mel Pino**: Sharing fun stuff. Kevin's ceiling almost done. Can't wait til that ugly vent is replaced.

**Mel Pino**: This is horrendous and their board is viewed by and increasing number of people to be totally renegade and out of control. You might have seen one of their planning board members quit in protest and will start advocating against them. No joke that if you guys want to be instant and justified heroes, position yourselves against this crap and start moving in the direction of what the majority of you constituents want rather than the builders. I recognize that is tough, but the decisions you make right now will decide what our county and neighborhoods look like no just in the next five years but in the next 20, 50, and 100. 

https://www.pnj.com/story/opinion/2021/07/08/santa-rosa-county-clear-cutting-goes-against-residents-wishes/7890840002/

**Mel Pino**: Check email when you have time.

### CONVERSATION ON 07-18-2021

**Mel Pino**: Underhill: David M. Bear you are obsessed. You just never imagined an elected official would have the nerve to not be impressed with you and your family money. Just out of curiosity, did you take Mel to the mountains with you, or did you leave the pets at home?

**Mel Pino**: David's response: Douglas Underhill Hahaha. I guess you never imagined someone would not fall for your lies. Someone you have no control over and can t manipulate. 

Speaking of obsessed: Does your wife know you re thinking about Mel and where she is right now?

### CONVERSATION ON 07-19-2021

**Mel Pino**: Call me when you have time so I can pitch my award winning, solve 75 percent of the problems at the county idea and I can explain to you for the thousandth time what a genius I am.

**Mel Pino**: That's a joke :)

**Jeff Bergosh**: LOL will do

**Mel Pino**: Eric m lipman  general counsel of Florida election Commission arrested on 11 charges counts of child pornography.

**Mel Pino**: Indicted not arrested

**Jeff Bergosh**: Wow!

**Mel Pino**: Tip of the iceberg I hope. Feds fanned out all over florida

**Mel Pino**: https://www.pnj.com/story/news/local/pensacola/2021/07/19/pensacola-there-hope-homeless-shelter-get-100-000-city/7984852002/

**Mel Pino**: One more check box in my advocacy goals. :)

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-20-2021

**Mel Pino**: Hey if you have time before budget call me as my brilliant genius idea has to do with that. :)

**Jeff Bergosh**: Okay will do

**Mel Pino**: Just an fyi

**Jeff Bergosh**: Thx

**Jeff Bergosh**: He has no sway in that decision.  None at all

**Mel Pino**: I'm just forwarding stuff I see. He is totally out of control in every way.

**Jeff Bergosh**: Yep

**Mel Pino**: And out of the gate with Robert's bullshit

**Mel Pino**: Along with Amber refusing to answer questions

**Mel Pino**: That's bullshit on the pc's

**Mel Pino**: Why is American relief act not this year even though it deals with next year also?

**Mel Pino**: Nice threat on coming to the county for her whole salary

**Mel Pino**: Remember those SRO's can come from let by AG opoinion

**Mel Pino**: Aren't they just two peas in a pod.

**Mel Pino**: Longevity bonuses should be in the mix. We have to retain. Merit is good but it also get played favorites with. 

**Mel Pino**: I love her.

**Mel Pino**: People can be on their high horse about it Jeff but chain smoking is about the only thing keeping some staff on their feet at this point. 

**Mel Pino**: People can be on their high horse about it Jeff but chain smoking is about the only thing keeping some staff on their feet at this point. 

**Mel Pino**: Just chilled for clerk, HR, and budget

**Mel Pino**: Maybe the administrative contract should have been terminated for the simple cause of "can't count to three."

**Mel Pino**: And.....here comes Pam.

**Mel Pino**: And.....here comes Pam.

**Mel Pino**: Says who? According to whom is maximus the new top dog.

**Mel Pino**: I know sometimes you think I'm nuts. This isn't to rub it in. It is this moment right now that I was screaming from the mountaintops was going to happen a year ago. This is why I kept saying that she needed to be removed well in advance of budget workshop. That isn't "I told you so" it's "I'm really not crazy"

**Mel Pino**: She has no fucking idea.

**Mel Pino**: It's a bluff.

**Mel Pino**: "We started looking at." "We are also considering." Great. It's not ready yet.

**Mel Pino**: Oh this will be good.

**Mel Pino**: She will meet with Doug, Robert, and Pam now and come up with her "discretionary" idea of what makes up Recurring to paint the biggest nightmare picture she can. It will be even worse than any slide so far.

**Mel Pino**: And I wouldn't bring up tennis court money with him hahaha

**Mel Pino**: Oh this is what you were talking about.

**Mel Pino**: This makes me want to puke.

**Mel Pino**: Ok I guess this is better than having all the division leads do this personally if it is a time save.

**Mel Pino**: But then they aren't available for questions.

**Mel Pino**: Too bad he wasn't worried about that when his administrator was slashing and burning her way through veteran staff.

**Mel Pino**: This entire show is still running on the old program. These people will not be capable of anything other than what has been drummed into them politically. They do not have the ability to change gears.

**Mel Pino**: Great time to pull the masks Jeff. Good God.

**Jeff Bergosh**: Constituent questions 

**Mel Pino**: Got it hopefully that answer was sufficient for the bozos.

**Mel Pino**: I can differentiate it just fine. She makes it up as she goes along and is full of shit.

**Mel Pino**: They haven't "implemented" anything. They have dreamed up some possible processes.

**Mel Pino**: Gee. Where have we heard about a five year plan before.

**Mel Pino**: Oh now it's staff that can't use account codes appropriately.

**Mel Pino**: I like the way she takes her coaching from Doug.

**Mel Pino**: What happened to that big contract for a consultant to assess the fleet that I called out as a sole source?

**Mel Pino**: The one where Wes said there were only two companies and one had a conflict of interest?

**Mel Pino**: If memory serves you guys voted the money that night.

**Mel Pino**: Maybe that's part of the context and I missed it.

**Mel Pino**: Doug just set it up to write the maintenance plan for Wes.

### CONVERSATION ON 07-21-2021

**Mel Pino**: Call if you have time before the playshop

**Mel Pino**: Posted a form for the ECW set.

**Mel Pino**: See my comment here, which I also posted to my facebook.

https://www.pnj.com/story/opinion/2021/07/21/marlette-cartoon-heads-escambia-county-hr/8028166002/

**Mel Pino**: Edited

**Mel Pino**: Take a look at the basic considerations/questions that are bulleted in this article. Even when actively pursuing an agile model of budgeting, an agency needs to be able to answer those strategic questions or it is pointless--and dangerous. Currently the budget office can't gently answer a single one of these questions, not define the actual parameters through which decisions were made. While this may be a solid model for consideration during the coming year, it's a disaster in the making to proceed with strategic goals and definitions not set. This article addresses private sector budgeting. The scenario is far worse for public agencies answering to state statute.

https://hbr.org/2020/08/an-agile-approach-to-budgeting-for-uncertain-times

**Mel Pino**: Cogently

**Mel Pino**: Jeff is sandra she can compete for those dollars, give her the 620 to pull down the 914. God knows with delta coming in and the hospitals fucking off she is going to need it.

**Mel Pino**: She's good!

**Mel Pino**: Why in the hell is REAP coming with all the money they already get from the downtown trough. That organization sucks.

**Mel Pino**: So they are coming in replace of Connie.

**Mel Pino**: Because you're a crook.

**Mel Pino**: They don't try too hard on that

**Mel Pino**: Of course Robert is keyed in on this.

**Mel Pino**: The human embodiment of zero fucking shame.

**Mel Pino**: They havent started.

**Mel Pino**: "This may or may not get us what we need to see." Amber with the new motto for Escambia county budget transparency

**Mel Pino**: Wtf is the a new ask from the special agency of Bender Wants it?

**Mel Pino**: Essentially

**Mel Pino**: When Robert says "that's what we're working on" who is we?

**Mel Pino**: She is a snake who will say anything.

**Mel Pino**: https://www.wfla.com/news/florida/florida-ag-ashley-moody-tests-positive-for-covid-19-despite-being-vaccinated/

### CONVERSATION ON 07-22-2021

**Mel Pino**: Oh perfect. Good thing she went and bought her some steel toe cowboy boots for the trip.

https://www.miamiherald.com/news/politics-government/state-politics/article252938903.html

**Mel Pino**: Just posted on redistricting.

**Mel Pino**: Did the county vacate the shoreline where the person wants the hold harmless on the sea wall GMR II.1? If not this is a very bad precedent for ALL of bayou Grande. The county is supposed to own the shoreline all the way around and this really opens up a Pandora's box to kick the public off the shoreline wherever there is a house.

**Mel Pino**: PLEASE take note of that Jeff. I know it doesn't look like a big deal, but if the county didn't vacate that waterside it is a HORRIBLE percent.

**Mel Pino**: Precedent

**Mel Pino**: This is bad bad bad. Further kicks the public of the shoreline. No way will anyone be allowed to use that shoreline after the owner puts up that seawall, it that is what is happening rather than the county building it. :(

**Mel Pino**: This is bad bad bad. Further kicks the public off the shoreline. No way will anyone be allowed to use that shoreline after the owner puts up that seawall, it that is what is happening rather than the county building it. :( and Doug always bothers that the county will not allow this sort of thing. The only way it's moot is if these people got a previous vacation from the county

**Mel Pino**: Holy shit

**Mel Pino**: You guys have got to step in on her. She has NO business doing this. What the fuck is "we"

**Mel Pino**: ARE YOU FUCKING SERIOUS

**Mel Pino**: Jeff please at least ask about that sea wall item. 

**Mel Pino**: The county can't have vacated it if it needs a hold harnless

**Mel Pino**: I forgot to convey that I spoke with a couple of uber ethical, non biased people in this field (and no not Matt selover). Air methods dispatch out of Nebraska. Shands dispatch out of Gainesville. If shands can't take the call, they HAVE to give to a different company. If life flight can't, their dispatch can send it to other locations and that can delay. There is no getting around the necessary evil of one of the companies doing dispatch.

**Mel Pino**: You don't want EMS dispatch stuck with "copter shopping" and that is the reason for the first call contract. But nobody knows why it was a "handshake" agreement under Janice when you guys voted the contract.

**Mel Pino**: That "handshake" bullshit has really created bad blood.

**Mel Pino**: I asked if I was true that the delay to Niceville impacted the base and the answer was that it might have. It probably should not have gone over to Niceville but to shands/medcare.

**Mel Pino**: Wow that goes against what I just said. What a mess.

**Mel Pino**: Okay Eric just confirmed what my guy told me on problems with Dispatch once it goes to life flight I think.

**Mel Pino**: https://www.pnj.com/story/news/2021/07/22/escambia-county-commissioners-may-need-pay-back-some-their-annuity/8048354002/

### CONVERSATION ON 07-23-2021

**Mel Pino**: Morning funny.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Who is the right person LOL

**Mel Pino**: Right??? Hahahaha

**Mel Pino**: Check my comment here

https://ricksblog.biz/childers-goes-off-again/

**Mel Pino**: Sorry. I posted and immediately reposted because my name didn't enter into the field in the first one. They are dupes...the second submission has my name. On Amber's resignation.

**Jeff Bergosh**: Okay thx

**Mel Pino**: Also on my facebook, the Pnj Facebook, the Pnj website, and pending on north Escambia.

**Jeff Bergosh**: 👍

**Mel Pino**: Im sick of these gender excuses and it's despicable it got set up for gender warfare.

**Jeff Bergosh**: Yep

**Mel Pino**: Im so glad Mike called to share the good news. :) 

**Mel Pino**: Hate to kill the good news but you need to know this. Hospitals lying their asses off about capacity again, natch. Have it from someone close to them that they have been waiting for a machine for 2 days. Wonder if they will be able to cover it up this round like they did last time.

**Mel Pino**: It's really senseless and sad. 

**Mel Pino**: Oh and also covenant is sending hospice staff out unvaccinated and you cannot legally request a vaccinated worker. Kim Carmichael kicked an unvaccinated caregiver out of her mom's house (who was there to administer oxygen for lung cancer) and my neighbor Vincent teschel has to allow unvaccinated nurses from covenant into his mom and dad's house if he wants home care for his frail mother with advanced Alzheimer's. These are Ron desantis's policies. 

### CONVERSATION ON 07-24-2021

**Mel Pino**: Posted. There is at least some merit in being able to tell these hospital administrators and lawmakers to fuck off. Man these people are gonna have a long time to think on their sins. 

**Mel Pino**: Check my Facebook comment to wendy 🤣🤣🤣

**Mel Pino**: This is from Mike. I'm not posting this public, as I hope it's wrong and doesn't happen and there is no reason to alarm people if it's off. Just circulating to friends and officials who might need to be prepared for this scenario. Let's hope this is way off base. 

 Dr Feigl-Ding offers a pretty scary take on Delta and R0. 

This thread suggests we may likely see Delhi like numbers across the American South
https://twitter.com/DrEricDing/status/1419079452718415875?s=20

**Mel Pino**: I think this might be Wendy's problem 🤣 the salad bowl and sharp Fiskars look is actually a hate symbol! Hahaaa! 



https://www.google.com/amp/s/www.fatherly.com/love-money/bowl-cut-haircut-hate-symbol/amp/

**Mel Pino**: That message is from a friend haha

### CONVERSATION ON 07-25-2021

**Mel Pino**: Ron Ellington passed yesterday. I believe he was treating for cancer and had a heart attack at the hospital.

**Jeff Bergosh**: Sad to hear-- even though politically we were not allies

**Mel Pino**: Yes, I feel the same way, but that's a sad way for anyone to go.

### CONVERSATION ON 07-26-2021

**Mel Pino**: I answered Cj Lewis on the budget here, top of comments

https://ricksblog.biz/county-budget-director-resigns/

**Jeff Bergosh**: Thanks.  That guys a fucking tool.  And a loser to boot.  Thinks he's smart with his long winded posts, but when he ran for office the voters told him otherwise and sent him a message that he was not qualified for city council or dog catcher.  I think he finished 4th in a 4'person race LOL.  Fucking tool-bag

**Mel Pino**: Yep he is so full of shit. He will never STFU he is so full of himself, so I can have fun with him when he posts stupid shit.

**Mel Pino**: Rick clearly can't stand him from the character he created for him in his books.

**Jeff Bergosh**: I went back and looked it wasn't a four person race it was a two person race and he got crushed 60 to 40 by PC WU

**Jeff Bergosh**: I think that retired him from politics--he would have been a fucking disaster

**Mel Pino**: And still is but can't give it up.

**Jeff Bergosh**: Glad my friend PC WU crushed him like a roach!

**Mel Pino**: https://thehill.com/policy/healthcare/564788-doctors-nurses-medical-groups-call-for-mandatory-vaccinations-of-health

**Jeff Bergosh**: Half the staff at local hospitals haven't taken the shots

**Jeff Bergosh**: I was astonished when I heard that!!

**Mel Pino**: Yep. Covenant is sending around unvaccinated hospice workers and playing games with the medical billing on it.

**Mel Pino**: Same shit, different wave.

**Mel Pino**: https://www.news4jax.com/news/local/2021/07/26/jacksonville-doctor-calls-on-desantis-to-declare-state-of-emergency-due-to-covid-hospitalizations/

**Mel Pino**: Officials just starting to defy DeSantis now.

https://www.orlandosentinel.com/coronavirus/os-ne-coronavirus-orange-in-covid-quandry-20210726-fhq3m5be5fdlvbt5gqxvdpxzki-story.html

**Mel Pino**: Emails attached to their post.

### CONVERSATION ON 07-27-2021

**Mel Pino**: Like I've said, there is no bottom with him. It will always get worse until he is either out of here or in jail.

**Mel Pino**: This fucker.

**Mel Pino**: Were not gonna quit, but you guys have to fight back also.

**Mel Pino**: Some of us will never stop pushing to put him in cuffs because that is where he and Wendy belong. They are crooks. That's why they are making this up. He has been run out of this town before. I want him behind bars this time. That's what I set out to do almost four years ago and I didn't think I would have to segue for a psycho medical director and a crooked admin, but with them out of the way I am back on him and he is going to feel it.

**Mel Pino**: Here are the unfiltered facts about mandates and an emergency vaccine. Of course the County could require it. Would the County get sued? Probably. Would they be able to defend it? Most likely. 

https://www.factcheck.org/2021/05/exploring-the-legality-of-covid-19-vaccine-mandates/

**Jeff Bergosh**: Interesting

**Mel Pino**: Right hahahaha

**Mel Pino**: These is the level of brain dead idiot he has as followers now.

**Mel Pino**: Do you want to talk about how you got your contractor's license? Because I am more than ready to start talking about that. When would you like me to start?

**Mel Pino**: That has nothing to do with county business, but with his fraudulent contracting license. Sent him that a couple of weeks ago.

**Mel Pino**: Good morning, hope you are feeling okay after last evening's social media display. Of course there are many of us who recognize there isn't an ounce of truth to this per Treasure Hills or Diamondhead.

**Mel Pino**: That also has nothing to do with county business. Sent him that last week.

**Mel Pino**: Posted this to Wendy three days ago. Also nothing to do with county business, but his illegalities.

**Mel Pino**: So no, Jeff, I am not worked up about Doug. I could give a rats ass about him in particular. It is the people still protecting him in the background the war is with.

**Mel Pino**: I am worked up because the county is going to do nothing about covid again and more county staff will probably die as a result. Just like last time.

**Jeff Bergosh**: Your anger is misplaced

**Jeff Bergosh**: Do you wanna get pissed? get pissed at the right people

**Mel Pino**: Did you not read the blog comment I put up on you blog excoriating the hospital admins?

**Mel Pino**: I have spent two days annihilating Larry downs and Tracy Adams, who is a friend, and their dipshit arguments on my facebook wall

**Jeff Bergosh**: Yeah I saw that but that's where the anger should be directed let's see you do a post on that on your Facebook

**Jeff Bergosh**: The county is providing resources the county is providing vaccination sites the county is providing information the county can't make the horse drink when we bring the fucking thing to the water trough think Mel

**Mel Pino**: What are you talking about? I have made many posts throughout this thing on my facebook, your blog, Rick's blog and northescambia. You are really going to try to pretend I don't have the balls to say something? 

**Jeff Bergosh**: Your anger is misplaced

**Mel Pino**: No, it isn't. 

**Jeff Bergosh**: Be mad at those who choose to be unvaccinated that's where your problem lies government can't be a nanny that holds everyone's fucking hands and oh by the way the fucking masks don't work. If they did we wouldn't have the fucking problem we have an all the blue states where they've been mandatory not just one mask but three

**Mel Pino**: And you are so mad at me because you know in your heart the Republican party has fucking created this disaster of a response and it is bootlicking this unconstitutional governor on a local level that has created the local messes in Florida.

**Jeff Bergosh**: Look you're not a dummy you're smart use your fucking head use your anger but channel it in the right fucking places not a county commission who is doing what we can but who have our hands fucking tied in many respects Fink

**Mel Pino**: Don't tell me wrong legal opinion like I am Joel cotton and don't know what I'm talking about, Jeff.

**Mel Pino**: You don't have your hands tied from speaking correct opinion. You choose not to.

**Mel Pino**: You are mad at me because you know what I am saying has merit. The BOCC--the policy board--was complicit in letting Janice Trump her way through covid and there are staff dead because of it. There is a chance to get it right this time

**Mel Pino**: Your hands are not as tied as you pretend they are.

**Mel Pino**: And then you want to talk to me about the serenity prayer?and Catholicism? Seriously? I'm sorry Jeff. Look, I'm not wasting time on this with weak politicians. I am calling you out because you are better than them.

**Mel Pino**: Don't belittle my emotions over people dying from bad politics, Jeff.

**Mel Pino**: I think you know by now I am tougher than nails and am not afraid of anything. I lose my shit when people suffer because of broken policy I can't impact. It makes me nuts. I'm not into the serenity prayer much.

**Mel Pino**: In fact I can't think of one damn thing I have ever accomplished by being serene and I bet you can't either. 

**Mel Pino**: Yesterday on my facebook.

**Mel Pino**: Yesterday

**Mel Pino**: Yesterday calling out desantis's illegal numbers games.

**Mel Pino**: Here is my repost of my comments I made on your blog with a header I slapped onto those comments and posted on my own Facebook.

**Mel Pino**: Hey Jeff I checked in with Michael Kimberl because I hadn't heard from him for a while. Not county business and please keep close...he was in the hospital from a bad crohn's bout. He appreciated me catching him up and mentioned your donation and will be reaching out when he is recorded.

**Mel Pino**: Sorry recovered

### CONVERSATION ON 07-28-2021

**Mel Pino**: Posted on Flood defenders

**Mel Pino**: I'm glad you met with them. They need to divorce ECW and I have been working on that hard in the last month with some success.

**Mel Pino**: Emma Kennedy did a very nice job with this.

https://www.pnj.com/story/news/local/escambia-county/2021/07/28/childers-provides-emails-showing-escambia-county-annuity-program-no-longer-option/5379941001/

**Mel Pino**: Posted on PJ's bullshit

**Mel Pino**: https://www.bloomberg.com/news/articles/2021-07-28/florida-hospital-admissions-break-covid-record-set-in-january

**Mel Pino**: Average daily admissions in 18 to 39 year olds has jumped 150 percent the last two weeks. This hospital surge is three times faster than the crest in January.

**Mel Pino**: Just talked to Lumon about what community health and health and hope Clinic could partner to do. We need an infusion of funding, people who aren't afraid to make hard decision for the local community, and a social media campaign to cut through this Facebook bullshit. It is the NUMBER ONE impact on people not vaccinating. 

**Mel Pino**: This is the Number one problem, Jeff. It has to be countered with real information that will wake people up on social media. There needs to be a coalition between county cmr, city, community health, and agencies like health and hope to get a REAL campaign going not that bullshit Janice cooked up to make fun of people who took it seriously.

https://www.washingtonpost.com/politics/2021/07/27/people-are-more-anti-vaccine-if-they-get-their-covid-19-news-facebook-rather-than-fox-news-new-data-shows/

**Mel Pino**: More children requiring hospitalization, critical care, and even ventilators.

This is what adults failing an entire generation of children and leaving them open to a lifetime of chronic illness looks like.

https://thehill.com/changing-america/well-being/longevity/565323-texas-doctor-warns-covid-cases-are-rising-among

### CONVERSATION ON 07-29-2021

**Mel Pino**: Really good article on one of the data scientists inside Facebook who exposed the political manipulation that impacted the 2020 election https://www.technologyreview.com/2021/07/29/1030260/facebook-whistleblower-sophie-zhang-global-political-manipulation/

**Mel Pino**: Hey, I am going to try to catch you early tomorrow on an ems thing.

**Jeff Bergosh**: Ok

### CONVERSATION ON 07-30-2021

**Mel Pino**: Hey are you on your way in?

**Jeff Bergosh**: I'm here

**Mel Pino**: That doesn't matter. It will backfire completely.

**Mel Pino**: People are getting sick of it.

**Mel Pino**: Call me back and I can explain the release thing.

**Mel Pino**: Call me--important news.

### CONVERSATION ON 07-31-2021

**Mel Pino**: Trusting you NOT to forward that. It's from an ER doc at Sacred. They are transferring patients in just got 2 from northern Louisiana.

**Jeff Bergosh**: Wow

**Mel Pino**: https://wgntv.com/news/coronavirus/florida-breaks-record-with-more-than-21000-new-covid-cases/

**Mel Pino**: From a trusted medic just now:

Many sites are out of testing supplies. Hopefully state will step in with testing sights again. 

**Mel Pino**: Fyi in Wes"s absence Debbie Bowers has informed another commissioner that his peers do not agree with his request to make sure that there is PPE readily available everywhere with signs warning about the spread of delta. And also that "they aren't seeing any deaths." That is the talking point with the state not releasing deaths on a county by county basis. We had 74 deaths in state of Florida yesterday which was 20 percent of all deaths nationally. Over a hundred deaths today and we broke the new caseload record on the same day.

### CONVERSATION ON 08-01-2021

**Mel Pino**: ER and bed capacity is dropping across the state


https://twitter.com/ChristinaPushaw/status/1421945251623755779?s=20

**Mel Pino**: DeSantis's press secretary who is a huge Rebekah Jones critic letting hospitals know they can always rely on the feds

**Mel Pino**: Another message about testing at community health:

I know FL DOH is at capacity for their capabilities with testing. 

### CONVERSATION ON 08-02-2021

**Mel Pino**: Good morning, I was just calling to remind you to check in on that stuff with the attorney.

**Jeff Bergosh**: In mtgs will call u after.  Want to discuss that

**Mel Pino**: K I posted on the charter

**Mel Pino**: I am supposed to be meeting with Alison this week fyi

**Jeff Bergosh**: 👍

**Mel Pino**: And a brief follow up.

**Mel Pino**: https://news.yahoo.com/matt-gaetz-says-freedom-variant-131142574.html

**Mel Pino**: Fyi Gulf shores closed also still hanging in with Myrtle beach

**Mel Pino**: THANK GOD

https://ricksblog.biz/breaking-david-morgan-drops-out-of-race/

### CONVERSATION ON 08-03-2021

**Mel Pino**: Left a voicemail

**Mel Pino**: What about the status reports from their attorney...they should contain opinions of how the evidence effects their case...whether believable etc 

**Mel Pino**: They likely did one after each depo-summarized the depo and contained their mental impressions 

**Mel Pino**: They also evaluate exposure early-the early reports would show their thoughts BEFORE Bergosh testified. 

### CONVERSATION ON 08-04-2021

**Jeff Bergosh**: .....but they don't want to release the opinion

**Mel Pino**: I was so pissed off reading that last transcript I could barely breath.

**Mel Pino**: PARTICULARLY the probably cause setup

**Jeff Bergosh**: Crazy right

**Mel Pino**: And isn't it funny that my attorney seems to be more interested in getting the truth out of the transcripts? Read them last night (I'm not paying for that, he is just interested) and texted a couple of things:

Just finished the transcript.  The story said they would not get summary judgment because of the timeline of events.  Not Bergosh 

**Mel Pino**: Recognize that has nothing to do with matt's cause but just this most recent bullshit

**Mel Pino**: Posted

**Mel Pino**: Hey when you get a chance release that blog comment. I threw it all on the field.

**Jeff Bergosh**: Okay

**Mel Pino**: That Napoleon comment was about Doug. See the D2.

**Jeff Bergosh**: Oh, okay thx.

**Jeff Bergosh**: That's apropos

**Mel Pino**: Yep

**Mel Pino**: Looks like hospitals are back on lockdown without announcing it. This post is NOT public. I believe she is in public defenders office

**Mel Pino**: BAM. You're welcome. :)

https://ricksblog.biz/hr-director-tried-to-throw-bergosh-under-the-bus/

**Mel Pino**: "I'm certainly not going to lie for the screw ups of Jerry Maygarden, Janice Gilley and Jana still"
🤣🤣🤣

**Jeff Bergosh**: LOL that's great!!

**Mel Pino**: Right?? That was awesome! Alison "it's just weird." Finally she just says it straight. I'm sure Doug is furious their plot was foiled. Nice try dipshit.

**Mel Pino**: School districts -- Leon County, Duval County, Broward County-- across Florida are mandating masks in direct opposition to DeSantis's executive order

**Jeff Bergosh**: LOL

**Mel Pino**: I would think this was funny if it wasn't the job they are doing on Matt I think he needs to lay down a cease and desist 

**Mel Pino**: Paul Fetsko sent this to Scott trotter

**Mel Pino**: https://www.cnn.com/2021/08/04/politics/asa-hutchinson-arkansas-mask-mandate/index.html

### CONVERSATION ON 08-05-2021

**Mel Pino**: Hey call me on your way in. Important

**Mel Pino**: Also do you have Marie Matt's number? Another commissioner is asking for it. Can't get a direct response on whether she is coming today or not

**Jeff Bergosh**: Okay will do

**Jeff Bergosh**: Don't have her number

**Mel Pino**: K Lumon can't get a call back from admin on whether she is coming to report

**Mel Pino**: Kevin sent this to Marie's husband: 

Trying to get a message to Marie that  the dais wants to have her input at the BoCC meeting today. Its not clear whether the invite has even been sent but multiple would be grateful for her there at agenda review 900

**Mel Pino**: I don't give a shit what those hospital admins are saying there are people stacked in the hallways. Admission is chaos.

**Mel Pino**: This is the true story. This is a friend of John rickmons' named Renee Giles. It's real. They sent her home still coughing up blood from covid and with a 104 temperature. Checked her out and she was only too happy to get out of there. If she dies at home chances are they will log her death as pneumonia. 

As a patient, I've seen it, and hospitals don't know what to do with it right now. I almost died at home after several trips to the ER being isolated in make shift rooms for way too many Covid patients. 105 fever, pneumonia, dehydration, not able to breath, d dimer up for blood clots, passed out on the floor, past brain fog, completely incoherent. Watching people through the glass next to me getting the vent. Laying alone because the doctor or nurse did not want to come in the room. Wondering when they were coming to vent me? Laying on the floor dieing alone at home. This shit is real. Lack of medical, overpopulated hospitals, yep, it's real. The "shot", I was eligible for it , it's a monoclonal antibody infusion. By the time I went through the avenues to supposedly get it or informed as to where well it was too late. I'm still in recovery with Covid Pneumonia barely able to walk,
 struggling to breathe, spitting up chucks of blood but thanking God for my life right now. No thanks to the doctors or hospitals "around here anyhow." But is it really their fault? The vaccine, well you decide. There are no guarantees.  I was scheduled to have mine then I got sick. I guess I waited too late because I was reluctant just like everyone else. Well, I'd rather have a few side effects for a few days from a vaccine. (Hello, This is modern society, we have vaccines) Then almost die and by the way, I gave it to everyone around me. Yep, I gave it to the people I care about. I put my loved ones at risk. I put 5 month old little Baby Azra at risk. And my mom. Pay attention, this is reality. Covid is real whatever strain it is. Hospitals are overwhelmed. And people don't know what to do. Well, I officially feel like a Zombie right now and it was not a vaccine that did this to me.
 It was Covid!

**Mel Pino**: Left a voicemail

**Mel Pino**: I hope that Alison is aware that Doug and Jacqueline are coming for her throat now on ecw, and how much good it does to placate him contrary to the interests of the rest of the board. I was VERY VERY grateful and appreciative of her interview with Rick and clarifying the shade meetings. It was hugely helpful in the context of everything. The depositions in Kate kenney case are ongoing right now

**Mel Pino**: If you haven't seen my comments on Rick's piece, I went ahead and connected some dots for people in mine:

https://ricksblog.biz/hr-director-tried-to-throw-bergosh-under-the-bus/

**Mel Pino**: Rick on Alison and retirement

https://ricksblog.biz/county-attorney-speaks-out-on-ethics-process/

**Mel Pino**: Marie coming

**Mel Pino**: https://www.cdc.gov/mmwr/volumes/70/wr/mm7031e2.htm

**Mel Pino**: Everybody knows that study exists. It's no secret.

**Mel Pino**: You are making things up and that is dangerous.

**Mel Pino**: You have no idea so quit guessing

**Mel Pino**: I'll be coming to public forum tonight with the data you couldn't find

**Mel Pino**: So they shifted the paperwork so they didn't get the notice?

**Mel Pino**: Is this that damn hole of Roberts? Can't tell.

**Mel Pino**: Okay not the hotel

**Mel Pino**: Hahahahahaha

**Mel Pino**: Residents got bigger boats.

**Mel Pino**: Like I said, we didn't need the roundabout :)

**Mel Pino**: Upon Roberts request, I just OP'd a clarification of his remarks on olf8 and tagged you on it. 

**Mel Pino**: And you got lucky. Wasting all mine time like that cut me off from going to the meeting on covid. Anyway, I promised Mike I wouldn't head down to that covid den while delta is ripping through. I'll just stay home and report. But check that post

**Mel Pino**: Here's some more hysteria.

https://khn.org/morning-breakout/florida-hospitals-run-short-of-oxygen-beds-while-desantis-criticizes-biden/

**Mel Pino**: Jeff can you please fit it in if all possible for the transcripts of the depositions on Matt's suit. If it comes up please ask when you can have those. I would love to see them asap they will be very helpful

**Mel Pino**: Fyi I am meeting with Alison next week on ems

**Mel Pino**: WHAT?? On top of those millions and millions of dollars of sweetheart contracting on that debris she let them ship it out and burn it???

**Mel Pino**: Sent to Doug: that is about the fourth time this meeting that you have demonstrated how negligent your understanding of the agenda and the business is by your absence at agenda review and your failure to read the agenda sufficiently.

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I hope he's coming back in

**Mel Pino**: I hope so too.

**Jeff Bergosh**: This is the shit that kills me

**Mel Pino**: I cant believe he won't be back for vote

**Jeff Bergosh**: Votes coming

**Jeff Bergosh**: He's back

**Mel Pino**: Jeff people don't understand there is backup in the packet

**Mel Pino**: Jeff explain ti them where the packet is

**Mel Pino**: Have drew show them

**Mel Pino**: After the vote have staff show them how to get to the big backup. They don't know it's there. It's not obvious. That's why I explain it to people every time I report the meetings. They think all the backup is linked

**Mel Pino**: AFTER the vote :)

**Mel Pino**: It's not their fault!! They don't know where it is!

**Mel Pino**: Yeah!!!!!!!!

**Mel Pino**: (from a friend) My dentist's wife was watching and she sent me the clip of underhill walking out and she was dying laughing! 

### CONVERSATION ON 08-06-2021

**Mel Pino**: Jeff you should do a quick blog post with screen shots showing people how to get to the big backup. That would be a HUGE service to the public because people have zero idea that's there. Janiceand Pam have shuffled things so many times and if you don't know what you're looking for there is nothing to guide you there. You could gear it to the NICE outcome where constituents were honestly confused about the difference between land use and zoning

**Mel Pino**: That stuff is incredibly confusing even on the basic level of FLU vs zoning. Ceci honestly thought you had wiped out all the zoning because jaqueline was squawking RED RED RED

**Mel Pino**: It was a very nice moment where they understood and rather than tsking them for not reading something they did know was there you could say you didn't realize Citizens were unaware and do three screen shot from meeting page, tab page, and then what the PDF of the olf stuff looks like on the page it starts

**Mel Pino**: You will also get a LOT more people reading it that way.

**Jeff Bergosh**: Okay will do

**Mel Pino**: Great meeting :)

**Jeff Bergosh**: I thought it went exceptionally well

**Mel Pino**: It did! It was amazing and it was because yu let ceci speak again

**Mel Pino**: If you hadn't let her speak that understanding and resolution never would have come, Jeff.

**Mel Pino**: I knew when you were saying "you didn't read the backup" that (1) you had no idea she didn't even know what backup you were talking about and (2) she was taking offense because she thought she HAD read all the backup

**Mel Pino**: That's a different issue of course from not understanding the difference between zoning and planning. But even regular meeting attendees have NO idea that packet is online or what it is. 

**Mel Pino**: That's why I always hammer it ever time I report "don't forget the big backup is under the 'pacjet' tab" and tell people if they are interested in an item that HAVE to click that packet and get the rest f the backup

**Mel Pino**: Jesus Christ. Republican need to start speaking out agains this, Jeff. At what point does silence become complicity.

New Trump rally on Capitol, Sept 18.

Oh dear.

https://www.huffpost.com/entry/matt-braynard-protest-capitol-riot_n_610c5c6be4b05f8157079a71

**Mel Pino**: Hhahahahahaaha

**Jeff Bergosh**: LOL what a nut job 

**Mel Pino**: Fyi the city had a town hall on Wednesday with the hospital admins with all city employees inviting to attend. I'm getting back from solid sources that the hospital admins admitted they are basically full already, they are predicting 50 days of this cycle, and that it is accepting much more quickly. They had to ramp up at 2 weeks rather than six. So  we aren't even a quarter way through if their predictions are right. Medics are shell shocked and say it is already way worse than anything they saw last round. Area company at about 75 percent covid calls.  Hospitals are ejecting and rejecting very sick patients. Sending the home to die and no beds at the inn regardless of how a patient ends up at the hospital. The hospital admins are admitting more to the city than they are the county. Probably because they are used to a soft go of it with janice's administration. Eric needs to push and make them understand there's a new sheriff in town.

**Mel Pino**: That is what I am sending to other commissioners as well.

**Mel Pino**: Heres a small bit of hope

### CONVERSATION ON 08-07-2021

**Mel Pino**: Check my tag on this. They slapped this crap up with an hour of me calling them out for avoiding the story 🤣

### CONVERSATION ON 08-09-2021

**Mel Pino**: Great interview:). That was really engaging. Now, What the fuck is he interviewing Dennis green for.

**Mel Pino**: That's edler's lawyer

**Jeff Bergosh**: Thanks- No idea why he'd bring that guy on

**Mel Pino**: He played for Bobby Bowden.

**Mel Pino**: He was Gallup about how that's where he learned about God before he went on to try to help Doug Underhill defraud his insurance company

**Mel Pino**: All up

**Mel Pino**: You guys have got to start putting pressure on these fucking administrators to release the damn death and pediatric stats.

**Jeff Bergosh**: You will probably get a very big kick out of the post I just put up on my blog. Your challenge attempt to read the caption and the blog picture without cracking a smile or chuckling I don't know that you'll be able to do it. Let me know :-)

**Mel Pino**: Tomorrow morning I am going to post the email I sent Barbara and christian trying to warn them that Jacqueline had boondoggled them and that  she was going to lose her suit. I cc'd her on it as a courtesy.

### CONVERSATION ON 08-10-2021

**Mel Pino**: You should take David's comment to heart. You will disagree, but I am firm that your post was unbelievably tone deaf. It's ludicrous--absolutely blind--to keep insisting there isn't systemic racism in our school system. And it makes you look really, really out of tough. I'm sure your base in D1 approves, though, so if that's who you are playing to its right on the mark. In the meantime, you are featuring Larry at a time most reasonable people I know have blocked to not give him a platform for his dangerous anti vaccine rants all over social media. Just not a good luck in multiple contexts. David never posts so I would imagine he was pretty appalled by that to put a comment down. Haven't talked with him about it though.

**Jeff Bergosh**: Huge backlash developing among teachers who are pissed off about that video.  Huge backlash.  It might cost Dr. Smith his job.  Serious anger over that propaganda 

**Mel Pino**: Of course. This is a very racist town.

**Mel Pino**: Never in all my life seen racism on a level that exists here. It may chase Mike and I out some day if it never changes. 

**Jeff Bergosh**: It isn't racist to disagree with something that is racist posing as academic theory

**Jeff Bergosh**: Because we will not agree

**Mel Pino**: Pensacola is a hell hole of racism and you can't see it.

**Jeff Bergosh**: There is some --I don't disagree with that

**Jeff Bergosh**: That's what that garbage propaganda video wants us to believe

**Mel Pino**: The only thing that will save this town from the racism that rots it in its core is population dilution from outside.

**Jeff Bergosh**: I disagree

**Mel Pino**: Of course you do. 

**Jeff Bergosh**: The folks that I associate with are not racist

**Jeff Bergosh**: Makes us realists: not racists

**Mel Pino**: Jeff this isn't even a topic I am gonna waste time debating with you...you are too set in your ways on it. It's not like covid, which is urgent. Your blog doesn't phase or surprise means I'm not upset about it. Going to get back to trying to save that tree

**Mel Pino**: Which is a disaster, btw

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Which tree?

**Mel Pino**: Not your average tree hugger situation

**Mel Pino**: This asshole back of Sandy saying wants to cut down the largest live oak in Escambia county for a fucking ministorage. Illegally and just pay the fines. It's over 80

**Mel Pino**: Fucking ridiculous

**Mel Pino**: County should have never had it zoned commercial with that tree on there. You can't build on the small lot without killing that tree

**Mel Pino**: I am trying to get Lumon to have the guy put the breaks on it so we can buy back the lot and turn it into a park

**Mel Pino**: Sandy sansing out to buy it and name the park after the sansings

**Mel Pino**: Working on an injunction to buy time

**Mel Pino**: Please post my comment that's all I am getting into with it today

**Mel Pino**: Other than Christ Almighty, could you not have done it without activating Larry. Most people I know have him blocked right now he is so hysterical with his covid conspiracies

**Mel Pino**: Not seeing my post on the video?

**Jeff Bergosh**: I approved it a while ago

**Mel Pino**: They're up now

**Mel Pino**: Hey do you have five minutes for me to run something by you? 

**Mel Pino**: Amber is throwing the bocc under the bus saying that LOST is "upside down" at 2m and growing and gave a little air blow through her nose on it. As the reason why they need to use TDC to close beach access

**Mel Pino**: I hope that monster remembered to include plenty of infant and pediatric size ventilators in that order.

https://www.local10.com/news/local/2021/08/09/florida-sets-another-covid-case-record-as-hospitals-face-sheer-exhaustion/

### CONVERSATION ON 08-12-2021

**Mel Pino**: What the he'll happened to your concurrency?????

**Mel Pino**: Maybe this will snap you guys out of your covid delusions?

**Jeff Bergosh**: It's coming in October--- after the budget

**Mel Pino**: Why?

**Mel Pino**: You don't have to answer that via text. It's bullshit.

**Mel Pino**: While covid WAS certainly challenging? 

**Jeff Bergosh**: Diplomacy

**Mel Pino**: Idiocy, denial, GOP self delusion about what is happening. Which is going to take everybody over the cliff with them.

**Mel Pino**: This plan better not box out from a bus to florabama. Doug has been blocking it his entire time in office.

**Mel Pino**: If that's not on the map ask why not. We need a bus out to beach access 4. I am NOT kidding

**Mel Pino**: It never went to the florabama

**Mel Pino**: It stopped at SW library miles away from beach

**Mel Pino**: The fucking bus needs to go to Johnson beach

**Mel Pino**: "Now that covid has slowed down" with our hospitals spilling over.

**Mel Pino**: He's lying it didn't go to florabama the entire time it ran

**Mel Pino**: Jeff we have got to get that seasonal bus route down to beach access 4 in there

**Mel Pino**: THANK GOD THANK YOU if you pushed for that...I just broke it out and linked to your coffee. I was tied up with preparing for that one o'clock on the tree

**Mel Pino**: Does this finally solve the mystery of why janice was whacking veteran staff?

**Mel Pino**: You have got to be kidding me. What are we paying him for?

**Mel Pino**: Of course you covid impact was higher. That what happens when you don't put in measures and pretend it doesn't exist and stick your heads in the sand. And it's happening again.

**Mel Pino**: Maybe the answer isn't incentivizing people to get out of program only. Maybe you guys could actually do something about covid in staff.

**Mel Pino**: This is a hell of a way to recruit staff. Nobody wants to work for the county as it is it is such a shit show.

**Mel Pino**: Better be ready for a big salary raise most people would probably want that anyway

**Mel Pino**: You can't eat insurance.

**Mel Pino**: This all looks knee jerk and this USI guy is doing a job on it. You guys seem like you need better answers and more time. It looks lik you need a deeper dive with better answers...they aren't ready. And this is going to GUT staff morale right now

**Mel Pino**: So basically the one thing you and Doug agree on is gutting health care benefits for staff during a pandemic. Great timing.

**Mel Pino**: Some of those people can't roll off the bench and come to work because they are too fucking sick from catching covid at the county.

**Mel Pino**: Wow an entire couple of months for staff to change up their family budgets during a pandemic. Man you guys are so out of touch. 

**Mel Pino**: Oh sorry I meant a couple of weeks before open enrollment. Jesus.

**Mel Pino**: And then you wonder why nobody wants to work for the county any more.

**Mel Pino**: Never found somebody who was a good fit because chips doesn't want competition.

**Mel Pino**: The direct money percentage on grants is what that department has colonized the entire county with.

**Mel Pino**: Hahahaahahaha wtf???

**Mel Pino**: Text I just got from a friend:

"Committee of the Holes."

 And no, she's not a firefighter. Just somebody appalled by the board's continued tone deafness during this pandemic.

### CONVERSATION ON 08-13-2021

**Mel Pino**: Hey, I was so upset about this I totally forgot :( I walked into the house and Mike was standing there and it's his birthday weekend. I already signed off Facebook for the weekend two hours ago...drew a firm line for his birthday.  Having me go on will hurt your cause as if I had to come out of my break or something. I will look at it though and see who might be good to respond.

**Jeff Bergosh**: Thx!

**Mel Pino**: Sorry I was all like "I Am done until Monday" to force myself to get the he'll off for his birthday.

**Mel Pino**: Check my post.

**Jeff Bergosh**: Will do and I just tried to call you back I got your voicemail

**Jeff Bergosh**: 💥💥💥Boom!!Great post Mel!

**Mel Pino**: It's way too late for this pleading to work, of course. We needed effective public policy instituted by our public officials on this a month ago. Hell, two weeks ago still would have done some good--mandatory masks, social distancing indoors, cancel youth sports, fuck the governor on his school funding game of chicken, HVACs that should have been attended to last round, but most of all an effective social media campaign orchestrated by the county combating disinformation. All of the lessons that should have been learned the last time around, but weren't, while officials instead chose to keep their head in the sand, bootlick their party, and let themselves believe fantasies contrary to science. This is going to get very, very bad now. The suffering will be enormous. And it didn't have to happen.

https://weartv.com/news/local/we-need-your-help-baptist-ceo-releases-strong-message-as-covid-cases-surge

### CONVERSATION ON 08-14-2021

**Mel Pino**: Jeff something I forgot to mention yesterday. This is why JJ kept saying you needed to ask for ALL the reports the outside and insurance counsel filed with the county attorney. He said they would be written, detailed reports that would be expected as part of their services. There are probably more of them in that case. 

**Mel Pino**: What about the status reports from their attorney...they should contain opinions of how the evidence effects their case...whether believable etc 

**Mel Pino**: That was weeks ago.

**Mel Pino**: There are probably a bunch of those status reports unless she combined them all into one.

**Mel Pino**: And why did Jana still have status reports you didnt? You need to find out exactly who was given those reports. Those were NOT public record until the case was over.

**Mel Pino**: Remember I have always suspected there might be a rat in the IT dept also.

**Mel Pino**: As I have been saying for a year, this is the biggest public health failure in the history of this country.

https://www.pnj.com/

### CONVERSATION ON 08-16-2021

**Mel Pino**: Posted a 2 part.

### CONVERSATION ON 08-17-2021

**Mel Pino**: Dont miss this point in my PM. If staff is so sure of their legality on this, then why, after being outright accused of doing something illegal, did nobody say "its legal" in the meeting?

**Mel Pino**: Because like is said NOBODY wants to be holding this bag.

**Mel Pino**: 2-1.4C staff and owner have to address each point. They did not. Staff declined. 2-5.1 tree removal criteria.  

**Mel Pino**: I have the new more compete scoop for you after a phone call. Call when you can so I can show you how this works hahaha

**Mel Pino**: Thank God for small favors

### CONVERSATION ON 08-18-2021

**Mel Pino**: https://www.mississippifreepress.org/14927/mississippi-quarantines-20000-with-5993-students-positive-for-covid-teen-deaths-rise/

**Mel Pino**: But I'm nuts about the LET funds. Right.

https://www.pnj.com/story/news/local/escambia-county/2021/08/18/escambia-county-sheriff-david-morgan-order-lifesize-bronze-statue-himself-75-000-taxpayer-money/8182851002/

### CONVERSATION ON 08-19-2021

**Mel Pino**: Jeff PLEASE explain on concurrency. People think you sabotaged it

**Mel Pino**: Here's how well the  "nobody's dying" and "only the fat people get vented" talking points is working nationally.

https://apnews.com/article/lifestyle-health-coronavirus-pandemic-c341a0e0ab5e9ecc3b3eedc855f33513

**Mel Pino**: If you call me up and ask about the possibility of a swap 

**Mel Pino**: I will be positive 

**Mel Pino**: That's up for debate. Will thinks it was illegal.

**Mel Pino**: I e we have EMS who aren't vaccinated

**Mel Pino**: And they CAN be legally compelled to vaccinate

**Mel Pino**: And Keith will be announcing that all staff HIRED by city will be vaccinated

**Mel Pino**: Just read the agenda. I am speaking on ARF/covid,  LET, and redistricting

**Mel Pino**: So her period of blame is her entire time in office.

**Mel Pino**: Which is it? Did he know it was wrong or was he a neophyte who thought it was okay?

**Jeff Bergosh**: Both?

**Mel Pino**: He first said that he took one look at it and knew it was wrong. When he was given the paperwqork

**Mel Pino**: Now he just said that as a neophyte he reaffirmed it in 2016

**Mel Pino**: Because staff told him it was okay

**Mel Pino**: Ask that fucker which is it

**Mel Pino**: Doug is going to say he could NOT opt out of FRS. Ask him where he is donating it then.

**Mel Pino**: Call me up I did the public reocrds

**Mel Pino**: I have the documents!

**Mel Pino**: I got them from Charlie peppler

**Mel Pino**: Ask Alison who did the PRR

**Mel Pino**: I made it to Alison and I have seen that the asshole is getting payouts on his checks

**Mel Pino**: Fyi I am speaking on LET next

**Mel Pino**: Actually 2.9 there is someone for 2.3

**Mel Pino**: Jeff ask Alison whose liability it s if Morgan wasn't doing let funds right

**Mel Pino**: The answer is yes.

**Mel Pino**: But ask the question

**Mel Pino**: The let funds liability is on you guys and she isn't doing it right

**Mel Pino**: The let funds liability is on you guys and she wasn't  doing it right for the whole time with morgan

**Mel Pino**: for the whole time with morgan. Chip wants it right

**Mel Pino**: Please stick up for him

### CONVERSATION ON 08-21-2021

**Mel Pino**: Jacqueline said Doug never signed an FRS  form.

**Mel Pino**: So I posted it.

**Mel Pino**: Walter Arrington asked about it and Doug lied.

**Mel Pino**: So he posted it 🤣🤣

**Jeff Bergosh**: LOL

**Jeff Bergosh**: He's a lying sack of shit

**Mel Pino**: Hahhaahaha

**Mel Pino**: I also posted on the westmarks coming for fees and sanctions. Fuck her. She's just as big a cancer as Doug.

**Jeff Bergosh**: Malignant

**Mel Pino**: Yup.

### CONVERSATION ON 08-23-2021

**Mel Pino**: Hey I forgot to tell you. From the docs we got nobody environmental signed off on that tree. Drew Holmer signed where brad Banes was supposed to sign. Banes recommended it not come down and Vicky recommended that as well. Two places at least staff said it was against the LDC to cut it down. Horace overrode it.

### CONVERSATION ON 08-24-2021

**Mel Pino**: Call when you can. I see what you were saying...that went in last week. I don't know if we still need it. Margaret got the development docs. I asked will.

### CONVERSATION ON 08-25-2021

**Mel Pino**: It blows my mind that people are actually shocked this is happening. It is the inevitable result of the Republican party's policy decisions and the most tragic public health failure in this country's history. All for the love of power.

Florida the only state where more people are dying of COVID19 now than ever before. Daily deaths now averaging 228 a day.
https://news.yahoo.com/florida-is-the-only-state-where-more-people-are-dying-of-covid-now-than-ever-before-what-went-wrong-090001893.html?

**Jeff Bergosh**: Sad

**Mel Pino**: It's going to get very bad in the schools the next couple of weeks. They aren't even quarantining at ferry pass elementary.

**Mel Pino**: https://twitter.com/RonFilipkowski/status/1430613422811586567?s=20

More defiance of Desantis. Tampa Mayor Jane Castor announced today all City of Tampa employees must be vaccinated by Sept 30. She says to those who talk about "freedom" not to vaccinate: "How about the freedom of their co-workers .. with co-morbidities? They have rights as well."

### CONVERSATION ON 08-26-2021

**Mel Pino**: Posted

**Jeff Bergosh**: 👍

**Mel Pino**: I assume that you know Meredith Reeves put her notice in but wanted to make sure as the county continues in its communication chaos.

### CONVERSATION ON 08-27-2021

**Mel Pino**: Posted on that dipshit Maddrey.

**Mel Pino**: This was apparnetly one of the subordinate employees he was screwing when he was her supervisor and then when he became chief as well too. That's Maddrey and it was posted yesterday.

**Jeff Bergosh**: LOL

**Mel Pino**: Check your email for Doug's emails on the county seal and claiming he is going to swear at Lisa savage and curse her with sand fleas in her armpits.

**Jeff Bergosh**: Got it

**Jeff Bergosh**: What a tool he is-----in every way

**Mel Pino**: This fox report has a graph showing The giant disparity between number of child covid cases in broad versus orange county schools. The headline should be "No Shit Masks Work As People 3000 Years Ago Had the Common Sense to Know"

https://www.fox35orlando.com/news/as-school-mask-mandate-debate-rages-on-do-masks-really-work

**Mel Pino**: Broward

### CONVERSATION ON 08-28-2021

**Mel Pino**: Check you email. I just sent out Doug's racist and misogynist rants the last time the seal came up, when he demanded of Lisa that she stop using it in articles on religious institutions. 

**Mel Pino**: Jeff Please call just as soon as you can this is very serious. It's not about Doug. 

**Jeff Bergosh**: On the tennis court between sets will call u after

**Mel Pino**: K 

**Mel Pino**: This is a direct result of people not understanding the Common sense measure of wearing masks. This has Nothing to do with what I needed to talk to you about though.

**Mel Pino**: I followed up on that email string to Savage with a new comment of Wendy's. 

### CONVERSATION ON 08-29-2021

**Mel Pino**: Another one bites the dust.

https://news.yahoo.com/anti-vax-radio-host-marc-070556812.html

### CONVERSATION ON 08-31-2021

**Mel Pino**: Baptist and sacred heart are on complete ems diversion right now.

**Mel Pino**: https://www.justice.gov/usao-ndfl/pr/fort-walton-beach-man-faces-federal-indictment-25-million-scheme-defraud?fbclid=IwAR1fjyL3SZclwBK0JfycoinsOsVxtE_Y4al9L769SvUYMQ8ckELKjrL1mAg

**Mel Pino**: Busy day.

**Mel Pino**: On Aug 10, Florida DOH changed the way it reports death data from date death reported to date of death (uncommon) in order to obscure the rising death counts
"Shivani Patel, a social epidemiologist and assistant professor at Emory University called the move "extremely problematic," especially since it came without warning or explanation during a rise in cases.
https://amp.miamiherald.com/news/coronavirus/article253796898.html?

**Mel Pino**: Check out this article from Pensacola News Journal:

Former ECSO Deputy Steven Sharp files to run for mayor of Pensacola

https://www.pnj.com/story/news/2021/08/31/pensacola-mayor-race-steven-sharp-former-ecso-deputy-files-seat/5666468001/

**Mel Pino**: Aside from county business. I just realized Ann Hill and Grover are orchestrating a fake food truck crisis so DC Reeves can rail against it and be the savior of small business downtown. You watch he will be out of the gate with that talking point. Ann probably got lured into it clueless.

### CONVERSATION ON 09-01-2021

**Mel Pino**: I don't know what you guys are being told, but two nights ago emis was only running four trucks again for the entire county. That is coming from someone inside an ER room and not a medic. Putting that out there publicly does no good that I've seen. But this situation has GOT to be addressed. Yes it's a pandemic but if ems can't rebuild right now then there has to be a different answer than continuing to run with 4 buses while our area hospitals are diverting patients left and right. 

**Mel Pino**:  Just received Ed Spainhower and Matt Coughlin depos.

### CONVERSATION ON 09-02-2021

**Mel Pino**: Thank you Jeff. To both you and Lumon for pushing and even Robert in his role as chair let it be known he wasn't thrilled.

**Mel Pino**: Im sorry for the pressure I put on you but you are the only one who can and will push on this and get somewhere as a Republican.

**Mel Pino**: I am also proud of Marie for admitting the administrators are full of shit and this isn't levelling out.

**Mel Pino**: Just fyi Laura Coale is live on ECTV doing a lying puff on EMS. PR is not going to solve the problem. Them being honest with you guys about what's really going on would be a good start

**Mel Pino**: Bill Fetke is threatening to run for mayor. With trump's endorsement. 🤣

**Jeff Bergosh**: 😂😂😂😂😂

**Mel Pino**: Right?????

**Mel Pino**: I posted about that bullshit about Kate and Joey. These people are so evil

**Mel Pino**: What is that Base encroachment item....make sure Doug isn't reneging on something. Haven't read it just have antenna up

**Mel Pino**: The property at the front gate are those plans he bought from Marilyn for an exorbitant amount

**Mel Pino**: Plats

**Mel Pino**: Woodbury Hess.

**Mel Pino**: Hes jacked up on meds.

**Jeff Bergosh**: Who

**Mel Pino**: Doug

**Jeff Bergosh**: Oh

**Mel Pino**: Hes reminding you guys of the money in LOST cause Doug is going to take it.

**Mel Pino**: Hes lying

**Mel Pino**: The water from Lake Charlene gets dumped in Jones swamp behind Forest Creek. This is one of many reasons this project sucks.

**Mel Pino**: CENSURE HIM 

**Mel Pino**: Jeff I PRR'd the docs Alison gave can you have Debbie shoot them to me

**Jeff Bergosh**: Don't have them electronically

**Jeff Bergosh**: Will get them 

**Mel Pino**: Thank you I want to get them to Rick pronto

**Mel Pino**: Thank you!

**Jeff Bergosh**: 👍

**Mel Pino**: Rick wants you on tomorrow

**Jeff Bergosh**: I'll be available :)

### CONVERSATION ON 09-03-2021

**Mel Pino**: Posted

### CONVERSATION ON 09-06-2021

**Mel Pino**: Jeff fix the typo in the title of your post

**Jeff Bergosh**: Okay

### CONVERSATION ON 09-07-2021

**Mel Pino**: Nice job.

**Jeff Bergosh**: Thx

**Mel Pino**: Posted. 3 parts.

**Mel Pino**: Stafford said there is no opportunity to do a referendum for this. You are correct thank God!

**Mel Pino**: So they will just make asses of themselves, we can capitalize on it with no fear of their success. :)

**Jeff Bergosh**: Yep

**Jeff Bergosh**: 👍😎

**Mel Pino**: Are you okay?? They just said you won't be there :(

**Jeff Bergosh**: Yes-- just not feeling well so just being safe.  Took some Tylenol and going to get a good night's sleep

**Mel Pino**: Oh no :( feel better

### CONVERSATION ON 09-08-2021

**Mel Pino**: How are you doing?

**Jeff Bergosh**: Much better today!

**Jeff Bergosh**: I think I must've pushed my body too far with a 22 mile bike ride Monday-- and not enough water

**Mel Pino**: Yeah!!! Thank goodness. 

**Jeff Bergosh**: 👍

**Mel Pino**: Some positive news: Pfizer's protease inhibitor approach combined with an AstraZeneca drug in market used to improve efficacy of anti-virals has entered clinical trials. 

The Pfizer approach is a treatment to help humans battle Covid-19 by slowing down its ability to replicate quickly. 

We could have by winter another weapon in the arsenal
https://www.express.co.uk/news/science/1488012/pfizer-breakthrough-covid-killing-pill-coronavirus-news-vaccine-virus-astrazeneca-1488012

**Jeff Bergosh**: Awesome news

### CONVERSATION ON 09-09-2021

**Mel Pino**: Just. An fyi have no idea what's up with it.

**Jeff Bergosh**: Nope

**Mel Pino**: I had no idea if it was true just putting it on your radar. Because anything is possible with the shit show that HR department has become. Remember, it turned out to be true they cancelled the bus drivers medical when they said they didn't.

**Mel Pino**: Seeing the spectacle on insurance benefits a couple of days ago, nothing would shock me.

**Jeff Bergosh**: From where?

**Mel Pino**: Will call on phone

**Jeff Bergosh**: K

**Mel Pino**: Not county business:

https://gulfcoastgoldstarfamilies.org/donate

**Mel Pino**: Glassman debacle

https://www.oxygen.com/crime-news/joshua-stewart-burks-charged-with-murder-in-troy-ellis-killing

**Mel Pino**: https://www.wbrc.com/2020/05/05/witness-talks-about-hunting-incident-that-leaves-year-old-dead/

**Mel Pino**: So that thing is obviously separate from Saturday event. He's always running something shady though and you can call D for confirm of that. Teri has a phone call with the father tonight and he was floored to find out they were running a game and his son was killed by somebody pretending to be a combat wounded vet who wasnt

**Mel Pino**: Teri is simply handing over the info and letting the family decide whether to pursue it. May just stay under the rug DG orchestrated this shit show. Whi knows.

**Mel Pino**: That has nothing to do with tomorrow other than Tim spears is furious and feels like Glassman preyed on him and lied to him (which he did and did and does all the time).

**Mel Pino**: Sorry, with Saturday.

**Mel Pino**: Lieutenant colonel, PhD purple hurt. 6 tours in middle east.

**Mel Pino**: Sorry, commander. Tired.

**Mel Pino**: He is currently the command of the Florida Department purple heart

### CONVERSATION ON 09-10-2021

**Mel Pino**: This asshole.

https://www.pnj.com/story/opinion/2021/09/10/marlette-barry-bergosh-star-censure-musical/5775013001/

**Mel Pino**: From a friend and not about county business.

D2 has a new job as of June. 1 as operations manager for ASRC Federal. I imagine that work could be done from anywhere but it  is fairly well paid. Reasonable explanation for new mortgage 

**Mel Pino**: Got that from a friend and obviously not county business.

**Mel Pino**: Please send that to Gary. He will know what I pertains to. The woman whose phone number is showing on the receipt had no clue it was going on there.

**Mel Pino**: Etc. 

**Mel Pino**: Phone number here.

**Mel Pino**: Gary might want to reach out to her.

**Jeff Bergosh**: Any news?

**Mel Pino**: Btw the people that came to town from Atlanta with the Gold Stars Tribute wall organization are pissed off that Glassman booked them for an event and mixed it with this concert event tomorrow. They thought they were going to be the main thing. They were paid for by a donation with Sandy sansing 5000. Stan Bernard of veterans memorial park board showed up to write another 5000 check. Please let your brother know. 

**Jeff Bergosh**: Okay

**Jeff Bergosh**: He spoke to del guido today

**Mel Pino**: Yep. I talked to chip. There's nothing to be done about it at this point but that asshole needs to be exposed.

### CONVERSATION ON 09-11-2021

**Mel Pino**: 🤣

### CONVERSATION ON 09-14-2021

**Mel Pino**: You on the move?

**Mel Pino**: If he starts talking shit today ask him how it went on Friday. If he has a report for the board what the outcome was.

**Jeff Bergosh**: LOL I might

**Mel Pino**: Doug has no fucking idea what he is talking about.

**Jeff Bergosh**: Exactly

**Jeff Bergosh**: Talk talk talk

**Mel Pino**: This just went up after we talked. Just one of many stories people are coming forward with fyi. This woman is not one of the usual suspects on ECW. In Beulah.

**Jeff Bergosh**: I know

**Mel Pino**: K

**Mel Pino**: I'm not lecturing you to be a loud mouth know it all Jeff. I'm trying. To snap you out of it. Because not a lot ever has a chance of getting fixed if you don't get it.

**Jeff Bergosh**: I spoke with her yesterday

**Jeff Bergosh**: Sad it had to be dumped on social media

**Mel Pino**: Just so you know there might be a lot more coming. People are taking it to social media because the problem persists, is not being fixed, and people are tired of being lied to about it Jeff. 

**Jeff Bergosh**: It is being fixed, it's just the fix isn't instantaneous

**Jeff Bergosh**: It takes time

**Mel Pino**: And in the meantime falsehoods are being put out and it's not working. People aren't buying it. That's all I am trying to get through to you. It is past the point of PRing.

**Mel Pino**: This is ALSO what I have been trying to say. People just don't think the county is interested in fixing anything. I tell them you guys don't understand how much needs to be fixed because you get robbed by your admins and division leads.

**Mel Pino**: Jobbed not robbed. Such as what is going on right now. He is joining you guys.

**Mel Pino**: Jobbing

**Mel Pino**: I'd like to know how Bart or Doug are connected to GTL solutions.

**Mel Pino**: GTL apparently has a subsidiary hawking supplements and CBD/hemp.

**Mel Pino**: I cant even believe you guys are going to continue to give studer money.

**Mel Pino**: Somebody close to me who knows just looked at that GTL site and he said its complete bullshit government contracts that are fake companies strung together and they are making money hand over first on fake shit. 

**Jeff Bergosh**: I still see a zero in that column

**Mel Pino**: Oh good!! I didn't realize the backup was up.

**Mel Pino**: From here on out its a win win for them on this shit. Don't fund them they cry how awful how corrupt. Fund them they gloat and get ready for the next ask. I wouldn't give them a damn dime.

**Mel Pino**: Ask them to come to PEDC and then don't give them anything.

**Mel Pino**: I thought they only needed a year. Woops!

**Mel Pino**: Still scanning through this GTL scam. Here is their special PURPLE hand sanitizer. It's isopropyl alcohol.

**Mel Pino**: Why were these ones that came in August even allowed onto the agenda?

**Mel Pino**: "African American heritage lady"

**Jeff Bergosh**: Yeah that was inartful

**Mel Pino**: But it didn't come to the Tdc in time.

**Mel Pino**: Where is the engineering plan?

**Mel Pino**: These bozos will have the statue standing on top of the plane by the time they are done

**Mel Pino**: Make sure that none of the ceremonies conflict with the next insurrection at the White house

**Mel Pino**: WHY did this asshole have to ruin such a good project.

**Mel Pino**: Now it's a planesickle?

**Mel Pino**: Did he actually fly that kind of plane?

**Mel Pino**: Nowyou knowwhy Sherri Myers walked out on his shit.

**Mel Pino**: Did dosev get an F4 because that's what he flew? Chappie flew a mustang and a shooting star. 

**Mel Pino**: https://www.sun-sentinel.com/coronavirus/fl-ne-covid-south-florida-death-toll-20210914-czgfrsojuffolcwvalzfgjzuya-story.html

Florida death toll data released in advance of law suit

Now visible in CDC site
https://covid.cdc.gov/covid-data-tracker/#county-view|Florida|12033|Risk|community_transmission_level

**Mel Pino**: So basically they aren't testing or they are dragging out the results of swab tests but even with the big dropout in texting we are still up a percentage change in positivity and over one hundred percent increase in deaths the last seven dies. And that's low because covid deaths are going unreported because the hospitals are kicking sick covid patients back home, coding for other things, diverting calls and DeSantis limited medical examiners from adding to covid deaths with an executive order.

**Mel Pino**: So basically they aren't testing or they are dragging out the results of swab tests but even with the big dropout in texting we are still up a percentage change in positivity and over one hundred percent increase in deaths the last seven dies. And that's low because covid deaths are going unreported because the hospitals are kicking sick covid patients back home, coding for other things, diverting calls and DeSantis limited medical examiners from adding to covid deaths with an executive order.

**Mel Pino**: Last seven days there has been a 7 percent drop in New hospital admissions and a 3 percent drop in beds used. There has been a 116 percent increase in death. So no, those of us saying that the hospitals are jacking with the real story on numbers and driving down case numbers and bed numbers by not testing, not admitting, and diverting have not been wearing tin foil hats.

### CONVERSATION ON 09-15-2021

**Mel Pino**: Check email

**Jeff Bergosh**: Okay

**Mel Pino**: I really think you owe it to the citizens of the county to put that up on your blog, even if you and I disagree about the D2 parameters. Im always for total public transparency and the press might cherry pick, you know.

**Mel Pino**: http://www.ethics.state.fl.us/PublicInformation/NewsAndEvents.aspx

It's up

**Mel Pino**: Posted

**Jeff Bergosh**: I just put the blog post up

**Mel Pino**: I'll bet you are bud. Good fucking luck.

**Jeff Bergosh**: Was this for me??

**Mel Pino**: I'm responding to Doug...he says in there he looks forward to a full investigation of findings

**Jeff Bergosh**: LOL

**Mel Pino**: It should have read "I'll bet he is"

**Mel Pino**: Posted

**Mel Pino**: It's my last and final takedown of that imbecile.

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: I’ll call u right back

**Mel Pino**: K


**Mel Pino**: I really hope you guys call for an investigation on the software problems at the jail go from there. 

**Mel Pino**: If there are illegalities civil rights issues that will come back on you guys :(

**Mel Pino**: This problem will get worse with the project at lake charlene

**Mel Pino**: That is, if the county Does anything about the choke points where that massive amount of water flows down to dump in Jones swamp

**Mel Pino**: Hahahaha yep. Huge pipes draining a giant more amount of water behind Forest Creek, if it doesn't Flood the neighborhoods to the south first

**Mel Pino**: And Corry bridge nothing because there's a previous choke point nder navy blvd

**Mel Pino**: BAM right behind Forest creek

**Mel Pino**: That's why they put the pop off valve up in Myrtle great the elementary school. He's getting ready to cram more water downstream

**Mel Pino**: We weren't politicking on that shit project. I don't care what Chris says it's shit.

**Mel Pino**: He's getting closer to exploding.

**Mel Pino**: Posted a two part comment.

**Mel Pino**: We will be very, very lucky if delta doesn't rear up again here, since they aren't masking the kids at school.

**Mel Pino**: Oh great studer is taking over the Estuary program also?

**Mel Pino**: Say something nice and take the high road

**Mel Pino**: Ask him why the city hall can't house the Estuary program.

**Mel Pino**: Hahahahahahahahaha

**Mel Pino**: Tell him he shouldn't be talking about Pensacola sports money

**Mel Pino**: YES

**Mel Pino**: YOU HAVE GOT TO BE KIDDING ME

**Mel Pino**: I can't believe she got away with this

**Mel Pino**: Support him in this. Janice fucked this so bad

**Mel Pino**: That's not the point.

**Mel Pino**: The point is this shit was so crooked.

**Mel Pino**: They are trying to get to the bottom of this Jeff.

**Mel Pino**: Of course they don't know.

**Mel Pino**: The boxes are probably in janice's trunk.

**Mel Pino**: Hahaahah

**Mel Pino**: He looks like he is going to cry.

**Mel Pino**: I missed it if she is talking about REAP they suck.

**Mel Pino**: So fucking shifty.

**Mel Pino**: Especially since he does such a shit job.

**Mel Pino**: Drop it until you can get a cyber expert in there and go through the county IT with a fine tooth comb. 

**Mel Pino**: Ask him if Pensacola sports is funding his trip

**Jeff Bergosh**: LOL

**Mel Pino**: Hahahaha he is such a fucking tool.

**Jeff Bergosh**: Yes he is

**Mel Pino**: That's supposed be the concurrency meeting

**Mel Pino**: So here is Jacqueline Rogers creeping on my husband's dead dad. The new facilities manager probably has public records requests in on him. Poor guy has no idea.

**Mel Pino**: Mikes father taught briefly at Rowan University.

**Jeff Bergosh**: WEAR finally covered Doug's probable cause finding.  Really vanilla, buried in the broadcast....

**Mel Pino**: Yep and they fucking spotlighted him FOREVER on flooding pontificating on how the board doesn't do enough

**Jeff Bergosh**: Yeah I saw that.  Sympathy play

**Mel Pino**: Studer.

**Mel Pino**: They let him have the pnjbut they know wear is more important.

**Mel Pino**: Call when you can I need to ask you a question.

### CONVERSATION ON 09-17-2021

**Mel Pino**: School board pulled a fast one and voted on the mask mandate at a special meeting this morning. 3 2 against.

### CONVERSATION ON 09-21-2021

**Mel Pino**: Hey call as soon as you can and before the meeting if possible. Important.

**Mel Pino**: Jeff pastor Tisdale is coming tonight and I am begging you to consider supporting funding for her. She does so much good and needs the help. She shouldn't have gotten cut off because people are afraid to say no to reap because of the political people backing it. Reap does NOT need funding. Epp does. Sherri is coming with pastor Tisdale to face down Doug.

**Mel Pino**: Sherri is livid.

**Mel Pino**: Bart Siders can't get the dais program working that he helped Janice advocate for?

**Mel Pino**: Fuck this.

**Mel Pino**: Id enjoy seeing them audited though.

**Mel Pino**: That was so nice Jeff. Thank you.

**Jeff Bergosh**: 👍

**Mel Pino**: Make it three days!

**Mel Pino**: It was 2018 I think

**Mel Pino**: Tell him to shut the Fuck up

**Mel Pino**: Cadillac is one of the few people with any fucking vision on how to do this shit he's got more brains in his little finger than Robert has in his whole body

**Jeff Bergosh**: Yes

**Mel Pino**: Sorry that was supposed to read Doug.

**Mel Pino**: ITS A GROWING EVENT

**Mel Pino**: Jesus Christ these people have no fucking idea what this sort of thing takes

**Mel Pino**: Theyre all down at the school board meeting every Jesus freak and QAnon down there fighting masks.

**Mel Pino**: We have the school board meeting on mute and you can literally tell which ones are against a mask requirement by how fucking crazy they look. 

**Jeff Bergosh**: Glad they get the fun tonight

**Mel Pino**: Sad no policy makers in this town have the balls to stand up to DeSantis and instead do the bidding of the crazy portion of their constituency while kids and teachers get sick and die.

**Mel Pino**: Maybe he would like to give up his discretionary to it.

**Mel Pino**: Hahahahahahahahahahaahhhhahhaha

### CONVERSATION ON 09-22-2021

**Mel Pino**: Posted on the workforce issue

**Mel Pino**: Check my comment on the homeless task force money grab here:

https://ricksblog.biz/homeless-task-force-presents-plan/

**Mel Pino**: Well here's the nail in the coffin. Literally.

https://ricksblog.biz/state-puts-more-covid-decisions-in-parents-hands/

**Mel Pino**: Fyi my elderly neighbor has covid. A friend took her to the ER but they wouldn't admit her and told them to drive her to a care facility. She has been there since the 17th and hasn't seen a doctor. Just nurses. I asked what her care is: nothing. A bed and food. I asked what the prognosis was: she said she didn't know. I asked when they thought she was ready to come home: she said they told her she could go whenever she wants. She can't get out of bed.

### CONVERSATION ON 09-23-2021

**Jeff Bergosh**: In safety meeting will call u back

**Mel Pino**: Yep good news

**Mel Pino**: Hey sorry just trying to connect before I have to go walk the wife of our friend who died (she has Alzheimer's)

**Mel Pino**: The docket is fixed! Check Leon's to see if it's updated also

### CONVERSATION ON 09-24-2021

**Jeff Bergosh**: Knowing I like Metal....thought you might enjoy this

**Jeff Bergosh**: If you haven't seen it already

**Mel Pino**: Hahahahaha just fired up electronics. Lazy nice morning :) hey I put more faith in heavy metal judgment than I do desantis's executive orders. 

**Mel Pino**: I'm crafting a post right now. I was too emotional and worn out last night and I want it to be really good.

**Jeff Bergosh**: LOL

**Mel Pino**: Just posted a two part comment. Had to get it right. 

**Jeff Bergosh**: K

**Mel Pino**: Jeff this is the text that attached to other people I sent to but for some reason it didn't attach on yours. Sorry. 

The 10/1 arraignment is for
Pre trial intervention 

**Mel Pino**: Look at the bullseye map Connor man just posted of BOCC and Ecua addresses on ECW.

**Jeff Bergosh**: What a little bitch he is

**Mel Pino**: Yep it doesn't list the actual addresses but they get their point across. I texted Lois and told her to let her peers know Doug was shit stirring on their addresses.

**Mel Pino**: Connor has to be one of the bigger dipshits I've seen.

**Jeff Bergosh**: Yes that too

**Mel Pino**: Posted in response to the asshole who was above my comment.

**Jeff Bergosh**: Ok

**Mel Pino**: My parting thought on covid for a good long while is posted in the comments here. I hope at one point more good people will recognize the avoidable tragedy that is playing out due to corruption, greed, and power hunger, pure and simple. Because in the end, there is no combination of religious faith and political philosophy that will possibly be able to excuse what is happening in this state and in this county per the pandemic.

https://ricksblog.biz/escambia-county-school-district-falls-in-line-with-lapado/

**Mel Pino**: Officially giving on wear. If that's the best they can do on ems, it's pointless.

**Mel Pino**: Look at the story on their website. Slop and wrong. I haven't looked at the news yet. We tape it every night in case we need to see something.

**Mel Pino**: Didn't mention that Steve white pled no contest to 2 charge and didn't say that had fifteen felonies dropped. Or when that happened. Blended in with the ones that just happened.

**Mel Pino**: No dates on anything.

**Mel Pino**: Bullshit statement on what "state attorney told"

**Mel Pino**: This is too many times that randy has gone sideways. Whether it is under his control or not, I'm done.

**Mel Pino**: Oh and I guess the report said that they all agreed to testify against Jim. 

**Mel Pino**: I'm sorry, Randy. I'm not looking for a fight on this,but I am going to have to handle this bad online reporting on Jeff"s blog :(

**Mel Pino**: Just posted. If you are still plugged in, I really hope you will get that correction of WEAR's reporting up asap.

### CONVERSATION ON 09-25-2021

**Mel Pino**: Still pissed about that bullshit coverage fro wear. This isn't even about county business so don't know if our texts about it are public record.but fyi I got my date wrong...Kate will be cleared on the West, not the 10th. This is from the docket. Its public record.

**Mel Pino**: And this.

**Mel Pino**: Noble prosequi is a formal notice of intent to abandon prosecution. If that doesn't mean this thing is over, I don't know what does. That notice went in the day of the hearing. I really think Tom Williams screwed up his docket work on this and thought it would be over on Thursday. Which shows how little they are used t how things go when they actually drop prosecution. It doesn't happen too often.

**Mel Pino**: On subject of WEAR, they are going from bad to worse and I just can't trust they are ever going to get anything right. That thing they did with highlighting Alex arduini as if he was a reasonable parental antidote to the likes of Dianne Krummel was appalling. Randy claimed ignorance of who he was, but I find it odd of Allah parents who spoke, that demon got selected for the news reel. 

**Mel Pino**: All the, not allah

**Mel Pino**: Nolle not noble.

**Mel Pino**: Fyi Jim wrote an article and thought it got published. He said sometimes ihe submits one on Friday they hold it over the weekend.

### CONVERSATION ON 09-26-2021

**Mel Pino**: Posted on the hundredth birthday.that generation won't come again.

### CONVERSATION ON 09-27-2021

**Mel Pino**: https://www.pnj.com/story/news/local/2021/09/27/escambia-county-ems-scandal-kenney-salter-reach-deal-dismiss-charges/5846456001/

**Mel Pino**: Jeff he did such a good job on that...even getting great quotes from kate'sattorney. Would you consider bringing in for a Monday morning post? This puts a wrap on it and is a much needed corrective to the wear slop. Jim is exactly right when he says they will enter a one year pre trial diversion program next week. The ink is dry with Tom Williams signature right on the docket

**Jeff Bergosh**: Awesome I'm going to call her later this afternoon

**Mel Pino**: Thank you :) 

**Jeff Bergosh**: 👍

**Mel Pino**: Left a VM no need for call back

**Jeff Bergosh**: I'm on Outzen show tomorrow morning at 7:10 talking about EMS 4

**Mel Pino**: Oh that's great.

**Mel Pino**: Sorry I missed you was outsie

**Mel Pino**: Hey I hope if you have it in you you will still bring Jim's article. It is the only fair reporting they had on this and Kate was so happy he wrote it. Good to give him the kudos when he deserves it hopefully he will keep writing unbiased pieces.

**Mel Pino**: Jeff thank you. :) when you go on to Rick's tomorrow, please do not forget to callout ECW's place in this debacle. That hate speech and libel site is on life support and the more decision makers who understand who she and Doug are and what the flying monkeyshave done, the better.

### CONVERSATION ON 09-28-2021

**Mel Pino**: A retired ems submitted this to ecw last night thinking they might feel bad and print it . Because that's how little these people understand about politics.

**Mel Pino**: Hey just a reminder not to mention speaking with anyone who got charges resolved.

**Jeff Bergosh**: I won't-- thanks!

**Mel Pino**: Hey just posted the last two installments of explaining why Doug was intent on blowing up public safety. Was too tired to get it up last night.

**Jeff Bergosh**: Got it

**Mel Pino**: Jeff the board is about ready to to be pummeled by a sustain attack from every downtown corner orchestrated through these massive bureaucracies they are setting up:  children's trust, the homeless task Force, and that studer mental health initiative Michelle is fronting. In addition to the stated goals they are trying to achieve (nebulous as they are), one of the real points is to connect a vast network of interest to move on the county. Not everybody participating is aware that's what's happening, of course. But they are padding their "pillars" with a lot of well meaning people who will get sucked in to their strength in numbers on paper game, with many more circulating in the background.

**Mel Pino**: When you have a chance, read that series I put down because it's the road map to why Doug was trying to destroy our public safety. It has to be understood in that context in order to fix it.

**Mel Pino**: Karen Stewart wood going for the gusto and enjoying the last few moments before she got kicked off ecw 🤣🤣🤣 They blocked her in record time haha

**Jeff Bergosh**: LOL

**Mel Pino**: They deleted a bunch of her comments about me but didn't touch the one David liked 🤣🤣🤣 omg laughing til I am crying

**Mel Pino**: Left you a voicemail.

**Mel Pino**: Kevin emailed those audio files. Left another voicemail on the info.

**Mel Pino**: Robert paving the way for the task Force to come to the bocc on a big ask in the same article Grover outright doubts it's efficacy and says we need a professional consulting firm that knows what they are doing.

https://www.pnj.com/story/news/local/pensacola/2021/09/28/pensacola-mayor-grover-robinson-sets-goal-relocate-110-homeless-camp-120-days/5885673001/

**Mel Pino**: Hahahahahaha

**Mel Pino**: Hey if you are still up check the voicemail I just left on some media coverage.

### CONVERSATION ON 09-29-2021

**Mel Pino**: Excellent article today!! You should pull it in Jeff. Jim actually set the stage for FIXING the problem.

**Jeff Bergosh**: Thanks-- yes-- it turned out good.

**Mel Pino**: He's really not all bad Jeff :) and he DEFINITELY has his eyes opened on Underhill and Jonathan.

**Jeff Bergosh**: Good

**Mel Pino**: Posted.

### CONVERSATION ON 09-30-2021

**Jeff Bergosh**: Check out Troy Rafferty's letter to Pam Childers on the 401(a).  I just linked it on my blog.  💥 💥💥

**Jeff Bergosh**: Kaboom

**Mel Pino**: Wonderful. And I guess Jacqueline pulled down a bunch of that string after my email last night. I am not going to let her just defame those people

**Jeff Bergosh**: No-after I read the emails you sent, I went and checked.  All still there.  Karen Stewart Wood rammed the truth up Jacquelin's ass hole

**Jeff Bergosh**: It's beautiful to witness

**Mel Pino**: Okay Kevin just looked though

**Mel Pino**: Sorry panhandle slim not fanboy haha

**Mel Pino**: DON'T circulate that haha it's not about county business.

**Jeff Bergosh**: LOL I won't 

**Mel Pino**: Posted on medical at the jail. 

**Mel Pino**: Posted on your ems part II.

**Mel Pino**: (Go county! Somebody just sent me this)
   Hmm I wonder if it's criminal to misrepresent a tree as a 54 inches instead of 84

### CONVERSATION ON 10-02-2021

**Mel Pino**: Check voicemail when you can.

**Jeff Bergosh**: Will do after tennis

**Mel Pino**: You're gonna love it haha

**Mel Pino**: Check that address when you can. No rush.

**Mel Pino**: Posted on the medical billing.

**Jeff Bergosh**: That post is blowing up with hits and comments.  I just approved five more comments

**Mel Pino**: I'm so glad Jeff. It's all finally coming out. :) God it is such a weight off my back you have no idea. So many sleepless nights worrying about this.

**Mel Pino**: Looks like one of my favorite researches has been going to town on what we lost when they forced Steve white out. Look at that man's record and imagine him doing the things they accused him of doing. And the shame it brought him. It's unfathomable.

**Mel Pino**: I hope that this finally demonstrates just how much of a cover-up administration can orchestrate on its own board. Because this thing has been going on for years and is only now all coming to light. 

**Mel Pino**: Posted a couple barn burners in advance of letting fly tomorrow.

**Mel Pino**: Posted a couple with very serious thoughts on the people who did this.

**Mel Pino**: Said I would respond point by point on medical billing as soon as people understood the context.

### CONVERSATION ON 10-03-2021

**Mel Pino**: Check voicemail kinda important

**Mel Pino**: Posted in response to medical billing. Thanks for those maps I couldn't make out...appreciate it.

### CONVERSATION ON 10-04-2021

**Mel Pino**: So she's terminated?

**Jeff Bergosh**: Who?

**Mel Pino**: Edler.

**Mel Pino**: That's from the county's defense reply to her complaint on 9/13/21

**Jeff Bergosh**: Don't know.  I know she's no longer medical director though-- which is a good thing

**Mel Pino**: Read that page. It says she was terminated.

**Jeff Bergosh**: Yes

**Mel Pino**: FINALLY!!!!!!!!!!!!!

### CONVERSATION ON 10-05-2021

**Mel Pino**: Check voicemail when you have a chance. LaFannetta soulswood died of covid this weekend and it is heavy on people's minds.

**Jeff Bergosh**: Can u talk?

**Mel Pino**: Yes

**Mel Pino**: Hey thinking that text might have been an accident?

**Jeff Bergosh**: I'll call u in 5 okay?

**Mel Pino**: K

**Mel Pino**: K

**Mel Pino**: Correction: lafennete died of a heart attack

**Jeff Bergosh**: 👌🙏

**Mel Pino**: Left a voicemail

### CONVERSATION ON 10-06-2021

**Mel Pino**: Jim did a nice job on redistricting. I let him know that perdido key didn't change because of census numbers Gerry mandering

**Mel Pino**: Left you a voicemail. Call when you have time it's not urgent.

**Jeff Bergosh**: Okay will do

**Mel Pino**: Hahahaha omg just saw the empty chair

**Jeff Bergosh**: 😎

**Jeff Bergosh**: No show

**Mel Pino**: Just posted to empty chair.

**Mel Pino**: Oh wait Jeff I was trying to respond to the previous one. I will repost it there and you can kill it on the empty chair

**Mel Pino**: Wooooooo hooooooo

**Mel Pino**: They have started on #4, Silt screen is up

**Mel Pino**: Just had a great talk with Paul Fetsko.

### CONVERSATION ON 10-07-2021

**Mel Pino**: Hey I don't know if you have the ability to post while you're travelling today, but I just put up a two parter on Jonathan Owens.

**Mel Pino**: He needs to stay the fuck off that ticket.

**Mel Pino**: Here we go. Let the games begin.

https://www.pnj.com/story/news/local/2021/10/07/new-charter-form-government-escambia-county-pitched-group/6021062001/

**Jeff Bergosh**: Yes but we knew it was coming

**Mel Pino**: Holy shit check Rick's blog. Vicki's on the charter advisory committee hahahahaha

**Mel Pino**: Omg it's like the party you would never, ever want to be trapped at.

**Mel Pino**: Jerry Maygarden first name on the list

**Mel Pino**: And Ed Fleming hahahahahaha damn I hate you are on vacation

### CONVERSATION ON 10-08-2021

**Mel Pino**: Check my comment on redistricting here.

https://ricksblog.biz/who-are-the-20-supporters-for-peacocks-proposal/

**Mel Pino**: Charter rather. 

**Mel Pino**: Marlette has really jumped the shark this time. He really knows how to pick his enemies. Please please please don't blow this up with a blog cartoon Jeff. Stay focused on redistricting Andy just hung himself well enough on his own.

https://www.pnj.com/story/opinion/2021/10/08/escambia-commissioners-dont-understand-legal-vs-moral-andy-marlette-column/6032129001/

**Mel Pino**: I just commented on Andy's jump the shark moment here.

https://www.pnj.com/story/opinion/2021/10/08/escambia-commissioners-dont-understand-legal-vs-moral-andy-marlette-column/6032129001/

**Mel Pino**:  Sent this to a couple of people Jeff. Maybe Levin Pap have had enough.

 Jeff's blog post about one of Andy's racist cartoons. It's not the only one. Jeff wanted to get a boycott going of PJ's ad dollars but couldn't get traction.
 http://jeffbergoshblog.blogspot.com/2021/03/blog-post_15.html?m=1

**Mel Pino**: Please check my comment here on charter and previous administration.

https://ricksblog.biz/what-happened-at-group-for-a-better-government-meetings/

### CONVERSATION ON 10-11-2021

**Mel Pino**: Now there's a once in a lifetime headline.all the lawyers in town will be Framing it haha

https://ricksblog.biz/why-attack-the-attorneys/

### CONVERSATION ON 10-12-2021

**Mel Pino**: When are you back?

**Jeff Bergosh**: Wednesday afternoon

**Mel Pino**: Cool

**Mel Pino**: Karen sindel and Vicki Haines Campbell on Kevin Brown's campaign team.

**Jeff Bergosh**: Team Kevin! 

**Mel Pino**: You picked a good week to be on vacation. It's a fucking shit show back here right now.

**Mel Pino**: I'm working on the boat ramp.

### CONVERSATION ON 10-14-2021

**Mel Pino**: Oh good God. Cyber enterprise risk management insurance. Slot in a half hour for Doug to drag that out while he spouts outdated information about cyber.

**Mel Pino**: Oh that is such great news on the wage increase

**Jeff Bergosh**: Got dragged into a meeting will call you on my lunch break

**Mel Pino**: No worries

**Mel Pino**: Posted to Edler termination.

**Jeff Bergosh**: I'll call u right back

**Mel Pino**: K

**Mel Pino**: Jeff I know there is a ton going on but it would be so awesome if you would hit on that boat ramp at commissioner forum. Worked my butt off on that :) I want them to understand I am going to stay on top of things

**Mel Pino**: This is one of the issues that they are going to pummel you guys on out of the city. Because people are sick to death of watching clea cutting and huge trees gettin chopped down in the county. The outrage over it is really growing.

**Mel Pino**: I was working out in the yard this past couple of weeks and the first thing people wanted to ask about is are we getting anywhere on the county cutting down trees.

**Mel Pino**: That's bullshit,everybody knows it, and if you guys keep allowing the destruction of our canopy and this kind of wanton wreckage, it's going to become a bigger and bigger issue. Especially as our Stormwater problem grows apace. I don't agree with margaret's approach these days, but the county is looking horrible to legions of people on this issue right now. Not just the one off occasional huge tree, but the absolute disregard of the board to the builder's benefit.

**Mel Pino**: So you just made the argument that the tree is to damn big to live.

**Mel Pino**: "Sadly there is a mitigation to pay." Yes and you guys are policy makers. It's your policy that is allowing it

**Mel Pino**: Public private to include private donations adding on the price.

**Mel Pino**: There are people that would throw down wild money to add on to what government can do

**Mel Pino**: Here's your moment. PKA isn't fighting the redistricting. 

**Mel Pino**: Or he'd be talking about it. If you are commissioner the Perdido Key Master Plan will be followed faithfully, environmental regs will be followed, and you will bring parking and more beach access.

**Mel Pino**: Pka is turning against lennar/ mirabile/troon/honours golf course.

**Mel Pino**: They see Doug has fucked them.

**Mel Pino**: WCI is mirabile

**Mel Pino**: You should ask krupnick to call you so you can discuss these issues with him as there is a good chance you will be running the key in january

**Mel Pino**: Doug, do you mean like you are not compliant in dozens of ways on your property...enviro, code, building off permit. Including when you were a contractor.

**Mel Pino**: Texted him that.

**Mel Pino**: This is what I have been trying to convince you guys. These problems can't continue. Again I don't agree with Flood defenders approach and unjoined their group. But you guys have got to stop this stuff. You can't just keep ignoring it.

**Mel Pino**: Instead they bought a fishing camp and scammed FEMA through three storms.

**Mel Pino**: Rick facione is Doug's old business partner.

**Mel Pino**: Doug's company coastal homebuilders shared an address with facione and speranza on sunbiz

**Mel Pino**: Actually Doug's partner was technically speranza but they were all in it together. 

**Mel Pino**: Perdido estates took them to court. There was  action against speranza/ facione while Doug was on paper with speranza's daughter Morgan on his own company. He blocked county staff from enforcing.

**Mel Pino**: Peridido estates is across the street from treasure hills, which Doug and Wendy got run out of town on after he finished his enlisted here.

**Mel Pino**: Doug, with everything else you have going on, you really might want to turn yourself in for your contracting crimes. It would save everybody a lot of time and hassle and they would probably be more lenient on you.

**Mel Pino**: Ask Doug if he had business connections with speranza and facione while the court order was being ignored. When he lies ask him why they shared a business address on sunbiz.

**Mel Pino**: Becuase his business coastal homebuilders shared an address on sunbiz with facione and speranza while this was going on. While he was on paper with Morgan speranza.

**Mel Pino**: Doug has set it up to try to force the county to buy them for speranza/facione.

**Mel Pino**: He is realizing he can't keep up the shell game any more.

**Mel Pino**: BAM. That's why Doug was calling for classic homes to be held accountable. Dissolved.

**Mel Pino**: That's not true. They are building in wetlands and swamp every day. Just need a magic soil sample erasure.

**Mel Pino**: Or rather than scooping bigger holes into the ground for Retention ponds that don't work, you could stop allowing clear cutting of trees.

**Mel Pino**: Omg it finally came through!!!!

**Mel Pino**: JAR tried to insinute that Rob Hogan got his job became he is coming from the same university that Mike's Dad had a brief professorship at in South Jersey haha

### CONVERSATION ON 10-15-2021

**Mel Pino**: Jeff this is why I am desperate to get this project out. These cheap mesh bags are breaking open and all the shells are spilling out onto the Sandy bottom. As was the point, to wreck the shoreline for human use so that they could shut it down for swimming and Doug could try to sell the park. This bag was sitting on the shoreline this morning

**Mel Pino**: HORRIBLE. PROJECT.

### CONVERSATION ON 10-18-2021

**Mel Pino**: Call when you have a chance. Not urgent but important.

**Mel Pino**: To the surprise of no one, Broxson sent out an email endorsing Kevin Brown today. 

### CONVERSATION ON 10-19-2021

**Mel Pino**: Was just gonna remind you I'm on at 7. :)

**Jeff Bergosh**: Good job!  Taco Tuesday

**Mel Pino**: Elevator pitch was bad but otherwise pretty happy with it :)

**Mel Pino**: I wondered wtf that video was about. Chip needs better people advising him on this sort of thing. This was amateur hour.

**Mel Pino**: This is what happens when you start taking your PR advice from CivicCon and your chief deputy's wife.

**Mel Pino**: https://ricksblog.biz/real-news-podcast-meet-melissa-pino-kevin-brown/

### CONVERSATION ON 10-20-2021

**Mel Pino**: Posted. 

**Mel Pino**: Thisis gonna be fun hahaha

**Mel Pino**: Hey sorry I left an important word out of the first sentence. I reposted with that word in...please post the second one!

**Mel Pino**: This was a new bag on the shore yrsterday

**Mel Pino**: Hey Jeff thank you for posting and I am SO sorry...try not to do this often. If you would grab that repost I was be so grateful, and delete that one. First sentence makes no sense.

**Jeff Bergosh**: Ok

**Mel Pino**: Thank u!

**Jeff Bergosh**: 👍

**Mel Pino**: That may give me enough room, Jeff. Not making any decisions yet.

**Mel Pino**: Yeah!!!!!!! Check my tag :)

**Mel Pino**: Any more questions now about who these guys are aligned with? That talking point sure sounds awfully familiar.

**Mel Pino**: Don't worry I'll spell it out haha. This isn't about county business so it's not public record. Kevin Brown's talking point on the BP money isnt just sanctioned by Doug broxson. He is there to speak things for broxson that broxson won't. And Karen Sindel and Doug are part of the mix. They probably bought Doug out. Word on the street is Doug put out an asking price of 300k.

**Mel Pino**: They were ready to drop this stuff to offset the good news on BA4

**Mel Pino**: And somehow, miraculously, it is Dovetailing nicely with Kevin Brown's interview yesterday. Here we go again.

**Mel Pino**: All orchestrated.

**Mel Pino**: Basically the missing piece and the big O failed to get their water carrying done, so they had to set up an entire machine to try to dismantle you guys.

**Mel Pino**: And get you to write checks to the nicer, gentler version of Doug.

**Jeff Bergosh**: LOL Conor and Jonathan are stressed over redistricting not going their way.  Boo hoo boys LOL😂😂😂😂😂😂😂😂😂😂😂

**Jeff Bergosh**: ...... and that's all they got a missed spelled sign that's not even a county sign??😂😂😂😂😂😂😂

**Mel Pino**: Right? They aren't the problem though. Out with the old Doug in with the new is.

**Jeff Bergosh**: "Let's go Brandon!!"

**Jeff Bergosh**: 😂😂😂😂😂

**Mel Pino**: Sorry. This isn't funny to me, when Kevin Brown tee'd it up. I take shit seriously when other people don't see it so I can help mop up after the carnage.

### CONVERSATION ON 10-21-2021

**Mel Pino**: Colin Powell had blood cancer that included a B cell immunity that ensured the vaccine wouldn't work.

**Mel Pino**: I guess Robert's version of my tacos is taquitos. You've got to be kidding me.

**Mel Pino**: Doug giving a shout out to the fish house and McGuire's. Guess hes liking that these days.

**Mel Pino**: You've got to be fucking kidding me.

**Mel Pino**: Somebody needs to get control of Ecua.

**Mel Pino**: Doug, did I just hear you say "This is in keeping with the way we've always done it, so hats off" ?

**Mel Pino**: What people are tired of is shit construction, clear cutting, and flooding problems to adjacent areas. Which of course can be solved with better policy and low impact development without squeezing the market. 

**Mel Pino**: He did not just do that.

**Mel Pino**: The way the CARES money ended up getting handled wasn't exactly a beacon of superior management

**Mel Pino**: https://money.cnn.com/2014/05/20/technology/innovation/chattanooga-internet/

**Mel Pino**: Oh my god will wonders never cease. Bart Siders made sense today and JAR gets called out for her lies. Woo hoo good day!!!

**Mel Pino**: This meeting is soooooooo much better than last week. Happy!

**Mel Pino**: Right because Roberts buds at roads Inc were planning on change ordering the shit out of that project.

**Mel Pino**: Jeff this is what the project was going to cost. With the real money actually up front.

**Mel Pino**: If anything putting it back our forced a realnumber on the project.

**Mel Pino**: Hes going to hear about this at next public forum.

**Mel Pino**: Doug originally moved Federal money from beach haven Sewer up to lake charlene

**Mel Pino**: Janice split that project in two to intentionally drive cost up as payback. 

**Mel Pino**: Oh great a joy Jones analysis. That will straighten things up. You guys did NOT recommend the split. At least on the dais. Janice brought that shit back for Doug.

**Mel Pino**: Woohoo hoooooo

**Mel Pino**: "In some way we're friends. In some wayswe're not." 

🤣🤣🤣🤣 Jesus he is a sad sack

### CONVERSATION ON 10-22-2021

**Mel Pino**: Left a message

**Mel Pino**: Gee. I wonder why joy Jones turned in her resignation after Doug smeared me-ON beach haven. Maybe because she knew I was going to bust that procurement.

**Jeff Bergosh**: February 18th

**Mel Pino**: Thnx

**Mel Pino**: Sorry

**Mel Pino**: The real losers are the constituents who have had to suffer from Doug Underhill being their commissioner,  Lois. A bane and scourge to everything he touches. The second procurement on this project was weighted, also. Feel free to give me a call if you want to discuss.

**Mel Pino**: Unlike other people who are just trying to score politics, I understand exactly what has happened on the past, why this is happening now, and am trying to help get it across the finish line nonetheless. Doug loves to put it out that I like to kill his projects for political reasons. It's a crock of crap. You know I have been advocating for moving along navy point and beach haven sewers for years. But I'll be darned if I going to let two bad back to back procurement start the project off on a the wrong foot. I don't think the project needs to be rebid unless there is something wrong legally the way it was handled. I assume it was shady but not illegal. I want the project moved at the next meeting but Doug is going to have to lay down more discretionary (as ALL commissioner are doing) and it would help if Ecua would contribute to the cost overage. Because if you think the project was going to come in at that first bid of 12M, I've got a Corry bridge I'd like to sell you.

**Mel Pino**: Commissioner Bergosh laid out 10 percent of the total cost of the bellview library out of his discretionary on overage from skyrocketing costs. If somebody can't talk some sense into that man, then there won't even be a discussion much less three votes....anybody can see that from the meeting.

**Mel Pino**: Posted

### CONVERSATION ON 10-23-2021

**Mel Pino**: I just posted on the false report Doug filed on Margaret and Kelly under an alias. Again, I am not down with the turn some of the advocacy has taken,which is why I turned the legal on the tree into Laurie Murphy's far more capable hands. But I'm not going to let him libel people, either.

**Mel Pino**: Just got this:

Hey so FYI the homelessness taskforce just become subject to sunshine law you may be able to find some interesting 🧐 stuff 

**Mel Pino**: Too late to pull that money back?

### CONVERSATION ON 10-24-2021

**Mel Pino**: Check my new post on Facebook on beach haven.

**Jeff Bergosh**: K

### CONVERSATION ON 10-25-2021

**Mel Pino**: Great article on ems and blue collar in PNJ

**Mel Pino**: https://www.rollingstone.com/politics/politics-news/exclusive-jan-6-organizers-met-congress-white-house-1245289/

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Went to one of these before---as an invited guest----then I got bashed while there.  Fucking Joke as is Myra Van Hoose who runs it

**Mel Pino**: Yep. Michelle is getting pretty tight with vivkihese days. Keep an eye on that.

**Mel Pino**: 3 officers left code. 2 sergeants one foot out the door. 

**Mel Pino**: 5 altogether

**Mel Pino**: Poor leadership other than Tim. Bad middle andupper management.

**Mel Pino**: NOT telling you that tone a negative Nancy. Just providing you with information. 

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: Separated at birth?

**Mel Pino**: I'm still trying to figure out the fixation with dressing your children as chickens and sticking them in the buckets they would occupy if they had their heads chopped off so they could be deep fat fried and eaten. But hey, that me.

https://images.app.goo.gl/JCWQBW9mF5DmkyYz9

**Jeff Bergosh**: LOL

**Jeff Bergosh**: *a smear

### CONVERSATION ON 10-27-2021

**Jeff Bergosh**: So now Tallman MCKay is blaming Matt Selover for all the recruiting and poaching. According to Matt it's a bunch of bullshit

**Mel Pino**: Of course it is. All sideline games to distracting people from redistricting so things get solidified for a particular candidate.

**Mel Pino**: Just posted. I don't know what can be done to help Matt. These people are ruthless. 

**Mel Pino**: I posted

**Jeff Bergosh**: Okay just approved it

**Mel Pino**: No on matts

**Jeff Bergosh**: I’ll call u right back

**Mel Pino**: If Doug won't cough up his discretionary, tell him fine. And that the board will fund it and take control of the projects in his district for the rest of his tenure. You guys will decide what gets done and what doesn't.

**Mel Pino**: You guys could make the rare--as in one and only--time that 4 commissioners decide it will be their votes and discussionthat decides what happens in a renegade commissioners district. It solves his lame duck bullshit and totally takes power away from him. Either he funds this fucking thing, or he loses direction of his district. How's that for a win win? :)

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: Going on ricks show in 5 minutes

**Mel Pino**: Dealing with Cox service call how did it go?

### CONVERSATION ON 10-29-2021

**Jeff Bergosh**: Happy Friday Mel!  Some tool on Escambia Hate Watch posted a news report on New Orleans' EMS service being ina massive crisis-- not responding to most calls even critical ones.  Isn't that the same team the Magnificent Former Escambia Medical Director "built" for success?????????

**Mel Pino**: The landing page headline was "spend Halloween at the elbow room"

https://www.pnj.com/picture-gallery/news/2021/10/29/celebrate-halloween-elbow-room/6199587001/

### CONVERSATION ON 10-30-2021

**Mel Pino**: Gee, it's now headline news.

### CONVERSATION ON 11-01-2021

**Mel Pino**: Call when you can. And if you want a laugh look at Grover post on my Halloween string from last night accusing me of wanting population control hahaha

**Mel Pino**: Oh I posted on your new blog

**Jeff Bergosh**: 👍

**Mel Pino**: Call when you can important

**Jeff Bergosh**: Will do

### CONVERSATION ON 11-02-2021

**Mel Pino**: So Ecua is only doing 250k??

**Mel Pino**: Lois told Dean tell people 2M

**Mel Pino**: Nope on phone with Dean it was Bruce Woody ha talked to who told him they voted an extra 2m. No wonder Lois has been avoiding my phone calls.

**Mel Pino**: I just told Stacy Hayden the board doesn't give a shit about 250k towards the grand total and they might as well have voted nothing because that's an insult.

**Mel Pino**: Lois when Bruce Woody told dean 2m he thought he meant the board voted and extra 2m, which would have been in line with the cost sharing. People were so pleased and we would have had a strong place to advocate for ARP. Now that it's clear that it was only bringing it up to 2m, which I think is only 250. K more? I haven't seen the hard numbers. But if that's what they voted in your absence,  it might as well have been nothing that's such a small drop in the bucket. Still going to advocate for Arp and getting project over the line, but that number doesn't make it easy.

**Mel Pino**: Is Patty talking about starting from Roberts changes? He loaded up on population during those changews

**Mel Pino**: Get the stuff Robert gained through his last minute changes off that map

**Mel Pino**: NOT HIS DISTRICTS TO BE MESSING

**Mel Pino**: This is where Robert messed with the map between 2 and 3 downtown

**Mel Pino**: When are you doing public forum

**Mel Pino**: Take public forum hahaha

**Mel Pino**: You guys almost have it fixed before public forum.

**Mel Pino**: DAMN I didn't have my ringer on. Just trying to figure out where the line got drawn on the west side

**Mel Pino**: Can you shoot me a copy of the map as soon as Stafford gets it to you?

### CONVERSATION ON 11-03-2021

**Mel Pino**: Btw janice's procurement guy has ignored my public record request on the beach haven procurement. As I figured he would.

**Mel Pino**: Thank you for sharing those photos of what David Stafford needed. I still don't get the reasoning, but at least I get the carve out. It's impossible to explain over the phone. I still won't understand what the heck happened with some of it until the map gets released.

**Mel Pino**: Just received it from Supervisor of elections...I made a verbal Prr to them last night, but said I would send an email, then didn't cause I figured they had enough on their plate. They sent it anyway, which was great of them.

**Jeff Bergosh**: Just sent

**Mel Pino**: Thank you

**Jeff Bergosh**: 👍

**Mel Pino**: I just emailed you some procurement docs that I just now had a chance to read thoroughly.

**Mel Pino**: I'm really grateful to Alison obtaining these PRRs. I don't know why it takes bothering the county attorney to get some folks to respond.

### CONVERSATION ON 11-04-2021

**Jeff Bergosh**: Thx I'll take a look

**Mel Pino**: I left you a voicemail on it I have to go sit with an Alzheimer's friend this morning.

**Mel Pino**: I forwarded that email with the docs...the attachments must not have come through for some reason. They are there on my side. Let me know if you can open them this time.

**Mel Pino**: I emailed you that other doc that procurement did not provide

**Mel Pino**: Technically legal I guess. Thank goodness. Worthless as a rebid, other than to drive the cost of the project up for a big dog.

**Mel Pino**: I have advocated hard with Ecua to come down with something more tonight. Bruce, Lois, and Stacy are supposed to be there. I didn't know that Bruce has discretion up to 100k and anything beyond that goes back to the board.

**Mel Pino**: Hopefully Bruce would at least give his discretionary. Not much I know but a sign of good will in contrast with a commissioner trying to blow up his own project.

**Jeff Bergosh**: I just texted u Doug's latest map.  It's still DOAand a Jackson Pollack shit toss at the wall

**Mel Pino**: I can't wait to speak to Doug's new map. So glad he put that on the agenda.

**Mel Pino**: Bruce Woody can give a hundred ' of discretionary.

**Mel Pino**: See if he's willing to bring Doug along.

**Mel Pino**: Hundred k

### CONVERSATION ON 11-05-2021

**Mel Pino**: Kevin Adams has no right to mess around in Laura edler's district. There are a lot of people very pissed off about that and his continual racist disrespect of her.

**Jeff Bergosh**: What happened?

**Jeff Bergosh**: Will call u right back

**Mel Pino**: Check email I'm sorry to bug you but I need some help with numbers

**Mel Pino**: I just sent an email clearly identifying that Doug Underhill and "Danny" speranza were registered agents of coastal homebuilders in 2008. It also shows the connection with the shared mailing address, with speranzo's address on various forms matching the address coastal still lists (on eight mile Creek). It further shows that although Doug was on the books for coastal until Dec 11 of 2017, he didn't list them on his financial disclosure with the county. So either he made no money over a thousand that year (I think that's how it works?) Or he didn't disclose.

**Mel Pino**: Posted.

**Mel Pino**: Check email again. I forgot that the now defunct homebuilders Association that Doug was railing against also shares and address with coastal homebuilders both now and when he was on the books with them at the same time he was commissioner of perdido estates.

### CONVERSATION ON 11-07-2021

**Mel Pino**: Posted

**Mel Pino**: Hey did my comment not come through?

**Mel Pino**: I put it back through.

### CONVERSATION ON 11-08-2021

**Mel Pino**: When the tide goes all the way out in the winter, those piles just sit on sand for days on end.

**Jeff Bergosh**: It looks terrible

**Mel Pino**: And is very, very dangerous. On top of eroding our shoreline faster because when the water is really moving it funnels behind the shells because the project didn't take into effect that this is an Estuary where the water moves in a circular pattern, not a bayou or a bay. When they dredged for the bridge that's when it created an Estuary effect. Which is wonderful. But this project should have stopped on the FIRST flow chart for deciding whether to put in something like this,which is the question "is this a high movement water body." Yes it is. Then the arrow points to "no." It's just a mistake. That's all. Mistakes can be corrected and this one is easy to fix by moving the shells over to the boat ramp side where they WILL help and nobody is supposed to be swimming.

**Mel Pino**: Calling you about something else though

**Jeff Bergosh**: What a guy!

### CONVERSATION ON 11-09-2021

**Mel Pino**: Does he even know about the conversation that happened after he left the meeting?

**Mel Pino**: I wish you would stop pounding the elected official argument. You don't need it.

**Mel Pino**: Lois is at the end of her term.

**Mel Pino**: I would like to hear a real discussion of Lumon dropping down without that in the way.

**Mel Pino**: Doug was out in the lobby talking to the press hahaha

**Mel Pino**: When he opens his mouth again tell him he thinks the press is more important than business.

**Jeff Bergosh**: LOL that doesn't surprise me

**Mel Pino**: Call quick if you can. Important.

**Jeff Bergosh**: Will do.  Finishing up my final report at the office.  Will call u in 5 from the road

**Mel Pino**: 👍

**Mel Pino**: House bill and Senate bill aren't technically connected yet. Just conveniently linking. Somebody might point out the connection and blam it's a brand new all encompassing super charged bill.

**Mel Pino**: Oh and Randy wood can go fuck himself. 

### CONVERSATION ON 11-10-2021

**Mel Pino**: Doug is holding a town hall in Beulah andTHE others. The county is paying to stream all three of them.

**Mel Pino**: In good news, Kevin Brown only pulled in 20k and the rolls are a hot mess.

**Mel Pino**: Sherri just pointed out that because this is federally funded it would have to be Ada compliant for wheelchairs.

**Mel Pino**: Vince Gibbs is making his argument right now.

**Mel Pino**: Wibbs

**Mel Pino**: Jared Moore just called his project the "best bet."

**Mel Pino**: Jared just called it "indigestion" about "safe outdoor spaces"

**Mel Pino**: He just compared the homeless camp in d1 with the "navy Fed model"

### CONVERSATION ON 11-11-2021

**Mel Pino**: See comment

https://ricksblog.biz/underhill-to-hold-three-town-halls-to-keep-perdido-in-d2/

**Jeff Bergosh**: LOL he's getting his ass handed to him in those comments

**Mel Pino**: I can't wait for the one down in perdido key.

**Jeff Bergosh**: I've got a feeling they'll all be yawners.  Staff, a few sycophantic, water-carrying Kool Aid drinkers, and a few lookie-Lou types that stumble in.  I don't think it changes anything

**Mel Pino**: Andrew del Gaudio going on Rick Outzen tomorrow morning

**Jeff Bergosh**: I'll be golfing I'll check the podcast.  What's his topic-- he should have been on today for veteran's Day??

**Mel Pino**: Nope. He wants to offer a corrective to Michelle Salzman's view of things.

**Mel Pino**: Btw this is one thing Dave Glassman's fake shell shit money laundering fraud has wrought. They represented this guy as a wounded warrior. He is not.

https://www.al.com/news/2020/12/veteran-now-charged-with-capital-murder-in-11-year-old-jeffco-boys-hunting-death.html

**Mel Pino**: Glassman thinks he crawled out of that one unscathed because he managed to keep it quiet around here. He may find differently when the trial starts in February and his facade AHERO has been named has been named in the wrongful death lawsuit.

**Mel Pino**: This is the little boy who was killed.

https://www.thetroyellisfoundation.com/

**Mel Pino**: None of that public record his has nothing to do with county business.

**Mel Pino**: Michelle is trafficking on Andrew's name on her Facebook page and he is not happy about it. Dave Glassman is now front and center on the women's monument.

### CONVERSATION ON 11-12-2021

**Mel Pino**: https://ricksblog.biz/real-news-andrew-del-gaudio/

**Mel Pino**: Bannon just caught criminal charges

### CONVERSATION ON 11-14-2021

**Mel Pino**: Morning, I'll forget it I don't mention it in the moment. Srlg is offering fifteen k signing bonuses. Somebody just posted it on ecw.

**Mel Pino**: 15k for medics 2500 for emts

**Mel Pino**: 15k for medics 2500 for emts

**Mel Pino**: Sorry

**Mel Pino**: Oh hey and on your way home you better apologize to Sally that you are going to owe me a LOT of steak dinners for all the people headed to jail haha

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Everyone wants paramedics

**Mel Pino**: Eveyone wants the biggest porterhouse at the district on the tab of their favorite commissioner. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-15-2021

**Mel Pino**: 2 Greenberg associates indicted

**Mel Pino**: Carne asada burrito from the truck next to vannoys

**Jeff Bergosh**: Looks tasty!  I like mine basic:  steak, guacamole, and salsa Fresca---I don't care for the rice and beans and lettuce inside that's more of a Tex-Mex thing and not authentic but I'm gonna give them a try!

**Mel Pino**: They'll make it to order...that one was loaded

**Jeff Bergosh**: How's the hot sauce?  Do they have a hot red sauce?

**Mel Pino**: This is their hottest regular. We are still trying to get them to cough up their hot hot they makes for themeselves

**Mel Pino**: They also have the best pancit and lump in town. And their Peruvian is authentic. It's unbelievable.

**Mel Pino**: Their tacos barria are fried and come with consomme on the side

**Mel Pino**: Jeff if you are up can you please call. Nothing about agenda--very important

**Mel Pino**: Left you a message and accidentally hung up on it

### CONVERSATION ON 11-16-2021

**Mel Pino**: Jeff all I can find is an item on blue angel. Nothing on river road.

**Mel Pino**: Never mind it's there. Two separate projects. Backup got buried in the packet.

**Mel Pino**: Please pay close attention to what I'm going to say on that property because we have been tracking that shady shit for a loooooong time Jeff. And that property is at the heart of his business plans. I'll do other staff a favor and bust this shit wide open but you have got to trust I know what I'm talking about. For once. :)

**Mel Pino**: Jesus Christ. There is Nothing in the packet I can see. I could be wrong because I haven't had time to cone but I don't even think the address is in the big packet?

**Mel Pino**: Left a quick follow up voicemail

**Mel Pino**: If Beach haven doesn't get moved up Lumon will be gone.

**Mel Pino**: There were two rounds of change of ownership. The second is when Grover got some California group if memory serves to donate some preservation. That's the vote Doug recused himself on I believe. Calling all this from memory but you could see from his response it hit pretty close to home.

**Mel Pino**: Wanted to confirm this before I said anything more. The path in front of Doug's house is indeed a multi use path. It went in under gene. Doug hooked it up with the current multi use path and connected in the design. He has also been saying that a needed repave is set to happen and when it does he's going to widen it.

**Jeff Bergosh**: Sounds about right

**Mel Pino**: 👍

**Mel Pino**: I'm turning him in for another code violation.

**Mel Pino**: He excavated a trench to send Stormwater off his property into the bay

**Mel Pino**: Now it's filled with water and cat tails and posing a potential sinking danger for him and his neighbor.

**Jeff Bergosh**: He can't just go and dig a drainage trench to the bay!  What a tool!  

**Jeff Bergosh**: I'm going to double check the tape but that's my recollection

**Mel Pino**: K let me know. I think Steven relented on rest ore. 

**Mel Pino**: Its the 8.4 in BP oil fund money. 

**Mel Pino**: Edited it...thank you

**Jeff Bergosh**: Yes.  Look at 1:20 of the video

**Jeff Bergosh**: (So essentially it's all from his discretionary money anyway) 😎🎩👌

**Mel Pino**: Essentially there is no such thing as different pots of BP it's all "fungible." Whatever you guys called it--it gonna come from BP. But I do appreciate the heads up so I was technically correct.

**Jeff Bergosh**: Nice job

**Jeff Bergosh**: And he's bouncing all over the place on topic to topic

**Mel Pino**: Did Doug's map satisfy the deviation?

**Mel Pino**: He's lying like a rug

**Jeff Bergosh**: It balanced numbers-wise but was a train wreck in all other respects

**Jeff Bergosh**: Giving it to Doug??   Good!!!!

**Mel Pino**: Yep

**Jeff Bergosh**: Glad Mike is giving it to him

**Jeff Bergosh**: *thud

**Mel Pino**: Yeah. I'm on the ground that Kevin went there with the jet ski comment. I don't know what he was thinking. :(

**Mel Pino**: Low blood sugar.

**Mel Pino**: He was just gonna correct the lie that Myrtle grove didn't change.

**Jeff Bergosh**: It was great

### CONVERSATION ON 11-17-2021

**Mel Pino**: Woops didn't realize it was so early. Daylight savings still messing with me. Give me a call on your way in if you have time

**Mel Pino**: Fyi the Roger Scott courts are going to get huge pushback after Grover bait and switched you guys (natch) and is now actually doing an expansion and cutting down seventy protected trees including two heritage trees. In addition the lease has been expired on the management company for a year and they are saying the financials are not public record when they have been making profit off a government funded facility. It hit the bricks at the city council meeting because Grover hid the trees the huge expansion and the Stormwater pond from city council and then it leaked so he ran to the press about it. People have asked me how on earth the bocc could support this boondoggle when Council wasn't even told the real deal. My response has been my feeling/ belief that although the bocc supported with money you guys are ethical people and if there is a single impropriety in that management deal or with the Arp or the bait and switch Grover pulled on the bocc and council alike that the bocc may not end up being happy with Grover not being on the up and up with what was planned there. 

**Jeff Bergosh**: Thx for heads up

### CONVERSATION ON 11-18-2021

**Mel Pino**: Morning Jeff, hey, kill that comment made lasting. I'm working on a post for my wall and realized to do that one better. I'll repost. Thank you!

**Jeff Bergosh**: Okay

**Mel Pino**: Holy shit there goes the base.

**Mel Pino**: Kevin Brown will be PR person for this on the campaign trail.

**Jeff Bergosh**: Got good info for u-- call when u can!!

**Mel Pino**: If you get confirm on that please blog it

**Mel Pino**: He's gone try to shove the cancel off on you

**Jeff Bergosh**: 👍

**Mel Pino**: Kevin already has the camera going. Doug just said that "fully expects this will be a go" and is blathering about the habitat conservation plan.

**Mel Pino**: Jeff what day did the school board vote the map through? When was the meeting

**Jeff Bergosh**: This past Tuesday, the 16th

**Jeff Bergosh**: We are outside the 10% variance between D1 and D2

**Mel Pino**: Exactly

**Jeff Bergosh**: Look at this fraud 

**Jeff Bergosh**: What a chameleon

**Mel Pino**: No shit. Is it true it expired in 1988

**Jeff Bergosh**: What expired?

**Mel Pino**: He said the McMillan case expired in 1988

**Jeff Bergosh**: I don't believe that to be true

**Mel Pino**: Told ya

**Mel Pino**: Doug just told the room he can build 7 houses on his property legally. And asked what kind of a person would do that.

### CONVERSATION ON 11-19-2021

**Mel Pino**: Dont. Do. It.

**Mel Pino**: DONT!!!!!

**Mel Pino**: Theyre trying to bait you. Take the high road this tim Jeff and stick to positive communications about constituent needs. Don't let them trigger you.

### CONVERSATION ON 11-21-2021

**Mel Pino**: DONT respond, Jeff. You didn't respond to the last one and it is making him nuts. So he raised the bar and threw another one down.

**Mel Pino**: The way to win this now is to freeze him out and render it irrelevant. PLEASE trust me on that!

**Mel Pino**: Oh never mind--somebody told me there was a new cartoon with the "grinch" it was a spellcheck error for grouch hahaha

**Jeff Bergosh**: LOL

### CONVERSATION ON 11-22-2021

**Mel Pino**: Posted

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Nicely done-- a scorcher!

**Mel Pino**: Jim bonoyer sentenced today

**Mel Pino**: Isn't clear on what. Call when you can.

### CONVERSATION ON 11-24-2021

**Mel Pino**: This is not about county business.

**Jeff Bergosh**: What a shit bag comment par for the course from this piece of shit

**Jeff Bergosh**: Is that from today??

**Mel Pino**: I left her a voicemail. I doubt she'll call.

### CONVERSATION ON 11-25-2021

**Jeff Bergosh**: Happy Halloween!!  LOL

### CONVERSATION ON 11-28-2021

**Mel Pino**: Tony Bennett is giving his last concert due to Alzheimer's on CBS tonight. With lady Gaga's help.

### CONVERSATION ON 11-29-2021

**Jeff Bergosh**: I watched it-- brought chills to me.  What a great show!

### CONVERSATION ON 11-30-2021

**Mel Pino**: Call me back if you can.

**Mel Pino**: https://ricksblog.biz/two-options-for-florida-house-d1-d2/

**Mel Pino**: The plot thickens

**Mel Pino**: Check email

### CONVERSATION ON 12-01-2021

**Mel Pino**: Of course Grover cutting the ribbon on amr's first tiny home today.

### CONVERSATION ON 12-02-2021

**Mel Pino**: No no no no no Doug CANNOT have signing approval

**Mel Pino**: Call if you can I'm gonna speaking on a few items

**Mel Pino**: I'm only going to sign up if any of the libellers show.

**Jeff Bergosh**: 👍

**Mel Pino**: Okay finally found the location of that Greenbelt stuff in packet. Nowhere near the AMR plat I was thinking of I don't think

**Mel Pino**: Late flag I will be getting up as a caution on the special traffic grant multi use. Want to make sure it not the same game as when stole that 2 46 m from you guys and knew the grant was never going togo. Just a caution that's all motto let him money grab this way when he will be out in a year leaving a mess.

**Mel Pino**: This guy is whacked. "Reporter" for studio 850 who believes there is a secret cabal.

**Mel Pino**: Is Doug leaking another economic development potential?

**Mel Pino**: Im waving thematic use stuff

**Mel Pino**: Multi

**Mel Pino**: Was that Andrew McKay?

**Jeff Bergosh**: Grinch

**Mel Pino**: Haha reminded me of him. Looked like him.

**Mel Pino**: Randy Ponson Doug shill

**Mel Pino**: He was the CAC rep for Lois benson

### CONVERSATION ON 12-03-2021

**Mel Pino**: Check Jim little argument.

**Mel Pino**: Article

**Jeff Bergosh**: Just did.  Very well-written.  Very unbiased and truthful.  Wonder if it will be linked on The hate watch site?

**Mel Pino**: Mike just said there are reports that DeSantis issued nine confidential executive orders a couple of months ago and that he is looking at cancelling the Florida national guard (who responds to the Pentagon) and setting up his own national guard.

**Mel Pino**: Okay just found the source. He is not cancelling the FNG and just funded them but he is trying to resuscitate the civilian state guard that would answer to him and once that's done he can deploy them rather than the official guard

**Mel Pino**: From retired military: Yes that's what the meeting yesterday with "gravy seals" was about. He is not cancelling the guard rather trying to break the chain of command so he has command and control authority and not the feds. He will have operational and policy command.

**Mel Pino**: A bunch of these secret orders.

**Mel Pino**: 🤣🤣🤣

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Did they not get the memo that they just got their asses handed to them last night?

**Mel Pino**: Nope. They never, ever, ever go away until they are totally exposed for what they have been running.

### CONVERSATION ON 12-04-2021

**Jeff Bergosh**: Hey Melissa I know it's short notice but there will be a meeting in what will be the new district 2 today with residence at 2 PM I'll be there State rep will be there and I'm going to invite the candidates who want to show up. I committed to this a while ago so I can't pull a no-show even though it's no longer in my district. Let me know if you're able to come and I'll get you the address and more specifics

**Mel Pino**: Thank you much; Jeff...I going to try to get there. We have a contractor on the way to walk through our houses though so don't know if I'll be able

### CONVERSATION ON 12-06-2021

**Mel Pino**: https://www.politico.com/news/2021/12/06/jan-6-generals-lied-ex-dc-guard-official-523777

**Mel Pino**: Of course they are lying. And they are two of many people lying about it. Thank God there are people willing to break rank to expose it. They may save our country. 

**Mel Pino**: Oh and speaking liars, please telltale quack activates who are coming onto your coffee in two days that they can go fuck themselves. And that hopefully they will die of covid sooner rather than later before they can kill more people with their homicidal lunacy. You can quote that.

**Mel Pino**: Tell the quack anti waxing doctors.

**Mel Pino**: Yes!!!!!!!!!!! Now give us a US attorney and start putting people in jail!!

The White House today published the first-ever US government strategy on countering corruption.

It's two weeks ahead of Biden's 200-day deadline, impressively broad in scope, and powerfully strong in details https://whitehouse.gov/briefing-room/statements-releases/2021/12/06/fact-sheet-u-s-strategy-on-countering-corruption/



**Mel Pino**: https://www.mpg.de/17916867/coronavirus-masks-risk-protection

Three metres are not enough to ensure protection. Even at that distance, it takes less than five minutes for an unvaccinated person standing in the breath of a person with Covid-19 to become infected with almost 100 percent certainty. That's the bad news. 

The good news is that if both are wearing well-fitting medical or, even better, FFP2 masks, the risk drops dramatically. 

In a comprehensive study, a team from the Max Planck Institute for Dynamics and Self-Organisation in Göttingen has investigated to what extent masks protect under which wearing conditions. 

In the process, the researchers determined the maximum risk of infection for numerous situations and considered several factors that have not been included in similar studies to date.

**Mel Pino**: Shit sorry I missed you. I seventeen gotten to the good part

**Mel Pino**: They are snapping up homes of people in the ad item system fortress undervalue and the lawyer buyers agent are in on it

**Mel Pino**: For Gross undervalue. My space bar is going.

**Mel Pino**: I really wish I could convey all of this to Gary directly. This is so bad, Jeff.

**Mel Pino**: Uncle Tom's court appointed lawyer is called William L Nelson lll
I asked my mom if she has ever spoke to him and she has no idea what he does and they only spoke once when she asked him if he could help get Toms bills paid with needing an additional lawyer (James C Taylor) and Nelson told her that he can not take any action for Tom because that it would be a conflict of interest... and she never heard from him again  

**Mel Pino**: Thats from Teri. So the new ad item system looks to be set up to let crooks bilk Alzheimer's patients and strip their houses while they have the keys. Sounds about right. I was beating my brain trying to imagine how they were going to bilk this new system. Duh. The estates.

**Mel Pino**: And the "buyer" Carla Culpepper is bullshit- it's her and her husband "collecting" properties just like Gleaton. They own 7 houses right now in the 70k range

**Mel Pino**: From Teri also. That's just from what EG is running. No doubt this was set up to run out of the gate all over the state from day 1

**Mel Pino**: Yep- Their most recent "steal" was from the life Estate of a guy that is not related to them in any way Harold Hugh ONeil died in 2013 and that when they took his house 

**Mel Pino**: They just flipped it on Dec 6!

**Mel Pino**: Those from Teri also. I'll stop for tonight but somebody has GOT to stop this Jeff.

**Mel Pino**: Gleaton also puts Leins on properties under guardian estates for "repairs" - then turns in invoices from Jonathan Cook to justify the cost - then the estate has to pay him to release the lein so the transaction can go then. I found one that uses a processional guardian series that he didn't in 2019

### CONVERSATION ON 12-07-2021

**Mel Pino**: Jeff I talked to JJthis morning and he said didn't think the special class lawyer bill went through..he thought they got it stopped. He's checking but that's really here nor there on the scam these guys are running on guardian estates. If there's nothing that can be done to stop it then least gary could talk to judge roles. Jj said he does the majority of the probate and he's by the book. These people need eyes on them. This isn't about county business obviously.

**Mel Pino**: Jeff Teri is hardly "stirring" this up. EG got the listing for her uncle's house unbeknownst to Teri. Her mom voiced that they didn't understand the decisions he was making (which MAY constitute multiple ethics violations for listing the house too land ignoring other offers. When Teri found out it was EG, she told parents they needed to go over to the house to see what he had stolen. He stole the fucking insulation out of his attic, Jeff. But the problem for the court system is that he is listing properties of people under guardianship before the judge issues an order and strongarming them into under market sales. Once Teri figured it out and explained it to her mom, her moment an email asking why they were proceeding with the sale when there wasn court order. EG told her that the other judge was taking too long and that it had been switched over to judge Boles and that boxes assured him the court order would come through by the closing date. He is targeting the homes of people under guardianship, selling them low with a buyers agent in on it, and then they turn around and sell the house at market value. One woman is holding all the properties he is doing this with.

**Mel Pino**: That Boles assured EG he'd have his court order, that is. JJ said boles is by the book and handling most probate and probably has no idea this is going on.

**Mel Pino**: Teri isn't making any of this up. These guys stole 77k of her credit card to put a roof on our new judges house. THATS why he wouldn't prosecute it.

**Mel Pino**: And our SAO KNOWS this and let him get away with it.

**Mel Pino**: It's like she was scared to do anything about it. Now we knowwhy.

**Mel Pino**: https://www.tallahassee.com/story/news/local/state/2021/12/07/first-presumptive-case-omicron-covid-19-virus-reported-florida/6419464001/

**Mel Pino**: Clara quoted extensively

https://www.pnj.com/story/news/local/pensacola/2021/12/07/pensacola-affordable-housing-tiny-homes-impact-fees-vacant-lots-escambia-county-advisory-committee/8888948002/

**Mel Pino**: Put up two part comment on the flood meeting.

### CONVERSATION ON 12-09-2021

**Mel Pino**: Has the board given any money to this guy yet?

**Jeff Bergosh**: Who knows

**Mel Pino**: They are retaining JJ on that to take care of this mess. THANK GOD.

**Jeff Bergosh**: Good!

**Mel Pino**: Just watched the tpo

**Mel Pino**: Remind me to tell you about a water quality issue around lilianbridge tomorrow

**Mel Pino**: Solves a lotof angles.

### CONVERSATION ON 12-13-2021

**Mel Pino**: Check voicemail

**Mel Pino**: Hi Doug, good luck at DOAH. Everybody deserves their day in court, even a crook like you.

### CONVERSATION ON 12-14-2021

**Mel Pino**: I read the rest of the article...called you immediately when I saw it. Might not be so cut and dry

**Mel Pino**: Are you fucking kidding me on the ethics complaint. I'm going to blow this shit up, Jeff. You can count on most people losing track over Christmas. Not me.

**Mel Pino**: Please know. If you guys let matt be screwed to cover your asses that you have let any degree of corruption run under you as policy makers, I will fight to my last breath to keep that kid fro getting his life wrecked. You guys are doing a superior shit job of letting your director game you.

**Mel Pino**: I am grateful to you forever for taking up Matt's case when you saw the shit was not right in the water. If you sanction this bullshit Jeff, I'm sorry I will have to come out for Matt. Because everybody knows this is Chips sickness infiltrating its toxins in every direction. He must be so proud.

### CONVERSATION ON 12-15-2021

**Mel Pino**: It's my understanding that they left evidence out of the investigation that corroborates Matt's claim. Trying to substantiate that.

**Mel Pino**: If this number comes in its Keith.

### CONVERSATION ON 12-17-2021

**Mel Pino**: Hey call me back if you can and I won't bug you again before Christmas:) 

**Jeff Bergosh**: Will do Mel- sorry I got tied up in a lunch meeting

**Mel Pino**: 👍

### CONVERSATION ON 12-21-2021

**Jeff Bergosh**: ......I read this to mean that members of the public can view the zoom proceedings. It be awesome if someone could live stream it on Facebook in real time LOL

### CONVERSATION ON 12-28-2021

**Mel Pino**: Happy holidays--i know everybody is taking a political break (I'm off facebook and loving it), but this is the single most important piece that has been written about DeSantis's trajectory yet.

https://floridaphoenix.com/2021/12/27/gov-desantis-seems-hellbent-on-taking-us-back-to-the-60s-only-its-the-1860s/

**Mel Pino**: That's a generic message. Hope you guys have had an awesome holiday and BE SAFE in the airports etc. Vaccinated people who are having breakthrough omicron here are so far avoiding hospital here but it is not fun stuff to have regardless. Unvaxed idiots are catching covid for a second and even third time.

**Mel Pino**: Doug has the roundabout at Johnson beach and Pk drive on the agenda with 850k of discretionary.

### CONVERSATION ON 12-30-2021

**Mel Pino**: Hey, you on your way in?

**Mel Pino**: Well I can't even find it. Just spent that time looking and I don't see it. Which makes me sad because honestly I am laughing my ass off at that. 

**Mel Pino**: Really nice things to say in the Outage Two Papers, Two Voices

**Mel Pino**: Woop there it is.

**Mel Pino**: That study is looking at ivermectin alongside flonase (steroid that will reduce inflammation but also lowers your immunity), fluvoxamine (an antidepressant prescribed for OCD) and has nothing to do that I can see with in vitro or in vivo demonstration of direct efficacy against covid in any way. They give participants ivermectin, a steroid, SSRI, or nothing and then ask them if they feel better. 

**Mel Pino**: Most of the headlines are very misleading--"want ivermectin? Sign up for this study." Participants don't know if they will be getting one of the three drugs or nothing. The study is clearly arranged to see whether drugs that just tend to make you feel better momentarily fare as well as ivermectin. Looks me like they are tryingto debunk it. This is also not good science. They need in vivo and in vitro studies of what things kill what. They need to be treating patients for virus, bacterial, parasitic, fungal, and protozoa infections AT ONCE if they are dying and trying to knock out whatever is killing them. And they need to be studying all the drugs--and herbs-- that kill those things as indications of WHAT their systems are tasked with, not as indication that the drug making them feel better kills a thing off label when there is zero proof.

**Mel Pino**: This is why western medicine is so fucked up, Jeff. Doctors are HORRIBLE scientists. Last people on earth you want running studies. We should be listening to the scientists who study this stuff. 

**Mel Pino**: You ever want to know how smart those doctors really are, try to talk to them about biochemistry or lipids. They won't have a fucking clue. Nor do they understand a damn thing about vitamin and mineral assimilation. Or the P450 liver enzyme system. In fact, that's a good test. Ask each one of them whether the drugs they are prescribing are cleared by the liver or the kidney. If they can even manage to answer that right, and the answer is liver (DoubleCheck though, they usually don't know), then ask them what enzyme channel in the P450 liver system is used to clear the drug and what other drugs patients may be taking that could really block that channel and shut down their liver. Then watch them get out of the question because they don't fucking know.

**Mel Pino**: https://drug-interactions.medicine.iu.edu/MainTable.aspx

**Mel Pino**: Be surprised if most of them could even tell you how exactly anything of this is cleared by the body. They will know remdesivir is he'll on kidneys. Beyond that, I doubt much.

**Mel Pino**: https://www.nih.gov/news-events/news-releases/large-clinical-trial-study-repurposed-drugs-treat-covid-19-symptoms

**Mel Pino**: Youre being gamed by medicine men and information headlines and reporting. This is a huge study hitting on many off label drugs funded by the NIH. It started in April. Vanderbilt is serving as the trials data coordinating center. Duke and NC Durham are serving as the clinical coordinating center. The disinformation fountains have latched on now that it is in the data processing and tryingto make it look like Vanderbilt is going to prove ivermectin works. You have got to go to the source of this stuff and not believe shysters and dupes. And nothing second hand.

**Mel Pino**: https://www.orlandosentinel.coJoel Greenberg prosecutor named interim U.S. attorney for district covering Orlandom/news/crime/os-ne-roger-handberg-interim-us-attorney-greenberg-prosecutor-20211228-quxova24yrdavar4un7swnqluy-story.html

Joel Greenberg prosecutor named interim U.S. attorney for district covering Orlando

"Greenberg, now slated to face sentencing in March, is cooperating with Handberg s team in an investigation that has reportedly grown to also include prosecutors in Washington, D.C., and examine everything from sex trafficking to public corruption in medical marijuana policy."

**Mel Pino**: Sorry

https://www.orlandosentinel.com/news/crime/os-ne-roger-handberg-interim-us-attorney-greenberg-prosecutor-20211228-quxova24yrdavar4un7swnqluy-story.html

**Mel Pino**: Woops he did it again

**Mel Pino**: https://mobile.twitter.com/rexchapman/status/1476595383220457485

### CONVERSATION ON 01-03-2022

**Mel Pino**: Galvez is NOT funded.

**Mel Pino**: Not only did Matt's stipend come out of the wrong cost center on the side of the clerk, but they actually paid him correctly the first 2 paychecks and then screwed it up the rest of the time.

### CONVERSATION ON 01-04-2022

**Mel Pino**: Hey don't know if Mike told you he's on Rick in a minute

**Jeff Bergosh**: Missed it

**Jeff Bergosh**: What was topic?

**Mel Pino**: Mike lowerys ruling

**Mel Pino**: They knocked it out of the park

**Jeff Bergosh**: Just saw the email

**Jeff Bergosh**: Sent late yesterday by Alison

**Mel Pino**: On new phone so think this is the right number. I think he texted you last night which was why I didnt...didn't want to steal his thunder.

**Mel Pino**: Text me back a quick confirm if it imported your no right

### CONVERSATION ON 01-05-2022

**Mel Pino**: Check pm and lmk if u get this text

**Jeff Bergosh**: Got it

**Mel Pino**: Thank u I miss my crackberry SO BAD already

### CONVERSATION ON 01-06-2022

**Mel Pino**: Left a message no need for call back.

**Mel Pino**: That is total fucking bullshit on tests not working for asymptomatic. First five days yes.

**Mel Pino**: Shes lying

**Mel Pino**: I wonder if abbott is aware she is saying their at home kits don't work for asymptomatic. I plan on asking them

**Mel Pino**: That's from abbot news release dirext from their website

**Mel Pino**: Lie after lie.

**Mel Pino**: HAHAHAHAHA Eight cases my ass.

**Mel Pino**: It was one meeting with 48 people and Doug misadvertized the meeting on purpose and stacked it with his supporters. 

**Mel Pino**: Don't care about the roundabout one way or another just giving you the true history

**Mel Pino**: If you want to know how full of shit bart is give me a call

**Mel Pino**: Jayer not running again

**Mel Pino**: Just sent an email to the head of abbott pr diagnostics division ccing the board. Doubt that she will respond to mine directly but that billahit needs to be on their radar and the screen shots from their website demonstrate her claims about the efficacy of testing asymptomatic patients was completely bogus.

**Mel Pino**: Please listen to a quick message I left on covid numbers before meerinf

**Jeff Bergosh**: K

**Mel Pino**: Just got a response from woman at abbott. She said she is going to reach out and talk to local leaders to make sure they are informed. And that yes "binaxnow is a highly reliable test and is authorized for people to use with and without symptoms.:

**Mel Pino**: I will post it on facebook

### CONVERSATION ON 01-07-2022

**Mel Pino**: Commissioner Bergosh would you please provide me with the public record on any responses that came in to your district office on the string I initiated with abbott. Thank you

**Jeff Bergosh**: Sure will

**Mel Pino**: Thank you

**Mel Pino**: Jeff correct the 4 1 vote. Also whose sig is that on the doc? Joe hammmons?

**Mel Pino**: I gave Marie a chance to respond and received none. So I just forwarded the abbott response on the home testing kits to the group.

**Mel Pino**: Posted. Those aren't just jabs for no reason jeff. It really pains me to say it and I forced myself.

**Mel Pino**: Wow kinsella

### CONVERSATION ON 01-08-2022

**Mel Pino**: Jeff we hear all manner of artillery on the base and ignore it. There was just a huge boom though brought kevin in from the shop. Probably nothing but just wanted to give you a heads up

**Mel Pino**: Confirmed on nas facebook controlled detonation

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: Controlled detonation of what?

### CONVERSATION ON 01-09-2022

**Mel Pino**: Sorry didn't see this. Phone notifications effed til my new one gets here
 They didn't say. Just said hey well be blowing shit up and of course people freaked they heard it as far away as correy. Kevin said it sounded like a car bomb to him and he is an artillery expert so you cN imagine people were scared

**Mel Pino**: Jeff PLEASE check your voice-mail asap

**Mel Pino**: I left wes a message about this and urged him to be in touch with you guys about it. If I have it, it won't be long til Jacqueline and Doug do  and they will have no mind for public panic nor the head space of our first responders. It goes without saying that this cannot continue in full on crisis mode per cdc guidelines at the county without it being addressed. Srli is not in crisis mode. The hospitals need to be aware and they should themselves be changing their operations for crisis mode, their precious electives be damned. Even by full on cdc "crisis" standard Escambia ema is taking big leeway by not prioritizing for asymptomatic and mold symptoms in hip, which means they can't. They have also screen shot the guidelines out of context on the cdc website to cut out the key points the head the chart, important context on mitigation strategies. The entire context of the management plan for hcp is that all the agencies on a community need to work together. This can't happen if the county continues to hide the crisis and the hospitals refuse to do their part. Right at the 
TOP of the cdc's contingency capacity strategy is "cancel all non essential procedures and visits." That is the first sentence. Our local elected officials have got to start leading on this issue for the welfare of their constituents and the ability of our local economy to weather this variant.

**Mel Pino**: Left voice-mail. Corrective coming

### CONVERSATION ON 01-10-2022

**Mel Pino**: Um what's with the less than. 

**Mel Pino**: Call if u can.

**Mel Pino**: Check pm

### CONVERSATION ON 01-11-2022

**Mel Pino**: Florida hospitals, according to HHS/Becker's
14-day change: 293% increase
Hospitalizations per 100,000 people: 40
https://www.beckershospitalreview.com/public-health/states-ranked-by-covid-19-hospitalization-rates-august-2.html

**Mel Pino**: Posted

### CONVERSATION ON 01-12-2022

**Mel Pino**: Posted

**Mel Pino**: Wear reported on ems.

### CONVERSATION ON 01-13-2022

**Mel Pino**: Sedition  charges have started with the bottom rung of the ladder. Doj is no doubt ready now to work their way up pretty quickly. Posted a follow up on your blog.

### CONVERSATION ON 01-18-2022

**Mel Pino**: I simply cannot understand why the 5 of you have to legislate through ordinance things that are perfectly clear in the employee handbook, unless passing an ordinance is duck and cover for your direct reports that refuse to follow the handbook in times past. The employee handbook is shot through with code on employees not participating in politics. If appears in at last three places  I can remember. Of course your attorney still opined Johnathan could run, so either your handbook is not in accordance with state statute or your attorneys opinions Rent in accordance with the handbook. To my mind time wod be better spent on figuring that out instead of passing more unnecessary legislation that Tallahassee couldn't care less about anyway.

**Mel Pino**: So Johnathan should have been up on a misdemeanor

**Mel Pino**: You guys need a total rewrite of the employee handbook in that case

**Mel Pino**: This begs the question of what else beyond elections is in the handbook that doesn't accord with state and federal law.

**Mel Pino**: Check email and lmk if that mac item has your support

**Mel Pino**: Posted

### CONVERSATION ON 01-20-2022

**Jeff Bergosh**: Sorry, I can't talk right now.

**Mel Pino**: Just a heads up that the homeless situation is going to blow up today Nd S a courtesy I wanted to let you know I will be advocating hard now for the county to start coming up with a solution and stop ripping benches out.

**Mel Pino**: We got our article in the post today.

### CONVERSATION ON 01-25-2022

**Mel Pino**: Kohler finally dropped his name in the d2 race with  sfroberger getting off. 

**Mel Pino**: Steve will probably endorse him which sadly will be worth next to nothing

**Jeff Bergosh**: LOL

**Jeff Bergosh**: He's a nice enough guy but it's going to seem opportunistic and I don't think he has a chance if I'm being very honest even though he's well-qualified he's a retired Navy captain he checks a lot of boxes

**Mel Pino**: He checks the trumplixN conspiracy boX that's for sure.

### CONVERSATION ON 01-27-2022

**Mel Pino**: Got this yesterday and it is so fucking pathetic I didn't even bother posting it with more important stuff happening. Suppose I will throw it up today. In case anybody was wondering just how desperate broxson is to get his shill in there so Janice Gilley can run d2.

### CONVERSATION ON 01-28-2022

**Mel Pino**: Screaming important and solid.

**Mel Pino**: Escambia is getting ready to have its resfore funds gutted. Bender at the helm when you should have been at the meeting as chair. Glen orchestrated the meeting in Tallahassee two weeks ago.

**Mel Pino**: Broxson wanting to take all unused restore funds and combine into one 8 statute sewer project. This is real jeff.

**Mel Pino**: Chips knows
 Matt left out of loop. Lobbyist and Robert there.

**Jeff Bergosh**: Matt's at meeting rn with all of us

**Mel Pino**: Call me aa soon as you can.

**Jeff Bergosh**: In mtg

**Mel Pino**: K its pot 2 and 3

**Jeff Bergosh**: Pot 2

**Jeff Bergosh**: Money's just sitting there we're going to tap it

**Mel Pino**: Haha ok

**Mel Pino**: Broxsons going to tap that shit for sure.

**Mel Pino**: Both pot 2 and 3 if he can do it and that 70 percent will move right on out of Escambia county to wherever he thinks the contractors who will get the sewer can best help him get to dc.

**Mel Pino**: Doubt he'll have to keep much of it here tl serve that purpose. Kevin brown has told people this is the point of him running BTW. Bp money. 

**Mel Pino**: Oh and heads up there's nothing bold about gifting cherry picked contractors with sewer.

**Mel Pino**: Of course we will never really know what happened at that meeting in Tallahassee because Robert keeps jumping you as chair and they locked chips and tim out of the meeting at the last minute and wouldn't allow remote. Hey if you trust bender though. He has been sitting meetings with broxson grover and kevon brown on it for a while.

**Jeff Bergosh**: It'll be a great project!  Big!

**Mel Pino**: Haha k jeff. I give up. Have fun while the money gets sucked out of Escambia and don't say I didn't warn ya.

### CONVERSATION ON 01-29-2022

**Mel Pino**: Beach access 4. 🥲

### CONVERSATION ON 01-30-2022

**Mel Pino**: Jeff when I saw the beach access 4 posts I realized I had forgot to share some key Perdido contacts. All these folks would be very good to reach out to in advance of town hall.  Del is real estate agent and soccer coach. Funny AF kiwi.


**Mel Pino**: Very important person on key. Real estate agent and partial owner of middle plat on gulf


**Mel Pino**: One of the biggest movers and shakers on the county but flies under radar.

**Mel Pino**: Owner of gift shop and various other business under gulf coast inc. Puts on festivals and fireworks.


**Mel Pino**: Long time resident of innerarity who knows everybody going back ages on hub Stacy side.


**Mel Pino**: Another life long resident on innerarity her mom is there also. Fights to keep shorelines open down there


**Mel Pino**: You probably already have tracys


**Mel Pino**: Rita very important. Long time precinct captain. Firey Cuban woman smart as a whip and tough as nails. Has fought Doug for years on his failure to bring a y to fruition


**Mel Pino**: I'm sure you have this but just in case


**Mel Pino**: Krispy Kreme franchise founder lives down from Anthony Baracco on river road. Partner of Lucy buffett


**Mel Pino**: Pastor leader in black community lives in chanticleer


**Mel Pino**: Almost forgot. This is the man who owns beach access plat next to Brenda's that randy and I were meeting with on potential sale


**Jeff Bergosh**: Thanks Mel

### CONVERSATION ON 01-31-2022

**Mel Pino**: Hey and there's no reason to chew time calling me back today...I sent those because all of those folks would be good to reach out in general and def in advance of the meeting. A lot of them checked out from public anything under Doug so are looking for a breath of fresh air. All of them good advocates for your vision.

**Mel Pino**: Brenda is a very important person to know. You'd never know that to meet her.

**Mel Pino**: and the guy with the access next to Brenda wants to sell to the county but couldn't get Doug to be serious. Brenda was the real estate agent on Doug's first failure. She has no choice but to sell to somebody else.

**Mel Pino**: Had

**Jeff Bergosh**: Thanks for this information

**Mel Pino**: So many people who checked out during Doug rein of terror. Norman Jete super important for innerarity unless Doug got him forced out the door. Thei harassment was awful Jonathan even called code on Norman in public record. Assailed. He would be over the moon with a call from you. 

**Mel Pino**: Asshole not assailed. Although they did that too.

**Mel Pino**: Norman coming

**Mel Pino**: Hey that was the wrong string in my facebook pm. I was trying to send you a string about people shooting ducks on the key.

**Mel Pino**: People are very upset there is duck hunting happening on what they thought was a bird sanctuary and very close to houses.

### CONVERSATION ON 02-01-2022

**Jeff Bergosh**: In a meeting will call u back

**Mel Pino**:  Nothing urgent just excited to hear how it went.

**Mel Pino**: Call if you have a chance about the meeting last night.

**Mel Pino**: Super nice article on the paper. Congrats Jeff. Sincerely. As somebody who spent years down in the trenches trying to help stem the worst from him for the people on innerarity I am so damn happy they don't have the threat of him My more I could cry. Norman Jeter posted and is thrilled.

