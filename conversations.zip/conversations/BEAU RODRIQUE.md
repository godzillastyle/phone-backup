

## CONVERSATIONS WITH BEAU RODRIQUE

### CONVERSATION ON 11-17-2019

**Beau Rodrique**: I’m under the impression all paperwork has been submitted to the title company as of this week for the Beulah fire Dept property purchase can you check and see if that’s correct? 

**Jeff Bergosh**: I will Beau.  I’ll do it first thing in the morning and I’ll let you know.

### CONVERSATION ON 02-25-2020

**Beau Rodrique**: Hey Jeff call me when get a chance please sir 

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Beau:  I am adding an item to tomorrow’s BCC agenda for the Beulah Volunteer Fire Department, station 2, to receive 8 new twin mattresses and a new commercial washer/extractor.  NTE $10,000.00. From District 1 Discretionary funding.  Please let the guys at the station know this.  Also—it is my understanding that the real estate purchase/closing for the property will happen tomorrow.  It took a while, but it looks like we are at the finish line. Thanks for all your continued efforts to make that happen!  Next up—getting a plan from an architect/engineer to get a proper renovation/modernization of that facility!

**Beau Rodrique**: Outstanding thank you sir 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-02-2020

**Beau Rodrique**: Call me when you can please 

**Jeff Bergosh**: In a meeting will call u after 

**Beau Rodrique**: 👍

**Beau Rodrique**: This went to the 1500 people on our page

**Jeff Bergosh**: Folks just need to know who is pulling his strings 

### CONVERSATION ON 04-21-2020

**Beau Rodrique**: Thank you sir 

**Jeff Bergosh**: No problem.  I’m going to get to the bottom of it

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good Morning Beau—I spoke with  Janice Gilley Tuesday morning about the burn ban, after I had spoken with you.  She said “No”.  I appreciated your experience and advice, so I went to the media anyway on Tuesday morning and advocated for the ban.  Well, what do you know, they put a burn ban into place yesterday (Wednesday) afternoon after all.  Imagine that?

Also-  I wanted to let you know that I just got my latest poll results back from Gravis.  I’m ahead of Jesse by 16 points, and I’m crushing Underhill’s Secretary by 30 points!  Thought you might like to know that 

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Beau

**Beau Rodrique**: Outstanding! The guys at the firehouse are ready to back you we just have to figure out how to do it. Maybe a picture with everyone in our station 2 (not ECFR) shirts that we bought out somewhere. We’ll figure it out but I glad your crushing Underhills secretary 

**Jeff Bergosh**: Thanks Beau—greatly appreciate the support!

### CONVERSATION ON 05-18-2020

**Beau Rodrique**: Any word on the beds for Beulah ?

**Jeff Bergosh**: They’re not delivered yet??  

**Beau Rodrique**: No sir 

**Jeff Bergosh**: This is ridiculous!  I approved $10K for these months ago!

**Jeff Bergosh**: And I’ll let the accountants figure out how to reconcile it

**Beau Rodrique**: Sounds good to me thanks

**Jeff Bergosh**: Sorry this has dragged out so long....I can’t help but think the career station wouldn’t have been made to wait....

**Beau Rodrique**: I agree with you there

### CONVERSATION ON 05-19-2020

**Jeff Bergosh**: Working a plan today

**Jeff Bergosh**: 8 twin mattresses correct?

**Beau Rodrique**: Yes

**Jeff Bergosh**: Okay

### CONVERSATION ON 06-02-2020

**Beau Rodrique**: Just wanted to pass this on since I know it was bothering you. I asked for all the people at the firehouse to show support for your campaign to let me know so we can schedule a picture or something and Gavin Price was the first person to say he was in 100%. I think his wife filled out those ballots you sent out

**Jeff Bergosh**: Thank you Beau!

**Jeff Bergosh**: That makes my day!

### CONVERSATION ON 06-12-2020

**Beau Rodrique**: Just a heads up still no beds 

**Jeff Bergosh**: I’m really disappointed in Janice.  This is inexcusable.  She told me last week they were to be delivered within “2-weeks”.  I have to believe it’s now an “any day now” situation.  

**Beau Rodrique**: They may very well be on the way I just wanted you to know 

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Beau—thanks for hanging in there and sticking it out.  I Wanted to let you know the design award for station 2 remodel and renovation will be on the agenda for our July 2nd meeting.  I’m busting through the log jam—you all WILL have a modern, functional facility!!

**Beau Rodrique**: Thank you sir 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Great News- I was just endorsed officially by the police union, the PBA!!  Can u believe it?  Will miracles never cease?!?

**Beau Rodrique**: This is awesome news! What’s your schedule look like Monday night? Think we can work on that endorsement picture with the folks at the firehouse if I can get a big group up there?

**Jeff Bergosh**: That would be great Beau.  I can be there any time Monday evening just let me know when!  Greatly appreciate it Beau!

### CONVERSATION ON 07-13-2020

**Jeff Bergosh**: Hello Beau just following up.  We still on for tonight, and if so just let me know what time.  Thanks again for your help and support!

**Beau Rodrique**: I don’t know if it will be a huge turnout but there will be several folks there. We got people in quarantine and others just on normal shift work but yes we still planned on getting the picture. Are any of the Restaurants at 9 mile and pine forest endorsing you? Thought maybe we could go there and show “the guys from Beulah Volunteer fire department endorsement for Jeff Bergosh”? I don’t know what are your thoughts?

**Jeff Bergosh**: I haven’t really sought their endorsements but we could meet at one of them, maybe the Ruby Tuesday— I’ve got a big sign there or right at the entrance to the fairgrounds I have a giant billboard there

**Jeff Bergosh**: Are you thinking before or after your meeting tonight?

**Beau Rodrique**: It will be around 7:30-8 before all e folks get there

**Jeff Bergosh**: Okay I’ll be there thanks Beau!

**Jeff Bergosh**: Hey Beau I’m here just not wanting to bust in on your meeting.  I’ll be out in the parking lot when you all are done with your meeting.  Thanks!

### CONVERSATION ON 07-14-2020

**Jeff Bergosh**: Beau-  thanks again for organizing the endorsement last night...I can’t tell you how much I appreciate it!

I’m going to post the picture on my website with a quote.  Please let me know if you’re alright with the below:


“Jeff Bergosh supports and has worked hard for the volunteer firefighters in Beulah at ECFR station2.  He said he would get us better equipment, and he did.  He said he would get us funding for a modern fire station— and he did.  Jeff Bergosh follows through on his pledges- and he does what he says he will do.  In this election for County Commissioner, District 1, we are supporting Jeff Bergosh because he gets things done for our community!”

Beau Rodrique 
Asst. Chief and 20 year fireman 
Beulah Fire Department (ECFR station 2)

**Beau Rodrique**: Looks good to me 

**Jeff Bergosh**: Awesome thanks Beau!

### CONVERSATION ON 07-28-2020

**Jeff Bergosh**: Hello Beau, do you have a minute to talk?

**Beau Rodrique**: Give me a few and I’ll call you if that’s okay 

**Jeff Bergosh**: Perfect thanks!

### CONVERSATION ON 08-18-2020

**Beau Rodrique**: Congratulations sir that was a heck of fight, I’m glad we could help 

**Jeff Bergosh**: You all made it happen Beau!!! Thank you!!!!!! This is OUR victory!!! Let’s make Station 2 Great Again!!!!!

### CONVERSATION ON 09-18-2020

**Beau Rodrique**: This can’t be true right?

**Beau Rodrique**: This can’t be true right?

**Jeff Bergosh**: Not true

**Jeff Bergosh**: Is your power still out Beau?

**Beau Rodrique**: Yes, power is on north east and west but south Rebel rd is out 

**Beau Rodrique**: I’m good with it I understand I just saw a lot of trucks in Perdido Key there doesn’t seem to much put here anymore

**Beau Rodrique**: We even cleared the roads and power lanes for them to get to work lol

**Beau Rodrique**: Out on a fire call now no tree or power trucks anywhere to be seen and I saw at least 50 headed towards the Key at 6pm.... seems odd

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: Good Morning Beau-  I got your message about Rebel Road.  As it pertains to the where debris is being hauled to— each of the three contractors was assigned a location so that their weight totals would not be intermingled with the other haulers’ debris—- and with the way the county is laid out it invariably produces inefficiency.  It’s the way FEMA set up the program....but it is inefficient

**Jeff Bergosh**: By the way:  I’ve heard rumors about the next fire chief being a soon to be retired DoD firefighter named Christopher Hatch.  Do you know that guy—-have you heard this rumor?

**Beau Rodrique**: Yeah I know him he’s a good friend of mine. Great guy and realistic when it comes to the needs of the fire service 

**Beau Rodrique**: I haven’t heard that rumor though 

**Jeff Bergosh**: Do u think he will value the volunteers— and treat them fairly?

**Beau Rodrique**: I believe so, he’s a well rounded fireman that came from the bottom up and was a volunteer in Escambia for a long time before his career with DoD took off. 

**Beau Rodrique**: I think he be a good local value add to ECFR no doubt 

### CONVERSATION ON 11-09-2020

**Beau Rodrique**: Give me a call when you can about last weeks Fire Admin shenanigans 

**Jeff Bergosh**: Will do thanks Beau!

### CONVERSATION ON 02-04-2021

**Beau Rodrique**: Give me a call when you can please sir 

**Jeff Bergosh**: Will do

### CONVERSATION ON 02-08-2021

**Beau Rodrique**: Wanted to give you a heads up myself and Capt McLeod quit the fire Dept tonight. There’s 5 active people on the roster at Beulah now unfortunately due to leadership. I appreciate everything you’ve done for us and I hate it ended this way but I wanted you to know before the Facebook warriors started in on you for Beulah missing calls which is fixing to get a lot worse. Again thank you for all you’ve done for us and the community

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Beau I am really bummed out to hear this.  I also got a voice mail from Eric Gilmore asking me to call him so I’m pretty sure that’s what this is about.  I’d like to discuss what led to this if you have some time today.

**Beau Rodrique**: Sure call me later

**Jeff Bergosh**: Will do 

### CONVERSATION ON 02-23-2021

**Beau Rodrique**: Can you send me Kevin Adams number for the school board please

**Jeff Bergosh**: Sure Beau

### CONVERSATION ON 02-25-2021

**Beau Rodrique**: I see you having to defend the volunteers on the Beulah scoop again and I appreciate it. Just want you to know like we discussed a few weeks ago most of the firemen and upper officer staff left a few weeks ago (myself included). There’s only 4 total people running calls at Beulah when they are available and it’s showing badly. They are missing calls completely and when someone does go it’s only one or 2 people usually not taking a fire truck. We all left because of the new Chief, he had us all fooled while Steve was still there but when he took over his true colors showed. We tried telling admin this was coming several times but they relentlessly supported Jim so everyone got tired of it and quit or moved to other stations. I wouldn’t be surprised if Shawn Hall was fed this same kind of info from his union brothers and admin to make you engage on social media so they can drop all the missed and under staffed call facts on you and make you look bad. All the people that used to be at Beulah are waiting on someone to remove Jim and we will all come back and staff it like it was but that doesn’t seem to be on some folks agenda.  I doubt there will be any volunteers to move into that new station when it takes place which is saddening 

**Jeff Bergosh**: Thanks for this info.  Very discouraging

### CONVERSATION ON 06-15-2021

**Jeff Bergosh**: Hey Beau I hope all is going well. So I just wanna give you some warning I got hit with a gigantic very very expansive public records request for all my social media text messages emails phone records everything the whole kitten caboodle for a five month. Regarding fire and public safety. So some correspondence between you and I will have to be turned over just wanted to give you a heads up this is a wonderful request coming from the lawyer for the fire Union

**Beau Rodrique**: No problem thanks for the heads up

**Jeff Bergosh**: 👍

