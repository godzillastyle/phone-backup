

## CONVERSATIONS WITH PHIL FIORILLI

### CONVERSATION ON 03-25-2020

**Phil FIORILLI**: Commissioner, First, Thank you for a very informative “Coffee” on Facebook this morning. 

My second item which I did not feel appropriate for this mornings meeting is if you have been able to determine an answer to the question I asked previously which was “Does one no stop a request for action?”  This is in reference to the two trees in the right of way on Shelby Lane. I previously sent you photos of the trees and the removal was on track till one individual called and voiced disagreement. I have subsequently talked with three of the residents and home owners closest to where these trees are located and they are in agreement with removing the trees as the trees present a danger if they get damaged during a high wind event. Thank you for your assistance in this trying time. R/

**Jeff Bergosh**: Hey Phil thanks for turning in this morning and yes I have forwarded that question up the chain and I’m waiting to hear back from Wes Moreno what the answer is.  thanks for reminding me —I will press them again today and see if I can get to the bottom of it.

Jeff B

**Phil FIORILLI**: Thank you. Next time we are together I’ll provide an additional comment. You and Wes continue to do great things. Thank you. R/

**Jeff Bergosh**: Thanks very much Phil!

### CONVERSATION ON 04-04-2020

**Phil FIORILLI**: Great Virtual presentation last week. Looking forward to this week’s get together. 
Thank you for keeping the beaches closed. 
I am concerned that there is so much hand wringing and back peddling on closing venues that need to be closed based on the data that is out there.the five Commissioners are empowered by the citizens to take the necessary steps to protect all. Punting the enforcement is not the answer. Also if the duly sworn law enforcement officials are not going to enforce the emergency orders then it is time to replace them and at least call them out as part of the problem as opposed to part of the solution. 
Trust you and yours continue to be safe and healthy. Cheers 

**Jeff Bergosh**: Thank you Phil!  I agree!

**Jeff Bergosh**: Thank you for your participation 

**Phil FIORILLI**: R
Any word from Wes on the status of moving forward on the tree removal?  I know this is low pri but with the upcoming hurricane season would like to get this done or at least know what the plan is. Thank you for all your consideration. R/

**Jeff Bergosh**: I look forward to the time when we can do it again face to face

**Jeff Bergosh**: I have asked about that tree situation, I will follow up Phil.  Sorry it has taken so long

**Phil FIORILLI**: Understand the slow progress. County surveyors were out doing their thing about ten days ago. 
I too look forward to the face to face opportunity. 

### CONVERSATION ON 04-13-2020

**Phil FIORILLI**: Commissioner, Just checking in to see if any progress has been made on clearing the right of way area on Shelby Lane. The lone dissenting voice was in complete agreement last summer when some of the right of way was cleared. This is right of way not personally owned property. Thank you for all you continue to do in these troubling times. Warm regards. Phillip

**Jeff Bergosh**: I’ll find out Phil—sorry this has dragged out so long

**Phil FIORILLI**: Thank you. If there is anything I can do to facilitate the accomplishment let me know. R/

**Jeff Bergosh**: Will do!

**Jeff Bergosh**: Thanks

### CONVERSATION ON 04-14-2020

**Phil FIORILLI**: Sorry I missed your call. I agree that something needs to be done with the entire corner. Your predecessor had agreed at one point to get the corner cleared but that never happened. 
Bottom line is that trees/vegetation that grows unchecked in the right of way can and does become a safety issue. Gulf power only addresses the non insulated power lines and does not address the other utilities lines that run on the common poles. This is in the right of way not on anyone’s private property. I as a concerned citizen want to get this safety issue cleared up. Thank you for taking the time to visit and take pictures. If I had known you were out here I would have come out and said hello. Thanks again for all you continue to do. R/ 

### CONVERSATION ON 04-15-2020

**Phil FIORILLI**: Question for the coffee this morning. Why is there minimal at best coverage of the positive outcomes with regard to COVID-19?  The vast majority of what we are hearing is the gloom and doom aspect of this nasty mess. What the local medical professionals have done to come together needs to be celebrated not forgotten.

### CONVERSATION ON 04-27-2020

**Phil FIORILLI**: Commissioner, Two questions this morning.
1.   Have you heard anymore on the Right of Way clearing here on Shelby Lane? 
2.  What happened to the MyEscambia Application that allowed citizens to input trouble calls or report code infractions to the appropriate office?  Tried to input a couple of issues over the weekend to no avail. 
Thank You again for your support and for all you are doing to make a difference. Warm Regards. Stay safe out there.

**Jeff Bergosh**: Good morning Phil—I know the arborist was out last week, awaiting her determination on the trees along Shelby.  As to the other issue, I’ll have Debbie look into that with IT and call you back when she gets word.  Have a great Monday

**Phil FIORILLI**: Than you.  Good to hear that Debbie is back. 

### CONVERSATION ON 04-29-2020

**Phil FIORILLI**: Commissioner, Thank you for all that you have done to keep the requested Shelby Lane right of way cleanup moving forward. I received the report from Debbie. I truly appreciate your and the County staffs work. Stay safe out there. Cheers Warm Regards, Phillip

**Jeff Bergosh**: Thanks Phil!👍

### CONVERSATION ON 05-01-2020

**Phil FIORILLI**: Commissioner, The roads department crew was out here this afternoon to work on the requested right of way cleanup. While I appreciate what was done I will submit that it is about 85% done. Stuff was cut short but the stumps reman which only means that in short order the problem will be back. I attached two photos to give you a glimpse of where the action was left. If you have the opportunity to drive by I would appreciate you feed back. Please understand that I truly appreciate what has been done as it looks 100% better than it did this morning. Respectfully,  Phillip

**Jeff Bergosh**: Okay thanks for the heads up Phil I’ll swing by and take a look on my way home from work.

**Phil FIORILLI**: Thank you. The update was a great idea. Got to love the tech that’s avail these days. 

**Jeff Bergosh**: Thanks Phil— the tech is great so just have to figure out how to use it properly LOL

**Phil FIORILLI**: R

### CONVERSATION ON 05-05-2020

**Phil FIORILLI**: Commissioner,  Hopefully you had an opportunity to see what has been done and what was not done. My vision is that the scrub growth and invasive plant growth can be cut down and back to the property line so that that area can be mowed on a regular basis to maintain a clear right of way.  I believe this is the only area along Shelby Lane that has not been cleared back to the property line. Thank you again for your support. V/R Phillip

### CONVERSATION ON 05-08-2020

**Phil FIORILLI**: Commissioner, I hate to stay on the subject of clearing the right of way on Shelby Lane  but I think I have figured out a part of the problem - the wire fencing in the brush is not on the property line with the right of way just like the chain link fence on the right hand side extends beyond the property line into the right of way. Thank you for listening. r/Phillip

**Jeff Bergosh**: Okay I’ll have the roads crew check that Phil—thanks for this information and have a great weekend!

**Phil FIORILLI**: Thank you. I know that the roads crew did a survey a couple of weeks ago. So it should have been marked. Have a great weekend with your family. Cheers and thank you for all that you do. I truly appreciate your efforts. V/r Phillip

### CONVERSATION ON 05-14-2020

**Phil FIORILLI**: Has there been any further progress on when this will be accomplished?

**Jeff Bergosh**: Not as of yet Phil.  I’ll get a status update

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 05-18-2020

**Phil FIORILLI**: Questions for this weeks coffee - For Kevin Adams-
With the schools of of session has all the deferred maintenance been done?
With Beulah Elementary School operating at over capacity if you discount the numerous aging portables. When is a new Elementary school going to be built. The bandaids are not working in the students best interest.
With the middle school operating at capacity what is the plan for the future with all the new construction and growth in this district from North to South and East to West? 

Questions for Vicky Campbell - 
Is there a plan to provide sewer hook ups to existing homes as the build out of new homes takes place adjacent to them. 
What needs to be done to bring fire mains to areas that have no fire hydrant? 
Does ECUA work together with County Roads staff to try and install utilities when roads are paved to minimize disruption and project costs?

Thank you for all that you do. R/
 

**Jeff Bergosh**: Thank you Phil—very good questions that will be asked Wednesday!

**Phil FIORILLI**: Thank you for facilitating this venue. All of your efforts to stay available are appreciated. 

**Jeff Bergosh**: 👍

**Phil FIORILLI**: Any word from the folks at the Roads Department on clearing back to the true property line?  The gas folks cleared about six feet to run gas lines last week. Thank you. R/

**Jeff Bergosh**: Not yet Phil—sorry for the delay.  I’ll ask Debbie to double check

**Phil FIORILLI**: Thank you also what is the mechanism on relaxing the open fire ban?  I know that we did not meet the previously established metric for ceasing open burning but the rational for the ban was good just hoping that with this rain the ban will be lifted. R/

**Jeff Bergosh**: I’m thinking it’s probably lifted but I’ll ask

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 05-20-2020

**Phil FIORILLI**: Commissioner, Did I miss the announcement that the burn ban has been lifted?  Could not find anything on the county website or on channel three news at five or six. Thank you in advance. R/

**Jeff Bergosh**: Nope.  It will be lifted and announced tomorrow

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 05-21-2020

**Phil FIORILLI**: Commissioner, What is the status of the burn ban being lifted?  Thank you in advance. R/

**Jeff Bergosh**: Not yet lifted per fire chief today.  Waiting until next week

**Phil FIORILLI**: That is unfortunate. Guess the actin Fire Chief did not want to make a decision. This is why open ended bans do not work. Once enacted no action required. On a separate note I trust that your leaker is found and prosecuted to the fullest extent. This is unacceptable in more ways than one. Hang en high. A public flogging is good for morale. Keep your head up. Cheers. 

**Phil FIORILLI**: Commissioner , I would be remiss if I did not say thank you to the staff for the additional trimming of high limbs along Shelby Lane. I still hold out hope that the ground based vegetation in the right of way will similarly be cleared. Thank you for your continued support. R/

**Jeff Bergosh**: Thank you Phil!

**Phil FIORILLI**:  Yes sir. 

### CONVERSATION ON 05-22-2020

**Phil FIORILLI**: Sorry my post was incomplete on your update broadcast. I was trying to ask - What is the Escambia County death rate (year to date) 2019 versus 2020 to see if there is truly an increase in deaths or not. I agree that every death is a tragedy but it seems like the Covid focus is skewing the picture. Maybe a wast of time in the end. Again sorry for being unclear. 

**Jeff Bergosh**: No problem Phil I just didn’t understand it in real time LOL

**Phil FIORILLI**: Roger that. I left a lot out in retrospect. 

### CONVERSATION ON 05-27-2020

**Phil FIORILLI**: Thank you for your efforts to resolve the Wilde Lake moguls as you turned off of Pine Forest. No more teeth rattling. Not sure when this was done but it is appreciated. Cheers

**Jeff Bergosh**: It came out nice didn’t it?  I drove it yesterday.  It’s an improvement but it’s not the final solution we need

**Phil FIORILLI**: Yes it is a vast improvement. Roger not the final but at least a step in the right direction. Thank you for asking about the “Burn Ban” status earlier. Seems like a whole lot of hand wringing and Government foot dragging to get this resolved. Again thank you for your support. R/

**Jeff Bergosh**: 👍 absolutely Phil!

**Phil FIORILLI**: Sorry to be a thorn but has there been any progress on ending the burn ban??  Have tried to find latest on MyEscambia to no avail. Thank you. 

### CONVERSATION ON 05-28-2020

**Jeff Bergosh**: I asked yesterday during my conference call but the fire chief hasn’t made the call yet

**Phil FIORILLI**: Thank you. Wheels move slow at times. Have a good weekend. Cheers. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-29-2020

**Phil FIORILLI**: Thank you for your help with the burn ban. As you know we are now out of the ban. 

**Phil FIORILLI**: Commissioner, Any more progress on right of way ground level vegetation clearing on Shelby Lane?  I appreciate your efforts. Thank you in advance. Have a great weekend. Looking forward to the Friday wrap up. Cheers!!

**Jeff Bergosh**: I asked for an update but have not got it yet.  I’ll check again

**Phil FIORILLI**: Commissioner, If the height of the trash mountain is dangerous for ECUA trucks to travel maybe there should be a transfer station at the landfill. I’ll be honest I don’t see how a transfer can be over capacity. More of a resource allocation situation. 

### CONVERSATION ON 06-02-2020

**Phil FIORILLI**: Commissioner, a couple of items for tomorrow’s Coffee. Status of Library project and status of  the Beulah Fire Station renovation and upgrade. 
On a separate note do you know what the upcoming Highway 90construction is all about and how long that is scheduled to take?  The lighted sign boards leave a lot to be desired. 
Thank you in advance. R/

**Jeff Bergosh**: I’ll find out—thanks for the questions!

**Phil FIORILLI**: You are welcome. Thank you for all you do. Cheers!!

### CONVERSATION ON 06-08-2020

**Phil FIORILLI**: Commissioner, I guess some trees can be cut down. 
Any resolution on the Right of Way clearing request?  I know that Art does not want to do it for fear of having to do it in other places. I’m not sure I understand the clear unwillingness to do the right thing.  I’m not convinced that Wes Merino is aware of the lack of effort here. 
On a separate note is there a way to bring repair actions to the correct PublicWorks area?  Since g“MyEscambia” app no longer works it is very difficult(impossible) to get pot holes and code enforcement issues resolved. Thank you again for your efforts. Keep charging!!  Cheers

**Jeff Bergosh**: Hi Phil I have asked for an update and I apologize for not getting back to you on it yet—been inundated with issues all over the place.  Is the ask MyEscambia app not working?  That is news to me and I will have that looked into. Thanks for the heads up on that!

**Phil FIORILLI**: Yes, I asked about the app back in April. It still is not working. It was a great way to get the little things fixed without them becoming big irritants. 
Look forward to hearing what the resolution is going to be. 
I understand that this is a low priority no loss of life request. Just trying to get it moved the last little bit. I do appreciate your patience in this matter.   R/

**Jeff Bergosh**: Sure thing Phil!

### CONVERSATION ON 06-17-2020

**Phil FIORILLI**: Jeff,  Need a new sign. Recent high winds broke the leg off. I’ve stuck it in the fence for the time being. The sign itself is fine it’s the metal leg that broke off at ground level. Good meeting this morning. Cheers.

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Thanks Phil!  Just planted 2 extras for you outside your fence.👍

**Phil FIORILLI**: Thank you. 

**Jeff Bergosh**: Absolutely and thank you!

### CONVERSATION ON 06-25-2020

**Phil FIORILLI**: Question - What is the best way to get potholes fixed?  Used to use the myescambia app but it does not work. Thank you. 

**Jeff Bergosh**: Good morning Phil-  where is the pot hole?  I’ll send out the crew to get it fixed.  And the myescambia app should be up and running but I’ll check with IT

**Phil FIORILLI**: They are on Shelby Lane. Once I get home I’ll paint them so that the road crew can see them. I’ll try the app again as well. Thank you 

**Jeff Bergosh**: Okay thanks Phil

**Phil FIORILLI**: I gave the App a second and third try without success. The attached photos are to provide locations on some of the worst areas. As you know Shelby Lane is narrow and when there are cars moving in both directions one or both will pull to the edge or into the unpaved right of way to avoid a collision. Shelby Lane is in dire need of resurfacing to include proper buildup of the curb area. Thank you 

**Phil FIORILLI**: Sir the MGO Application is a poor replacement for the MyEscambia Application if that is what has happened totally not user friendly.   Thank you for forwarding the previously identified roadway issues. 

**Phil FIORILLI**: Commissioner, A thought on the upcoming election cycle. Given that the current social distancing will likely be with us for the foreseeable future it might be a good idea for the County Commissioners to take a united position and encourage the Supervisor of Elections to double or triple the number of voting locations. Yes this means more equipment and personnel but it would serve the community in a positive way. Just a thought. R/

### CONVERSATION ON 06-26-2020

**Jeff Bergosh**: I agree but the problem we are having is getting enough poll workers to volunteer.  Many are elderly and medically fragile and therefore unable to work polling stations.  I believe, unfortunately, we will have fewer polling places and a heavier reliance on vote by mail this year—-which I do not like.  But the circumstances are what they are.......

**Phil FIORILLI**: Roger. 

### CONVERSATION ON 06-28-2020

**Phil FIORILLI**: The above is from the CDC. 
If you are well no face mask. Hope this helps add to your decision tree. Stay safe. Trust you got the photos I sent. The MyEscambia app still does not accept uploads for road work requests or I do not know how to use it. The app worked last summer and was easy to use. Maybe someone can explain why it no longer is functioning. Thank you. Cheers. R/

### CONVERSATION ON 06-29-2020

**Jeff Bergosh**: I appreciate the screen shot and I’m working the issue of the online issue reporting—thanks for the heads up on it

**Phil FIORILLI**: Commissioner, Just saw your interview with CH 3. Thank you for your statement on “Facts and Science”. Even the CDC has vacillated on the issue of wearing a mask.   R/

**Jeff Bergosh**: Thanks Phil!

**Phil FIORILLI**: You are welcome. 

### CONVERSATION ON 07-08-2020

**Phil FIORILLI**: Commissioner, As the dashboard is created how will deaths be categorized?  Just because an individual is positive for COVID-19 does not automatically mean that is the cause of death. Let’s try to be clear on that fact. I do think that a fact based dashboard has been long overdue. V/R

### CONVERSATION ON 07-15-2020

**Phil FIORILLI**: Sir, As you look at the budget please look at reducing duplication. Does there really need to be as many separate sites for public works? There is equipment ago the road prison, at the North end, at East Nine Mile and at the dirt pit on Mobile Highway.   Economy of scale says there is too much overhead. Reduce the fat and increase efficiency. 

**Jeff Bergosh**: Will do Phil- There are multiple areas where we have duplication/overlap— I look forward to reducing this when we vote on this in September.

**Phil FIORILLI**: Thank you for looking at this. Understand that there are/were good reasons in days gone by but again as you have to seriously look at belt tightening I hope you can get two other members to agree. Business as usual is no longer doable. V/R

**Jeff Bergosh**: Exactly!  

### CONVERSATION ON 07-16-2020

**Phil FIORILLI**: Example of a Texas dashboard. FYI. R/

### CONVERSATION ON 07-25-2020

**Phil FIORILLI**: Commissioner, What can be done to force the developers along Beulah Road between Nine Mile Rd. and Mobile Highway to fix the drainage issues when it rains?  Presently the ditch on the West side does not carry water when it rains as it did today. The water floods across Beulah Road which is causing a hazard. This is unsatisfactory.  Thank you for taking action on this community matter. R/Phillip

**Phil FIORILLI**: Commissioner, What can be done to force the developers along Beulah Road between Nine Mile Rd. and Mobile Highway to fix the drainage issues when it rains?  Presently the ditch on the West side does not carry water when it rains as it did today. The water floods across Beulah Road which is causing a hazard. This is unsatisfactory.  Thank you for taking action on this community matter. R/Phillip

**Jeff Bergosh**: Phil— I will ask the engineering staff and development services to look into this.  I know it presents a problem when we have heavy downpours.

**Phil FIORILLI**: Thank you. Seems like the developers failed to build in drainage openings that directed water into the established ditches. I just hope the County has not taken maintenance of this on. I cannot afford the cost as a taxpayer. 

### CONVERSATION ON 07-30-2020

**Phil FIORILLI**: Saw this at a local Auto Parts store this morning. The sign says it all. If there is a County wide Ordinance it might be better aimed. Just another thought. No easy answer. This option at least focuses more on where congregation happens. Might be a bit less onerous than a mandate aimed at citizens. End result is what is important. R/

### CONVERSATION ON 08-07-2020

**Phil FIORILLI**: Cannot believe the lack of preparedness the “Mobile COVID 19 Test Site” has had. Two days one hour of supplies and done. Did they think that this part of the County as not going to use the opportunity? Not a good result for the many that tried to us to no avail. 

**Jeff Bergosh**: Sorry to hear the state fell short on this.  I will see if we can expand this testing out there.  Let me get to work on that!

**Phil FIORILLI**: Thank you. This might work better if the Mobile site went street to street vice setting up at one location. Yes Beulah was country but alas no more for the most part. This has left a bad taste in some of the Equestrian workers not that in the end it’s all part of a days work. Stay safe and hydrated. R/

**Phil FIORILLI**: Commissioner, I understand that there is a zoning request in progress to rezone the property that fronts Mobile Highway and is bounded on one side by Stagecoach Rd and Jamestown Rd on the other. I trust that the developer will be required to put in dedicated Right and Left turn lanes off of Mobile Highway. Hopefully you will communicate with the district representative on the Zoning Board that the good of the community requires this as well as proper storm water retention. Beulah growth remains out of control with all the residential new construction. As you are well aware the existing infrastructure is at or past the point of failure. Thank you in advance. R /

**Jeff Bergosh**: I haven’t seen it yet Phil but I’m not gonna support any upzoning’s until we finish our master plan for the area

**Phil FIORILLI**: Hopefully the Zoning board will not undercut you on that position. Thank you for your continued service. R/

**Jeff Bergosh**: If they do I’ll vote them down😎👍

**Jeff Bergosh**: Thank you Phil! 

**Phil FIORILLI**: Thank you!!

### CONVERSATION ON 08-15-2020

**Phil FIORILLI**: Commissioner, Further to my earlier question on what is going to be done about the unsatisfactory drainage control by the developers of the subdivisions along Beulah Rd between Mobile Highway and Nine Mile Road who is responsible for the undermining of Beulah Rd that has now lifted the asphalt paving and is becoming a danger to all who drive this road. Again the developers and the County Planning department have failed to do their jobs and the taxpayer will foot the bill for repairs. This cycle of passing the buck has to stop.  R/

### CONVERSATION ON 08-16-2020

**Jeff Bergosh**: Phil I don’t disagree.  I drive that road on a very regular basis— where is the damage?  Is it north if Mobile Hwy or South?  If it is South of Mobile Hwy We have control and can effect a repair.

**Phil FIORILLI**: No Sir it is North of Mobile Hwy. it is a direct result of the builders not controlling the runoff from the developments. The County or State is getting a pig in a poke so to speak when they are left to fix what was improperly designed. I’ll be happy to meet with you to show you this debacle. R/

**Jeff Bergosh**: Okay let’s plan on that when I get back to town from my trip this week to Milwaukee to take my son back to Law School at Marquette.  I’ll be back on the 26th

**Phil FIORILLI**: I’ll be available when you are. Safe travels

**Jeff Bergosh**: Okay thanks Phil?

**Jeff Bergosh**: *don’t know why autocorrect added the question mark LOL

**Phil FIORILLI**: R

### CONVERSATION ON 08-26-2020

**Phil FIORILLI**: Commissioner, I see that once again the land development/zoning board has disregarded the desires of the community in approving the plan for a Dollar General on Kingsfield. When is this roughshod treatment of those who are directly affected read home owners going to stop. I get it the property owner can sell to whoever but the follow on development needs to be mindful of the existing homeowners wishes. V/r

### CONVERSATION ON 08-27-2020

**Jeff Bergosh**: Hey Phil I agree with you in that instance it’s my understanding that that proposed development fell within the existing zoning and future land-use and I believe it is for that reason why it was approved

**Phil FIORILLI**: While that may be true the developer to my understanding needed a variance to build an over sized building which is a large part of what the homeowners were requesting not happen. I could be mistaken but then again. 

On a different note: Congratulations on your reelection. Trust your family trip was as relaxing as the Facebook posts indicated. Welcome back to the fray. 

**Jeff Bergosh**: Thanks Phil!! 

### CONVERSATION ON 08-28-2020

**Phil FIORILLI**: Jeff, Any word on what is going to be the end result of the Mobile Highway relabel?  The real need is for a rebuild that brings the necessary turn lanes along with a wider driving surface area. Whatever you can do to stop the undersized ingress/egress points for the new subdivisions would be great. Sorry if that decreases developer profit but we both know it’s a pass along cost to the new homeowners and there seems to be no shortage of buyers willing to by the overpriced offerings out here in District One.  R/

### CONVERSATION ON 08-29-2020

**Jeff Bergosh**: Phil they are designing that in the first quarter of next year it’s a state project I believe part of it will be safety enhancements including wider shoulders turn lanes but they will not before lining it because the volume of traffic does not justify four lanes on mobile highway

**Phil FIORILLI**: I understand the words but do not agree with the volume. If that is true I would submit that the new Commercial construction as well as the under construction residential as well as the planned residential will levitate to work and the stores. Maintaining an undersized road when now is the time to be proactive is totally wrong. If the TPO cannot see that this is undersized then it’s past time to get bigger decision makers onboard. Pushing the widening of Mobile Highway further to the right is wrong on so many levels. R/

### CONVERSATION ON 08-31-2020

**Phil FIORILLI**: Jeff, if the dollar figures in the attached chart are correct could you explain why infrastructure is not being improved and replaced. I for one do not believe that the county has tightened any belts or consolidated any operations for efficiency. 
More revenue more spending for new not repairing the existing. When is this going to stop?

**Jeff Bergosh**: No chart attached

**Phil FIORILLI**: Sorry about that. Just sent it. 

**Phil FIORILLI**: Have you seen the damage on Beaulah road from the recent rains undercutting the roadway?  I am happy to meet you and show you the damage. Bad design at work from the site prep to the county engineers. 

**Phil FIORILLI**: Given that the CDC has changed the guides on what is a true Covid death and is now showing only Six percent of all who get the Covid virus actually die from it while the other 94% had one or more underlying medical conditions when will the county Covid dashboard be updated to reflect a more true status?  The continued misreporting of deaths only fuels the pandemic fires. Thank you for listening. R/

### CONVERSATION ON 09-01-2020

**Jeff Bergosh**: Phil I agree with you I think that is a devastating statistic that was put out and it will be discussed at tomorrow mornings coffee it really is crazy to think that only 6% of people with no underlying health conditions have succumbed to this virus

**Phil FIORILLI**: Would be interesting to ghettos the same clean number for the flu. My money is on the flu to be higher.  Stay safe. 

**Phil FIORILLI**: Should have read “ get the same clean numbers for the flu”. Got to love auto correct. 

### CONVERSATION ON 09-02-2020

**Phil FIORILLI**: Commissioner, How is this going forward if the master plan has not been finalized??

### CONVERSATION ON 09-03-2020

**Jeff Bergosh**: Not sure where this is located?  Where is this, off of Klondike?

**Phil FIORILLI**: This is on Beulah Road just past the new Circle K. It’s on the left side as you head towards the landfill. 

**Jeff Bergosh**: It may have already been platted and permitted— not sure.  I inherited lots of this——stuff that was approved but laying dormant through the recession and after and coming back to life as the economy improved 

**Phil FIORILLI**: Do no be believe that to be true as this property was for sale in January
If memory serves. 

**Jeff Bergosh**: You may be right

**Phil FIORILLI**: Property sold to this developer in 2018 less the house that sits in the middle so to speak. May have been the house that was for sale. That still would make this a development that should be tabled until the OLF-8 business is finished. 
It would appear to me that the zoning board and the county commissioner ‘s are out of sync. I get the one off homes on family land being approved but a better handle on development needs to occur. I get that you are chasing the tax revenue but maybe spend more time reducing costs to the taxpayer and then you will have the resultant savings to fix some of the long-standing deficiencies. 

**Phil FIORILLI**: On a separate note the recent overlay for OLF-8  that showed residential development did not show streets that would accommodate school bus turn around or adequate width to accommodate parked cars and emergency vehicle passage. Just an observation as it was only a proposal. 
But proposals have a way of becoming reality without any common sense changes. 

**Phil FIORILLI**: I am a bit surprised by your earlier statement. Are you saying that there is no current review on new development construction when the developer does not go forward with a development for any of a variety of reasons?  I would expect that any development that has not broken ground would be subject to the OLF-8 development moratorium. How do you get the infrastructure piece fixed and the costs applied to the appropriate party(not the taxpayer) involved? A building moratorium is a building moratorium. No exceptions. The taxpayers deserve better treatment. For what it’s worth. 

**Jeff Bergosh**: Going in mtgs. Will talk later

**Phil FIORILLI**: R. Stay safe. 

### CONVERSATION ON 09-08-2020

**Phil FIORILLI**: What time is the TPO meeting and where is it held?  Thank you. 

**Jeff Bergosh**: TPO meeting is tomorrow morning, Wednesday morning,  at 0900 at the Gulf Breeze Community Center 800 Shoreline Drive Gulf Breeze Fl 32561

### CONVERSATION ON 09-09-2020

**Phil FIORILLI**: Jeff, Sorry I could not attend today’s TPO meeting. Anything you can share. Would like to meet somewhere for coffee. I have a few thoughts I’d like to share but as I’m old school texting lacks in delivery. Thank you. R/ Phillip

**Jeff Bergosh**: Sounds good Phil I’ll give you a call

**Phil FIORILLI**: Roger. 

**Phil FIORILLI**: Sounds like a plan!!

### CONVERSATION ON 09-10-2020

**Phil FIORILLI**: Commissioner, The folks ate the dump need to start charging the surcharge for “uncovered” loads. Would also be appropriate for the correct agency to spend some time on nine mile and Beulah roads. Today it was fresh cut limbs on nine mile and uncovered loads on Beulah. Danger Will Robinson Danger. R/Phillip.

**Jeff Bergosh**: You are right about that!

### CONVERSATION ON 09-13-2020

**Phil FIORILLI**: Sir, when did Ms Blackwell become the know all be all fo Beulah. I would submit that the resident opinion polls are a microscopic sampling of District One residents. I for one am totally against a “Town Center” and any more residential units. Regardless on the completion of a new I10 interchange. Certainly an additional interchange would be nice but until the rest of the feeder transportation infrastructure is brought up to current standards much less going above and beyond. r/ Phillip

### CONVERSATION ON 09-14-2020

**Jeff Bergosh**: Thanks Phil I totally agree.  Most residents out here do not want any more residential on the field.  That editorial piece was essentially a hatchet piece against me because I refuse to genuflect before Navy Federal Credit Union and a few NIMBYS.  I’m going to complete the rebuttal today and send it in to the PNJ

**Phil FIORILLI**: Sounds good. Stay the course. 

### CONVERSATION ON 09-21-2020

**Phil FIORILLI**: I know you and the county road crews are covered up but I wanted to ask a question - What would it take to revisit the cutting down of the trees in the Shelby Lane Right Of Way that we previously discussed. As a result of the storm David has publicly stated that he would like them gone. If this is a possibility I will ask him the discuss with the second negative voice and if both agree will with your support only bring this up again. It’s amazing what’s accomplished with mother nature’s help. Thank you for all that you continue to do even when it is not appreciated. FYI Shelby Lane has power again. Cheers. 

**Jeff Bergosh**: Hi Phil Glad your powers back up so many issues were dealing with right now but we will certainly look at that Shelby Lane issue and prioritize it accordingly once we come up for air with all the storm debris removal

**Phil FIORILLI**: Roger. I’ll get David to talk with the other party and if concurrence happens I’ll bring it to you. No concurrence and I’m done trying in the short term. Thank you again. Now what can you do about all the rain?  Smile Sir I’m kidding. Have a good day heading the cats around in the round room. R/

**Jeff Bergosh**: 😎👍thanks!

### CONVERSATION ON 09-25-2020

**Phil FIORILLI**: Jeff,  First off a big thank you for all of your efforts post Hurricane Sally. 
Have a question- Has the County given any thought to actually clearing the right of ways of stuff that has grown up and now presents a hazard to the community either when it falls into the roadway or when it takes out power and communication lines. Presently with so many residents using the communications grid to attend school or work or participate in local government meetings. It would be a great thing to do. 

There seems to be a divide between the Electrical power company and the communications providers or line trimming. The power company only trims near the uninsulated power distribution lines and does not trim the insulated line area. The communications providers adamantly refuse to trim the space around their transmission lines. Maybe the county can bring some firepower to this. Thank you for your time. R/Phillip

**Jeff Bergosh**: Thanks Phil this seems like a reasonable suggestion when the dust settles from the storm will definitely look at this

**Jeff Bergosh**: Hope all is well with you!!

**Phil FIORILLI**: All well only minor damage. Piling stuff at the curb. Fun times. Let me know when you want to meet for coffee on your way to work. You pick. Cheers

**Jeff Bergosh**: We will do this— looking forward to it Phil!

### CONVERSATION ON 09-27-2020

**Phil FIORILLI**: Is there anywhere that citizens can dump non vegetative stuff ie insulation, Sheetrock, carpet besides to curb?  Have had three flat tires in four trips to the dump. I would rather pick it up once rather than having to pick stuff up twice after the grapple and Mother Nature makes a bigger mess on the side of the road. I’m sure the road crews don’t want to go behind and do the final hand picking up. Thank you. Cheers. 

**Jeff Bergosh**: Right now Phil the only sites that have been identified for drop off or for vegetative debris so right now the only option for all other debris is to leave it curbside sorted and separate from the vegetative debris

**Phil FIORILLI**: Thank you.   

### CONVERSATION ON 10-05-2020

**Phil FIORILLI**: Quick question  What can be done to prevent debris from being piled in a drainage ditch?  My favorite neighbor is doing this and tearing up the ditch at the same time. Thank you. 

**Jeff Bergosh**: At the moment since everyone is is all strung out trying to get debris off their property there’s probably very little we can do in the near term. what we will do is after the debris is cleaned up we will send the road crews out and assess the ditches and repair the ones that need to be repaired.  Unfortunately it’s only gonna get more hectic in the lead up to this next storm coming in the gulf.

**Phil FIORILLI**: R. Then I will relocate the debris as the clam grabbers are what tore up the ditch last time (Ivan) and the county has yet to repair. Your predecessor said it would get done but to date no joy. Last attempt to fix only resulted in road sweeping dirt and lost of pebbles being brought out I’ve given up on Art doing anything meaningful to fix the situation. More later. R/

**Jeff Bergosh**: Okay I’ll look into it all when I come up for air Phil

**Phil FIORILLI**: Thank you. Not a priority what with all that is going on. Stay safe. 

**Jeff Bergosh**: You as well Phil!

**Phil FIORILLI**: Thank you. I’m trying. 

### CONVERSATION ON 10-08-2020

**Phil FIORILLI**: Jeff, On the subject of “Gated Communities” and debris removal, what happened after Ivan? And what are the recorded covenants and deed restrictions that were placed on the development at the time of development and maintained/in effect today?  While I feel for the residents and their predicament. They are all to happy to cite these restrictions when it benefits them. Another example of developers over reaching and banking profit. Just my two cents. Hope you are having as good a day as you can. Keep juggling all the moving pieces. Cheers. R/

**Jeff Bergosh**: Thanks Phil

### CONVERSATION ON 10-12-2020

**Phil FIORILLI**: Quick question - Who decided where the FEMA trucks emptied after picking up a load. I’m asking because the truck picking up on Shelby Lane has to go over to Highway 98 across from the Navy Hospital to dump. Would seem that every FEMA collection site should allow any FEMA debris truck to dump their load. Less driving time means more loads per day which gets the debris picked up quicker. 

On a separate note I noticed an open fire on Mobile Highway just east of Beulah Elementary School was still burning this morning. 
When will the burn ban be lifted?  Seems the burn ban is unnecessary. Thank you for listening. R/

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: Hi Phil-  I believe the burn ban is still in effect so whomever was burning was probably doing so in violation of the ban.  As it pertains to the where debris is being hauled to— each of the three contractors was assigned a location so thwart their weight totals would not be intermingled with the other haulers’ debris—- and with the way the county is laid out it invariably produces inefficiency.  It’s the way FEMA set up the program....

**Phil FIORILLI**: Roger. Thank you for the reply. Stay safe out there. Cheers!!

**Jeff Bergosh**: You too Phil!

### CONVERSATION ON 10-19-2020

**Phil FIORILLI**: Jeff, What are the chances that the burn ban can be lifted or at least modified?  I have a pit that I use to burn in.  Have noticed several open ground level fires this weekend without any fire Dept response to the smoke. All have been visible along Mobile Highway. 

**Phil FIORILLI**: Thank you in advance. 

**Jeff Bergosh**: Hi Phil I’ll ask the question.  Things have been dry but I believe later this week we will be getting rain

**Phil FIORILLI**: Thank you. It’s a bit frustrating when we are under a burn ban and our neighboring counties are not. Hopefully ECUA or whoever runs the county landfill will not be releasing methane gas again any time soon. Again thank you for all you do and have done. Cheers and stay safe. R/

### CONVERSATION ON 10-20-2020

**Phil FIORILLI**: Jeff, I listened/watched the OLF-8 Charade today and was left gasping for air when one of the presenters made the comment that they were told not to include any land reservation for schools. While I see that there is county representation present there is no school board presence. While I have low expectations for the present district one rep at least there should be a presence. Beulah Elementary school replacement site somewhere in the plan regardless of how it’s funded in the end it’s taxpayer dollars that get the purchase done and the school built. Please tell me that schools are in your plan for the future. Thank you for listening. R/

### CONVERSATION ON 10-21-2020

**Jeff Bergosh**: Of course they are filled I actually brought this concept up way back starting in 2013 when I was the school board member because I knew Beulah Elementary was way over crowded. The final plan will include at least 10 acres for a follow on elementary school to complement the overcrowded Beulah Elementary school that’s my prediction

**Jeff Bergosh**: Once this team of planners is done we’re going to rearrange it and get it right because none of the four designs I saw captured what I think we need

**Phil FIORILLI**: I would submit that the planning team needs a school board member involved until the end. Even if no residential is the final decision a school on 25 plus acres could be complementary to the final site projection. It appears to me that Ms Blackwell has a lot of sway at this point. I’m on team no residential but we need a new school and this is a golden opportunity to let the overall developers pay the land cost for the school site withhold. R/

**Jeff Bergosh**: I don’t necessarily disagree on having school board involved— they have had a carte blanch, open invitation to participate.  As a matter of fact, the chair of the school board Patty Hightower called me late last week and we discussed at length the need for another elementary school in Beulah and she asked my thoughts on the OLF 8 site for a school and I agreed.  Now, as far as Theresa Blackwell goes, she has NO sway on anything.  NADA.  She’s important in her own mind only, and she can provide input just like you and Other interested citizens and NFCU—- but at the end of the day its 5 commissioners that will finalize the plan.  And I predict Theresa won’t like it.......

**Phil FIORILLI**: I’m on your side on this. Was just passing my observation/takeaway from the interchanges I heard during the presentation of the four proposals. 

As far as the school goes I would submit that early visible involvement by the school board would be better that way at least the concepts get out there in the public’s view and siting a school is not viewed as an afterthought. Just my three cents. R/

### CONVERSATION ON 10-23-2020

**Phil FIORILLI**: Good morning!! Quick question - When has the groundbreaking for the District One Library been scheduled for. Saw that the sign out front of the site was abused by Sally hopefully the former bank structure did not suffer significant damage that will impact the plan. Stay safe out there. Cheers!!  R/

### CONVERSATION ON 11-07-2020

**Phil FIORILLI**: Please pass this concern to the fine folks that look at sites during construction and ask them how there is no wetland encroachment and damage on Lakeside Oak down where the cul de sac is. This is in the Lakeshore Preserve development off of Beulah Road. Thank you.  

**Phil FIORILLI**: Another question, when does the county take maintenance responsibility for the roads in this (Lakeshore Preserve) subdivision. I heard Horace say after two years but currently there is a sink hole depression halfway down Oak Lake Blvd.  Right in front of 7444 Oak Lake Blvd.  Thank you again.

### CONVERSATION ON 11-11-2020

**Phil FIORILLI**: Are the fees for a door replacement still being waived? I understand that a permit is still required but trying to ensure a neighbor is overcharged. Thank you. 

### CONVERSATION ON 11-12-2020

**Jeff Bergosh**: Hey Phil-if it’s hurricane related, not new construction, the fee is waived but the permit is required

**Phil FIORILLI**: Roger. Neighbor is having front door and storm door repaired. Thank you for the response. 

### CONVERSATION ON 11-24-2020

**Phil FIORILLI**: Here is another example on Shelby Lane of poor Right of Way maintenance. I can send you more photos if you like. 
What I would appreciate is if we can reopen the dialogue on removing the vegetation along the entire length of Shelby Lane from the roadway to the true property line. The previous discussion was in accurate since the farm fence was not on the property line but is in fact in the right of way. Thank you. R/Phillip

**Jeff Bergosh**: Hey Phil— I’ll forward this to the roads department to have them thin it out.  Hope you have an excellent Thanksgiving with the family!

**Phil FIORILLI**: Thank you. There are at least three opportunities for success. There may be more. If Wes would like I’ll send you the street addresses.  Have a great Thanksgiving with your family. Cheers  R / 

### CONVERSATION ON 03-29-2021

**Phil FIORILLI**: Commissioner, Is there a way to anonymously  get  zoning control to determine how many dwellings are occupied by various people related or not at 7150 and 7160 Shelby Lane.  

I know that the owner of 7160 is living in one of the sheds behind the White House in the front.

Bringing down the neighborhood. 

Thank you in advance.

**Jeff Bergosh**: I’ll find out Phil.  Thanks for bringing it to my attention

**Phil FIORILLI**: Thank you. Did you see my request for grounds maintenance at the Interarity point fire station?  I know that is not your district but was hoping you could intercede with Mr. Underhill.  Not a good look for visitors to the park and boat ramp. Thank you in advance. R/

### CONVERSATION ON 07-12-2021

**Phil FIORILLI**: Just checking to follow up on the right of way maintenance request I sent last week. I included photos. Thank you in advance for your assistance. R/

**Jeff Bergosh**: Hey Phil—I thought Those might’ve been yours. It came to me in a text file so I wasn’t sure but now that you’ve texted me I will double check them Debbie is out of the office but I’ll have Caleb my intern for those to Wes. Hope all is well!

**Phil FIORILLI**: Thank you. I sent them to the D1 address. Is there a better address to use?  Thank you again. R/

**Jeff Bergosh**: No that’s the right one.  

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 07-14-2021

**Phil FIORILLI**: Commissioner, Are there any plans to improve connectivity for those residents that do not live in the North end of the county?  An example is Shelby Lane. While the new subdivisions that are being built out have fiber to the house. The existing residences are being by passed creating islands in the digital desert. Please consider these islands in your quest to bring the county into the digital age. Thank you in advance for your time. R/ Phillip Fiorilli

**Jeff Bergosh**: Will do Phil!

**Phil FIORILLI**: Thank you. 

**Jeff Bergosh**: 👍

**Phil FIORILLI**: Commissioner, At what point does a weed infested/ overgrown area rise to the level where Code Enforcement will inform the owner that this growth is not allowed?  This is the current state of affairs at 7265 Shelby Lane. Thank you for your assistance. R/

**Jeff Bergosh**: I'm not sure but I'll find out

**Jeff Bergosh**: I'm sending this to Tim Day

**Phil FIORILLI**: Thank you again. The owner of the property directly behind cut the right of way this past Sunday. I do appreciate your help. R/

### CONVERSATION ON 08-06-2021

**Phil FIORILLI**: Commissioner, Any feedback fromCode Enforcement on their visit to the weed infested yard at 7265 Shelby Lane?  Thank you in advance. R/Phillip

**Jeff Bergosh**: Yes they issued a citation and I have spoken to the resident as well.  He's not happy but I've explain to him that if you clear-cut an area of your property you can't just let it become infested with weeds if you want a buffer you have to plant something there that is not unsightly

**Phil FIORILLI**: Thank you. Is there any time line for progress?

**Jeff Bergosh**: It's in the early stages so it could be a while if the owner doesn't voluntarily comply.  But at least the ball's rolling

**Phil FIORILLI**: Thank you again. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2021

**Phil FIORILLI**: Commissioner, Good morning. Not to beat a dead horse so to speak but how many rats need to be seen before the weed infested lot gets cleaned up?  Don't need to have vehicle wording chewed up unless the county will pay for that fix. 

On another note, Who should I contact to request that the drainage ditch on the west side of my property along Shelby Lane be cleaned out?  Weeds and grass are impeding the storm water flow. 
Thank you for your time and assistance. R/ 

**Jeff Bergosh**: I'll take both for action to get updates and service.  Thx for heads up

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 09-03-2021

**Phil FIORILLI**: Commissioner, Thank you for the quick response and action on the weed removal from the drainage ditch. 
     Have you received an update on the overgrowth situation that Code Enforcement has viewed?  Thank you in advance.  R/

### CONVERSATION ON 10-18-2021

**Phil FIORILLI**: Commissioner, any update on when the code violation situation on Shelby Lane will be concluded. Thank you for your continued involvement in resolving this health and safety issue. R/

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: Good morning Phil I'm having staff research that right now and someone will get you the answer today

**Phil FIORILLI**: Thank you. 

### CONVERSATION ON 11-08-2021

**Phil FIORILLI**: Commissioner , I'm resending the below to try and determine the way ahead. Thank you in advance. R/

Commissioner, any update on when the code violation situation on Shelby Lane will be concluded. Thank you for your continued involvement in resolving this health and safety issue. R/

**Jeff Bergosh**: Not sure Phil but I'll have staff provide an update.

**Phil FIORILLI**: Thank you. Sorry that this is dragging on. Appreciate your oversight. 

