

## CONVERSATIONS WITH MAYOR ASHTON HAYWARD

### CONVERSATION ON 02-19-2020

**Mayor Ashton Hayward**: You probably know however I wanted you  to make sure.  

**Jeff Bergosh**: Yes I saw this-are you coming to this?

**Mayor Ashton Hayward**: On my way to Dallas

**Jeff Bergosh**: Have a good trip!

**Mayor Ashton Hayward**: On my way to Dallas

**Mayor Ashton Hayward**: 👍🏻👍🏻👍🏻

### CONVERSATION ON 02-20-2020

**Mayor Ashton Hayward**: Thank you for your Leasership 

**Jeff Bergosh**: Thank you Ashton!

### CONVERSATION ON 04-02-2020

**Mayor Ashton Hayward**: R u in your meeting?

**Jeff Bergosh**: No

**Jeff Bergosh**: We canceled our morning meeting

**Mayor Ashton Hayward**: Jeff,  stay strong support.  I think it’s very important to keep our beaches closed for the safety of our citizens right now.  All my best, Ashton 

**Jeff Bergosh**: Yes I agree.  That’s what’s going to happen.  Stay safe!

Jeff 

**Mayor Ashton Hayward**: Thank you , you & your family stay safe.

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-03-2020

**Mayor Ashton Hayward**: Good morning, FYI you might have seen this.

### CONVERSATION ON 06-21-2020

**Mayor Ashton Hayward**: Happy Fathers Day my friend.  Saw your brother yesterday, hope your well.  Keep punching.

**Jeff Bergosh**: Thanks Ashton!!  Happy Father’s Day to you!! Make it great!

**Mayor Ashton Hayward**: 👍🏻 

### CONVERSATION ON 08-17-2020

**Mayor Ashton Hayward**: Good morning Commissoner, how are you feeling?  Best, As

**Mayor Ashton Hayward**: Ashton 

**Jeff Bergosh**: Tha is Ashton!  I’m feeling great- all six polls run in my race put me in the lead so I’m feeling pretty confident— but we will see what happens Tuesday.  I think I’ll win it by 5-7 points and 450-550 votes.  Thanks for all your help and support!!

**Jeff Bergosh**: And I hope all is well with you 

### CONVERSATION ON 08-18-2020

**Mayor Ashton Hayward**: Good luck today my friend!

**Jeff Bergosh**: Thank you Ashton!

**Mayor Ashton Hayward**: Congratulations my friend!

**Jeff Bergosh**: Thanks Ashton!!!!!! Glad it’s now over for the next 51 months!!!!

**Mayor Ashton Hayward**: Yes sir!

**Jeff Bergosh**: 👍👍

### CONVERSATION ON 09-16-2020

**Mayor Ashton Hayward**: You guys OK?  Let’s catch up tomorrow.

**Jeff Bergosh**: Yes we have a few trees down but overall we did fine.  Hope you all are alright as well!

**Mayor Ashton Hayward**: 👍🏻

### CONVERSATION ON 09-18-2020

**Mayor Ashton Hayward**: You mentioned a lot of trees down, my significant other Jeff Strickland, has a tree removal business and they have crews out today if y’all need any help - 850.291.8254

**Mayor Ashton Hayward**: Whitney Hill works for Dr. Reese.

### CONVERSATION ON 11-26-2020

**Mayor Ashton Hayward**: Good morning Jeff.  Happy Thanksgiving to you & your family, Enjoy the day my friend.  Best, Ashton 

**Jeff Bergosh**: Thanks Aston! Hope you all had a great one as well!

**Mayor Ashton Hayward**: 👍🏻👍🏻👍🏻

### CONVERSATION ON 11-30-2020

**Jeff Bergosh**: https://peterattiamd.com/lloydklickstein/

**Mayor Ashton Hayward**: 👍🏻

**Jeff Bergosh**: Interesting stuff

### CONVERSATION ON 12-03-2020

**Mayor Ashton Hayward**: Good morning, c u @ McGuires @ 12:30 Tap Room.  Thx

**Jeff Bergosh**: Right on I’ll be there

### CONVERSATION ON 12-25-2020

**Mayor Ashton Hayward**: Merry Christmas Jeff!  Best to the family.

**Jeff Bergosh**: Merry Christmas Ashton!

### CONVERSATION ON 01-07-2021

**Mayor Ashton Hayward**: Happy New Year!  Thank you for supporting the young man developing the apartments on Sorrento.  Best, Ashton 

**Jeff Bergosh**: Thanks — the commissioner for that district pulled a no show LOL

**Mayor Ashton Hayward**: 😳

### CONVERSATION ON 02-15-2021

**Mayor Ashton Hayward**: Jeff, good morning.  Hope you guys are well.  Do you know any of the Commissioner’s in Taylor County?  Thx, Ashton 

**Jeff Bergosh**: Good Morning Ashton- hope all is well.  Unfortunately I do not know any of those commissioners.  Sorry about that

**Mayor Ashton Hayward**: Cool let’s connect soon

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: *mtg

**Mayor Ashton Hayward**: Can u step out for r a second

**Mayor Ashton Hayward**: Good morning, I would greatly appreciate your support on the Local Provider Participation Fund.  I did it in the city before I left.  It’s NOT a tax.  Escambia County needs the help.  

**Jeff Bergosh**: Yes I spoke to Mark Faulkner yesterday on it.  I intend to support it

**Jeff Bergosh**: 👍

**Mayor Ashton Hayward**: Let them know you & I chatted if u like 

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Thx

**Mayor Ashton Hayward**: 👍🏻 

### CONVERSATION ON 06-20-2021

**Mayor Ashton Hayward**: Happy Father’s Day my friend.

**Jeff Bergosh**: Same to you- make it a great one!

### CONVERSATION ON 07-01-2021

**Mayor Ashton Hayward**: Jeff, good evening.  Great remarks today & thank you for your leadership & the kind words.  You are a class act.  Let’s connect soon & best to the family.

**Jeff Bergosh**: Thanks Ashton!  Let’s do that.  I meant what I said:   without you I don’t think this whole deal happens.  What you did for Pensacola will pay dividends for decades to come. What a great day for our area —right?!? I’m glad you were able to make it over to the event.  Definitely let’s have lunch soon— you me and Gary.  Have a great and safe Fourth of July with your family!

**Mayor Ashton Hayward**: Thank you my friend, you too!  Best, Ashton 

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-16-2021

**Mayor Ashton Hayward**: What’s your email for a personal invite?

**Jeff Bergosh**: Jeffbergosh@gmail.com

### CONVERSATION ON 08-09-2021

**Mayor Ashton Hayward**: Let me know when you want to grab lunch.

**Jeff Bergosh**: Will do looking forward to it. I’m out in the field right now but when I get back to my office I’ll check the calendar —hope all is well Ashton!

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: How about Friday at the IPC?  11:30?

**Mayor Ashton Hayward**: JB, good morning.  Unfortunately will out of town for work.  Can we do next Friday?  Thx

**Jeff Bergosh**: Sure thing— the 20th 11:30works for me.  I’ll put it in my calendar.  Hope all’s well!  I’ll invite the Judge to join us if that’s cool

**Mayor Ashton Hayward**: Absolutely 

**Mayor Ashton Hayward**: Putting on my calendar 

**Jeff Bergosh**: 👍

**Mayor Ashton Hayward**: Looking forward to it

**Jeff Bergosh**: Me too— have a great rest of the week!

**Mayor Ashton Hayward**: 👍🏻 back @ u

### CONVERSATION ON 08-19-2021

**Jeff Bergosh**: Hey Ashton— just checking to make sure we’re still on for lunch tomorrow at 11:30 @ McGuires

**Mayor Ashton Hayward**: Yes sir

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-20-2021

**Jeff Bergosh**: Almost there

### CONVERSATION ON 08-28-2021

**Mayor Ashton Hayward**: Good morning, FYI Bender's father passed.  

Please tell Sally I got her email, I'm going to do something.

**Jeff Bergosh**: Thank you very much Ashton I’ll let Sally know and yes I heard about Robert’s father very sad

**Mayor Ashton Hayward**: 👍🏻

### CONVERSATION ON 09-16-2021

**Jeff Bergosh**: Just dropped Item 13

### CONVERSATION ON 10-05-2021

**Jeff Bergosh**: Hey Ashton it’s Jeff Bergosh I had a quick couple things I wanted to run by you if you had a minute to call.  I know you’re busy but if you call me back that’s be great—— look forward to catching up thanks!

**Mayor Ashton Hayward**: Give me 35

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-18-2021

**Jeff Bergosh**: Hello Ashton— I just read in Ricks Blog that you’re now working for a big lobbying firm— congratulations!  So are you no longer at Andrews Institute?

**Mayor Ashton Hayward**: No he's not correct 

**Jeff Bergosh**: I thought that was kind of a strange post—

**Jeff Bergosh**: Glad to hear you’re still at Andrews

**Mayor Ashton Hayward**: Bizarre I will advise when needed.  Goofy.

How are you?

**Mayor Ashton Hayward**: Absolutely 

**Jeff Bergosh**: I’m good

**Jeff Bergosh**: Just gearing up to take back Perdido Key from Dildo Doug 😎👌👍

**Mayor Ashton Hayward**: Good!

### CONVERSATION ON 10-29-2021

**Jeff Bergosh**: Hey Ashton! I missed you at Michell’s fundraiser last night— it turned out pretty good for her.  I was wanting to touch base with you about the Health and Hope Clinic fundraiser to see if you will be able to get behind it.  It’s coming up in 30 days but pledge commitments are due (for the printing of programs) by Nov. 5th— a week from today.  Anything you can do would be greatly appreciated.  I hope all is well-  have a great weekend!

**Mayor Ashton Hayward**: Hey there Jeff, hope you had a great week.  An & I are in .  I reached out to Witkin he said he always sponsors.  Please check.  Also I will hit a few others.  Ran into your brother tonight @ McGuires .  Let's connect.

**Jeff Bergosh**: Right on thanks Ashton!  Yes, let’s talk next week have an awesome weekend!!!

### CONVERSATION ON 11-23-2021

**Jeff Bergosh**: Hey Ashton hope everything’s going well and that you guys are all set for a great Thanksgiving! I just wanted to thank you again for your generous support of the Christmas at the Clinic event at the Pensacola Country Club a week from today. Sally just asked for me to reach out and see if you and An will be able to attend  the event ——-it would really mean a lot to both of us if you could if you’re able.  Anyways —-let me know, and again—Happy Thanksgiving, look forward to talking to you!

**Mayor Ashton Hayward**: Absolutely we are! 

**Jeff Bergosh**: Awesome thanks Ashton!!

**Mayor Ashton Hayward**: Looking forward to it 

### CONVERSATION ON 12-02-2021

**Mayor Ashton Hayward**: Jeff, good morning.  Great event Tuesday, please tell Sally she did a wonderful job.  

Question, do you have a busy day?  I have some HS seniors from around the panhandle that ask me to speak. It's a SGA thing at UWF at 9:30 today, speak for 30 minutes max . Topic ins leadership & how you got into politics.  I know it's last minute but I'm sick as a dog.  

Got on antibiotics yesterday.    Again I know it's last second.  Let me know please.  Thank you, Ashton

**Jeff Bergosh**: Thank you so much for the kind words!  I’d love to speak at that event Ashton and any other day I would do it but I have a board of County commissioners meeting at 9 o’clock that’s going to run till noon and then I have another one starting at 4:30. I bet my brother would love to do something like that if he’s not in court today do you want me to ask him?

**Mayor Ashton Hayward**: That would be amazing.  Again I apologize I'm miserable.

**Jeff Bergosh**: Calling him rn

**Mayor Ashton Hayward**: 👍🏻 

**Mayor Ashton Hayward**: Jeff, you are a lifesaver.  Give em hell today!  

Sincerely, thank you.

**Jeff Bergosh**: Thanks Ashton!!

### CONVERSATION ON 12-25-2021

**Mayor Ashton Hayward**: Merry Christmas my friend.  Ashton 

