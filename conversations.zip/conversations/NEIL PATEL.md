

## CONVERSATIONS WITH NEIL PATEL

### CONVERSATION ON 01-02-2020

**Neil Patel**: Hey it's Neil from Kia Autosport Pensacola 

**Jeff Bergosh**: Hey Neil it's Jeff Bergosh I'm gonna head that direction my daughter should be there right now with her white Chrysler Sebring convertible if you see a young lady walking around that's probably my daughter

**Neil Patel**: Ok np ty

**Jeff Bergosh**: Hey Neil--looking at adding my daughter Tori to my policy but I need the VIN can u text it to me?

**Jeff Bergosh**: Can we come back and do this deal right now?  The quote on my policy was much better

### CONVERSATION ON 01-14-2020

**Neil Patel**: Good morning I need one document signed that finance forgot to get signed can I email to you and you sign, scan and email back?

**Jeff Bergosh**: Sure Neil

**Neil Patel**: Ty, what's your email?

**Jeff Bergosh**: Jeffbergosh@gmail.com

**Neil Patel**: Just sent email 

### CONVERSATION ON 08-25-2020

**Jeff Bergosh**: Hi Neil— what kind of lease deals is Kia putting out right now? I’m looking for another small car, 3 yrs lease—thanks, Jeff Bergosh 

**Neil Patel**: Hey how are you?

**Jeff Bergosh**: Doing great!

**Neil Patel**: $0 down on a Forte around $280 and a Soul around $320

**Neil Patel**: Good luck on election!!

**Jeff Bergosh**: I won it already!  Thanks!

**Neil Patel**: Sorry I meant congrats lol

**Jeff Bergosh**: Thanks

**Neil Patel**: No problem 

**Jeff Bergosh**: I’m going to come by

**Neil Patel**: Ok let me know when 

**Jeff Bergosh**: 10 min

**Neil Patel**: Ok cool

