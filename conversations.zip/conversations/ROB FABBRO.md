

## CONVERSATIONS WITH ROB FABBRO

### CONVERSATION ON 10-12-2020

**Jeff Bergosh**: Hey Rob thank you very much for coming --we had a great time it was a lot of fun--we're looking forward to doing this again have a great week!


### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Hey Rob are you and Jeanette here? 

### CONVERSATION ON 10-22-2021

**Jeff Bergosh**: Hey Rob we're parking right now if you guys are here you can go ahead and head into the IPC I've got a table reserved with our name on it

