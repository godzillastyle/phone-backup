

## CONVERSATIONS WITH ERIC SHARPLIN

### CONVERSATION ON 06-28-2021

**Eric Sharplin**: Hi Jeff I think Alex andrinni

**Eric Sharplin**: May run against you

**Jeff Bergosh**: 👍

**Eric Sharplin**: Had u heard that

**Jeff Bergosh**: No

**Jeff Bergosh**: Meanwhile, that's 3 1/2 years away.  That's a loooooonnnngggg time for him to wait

**Eric Sharplin**: Unless he think about dist 2

**Eric Sharplin**: I told Melissa to calm down she said wendy was staring at her in publix

**Eric Sharplin**:  I hope Vicki don't run

**Eric Sharplin**: 9 percent rate increase

**Eric Sharplin**: What's going on over there

### CONVERSATION ON 06-30-2021

**Eric Sharplin**: I want to say statement was corrupt Doug said that's why y'all got rid of gilley

**Jeff Bergosh**: He's wrong as per usual

### CONVERSATION ON 07-01-2021

**Eric Sharplin**: Hope you have a wonderful  4th of july

**Jeff Bergosh**: U too

### CONVERSATION ON 07-13-2021

**Eric Sharplin**: Hi Jeff 

**Eric Sharplin**: U might wanna consider remind the poster to be nice

**Eric Sharplin**: On your blogspot

**Jeff Bergosh**: Sure will.  Lots of folks getting worked up........

**Eric Sharplin**: People including me get to excited

**Eric Sharplin**: But I stand behind my statement we must be willing to forgive an forget

### CONVERSATION ON 07-14-2021

**Eric Sharplin**: The war just started again

**Jeff Bergosh**: It never ends 

**Eric Sharplin**: Melissa deactivate d her fb

**Eric Sharplin**: Me

**Eric Sharplin**: She told

### CONVERSATION ON 07-21-2021

**Eric Sharplin**: Sent u latest cartoon

**Jeff Bergosh**: Yeah I saw it

**Eric Sharplin**: Crazy

**Eric Sharplin**: They never stop

### CONVERSATION ON 07-22-2021

**Eric Sharplin**: What channel is Escambia tv on

**Eric Sharplin**: On spectrum

**Eric Sharplin**: Did u know amber was quitting

### CONVERSATION ON 09-15-2021

**Eric Sharplin**: Press lease on doug

**Eric Sharplin**: State ethics commission

### CONVERSATION ON 10-09-2021

**Eric Sharplin**: Wow Doug is never nice

**Eric Sharplin**: Attacking u

**Eric Sharplin**: On ecw

### CONVERSATION ON 11-18-2021

**Eric Sharplin**: I see the other night show at little Grove Church saw male tried to take it on I know she's planning on trying to take you on at The point Church and the church but it's also one-sided so I don't see it what purpose mel pino is getting done

**Eric Sharplin**: Hopefully Doug will be more

**Eric Sharplin**: Open

### CONVERSATION ON 12-03-2021

**Eric Sharplin**: Doug I think will be ur opponent

**Jeff Bergosh**: Good.  In 36 months he can come off the bench and run against me when I'm next up for election, at which time I'll crush him like a roach

**Jeff Bergosh**: I'd actually welcome the opportunity to do it!

**Eric Sharplin**: Possiblity y'all may to run this year

**Jeff Bergosh**: True

**Jeff Bergosh**: Even better

**Eric Sharplin**: In 2022

**Eric Sharplin**: Mel saw a posting

**Eric Sharplin**: About it

**Eric Sharplin**: I think Mel will miss ole doug

**Jeff Bergosh**: LOL 

**Eric Sharplin**: Just my view it's seems like a  old sweetheart quarrel they both like nagging each othet

**Jeff Bergosh**: I think she despises him because he's dishonest and corrupt

**Jeff Bergosh**: And he lies.  A lot

**Eric Sharplin**: True

**Jeff Bergosh**: Only the Kool Aid drinkers love a liar 

**Eric Sharplin**: Yes

**Eric Sharplin**: I noticed he don't respond to her

**Eric Sharplin**: As much

### CONVERSATION ON 12-04-2021

**Eric Sharplin**: Jeff said he squash Doug like a roach if he runs

**Eric Sharplin**: Opps

**Eric Sharplin**: Was sending to Mel pino

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: 👍

