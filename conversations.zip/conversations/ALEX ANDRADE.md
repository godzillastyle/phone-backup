

## CONVERSATIONS WITH ALEX ANDRADE

### CONVERSATION ON 12-06-2019

**Alex Andrade**: Please let me know if you need anything. 

**Jeff Bergosh**: Thanks Alex I think there’s probably 100 police vehicles on the base so I think they got it covered let me know if you hear anything please

**Alex Andrade**: I will. 

**Alex Andrade**: DEM and Governor's office wants to make sure the County gets whatever it needs today.

### CONVERSATION ON 05-06-2020

**Alex Andrade**: Hey Commissioner, DEM is sending resources to help with the fires in Santa Rosa County, they’re aware of the second fire. If you need anything, please let me know 

**Jeff Bergosh**: Will do.  I’m watching it closely

**Jeff Bergosh**: Thank you Alex!!

**Alex Andrade**: These fires have great timing for sure. 

**Jeff Bergosh**: Yeah—timing is terrible!

### CONVERSATION ON 05-21-2020

**Jeff Bergosh**: Hello Alex—to what email should I send the Zoom meeting invite for Wednesday’s coffee meeting online?  Also— thanks for agreeing to join me for it!

**Alex Andrade**: Alex.andrade@myfloridahouse.gov

**Alex Andrade**: And yeah, absolutely!

**Jeff Bergosh**: Outstanding—thank you!!

### CONVERSATION ON 05-27-2020

**Jeff Bergosh**: Hey Alex are you logging in to the coffee?

**Alex Andrade**: Yep, right now

**Jeff Bergosh**: 👍

**Alex Andrade**: Thank you sir!

**Jeff Bergosh**: Alex that was awesome!  Thank you for participating and for the great insights!

**Alex Andrade**: For the record, I’d love it if it were a constitutional right to buy and sell alcohol, but 18-20 year olds would be included if it were. 

**Jeff Bergosh**: Yes—and they would really like that

**Alex Andrade**: I would have as an 18 year old as well. Lol

**Jeff Bergosh**: Me too!!

### CONVERSATION ON 06-30-2020

**Alex Andrade**: Just saw Doug take credit for himself and Jonathan Owens for the water projects I got funded. I’m still laughing at his lack of awareness or complete dishonesty

**Jeff Bergosh**: He is a tool.  Totally out of touch

### CONVERSATION ON 08-27-2020

**Alex Andrade**: Hey, I wanted to say congratulations on the win. You earned it and I’m looking forward to working with you again sir.

**Jeff Bergosh**: Thank you Alex!! Congrats to you on retiring Dosev!!  Did he ever call you to concede?

**Alex Andrade**: No, just texted me later and said I made a “big mistake”

**Alex Andrade**: Not sure what that means but I can’t wait find out 😂

**Jeff Bergosh**: Wow!  What a guy....

### CONVERSATION ON 09-14-2020

**Alex Andrade**: Need anything going into this storm at this point?

**Jeff Bergosh**: Good morning— I think it is so far so good this far —- thanks very much for checking in though!  

**Alex Andrade**: Absolutely, I don’t anticipate it being earth shattering. 🤞

**Jeff Bergosh**: Me neither— and I hope we’re both right!

### CONVERSATION ON 09-15-2020

**Alex Andrade**: Checking in. You have everything you need?

**Jeff Bergosh**: So far so good— thanks for checking in!  Stay safe!

### CONVERSATION ON 09-21-2020

**Alex Andrade**: Hey, figured you should know there’s a sewer backup that is still overflowing at 5701 Princeton Dr. from my phone it looks like it’s in your district.

**Alex Andrade**: I’m relaying to ECUA

**Jeff Bergosh**: Thanks for the heads up—appreciate it very much!

**Alex Andrade**: They just Facebook messaged me

### CONVERSATION ON 10-12-2020

**Alex Andrade**: I got a chuckle out of Doug hopping on my Facebook page and lecturing me about effectiveness. At least he didn’t call me “boy” this time

**Jeff Bergosh**: That guy’s a real piece of work.  He has zero credibility and he’s the poster child for how not to be effective and work together with his peers.  Glad you schooled him with your response.  Two years cannot come quickly enough.....Hope all’s well

**Alex Andrade**: You think he gets a real challenger?

**Jeff Bergosh**: I certainly hope so.  It has to be someone who will go door to door and work though.  He won’t be a pushover so it will take a worker

**Jeff Bergosh**: I hear Marty Stanivich is going to put his hat in the ring

**Alex Andrade**: Interesting

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Congratulations on your victory tonight Alex!

**Alex Andrade**: Thank you sir! Glad to be passed it

**Jeff Bergosh**: 👍👍

**Alex Andrade**: Hoping it ticks up past 55% but I’m glad it’s over

**Jeff Bergosh**: LOL that’s right!

### CONVERSATION ON 04-21-2021

**Jeff Bergosh**: Hello representative Andrade I see you are a cosponsor on HB7041. I support that bill without the punitive language directed at single member district county commissioners as you and I have discussed. I believe the senates version is a much better bill. I’m hearing the house will adopt the Senate version which is very similar to the house companion. However the senate bill is better because it does not contain those onerous provisions that appear to be retaliatory toward certain county commissioners. Is what I am hearing accurate that the house will adopt the Senate version? Please let me know and I greatly appreciate it.

Jeff Bergosh 

**Alex Andrade**: I know the issue well and remember our talk, I’ve spoken with the sponsor several times. I think the senate version is the only one with the ability to pass and don’t believe it will contain that language in it

**Jeff Bergosh**: Thanks very much.

**Jeff Bergosh**: *Senator Baxley

**Alex Andrade**: Liked “Current Senate version does not contain that language center back to me did not add it included a lot of the language from the hospital.”

**Jeff Bergosh**: Sorry for the gibberish. What I meant to say was Senator Baxley specifically excluded that language when he added a lot of Ingnolia’s bill language  into senate bill 90

**Alex Andrade**: Yeah

**Jeff Bergosh**: So I’m hoping the house adopts it just as it sets and as it passed the rules committee yesterday

**Jeff Bergosh**: Have a great rest of the week!

**Alex Andrade**: You too sir!

### CONVERSATION ON 04-22-2021

**Alex Andrade**: The sponsor doesn’t like the language and doesn’t think the senate will have it on their bill

**Jeff Bergosh**: The senate sponsor, Baxley?

**Alex Andrade**: House sponsor

**Jeff Bergosh**: Great news.  So will the house adopt Senate’s version?

**Jeff Bergosh**: Thx very much for the update!

### CONVERSATION ON 07-16-2021

**Alex Andrade**: Good afternoon Commissioner. I wanted to connect you via text with Jay Faison. He's a driving force behind Flood Defenders and the American Flood Coalition. As you know, flood policy in Florida made huge strides this Session, and there are some opportunities for the County to leverage state funding in the near future if the County can get behind it proactively. Jay will be in town later this month, and hopefully that visit can help roadmap the best way the County can take advantage of the new programs. 

I remember how difficult it was to see neighborhoods underwater again after Sally, and figure it could help connecting you with Jay, especially to know what to task the new lobbyists with and to make sure Matt Posner and staff have the resources they need to pursue state funding.

### CONVERSATION ON 08-04-2021

**Alex Andrade**: Hey Commissioner, can you give me a call when you get a chance?

**Jeff Bergosh**: Absolutely.  Sorry I missed your call — been in and out of meetings all day at work.

**Alex Andrade**: All good, just wanted to touch base on one thing. No rush

### CONVERSATION ON 08-25-2021

**Alex Andrade**: Have a fun idea for you that I think you’ll really enjoy getting behind. Today’s been a good day 😂

**Alex Andrade**: Governor’s press secretary

**Jeff Bergosh**: I love that!!! I hate Marlette

**Alex Andrade**: I’ve been working with them today to take him to task. It’s gotten thousands of retweets on Twitter, but less on Facebook. Someone thought you might want to blog about it

**Jeff Bergosh**: I will!! Awesome!!! Thank you!!!

**Alex Andrade**: Awesome!

**Jeff Bergosh**: Alex I apologize for not being able to call you right back I’m in a meeting with the fire chief —but I want talk to you about this and I’ll call you after this meeting it’s over if you are available and that’s okay?

**Alex Andrade**: https://twitter.com/ralexandradefl/status/1430658698423193603?s=21

**Alex Andrade**: I’ll be at a town hall in Gulf Breeze, but can call you back later tonight if I miss you if that’s ok

**Jeff Bergosh**: Ok

**Alex Andrade**: https://www.tampafp.com/gannett-under-fire-for-racist-and-misogynistic-cartoons-published-in-florida-newspaper/

**Alex Andrade**: This article is GOLD

**Alex Andrade**: https://twitter.com/ralexandradefl/status/1430709184643928069?s=21

**Alex Andrade**: Going after local advertising dollars…

**Jeff Bergosh**: I just posted a blog on this

**Jeff Bergosh**: Someone needs to call rooms to go and tell them about this crap. The minute they stopped or three page colorful ads Dailey I think the news journal goes under

**Alex Andrade**: Can you send me the link?

**Jeff Bergosh**: http://jeffbergoshblog.blogspot.com/2021/08/how-is-this-okay-how-does-andy-marlette.html?m=1

**Alex Andrade**: Thank you!

**Jeff Bergosh**: No—- thank you!  This guy’s a sack of crap

**Jeff Bergosh**: Also posted on my blog

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-01-2021

**Alex Andrade**: Can you send me Wes Moreno’s cell?

**Jeff Bergosh**: Sure

**Alex Andrade**: Thank you!

**Jeff Bergosh**: 👍

**Alex Andrade**: Sorry, do you have Eric Gilmore’s cell?

**Jeff Bergosh**: Sure

**Alex Andrade**: Thank you!

**Jeff Bergosh**: No problem!

### CONVERSATION ON 09-13-2021

**Alex Andrade**: Hey Commissioner, have time for a call this morning?

**Jeff Bergosh**: Absolutely

### CONVERSATION ON 09-14-2021

**Alex Andrade**: Has he provided the plans to anyone?

**Alex Andrade**: I call BS that true engineering work has been done

**Alex Andrade**: Has FDOT signed off on them? 

**Alex Andrade**: Doesn’t sound like they have

**Alex Andrade**: Bullshit. They haven’t issued permits. 

**Alex Andrade**: So he doesn’t know how much construction will actually cost? He’s jumping all over the place

**Jeff Bergosh**: I wanted to have him answer on the record.  If he misrepresented, it will be difficult to support

**Alex Andrade**: Yeah, he’s a fraud. 

**Alex Andrade**: No way this gets done in a year

**Jeff Bergosh**: I agree I don’t see it happening

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: *Gannett

**Alex Andrade**: Yes! We’ve worked to break the stranglehold on legal notices for a long time

**Jeff Bergosh**: We’ve got to get that passed this year

**Alex Andrade**: I’m gonna let Randy Fine know. You shouldn’t be required to go to a newspaper at all. It’s 2021. The ideal is a 1 stop website clearinghouse with little to no fees charged

**Jeff Bergosh**: Yes!! Or let us publish notices Front and center on our official webpage and Facebook sites

**Jeff Bergosh**: Imagine the savings state wide to cities municipalities school boards and counties

**Alex Andrade**: Has the new policy been voted on by the BOCC?

**Jeff Bergosh**: No it’s just something that staff began to do and I think rightly so they see how we’ve been unfairly targeted with unfair cartoons in accurate characterizations character assassinations and other garbage

**Jeff Bergosh**: Got to admit it’s pretty genius though right?

**Alex Andrade**: Gotcha, if it’s ever an official action, please let me know as well

**Jeff Bergosh**: Will do

**Alex Andrade**: Yes, Randy Fine has been working that policy every year I’ve been there

**Jeff Bergosh**: It’s my understanding the big news media outlets send an army of lobbyists to Tallahassee every year to defeat it

**Alex Andrade**: The house has always passed it. It’s the senate that isn’t a fan

**Jeff Bergosh**: It’s time

**Alex Andrade**: I don’t know who lobbies against it. They know it’s a lost cause in the house. Lol

**Jeff Bergosh**: Good.  Now onto the Senate!

**Alex Andrade**: I lied. Some compromise language passed last session. Let me send you the link 

**Alex Andrade**: https://www.myfloridahouse.gov/Sections/Documents/loaddoc.aspx?FileName=h0035z1.CIV.DOCX&DocumentType=Analysis&BillNumber=0035&Session=2021

**Alex Andrade**: Here’s the final analysis(sparknotes for legislators) on the bill that passed

**Jeff Bergosh**: Thanks very much for this Alex!

**Alex Andrade**: Hey, I had some folks near Lake Charlene area calling me about water runoff and flooding issues. I told them I’d see if you wanted to visit with them with me in the next few months. Mike Arborout (sp*) was the first to contact me about it

**Jeff Bergosh**: Okay that sounds good— I’d be happy to.  It’s Doug’s district but sure let’s do that

**Alex Andrade**: Thank you sir! I need to double check the addresses, I thought it was right on the line

### CONVERSATION ON 11-30-2021

**Alex Andrade**: Sorry I missed your call. I’ll call back in 10 if that works

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: Are we still on for a meet and greet with residents tomorrow?

**Alex Andrade**: Yes sir!

**Jeff Bergosh**: Right on— just wanting to make sure

**Jeff Bergosh**: I’ll be there!  Incidentally— it’s no longer in my district as of last night

**Alex Andrade**: Oh nice!

**Alex Andrade**: Laughed at “I’ll be there!  Incidentally— it’s no longer in my district as of last night”

**Jeff Bergosh**: So I can say what I want to say

**Alex Andrade**: Haha, good point

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-04-2021

**Alex Andrade**: Thank you so much for coming!

**Jeff Bergosh**: Absolutely—- thanks for inviting me.  I’m following up 

**Alex Andrade**: You’re the man!

**Jeff Bergosh**: No you are!

### CONVERSATION ON 12-16-2021

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Something to consider if bail reform is going to happen this session

**Alex Andrade**: It’s the #1 false argument from the clerks. I’m not touching one comma of the law on how bail is set. 

**Jeff Bergosh**: Okay good—- I hear it’s being pushed hard

**Jeff Bergosh**: By one of our local hoteliers

**Alex Andrade**: It is

**Jeff Bergosh**: In Tally

**Jeff Bergosh**: Do u have a minute for a quick call?

**Alex Andrade**: Yes sir

