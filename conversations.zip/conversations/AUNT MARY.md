

## CONVERSATIONS WITH AUNT MARY

### CONVERSATION ON 05-24-2020

**Aunt Mary**: https://www.cbsnews.com/news/how-to-participate-in-steve-hartmans-taps-across-america/

**Aunt Mary**: 

Let’s all do this. I will know that at that moment we will all be standing in our driveway or on our porch with hand over our hearts remembering all those who served our country. 🇺🇸 
💕


### CONVERSATION ON 08-19-2020

**Aunt Mary**: Congratulations Jeff on your win!!
💕

**Jeff Bergosh**: Thank you!!

### CONVERSATION ON 06-03-2021

**Aunt Mary**: Good morning!!
I just finished listening to the two co-chairs of the Problem Solvers Caucus on Michael Smerconish. 
Their interview is in his 9:00 o’clock hour today on Sirius XM. 
It was really good and you can see how impressed Michael is with their work in Congress. 
Maybe you can listen to the program when you have some down time. It can be listened to at any time if you are a SiriusXM member.

### CONVERSATION ON 06-05-2021

**Aunt Mary**: Smerconish is on right now on CNN. He is going to have the problem solver’s co-chairs on in a few minutes. 

### CONVERSATION ON 07-15-2021

**Aunt Mary**: Thanks for sharing……..wish I was there. I love the backroad adventures. 💕

### CONVERSATION ON 07-16-2021

**Aunt Mary**: Loved an image

### CONVERSATION ON 08-16-2021

**Aunt Mary**: Hi Jeff,
I read your blog for the first time today after I read the front page of the PNJ. 
I considered it quite eloquent . 
I just recently rejoined the League of Women Voters. I had belonged to the League for many years when I first lived here. Now, like then, I find the political “goings on” in the area very interesting and I’ve learned with my recent subscription to the newspaper that I will not always get all the facts. 
So it is good to know that I will have a place that I can go to to get the rest of the story. 
I look forward to catching up with you and Sally,
Mary

### CONVERSATION ON 08-17-2021

**Jeff Bergosh**: Hello Mary!  Yes, those rats at the PNJ do their level beat to always paint me in a false light because they really, really dislike conservative politicians.  That issue they bring up is a red herring (my testimony) but of course they make it the centerpiece of their story.  They really are reprehensible.  But they have a monopoly so they do what they want.  I am fortunate that I do have some moderate level of recourse via my blog that I’ve had for 12 years— which allows me a platform to at least put out the truth about PNJ’s dishonesty.  But it’s oftentimes simply bare knuckles brawling in local politics; they are encouraged by their corporate folks to “find local corruption”. So when they can’t find it, they “create” it LOL.  Thanks for the kind words and I’m glad to know you are back in town— Sally and I can’t wait to have you over for dinner.  Have an awesome week!

Love,

Jeff

### CONVERSATION ON 08-18-2021

**Aunt Mary**: I opened my newspaper this morning to a Shakespeare editorial cartoon. 
I think Mr. Marlette is trying too hard to convince the PNJ audience and is losing his credibility on this issue. 

Mary
💕

**Jeff Bergosh**: LOL thanks!  

**Jeff Bergosh**: It’s bareknuckle brawling time

### CONVERSATION ON 08-21-2021

**Aunt Mary**: If at all possible, the saving of a really rare, magnificent, big tree is a good thing. 
It speaks to the level of progress made by a civilized society. 
Thank you for caring. 

### CONVERSATION ON 08-22-2021

**Jeff Bergosh**: Thx Mary!

### CONVERSATION ON 08-24-2021

**Aunt Mary**: I was looking at your favorite movies list on your blog. 
I would like to suggest a movie I think you might find worthy of viewing. 
It is called “Hidden Figures”. 
It is the story of three African American women who significantly contributed to the advancement of the U. S. Space Program despite the indignities they had to overcome. 
I hope you enjoy. ☺️ 

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: I saw that one.  I liked it, based upon a true story to boot!

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: 1200 Fort Pickens Road # 2-C
Pensacola Beach 32561

(Tristan Towers.  Gate code is #7777

**Aunt Mary**: Oh Jeff,
What a bummer!!
I am up in Nashville at Sally’s for a couple weeks , so I’ll have to take a rain check. 
Thank you and Sally so much for including me. 
💕

**Jeff Bergosh**: 👍.  Absolutely!

### CONVERSATION ON 12-21-2021

**Aunt Mary**: Jeff and Sally,
Thank you so much for dinner Sunday evening. It was so thoughtful of you. 
I really enjoyed my time talking with Tori……….she is such a delight. 
Sally…….may I please have your number? I would like to follow up with you after the holidays and come visit your organization. 
I love a good cause. 
Happy New Year!! 🎆🎊 🥳 
💕

**Jeff Bergosh**: Thank you so much for the kind words about Tori— we all had a great time too!!  Thanks for being there with us to celebrate— Merry Christmas!!

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas David!

**Aunt Mary**: Merry Christmas Guys!!
🎄❤️🎄

