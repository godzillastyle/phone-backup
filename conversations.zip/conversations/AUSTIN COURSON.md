

## CONVERSATIONS WITH AUSTIN COURSON

### CONVERSATION ON 05-06-2021

**Jeff Bergosh**: In a BCC meeting will call back

**Jeff Bergosh**: Okay thanks for the heads up.  Are you talking about the equestrian center?

**Jeff Bergosh**: Okay I’ll get on it right away.  What time tomorrow does this start?

**Jeff Bergosh**: Okay I will speak with facilities

**Jeff Bergosh**: Do you know Michael Rhodes our parks director?

**Jeff Bergosh**: I will

