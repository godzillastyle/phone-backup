

## CONVERSATIONS WITH JATIN

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thanks Jatin!!

### CONVERSATION ON 08-25-2020

**Jeff Bergosh**: Hey Jatin, just give me a call on this number when it’s convenient and we can chat.  It’s Going to be quite some time before they make the final recommendations on the master plan so that was just the initial thoughts

### CONVERSATION ON 01-02-2021

**Jeff Bergosh**: It’s an awesome place.  Happy New Year!

