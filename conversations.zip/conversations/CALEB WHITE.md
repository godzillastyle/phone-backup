

## CONVERSATIONS WITH CALEB WHITE

### CONVERSATION ON 07-06-2021

**Caleb White**: Eric Prutsman
850-210-2525
Item 11 first call
Baptist lifeflight

**Jeff Bergosh**: Got it Caleb, thanks

### CONVERSATION ON 07-13-2021

**Caleb White**: If you get a chance, please send the email address for Brenda Sinquefield so engineering can contact her.

**Jeff Bergosh**: Who is she?

**Caleb White**: She sent an email about the sinkhole that you sent a screenshot of Sunday

**Jeff Bergosh**: Oh, okay.  I’ll get it

**Caleb White**: Hey, just confirming that the weekly meeting for tomorrow afternoon at 4:30 is still good

**Jeff Bergosh**: So I think it is.  I’m assuming so.  Can u please double check with Sharon and Alison?  Thanks Caleb!

**Caleb White**: It is. Sharon was just double checking with you.

### CONVERSATION ON 07-14-2021

**Caleb White**: The number for the meeting at 4:30 is 863-333-5817, 973881295#

**Jeff Bergosh**: Thanks Caleb

### CONVERSATION ON 07-19-2021

**Caleb White**: Hey, could you give Eric Prutsman a call. He wants to talk to you about the first call agreement.
850-210-2525

**Jeff Bergosh**: Okay will do

### CONVERSATION ON 07-20-2021

**Jeff Bergosh**: He didn’t answer so I left him a voicemail

**Caleb White**: Okay

### CONVERSATION ON 07-21-2021

**Caleb White**: It was on the dais. I set it in your office

**Jeff Bergosh**: Awesome— thanks Caleb!!

### CONVERSATION ON 07-26-2021

**Caleb White**: 👍

