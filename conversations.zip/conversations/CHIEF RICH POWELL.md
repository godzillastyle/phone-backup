

## CONVERSATIONS WITH CHIEF RICH POWELL

### CONVERSATION ON 08-04-2020

**Chief Rich Powell**: Good afternoon sir,¿¿In preparation for tomorrow's coffee meeting I see there was a list of question to the SO, is there any particular question (s) you would like me or my ARNP to be prepared for?  ¿Thanks,¿Rich 

**Jeff Bergosh**: Good afternoon Chief!  

Thanks for agreeing to fill-in on short notice!

I think will ask questions like the following:

Number one what is the most challenging part of keeping a detention facility secure while also protecting the inmates and staff from infection from COVID-19

Number two how are you handling the challenge of isolating those inmates who test positive to prevent a larger infection?

Number three the work crews that are assigned to the road camp are going back out in the field now to pick up trash is that safe to do and how do you do that while keeping these inmates socially distanced while traveling to work sites?

Number four tell us about the procedures the jail staff utilizes at the intake point of a new inmate to ensure that individual does not have COVID-19?

Number five what will you do if a significant portion of your staff test positive and you don't have adequate staff to protect and guard the facility if it were to come to that? Is there a plan for that?



### CONVERSATION ON 01-28-2021

**Chief Rich Powell**: Gentlemen,
Sorry I could not accompany you on your tour, but this virius has me down   for a few days. Escaped it for a year, but it found me.
I hope my staff answered all of your questions and gave you good insight into our future at corrections. 
Please let me know if there is anything I can do for you or questions you may still have.
Take care,
Rich Powell 

**Chief Rich Powell**: Thank you

### CONVERSATION ON 01-29-2021

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: On a conf call will call u right back

### CONVERSATION ON 01-04-2022

**Chief Rich Powell**: Sir, can you send me the spelling of last name of the inmate?

**Jeff Bergosh**: Murillo

**Chief Rich Powell**: Update on last, I got him on the trip tomorrow with 21 others. With 113 males & females sentenced  with a some of those waiting on paperwork from the courts. I will continue to push and work with Tallahassee to get more then what they allocate to us.

**Jeff Bergosh**: Thank you Chief

**Chief Rich Powell**: No, thank you for your support! 

**Jeff Bergosh**: Absolutely!

### CONVERSATION ON 01-06-2022

**Chief Rich Powell**: Update on the number in case you needed them. We are holding 111 and waiting for the paperwork on 22 others. 

**Jeff Bergosh**: Thanks Chief.  The paperwork for the 22 others — is that incoming prisoners or outgoing?

**Chief Rich Powell**: Those are sentenced that we are waiting for all the paperwork from the courts

**Jeff Bergosh**: But we have them in custody now?

**Chief Rich Powell**: Yes 

**Jeff Bergosh**: So 133 total?

**Chief Rich Powell**: Yes

### CONVERSATION ON 01-26-2022

**Chief Rich Powell**: Good morning Sir, 

Thought you would like to know we transported 38 to prison today...we have Tallahassee's attention. Here is the balance as of this morning:


MALES 

64-- W/PAPERWORK

21-- W/O

TOTAL=85


FEMALES

6--W/PAPERWORK

2--W/O

TOTAL=8


