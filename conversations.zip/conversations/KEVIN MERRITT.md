

## CONVERSATIONS WITH KEVIN MERRITT

### CONVERSATION ON 07-02-2021

**Jeff Bergosh**: Just the HR number is all I have

