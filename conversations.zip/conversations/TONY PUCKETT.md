

## CONVERSATIONS WITH TONY PUCKETT

### CONVERSATION ON 11-09-2019

**Jeff Bergosh**: Are you watching this Alabama comeback!?!

**Tony Puckett**: I'm at the game.  Wild.

**Jeff Bergosh**: Have fun!

**Tony Puckett**: Thanks. 

### CONVERSATION ON 11-22-2019

**Tony Puckett**: Jeff, hope you are having a wonderful time on your trip. Just wanted to let you know that I have already approved all of your guy's timesheets for this week.  With our short week next week my payroll folks wanted to get a jump start. Thanks, and enjoy!

**Jeff Bergosh**: Hey Thanks Tony!  Yes, we're having a blast-really incredible place!

**Tony Puckett**: Awesome. Safe travels. 

### CONVERSATION ON 12-06-2019

**Tony Puckett**: Thanks for the update.  Be safe. 

**Tony Puckett**: Report is shooter has been killed. 

**Jeff Bergosh**: Shooters down three fatalities 15 shooting victims that's the latest information I have.  All our personnel are accounted for Ira Warren and Dave on the Base myself Tim Heather Gary Jaron and John off the base

**Tony Puckett**: Thanks Jeff.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Tony we just got the word that personnel can leave building 458. I spoke with Ira he and Warren and Dave have locked up and secure the building there exiting the base through the back gate the front gate is still closed. So all personnel will be off the base and everyone is safe and accounted for. I won't bother you anymore today but if you have any questions please give me a call I'm sure we'll talk about this on Monday when we all resume work and I wasn't able to do anything with the payroll hopefully we can do that on Monday morning.

**Tony Puckett**: No bother at all, I appreciate you keeping me informed.  Have a good weekend. 

**Jeff Bergosh**: You as well Tony

**Tony Puckett**: Keep me posted. 

**Tony Puckett**: Ira, Warren and Dave are in the building. 

**Tony Puckett**: Can you take care of that Tim?

**Tony Puckett**: Thanks guy's. 

**Tony Puckett**: The latest I have heard is shooter has been killed, 15 victims and 3 fatalities. 

### CONVERSATION ON 12-23-2019

**Tony Puckett**: I can't talk right now. I'll call you back shortly.

### CONVERSATION ON 12-30-2019

**Tony Puckett**: Just heard your voicemail. I had sent you a response to the email,  but again enjoy your time in New Orleans.  Be safe!

**Jeff Bergosh**: Thank you Tony!  It will be a little bittersweet because my dog got sick and I just found out from the vet that we have to put him down.  But he had a good life 13 years and he was a great friend

**Tony Puckett**: Wow, I am so sorry to hear that.  I dealt with that last Christmas,  just like losing a brother or a child. Sorry for your family. 

**Jeff Bergosh**: Thanks Tony we're all headed to the vets at 5:30 tonight to say goodbye so that won't be pleasant--my heart is crushed💔

**Tony Puckett**: Oh, I know exactly what you are going through.  I cried for days. 

**Jeff Bergosh**: That's where I am Right now.... it's horrible

**Tony Puckett**: Yep, it stinks. 

### CONVERSATION ON 03-26-2020

**Tony Puckett**: Can you call back later?

### CONVERSATION ON 03-30-2020

**Tony Puckett**: Jeff, call 256.536.7117 ext. 172 passcode 172

**Tony Puckett**: Passcode 7777 ,sorry

**Jeff Bergosh**: Got it--calling

**Tony Puckett**: Jeff, thanks so much for everything you do for me. I never have to worry about you taking care of business at NAS Pensacola with the companies best interest as your main goal. Hope the rest of your day went well. I did call and check on The Daniel's and the little one was resting well. Thanks again.

### CONVERSATION ON 03-31-2020

**Jeff Bergosh**: Thank you Tony!

**Jeff Bergosh**: Good morning Tony--do you have a minute for a quick call?

**Tony Puckett**: Yes

### CONVERSATION ON 04-01-2020

**Jeff Bergosh**: Tony--Just keeping you in the loop in real time.... Florida Governor Ron DeSantis issued a stay at home order statewide beginning Tonight at Midnight.  Details will be coming shortly and I will speak with Mark Powell about how that impacts our operations.

### CONVERSATION ON 05-31-2020

**Jeff Bergosh**: Hey Tony it's Jeff Bergosh I hope you're having a great weekend. Hey listen Sally surprised me with a Sunday night stay at a resort in Pensacola Beach for our anniversary. So I may be an hour or so late to work tomorrow I'll let staff know and I'll schedule the weekly meeting accordingly just let me know if that's all right with you and I hope you're having a great Sunday!

**Tony Puckett**: Nice. Enjoy your time. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-23-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-29-2020

**Tony Puckett**: Did Heather show up?

**Jeff Bergosh**: Yes she's here

**Jeff Bergosh**: Do u have a minute to chat?

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-30-2020

**Jeff Bergosh**: https://www.google.com/amp/s/www.wkrg.com/local-news/community-debates-with-escambia-co-commission-on-defunding-the-police/amp/

Tony--this is the news report out of Mobile on the "youth" that came before our county commission a few weeks ago wanting us to defund our  County Sheriff's office.  Let's just say I had a significant disagreement with them.  🙂

### CONVERSATION ON 07-02-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍just have an update for you

### CONVERSATION ON 07-10-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Ok thx

**Tony Puckett**: Did you find out anything about the PBOSC employee?

### CONVERSATION ON 07-15-2020

**Jeff Bergosh**: Hey Tony just wanted to let you know I followed up on that question about quarantining for visitors coming to Florida. I had the county administrator speak with the governors office directly ---there is no mandate for that as of right now.

**Tony Puckett**: Thanks. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-19-2020

**Tony Puckett**: Congratulations on your win last night!

**Jeff Bergosh**: Thanks Tony!!!  8 points and more than 1,000 votes---I'll take it LOL

**Tony Puckett**: Yes sir.

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: Tony, also want to say thank you for allowing me to continue to serve.  I'm blessed-- and thankful!!  Also-- thanks for allowing me to take PTO to spend time with my son Nick as he starts year 2 of Law school at Marquette in Milwaukee.  It's going to be a much needed break 🙂🙂

**Tony Puckett**: Very proud for you. Enjoy your family time!

**Jeff Bergosh**: Thank you Tony!!!!

### CONVERSATION ON 09-15-2020

**Jeff Bergosh**: Tony- FYI our phones, PBSS Network, and NMCI network are all down.  Cell phone will be the only way to reach us if need be.

-Jeff B

**Tony Puckett**: Is the base not going to shut down?

**Jeff Bergosh**: They are shut down for non-essential personnel 

**Tony Puckett**: So, you sre tge only one that is supposed to be there now?

**Jeff Bergosh**: PBSS are here as well.  WhiteTail is not

**Tony Puckett**: Hmmm. I guess the guys know they can leave but have to use PTO?

**Jeff Bergosh**: This was my back and forth with PBSS in an attempt to get clarification.  This morning at 4:30 they sent this which I forwarded to the team via text

**Tony Puckett**: Good deal,  we are covered then.

**Jeff Bergosh**: Yes

**Tony Puckett**: My wife and two friends were to travel down to Gulf Shores on Thursday for a long weekend.  What do you think conditions wi be like? I'm thinking they need to postpone.  

**Jeff Bergosh**: I think they should hold off.  Here's the very latest track from the county Tony

**Jeff Bergosh**: Gulf Shores, Orange Beach, Fort Morgan going to be inundated with water

**Tony Puckett**: I think they will postpone. 

**Jeff Bergosh**: That's a good idea

**Tony Puckett**: Keep me posted.  Thanks.

**Jeff Bergosh**: Will do

**Jeff Bergosh**: Tony-- both NMCI and PBSS emails and networks were down all day so thus no SITREP or reports.  Once these are back up I'll forward an updated report.  The hurricane is supposed to come ashore just to the East of Mobile Bay at 0700 tomorrow.  I don't anticipate any staff coming in because of the hazardous conditions during that time-- plus the flooding and storm surge.  I will be in contact with you tomorrow if anything changes.

V/R,

Jeff B

**Tony Puckett**: Understand.  Be safe and let me hear from you tomorrow 🙏 

**Jeff Bergosh**: Will do Tony

### CONVERSATION ON 09-16-2020

**Jeff Bergosh**: We took a beating last night!

**Tony Puckett**: Looks like it. 

**Tony Puckett**: Glad you are safe.

**Jeff Bergosh**: Thx me too.  I texted the team this morning.  

**Jeff Bergosh**: I've not heard anything about NASP other than they took a hard hit as well.  My house is okay but I have three big trees down and LOTS of cleanup ahead.  I group texted everyone from the office this morning.  Authorities have ordered a shelter in place, all major bridges are out and there are  lots of road closures-- so not sure what ability to work looks like yet for tomorrow... I'll keep you posted.

**Tony Puckett**: Thanks.

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Can you talk?

### CONVERSATION ON 09-18-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-19-2020

**Jeff Bergosh**: Hey Tony hope your Saturday is going well. just wanted to give you heads up:  Tim Daniel is being called in on an emergency water leak situation so he just called me he's on his way down to the base right now.  I'll keep you posted on what happens

**Tony Puckett**: Thanks Jeff. Hope things are going better for you and your family. 

**Jeff Bergosh**: They are-- got three trees cut up and moved to the street.  One more big oak to go tomorrow 

### CONVERSATION ON 09-21-2020

**Jeff Bergosh**: Good morning Tony this is Jeff down in Pensacola we're about to start our staff meeting just call when you have a minute and will put you on speaker thanks

**Tony Puckett**: Jeff, don't wait on me  as I am stuck on another conference call.  I'll check in with you later.

**Jeff Bergosh**: Okay will do thanks Tony

**Jeff Bergosh**: I'll send you more detailed information in an email from my Gmail account because I cannot send one from PBSS or NMCI as both those networks remain in operable

**Tony Puckett**: Sounds good 👍.  Thanks. 

**Jeff Bergosh**: Tony--the Navfac structural engineers just walked through the building and assessed it. They looked at the cracks in the concrete on the second deck from the second deck and then from the first deck they went up on ladders and moved the ceiling tiles and inspected the joists and the pan.  We are all good --no major structural damage no issues with that.  We can fully occupy the building with no safety hazards present.--so I thought that was some good news that I wanted to pass along to you right away.

Jeff B

**Tony Puckett**: I needed a little good news.  Thanks 😊 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: FYI Tony this is what they posted on our facility indicating that we are good to go for occupancy

**Tony Puckett**: That is CYA for us.

### CONVERSATION ON 10-01-2020

**Jeff Bergosh**: Good Morning Tony.  Just wanted to let you know Tim and Heather were involved in a minor traffic accident on the way to work this morning.  They are okay but the car needs to be towed.  I'm forwarding you the picture and the email string between Heather and I so you'll be up to speed.  I anticipate they'll be in this afternoon after they get a rental car.

**Tony Puckett**: Bummer.  Glad everyone was ok.

**Jeff Bergosh**: Me too

**Jeff Bergosh**: Tony-- I got a call from Tim-- they got their car towed to the repair shop and they have now got a rental car but they probably will not make it back to work today. Tim Said they both want to go home --not feeling great. So I believe they will be in first thing tomorrow morning.  Tim has nothing due today so I will send you the sit rep and reports first thing in the morning when Heather gets in if that's OK with you.  Just wanted you to know the latest.

**Tony Puckett**: Thanks Jeff.

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-03-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Thanks Tony--- nothing big, just an update.  Thanks.

### CONVERSATION ON 12-11-2020

**Jeff Bergosh**: Good morning Tony.  I BCC'd you on an email I sent to Tim about a near miss of an electrical line on one of his issued dig permits on Corry Station.  I've spoken to Gerald Flint and it is NOT being written up as a near miss as I'm now told it was not an energized line and also it appears that this line in question was abandoned in place.  Nevertheless--I'm still going to request Tim give me a short narrative on this upon his return to the office next week; even though it was an abandoned, unenergized line-- Tim didn't know that when the permit was issued so this is a good time for us to take a step back and determine if there was anything we should have done differently that would have led to us identifying and marking that line.  It is a process improvement and learning opportunity.

**Tony Puckett**: Good job. Yes, I think addressing this with him would be wise.

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-16-2020

**Jeff Bergosh**: Tony-  FYI this is the text exchange I just had with Warren.  He did go get a COVID-19 test after all.....

**Tony Puckett**: Ok. I hope 🙏 he doesn't have it.

**Jeff Bergosh**: Me too!

**Jeff Bergosh**: .... that he got tested

**Tony Puckett**: Couldn't hurt.

**Jeff Bergosh**: Okay will do.  I'll Bcc you.  Thanks Tony!

### CONVERSATION ON 12-17-2020

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Okay thx Tony.  Just a quick question 

### CONVERSATION ON 12-18-2020

**Jeff Bergosh**: Tony-- I just heard from Warren.  No test results yet and he's feeling better-- just a little stomach discomfort lingering.  I'll let you know if I hear anything else from him later in the day.

V/R,

Jeff

**Tony Puckett**: Thanks Jeff.

**Jeff Bergosh**: 👍

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Thanks Tony Good news to pass on Warren

**Tony Puckett**: Negative?

**Jeff Bergosh**: Yes!  Negative.

**Jeff Bergosh**: Great news right!!

**Tony Puckett**: Awesome. 

**Jeff Bergosh**: He'll be back in Monday and he will bring his negative test result and give it to Jaron

**Jeff Bergosh**: Can I inform PBSS?

**Tony Puckett**: Perfect. I am on a conference call.  

**Tony Puckett**: Yes, please do.

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-07-2021

**Jeff Bergosh**: Hi Tony I just emailed you a purchase order form that PBSS wants us to sign to do a modification to a customer funded estimate.  You had previously given this price to Drew Linger.  Do you want me to sign it and send it back to them or do you want to sign it?  Just let me know so we can initiate the work order.   Thanks!

V/R,

Jeff B

**Tony Puckett**: Jeff, just responded to you via email to please sign. Just make sure I get a fully executed copy back for invoi in once complete.  Thanks. 

**Jeff Bergosh**: Will do Tony!  Get well soon!

**Tony Puckett**: Thanks Jeff.

### CONVERSATION ON 02-04-2021

**Tony Puckett**: I'll call you back.

### CONVERSATION ON 03-10-2021

**Jeff Bergosh**: Good morning Tony-  do you have a moment for a quick call?  It's about Tim Daniel.  I have forwarded you two doctor's notes he gave me today regarding a hip injury (non work related) he apparently sustained over the weekend.  Looks like it will necessitate he be on light duty for at least a week.  I'm going to make Dave Midgorden the "on call" CET and work with Dave and Tim--and Ira to manage the workload this week and first part of next week

### CONVERSATION ON 03-17-2021

**Jeff Bergosh**: Hi Tony-- just letting you know PBSS internet and phones have been down all day today.  If you have emailed me or anyone down here we are not getting them today.   Hopefully they will be up before COB or else I won't be able to send you the reports

**Tony Puckett**: Gotcha. Thanks for letting me know. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: FYI Tony-- our internet just got restored here in Bldg. 458.

**Tony Puckett**: Great 

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: Good afternoon Tony.  I just had a meeting with Mark Powell about our renewal estimating software from RS means.  He's giving some significant pushback on it as the price for what we have used for the past several years has gone up about a Thousand Dollars to just under $18K for three licenses for a year.  I'd like to discuss this with you if you have a moment to talk?

Thanks very much.

V/R

Jeff B

**Jeff Bergosh**: He's looking for ways to save-- but not sure if we can manage without COSTWORKS estimating program

**Tony Puckett**: I'm in New Mexico,  but I will call you in a little while. 

**Jeff Bergosh**: Ok thx Tony

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: Hey Tony I had a good conversation with two technical representatives from Gordian group about the COSTWORKS software we use and what we need. It looks as though one of those additional add-ons was duplicative and so we are requesting they submit their bottom line best price minus the duplicative program which should shave $2000 off the cost --and I feel like I have a much better understanding of the need for our planners to have this program. I'd like to discuss it with you at some point with when you can call me at your convenience before I go and talk to Mark about it. Thank you Tony.

V/R,

Jeff

### CONVERSATION ON 04-06-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Tony-- I drove to the site, and personally called the contractor for the extension which he granted.  We are all going to meet out at the job site Friday morning at 1000 so the situation has been resolved for now.  Just a really, really sketchy request which I wasn't comfortable going forward with so we reeled it in for a couple more days......I'll keep you posted on it 

Thanks.

V/R,

Jeff

### CONVERSATION ON 04-07-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-14-2021

**Jeff Bergosh**: We got our COSTWORKS software today!!

**Tony Puckett**: Awesome. 

### CONVERSATION ON 04-21-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍. Thx.  Have some information to pass based upon our conversation yesterday afternoon when you have a moment

### CONVERSATION ON 05-07-2021

**Jeff Bergosh**: Hi Tony I just tried to leave you a message just to let you know Jaron is still working on his program presentation --however what he just gave me as a revised version is not up to snuff. There was not enough new data added and I am redirecting him to add additional data before we speak with you. His counterpart at PBSS is on leave until Monday of next week so it may be prudent to give you the latest revision mid week next week.  Please let me know if this works in your schedule for us to provide an update on Wednesday.

**Tony Puckett**: Sounds good.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-18-2021

**Tony Puckett**: Solicitation is out and proposals are due 29 June.

**Jeff Bergosh**: Wow!

**Jeff Bergosh**: Ira was right

**Tony Puckett**: Yes sir.

**Jeff Bergosh**: I'll keep my ear to the ground if I hear anything else I'll let you know meanwhile if you need anything from me just let me know and I'll do whatever we need to do

**Tony Puckett**: Perfect.  Thanks. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-19-2021

**Jeff Bergosh**: V/R,  Jeff B

**Tony Puckett**: Great. Thanks. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-25-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-27-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-28-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-10-2021

**Jeff Bergosh**: Hello Tony-- hope the drive back to Huntsville has been okay.  I wanted to follow up with you on Bldg 3460.  INFADS was up today so I logged in and looked up the Bldg 3460 info.  It is 774,092 SF.  I am also doing a facilities csv download from which I'll be able to work up the most recent total facilities information (number of type II facilities, total prv, and total sf)

V/R,

Jeff

**Tony Puckett**: Thanks Jeff. I would like for you to participate in a conference call with Vectrus on Monday at 11:00 cst if you can work it in to your schedule.  I will let you know the call in number Monday morning.  Thanks.

**Jeff Bergosh**: Got it.  It's on the calendar and I'll just be looking for the call in credentials.  Also, just let me know what I can do to assist in the way of preparation for the call, etc.  thanks Tony!

### CONVERSATION ON 06-14-2021

**Jeff Bergosh**: Thanks for having me on

**Tony Puckett**: Absolutely,  I want you to be a part of this. 

**Jeff Bergosh**: Thank you!

### CONVERSATION ON 06-15-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: A gentleman from Skookum Government Services called, he was on the bus tour last week.  He's going to bid the contract and he's interested in discussing potential partnering with eLe.  

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: Tony--- this, below,  came to me just now from PBSS's Nels Palm. Does this apply to us as well? Do I need to pass the word on this to the staff?

"All
Tomorrow will be considered a federal holiday for pbss.  Please pass the word to your people and to anyone that I have omitted.   If you have things that cannot wait, take care of it and then leave.  
Mark"

**Tony Puckett**: If they say holiday then it will be a holiday. Can you contact everyone?

**Jeff Bergosh**: Yes I will

**Jeff Bergosh**: Thanks very much Tony!

**Tony Puckett**: Thanks, having to notify a lot of employees,  don't know why they waited so late.

**Jeff Bergosh**: I'm not sure--it might be because the law just passed?  Anyway I'm sure it will be welcome news to the staff🙂👍

**Tony Puckett**: You can do time stuff Monday,  don't worry about the time I probably owe you anyway.  

**Jeff Bergosh**: Thank you Tony!  Greatly appreciate that!!

**Tony Puckett**: Enjoy!

**Jeff Bergosh**: Will do thank you Tony!

### CONVERSATION ON 06-23-2021

**Jeff Bergosh**: Just sent the SITREP-- but the IAP network is down.  It's in the outbox so it should go out in a bit.  Have a great afternoon Tony!

V/R,

Jeff

**Tony Puckett**: Sounds good. Thanks Jeff.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-25-2021

**Jeff Bergosh**: I'm going to call Rodolfo and give him that number so we can plug it in for those utility drawing spec items if you think that's a good idea. I'll go ahead and do it unless you tell me otherwise. Also feel free to call me this weekend if you need anything or any of these questions answered I'll be available I hope you have a good weekend!

**Tony Puckett**: Sorry,  been on phone so much today it died and didn't have a charger with me. Had to wait until I got home. Thanks for everything. 

**Jeff Bergosh**: No problem At all Tony.  Have a great weekend!

### CONVERSATION ON 06-28-2021

**Jeff Bergosh**: Good Morning Tony.  I'll be on the call today with  just wanted to let you know it's 2:30 our time not 3:30 ---just in case you and Rodolfo thought it was 3:30.

**Tony Puckett**: Got it, it will be 1:30 my time.

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-29-2021

**Tony Puckett**: Can you get on now.

**Jeff Bergosh**: Yes 

### CONVERSATION ON 07-07-2021

**Jeff Bergosh**: Trying to get into this call--what is the meeting I'd # please?

**Tony Puckett**: 2565367117126#

**Jeff Bergosh**: Tony do you want me to include the costs of the uniforms per year along with the water service on this spreadsheet?

**Tony Puckett**: Yes

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-14-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Right on thanks Tony.

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Tony Good News FYI.  The new battery worked for the GPR so we are back in business working on the big excavation permit Jobs.

**Tony Puckett**: Awesome 👌. 

### CONVERSATION ON 07-26-2021

**Jeff Bergosh**: Tony-- just a heads up our computers are down.  I talked to Nels at PBSS and it's a nationwide outage with our provider mediacom

**Tony Puckett**: Okie Dokie 

### CONVERSATION ON 07-28-2021

**Jeff Bergosh**: Tony I'm at the Navy League Luncheon honoring The NAS Captain.  Can I call you back, or do I need to step out?

**Tony Puckett**: I can wait.

**Jeff Bergosh**: Tony I just sent you the draft org chart.  You should have it in your inbox

V/R

Jeff

**Tony Puckett**: 👍

### CONVERSATION ON 08-10-2021

**Jeff Bergosh**: If you have a moment I'd like to discuss this with you, so we can make appropriate notifications etc.

Thanks Tony,

Jeff

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: Ok thx Tony

### CONVERSATION ON 08-11-2021

**Jeff Bergosh**: Hey Tony I just missed your call just tried to call you back

**Tony Puckett**: On a call, just wanted to check on Jaron.

**Jeff Bergosh**: Haven't heard from him yet today but I'll get an update from him, and put it in the Sitrep 

**Tony Puckett**: No worries,  just want to make sure he is doing ok.

**Jeff Bergosh**: I just texted him to check-- didn't want to call in case he's sleeping

**Tony Puckett**: Perfect. Thanks. 

**Jeff Bergosh**: 👍 and I'll let you know how he responds 

**Tony Puckett**: Okie Dokie 

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: Good morning Tony-- I had to take a quick drive off base to handle a emergent issue related to social media and my county commissioner role.  I'm back now and I'll account for this with .5 hrs PTO on my timesheet.  The reason I didn't have it on my out of office spreadsheet was it was unexpected and came at me out of the blue.  Thanks Tony.

V/R

Jeff B

**Tony Puckett**: No worries, hope you got it worked out.

**Jeff Bergosh**: Thanks Tony.  Yes sir, I put the fire out real quick🔥👍

**Tony Puckett**: Awesome. 

### CONVERSATION ON 08-17-2021

**Jeff Bergosh**: Tony-- I just got this text from Jaron.  He's doing much better!

V/R

Jeff

**Tony Puckett**: Thanks for the update. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-06-2021

**Jeff Bergosh**: Good Afternoon Tony--

I hope you're having a great Labor Day.  I wanted to make you aware that Tim got called in for an emergency locate as there was a water main break at Corry Station.  I'm waiting to hear the outcome.  I'll give you a full report in tomorrow's SITREP 

V/R

Jeff

**Tony Puckett**: Sounds good.  Thanks.

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-06-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

**Tony Puckett**: I'm tied up on a call. I know you have things squared away down there, have a safe trip and enjoy!

**Jeff Bergosh**: Thanks Tony!  Will do and we will talk next week.

**Tony Puckett**: 👍

### CONVERSATION ON 10-21-2021

**Tony Puckett**: I'll call you back.

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: Tony-- I just spoke to Gerald Flint at PBSS about the whole IAP/PBSS implementation of the vaccine mandate. He does not have any guidelines yet for issues such as medical exemptions or religious exemptions. He did tell me that he has spoken to corporate and that they intend to push out these guidelines this week. When I get them I will forward them to you as well and I assume we will be following their guidelines? The reason I'm letting you know this is because both Jaron and Tim have been asking and they're concerned about the timeline.  Neither of them are vaccinated.

Hope you're feeling better!

V/R,

Jeff

**Tony Puckett**: Thanks for the update.  We will see what they come up with and then make our decision. Are those two not going to be vaccinated?

**Jeff Bergosh**: That's the sense I get. Particularly Jaron since he's already had the virus and he's young and healthy. Tim on the other hand has shared with me that it's a medical reason why he can't get it because his blood is too thick that's what he says

**Jeff Bergosh**: My sincere hope is that they at least allow for a testing regimen for those who have legitimate reasons or objections to taking the vaccine. I'm not hopeful that they will though

**Tony Puckett**: They may be able to ask for an exemption,  but they will then have to mask up, social distance and be scrutinized by co-workers. 

**Jeff Bergosh**: Yep

**Jeff Bergosh**: Hopefully we will get the latitude to do that

**Tony Puckett**: We'll see. 

### CONVERSATION ON 11-19-2021

**Jeff Bergosh**: Good Afternoon Tony--

I'm trying to get into the online timekeeping system to approve the last three timesheets but t looks like that site is down.  I have a call in to Joseph Ballew as well-- just letting you know why these last three aren't approved/submitted yet.

V/R,

Jeff

**Tony Puckett**: Ok. Thanks 

**Jeff Bergosh**: Just got it resolved

**Tony Puckett**: Thanks Jeff

**Jeff Bergosh**: Absolutely Tony-- have a great weekend!

**Tony Puckett**: You too.

### CONVERSATION ON 11-23-2021

**Jeff Bergosh**: Tony-- have something to run by you I picked up on my call with FMD today.  No rush and no problem or issue for us or about us---but when you have a minute I want to let you know what they slipped and said to me about next year.....intriguing 

V/R,

Jeff

### CONVERSATION ON 01-28-2022

**Jeff Bergosh**: Tony-- Just a heads up I just got a call from Ira.  He tested positive for COVID today so now he will be quarantining an additional 10 days from today.  I'm calling PBSS safety right now but wanted you to know first.

V/R,

Jeff

**Tony Puckett**: Thanks Jeff. Is he very sick?

**Jeff Bergosh**: No symptoms today but he was ill yesterday.  I just got off the phone with Gerald Flint at PBSS safety and he just told me the quarantine is 5 days no test needed to return.  So I'm calling Ira back to let him know.  Wednesday he should be back in the office

**Tony Puckett**: Great. 

