

## CONVERSATIONS WITH NATHAN BOYLES

### CONVERSATION ON 04-26-2020

**Jeff Bergosh**: Hey good morning Nathan this is Jeff Bergosh--Escambia County Commissioner.  Just wondering if you would be willing to join me on Wednesday for my coffee with the commissioner event? if you're available I can send you the invite credentials.  I do the event from 6:30 AM until 7:30 AM Wednesday Mornings and I live stream it on Facebook so that I can take constituent questions and comments simultaneously.  I’ve been doing this for a while now and it gets great participation and I’ve had the CEOs of all the major hospitals on over the past several months.  Matt Gaetz is going to join me —but he cannot do it until 9 AM so I’m going to try and get you and Sam Parker from Santa Rosa County  on my coffee livestream to talk about regional issues with reopening the economy, federal versus state guidance, etc. .  If you’re available I’ll send you the login credentials—- hope you can join me!

**Jeff Bergosh**: Fantastic.  I’ll send over the meeting log in credentials.  Thanks and I look forward to it!

### CONVERSATION ON 04-27-2020

**Jeff Bergosh**: Hello Nathan— to what email address should I send the meeting log-in credentials for Wednesday morning’s virtual coffee meeting online?

Thanks, 

Jeff BERGOSH

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Good afternoon Nathan- I sent you a Microsoft teams invite for tomorrow morning’s virtual coffee with a commissioner meeting at 0630.  If you can join in a couple of minutes early that would be great.  Looking forward to hearing your thoughts on the next phases of recovery for our region.  I’m also attaching the call in number here as well.  

Thanks!

Jeff Bergosh

**Jeff Bergosh**: Typically 45 minutes

**Jeff Bergosh**: Turns out better that way

**Jeff Bergosh**: Cool— I look forward to the discussion!!  Thanks for agreeing to it!

### CONVERSATION ON 04-29-2020

**Jeff Bergosh**: Nathan—thanks very much for participating in our coffee this morning—I greatly appreciate it!

