

## CONVERSATIONS WITH CHRISTIE WEAR CH 3

### CONVERSATION ON 05-13-2020

**Christie WEAR Ch 3**: Good finally meeting you today. Call me if you need anything.

Tanner Stewart

**Jeff Bergosh**: Thanks Tanner- will do!

### CONVERSATION ON 07-24-2020

**Christie WEAR Ch 3**: Hey Commissioner, was hoping to get a statement from you today on a possible mask mandate in the county?

**Jeff Bergosh**: My apologies—I’m dealing with an issue at work out in the field and won’t be available 

**Christie WEAR Ch 3**: No worries

**Jeff Bergosh**: I sent Randy the following:  


"In light of the uptick in fatalities and incredible increases in the number of hospitalizations in Escambia County--I am certainly willing to look at what Councilwoman Canada-Wynn sent over and also what other nearby jurisdictions are implementing.  I remain committed to working with my counterparts on the board to follow the science and expert advice in order to chart the best course of action to protect the health of community members going forward.  I expect a robust discussion on this topic at our next meeting"

**Christie WEAR Ch 3**: Awesome thank you

### CONVERSATION ON 10-07-2020

**Jeff Bergosh**: Tanner— what time are we meeting at Burger Factory?

**Christie WEAR Ch 3**: We are heading there now if you’re ready?

**Jeff Bergosh**: Yep— on way

### CONVERSATION ON 03-04-2021

**Christie WEAR Ch 3**: Are you available to speak this morning on the brown outs?

**Jeff Bergosh**: Sure, after our meeting

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: That dog was STRONG!

**Christie WEAR Ch 3**: Hey Commissioner it’s Tanner Stewart at Ch.3.. I’m working on a follow-up to a story Friday on a death inside the jail. Are you free for an interview ?

**Jeff Bergosh**: Sure.  I’m headed to the Sheriff’s Office luncheon at 11:00.  Do you want to meet me there at a quarter till 11?

**Christie WEAR Ch 3**: I’m waiting on my photographer to get back, may not have enough time then. Are you free this afternoon?

**Christie WEAR Ch 3**: We will be there at 11. Sorry for the confusion 

**Jeff Bergosh**: Event starts at 11

**Jeff Bergosh**: Text when u arrive

**Christie WEAR Ch 3**: We’re pulling up 

**Jeff Bergosh**: Okay I’m here at the entrance

