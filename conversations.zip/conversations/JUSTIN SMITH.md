

## CONVERSATIONS WITH JUSTIN SMITH

### CONVERSATION ON 05-06-2020

**Justin Smith**: Hey man it’s Justin from The Dock, I didn’t forget ya but we got our asses kicked yesterday we were busy

**Jeff Bergosh**: No worries— thanks Justin!

**Justin Smith**: Maybe I can get a few signs in a day or so and I’ll collect the donations too

**Justin Smith**: I’ll handle Bellview community 

**Jeff Bergosh**: Thanks sounds great.  Just let me know when you have time and I’ll bri g them to you.  Appreciate the support!

**Justin Smith**: 💪

**Justin Smith**: Do you have a site people can donate on or must be a check 

**Jeff Bergosh**: I do.  www.jeffbergosh.com. Green button “make an online donation” on right side

**Jeff Bergosh**: Thanks Justin!

**Justin Smith**: Got it!

### CONVERSATION ON 05-10-2020

**Justin Smith**: Put a big sign here it’s a great location off blue angel and Casey asked my uncle for this spot and we politely told him no

**Justin Smith**: 6570 blue angel

**Jeff Bergosh**: I will Justin thanks very much

**Justin Smith**: I need 13 yard signs too and I’ll get some donations as well

**Justin Smith**: My address is 6132 Suntan circle 

**Justin Smith**: Your a straight up guy and you cut to the chase unlike others Lol

**Jeff Bergosh**: Thanks Justin!

**Jeff Bergosh**: I planted that sign on blue Angel and I just dropped off the yard signs on your front porch thanks so very much for your help and your support I greatly appreciate it Justin!

**Justin Smith**: Yes sir! 

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Good afternoon Justin—-as a person that has helped me in my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Justin— thanks for your help and support!

**Justin Smith**: Loved “Good afternoon Justin—-as a person that has helped me in my campaign and supports my candidacy—I wanted to let you know that I just got my latest poll results back from Gravis.  

I’m ahead of Jesse Casey in my race by 16 points, and I’m crushing Doug Underhill’s Secretary —-John Owens —-by 30 points!  Thought you might like to know that.

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Justin— thanks for your help and support!”

**Justin Smith**: I have and will continue to push for you in my community bro 

**Justin Smith**: Your a good man

**Jeff Bergosh**: 👍thank you Justin!

**Justin Smith**: My daughter Delaney our helping 

**Jeff Bergosh**: Awesome!! That’s great!

### CONVERSATION ON 05-15-2020

**Justin Smith**: Mom just assures me she would take care of Springfield and the Floridian subdivision.  I will get a couple good sign locations today

**Justin Smith**: *assured 

**Jeff Bergosh**: Thank you Justin!

**Justin Smith**: 💪

### CONVERSATION ON 05-17-2020

**Jeff Bergosh**: Hey Justin, I’m dropping off the magnets, I’ll leave them on your front porch.  Thank you for the help!!

**Jeff Bergosh**: Wouldn’t want to get on his bad side!

### CONVERSATION ON 05-18-2020

**Justin Smith**: I was beat yesterday! I fell asleep at 7:13 lol

**Justin Smith**: I’ll have those sign addresses today

**Jeff Bergosh**: Thank you Justin!!

**Jeff Bergosh**: Nice!!

**Jeff Bergosh**: Nice!  Thank you!

### CONVERSATION ON 06-01-2020

**Justin Smith**: Complete trash 

**Jeff Bergosh**: I like the sheriff’s perspective

**Justin Smith**: Absolutely 

**Justin Smith**: These thugs are gonna start some shit in cantonment 

**Justin Smith**: It’s all over Facebook 

### CONVERSATION ON 06-06-2020

**Jeff Bergosh**: Signs up at Baughn’s Thanks for the great location Justin

**Justin Smith**: 💪💪

### CONVERSATION ON 07-08-2020

**Jeff Bergosh**: In mtg will call u back

**Justin Smith**: PBA meeting? 

**Justin Smith**: They are texting me from there now asking questions but keep that to yourself 

**Jeff Bergosh**: Okay thx.  Headed that way for an appointment

**Jeff Bergosh**: Hope they don’t endorse Underhikl’s Secretary

**Justin Smith**: DONT repeat this 

**Justin Smith**: I’m fixing it now 

**Jeff Bergosh**: Thx!!

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: Yes!!

**Jeff Bergosh**: I’ll wait for the official call— greatly appreciate your help Justin thank you so much!!!

**Justin Smith**: I told ya I’d fix it lol 

**Justin Smith**: Yes sir

**Jeff Bergosh**: You did!!  Thanks!!

**Jeff Bergosh**: I really think this will help with the relationship going forward I really believe that

**Justin Smith**: Absolutely 

**Justin Smith**: (850) 776-1897 Cory smith he’s a k9 as well he intercepted that package of 12 kilos cocaine

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-18-2020

**Justin Smith**: 💪💪💪💪💪. I’ll always support your brother if anyone ever tried to run against him 


**Jeff Bergosh**: Thanks Justin!  He will always do the right thing!

**Justin Smith**: Lots of people are talking about it too 💪💪

**Jeff Bergosh**: 👍👍👍

**Justin Smith**: If anyone tries to run against him in the future count me and my family in! 

**Jeff Bergosh**: Thank you!!!

**Justin Smith**: Let him know if it doesn’t put anyone in a vicarious position, I’ve been 100% with you and I’ll do the same for your brother, Jeremy Jarman (marshals task force agent) talks HIGHLY of him 

**Jeff Bergosh**: I will thank you for the support Justin

### CONVERSATION ON 07-26-2020

**Jeff Bergosh**: Hey Justin— great talking to you today.  I’m organizing sign waving events on two Saturdays in August ahead of my election.  If you know any folks that could help If greatly appreciate it! 

Next SaturdayAugust 1st-

11:00AM-2:00PM. Pensacola Interstate Fairgrounds

Saturday August 15th

11:00-2:00PM  KFC. At Mobile Hwy And Michigan Ave

Thanks for all your help Justin!!

Jeff B

**Justin Smith**: 💪

### CONVERSATION ON 07-31-2020

**Justin Smith**: Keep that to yourself 

**Justin Smith**: That’s what Alexander sent PBA

**Jeff Bergosh**: Wow Justin.  That sounds like sour grapes to me!  

**Jeff Bergosh**: .....like the rest of us do!

**Justin Smith**: He’s using the race card 

**Justin Smith**: Pathetic 

**Jeff Bergosh**: That is pathetic

**Jeff Bergosh**: He knows I’ll own him in a live debate.  Very weak— yet folks still worship him

**Justin Smith**: 😂😂😂

### CONVERSATION ON 08-18-2020

**Justin Smith**: We win? 

**Jeff Bergosh**: Will know at 7:15

**Justin Smith**: Fuck 

**Justin Smith**: Fuck 

**Justin Smith**: Lmk 

**Justin Smith**: Lmk 

**Justin Smith**: Lmk 

### CONVERSATION ON 09-03-2020

**Justin Smith**: I removed 27 signs 

**Justin Smith**: I discarded them at the bar in our dumpsters in case you get a call 

**Jeff Bergosh**: Thank you so much Justin!!! Greatly appreciate that!!!

**Justin Smith**: Yes sir! 

**Jeff Bergosh**: Were these the big signs, the wood ones?

### CONVERSATION ON 11-17-2020

**Jeff Bergosh**: He’s smoking crystal

**Justin Smith**: 😂😂

### CONVERSATION ON 11-26-2020

**Justin Smith**: Happy Thanksgiving bro

**Jeff Bergosh**: Same to you Justin!

### CONVERSATION ON 02-04-2021

**Jeff Bergosh**: In a meeting I'll call I back

### CONVERSATION ON 02-09-2021

**Justin Smith**: Fuck him 

**Jeff Bergosh**: He’s a POS

**Justin Smith**: Find out who we need to support fuck that bitch 

**Jeff Bergosh**: Working it as we speak

**Justin Smith**: 💪

### CONVERSATION ON 02-11-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

### CONVERSATION ON 03-01-2021

**Justin Smith**: Sgt Newton the PBA president wrecked his ass 😂

**Jeff Bergosh**: Wow!

### CONVERSATION ON 03-04-2021

**Jeff Bergosh**: In bcc mtg will call u back

**Justin Smith**: Tell them I’m ready to physically fight Skanska Lol

**Jeff Bergosh**: You’ll have to get in line

### CONVERSATION ON 03-05-2021

**Justin Smith**: PLEASE slam those mf’s with Skanska

**Jeff Bergosh**: We hired three of our area’s top law firms just last night to do just that Justin!!

**Justin Smith**: 💪💪

### CONVERSATION ON 03-08-2021

**Jeff Bergosh**: In math will call u back

**Justin Smith**: https://fb.watch/46l_muj84L/

**Justin Smith**: Watch that

### CONVERSATION ON 04-07-2021

**Justin Smith**: Between you and I Is he good? 

**Jeff Bergosh**: Steve’s a nice guy

### CONVERSATION ON 05-05-2021

**Justin Smith**: This is just outside of Sunset Estates on saufly field 

**Justin Smith**: There’s 3 different hole 

**Justin Smith**: Holes 

**Jeff Bergosh**: Got it.  Sending to staff, thanks for bringing them to my attention

**Justin Smith**: 💪

### CONVERSATION ON 07-13-2021

**Jeff Bergosh**: Hey Justin-  I just spoke to Kevin Adams about your daughter. He will speak to the superintendent to see if he can get her switched. He just asked that you send him an email with your daughters name and indicating the teacher that she wants. And he’ll go to work to try to make it happen for you. His email address is: kadams2@ecsdfl.us

**Justin Smith**: I appreciate you man 

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-18-2021

**Justin Smith**: https://www.pnj.com/story/news/local/escambia-county/2021/08/18/escambia-county-sheriff-david-morgan-order-lifesize-bronze-statue-himself-75-000-taxpayer-money/8182851002/

**Justin Smith**: He’s livid 

**Jeff Bergosh**: Crazy shit!!

**Justin Smith**: Chip is one mad mf

### CONVERSATION ON 11-18-2021

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Where’d that come from???

**Justin Smith**: Some guy made them for a joke  and cops are buying them 😂

**Jeff Bergosh**: LOL

**Jeff Bergosh**: 😂😂😂

**Justin Smith**: 😂😂😂

**Jeff Bergosh**: Did they melt the statue down to make these?

**Justin Smith**: No 😂😂😂 

### CONVERSATION ON 11-19-2021

**Justin Smith**: 😂😂😂

**Jeff Bergosh**: That’s a great meme!!

**Jeff Bergosh**: Hey, where can I buy 3 of those Morgan coins??

**Justin Smith**: I’ll grab you 5

**Justin Smith**: They only made 100

**Jeff Bergosh**: That’s be awesome!! 

**Jeff Bergosh**: Please

**Justin Smith**: Consider it done! 

**Jeff Bergosh**: Thanks Justin!

**Justin Smith**: K9 handlers and patrol captain had it done 

**Justin Smith**: I didn’t tell u that lol

**Justin Smith**: Chip said it was hilarious af 😂

**Jeff Bergosh**: I’ll keep it hush hush 

**Jeff Bergosh**: It is!!

### CONVERSATION ON 12-07-2021

**Justin Smith**: Lots of cops and C.O’s are extremely happy with you defending them. 💪 especially over at the jail and the k9 handlers 

**Jeff Bergosh**: Thanks Justin!  Sick and tired of bullshit blame they get when folks show up massively medically compromised already 

**Justin Smith**: I agree! 

### CONVERSATION ON 12-08-2021

**Justin Smith**: Tell Grover to move all those transients under the bridge In his back yard 😂

**Jeff Bergosh**: LOL right??  Or bay view park or East hill!!

**Justin Smith**: 😂😂😂

**Jeff Bergosh**: Any status update on getting one of those Morgan coins Justin?

**Justin Smith**: I’ll have them Friday afternoon

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-27-2021

**Justin Smith**: Need to talk to ya in confidence 

**Jeff Bergosh**: Okay I’ll give u a call today when I get a minute away from family.  Hope you had a merry Christmas Justin!

### CONVERSATION ON 12-30-2021

**Justin Smith**: 6311 ARD Rd

**Jeff Bergosh**: Got it.  I’ll get it to code enforcement

### CONVERSATION ON 01-03-2022

**Justin Smith**: Don’t forget to make that call, I know they’ll appreciate it a lot 

**Jeff Bergosh**: 10-4. Already in the works

**Justin Smith**: 💪

### CONVERSATION ON 01-14-2022

**Jeff Bergosh**: Awesome.  Can’t wait to get a couple!!

**Jeff Bergosh**: They sent all 28 prisoners back to us

**Justin Smith**: Told ya! 

### CONVERSATION ON 01-17-2022

**Jeff Bergosh**: Good morning Justin!  When and where should I meet up with you today to grab a couple of those Morgan coins?

**Jeff Bergosh**: You back on the mainland Justin?

**Justin Smith**: Professional Automotive 

**Justin Smith**: 4401 West Jackson st

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-25-2022

**Jeff Bergosh**: In a meeting will call u back

**Justin Smith**: Scott Haines arrested 

**Jeff Bergosh**: Wow on what charge??

**Justin Smith**: Wire fraud and taking advantage of elderly 

**Justin Smith**: Federal indictment 

### CONVERSATION ON 01-29-2022

**Justin Smith**: When you can call me 

### CONVERSATION ON 02-01-2022

**Justin Smith**: Got info for you call me 

