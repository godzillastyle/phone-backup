

## CONVERSATIONS WITH HANNAH WEAR CH 3

### CONVERSATION ON 11-02-2021

**Jeff Bergosh**: Perfect— see u then

