

## CONVERSATIONS WITH BILLY ANDERSON

### CONVERSATION ON 10-19-2021

**Jeff Bergosh**: Sounds great thanks very much!

### CONVERSATION ON 11-02-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

**Jeff Bergosh**: Hey Billy—I know you’ve been out of town but I was wanting to touch base with you about the Health and Hope Clinic fundraiser to see if you will be able to get behind it.  It’s coming up in a little less than 30 days but pledge commitments are due (for the printing of programs) by Nov. 5th— this Friday.  Anything you can do would be greatly appreciated.  I’ll text you a sponsorship form in case you would like to be a sponsor.Just let me know and thanks!  I hope all is well-  have a great week!

Jeff Bergosh

**Jeff Bergosh**: Right on thank you Billy!  Have a safe trip.

