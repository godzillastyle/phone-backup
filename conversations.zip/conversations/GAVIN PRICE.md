

## CONVERSATIONS WITH GAVIN PRICE

### CONVERSATION ON 12-17-2019

**Gavin Price**: Call me when you have a moment 

**Jeff Bergosh**: Will do

### CONVERSATION ON 03-04-2020

**Jeff Bergosh**: Gavin:  I am adding an item to tomorrow’s agenda for the Beulah Volunteer Fire Department, station 2, to receive 8 new twin mattresses and a new commercial washer/extractor.  NTE $10,000.00. From District 1 Discretionary funding.  Please let the guys at the station know this.  Also—it is my understanding that the real estate purchase/closing for the property will happen tomorrow.  It took a while, but it looks like we are at the finish line. Thanks for all your continued efforts to make that happen!

**Gavin Price**: Thanks you for your help Jeff. Will let you know when signing is complete 

**Jeff Bergosh**: 👍

**Gavin Price**: Hope this font cause you a heartache with county fire about these items. You know they are gonna accuse you of stepping on there toes

**Jeff Bergosh**: I don’t give a damn what those guys think.  They want volunteers gone, I will fight against that as long as I’m here!  And you all deserve better treatment and gear, so this is the start of that!

**Gavin Price**: Thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-05-2020

**Gavin Price**: Paper work has been signed and is complete 
 Thanks for all your help
    Gavin

**Jeff Bergosh**: That’s fantastic Gavin!  Congratulations.  Now it is on to part II

**Jeff Bergosh**: .......getting you all the proper facility modernizations that you need and deserve.    It’s coming

**Gavin Price**: Thank you my Friend. 
 We need to have a drink after all this!

**Jeff Bergosh**: Absolutely!

### CONVERSATION ON 03-06-2020

**Gavin Price**: My new name is McGuiver. 😂😂😂😂😂😂😂😂

**Jeff Bergosh**: You like???   LOL when I saw that paper clip inside the electronics compartment that’s all I could think MacGyver paper clips rubber bands into pens and duct tape he could fix anything😎👍

**Gavin Price**: That’s me !!!!!!
 By the way Great Article!

**Gavin Price**: If me or Steve can’t fix it! Throw it away !

**Jeff Bergosh**: Thanks Gavin!  Yesterday was a great win for Beulah!  We’re going to get you all the facility upgrades you all deserve-I give you my word on that!!!

**Gavin Price**: Thank you Jeff.
 I know it will happen!

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-20-2020

**Gavin Price**: Jeff, sorry it took me a while to get back to you , but No they have not been delivered 

**Jeff Bergosh**: No problem Gavin I’ll get to the bottom of it you can count on that

**Gavin Price**: I know you will !

### CONVERSATION ON 04-21-2020

**Gavin Price**: 👍

### CONVERSATION ON 04-24-2020

**Gavin Price**: Hear anything back on the washer and mattress’s ?

**Jeff Bergosh**: Yes.  The mattresses I paid for are on order and should be here any day— they’re coming soon.  The heavy duty, stainless steel extractors for cleaning the gear are on order but none have been received yet.  One of these units is earmarked for station 2 according to the reply I got from Janice Gilley and Paul Williams

**Gavin Price**: Good deal. Thanks Jeff

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: From Administrator Gilley just now👍

**Gavin Price**: 👍

**Jeff Bergosh**: Mattresses Are coming soon I've been pressing hard ----because I can't believe it takes this long to purchase mattresses!!

**Gavin Price**: Nothing surprises me

### CONVERSATION ON 05-06-2020

**Gavin Price**: I need to talk to you

**Gavin Price**: I checked with the guys. No mattresses or dryer yet. They are installing the extractor this morning

**Jeff Bergosh**: Okay thanks for the heads up

**Gavin Price**: Yes sir

### CONVERSATION ON 06-15-2020

**Gavin Price**: This is Gavin. Please give me a call when you can

**Gavin Price**: Jeff, just talked to a friend of mine who said the union is pushing this. They want Beulah payed so every station on the south end will be career. Then they want to to make Cantonment north there own fire district so the union will have a lot more bargain power with the main union. Don’t know how much truth there is to this but it makes sense 

**Jeff Bergosh**: It wouldn’t surprise me

### CONVERSATION ON 06-16-2020

**Gavin Price**: If you would and can find out please let me know how to file a complaint. I can’t let it go what they did to Steve 

**Jeff Bergosh**: I will

**Gavin Price**: Thank you my Friend 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: So thanks for letting me know so that I had enough time to take some action

**Gavin Price**: Well I knew you did not know any thing about it or it would not of occurred to begin with. Just can not believe they would do that to Steve after he has devoted his life to this county. Also did you see the Supreme Court ruling on LGBT and transgender people. Hope the county understands the shit I could start

**Jeff Bergosh**: I hope they’re paying attention too!

### CONVERSATION ON 06-18-2020

**Gavin Price**: Hey , I put your signs back up at race track. Combined the 2 so you can see coming into track and leaving. They are 10 feet inside track property 

**Jeff Bergosh**: Thank you Gavin— greatly appreciate it!!

**Gavin Price**: Welcome

**Jeff Bergosh**: Gavin—-by the way.......thanks for hanging in there and sticking it out.  I know that was a shit meeting the other night!  But I Wanted to let you know the design award for station 2 remodel and renovation will be on the agenda for our July 2nd meeting.  I’m busting through the log jam—you all WILL have a modern, functional facility!!

**Jeff Bergosh**: When I get it, which will be within one week, I will get it to you

**Gavin Price**: If they will just leave us alone. Still pissed off sbout Steve

**Gavin Price**: Bet they are pissing there pants.

**Jeff Bergosh**: I also asked about an investigation and complaint about the way they tried to run off Steve.  Send me an email of the facts and the complaint—It is going directly to administrator and ethics/compliance office

**Jeff Bergosh**: I got them spun up yesterday!!!!

**Gavin Price**: I’m having someone with a little more tac than me helping me with a letter

**Jeff Bergosh**: 👍👍😎😎

**Gavin Price**: As far as my son I still not sure about a course of action. What they did was wrong on so many levels

**Jeff Bergosh**: Mattresses delivered today to Beulah Gavin—-sorry it took as long as it did.  It should not have.  But we got them there today at long last!

**Gavin Price**: Thank you Jeff. As far as my son is concerned I  don’t want this to go any farther than us, the attorney and the administrator because it could put him in danger. If you find out anything just tell them to establish a policy for employees and forget my son exists 

**Jeff Bergosh**: Ok

### CONVERSATION ON 08-18-2020

**Gavin Price**: Congratulations 

**Jeff Bergosh**: Thanks Gavin!

### CONVERSATION ON 08-31-2020

**Gavin Price**: Hey Bud, Do you wish to keep your sign here at track

**Jeff Bergosh**: Hey Gavin I’m gonna come by and grab it and less you would be willing to grab it for me and trash it?

**Gavin Price**: I will take care of it. Just wanted to check with you first

**Jeff Bergosh**: Thank u Gavin!!

**Gavin Price**: Welcome my Friend

### CONVERSATION ON 10-05-2020

**Gavin Price**: Do you know who to call to have a blue roof put on a house

**Jeff Bergosh**: Call the citizen’s info line and they can direct you to faith based organizations that are out assisting citizens.  850-471-6600

**Gavin Price**: Thank you my Friend 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-29-2020

**Gavin Price**: Call me when you have a moment 

**Jeff Bergosh**: On a conf call will call u back

### CONVERSATION ON 02-18-2021

**Gavin Price**: You do know Beau Rodrique left the Dept 

**Jeff Bergosh**: I think he transferred

**Gavin Price**: Told the Dept he retired from ECFR.something happened, but don’t know what

### CONVERSATION ON 06-15-2021

**Jeff Bergosh**: Hi Drew-- looks like I missed your call.  Is this a good number to text you on?

### CONVERSATION ON 06-23-2021

**Jeff Bergosh**: Thank you Elizabeth!

**Gavin Price**: Jeff, this is Gavin. Please give me a call at your convenience 850-554-3649

