

## CONVERSATIONS WITH TIM BRYANT 5 FLAGS

### CONVERSATION ON 04-07-2020

**Jeff Bergosh**: I’ll call u this afternoon on the way home

### CONVERSATION ON 08-14-2020

**Jeff Bergosh**: Hey Tim!  Thanks very much!  What time is the event?

**Jeff Bergosh**: Okay thanks Tim!

**Jeff Bergosh**: We still a go for racing tonight?  This storm looks pretty intense!

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-18-2020

**Jeff Bergosh**: Thanks Tim!  I might take you up on that!

**Jeff Bergosh**: I’m also looking into assisting you with the thermal scan costs if you are still looking to do that.  I’ll find out from legal today if I can contribute some discretionary money or CARES act money to that.  I had planned to call you this week about it

### CONVERSATION ON 10-18-2021

**Jeff Bergosh**: Sorry, I can't talk right now.

