

## CONVERSATIONS WITH SARA DAVY

### CONVERSATION ON 11-14-2020

**Jeff Bergosh**: Hi Sara the official date we’ve been given is March 1 or six months from the barge strikes the damage the bridge. However many of us remain deeply skeptical to Florida Department of transportation to meet this timetable. Many folks think it will be late May early June at Best

### CONVERSATION ON 12-29-2021

**Jeff Bergosh**: Wow!!!!!!!! What an incredibly generous contribution!!!!!!!!

Way to go!!!!

