

## CONVERSATIONS WITH SHERIFF MORGAN

### CONVERSATION ON 03-24-2020

**Sheriff Morgan**: Commissioner, we are knocking around ideas on how to keep manpower on the road (during and after this pandemic) and child care is a huge issue. We are considering a stipend or a even a facility. It would have to be 24/7 to accommodate first responders needs (much like military facilities).  Is this something the county would be interested in partnering with us? Much like the employee clinic.

**Jeff Bergosh**: I absolutely think that would be something we’d be willing to work with you on —-and something that’s going to be necessary. I’ll discuss it with Janice Gilley and see what we can come up with. And I feel certain my counterparts would support this as well we just got a know what it would look like and what it would cost.

**Sheriff Morgan**: Of course, cost is always the bottom line. Even after the pandemic passes single parenthood is a fact of life, and a large applicant pool that needs to be opened. Thanks! Looking forward to getting some preliminary data we can work with.

**Jeff Bergosh**: Me too.  Just let me know how We can assist, and I will discuss it with Janice as well.

**Sheriff Morgan**: Great. Will complete a few preliminary details and get back with you.

**Jeff Bergosh**: 👍

**Sheriff Morgan**: BTW, people forget you too are in the first responder/public safety realm....the jail, EsCoFD, EMT, etc. they too are facing this same issue. Rather than yearly salary increases, let’s explore benefits. I’m convinced Commissioner this is HUGE.

### CONVERSATION ON 03-25-2020

**Jeff Bergosh**: I agree!  Absolutely!

**Sheriff Morgan**: There’s a building in the county inventory that’s about to be vacated. Current occupant is NWFL Rebuild. Location is 150 E Maxwell. 4200 sq feet.  Has potential. Our numbers for children of child care age (worst case that everyone would need to be cared for) is 300. We’re checking on liability coverage through FSA, etc.

**Jeff Bergosh**: I am going to be on a conference call beginning at 4:30 with Janice Gilley and senior staff.  This will be a discussion topic-  I’ll let you know how that goes

**Sheriff Morgan**: Thanks! This should be available for all county employees. We’re knocking around ideas for sustaining the benefit. How do we make it cost neutral? As you know military commissaries are so established. The do not make a profit, but prices are set to ensure they are ‘self/sustaining.’

### CONVERSATION ON 03-30-2020

**Sheriff Morgan**: Good morning Commissioner, FYI, the ECSO has its first confirmed case of COVID-19.

**Jeff Bergosh**: Sorry to hear that Sheriff—hope he/she is getting the necessary medical treatment

**Jeff Bergosh**: BTW—I discussed the childcare proposal with Janice Gilley and she and staff are exploring it.

**Sheriff Morgan**: Thank you.

### CONVERSATION ON 07-31-2020

**Jeff Bergosh**: Good Afternoon Sheriff Morgan-

Thanks very much for joining us this Wednesday morning for our online discussion on COVID-19 and the impacts it is having on our community.  I sent the meeting invite/login information to 
Dmorgan@escambiaso.com - please let me know you received it.

**Sheriff Morgan**: Got it. See you Wednesday morning.

**Jeff Bergosh**: Thank you Sheriff— see you then.

### CONVERSATION ON 08-19-2020

**Jeff Bergosh**: Thank you Ken!!!!!

**Sheriff Morgan**: Commissioner, thought I’d wait till the smoke cleared before congratulating you on last night’s win....in a crowded field. The citizens have spoken!

