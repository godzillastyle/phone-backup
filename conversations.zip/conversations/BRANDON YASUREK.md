

## CONVERSATIONS WITH BRANDON YASUREK

### CONVERSATION ON 09-29-2020

**Jeff Bergosh**: Jeff Bergosh

**Brandon Yasurek**: So Brandon was in here with me when we were talking. But I think Brandon could greatly benefit from seeing a therapist. I know that it’s going to be hard to convince him to go talk to one but I think that may be what’s most beneficial to him. Just having someone who can help him interpret his thoughts and find a healthy way of coping with the passing of Cam  would help him tremendously.

**Jeff Bergosh**: Okay thanks that’s what we are going to do

**Brandon Yasurek**: You’re welcome. If y’all need anything just let me know 

**Brandon Yasurek**: I’m sitting in his room with him until he falls asleep 

**Jeff Bergosh**: Thank you for doing this!  

**Brandon Yasurek**: I think I finally got him to sleep 

**Jeff Bergosh**: That’s fantastic!  

**Brandon Yasurek**: Well know if sleep deprivation was why when he wakes up

**Jeff Bergosh**: Yes hopefully we will.  Will you let me know if he wakes up this evening later?  I’m hoping he sleeps straight through to the morning as he needs it

**Brandon Yasurek**: That’s what I’m hoping too 

**Brandon Yasurek**: I think he’s been too scared to sleep because of his buddy dying. His buddy died in his sleep from what I understand. Brandon asked me to wake him up in 8 hours to make sure he’s okay. I don’t want to wake him up because I know he needs the sleep so we’ll see what happens 

**Jeff Bergosh**: Okay well that makes sense.  So I assume you’ll pull his door shut but that it’s not locked

**Brandon Yasurek**: I was wrong. I went to check on him and his door was locked. 

**Brandon Yasurek**: I left for like 5 minutes 

**Jeff Bergosh**: Okay well I hope he goes to sleep

**Jeff Bergosh**: Please let me know if you think he isn’t sleeping

**Brandon Yasurek**: I will 

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-30-2020

**Brandon Yasurek**: So did they wind up admitting him? 

**Brandon Yasurek**: And is everything okay? 

**Jeff Bergosh**: Yes they did admit him and he finally got to sleep around midnight.  He will be meeting with counselors today and they reported to me that he’s doing better this morning after having got some sleep.  Thanks again for looking out for him and for your help yesterday

**Jeff Bergosh**: Incidentally— in case he is in for an extended period I need to get you the money for his portion of the October rent.  Just please let me know the amount and I’ll bring it by.  Thanks Brandon

**Brandon Yasurek**: Okay. I really really appreciate that 

**Brandon Yasurek**: His portion is $425.

**Jeff Bergosh**: Okay I will get it to you after I get off of work today.  Where should I meet you between 4:30-5:00?  The apartment?

**Brandon Yasurek**: That should work 

**Jeff Bergosh**: 👍

**Brandon Yasurek**: Thank you sir 

**Jeff Bergosh**: No problem

**Jeff Bergosh**: Just let me know, thanks

**Brandon Yasurek**: Yes sir 

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-14-2020

**Jeff Bergosh**: Thanks Brandon

**Brandon Yasurek**: You’re welcome 

