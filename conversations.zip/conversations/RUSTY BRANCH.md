

## CONVERSATIONS WITH RUSTY BRANCH

### CONVERSATION ON 10-24-2019

**Jeff Bergosh**: We missed you Tuesday Rusty—you missed a hell of a party!!  Hopefully you can make it to the next one!

**Rusty Branch**: Man, I hated to miss it. Laura had to work late and I called in to run kids to soccer and dance. The photos look great and I sent a couple of people including Walker Wilson, I hope they showed up. 

**Rusty Branch**: Meant to mention to you, if you want to do a fundraiser at my house my wife & I would be more than happy to host. I know it isn’t in your district, but Bridgette Brooks and Steven Moorhead live in my neighborhood and they would assist, I am sure of it. 

**Jeff Bergosh**: Thanks Rusty—I might take you up on that!

**Rusty Branch**: 👍🏼

### CONVERSATION ON 10-30-2019

**Rusty Branch**: Good afternoon. Ron Ellington has a proposal for truly evaluating the Bay Center that I think you might like. He is meeting with some other commissioners to discuss and he asked if I could set up a meeting with you...might you be interested and available? 

**Jeff Bergosh**: Sure Rusty—Probably need to shoot for next week at some point

**Rusty Branch**: Sounds good, maybe coffee on your end of town...

**Jeff Bergosh**: Sounds good

### CONVERSATION ON 11-05-2019

**Rusty Branch**: Good morning, just wanted to follow up on potential meeting this week with you, I & Ron Ellington. Do you have any available times? 

**Jeff Bergosh**: Hello Rusty—how about today at 12:00 at my office?

**Rusty Branch**: I have to meet with an SRIA member at 11:30, but Ron will be there.

**Jeff Bergosh**: Okay tell him I’ll see him then

**Rusty Branch**: You the best!!

**Jeff Bergosh**: Thx

### CONVERSATION ON 11-20-2019

**Rusty Branch**: Sorry we missed you at the event last night. I hope it went well. 

### CONVERSATION ON 11-27-2019

**Rusty Branch**: Good morning. Might you be available/interested in meeting with an appropriations lobbyist on the afternoon of the 3rd, prior to Lewis’s senate fundraiser? 

**Jeff Bergosh**: Sure.  I’ll have to check the calendar.  Where and what time?

**Rusty Branch**: If you are going to the fundraiser at Lewis’ then we can do it in Gulf Breeze later in the afternoon...or whatever you prefer 

**Jeff Bergosh**: Not going to make the fundraiser.  Let’s talk Friday and work out a time.  I hope you have a very Happy Thanksgiving Rusty!

**Rusty Branch**: Ok, sounds great and thanks. 

**Jeff Bergosh**: Thanks!

### CONVERSATION ON 12-02-2019

**Rusty Branch**: Good morning. Can you meet the appropriations guy tomorrow afternoon? We can meet downtown.

**Jeff Bergosh**: Hey Rusty I would love to but my schedule just got turned upside down at my day job so today & tomorrow I’m locked down.  I can meet Wednesday after the joint city county meeting at 11:45 or so if that works

**Rusty Branch**: Good deal. I will see if he will be in town still and let you know. Thanks 

**Jeff Bergosh**: Thx

### CONVERSATION ON 12-05-2019

**Rusty Branch**: What the heck, you aren’t on PEDC?? You are a champion of that organization and the only board member who could articulate their efforts. 

**Rusty Branch**: Oh great!! 

**Jeff Bergosh**: Glad I’m still on board!  Whew!!!!

**Rusty Branch**: That’s good news 

**Rusty Branch**: Paid parking in the core is such a great idea. 

**Jeff Bergosh**: I agree

**Jeff Bergosh**: Fixes traffic

**Rusty Branch**: It limits cars for sure. Won’t fix traffic. 

**Jeff Bergosh**: I think it is the 90% solution

**Jeff Bergosh**: Big days, big traffic

**Rusty Branch**: Too many places have fixed this issue with far more vehicle passages. But I understand we need to take it in bites and pieces.   

**Jeff Bergosh**: 👍

**Rusty Branch**: What is the source for this data? Did he pay for an additional traffic study? 

**Jeff Bergosh**: No, our TSOC at our one-stop facility collects this data

**Jeff Bergosh**: That toll booth is the primary culprit

**Rusty Branch**: We run those in Santa Rosa? 

**Jeff Bergosh**: Yes

**Rusty Branch**: It is the culprit now because it is the first choke point. Engineers have said once you truly open it the signalized intersection will then serve as a choke point. 

**Jeff Bergosh**: Bender’s chart indicates the time from fair point through the light at fort Pickens .  Through the light

**Rusty Branch**: But we will likely get a half fix like this county is famous for, not maximize our assets and miss the ROI that we could have gotten. 

**Jeff Bergosh**: I think this will be part I of the fix

**Rusty Branch**: That’s because the they were manipulating the light and causing back ups on Ft. Pickens. But I hope you are correct. I would like some of those nice Walton County schools for my kids. Haha

### CONVERSATION ON 12-13-2019

**Rusty Branch**: Good morning, You attending the legislative luncheon today?

**Jeff Bergosh**: In Orlando

### CONVERSATION ON 12-19-2019

**Rusty Branch**: You get driven around...boss 😂

**Jeff Bergosh**: I thought That might have been you Rusty LOL

**Jeff Bergosh**: Merry Christmas

**Rusty Branch**: Same to you. Have a great one!!

### CONVERSATION ON 01-10-2020

**Rusty Branch**: Good morning. Hope your brother will run for State Attorney, I enjoyed the blog post you wrote. Also, I know you all are discussing the 5th cent next week and I am assuming based on bloats discussions that you will be supportive, is that correct? Thanks 

**Jeff Bergosh**: Thanks Rusty—yeah for sure

**Rusty Branch**: I hoped not, but assumed so. Thanks 

**Jeff Bergosh**: Need that revenue to be put into place

**Jeff Bergosh**: However given the election year who knows if others will buckle and thus no super-majority

**Rusty Branch**: It will continue to reduce visitors and visitors spend (ie. taxes) at the beach. But you all can not reduce millage and get those funds from locals. 

But if enacted certainly hope it is put in the right place to generate the largest return for the county. 

**Jeff Bergosh**: If that question in and of it’s self alone is the litmus test for whether or not hoteliers will support Johnathan Owens I think a second question should be put before him that is does he support the roundabouts I’d like to know on the record where he’s at on that

**Jeff Bergosh**: I saw the article where it says we need more supply out at the beach and that there are not enough hotel rooms to meet the demand

**Rusty Branch**: That’s not the sole question for my folks. 

**Jeff Bergosh**: I hope not

**Jeff Bergosh**: I’m interested to see who’s actually going to write them a check can’t wait to see that list

**Rusty Branch**: I think Patel’s will give push back as their margins are the slimmest.  

**Jeff Bergosh**: Him

**Jeff Bergosh**: To help with the Baycenter lift

**Rusty Branch**: Yeah but he only owns 2 hotels. Other patels are very unhappy if their TDT goes to help jay make personal money on a side deal. 

**Jeff Bergosh**: Well I will certainly listen to what everyone says and I think at the end of the day it will come down to is there four votes for a super majority

**Jeff Bergosh**: And I just don’t know if there is prior to August 18

**Rusty Branch**: Guys like Tish have much more at stake because he owns many more hotels. 

**Jeff Bergosh**: Hopefully everyone who has an opinion on the subject will come before the board and speak on the record

**Jeff Bergosh**: I hope they will

**Rusty Branch**: But the real issue is the unrealized spend this will create with peak season beach visitors. We have had three straight years of declines in July at the beach. 

### CONVERSATION ON 01-14-2020

**Rusty Branch**: Good morning Commissioner,  I was just looking back at our texts from last week to remind myself what we discussed and I noticed you mentioned an article you read where we were out of rooms at the beach. That was a statement by Steve Hayes to the PNJ to suggest a reason why occupancy had stagnated at the beach...which was what any good politician would do, always spin negative issues in the best light. I wrote viewpoint clarifying that wasn’t the case and the beach in terms of occupancy has declined since the BP marketing dollars ran out after 2016 and even during season isn’t bear 100% occupancy. 

Just wanted to clarify that, we can do a lot more in terms of occupancy during the peak season and when we do the county reaps much greater rewards.   

### CONVERSATION ON 01-16-2020

**Rusty Branch**: The amount of misinformation that shared today was astounding.

**Rusty Branch**: I know your position and I know you always get your facts together, but stuff being shared by your counter part was very concerning. 

**Jeff Bergosh**: Which part Rusty?

**Rusty Branch**: Sorry for the slow response was in a meeting. That we could statutorily get to a 6th cent, that the majority of Florida Counties have a 5th cent, how much we spend on marketing, that counties are at a 7th & 8th cent, that we don’t spend millions on non marketing efforts annual when we have done that for years and it’s why we don’t have any reserves to speak of, that this tax will not impact locals. 

Had two items in the agenda and the staff didn’t seem prepared for either and Comm. Bender was obviously unprepared for his item. 

### CONVERSATION ON 02-13-2020

**Rusty Branch**: You endorsing Diane?

**Jeff Bergosh**: LOL. No.  I’m endorsing opening Beach Access #4 in Perdido Key

**Jeff Bergosh**: What’s Diane running for??

**Rusty Branch**: Florida House. I thought she was giving you a supporter button before the mtg. 

**Jeff Bergosh**: Open Access #4

**Rusty Branch**: Nice!! But she will interrupt supporting her causes as supporting her. 

### CONVERSATION ON 02-20-2020

**Rusty Branch**: They never listen to you on Beulah...I would be so frustrated. You a better man than I.   

**Jeff Bergosh**: Yes it comes with the territory

**Rusty Branch**: Sure but you always defer to them in their districts. 

**Jeff Bergosh**: I try to be congenial

**Rusty Branch**: Good afternoon. Thanks for trying not to spend TDT on beach access 4 today. It’s strange that the argument for a while has been we should open it for locals, but then decided to use tourist development tax on it, but it will & should qualify according to statute. The statute also says that TDT can only pay for up to 70% of the project cost.

**Jeff Bergosh**: I would have preferred to fund the whole thing with LOST.  We buy playground equipment and make tennis courts with local option sales tax but we can’t open the beach with it? I don’t think it’s gonna be such an easy vote at the TDC

**Jeff Bergosh**: Thanks for noticing though Rusty I appreciate that

**Rusty Branch**: Some TDC members don’t seem happy, but you guys have been good to them. As for noticing, I not only noticed, I will also make sure all our members know you fought for this to be funded out of LOST and they will appreciate your efforts. 

**Jeff Bergosh**: Thank you Rusty

### CONVERSATION ON 02-26-2020

**Rusty Branch**: Good afternoon, hope you are well. Wondering how come the County budget for next year is already reducing the Visit budget by over a million? It’s the only place the County gets an ROI. 

**Jeff Bergosh**: Not sure Rusty—I’ll ask

### CONVERSATION ON 03-03-2020

**Rusty Branch**: Good morning. It looks like Nash Patel is resigning from the TDC today and Tish Patel is very interested in that spot. Tish owns hotels in 3 or 4 of the county districts including yours, so I hope you will consider him seriously. Terrific young man who is very involved in Escambia County.

**Jeff Bergosh**: Yeah I was sorry to hear Nash resign. I will look at Tish’s application very favorably

**Jeff Bergosh**: .........That said who else is in the running?

**Rusty Branch**: Not sure yet, don’t even think it has been advertised yet because resignation is on the agenda today. However, Tish is now the biggest player in that community in terms of hotels/funds and would be a great guy for you to get to know/meet with.

**Rusty Branch**: Nash & Jay are selling their only 2 hotels and Nash works out of town most every week. So I think they are getting out of the hotel/tourism business all together. 

**Jeff Bergosh**: Wow—I didn’t know that!

### CONVERSATION ON 03-05-2020

**Rusty Branch**: Don’t trust those beach numbers shared a few minutes ago...will continue to make the whole board look bad if D4 is believed carte blanche on those issues. Many people in the community have seen documented numbers to the alternative. Just FYI 

**Jeff Bergosh**: Thx

### CONVERSATION ON 03-12-2020

**Rusty Branch**: This is a disaster. County should have one person speaking. With no audience but media. Who is running y’alls PR?!?

**Rusty Branch**: Also, is the COTW suspended right now? 

**Jeff Bergosh**: It was briefly

**Rusty Branch**: Cool. 

I’m not sure “this” project has local support. Jay asked for folks to attend today and support him and none of them showed up.

**Jeff Bergosh**: D’oh

**Jeff Bergosh**: Homer Simpson might say

**Rusty Branch**: You will need almost $5m annually to pay the note on this deal. Will pay over $40m in debt service alone even if you could get triumph and there isn’t a chance of that due to statute stating wage level
is deciding factor. 

**Jeff Bergosh**: That certainly makes it tough

**Rusty Branch**: Had a good convo with Steve Moorehead about you today. He is a fan of yours. Keep up the good work.

**Jeff Bergosh**: Thanks Rusty!

**Rusty Branch**: Also thanks for the pushing the
Corona update today. County about to take it on the chin economically if we don’t get ahead of this.

**Jeff Bergosh**: I hope to God the summer heat kills this damn thing. Otherwise we’re not gonna have a summer.......

**Jeff Bergosh**: .........And that would be devastating

**Rusty Branch**: Jobs gonna be the worst hit. 

**Jeff Bergosh**: Yep

**Jeff Bergosh**: And that will trickle out into the overall economy in a bad way

**Rusty Branch**: And if Tourism/visitors takes a big hit, 1/3 if LOST takes a hit 

**Jeff Bergosh**: That’s right, and that’s scary

### CONVERSATION ON 03-16-2020

**Rusty Branch**: Backed up on a Monday to 3mile, but no doubt 4 got it under control.

**Rusty Branch**: But seriously, any chance that the County closes the beach? 

**Jeff Bergosh**: Wow!  Weather is perfect so this doesn’t surprise me.  Call D4 and tell him to activate my panic switch idea!!  I’m serious

**Jeff Bergosh**: .....But about closing the beach I don’t think that’ll happen until we get some sort of mandate from the governor or unless we get some kind of a massive outbreak locally

**Rusty Branch**: He doesn’t need your or anyone else’s idea, he has everything all figured out. 

Thanks for beach feedback. With Miami closing folks we worried. 

**Jeff Bergosh**: But they and Broward County are having one hell of an outbreak so I think that’s the differentiator

**Jeff Bergosh**: If we have the outbreak they’re having right now I think we would be close down and locked up tight

**Rusty Branch**: Understandable. Good feedback. 

**Jeff Bergosh**: Thanks.  I hope the hotels and the restaurants are scooping up all the revenue they can get while they can get it..........Because who knows which way this goes when we start reporting cases locally

**Rusty Branch**: You see Goldman Sachs investor call minutes today? If you haven’t, don’t 😳

**Jeff Bergosh**: It’s all going south right now.  Scary

### CONVERSATION ON 03-17-2020

**Rusty Branch**: Summary of Goldman Sachs Investor call... where 1,500 companies dialed in. 
 
The key economic takeaways were:
 
50% of Americans will contract the virus (150m people) as it's very communicable. This is on a par with the common cold (Rhinovirus) of which there are about 200 strains and which the majority of Americans will get 2-4 per year.
 
70% of Germany will contract it (58M people). This is the next most relevant industrial economy to be affected.
 
Peak-virus is expected over the next eight weeks, declining thereafter.
 
The virus appears to be concentrated in a band between 30-50 degrees north latitude, meaning that like the common cold and flu, it prefers cold weather. The coming summer in the northern hemisphere should help. This is to say that the virus is likely seasonal.
 
Of those impacted 80% will be early-stage, 15% mid-stage and 5% critical-stage. Early-stage symptoms are like the common cold and mid-stage symptoms are like the flu; these are stay at home for two weeks and rest. 5% will be critical and highly weighted towards the elderly.
 
Mortality rate on average of up to 2%, heavily weight towards the elderly and immunocompromised; meaning up to 3m people (150m*.02). In the US about 3m/yr die mostly due to old age and disease, those two being highly correlated (as a percent very few from accidents). There will be significant overlap, so this does not mean 3m new deaths from the virus, it means elderly people dying sooner due to respiratory issues. This may however stress the healthcare system.
 
There is a debate as to how to address the virus pre-vaccine. The US is tending towards quarantine. The UK is tending towards allowing it to spread so that the population can develop a natural immunity. Quarantine is likely to be ineffective and result in significant economic damage but will slow the rate of transmission giving the healthcare system more time to deal with the case load.
 
China’s economy has been largely impacted which has affected raw materials and the global supply chain. It may take up to six months for it to recover.
 
Global GDP growth rate will be the lowest in 30 years at around 2%.
 
S&P 500 will see a negative growth rate of -15% to -20% for 2020 overall.
 
There will be economic damage from the virus itself, but the real damage is driven mostly by market psychology. Viruses have been with us forever. Stock markets should fully recover in the 2nd half of the year. Investing in the next few weeks may be a good idea.
 
In the past week there has been a conflating of the impact of the virus with the developing oil price war between KSA and Russia. While reduced energy prices are generally good for industrial economies, the US is now a large energy exporter, so there has been a negative impact on the valuation of the domestic energy sector. This will continue for some time as the Russians are attempting to economically squeeze the American shale producers and the Saudi’s are caught in the middle and do not want to further cede market share to Russia or the US.
 
Technically the market generally has been looking for a reason to reset after the longest bull market in history.
 
There is NO systemic risk. No one is even talking about that. Governments are intervening in the markets to stabilize them, and the private banking sector is very well capitalized. It feels more like 9/11 than it does like 2008.

**Jeff Bergosh**: Thanks for forwarding that Rusty that’s very good information

**Rusty Branch**: Time to invest!! That’s my takeaway. 

**Jeff Bergosh**: Governor closing bars for 30 days

**Jeff Bergosh**: Live news conference

### CONVERSATION ON 03-19-2020

**Rusty Branch**: If the hoteliers came out with a plan to limit occupancy, temp check all workers, monitor distancing behind their hotels...would that help keep beaches open? 

**Jeff Bergosh**: I believe it would

**Rusty Branch**: Thanks 

**Jeff Bergosh**: Special meeting tomorrow, tentatively, at 11:00

**Rusty Branch**: Press conference at noon. Limiting occupancy at hotels by 50%, screening staff and guests, following CDC recs...policing safe distances beach behind our hotels. 

Keep as many staff as possible employed while also creating safe environments.

**Jeff Bergosh**: Noon today?  Where, and who is participating?

**Rusty Branch**: Margaritaville. Bender, can you come. 

**Jeff Bergosh**: Today?

**Jeff Bergosh**: ?

**Rusty Branch**: Yes, Bender’s idea 

**Jeff Bergosh**: 👍

**Rusty Branch**: Will county follow Grover and close in restaurant seating? 

**Jeff Bergosh**: I have no idea

**Jeff Bergosh**: What did Grover do?

**Rusty Branch**: Close inside seating at restaurants 

**Jeff Bergosh**: Wow

### CONVERSATION ON 03-20-2020

**Rusty Branch**: Select Speciality Hospital on Airport is a Long Term Acute Care (LTAC) hospital and has: 75 beds, 21 vents, 20 bipaps, 3 negative pressure rooms. Census is around 50. Currently using 11 vents and 8 bipaps. 

**Jeff Bergosh**: Thanks

**Rusty Branch**: Also, generally Icu beds are really based on staffing ratios. 

It’s an acuity based staffing approach. Not a rule per say but it is how all ICUs operate. Usually 2:1 or 3:1 (nurse to patient) 

**Rusty Branch**: Can you bring up and/or consider TDT forgiveness for March...many communities are doing this. Hotels across the county (especially i10) are hurting and this will help them make payroll. 

**Jeff Bergosh**: That would require a state action Rusty

**Rusty Branch**: County imposed tax that is collected by the county. State just allows for it by statute. 

You could forgive or delay it until later in the year. 4% bump would help hotels make payroll. 

**Jeff Bergosh**: Take a look at The governor’s brand new executive order 20 - 72 it totally prohibits any medically non-urgent unnecessary medical or dental procedures to conserve personal protective equipment for the COVID 19 response.

**Rusty Branch**: Yep. Just got that sent to me. Faulkner was selling a load of bull and a guy dies of COVID on the 6th and SH doesn’t stop electives until the 16th?!? 

**Rusty Branch**: And when they do miraculously their days of PPE increase. 

**Jeff Bergosh**: Tough day for all of us.  Now the doctors get to join us 

**Jeff Bergosh**: And dentists

**Rusty Branch**: Yep. But 3 hospitals CEO’s all walk with millions at the end of the year...bank on it. 

**Jeff Bergosh**: Probably

### CONVERSATION ON 03-23-2020

**Rusty Branch**: Good afternoon. Local TDT loans or grants or forgiveness could save a lot of jobs right now. 24k tourism related jobs, we should try to save as many as possible. 

**Jeff Bergosh**: I don’t disagree Rusty are you talking about marches collections which would be due April 20?

**Jeff Bergosh**: March’s

**Rusty Branch**: Yes 

**Jeff Bergosh**: State of Florida and relevant statutes would control our ability to provide this accommodation though, I believe

**Rusty Branch**: I think it would allow, just as you could suspend the 3 & 4 cent completely with 3 votes. 

**Rusty Branch**: Which would also work!! 😉

**Jeff Bergosh**: Something to think about

**Rusty Branch**: Thanks 

### CONVERSATION ON 03-24-2020

**Rusty Branch**: Man...they arresting EMS folks in the middle of covid-19, what the heck did they do?!? 

**Jeff Bergosh**: There’s allegations that they forged training documents so we’ll see what happens.

**Rusty Branch**: Wow

**Rusty Branch**: https://www.gulfshoresal.gov/CivicAlerts.aspx?AID=555&fbclid=IwAR3dqo0eeRDuPVfFxuqT3eDivNQESgxInbxtyP-P5NssVefMNIWMVqvynuo

### CONVERSATION ON 03-25-2020

**Rusty Branch**: Great town hall. Thanks for all you are doing.  

**Jeff Bergosh**: Thanks Rusty!

### CONVERSATION ON 03-30-2020

**Rusty Branch**: What time is the BCC mtg this Thursday?

**Jeff Bergosh**: 5:30

**Jeff Bergosh**: Public forum at 4:30

**Rusty Branch**: Thanks, thought y’all had moved it to the morning for some reason. 

### CONVERSATION ON 04-01-2020

**Rusty Branch**: Good morning commissioner. What are you thinking on the beach issue?

**Jeff Bergosh**: I wish they were open, but I am going to defer to the experts in our medical field and the epidemiologists.  It will be a good discussion

**Rusty Branch**: Understand. I suspect Grover puts a stay at home order in place after tomorrow if y’all keep it closed.

**Jeff Bergosh**: Wow

**Rusty Branch**: Y’all will be pressured to do the same. 

### CONVERSATION ON 04-08-2020

**Rusty Branch**: Good morning, hope you are well. Can’t believe the number of jobs this covid is taking. Hope we can start backing out of this soon. Other communities are doing so. 

**Jeff Bergosh**: Cocoa Beach

**Rusty Branch**: Daytona, Gold Coast, etc. 

**Rusty Branch**: Non clinical Healthcare folks have lead governments astray.

**Rusty Branch**: These hospitals CEO’s are the worst...total money managers and on public surveys they always score low compared to favorability for nurses and docs. 

**Rusty Branch**: You should get a doc to be on a coffee & convo with you, will be much more favorable with general public. 

**Jeff Bergosh**: I’ll see if I can do that-that’s a good idea!

### CONVERSATION ON 04-14-2020

**Rusty Branch**: Good morning. Had a thought about the need to stream line and generate more county revenue going forward (the state & county will have major financial issues). It might be a good time to roll the SRIA staff into the county, keep Paolo on the island, have finance staff (7 of the 11) move to Clerk’s office and bring those SRIA lease & other fees into the county coffers. 

### CONVERSATION ON 04-16-2020

**Rusty Branch**: McKay did you wrong on that one. You are correct about the beach. 

**Jeff Bergosh**: I agree.  Horrible optics for Escambia county. And a major double standard everyone knows this sort of gathering on the beach among surfers would’ve been broken up instantaneously

**Jeff Bergosh**: At least he had the class to let me come on and defend my position

**Rusty Branch**: Not sure who he supports, but calling you out on that minor issue was odd at best and deliberate at worst. 

**Jeff Bergosh**: Deliberate

**Rusty Branch**: Which isn’t good. 

**Rusty Branch**: That event getting national play will also hurt us on the comeback. Would you come here with that in your mind or go to Destin or Gulf Shores?!?

**Jeff Bergosh**: Exactly

**Rusty Branch**: Hopefully we can get locals back to the beach soon. All our feeder markets are locked down and those folks aren’t traveling anyways. The research says folks will not really start traveling again until late fall (November). This summer is in the tank for us, but us locals should be able to walk, fish, surf, enjoy that beach at a minimum.  

**Jeff Bergosh**: I don’t disagree.  The block party might just provide the impetus for us to do it

**Rusty Branch**: And honestly we are working with hospital leadership to give them some reassurance that people are not going to flood our area...people are on lock down elsewhere and they are worried about their bank accounts so travel is shot for a while. 

### CONVERSATION ON 04-17-2020

**Rusty Branch**: Do you have a few minutes to chat this afternoon about a smart plan for reopening the beach?

**Jeff Bergosh**: Sure—I’ll call u on my way home from work

**Rusty Branch**: What time might that be? 

**Jeff Bergosh**: 4:30ish

**Rusty Branch**: Sorry I missed you. Don’t want to take up your Friday night, can we schedule a call for Monday?

**Jeff Bergosh**: Sure

### CONVERSATION ON 04-20-2020

**Rusty Branch**: Sorry I haven’t been able to catch up with you today. Are you available to chat for a few minutes this afternoon?

**Jeff Bergosh**: Sure.  I’ll call u when I’m leaving the office

**Rusty Branch**: Thanks, I read your blog and have been working on your 3 criteria. 

### CONVERSATION ON 04-22-2020

**Rusty Branch**: How did go this morning?

### CONVERSATION ON 04-27-2020

**Rusty Branch**: https://floridapolitics.com/archives/330091-still-no-signs-of-a-coronavirus-spike-in-northeast-florida-after-controversial-beach-openings

**Rusty Branch**: Very positive. 

**Jeff Bergosh**: That is

**Rusty Branch**: Also, are you all voting on something Triumph related tomorrow? Someone at the boardwalk said they spoke with county staff and understood that was going to be discussed tomorrow. 🤷🏻‍♂️

**Jeff Bergosh**: Not to my knowledge— unless there will be an add-on to our agenda 

**Rusty Branch**: 👍🏼

**Rusty Branch**: Thanks for responding. I assume you are for opening the beaches with the hospital’s letter? 

**Jeff Bergosh**: Yes that’s where I’m leaning

**Rusty Branch**: Thanks. 8am to 8pm would be great. Easy to enforce.

### CONVERSATION ON 04-28-2020

**Rusty Branch**: Good morning. I have looking at and talking with other beaches around the state and they suggest a weekday versus weekend for reopening beaches. Weekdays seem to bring out less people and create less opportunity for negative PR moments. Opening tomorrow or Thursday might be a wise decision.

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: Hey Rusty—I’d like to have you as my guest on a coffee with the commissioner event to talk about the COVID-19 recovery, impacts to tourism, the beaches, etc.  would you be interested and could you join me next Wednesday May 6th online?

**Rusty Branch**: Absolutely!! Thanks for the invite as it will be an honor to be your guest. 

**Jeff Bergosh**: Right on thanks Rusty!  We will do it on Zoom—I’ll send you the meeting log in numbers.  I know you’ll have lots of data and good info to bring to the discussion!  

**Rusty Branch**: Very much looking forward to it. 

**Jeff Bergosh**: Me too!

### CONVERSATION ON 05-04-2020

**Rusty Branch**: Great weekend at the beach. Occupancy a little below were it needed to be and everyone was spacing out. 

**Jeff Bergosh**: Yeah I went out there on Sunday it was beautiful.  No traffic backups either

**Rusty Branch**: Only 16k on Saturday had it stopping  just thru toll booth and backed up getting off, but I will take that over what we have had.

**Jeff Bergosh**: Yep

### CONVERSATION ON 05-06-2020

**Jeff Bergosh**: Rusty— Thanks very much for coming on the coffee today!

**Rusty Branch**: It was great. Thanks again. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-07-2020

**Rusty Branch**: Hey great job tonight. Just wanted to let you know that Jason Nicholson as a former chair of Visit Pensacola would be a great TDC member.

**Jeff Bergosh**: Thanks Rusty -  I think Mitesh Patel got it unanimous

**Rusty Branch**: Tish is a great guy. Perfectly fine with him. 

**Rusty Branch**: Also, can you please text me tonight the vote on TDT late fee waiver? I would appreciate that, have to sign off watching.

**Jeff Bergosh**: Will do

**Rusty Branch**: You are the best, thanks 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Amnesty for TDC passed 5-0

**Rusty Branch**: Great, assumed it would but wanted to be sure. Thanks and safe travels home. Your work is appreciated. 

### CONVERSATION ON 05-14-2020

**Jeff Bergosh**: Rusty—-as a supporter who has helped me get financial contributions to my campaign, I wanted to let you know that  even though I have not been able to actively campaign since mid-March with the COVID-19 Pandemic consuming my time and efforts, I just got my latest poll results back from Gravis.  I’m further ahead of Jesse Casey in my race now than I was in February’s poll (by 16 points) and I’m ahead of Underhill’s Secretary and the fire union by 30 points!  Thought you might like to know that.  Soon, once the Governor allows phase II of the re-opening—-I’ll begin to deploy the rest of my 1,000 large and small signs, TV, Radio, and outdoor billboards plus social media and door to door.  I’m going to push through to the finish line on August 18th like nobody has ever seen before in Escambia county—-ever!  Thanks for your continued support!

Bergosh.  46%
Casey.       30%
Owens.      16%
Trotter.         8%

Have a great Thursday Rusty!

**Rusty Branch**: That’s awesome!! You better win 😂. I have been staking my political predicting acumen on you winning easily. I haven’t miss called a race in 10years. 
You the man, keep up the good work. 

**Jeff Bergosh**: Thanks Rusty—I’ll keep trying to do my best!

### CONVERSATION ON 05-23-2020

**Rusty Branch**: Hey buddy. Hope your Memorial Day weekend is off to a great start. I have already been getting calls about beach traffic this morning. This is the 3rd Saturday in a row since beaches reopened that traffic is backed up into Gulf Breeze with an all electronic toll booth that you all supported. But, as the engineers have said since 2009, to fix traffic you have to deal with both the toll booth & the signalized intersection. We also have 3 hotels closed on the beach and vacation rentals have been closed until this week and haven’t really been able to book up this week...but we are seeing back ups. This is without doubt a locals issue but it will continue to impact tourism (our only hope in restoring lost public funds over the last 3 months other than taxing locals more) in a negative manner. I know this isn’t your district, but I know it impacts us all. Have a great day my friend.

### CONVERSATION ON 05-29-2020

**Rusty Branch**: Good morning Comm. Bergosh. I was wondering if you might be willing to ask Janice to request the Governor end the i10 check point. Gov said he only put it in place because Escambia asked for it. At this point it is simply a traffic aggravation & point of confusion for travelers. Also, Louisiana now has less active covid cases than Florida and is no longer a hot spot of concern. Thanks considering this. 

**Jeff Bergosh**: I asked her on Wednesday this very question—along with Andrade.  They both still support it... go figure right?  $50 per hour side work for the deputies and highway  patrolmen and PPD—-that is quite an enrichment program and as long as the state is paying the tab I don’t think they will rush to close it.

**Jeff Bergosh**: Even though as you correctly point out Louisiana is not the hotspot it was 6-weeks ago.......

**Rusty Branch**: Really disappointing. 

**Jeff Bergosh**: I think it’s time too— for what it’s worth

**Rusty Branch**: Thanks 

**Jeff Bergosh**: Yes.  Hey what do you think about keeping to the four lanes at the toll booth closed? I think that’s unnecessarily restricting traffic and I asked Bender about it at the meeting and he is convinced that leaving only the two through the toll booth is faster. I disagree with him I think at a minimum we should have three open what do you think?

**Rusty Branch**: I think more lanes makes more sense but I’m not a traffic engineer so I’m not sure. Don’t think FDOT really weighed in as much as he says. But I can ask traffic consultant we are paying to study the hot right suggestion. Bender wouldn’t pay a few thousand to have a expert study that idea (which will be easily $2million), so we are paying him and I am sure he can give us a quick & clear analysis. It’s a real shame how he just cherry picks some anecdotal data for his decision making on the island. 

**Jeff Bergosh**: Yep I agree

**Rusty Branch**: That gridsmart data he showed y’all was carefully handpicked. He, Angela & Janice are tight tho and largely out operating those of y’all who have real jobs   

**Jeff Bergosh**: Could be

### CONVERSATION ON 06-13-2020

**Rusty Branch**: Good morning. I heard you had some good Escambia Children’s Trust meetings this week...

**Jeff Bergosh**: Yep.  It’s going to be on the ballot in November, no doubt.

**Rusty Branch**: Sounds good. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-16-2020

**Rusty Branch**: You are a rock star!! Great job. 

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Thx

### CONVERSATION ON 07-06-2020

**Rusty Branch**: Good afternoon. Those salaries at the County are crazy good. No wonder y’all don’t get more done...those wages and no performance metrics...bonuses & profit sharing is what pushes up production in the private sector. 

### CONVERSATION ON 07-07-2020

**Jeff Bergosh**: You are right.  Great salaries, great benefits.  Yet still at least one of our unions believe we need higher pay like NYC or LA.  You can’t make this stuff up.......

**Rusty Branch**: Unbelievable. 

Also, looks like Janice is cutting Visit Pensacola marketing funds but not other areas TDT foots the bill for. Our tax base needs tourist here in the fall replenishing those funds. Beach hoteliers will be fine either way, our county coffers  will not.  

**Jeff Bergosh**: I look forward to discussing that.  I agree that we have to keep priming the pump. I see just today Destin Fort Walton Beach with an aggressive ad campaign targeting Pensacola

**Rusty Branch**: Yep!! And Orange Beach/Gulf Shores are targeting all of our historical great Louisiana and northern Alabama markets...and they are winning big. 

**Jeff Bergosh**: We’ve got to get the handle on this.  We are the big dogs not Ft Walton Beach

**Rusty Branch**: Julian has two hotels in Ft. Walton and about to build another. That will be the 9th hotel he has built in the gulf coast since he last built in Escambia. It’s because places like Okaloosa are marketing like crazy, fixing their traffic...including putting a roundabout in at the landing of the brooks bridge. Heck we went over two weeks ago and the sheriff, state rep and county Comm came and meet with us at the hotel to ask how they could help us. And here we have stuttering Bender stifling arming us all the time while he runs the beach into the crowd. Less people last weekend than we get on October weekends came onto the beach. 

**Jeff Bergosh**: Wow

### CONVERSATION ON 07-09-2020

**Rusty Branch**: Good afternoon. Do you have any time tomorrow for a short phone call with Ted Ent & I about marketing budget?

**Jeff Bergosh**: Sure.  After 3:00 just call at your convenience

**Rusty Branch**: Roger that. 

### CONVERSATION ON 07-10-2020

**Rusty Branch**: Good afternoon. Sorry but Ted is unable to participate in a call today. Any chance we could ring you on Monday? We will only take a few minutes of your time.

**Jeff Bergosh**: Sure thing-  just call me in the afternoon

**Jeff Bergosh**: Have a great weekend!

**Rusty Branch**: Thanks and you as well. 

### CONVERSATION ON 07-13-2020

**Rusty Branch**: Good afternoon. If you have a second please give me a call. Thanks 

**Jeff Bergosh**: Will do as soon as I’m out of this meeting

**Rusty Branch**: Sounds great. But if you don’t mind call Ted directly. 

### CONVERSATION ON 07-14-2020

**Rusty Branch**: Good morning. 
WFH stopping all non emergency surgeries on Thursday...do you foresee a return to shut downs?

**Jeff Bergosh**: Did that just happen?!?  I have not heard that

**Rusty Branch**: Last night it was shared. 

**Jeff Bergosh**: Is it statewide or just locally?

**Jeff Bergosh**: I am worried about another shutdown

**Rusty Branch**: Just that hospital. 

**Rusty Branch**: But others will likely feel forced to follow their lead.

**Jeff Bergosh**: DeSantis under pressure—-particularly if hospitalizations/deaths increase

**Rusty Branch**: Yep. 

How much y’all paying this guy to read slides?!? 

**Jeff Bergosh**: Like $130K

**Rusty Branch**: 😳

**Jeff Bergosh**: Great work if you can get it

**Rusty Branch**: I gotta go...going to start sucking up to Mrs. Gilley. 

**Jeff Bergosh**: I’m just seeing what’s happening in the other big states with restaurants closing again

**Jeff Bergosh**: Lol right!?!

**Rusty Branch**: We are about to be in trouble, I fear. 

**Jeff Bergosh**: If they shut the economy again we will go into a worse recession if not a depression

**Rusty Branch**: Don’t leave the market tho...it had a big recession built in.

**Jeff Bergosh**: You think so??

**Jeff Bergosh**: Down to 16,000

**Rusty Branch**: No way. But I track S&P with high growth mutual funds. The house always wins. 

**Rusty Branch**: Sacred Heart has 78 covid positive patients and will reenact a no visitation policy...but they aren’t planning to limit non emergency surgeries. 

**Jeff Bergosh**: I hope you’re right on the stocks.  I’m really rooting for our hospitals — that they can handle this surge....if they do, and don’t get over run— then just maybe we will get through this without economic devastation....

**Rusty Branch**: Yes sir. God bless you. 

**Jeff Bergosh**: Thanks Rusty.  God bless us all!!!

### CONVERSATION ON 07-15-2020

**Rusty Branch**: I thought Janice was against masks...how come she wearing one today? She got symptoms?

**Jeff Bergosh**: Yes I noticed that.  Or, does she know something we don’t know?

### CONVERSATION ON 07-22-2020

**Rusty Branch**: Dude, it is hilarious that to you have Dr. Saunders on with Janice...you are next level!! 

**Jeff Bergosh**: Thx

**Rusty Branch**: Martha thinks Janice is a bit of a clown show and I don’t think Janice disappointed her in that regard today.

**Jeff Bergosh**: LOL 

**Rusty Branch**: Let’s just love one another and that will fix everything. 

**Jeff Bergosh**: Yes I thought that was a somewhat different response

### CONVERSATION ON 08-03-2020

**Rusty Branch**: Good morning. Been doing some math over the weekend. And it appears to me when you all use TDT for infrastructure projects you are in-effect giving more LOST type dollars to D4 & D2 while taking away (or never realizing) LOST collections that could be spent in your district. We have Majority Opinion, Dr. Harper and State economist validating roughly $1 spent in marketing returns you $3 in taxes. When you use TDT for non marketing/non event expenditures you are reducing County (but primarily D1, D3 & D5) funds.

### CONVERSATION ON 08-06-2020

**Rusty Branch**: Janice & D4 got this covid under control, since March...🙄

**Jeff Bergosh**: Nobody has this under control

**Rusty Branch**: He can’t form a full sentence...😳

**Jeff Bergosh**: Which one-  both?  LOL

**Rusty Branch**: Your buddy to the left...sure his secretary told him what to say, he just can’t get it out. 

**Jeff Bergosh**: LOL

### CONVERSATION ON 08-19-2020

**Rusty Branch**: Heck of a race, congrats. 

**Jeff Bergosh**: Thx Rusty

### CONVERSATION ON 08-20-2020

**Rusty Branch**: Good morning. This item is coming up today and is based upon a July TDC meeting where numbers were presented that suggested there were in effect no TDT funds left. In August TDC met and finance dept folks said there was over $3million there & would easily be over $5million by years end. TDC recommended funding Visit thru the end of the year but that isn’t reflected at all on this item.

### CONVERSATION ON 09-03-2020

**Rusty Branch**: I see, this has become a Studer project. Good luck. 

**Jeff Bergosh**: They have to go through me to do it

**Jeff Bergosh**: 😎👍

**Rusty Branch**: Or just get three others. 

**Jeff Bergosh**: They don’t have 3 votes

**Rusty Branch**: Your board-mates will fold when time comes. They signaled that today. 
Good luck my friend. 

Also, ST isn’t the same as selling and then applying for triumph. ST can leave and city owns assets. Y’all wouldn’t have that relationship.

**Jeff Bergosh**: Thanks I know they will but I won’t 

**Rusty Branch**: 👍🏼

### CONVERSATION ON 09-04-2020

**Rusty Branch**: Good morning. I noticed last night that y’all purchased Turpin a new truck, $30k’ish from TDT. On Tuesday at TDC there was a long discussion about what we are really spending TDT on & this item was not mentioned. I have to doubt a truck was absolutely necessary at this moment & that spend could have saved two visitor center jobs that were cut during June. It would have also likely saved two applications for rent assistance. Little decisions like this have big ramifications and they get pushed to y’all all the time.

**Jeff Bergosh**: Thx for the heads up Rusty

### CONVERSATION ON 09-05-2020

**Rusty Branch**: Good morning. The locals not going to be happy today, they all trying to get to their beach...I wished they had listened to you, but you know some minor re-striping will solve all the issues!! Haha

**Jeff Bergosh**: Wow!!

**Jeff Bergosh**: Nightmare

**Rusty Branch**: Going to get worse and not many tourist at the beach this weekend. This is all locals. 

But of course your counter part knows what you need in Beulah but you are clueless about beach issues.   

**Jeff Bergosh**: LOL right!!

**Rusty Branch**: Still backed up at 7:30. Crazy stuff.

**Jeff Bergosh**: Wow!!  Even at 7:32??

**Rusty Branch**: Yep. Haven’t seen that in a while. 

Hope you and yours are having a great weekend, blessings my friend. 

**Jeff Bergosh**: Same to you Rusty!  BTW— we’re still attending church online remotely— are you all going live yet??

**Rusty Branch**: Yeah, we started back when they reopened and stared sending the kids to Sunday school last week. It’s been good.

**Jeff Bergosh**: We’re still online but I’m looking forward to in person

**Rusty Branch**: I will be glad to see you. 

**Rusty Branch**: Crowds have stagnated some since they went back to 9:30 & 11 services.

**Jeff Bergosh**: Thx.  Likewise!!

### CONVERSATION ON 09-08-2020

**Rusty Branch**: This is BS, you know H&H helps the working poor...the one group tax dollars should help. 

**Jeff Bergosh**: Agreed

**Jeff Bergosh**: But I’m muzzled on it

**Rusty Branch**: When he uses TDT for infrastructure (only in d2&4) and not marketing, it prevents the generation of more LOST that could be spent in your district. 

**Jeff Bergosh**: Not a bad point

**Rusty Branch**: Does he understand how marketing works?!?

**Jeff Bergosh**: Which one?

**Rusty Branch**: D4

### CONVERSATION ON 09-09-2020

**Rusty Branch**: Good morning. Heck of a meeting last night. I would be very interested in hearing your plan for the 5th cent. 

Also, still think that was a jacked up move they pulled on Health & Hope last night. We supported that organization for years and saw its very good work. 

**Jeff Bergosh**: Thx Rusty!  I like the resolution that stipulates half goes to marketing and half goes to a sporting venue supporting a professional team which is allowable under the statute

**Jeff Bergosh**: 
And I agree they should give more to Health and Hope clinic unfortunately I can’t advocate because of the position SALLY holds but I wish someone would let these guys know that every indigent or working poor person that that clinic services saves the county money on Medicaid reimbursements that the federal government has foisted on the county via the state but I guess that’s only a good talking point we were giving community Health Northwest a half $1 million

**Rusty Branch**: The professional sports franchise would be interesting. The bay center contract is so poorly executed for the county that you all could do a lot if you rebid that deal...but it would require someone like you, who has owned a business, to negotiate a good contract or we will be right back in the same mess. 

### CONVERSATION ON 09-10-2020

**Jeff Bergosh**: You are right.  I do believe the board will take a more active role in that effort this go round 

**Rusty Branch**: I sure hope, to many “friends” getting taken care of by county administration. But unfortunately, in the meantime and with the potential of another Bay Center taking 1/3 of TDT funds tourism compression will continue to decrease causing more loses in town and diminishing the returns. It will also cause a continued loss of market share. 

**Jeff Bergosh**: I think will do our part to prevent that to the extent we are able.

**Rusty Branch**: I know you guys understand revenue importers and revenue exporters. Whatever the dialogue is, the actions should always be (if we are thinking about this like a business) to support revenue importers. We really only have two of those industries to speak of in town and unfortunately we rarely incentivize them and often neglect them. It is without doubt why are county lags in so many measures. You are the lone hope on the board for me at this time to think more strategically, rather than defensively.  

**Jeff Bergosh**: I’m in a ternal optimist I think the best days are coming and I think we’re on the verge of a real turning point once we get past Covid

**Jeff Bergosh**: Thanks for the kind words Rusty

**Rusty Branch**: I like your optimism. I’m the opposite. Navy Fed will continue to poach otherwise employable locals causing staffing issues across the county. Commercial leasing will stall and business travel will be dry for 1.5 years causing low skill hospitality workers to lose jobs and thus becoming more dependent on the system that locally is completely over burdened. Janice’s compete lack of managerial skills coupled with Grover’s inability to say no will render local government inadequate to execute. And Bender has been allowed to raid marketing dollars that could actually have a ROI from a tax generation perspective for the whole county so he can get some personal district projects. I think it will be a lean couple of years at a minimum. And all our Triumph money is locked up in an industry that will be dead for at least 2 years and thus far has only created 143 jobs (not that anyone could have seen that coming, just an unfortunate reality). 
But I hope I am completely wrong. 

**Jeff Bergosh**: I believe you are

**Jeff Bergosh**: ...... but again I’m a glass half full kind of guy😎👍

**Rusty Branch**: Right on!! Have a great day. 

### CONVERSATION ON 09-24-2020

**Rusty Branch**: The lack of discipline just showed is a serious issue for you all going forward.

**Rusty Branch**: Well stated!! 

**Jeff Bergosh**: Thx

### CONVERSATION ON 09-29-2020

**Rusty Branch**: Good morning sir. I was wondering if you might be supportive of postponing the 5th cent discussion until the lodging industry can better ascertain the short and long term losses it will realize as a result of covid & the hurricane? This bridge being out will have a significant impact on the lodging industry and our community and avoiding anything that might further  destabilize it at this point, in my opinion, should be avoided. Thanks for considering this.  

**Jeff Bergosh**: Rusty I think that’s a fair conversation to have but I think we have to put everything back on the table then if we’re gonna talk about pulling the fifth cent back. I say that because some of us voted on the last decision on funding Visit Pensacola with the thought that we would have the additional revenue coming from the fifth cent.  It will have to be a much broader conversation

**Rusty Branch**: I understand. Unfortunately I think we are looking at a difficult year due to the bridge being out, tho some think that might create an semi-exclusive tourism hot point at Pensacola Beach. I don’t know if that’s correct, but I know the industry is in a bad way and with 20k plus jobs depending on this industry it could use any help possible. Also, beach declines mean big declines in town. Thanks for considering this. I appreciate you. 

### CONVERSATION ON 10-04-2020

**Rusty Branch**: Happy Sunday afternoon, I hope the weekend has treated you well. Now that the deed is done on the 5th cent, I agree with you it is time to get a sports facility done. Let me know how I can help you as the process unfolds. 
Cheers and Go Padres!!

**Jeff Bergosh**: Thanks Rusty!  That was a great game— can’t believe they took the Cardinals out.  Yes, let’s get the new facility— appreciate the support on that!  Have a great Sunday Afternoon

### CONVERSATION ON 10-23-2020

**Jeff Bergosh**: Congratulations on your new position with The Hive— nice writeup in the PNJ!

**Rusty Branch**: Thank you sir. Hope all is well with you. 

**Jeff Bergosh**: 👍 thanks so far so good!  

**Jeff Bergosh**: Do u have time for a quick call?

**Rusty Branch**: Yes

### CONVERSATION ON 10-26-2020

**Jeff Bergosh**: Hi Rusty— just checking in to see if you were able to speak with Julian about the upcoming fundraiser for Christmas at the Clinic?  Thanks very much— 
SALLY and I greatly appreciate anything you all could do to help!

**Rusty Branch**: I didn’t get to see Julian today, but spending all day with him tomorrow in a plane, so I will speak with him about then.

**Jeff Bergosh**: Thx Rusty!

### CONVERSATION ON 10-28-2020

**Rusty Branch**: Good afternoon. Any chance you could meet Julian, Ted & I either tomorrow or Friday? We could meet at either the Innisfree Jet Center or the Hyatt at the Airport. Like to discuss supporting the Health & Hope clinic. Thanks

**Jeff Bergosh**: Sure Rusty.  Friday would work well— would lunchtime work?

**Rusty Branch**: Mg

**Rusty Branch**: Sorry, pocket text. Just confirming lunch works for Ted & Julian.

**Rusty Branch**: Apologies, Julian has a lunch meeting with Grover & the mayor of Savanah, GA on Friday. He is available from 2:15 to 3:30 on Friday, does that work for you?

**Jeff Bergosh**: Sure.  Are we meeting at the Hyatt airport?

**Rusty Branch**: Yes Hyatt Airport, thanks. 

**Jeff Bergosh**: Sounds good I’ll be there at 2:15.  Let me know if I should bring Sally as well, to detail all the great things the clinic does in our community😎👍

**Rusty Branch**: I think you will be able to cover it well enough, so no need to pull her away. Thanks and we will see you Friday.

**Jeff Bergosh**: 👍👌

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Did you see the agenda yet?  Large expenditure at the beach — $600K coming out of congestion management plan.......what’s the scope of work though?

**Rusty Branch**: Sorry for the slow response, been in meeting all morning. Thanks for the heads up. I will ask Mr. Bender. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-05-2020

**Rusty Branch**: Beyond silly if you all allow that guy to lead on this big of an issue. 

### CONVERSATION ON 11-06-2020

**Jeff Bergosh**: As you saw he doesn’t get to lead anything —-we’re gonna watch every step of the way and when necessary we’re going to hire a firm to get every penny that we deserve because we are taking losses because of FDOT’s project.  Also —wanted to say thanks for the room night donations to Christmas at the clinic. Please express my appreciation to Julian for helping with that effort. Even though we’re living with Covid and the world is upside down, it looks like we’re gonna break last year‘s record in fundraising for that very worthy cause—— so thanks for your assistance with that!

**Rusty Branch**: Good plan but signaled him as the leader and he will take over chairmanship soon. The Robert & Janice show has come to town. 

I will also make the room donation to any Innisfree property which opens it to Amelia Island, Coco Beach, Sarasota, Panama City Beach, FW Beach and Orange Beach. 

Also, I would like to push you hard for Children’s Service council board appointment...you cool with that? 

**Jeff Bergosh**: I’d really like that but I’m sure that will face resistance.  The Powers that be will want Lumon May in that slot and their fallback will be Stephen Barry as a former chairman of the Escambia County public schools foundation. They know I have too often questioned the status quo in education and so therefore they will push back hard on that.  Plus Malcolm will continue to exert his influence against me as he was really against the appointed superintendent and can’t believe we got that over the line and that I was the proponent of that for many years.  but I would love nothing more than to be a part of that so that we can do what’s necessary to fix the social dysfunction that drives these issues into the classrooms and ultimately into the quart rooms.  By the way who makes the appointments? Is that something we will do as a board of County commissioners?

**Jeff Bergosh**: *court

**Rusty Branch**: Yes, your board will appoint a member. We will encourage Lumon to not do it in hopes of getting funding for his programs. You are a natural fit in my opinion. We will pull completely back and not pull a Quint and want our people at the table, I just want the best people at the table and trust they will do the right thing. 

**Jeff Bergosh**: Thanks Rusty— Is be honored and humbled to serve!  And I may have a shot if Lumon does not actively lobby for it

**Rusty Branch**: Lemon cares more about that potential money. 

**Rusty Branch**: We will push for you all to appointment your member quickly in the initial five required spots so be ready for that. 

If for some reason you don’t get appointed, Sally needs to apply for an at large position.

**Jeff Bergosh**: Thanks Rusty!!!

### CONVERSATION ON 11-19-2020

**Rusty Branch**: Good morning. We have been working several angles and you are the clear front runner for Children’s Trust board. Just wanted to keep you updated. 

**Jeff Bergosh**: Outstanding!  I’m extremely humbled if this comes to be!

**Rusty Branch**: And once on, you will need to be chairman for some strategic reasons, we will work on that as well. Things are coming along nicely. Had a of call with Janice Gilley this morning. 
Have a great Friday.

**Jeff Bergosh**: That would be outstanding!

### CONVERSATION ON 11-20-2020

**Rusty Branch**: Quick question. Can the county or any government entity get a loan from a commercial entity...ie. Hancock Whitney? 

**Jeff Bergosh**: Yes —- but not sure why they would when they could bond money at a lower cost

**Rusty Branch**: What does bond mean, exactly? 

**Rusty Branch**: The Children’s Trust will need start up money. Most get loans from County. 

**Jeff Bergosh**: Funds can be bonded against anticipated revenue.  In this instance- the revenue is ad valorem that is bondable.  

**Jeff Bergosh**: Autocorrect

**Rusty Branch**: Ok, you & I may need to talk prior to your appointment, which will likely be early December. 

**Jeff Bergosh**: Right on.  Hope you and yours have a Happy Thanksgiving!

### CONVERSATION ON 12-02-2020

**Rusty Branch**: The “bug” portion of your session this morning was hilarious. Escambia County is a shameful mess.

**Jeff Bergosh**: Crazy stuff happening but not a shameful “mess”....good things happen daily as well they’re just not reported.

**Jeff Bergosh**: But do we have some issues—- well, yeah

**Rusty Branch**: You are always so optimistic...I love that!!

Tho, I think we have a low bar for “good things” in Escambia. Since joining Innisfree and meeting with leaders in other markets I have realized how low the bar is. 

### CONVERSATION ON 12-03-2020

**Rusty Branch**: You have time to chat this morning about the Children’s Trust?

**Jeff Bergosh**: Sure-  in a mtg now but I’ll call u after

**Rusty Branch**: 👍🏼

### CONVERSATION ON 12-08-2020

**Rusty Branch**: If you have a minute after the mtg, please given me a call. 

**Jeff Bergosh**: Will do

### CONVERSATION ON 12-10-2020

**Rusty Branch**: Y’all could vote to have DOR collect TDT and take that responsibility off of the Clerk. DOR is actually the default collector, y’all had to vote to have Clerk collect TDT in the first place. 

**Rusty Branch**: Good evening. I couldn’t watch tonight, did they appointed you to children’s trust or did y’all postpone that?

**Jeff Bergosh**: Lumon expressed a significant wish to do it—so in the interest of congeniality I bowed out and recommended him.  Otherwise it would have been a 2-2 vote for me and it would have failed.  You’ll have to watch the morning review video.  It’s all good though— appreciate the thought and the confidence you all had in me!

**Rusty Branch**: Well he will get off other boards and sign non-conflict agreements. This isn’t like other boards, I suspect he bows out soon enough or that board won’t be able to fund his pet projects. 

**Jeff Bergosh**: Well I’m hoping I can get appointed.  I’d love to serve

### CONVERSATION ON 12-11-2020

**Rusty Branch**: I wished you wouldn’t have thrown me under the bus talking to Lumon about the trust board...but hey them’s the breaks sometimes. No hard feelings and I do hope you get appointed, I think you can truly make a difference. Blessings my friend. 

### CONVERSATION ON 02-05-2021

**Rusty Branch**: Good morning. Are you allowed to share the list with the names of the children’s trust applicants? Also, I’m not sure why one BCC continues to say you all “levied this tax” but that is wildly incorrect...anyways, thanks 

**Jeff Bergosh**: Sure- it’s a public record

**Jeff Bergosh**: Do u want me to send u the list?

**Rusty Branch**: That would be great. Thanks 

**Jeff Bergosh**: https://jeffbergoshblog.blogspot.com/2021/02/blog-post_57.html?m=1

**Rusty Branch**: Well duh...I should have checked your blog. Thanks 

**Jeff Bergosh**: LOL

**Rusty Branch**: Solid list. Janice didn’t think we would get 10 applicants...I assured her we would get plenty. 

**Jeff Bergosh**: I agree

**Rusty Branch**: You might not share and I don’t have any preferences or recommendations, but do you have two names you will submit for children’s trust? Completely understand if you don’t want to share that info, just curious and hopefully for good candidates to go to Tallahassee. 

**Jeff Bergosh**: Having a hard time narrowing it down.....there’s five I want to vote for

**Rusty Branch**: Well after seeing you pick Brigette Brooks for SRIA, I would put you at the top of people pickers in Escambia. 

You are our local George C. Marshall (the best picker of men this country has ever had)!!

**Rusty Branch**: Good luck. 

**Jeff Bergosh**: Thanks Rusty!!

### CONVERSATION ON 02-10-2021

**Rusty Branch**: Good morning. I hear y’all’s lobbyist is retiring...I would encourage you to ensure the next lobbyist you hire is an “appropriations” lobbyist. Makes all the difference. 

**Jeff Bergosh**: Agreed!

### CONVERSATION ON 02-18-2021

**Rusty Branch**: Would really like to have Jason Nicholson on the TDC. Innisfree is the largest TDT collector in the County and hasn’t had a TDC board member in several years. Thanks 

### CONVERSATION ON 02-19-2021

**Rusty Branch**: Good old D4 stepped in where you were having trouble. He really is a life saver. 

**Jeff Bergosh**: LOL 

**Jeff Bergosh**: I hope that’s sarcasm Rusty 

**Rusty Branch**: It was 😉

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-25-2021

**Rusty Branch**: 2 at large is a freakin Brilliant move!!

**Jeff Bergosh**: Thx we will see where the conversation goes

### CONVERSATION ON 03-26-2021

**Jeff Bergosh**: I thought it was a worthwhile idea but there was no appetite whatsoever from my peers During our Meeting yesterday. unfortunately they’re very comfortable with the status quo.

**Rusty Branch**: You opened the door. That’s all that was needed. 

**Rusty Branch**: Great job. 

**Jeff Bergosh**: Thanks for the kind words Rusty have a great weekend!

### CONVERSATION ON 04-14-2021

**Rusty Branch**: Good morning sir. We need to get this Bay Center thing right and we need an adjacent open floor concept bldg next door. A committee of true developers and interested parties could help your board out tremendously.

**Jeff Bergosh**: I agree

### CONVERSATION ON 04-15-2021

**Rusty Branch**: Why would they reach to stay afloat when you all are always going to float them. The county has continued the worst operational contract maybe in history and their leaders get bonuses every year while losing millions at the facility. 
However, it’s fun to watch 😁

**Jeff Bergosh**: I want to get over the hump and negotiate a performance-based contract with them with metrics make it as efficient as possible and I’m all for that Rusty. Matter fact I’ll probably lean on your opinion and expertise as well when I get a crack at it. Meanwhile I’m a realist and I understand these venues typically operate in the red. It’s not uncommon and many quality-of-life amenities in a community don’t generate profit

**Jeff Bergosh**: Most don’t

**Rusty Branch**: Understand, plus your peer set is collectively low grade on the business acumen. 
On another issue (between only you & I) are there any local incentives you can think of for someone looking to do a couple of projects in the county, roughly $100 million in private development resulting in 400 plus jobs? 

**Jeff Bergosh**: That sounds intriguing.  I believe there are those sorts of incentives but it all depends on the average wage paid-so the higher the wages the better the incentives.

**Jeff Bergosh**: Would love to know more if you are at liberty to discuss

**Rusty Branch**: I am not right now (NDA) but that is good info. 

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-28-2021

**Rusty Branch**: Good afternoon. Have you been meeting with Darien Schafer? Is he supportive of doing something with the Bay Center? 

### CONVERSATION ON 04-29-2021

**Jeff Bergosh**: I actually spoke to him at length yesterday afternoon.  Give me a call today and we can discuss

**Rusty Branch**: Good deal. 

**Rusty Branch**: Good time to call? 

**Jeff Bergosh**: Sure

### CONVERSATION ON 05-12-2021

**Rusty Branch**: Did the doctor say this morning she serves as many people as Denver, Co??

**Jeff Bergosh**: Yes. In mtg will call u after

**Rusty Branch**: Thanks, want to run an SRIA issue past you and set up a time to meet about the Bay Center. 

**Rusty Branch**: Just wanted to check in on your availability to chat today?

**Rusty Branch**: Thanks for you help today. Productive meeting tonight.

**Jeff Bergosh**: Glad to hear that

**Rusty Branch**: Let’s talk soon. Thanks again

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-26-2021

**Rusty Branch**: Hey buddy. Well, Campanella back tracked on the policy amendment that they voted 6-0 for staff to change and Brigette wouldn’t make a motion to support the item. Feels like we are back at square one. 

**Jeff Bergosh**: Sorry to hear this Rusty.  I think they should waive that fee as we discussed 

**Rusty Branch**: Yeah, hopefully they still will. Just updating you. Have a good evening. 

### CONVERSATION ON 06-03-2021

**Rusty Branch**: Good ol’Pam keeping y’all out of trouble. 

### CONVERSATION ON 06-04-2021

**Jeff Bergosh**: 👌

**Jeff Bergosh**: But those who were there know what really happened

**Rusty Branch**: I watched the entire meeting She was holding cards, strategically hoping y’all would bring it to a vote and then she was going to pour cold water on Barry & May for causing so much trouble for her ally Janice. Easy read on that one. 

**Jeff Bergosh**: But she waited for me to do it, which is not unlike watching your best friend get his ass kicked in a bar fight by multiple persons and not doing anything to help, then after your best friend fends off the attacks and takes his lumps—with no help from you—-you tell your friend. “Don’t worry I had your back and I wasn’t going to let them kick your ass!”  “I had your back I tell ya!!”

Yeah right

**Jeff Bergosh**: Which those of us with brains spotted very, very quickly

**Rusty Branch**: I don’t think so. I don’t think she wanted you to do what you did. She wanted it tee’ed ip for a last second, almost vote save. 
She isn’t concerned about having your back. 

**Jeff Bergosh**: Don’t worry though, PNJ will write up a piece giving her all the credit for shutting down the issue——even though you and I both know the issue was settled before she even opened her pie hole 

**Jeff Bergosh**: That’s very apropos

**Rusty Branch**: You could have had all the glory, but you were a little too soft on Barry & May saying you wanted to support them...and thus left the door open for her to slam it. 
You did the hard work but your sympathy to those guys when everyone was hating them was just enough for her to be a hero. 

**Jeff Bergosh**: She’s no hero.  Only a low IQ viewer could assess it that way.  I shut it down in deft fashion, to the point that Barry withdrew the motion........THEN she rides in on the white horse.  It was poor form.  She should have kept her hole closed, didn’t concern her by that point.......but hey, you see it differently and reasonable people can disagree

**Jeff Bergosh**: Have a great weekend

**Rusty Branch**: Well then, there are a lot of low IQ people in this community then. I have talked with dozens of people last night and this morning and they only spoke of her assertiveness. 
You did the heavy lifting and you should have crushed those guys in grand fashion...they aren’t good public servants.

**Jeff Bergosh**: There are lots of them

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-10-2021

**Rusty Branch**: Man I know you were just making a non tax increase point on the economic development issue today. I mean on Navy Fed just the infrastructure costs alone of the employees who moved here will never make that a net income scenario for the County and you add in the facility itself the loses are astronomical. But you already know that.

**Jeff Bergosh**: ?

**Jeff Bergosh**: I hope so 😂

**Rusty Branch**: Not a chance, some elementary reading on the topic will show those costs far out weigh benefits. 

**Rusty Branch**: Politically you have to do it. But not a money win at all. 

**Jeff Bergosh**: You’re smoking crystal if you think That bringing Navy Federal credit Union and they’re 1.2 billion in infrastructure investment 10,000 jobs and a half $1 billion payroll yearly was anything but a grand slam home run that far exceeds everyone’s wildest expectations and is nothing but a huge win and more than justifies any costs associated with acquiring that deal

**Rusty Branch**: Sorry just walked into the Superintendent’s office...your old stomping grounds. 

**Rusty Branch**: Bigger costs to the tax payer than that investment. Easy math. Talk to you later. 

**Jeff Bergosh**: Call when u can so I can educate you on how NFCU is a huge win

**Jeff Bergosh**: Easy math

**Rusty Branch**: I will but you can’t, it’s a loser for the tax payer. 

**Jeff Bergosh**: Don’t know where you’re getting that but it’s incorrect Rusty

**Jeff Bergosh**: Who is this, Doug?

**Rusty Branch**: We will chat, easy math. It’s why individual businesses always ask governments to do this and never do these deals themselves. 

**Jeff Bergosh**: Incorrect Rusty

**Jeff Bergosh**: But yeah— if this is really you and not Doug——-let’s talk

**Rusty Branch**: Look up one scenario where it is different and we will chat about it. 

**Rusty Branch**: Haha...you easy to spin up these days. Have a good one 😂

**Jeff Bergosh**: LOL 

### CONVERSATION ON 06-17-2021

**Rusty Branch**: What a day!! 

**Jeff Bergosh**: Yes

### CONVERSATION ON 07-06-2021

**Rusty Branch**: Good morning. Hope you are doing well. I was wondering what you think will be the county’s top request from Tallahassee this upcoming legislative session? 

**Jeff Bergosh**: Hey Rusty.

—Full Funding for constructing the Beulah interchange

—funding for construction of a 4th lane on Pine Forest Road between I-10 and 9-Mile road

—Liberalization of our ability to make Medicaid claims on incarcerated individuals

—relief from cost shifting on unreimbursed medical care

—relief from the assault on home rule via overly restrictive legislation

—relief from unfunded mandates

—more state dollars for our state roads in D-3

**Jeff Bergosh**: ....to start with

**Rusty Branch**: Nice…that looks like a solid list. 

**Jeff Bergosh**: There are more things we need that we will add to the wish list

**Rusty Branch**: No doubt the list of needs is long. 

### CONVERSATION ON 07-12-2021

**Rusty Branch**: Good morning/afternoon. I heard the conversation about a sports facility at your board meeting last week and specifically Steven’s request for someone to bring a plan. You should form a committee of industry experts to explore options. 

**Jeff Bergosh**: Not a bad idea.  But wait:  what about Jay Patel and his plans?

**Jeff Bergosh**: I haven’t seen him for awhile— like he disappeared into witness protection or something 

**Rusty Branch**: I think Jay certainly has ideas and y’all should consider them. I am just suggesting you put together a group of developers, sports tourism folks, finance people and let them generate and/or review ideas. 
Folks like Jim Cronely, Bruce Vendenburg, Julian MacQueen, Judy Bense, etc. 

**Jeff Bergosh**: I’m all for it

**Rusty Branch**: It would be a good move for you to be the one activating those folks. 

**Jeff Bergosh**: That’s a good point

**Rusty Branch**: It was also make you the consensus/bridge builder on that board. 

**Jeff Bergosh**: Now why the heck would I want to do that though?  I’d much rather crash blimps into the Pensacola Beach Water tower!

**Rusty Branch**: Good point…scrap my previous idea and burn it all down 😂

**Jeff Bergosh**: LOL

**Rusty Branch**: I couldn’t believe we never got over 17.7k cars this weekend onto the beach. 

**Jeff Bergosh**: I was there Friday and Sunday and it was packed

**Rusty Branch**: Some of the restaurants didn’t do as well as expected, but Innisfree had a good weekend. We had a full band on stage between water pig & red fish blue fish. People loved it. 

**Jeff Bergosh**: That’s awesome!

### CONVERSATION ON 07-20-2021

**Rusty Branch**: Good morning. Was thinking that if Janice runs Doug’s appropriations shop she will likely low key punish you all. You need to buffet that by hiring a lobbyist with a personal connection to her so that she will want to help that person. There is an option for this if you want it. 

**Jeff Bergosh**: That’s not a bad idea

