

## CONVERSATIONS WITH LUKE BALL

### CONVERSATION ON 04-24-2020

**Jeff Bergosh**: Good Morning Luke--this is commissioner Jeff Bergosh from Escambia County.  We spoke last week about having Congressman Gaetz on our Wednesday coffee at 7:30AM Eastern Time this coming Wednesday morning the 29th.  Is there a particular email address that I can send the call in information?  And, can the Congressman use Microsoft Teams if we do it on that platform?  I understand he doesn't use the zoom platform.  Please let me know and thanks!

**Luke Ball**: Hey Jeff, is there any chance we could push the meeting back in the morning to maybe 9amCT? Or even do a special update from the congressman for about 15 minutes on another video?

**Luke Ball**: If you're able to do a separate video, we can share on our social media platforms too

**Jeff Bergosh**: Luke a separate video could work.  If you could send it to us we will play it at the coffee meeting and then expound in the topics.  Would he give us just like an update/overview of Federal response to COVID-19?

**Jeff Bergosh**: Would much prefer to have it with him live but I know that 6:30 time is early

**Luke Ball**: If you can host a separate video just like you normally do at a later time, I can have him call in and you can ask him some questions on video with him on speakerphone that we will then share to our Facebook audience

**Jeff Bergosh**: That would be great!  

**Jeff Bergosh**: 9:00 our time, CT?

**Luke Ball**: Yes sir - 9amCT on 4/29 via speakerphone for about 15 minutes

**Jeff Bergosh**: Perfect.  I'll mark it down and get the call in information sent over to you.  If it's alright, I'd like to schedule a test run with you on Monday afternoon--just a one minute test.  Would that be alright?  

**Luke Ball**: Works for me, just let me know what time

**Jeff Bergosh**: Okay thanks very much Luke!

**Luke Ball**: Yes sir!

### CONVERSATION ON 04-27-2020

**Jeff Bergosh**: Luke--I'm setting up a test call on Microsoft teams just to ensure it will work well for the 9:00 Wednesday chat online with congressman Gaetz.  I'll shoot for this afternoon if that works for you--just give me a good email address where I can send your invite credentials for log in

Thanks!

Commissioner Jeff Bergosh 

**Luke Ball**: Ok - the Congressman will be calling in on your cell phone's speakerphone. Are you testing the audio on Microsoft teams? 

**Jeff Bergosh**: Yes

**Luke Ball**: Ok - my email is luke.ball@mail.house.gov

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-29-2020

**Luke Ball**: Since it's just you talking to him, can you just not display the screen and have the camera just facing you? With his audio playing through the computer?

**Jeff Bergosh**: That's exactly what we're gonna do we've got it solved so he'll be getting a call for me from an 850 number at about two minutes till and there will be no display

**Luke Ball**: Sounds good 👍

**Luke Ball**: Looked great Jeff - thanks so much! We shared on our page

**Jeff Bergosh**: Thanks Luke!!

