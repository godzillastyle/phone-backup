

## CONVERSATIONS WITH CHORUS NYLANDER

### CONVERSATION ON 11-07-2019

**Jeff Bergosh**: The county continues to  cooperate with an ongoing state investigation that includes the gathering of records, some of which are housed at the public safety building. 


Official county response

**Chorus Nylander**: FDLE tells us it's not FDLE do you know the agency?

**Jeff Bergosh**: Unsure--sorry if I misspoke, that's who I was initially told was there

**Chorus Nylander**: Nvm FDLE is now confirming it

**Jeff Bergosh**: Okay so I was right 😎

### CONVERSATION ON 11-08-2019

**Chorus Nylander**: Good morning. Can you give us more about the FDLE raid of public safety?

**Jeff Bergosh**: Sorry Chorus no new information to pass as of yet.

### CONVERSATION ON 03-17-2020

**Jeff Bergosh**: Hey Chorus we're playing phone tag. Anyway I'm gonna be up at the emergency operation center at 11:30 so please let me know you got this message.... apparently there will be a 12 noon press conference with the county and Dr. Lanza and it's my intention to be there for that

**Chorus Nylander**: Keeps going to voicemail. Yes i will be there

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-13-2020

**Chorus Nylander**: Could I talk to you about the rat apocalypse today? Sounds serious I want to know what is being done to protect the citizens of Escambia County from a rat army invasion? Should we surrender now will they spare us? 

**Chorus Nylander**: Just kidding 

**Jeff Bergosh**: LOL

**Jeff Bergosh**: Funny right??

**Chorus Nylander**: Crazy but logical after thinking about it. There's probably a whole ecosystem dependent on our routines so when we shut everything down probably has a much bigger impact than we would think. 

**Jeff Bergosh**: Yeah.... but who knew they were people that study this stuff?!?  I just thought it was a funny read

**Chorus Nylander**: Very funny 

### CONVERSATION ON 04-17-2020

**Jeff Bergosh**: 4 minutes out

### CONVERSATION ON 07-15-2020

**Jeff Bergosh**: Can I call you later?

**Chorus Nylander**: Yes

**Jeff Bergosh**: Sure

**Jeff Bergosh**: In meeting

**Chorus Nylander**: Let me know when I can call you 

**Jeff Bergosh**: I can step out

### CONVERSATION ON 07-20-2020

**Jeff Bergosh**: I'm in a meeting I'll call u back

**Chorus Nylander**: Can we grab an interview with you. Wanted to ask you (trying to ask all Commissioners) about views on making a mask mandate now after many big brand stores release policies of their own 

**Jeff Bergosh**: Back to back meetings till 1:15--could meet u after that

**Chorus Nylander**: Yeah would 1:30ish be possible 

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I'll be there

**Chorus Nylander**: Ok. That works. Thanks

### CONVERSATION ON 10-15-2020

**Jeff Bergosh**: Are you all in the lobby?

**Chorus Nylander**: Yes

**Jeff Bergosh**: Okay I'll meet you out there right after this meeting 

**Jeff Bergosh**: Chorus-- I misspoke.  The address is 2906 N. Palafox street

**Chorus Nylander**: Got it. Thanks

