

## CONVERSATIONS WITH NELS PALM

### CONVERSATION ON 02-09-2021

**Jeff Bergosh**: Nelson just want to know if we got an all clear

**Jeff Bergosh**: Some of our early arrival folks it's time for them to go home

**Jeff Bergosh**: For exit too?

### CONVERSATION ON 06-17-2021

**Jeff Bergosh**: Nels does this include the subcontractors as well?

**Jeff Bergosh**: This is Jeff Bergosh from eLE

**Jeff Bergosh**: Okay thanks for the good news 

### CONVERSATION ON 06-18-2021

**Jeff Bergosh**: Hope you all are staying cool.   120 degrees!!

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Nels the line is fixed we’re back up and running

**Jeff Bergosh**: No— thanks you!!

**Jeff Bergosh**: Yes!!!

