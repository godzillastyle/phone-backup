

## CONVERSATIONS WITH MELISSA BROWN

### CONVERSATION ON 01-08-2020

**Jeff Bergosh**: In a mtg can I call u back ?

**Melissa Brown**: Absolutely,  I left you a voicemail. 
Call me back at your convenience.  I should be available most of the day. 

### CONVERSATION ON 01-10-2020

**Jeff Bergosh**: Hi Melissa this is Jeff Bergosh wanted to let you know I did not forget about your issue I've spoken with staff and I've spoken with others associated with DR Horton and I'm still working on the issue. It will probably be at some point next week when I will get back up with you and we can discuss this in detail. I hope you have a good weekend and I look forward to speaking with you next week thank you

**Melissa Brown**: Thank you for touching base with me.¿I completely understand that this will take some time. I appreciate all of your efforts. ¿As long as no one is building a house too close to my wetlands and my horse fence is still standing I am happy.¿I hope you have a great weekend as well! 

### CONVERSATION ON 01-13-2020

**Melissa Brown**: Hey Jeff,
Hope your Monday is starting out well. 
I just got an email from the Developers attorney.  I wanted you to see it and get your opinion before I agree to go meet with them.
Thanks, 
Melissa

**Melissa Brown**: To be honest.. I feel like a pork chop walking into a Lion's den

**Jeff Bergosh**: Good morning Melissa I get it that it's somewhat intimidating. But I've been making calls and I do believe folks want to be reasonable and work with you. They can't force you to do anything so it might be in your interest to hear them out and hear what they have to say. Of course you will make that final determination but at the end of the day they can't do anything to you

**Melissa Brown**: Thank you for the advice Jeff. It's not like I haven't stood toe to toe with them before.¿I guess the constant pressure and harrassment from them is finally taking it's toll on me.¿Again, thank you for all of your help and advice.¿I will let you know how it goes!

**Jeff Bergosh**:  Please do--and good luck.  I look forward to speaking with you on this matter later in the week- just waiting for a couple more data points

### CONVERSATION ON 01-15-2020

**Melissa Brown**: Hey Jeff, I met with the attorney and his client.¿They just offered to rebuild that part of my fence.¿I counter offered by asking them to re fence the whole property line so that in the future there will be no question as to whose property is whose.¿The client said no but the attorney said that he should consider it. They are going to get back to me on their decision.¿I also brought up the fact that the houses in question are being built so close to the wetland area back there. The developer stuttered a bit, then said that the county is not considering it a wetland area.¿I assure you when I first purchased this property and wanted to clear out that wet weather area the county said absolutely not!! ¿Could you please explain to me why, when I wanted to make improvements to it, the county told  ,me no. But when a developer wants to build houses in it, it is absolutely ok?¿

**Jeff Bergosh**: That's an excellent question and I will find out. I hope they take you up on your offer I think that's fair. Can you please email me the map that shows the area that you believe is wetlands and I will have it checked thanks

**Jeff Bergosh**: Got it

### CONVERSATION ON 02-05-2020

**Melissa Brown**: Hey Jeff, this is Melissa Brown.  I live next door to the new subdivision Rock Ridge on Frank Reeder Rd.¿Who do I get in contact with to have these issues fixed? DR Horton or the county? ¿There is clay in both the front and back wetlands. And as you can see their silt fence has failed and clay is pouring on to my pasture.¿I know it was a heavy rain but these silt fences were already down before the storm.¿

**Jeff Bergosh**: Hi Melissa-- I am forwarding this text and these pictures to our environmental department and they will take appropriate action.  Thanks for bringing this issue to my attention.

Jeff Bergosh

**Melissa Brown**: Thank you so much! 

### CONVERSATION ON 02-06-2020

**Melissa Brown**: I understand that hard rains can make normally clear water look muddy. But both of these pictures were taken yesterday after the hard rain.
The muddy clay picture is the west (rock ridge) side and the clear picture was taken of the east (my) side of the wetland area. Where the clay hasn't reached just yet.
As you can see, the hard rain, did not stir up the water and make it muddy. It is the run off from the subdivision. 
I truly appreciate your help in this matter.
And you are welcome to give your environmental department my number if they need to reach me.

### CONVERSATION ON 02-08-2020

**Jeff Bergosh**: I will do this.  And, just so you know I am having a meeting on Monday afternoon at 4 PM with the county administrator the county engineer and multiple members of high-level staff.  In addition to the things we were going to discuss at that meeting ----I am also going to ask for specific information and solutions for the stormwater issues out in Beulah that have been exacerbated by these developments and their apparent inability to control the stormwater on their properties.  I will discuss the outcome of this meeting with you personally next week.  I hope you have a good weekend.

Sincerely,

Jeff Bergosh
850-293-1459

**Melissa Brown**: Thank you Jeff! And I hope you have a great weekend as well.

### CONVERSATION ON 04-15-2020

**Jeff Bergosh**: hi Melissa it's been a long day and I've been putting out a lot of fires today with the whole COVID-19 epidemic that we're dealing with but I did get these pictures and your text messages and tomorrow I will pass them on and speak with the builders representative and see what we can get done. I hope all is well with you!

**Melissa Brown**: Thank you! 

### CONVERSATION ON 05-03-2020

**Melissa Brown**: With county offices closed who would I contact about this.. they have a water pipe wide open flooding my property 

**Melissa Brown**: We can't even mow our damn pasture ...this is bullshit that we have to pick up their trash on a Sunday morning before we can mow!!!

**Jeff Bergosh**: Hey Melissa--I spoke with them last week when you messaged me.  Let me see if I can get a better response.  

**Melissa Brown**: We got the water stopped . Found someone on sight finally and he turned it off.¿The trash is still a daily problem.  I understand some construction trash here and there but I'm tired of picking up excessive construction trash.. and not to mention their lunch trays and beer/soda cans.¿They need to be fined.. ¿This is ridiculous!¿I appreciate your help!¿ 

**Jeff Bergosh**: I agree.  I'm on it!

### CONVERSATION ON 11-14-2020

**Melissa Brown**: Hey Jeff, this is Melissa Brown.  I absolutely hate to bother you on the weekend but I'm not sure who else to contact. I live on the north side of OLF8. 
I was wondering if you could please get Roads, Inc to lock this back gate at night and weekends when it's not in use.
There has been (I'm assuming kids) going out there in there in their trucks and doing donuts when nobody is out there 😭
I would appreciate any help you can give me. Or if there is someone else I need to contact please let me know.
I know kids just need to have a little fun but one truck almost flipped today and the noise at night is a bit frustrating😕

### CONVERSATION ON 11-16-2020

**Jeff Bergosh**: Melissa-- got it, thanks for bringing this to my attention.  We will get it secured.

**Melissa Brown**: Thank you so much!

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-09-2020

**Melissa Brown**: I know I normally text you with complaints..but just wanted you to know that, this long time Beulah Resident appreciates the fact that you are staying true to your original plan of bringing more jobs to our area and trying to minimize the residential building! 


**Jeff Bergosh**: Thank you Melissa!

