

## CONVERSATIONS WITH DAVID LOGAN

### CONVERSATION ON 02-23-2020

**Jeff Bergosh**: Oh my gosh!  Is it big?  I will get someone on it right away

**Jeff Bergosh**: I want to see it first though😎👍

**Jeff Bergosh**: Wow!!

**Jeff Bergosh**: I stop by to look at it he’s nowhere to be found he’s probably signing himself on the other side out of you I will call the administrator and we will get a wrangler out here to get them

**Jeff Bergosh**: Sunning

**Jeff Bergosh**: Wow that’s is for sharing

### CONVERSATION ON 02-25-2020

**Jeff Bergosh**: Hopefully they won’t kill him 

**Jeff Bergosh**: Thanks for the heads up

