

## CONVERSATIONS WITH DONNA LISTIN RYAN

### CONVERSATION ON 09-29-2021

**Donna Listin ryan**: Hey- are u at the condo?!

### CONVERSATION ON 12-24-2021

**Jeff Bergosh**: Thank you Joseph!  San Diego is not a bad place to be for Christmas!

**Donna Listin ryan**: Hi guys!! So much fun tonight. Mr. Jeff... I still haven't got the photo 😉

**Donna Listin ryan**: Not to be a pain in the ASS but I want to post a few photos on FB and I really don't have a good photo of just the girls so hoping Jeff's picture from the restaurant turned out good. So... when you can please send it to me. Thanks!! 👍😊😁😉

**Donna Listin ryan**: Thanks Jeff!!

**Jeff Bergosh**: Absolutely!  Merry Christmas!!!

### CONVERSATION ON 12-25-2021

**Jeff Bergosh**: Merry Christmas Mary!!

**Jeff Bergosh**: Merry Christmas!

**Donna Listin ryan**: Hahaha 🤣  That's great!!

Merry Christmas 🎄 

