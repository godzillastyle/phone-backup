

## CONVERSATIONS WITH JULIAN IRBY

### CONVERSATION ON 03-31-2021

**Jeff Bergosh**: Thanks Julian!  I look forward to having lunch with you and Gary and possibly Joe Riccio as well!

