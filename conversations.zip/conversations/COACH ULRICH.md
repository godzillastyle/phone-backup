

## CONVERSATIONS WITH COACH ULRICH

### CONVERSATION ON 08-18-2020

**Jeff Bergosh**: Thanks Coach— looks like I got the win by 8 points

**Jeff Bergosh**: 👍😎

