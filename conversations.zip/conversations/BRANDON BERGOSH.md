

## CONVERSATIONS WITH BRANDON BERGOSH

### CONVERSATION ON 10-22-2019

**Brandon Bergosh**: Hey dad,
 Sorry i couldn’t make your event tonight i had to work. Heard you raised a lot of money which is awesome! I love you pops

     -Brandon

### CONVERSATION ON 10-23-2019

**Jeff Bergosh**: Love u too Brandon—you missed a good one! Have a great week!

### CONVERSATION ON 10-29-2019

**Brandon Bergosh**: Wow that was quick

**Jeff Bergosh**: Gone!

### CONVERSATION ON 11-02-2019

**Brandon Bergosh**: Where are u?

### CONVERSATION ON 11-04-2019

**Brandon Bergosh**: Can u reimburse me for the work clothes?

**Jeff Bergosh**: We will, Friday when we get paid

**Jeff Bergosh**: Sorry, I can't talk right now.

**Brandon Bergosh**: I got in an accident

**Brandon Bergosh**: Answer

**Jeff Bergosh**: Do I need to leave this luncheon?

**Brandon Bergosh**: Dude

**Brandon Bergosh**: I need help

**Brandon Bergosh**: Answer

**Brandon Bergosh**: Her information & car

**Jeff Bergosh**: I don’t see anything at all Brandon?!?

**Jeff Bergosh**: Are you talking about there’s three small areas of chip paint above the license plate?

**Brandon Bergosh**: Correct

**Brandon Bergosh**: Not bad at all

**Jeff Bergosh**: Wow that’s nothing

**Brandon Bergosh**: I’m saying

### CONVERSATION ON 11-06-2019

**Brandon Bergosh**: The cat from that football game we watched is famous now haha

**Jeff Bergosh**: I know — it was on the news yesterday

**Brandon Bergosh**: In class, what’s up?

**Jeff Bergosh**: Hey-I’m wondering who’s on my Napster.  Guess it’s not you

**Brandon Bergosh**: Nope. Probably nick

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-14-2019

**Jeff Bergosh**: Do u still need cold medicine?

**Brandon Bergosh**: Plzz

### CONVERSATION ON 11-20-2019

**Jeff Bergosh**: Get off My Napster I’m on my lunch break trying to get a workout in I want to be able to listen to music y’all can have it back at 12:15

**Brandon Bergosh**: Im not

**Brandon Bergosh**: Im in class

### CONVERSATION ON 11-21-2019

**Jeff Bergosh**: Good night Brandon we love u.  Be nice to Rocky—see u in a couple of days!

### CONVERSATION ON 11-22-2019

**Brandon Bergosh**: Yes, way to rub it in😂

**Jeff Bergosh**: Goodnight Brandon we love u.  Hope everything is going well.

### CONVERSATION ON 11-23-2019

**Jeff Bergosh**: Are u at home Brandon?

**Brandon Bergosh**: Just got to work

**Brandon Bergosh**: Y?

**Jeff Bergosh**: I okay.  Just checking in to se. how everything’s going.  

**Jeff Bergosh**: Rocky is doing okay?

**Brandon Bergosh**: Rocky is good but i don’t think he’s been eating much which is a bit concerning

**Jeff Bergosh**: How about water,  have u been making sure he’s got clean water daily?

**Brandon Bergosh**: Yea i keep changing it out

**Jeff Bergosh**: Okay good we will see u tomorrow

**Jeff Bergosh**: Love you

**Brandon Bergosh**: Love ya too! When yall gettin back?

**Jeff Bergosh**: 9:00pm tomorrow

**Jeff Bergosh**: See u then, goodnight

**Brandon Bergosh**: Okay cool, goodnight :)

### CONVERSATION ON 11-25-2019

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Conceited 

### CONVERSATION ON 11-27-2019

**Brandon Bergosh**: Hey i just got a phone call from Geico?

**Jeff Bergosh**: About what?

**Brandon Bergosh**: The “accident”

**Jeff Bergosh**: Have them call me

**Brandon Bergosh**: It was an 800 number

**Jeff Bergosh**: Did they give you a reference number??

**Brandon Bergosh**: She said she was gonna send us both an email

**Jeff Bergosh**: Okay I will look for it

**Jeff Bergosh**: What’s your email address

**Brandon Bergosh**: blbergosh@gmail.com

### CONVERSATION ON 11-28-2019

**Brandon Bergosh**: hahaha that’s great

### CONVERSATION ON 12-01-2019

**Jeff Bergosh**: Hey where r u???

**Jeff Bergosh**: ??

**Brandon Bergosh**: Uwf dorms

**Jeff Bergosh**: I thought you had to study for a final today?

**Brandon Bergosh**: No

### CONVERSATION ON 12-03-2019

**Jeff Bergosh**: Mom’s package has been delivered so if you are there please grab it from the porch and bring it inside. Let me know if you got it please thanks

**Brandon Bergosh**: I got it yea

**Jeff Bergosh**: Thx

### CONVERSATION ON 12-04-2019

**Jeff Bergosh**: Brandon call me

**Jeff Bergosh**: U need to call GEICO at 1-863-646-9732 and speak to Lindsey.  She needs your recorded account of what happened in that parking lot

**Brandon Bergosh**: Yea sorry i silenced my phone cuz i was finishing essay

**Brandon Bergosh**: I’ll call her rn

**Jeff Bergosh**: Ok thx

**Jeff Bergosh**: UPS says it was delivered Monday morning at 10:45

**Brandon Bergosh**: Not to my knowledge

**Brandon Bergosh**: Also

**Brandon Bergosh**: I just tried calling her & got sent to voicemail

**Jeff Bergosh**: Leave her a message

### CONVERSATION ON 12-06-2019

**Brandon Bergosh**: Did u hear about the NAS shooting?

**Jeff Bergosh**: I’m here

**Brandon Bergosh**: Thats crazyyy

### CONVERSATION ON 12-07-2019

**Jeff Bergosh**: Hey where r u?

**Jeff Bergosh**: I’m locking up r u coming home tonight?

**Brandon Bergosh**: No lock up

### CONVERSATION ON 12-14-2019

**Jeff Bergosh**: How are things going Brandon?

**Brandon Bergosh**: Well

**Jeff Bergosh**: Are you remembering to give Rocky fresh water each day?

### CONVERSATION ON 12-16-2019

**Jeff Bergosh**: Where’s the report card?

**Brandon Bergosh**: I’ll have to show u

**Jeff Bergosh**: K

### CONVERSATION ON 12-18-2019

**Jeff Bergosh**: Are u at home?

**Brandon Bergosh**: yea why

**Jeff Bergosh**: Do u work tonight?

**Brandon Bergosh**: Why?

**Jeff Bergosh**: Call me

**Brandon Bergosh**: Heading that way now

**Jeff Bergosh**: Ok me too

**Jeff Bergosh**: U there?

**Brandon Bergosh**: I just got here

**Brandon Bergosh**: Where are you?

**Jeff Bergosh**: Here

### CONVERSATION ON 12-30-2019

**Brandon Bergosh**: I wanna be there

### CONVERSATION ON 01-10-2020

**Brandon Bergosh**: Nick and I are grabbing a quick lunch and coming right back to house

**Jeff Bergosh**: Okay I’m heading that way so I’ll see you all back at the house before I take Nick to the airport

**Brandon Bergosh**: $107.26

**Brandon Bergosh**: For textbooks

**Jeff Bergosh**: K

### CONVERSATION ON 01-13-2020

**Brandon Bergosh**: I need u to reimburse me still^

**Brandon Bergosh**: & also $53.70 for my last nook that i just got today

**Brandon Bergosh**: book*

**Jeff Bergosh**: Okay

### CONVERSATION ON 01-14-2020

**Jeff Bergosh**: Just put the $160.96 back in your checking to reimburse you for your books👌

**Brandon Bergosh**: Okay, thanks dad love you!

**Jeff Bergosh**: Love u too

### CONVERSATION ON 01-21-2020

**Brandon Bergosh**: Gas: $31.74

### CONVERSATION ON 01-24-2020

**Jeff Bergosh**: Brandon, please respond to avoid your appointment being canceled on Mon Jan 27 2020, 2:40pm at Clarkson Eyecare - Nine Mile.  Reply Y to confirm, N to cancel. or text with Qs.

### CONVERSATION ON 01-27-2020

**Jeff Bergosh**: That’s it

**Brandon Bergosh**: I’m sorry for being rude. I’ll start doing more chores around the house but to give me a week to move out and constantly tell me to move out for the past year is cruel and unfair. I know i was rude this morning & i’m sorry for getting into it with you this morning mom. I’ll be better.

**Jeff Bergosh**: You have no idea how good you have it

**Jeff Bergosh**: We’ll talk when I get home tonight

### CONVERSATION ON 01-28-2020

**Brandon Bergosh**: It looks like PSC is wanting to give me money.

**Brandon Bergosh**: I’d like yall to check this out when you get home

**Jeff Bergosh**: That’s a tax form — not a scholarship.  That’s what we spent on tuition and a part of what we file with our tax returns.     Sorry

### CONVERSATION ON 02-01-2020

**Brandon Bergosh**: Emphasized “Make sure to wear a mask on the plane back. Don’t want to get that corona virus ”

### CONVERSATION ON 02-04-2020

**Jeff Bergosh**: Got my poll results back just now—among those who have decided in my race:

Jeff Bergosh. 52%
Jesse Casey.  31%
Jonathan Owens. 13%
Jimmy Trotter.     4%

(Undecided 64%)

Among those that have decided in Gary’s hypothetical state attorney race:

Gary Bergosh. 65%
Greg Marcille   35%

(Undecided 70%)

**Brandon Bergosh**: Thats awesome dad!

**Jeff Bergosh**: 😎

### CONVERSATION ON 02-06-2020

**Jeff Bergosh**: Brandon, we've scheduled you an appointment at Clarkson Eyecare - Nine Mile on Wed Feb 19 2020, 1:40pm at 1308 W. NINE MILE RD SUITE 11 & 12, Pensacola, FL.

**Brandon Bergosh**: Yea i know. I was just there to schedule it. 

**Jeff Bergosh**: Ok

### CONVERSATION ON 02-08-2020

**Jeff Bergosh**: Hey Brandon—we are locking up, r u coming home?

Be safe

Love,

Dad

**Brandon Bergosh**: Yes im coming home

**Jeff Bergosh**: Okay I won’t set the alarm

### CONVERSATION ON 02-19-2020

**Brandon Bergosh**: Hey dad i’m at my eye appointment, she wants to know if this appointment is under private pay or vision?

**Jeff Bergosh**: Humana Vision Care with Escambia Board of County Commissioners

**Brandon Bergosh**: Thanks dad. Turns out they have it in the system

**Jeff Bergosh**: Make sure they have both and use the one that’s better. Ask them to write you a prescription for your contact lenses and that you want to use the insurance for a well visit today and an eye exam. Ask them what that will cost and we will go online and purchase contact lenses at the best price from a different vendor.

**Brandon Bergosh**: okay

### CONVERSATION ON 02-20-2020

**Jeff Bergosh**: Call Valentina at Clarkson eye care for refund

479-2020

**Brandon Bergosh**: Okay she took care of it. She said it’ll back up in my account in 3 business days

**Jeff Bergosh**: Okay good

### CONVERSATION ON 02-26-2020

**Brandon Bergosh**: Lmao

**Brandon Bergosh**: Glad you’re safe! 

### CONVERSATION ON 03-02-2020

**Jeff Bergosh**: LOL

**Brandon Bergosh**: I ordered it

**Brandon Bergosh**: Itsnot on netflix anymore

### CONVERSATION ON 03-06-2020

**Jeff Bergosh**: Alright who is on my Napster??? I’m trying to enjoy songs during my lunch!!

**Brandon Bergosh**: I am. I’m On my way to Destin

**Jeff Bergosh**: Okay get off for the next 30 min

**Jeff Bergosh**: Then it’s all yours

**Brandon Bergosh**: K

**Brandon Bergosh**: Beach

### CONVERSATION ON 03-08-2020

**Brandon Bergosh**: That sounds like a rare occasion lol enjoy it!

**Brandon Bergosh**: Emphasized “And hopefully Brandon will be 21 next time too haha ”

### CONVERSATION ON 03-09-2020

**Brandon Bergosh**: I am

**Brandon Bergosh**: Chill

**Brandon Bergosh**: Im driving to class

**Jeff Bergosh**: Well listen to the radio and get off my Napster

**Brandon Bergosh**: Family package

**Jeff Bergosh**: Yeah that’s the plan we don’t have

**Brandon Bergosh**: But we need

**Jeff Bergosh**: Free radio for you Napster for me

### CONVERSATION ON 03-10-2020

**Jeff Bergosh**: Okay well that’s awesome!  I’ll have to clean out the Toyota, I’ve been using it as my campaign car and was going to clean it out tomorrow because I thought you were coming Thursday.  No worries though I’ll do it tonight.  Glad you are coming early!!

**Brandon Bergosh**: Carne asada’s tonight?

### CONVERSATION ON 03-13-2020

**Jeff Bergosh**: 4

**Brandon Bergosh**: Same

### CONVERSATION ON 03-20-2020

**Jeff Bergosh**: Call your manager

**Brandon Bergosh**: Just called & no i don’t have to go in

**Jeff Bergosh**: Beaches closed for 2 weeks

**Brandon Bergosh**: Didn’t want you to get blindsided by this walking in the door, but this piece that makes the toilet flush broke off & we need a replacement.

**Jeff Bergosh**: Which bathroom

**Brandon Bergosh**: Mine

**Brandon Bergosh**: Kids

**Jeff Bergosh**: Ok

### CONVERSATION ON 03-26-2020

**Jeff Bergosh**: If yes, I’ll try to get home early

**Brandon Bergosh**: Yea for sure, what time are you thinking?

**Jeff Bergosh**: 4:15

**Brandon Bergosh**: Okay cool sounds good

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-30-2020

**Jeff Bergosh**: Thx

**Brandon Bergosh**: No problem

**Brandon Bergosh**: Just bought bread & hamburger buns. Looking for TP now! 

**Brandon Bergosh**: TP & paper towels

**Brandon Bergosh**: & nope just trying to “contribute” to the family cuz apparently i’m a POS :)

**Brandon Bergosh**: ditto

### CONVERSATION ON 04-08-2020

**Jeff Bergosh**: I'll call u right back

**Brandon Bergosh**: I can’t do online class because of our shitty internet

**Brandon Bergosh**: Thanks..

**Brandon Bergosh**: ^

**Brandon Bergosh**: Join now!

**Brandon Bergosh**: Yea

### CONVERSATION ON 04-18-2020

**Brandon Bergosh**: Oh no😂

**Brandon Bergosh**: We got our returns in the mail Nick

### CONVERSATION ON 04-27-2020

**Brandon Bergosh**: AT&T just ruined my birthday surprise :/

**Brandon Bergosh**: haha

### CONVERSATION ON 04-28-2020

**Jeff Bergosh**: Brandon— go look on the porch!

**Jeff Bergosh**: R u at home??

**Brandon Bergosh**: Yea

**Brandon Bergosh**: Okay

**Jeff Bergosh**: Did u get my package that got delivered?

**Brandon Bergosh**: No package on the porch

**Jeff Bergosh**: Okay I thought it was delivered

**Jeff Bergosh**: Look around they’re saying it got delivered

**Brandon Bergosh**: Tori must have grabbed it then

**Jeff Bergosh**: K

### CONVERSATION ON 04-29-2020

**Brandon Bergosh**: Very bad look

### CONVERSATION ON 04-30-2020

**Jeff Bergosh**: Did u go and get your paperwork from 5 Sisters?  We have to fill out application for unemployment today

**Brandon Bergosh**: Going rn

**Brandon Bergosh**: Traffic was wack

**Brandon Bergosh**: Got it

**Jeff Bergosh**: Okay, head home and get on the computer and I’ll text you the information you need to fill out the form

**Brandon Bergosh**: Just show me when u get home i have an exam to do rn

**Jeff Bergosh**: You need to start right away—due today by COB. 5:00

**Brandon Bergosh**: Why cant u help me like u said u would

**Jeff Bergosh**: I will

**Jeff Bergosh**: ......and you have everything you need to fill out the form for your benefits

**Brandon Bergosh**: If you know how to do this why wont you

**Jeff Bergosh**: I’m at work

**Jeff Bergosh**: I’ve never applied before, I just did the research for you so it would be easy

**Brandon Bergosh**: Need a little help here

**Jeff Bergosh**: Okay

**Brandon Bergosh**: Need a little help here

**Jeff Bergosh**: Routing number is

**Brandon Bergosh**: I think i’m done

**Jeff Bergosh**: Right on!  Glad u got this done!!

### CONVERSATION ON 05-01-2020

**Jeff Bergosh**: R u at home Brandon?

**Brandon Bergosh**: Yea, y?

**Jeff Bergosh**: Bad wreck in Cantonment—2 dead just making sure u r safe

**Brandon Bergosh**: Oh yikes

**Jeff Bergosh**: Tori there?

**Brandon Bergosh**: No i think she workin

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-02-2020

**Brandon Bergosh**: Can u get me an xbox 1 controller too please

**Jeff Bergosh**: ??

**Jeff Bergosh**: They don’t sell those here

**Brandon Bergosh**: Which walmart are you at?

### CONVERSATION ON 05-19-2020

**Jeff Bergosh**: ........Because you’re definitely entitled to unemployment payments for the eight weeks you’ve been out of work

**Brandon Bergosh**: Got it

**Brandon Bergosh**: I filled everything out properly. Still says “pending-submitted” for whatever reason. Not sure what I can do about that though.

**Jeff Bergosh**: Okay maybe the approval is coming soon

**Brandon Bergosh**: Hopefully 

**Brandon Bergosh**: Also just paid for a summer class @ psc

**Jeff Bergosh**: How much$

**Brandon Bergosh**: $338.73

**Brandon Bergosh**: Taking Macroeconomics

**Jeff Bergosh**: Nice!

**Jeff Bergosh**: You’ll love it

**Brandon Bergosh**: I know, i’m excited!

### CONVERSATION ON 05-20-2020

**Brandon Bergosh**: What’s a good email for me to send you my grades?

**Jeff Bergosh**: Jeffbergosh@gmail.com

**Brandon Bergosh**: Okay i just sent you an email.

**Jeff Bergosh**: Thx

### CONVERSATION ON 05-22-2020

**Jeff Bergosh**: Hey where r u?

**Brandon Bergosh**: Coming home rn, don’t lock up

**Jeff Bergosh**: Drive careful park in the cul de sac

**Brandon Bergosh**: Okay 

### CONVERSATION ON 05-26-2020

**Brandon Bergosh**: hahahaha

### CONVERSATION ON 05-28-2020

**Jeff Bergosh**: But no matter what don’t drive it it’s too low on air it would destroy the rim

**Brandon Bergosh**: I’m pretty sure my tires just need some air. I’ll take it to gas station later🤙🏼

### CONVERSATION ON 05-29-2020

**Brandon Bergosh**: What all do i need to get done with my car?

**Jeff Bergosh**: New tire for front driver side, put spare back in car, get a front-end alignment job, have brakes inspected, rotate tires, and an oil/filter change with fluids topped off.  New windshield wiper blades if needed.   Go to Vannoys right past the I 10 on-ramp 

**Jeff Bergosh**: What is the status

**Brandon Bergosh**: I forgot about a friends birthday lunch so i havent had the chance today

**Jeff Bergosh**: It’s not safe to be driving it like this

**Brandon Bergosh**: I didn’t drive, i rode with Josh

**Jeff Bergosh**: 👍but tomorrow the crowd at Vannoys will only be larger

**Brandon Bergosh**: I’ll take care of it don’t worry

**Brandon Bergosh**: I’m at Vannoys rn

**Brandon Bergosh**: Im just gonna pay & have u reimburse me

**Jeff Bergosh**: Okay did they say how much it would cost?

**Brandon Bergosh**: Its gonna be like 500 after everything probably.

**Jeff Bergosh**: Alright well let me know.  Are they working on it right now?

**Brandon Bergosh**: They are working on it rn yea

**Jeff Bergosh**: K

**Brandon Bergosh**: Lady just showed me & there’s actually a lot of shit wrong with the car.

**Jeff Bergosh**: We know this.  It’s old.  Just pay for the stuff I described, don’t let them sell you on a bunch of additional stuff

**Brandon Bergosh**: It’s gonna be $740

**Jeff Bergosh**: What does that include?  Just what we discussed?

**Brandon Bergosh**: Rear brakers & also front passenger tire

**Jeff Bergosh**: Alignment?

**Jeff Bergosh**: Oil change?

**Brandon Bergosh**: Yea thats all included too

**Jeff Bergosh**: Okay do it.  I’m transferring the money rn 

**Jeff Bergosh**: Into your checking account

**Brandon Bergosh**: Okay

**Jeff Bergosh**: Will they do it today?

**Brandon Bergosh**: Yea they are

**Jeff Bergosh**: Okay good

**Jeff Bergosh**: Bring home the receipt please

**Brandon Bergosh**: ok

### CONVERSATION ON 06-02-2020

**Jeff Bergosh**: Hey Brandon—I put the money in your account for the haircut.  If you are still feeling pain this morning call me and I will get you set up with an appointment at our clinic

**Jeff Bergosh**: Don’t ignore it

**Brandon Bergosh**: I’m working again starting tomorrow!!

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Oh trust me i know

### CONVERSATION ON 06-08-2020

**Brandon Bergosh**: I need a new house key

**Jeff Bergosh**: Why?  What happened?

**Brandon Bergosh**: It’s rusted

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Going to bed— goodnight

**Brandon Bergosh**: Goodnight

### CONVERSATION ON 06-09-2020

**Brandon Bergosh**: Hey dad, looks like i need to get the book for this class. Any way you can help me out with this? It costs $107.

**Jeff Bergosh**: Yes.  I’ll put the money back in your account.  Just buy it.

**Brandon Bergosh**: Okay sweet. Thanks dad, love you!

**Jeff Bergosh**: Love u too

### CONVERSATION ON 06-16-2020

**Brandon Bergosh**: Wow, that’s dope dude. Have fun!

### CONVERSATION ON 06-18-2020

**Jeff Bergosh**: Hey Brandon-  Mom and I just put the $338 for tuition back in your account, plus I put that extra $63 in your account Saturday to cover the full cost of your book! 😎👍

**Brandon Bergosh**: Aw, thanks dad!

**Jeff Bergosh**: Call that 800 number today—check on your claim.  They owe you $$$$ thousands that you’ll be able to put right into your savings.  Don’t blow that off!  Be persistent and aggressive!!!!

**Brandon Bergosh**: Sunday

### CONVERSATION ON 06-23-2020

**Jeff Bergosh**: Brandon call this number, get your money and get paid!

**Brandon Bergosh**: Oh hell yeaa

### CONVERSATION ON 06-24-2020

**Brandon Bergosh**: Just got a 100 on my first Macro test! Still have a 100 in the class somehow.

**Jeff Bergosh**: Outstanding Brandon!!! I’m proud of you!!!!!!!!

**Brandon Bergosh**: Thanks dad! :)

### CONVERSATION ON 07-02-2020

**Brandon Bergosh**: Unemployment money finally came in!

**Jeff Bergosh**: Put it in your savings account Brandon!

**Brandon Bergosh**: I just took care of it online. Should take 1-5 days before it pops up in my account.

### CONVERSATION ON 07-08-2020

**Brandon Bergosh**: Hey dad, did you happen to save those unemployment checks?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Why?

**Brandon Bergosh**: Just making sure because if these checks don’t show in my account soon I’m just gonna take them up to navy fed.

**Jeff Bergosh**: Okay

### CONVERSATION ON 07-09-2020

**Jeff Bergosh**: Mom has them in her purse in an envelope with your name on it

**Brandon Bergosh**: I got them from her, thanks dad!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: There’s a branch on Davis

**Brandon Bergosh**: Yeah I will

**Brandon Bergosh**: “Service engine soon” light is on in my car. I’m coming home rn.

**Jeff Bergosh**: Okay we’ll take a look at it

**Brandon Bergosh**: No he shouldn’t. Just don’t be around Kyle & wear a mask. You take a test & happen to test positive you are out of a job for 4 weeks. There’s been too many false positives to even chance that. 

**Brandon Bergosh**: Buy gloves & germ ex

**Brandon Bergosh**: & tell him to buy sanitizer spray to wipe down stuff after using it.

### CONVERSATION ON 07-10-2020

**Jeff Bergosh**: How did it go with your car today?

**Brandon Bergosh**: I never took it today because I was exhausted after work

### CONVERSATION ON 07-16-2020

**Brandon Bergosh**: Hey dad, I got an email regarding my debit card expiring. Do you know how I’m supposed to go about getting a replacement?

**Jeff Bergosh**: You just go inside any branch office and they will issue you a replacement on the spot.

**Brandon Bergosh**: Okay cool, thanks dad love you! :)

**Jeff Bergosh**: Love you too.  Miss u!

**Brandon Bergosh**: Miss you too!

**Brandon Bergosh**: Hey dad, a friend of mine that goes to college here but isn’t from here wants to know how he can go about voting here in Escambia county. How would he go about getting registered?

**Jeff Bergosh**: He needs to call the supervisor of elections office here at 850-595-3900. They will walk him through the process.  Last day to register for the primary is Monday, July 20th

**Brandon Bergosh**: Okay very cool, thanks dad!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Hey, did u have the car checked out?  You really need to get that done

**Brandon Bergosh**: I haven’t had the chance yet but I will whenever I get a day off

**Jeff Bergosh**: Ok

**Jeff Bergosh**: School going well?

**Brandon Bergosh**: Yeah! I have a 97 in Macro!

**Jeff Bergosh**: That’s fantastic keep up the great work!!

**Brandon Bergosh**: Will do :)

**Brandon Bergosh**: I just got a job offer from a guy I waited on hahaha

**Brandon Bergosh**: Some sales job but I politely declined🙃

### CONVERSATION ON 07-18-2020

**Brandon Bergosh**: Just got a call from Boppa & he said each day he is feeling better and better. We talked for a while & I really needed that. No doubt in my mind he will bounce back from this!❤️

**Jeff Bergosh**: Glad he is doing well.  Mom and I are calling him tonight

### CONVERSATION ON 07-19-2020

**Brandon Bergosh**: I took the political compass test

### CONVERSATION ON 07-23-2020

**Jeff Bergosh**: That was a great day fishing!!

**Brandon Bergosh**: Yea, you went without a certain someone😏

**Jeff Bergosh**: LOL let’s not encourage that!

**Brandon Bergosh**: dope😌

**Brandon Bergosh**: Alaska trip

**Brandon Bergosh**: Next summer😌

### CONVERSATION ON 07-25-2020

**Jeff Bergosh**: Here are the dates

August 19-25

Would be great if you could come with us!

**Brandon Bergosh**: How does he still have a job?

**Brandon Bergosh**: Anyone home?

### CONVERSATION ON 07-26-2020

**Jeff Bergosh**: Just let me know we love you

### CONVERSATION ON 07-28-2020

**Brandon Bergosh**: Schedule for Fall semester & the last of PSC.

**Brandon Bergosh**: I’m going to pay tomorrow.

**Jeff Bergosh**: Right on we will reimburse u for it.  Is that the last of PSC?

**Brandon Bergosh**: Yessirrr

**Jeff Bergosh**: 👍👍

### CONVERSATION ON 07-29-2020

**Brandon Bergosh**: $861.64

**Brandon Bergosh**: I just paid for my classes

**Jeff Bergosh**: Okay I’ll reimburse u today

**Jeff Bergosh**: Congrats on finishing!!!

**Brandon Bergosh**: I might not be able to go to Milwaukee tho because my classes start on the 17th but I’ll try.

**Jeff Bergosh**: Hope u can.  Are they live classes or online?

**Brandon Bergosh**: I chose specifically to do live classes because I learn better that way.

**Jeff Bergosh**: Okay— well what days are your classes?

**Jeff Bergosh**: Also, I just put the money back into your checking acct

**Brandon Bergosh**: Monday-Thursday

**Jeff Bergosh**: Okay- well, you’d be missing Thursday then the following Monday-2 days total— because we’re not leaving until Wednesday afternoon the 19th

**Jeff Bergosh**: Hope you can work with the professors to make it happen— It’s going to be awesome for us all to be together 🙂

**Brandon Bergosh**: I’ll talk to them & see what I can do! :)

**Brandon Bergosh**: & thanks for reimbursing me dad, love ya❤️

**Jeff Bergosh**: Love u too B!

### CONVERSATION ON 08-03-2020

**Brandon Bergosh**: My first day of class is the 15th :/

**Brandon Bergosh**: I would love to, but what I’m saying is I’m not so sure I’ll be available the 15th. 

**Brandon Bergosh**: Jk I can go. Class starts on the 17th :)

**Brandon Bergosh**: I helped 4 years ago as well mother. Thanks for making it sound like I haven’t helped at all though!!😊

### CONVERSATION ON 08-10-2020

**Brandon Bergosh**: Hop off my Napster I’m at the gym

**Jeff Bergosh**: I need it for another 10 minutes I’m on my walk

**Brandon Bergosh**: Uncool

**Jeff Bergosh**: OK I’m all done with it now you can jump on

### CONVERSATION ON 08-11-2020

**Brandon Bergosh**: I’ve been trying to figure this out Dad but it’s complete bs. A nightmare that I’m not completely sure is worth it. I’ve tried calling and completeting the forms online. It is a  complete joke. If you think you could help me that would be greatly appreciated!!

**Jeff Bergosh**: It just takes persistence

**Jeff Bergosh**: U have to keep calling

**Brandon Bergosh**: You have no idea

**Brandon Bergosh**: I have

### CONVERSATION ON 08-13-2020

**Brandon Bergosh**: Hey dad do you happen to know exactly what time I was born?

**Jeff Bergosh**: I think it was like 5:00 in the afternoon??  Why?  Mom probably knows for sure

**Brandon Bergosh**: Okay cool thanks dad! :)

### CONVERSATION ON 08-16-2020

**Brandon Bergosh**: What day will we be back in Pensacola?

**Jeff Bergosh**: Late Monday Aug 24th

### CONVERSATION ON 08-17-2020

**Brandon Bergosh**: Just got this message

**Brandon Bergosh**: You should do one of these dad!

**Jeff Bergosh**: And when I say Jessie’s lead I mean Jessie’s current 20 point lead over Johnathan

**Brandon Bergosh**: It could be cutting your lead just as much as it is Jessie’s though..🤔

**Brandon Bergosh**: It’s better to be safe then sorry.

**Brandon Bergosh**: than*

**Jeff Bergosh**: I’ve been getting lots of texts from lots of candidates—I just don’t think it helps but we will see.

**Brandon Bergosh**: It gets your name out there for those who aren’t familiar with you. 

**Brandon Bergosh**: But it’s ultimately your call

**Jeff Bergosh**: Mine goes out tomorrow morning!

**Brandon Bergosh**: Glad we convinced you! :)

### CONVERSATION ON 08-18-2020

**Brandon Bergosh**: What time are we trying to leave tomorrow?

**Jeff Bergosh**:  I’m hoping between one and three

**Brandon Bergosh**: Okiedokie

**Brandon Bergosh**: Good stuff pops😌

**Brandon Bergosh**: Things are looking good so far! Not all the votes are in but it’s looking good! :)

**Brandon Bergosh**: Dad made us turn our phones off

### CONVERSATION ON 08-21-2020

**Brandon Bergosh**: Nick & I are on our way ova!

### CONVERSATION ON 08-22-2020

**Brandon Bergosh**: Start heading down

**Jeff Bergosh**: Okay

**Jeff Bergosh**: Okay right on see you all then

**Brandon Bergosh**: Mom & I are at hotel

### CONVERSATION ON 08-23-2020

**Jeff Bergosh**: Hey guys are you up?  I want to take us all to breakfast this morning at the hotel?  Can you all meet us over here?  We’re shooting for 8:45?

### CONVERSATION ON 08-24-2020

**Brandon Bergosh**: Indiana

### CONVERSATION ON 08-25-2020

**Brandon Bergosh**: Thank you for my new car

**Jeff Bergosh**: Just take care of it!

### CONVERSATION ON 08-27-2020

**Jeff Bergosh**: R u in class rn?

**Brandon Bergosh**: Nope

**Brandon Bergosh**: Why what’s up?

**Jeff Bergosh**: Can u talk?

**Brandon Bergosh**: Yea 1 sec

**Jeff Bergosh**: K

### CONVERSATION ON 08-29-2020

**Jeff Bergosh**: Also, tonight is the night Metallica plays at the fairgrounds live broadcasted around the world.  You’re invited to come along we leave at 7:15.  3 Days Grace is opening band.

**Brandon Bergosh**: Damn I wish u told me in advance but I’m a double today

**Brandon Bergosh**: :/

**Jeff Bergosh**: No problem.  U good for those San Diego dates—12-21-20 through 1-5-21?

**Jeff Bergosh**: We have bought plane tickets for u?

**Brandon Bergosh**: I will be, Yessirr

**Jeff Bergosh**:  Great!  

**Jeff Bergosh**: All right I hope you have a good night at work we love you and will see you soon

### CONVERSATION ON 08-31-2020

**Brandon Bergosh**: Did you put 750 in my account?

**Jeff Bergosh**: No— did u get $750??

**Jeff Bergosh**: From what?

**Brandon Bergosh**: Yea, idk ig work

**Jeff Bergosh**: Great!! ProbablyPSC

**Brandon Bergosh**: You think?

### CONVERSATION ON 09-01-2020

**Jeff Bergosh**: Get off my Napster!!

**Jeff Bergosh**: I’m working out till 1

**Brandon Bergosh**: Dude

**Brandon Bergosh**: Pay extra

### CONVERSATION ON 09-07-2020

**Brandon Bergosh**: Are you working today Dad?

**Jeff Bergosh**: Nope I’m off

**Jeff Bergosh**: You?

**Brandon Bergosh**: Same yea

**Brandon Bergosh**: Are you at the house?

**Jeff Bergosh**: We are over at Uncle Gary’s you should stop by

**Brandon Bergosh**: Whose all there?

**Jeff Bergosh**: Me Mom Gary Carissa Ben and Alex

**Brandon Bergosh**: Okay I’ll swing by

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-08-2020

**Brandon Bergosh**: Any update on the Cares-Grant money?

**Jeff Bergosh**: I’ll have something Thursday for you on that

### CONVERSATION ON 09-09-2020

**Jeff Bergosh**: Off my Napster!  I’m exercising!!

**Brandon Bergosh**: I’m off

**Brandon Bergosh**: I’m off

**Brandon Bergosh**: Sorry, I was driving & didn't wanna look at my phone.

**Jeff Bergosh**: 👍

**Brandon Bergosh**: sorry bout it

**Jeff Bergosh**: No problem I’m off now it’s all yours

### CONVERSATION ON 09-16-2020

**Brandon Bergosh**: Back at 7:30 when u called me lmao

### CONVERSATION ON 09-18-2020

**Jeff Bergosh**: How is your gas situation?

**Brandon Bergosh**: Still half a tank

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Are you at work today?

**Jeff Bergosh**: No

**Brandon Bergosh**: Hey I’m at home

**Jeff Bergosh**: I’m at the base at my office working

**Jeff Bergosh**: Moms at the clinic and Tori’s working.  I’ll be back after I get some work done.  You can hang out in the AC and relax.  TV and cable are working

**Brandon Bergosh**: I’m gonna stay here for a bit if that’s okay

**Brandon Bergosh**: Just found out one of my best friends died today

**Jeff Bergosh**: What????  Who????

**Brandon Bergosh**: Cameron Newton 

**Brandon Bergosh**: From baseball team

**Brandon Bergosh**: & they aren’t sure yet

### CONVERSATION ON 09-22-2020

**Brandon Bergosh**: I need to get a suit

**Jeff Bergosh**: Okay- when do u need it by?

**Brandon Bergosh**: Thursday

**Jeff Bergosh**: Okay- I have a meeting today but tomorrow afternoon I can go and meet you at the mall and we can pick up a nice solution for you

**Jeff Bergosh**: Can you do it tomorrow at 4:00?

**Brandon Bergosh**: I work at 5

**Jeff Bergosh**: Okay so that won’t work then.  Go to Belk and go to the suit section and find a nice black suit, tie, and shirt.  Try it on to make sure it fits well.  Pay for it with your red card and I’ll put the money you spend right back in your account.  

**Jeff Bergosh**: Just ask the attendant to help you pick the right one based upon what you like and for the occasion 

**Brandon Bergosh**: Okay

**Jeff Bergosh**: So you’ll go today then?

**Brandon Bergosh**: Can u meet me there today?

**Jeff Bergosh**: I can’t because I have county commission meetings at 4:00 and 5:00—- that’s why tomorrow or yesterday would have been perfect

**Brandon Bergosh**: I’ll just go today

**Jeff Bergosh**: Okay.  I suggest a Black suit— you can wear that for any occasion.  Make sure you try it on

**Jeff Bergosh**: Belk is the place to go at the mall

**Brandon Bergosh**: Okay sounds good

**Brandon Bergosh**: I just bought everything I need

**Jeff Bergosh**: Right on

**Jeff Bergosh**: How much did you spend?

**Brandon Bergosh**: $189.07

**Jeff Bergosh**: Okay I’ll get it transferred back

**Brandon Bergosh**: Okay thank you

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-24-2020

**Jeff Bergosh**: Text me your address for this application

**Brandon Bergosh**: 2220 Gloria Circle

**Brandon Bergosh**: Zip code: 32514

**Jeff Bergosh**: Is there an Apt #?

**Brandon Bergosh**: Building 12 Apt. 143

**Jeff Bergosh**: Is your email

Blbergosh@gmail.com.

**Brandon Bergosh**: Yessir

**Jeff Bergosh**: Okay thx

### CONVERSATION ON 09-26-2020

**Brandon Bergosh**: I need the address for where to take this paper work please.

### CONVERSATION ON 09-27-2020

**Jeff Bergosh**: Okay I’ll forward it to you 

**Jeff Bergosh**: Do u have something showing your name on it at your address (lease paperwork, Bill, etc,)— you need that as well.

**Brandon Bergosh**: No, but on Tuesday I’ll have time to run to the office & have them print me out a sheet. After school that is<-

**Jeff Bergosh**: Okay

**Brandon Bergosh**: Yessir

**Brandon Bergosh**: Alright goodnight dad, got work at 9. Love you❤️

**Jeff Bergosh**: Love u too!

**Brandon Bergosh**: Please respect my current wishes, love you dad!❤️ 

### CONVERSATION ON 09-28-2020

**Jeff Bergosh**: Sure Brandon love you too.  

**Jeff Bergosh**: What does that mean though?

**Brandon Bergosh**: We’ll talk about it when I come by the house next :)

**Jeff Bergosh**: Okay.  Are you coming over tomorrow?  I’m emailing you one more form you need to submit with your package to get the cares act money

**Brandon Bergosh**: I don’t need the money. We’ll discuss why that is tomorrow dad, goodnight❤️

**Brandon Bergosh**: Jk I want the money lol

**Jeff Bergosh**: ? Free money and you don’t need it??  Yes you do. 

**Brandon Bergosh**: ^

**Jeff Bergosh**: Brandon— check your email I sent you the rest of the important information about filing your cares act paperwork

**Brandon Bergosh**: Sounds good, thanks dad! :)

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Hey dad, do you think you’ll be up late tonight by chance?

**Jeff Bergosh**: Mom and I are on the way home right now.  What’s going on?

**Jeff Bergosh**: Brandon call mom

**Brandon Bergosh**: I told her what I believe she should do lol. Which is talk to you because you help her learn.

### CONVERSATION ON 09-29-2020

**Brandon Bergosh**: I need your WORD that this (newly found information) will STAY in the family dad. Do I have your word?

**Jeff Bergosh**: Of course.  I love you Brandon 

**Brandon Bergosh**: Those are my favorite words to hear from you❤️

**Brandon Bergosh**: I’m going to help you be President of our country. Mark my words! :)

**Jeff Bergosh**: Okay but let’s start by doing fantastic at Spanish Class today and getting the paperwork submitted for your Cares act grant.  Today is the deadline

**Brandon Bergosh**: Okay, will do.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Brandon are u at your apartment?

**Brandon Bergosh**: Yea

**Jeff Bergosh**: Brandon— 

**Brandon Bergosh**: Yessir?

**Jeff Bergosh**: Call me please

**Jeff Bergosh**: Important

**Brandon Bergosh**: No

**Brandon Bergosh**: That shit for crazy people

**Brandon Bergosh**: Which I’m not.

**Brandon Bergosh**: Hope you can understand

**Jeff Bergosh**: We think you should speak to the counselor

**Jeff Bergosh**: Why wouldn’t you talk to them if they came to your place

**Brandon Bergosh**: I might make a trip up to Milwaukee soon to be around Nick. I miss him a lot and feel really bad for putting him through this..

**Jeff Bergosh**: What?

**Brandon Bergosh**: Please stop

**Brandon Bergosh**: It’s getting annoying

**Jeff Bergosh**: We Are trying to get you help and we need you to consent to it so that you can get help

**Brandon Bergosh**: I don’t know where I’d be without you guys😓. Thanks for all the love and support during this time

**Brandon Bergosh**: Dad you lied to me. Again

**Brandon Bergosh**: I need some space

**Brandon Bergosh**: I’m embarrassed enough as it is..

**Brandon Bergosh**: I didn’t even want to think about how he died. I’m the worst..

**Brandon Bergosh**: I’ll come over tomorrow as long as you promise to not keep PRESSING me. I mean like fr, it’s starting to annoy me.

### CONVERSATION ON 10-03-2020

**Brandon Bergosh**: Baby shower card for mom

**Brandon Bergosh**: @ her request :)

**Jeff Bergosh**: Got it!

**Jeff Bergosh**: Tell mom I’ll get it and bring it home 

**Brandon Bergosh**: Word

**Jeff Bergosh**: Do you all want me to bring breakfast home after this set is over? I can stop on the way home just let me know?

**Brandon Bergosh**: No

**Brandon Bergosh**: Just get yourself breakfast

**Brandon Bergosh**: I’m getting everyone else Waffle House. :)

**Jeff Bergosh**: Okay love u

**Brandon Bergosh**: Love you too pops

### CONVERSATION ON 10-05-2020

**Brandon Bergosh**: I JUST now woke up, Dad! :)

**Jeff Bergosh**: How many hours sleep?

**Brandon Bergosh**: 7 hours, which is one hour longer than last night!!!

**Jeff Bergosh**: Good

**Jeff Bergosh**: It’s important

**Brandon Bergosh**: Have a good day at work, luv ya pops!🤙🏼

**Jeff Bergosh**: Love u too Brandon.  

**Jeff Bergosh**: Let me know if you want to take a walk at lunch with me okay

**Brandon Bergosh**: I would, but I just walked 3.8 miles with Tori & Mom! You talk with Doctor yet?

**Jeff Bergosh**: Got you earliest appointment I could for Dr Kassabian, Dr. Packard texted me back he will have a note prepared today for school and work. He also has your sweatshirt which I’ll get back for you today when I get your note!

**Jeff Bergosh**: Did your Astronomy professor email you back yet? 

**Brandon Bergosh**: Liked “Got you earliest appointment I could for Dr Kassabian, Dr. Packard texted me back he will have a note prepared today for school and work. He also has your sweatshirt which I’ll get back for you today when I get your note!”

**Brandon Bergosh**: Liked “Did your Astronomy professor email you back yet? ”

**Jeff Bergosh**: Okay that’s great news Brandon

**Jeff Bergosh**: Now you need to catch up on your assignments

**Brandon Bergosh**: I’ll let you help me reply to the email when u get back.

**Jeff Bergosh**: Sure but meanwhile start doing the work so that when I get there we can go on a walk

**Jeff Bergosh**: Spanish and Astronomy

**Brandon Bergosh**: I don’t really feel like going on another walk today to be honest dad. I’m down for tennis though if you are?

**Jeff Bergosh**: Okay well maybe we’ll do that.  But focus on getting caught up today while we’re all at work

**Brandon Bergosh**: Yessir, will do!

**Brandon Bergosh**: When you get a chance, please look in/around your car. (Front seat)

**Jeff Bergosh**: Look in your room

**Brandon Bergosh**: Where did you put my wallet dad... 

**Brandon Bergosh**: Get a hold of mom please. She is ignoring me.

**Brandon Bergosh**: Kill it at work today dad. Luv ya🤙🏼❤️

**Jeff Bergosh**: Love u too Brandon

**Brandon Bergosh**: Yessirrrr

**Brandon Bergosh**: Do u need me to make the appointment with Kassabian, dad?

**Brandon Bergosh**: Because I could if u wanted me to

**Jeff Bergosh**: Already made.  3:50 this Friday.  It was the earliest appointment he had

**Brandon Bergosh**: Perfect. Your the best!

**Brandon Bergosh**: Pig

**Jeff Bergosh**: ??

**Jeff Bergosh**: What is this??

**Brandon Bergosh**: U were on the video camera stalking me

**Jeff Bergosh**: No I’m at my desk working Brandon

**Brandon Bergosh**: Who was on the camera then?

**Brandon Bergosh**: ?!?!

**Jeff Bergosh**: Nobody— it’s motion sensitive

**Brandon Bergosh**: SOMEONE was laughing through the camera.

**Brandon Bergosh**: Punk😂

**Jeff Bergosh**: ??

**Jeff Bergosh**: What the heck are you talking about??!!??

**Brandon Bergosh**: Beavis

**Brandon Bergosh**: “Burrito dog boy” is what you are

**Brandon Bergosh**: You filthy disgusting 1 legged pig

**Jeff Bergosh**: You’re very funny burrito dog

**Brandon Bergosh**: 😂😂😂

**Jeff Bergosh**: Burrito donkey

**Brandon Bergosh**: Laughed at “Burrito donkey”

**Brandon Bergosh**: It looks like the insurance is going to cover my hospital bill, dad! So there’s some “positive” news. . . . lol

**Brandon Bergosh**: Loved “Morning, gang! I got the internship with the sports agency!!”

**Brandon Bergosh**: So proud of you man, you deserve it!!

**Brandon Bergosh**: ^

**Brandon Bergosh**: Can I call u rn?

**Brandon Bergosh**: Who has my wallet?! . . . .

**Brandon Bergosh**: & follow up question. Why?

**Brandon Bergosh**: & is that lmao

**Brandon Bergosh**: ik*

**Jeff Bergosh**: Brandon Did you have it on your walk?

**Jeff Bergosh**: Look by the computer

**Brandon Bergosh**: I didn’t lose it, so Where did you put it?

**Brandon Bergosh**: Found wallet in back seat pocket of dads truck. Thanks to everyone that looked well. Cough* Cough* Jeffrey. . . . 

**Brandon Bergosh**: Laughed at “We are all glad that 2 1/2 hour search is over & solved! ❤️”

### CONVERSATION ON 10-06-2020

**Brandon Bergosh**: Just tried to call you. Just wanted to lyk that I slept even better last night than I did the night before. Please call me back when you get a chance! :)

**Brandon Bergosh**: Oh, you used my toothbrush on accident this morning too btw. . . .

**Brandon Bergosh**: Where can I find another?

**Brandon Bergosh**: What day does mail come by our house?

**Jeff Bergosh**: Every day at 3:00, why?

**Brandon Bergosh**: Left my keys in mailbox while I walk around neighborhood🤙🏼

**Jeff Bergosh**: Okay.  But why not just keep them in your pocket?

**Brandon Bergosh**: Headphones & phone already are. That would’ve weighed me down. Now do your WORK, dad. Luv ya❤️

**Jeff Bergosh**: Love u too Brandon!

**Brandon Bergosh**: Quit

**Jeff Bergosh**: What??

**Brandon Bergosh**: Stalking me

**Jeff Bergosh**: I’m not— but the camera is sensing motion and noise- which sets it off

**Brandon Bergosh**: Liar

**Brandon Bergosh**: 😂

**Jeff Bergosh**: Huh?!?

**Brandon Bergosh**: Laughed at “Huh?!?”

**Brandon Bergosh**: When u gonna be home?

**Brandon Bergosh**: I wanna go play tennis.

**Brandon Bergosh**: Interesting article I think you ALL should read :)

**Brandon Bergosh**: Via: Business Insider

**Jeff Bergosh**: Brandon this was a good article— it’s why we all try to exercise as often as possible 😎👍

**Brandon Bergosh**: Nick & I agreed to start doing 300 sit-ups & 50 push-ups every day. 

**Brandon Bergosh**: If any one else thinks they could HANDLE IT you’re more than welcome to START TODAY! :)

**Jeff Bergosh**: I’m in!!!

**Brandon Bergosh**: Sweet

**Brandon Bergosh**: Sally/Tori?!😌

**Brandon Bergosh**: Lmao

**Brandon Bergosh**: Liked “What?”

**Brandon Bergosh**: Laughed at “Means of course haha ”

### CONVERSATION ON 10-07-2020

**Jeff Bergosh**: We are but it’s not coming our way, thankfully

**Brandon Bergosh**: I totally called it

**Jeff Bergosh**: What’s that? An omelette?

**Brandon Bergosh**: Just finished making it, yea!

**Jeff Bergosh**: 👍

**Brandon Bergosh**: We are outta milk btw

**Jeff Bergosh**: I’m getting some on way home

**Jeff Bergosh**: Later today

**Brandon Bergosh**: Sweet

**Brandon Bergosh**: Liked “I’m getting some on way home”

**Brandon Bergosh**: I’m still a picky eater... lol

**Brandon Bergosh**: Loved “Good evening everyone!
Big News from the Godwin Clan....
Seth has decided to join the Army!
He leaves on the 26th! 😬😥😁
He has talked about this for awhile and he stood his ground until they made the offer he wanted! He will go into special forces. 
We will have a Sending Off party for him on Oct. 18th, Sunday,  at Evan & Katelyn's house @4! We will have Chad's amazing pulled pork and of course chicken! Come and go as you can! I know Sunday's are hard to stay late for some & plenty of the family on this text will not be here but wanted you all to know so you can give him a shout out! He is not on fb but perhaps Instagram or his cell 850-712-1309 
Love 💘  to all!
(I had a message I thought I had sent a few days ago but come to find out...I didn't hit send🙄)”

### CONVERSATION ON 10-08-2020

**Jeff Bergosh**: Brandon: Mom said you and she worked out a couple of deals for you  so are you good?  

**Jeff Bergosh**: She said you’d be completing the homework as a part of the deal right?

**Brandon Bergosh**: Be more specific, please?

**Jeff Bergosh**: Astronomy and Spanish

**Jeff Bergosh**: Homework

**Brandon Bergosh**: What was the whole deal again?

**Jeff Bergosh**: I’ll talk to her after tennis — thought you all discussed it

**Brandon Bergosh**: Mom & I did, but it sounds like she is bending the truth. . . . 

**Brandon Bergosh**: Also sounds like she didn’t mention her side of the deal lol

**Jeff Bergosh**: What was your understanding of the deal?

**Brandon Bergosh**: We made 2 deals. 

**Brandon Bergosh**: Talk to mom about them when you get a chance.

**Brandon Bergosh**: If she doesn’t remember, I would suggest taking her to see a doctor (memory problems) that would be better fixed now as opposed to later.

**Jeff Bergosh**: She said part of the deal was you completing your homework

**Jeff Bergosh**: Have you done that

**Brandon Bergosh**: Don’t ignore what I just told you ^ simply because I’m your son (younger than you). Mom has serious memory problems. LOOK INTO IT.

**Brandon Bergosh**: & I’m working on homework right now.

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I need you to get mom checked out, dad!

**Brandon Bergosh**: Why are you ignoring me?!

**Jeff Bergosh**: I’m in a BCC meeting RN

**Brandon Bergosh**: k

**Jeff Bergosh**: Love u!

**Brandon Bergosh**: Love you too!

**Brandon Bergosh**: Dad!

**Brandon Bergosh**: Get a hold of mom!!!

**Brandon Bergosh**: Is she okay?!

**Jeff Bergosh**: She is fine!  She is at tennis

**Jeff Bergosh**: In a meeting

**Brandon Bergosh**: Okay✌🏼

**Brandon Bergosh**: What time is appointment tomorrow?

**Jeff Bergosh**: 3:50

**Jeff Bergosh**: Want to meet at the house before?

**Brandon Bergosh**: Sure

**Brandon Bergosh**: Liked “Want to meet at the house before?”

**Jeff Bergosh**: Okay great I’ll be home from work right at 3:00

**Jeff Bergosh**: So we can go together 

**Brandon Bergosh**: Okiedokie

**Brandon Bergosh**: I’m staying at my apartment tonight tho

**Jeff Bergosh**: Your medicine is here— I need to come and get it if you’re not staying here 

**Jeff Bergosh**: Come by and get it

**Brandon Bergosh**: I’ll come get it🤙🏼

**Jeff Bergosh**: Good

### CONVERSATION ON 10-09-2020

**Jeff Bergosh**: Good Morning Brandon— hope you slept well 1st night back at the apartment.  Sorry about the Padres...... looks like the Dodgers are an unstoppable force.  I’ll see you at the house today at 3:00 for your appointment.  Love you!

**Brandon Bergosh**: Love you too dad❤️

**Jeff Bergosh**: This is where the appointment is today

**Jeff Bergosh**: So meet me at the house by 3:00 so we can make it on time

**Brandon Bergosh**: You’ll drive me right?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: But if you need a ride tell me a soon as possible if that’s what you

**Brandon Bergosh**: I’m coming to house, yes

**Brandon Bergosh**: I’ll be there in 10

**Brandon Bergosh**: Got stuck in “Davis” traffic

**Jeff Bergosh**: Ok

**Brandon Bergosh**: Did u grab my food from your backseat by chance?

**Brandon Bergosh**: Don’t make dinner tonight. Mom got us all food!

**Jeff Bergosh**: Awesome!!

### CONVERSATION ON 10-10-2020

**Jeff Bergosh**: This came for you today

**Brandon Bergosh**: Awesome

**Brandon Bergosh**: Should be having more come in soon! :)

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I’ll be home tomorrow night for dinner. Just catching up on school work right now. :)

**Jeff Bergosh**: Right on!

**Jeff Bergosh**: How’s that going?

**Brandon Bergosh**: & Monday after classes I’ll come by so you can help me with transfer (uwf) process!

**Jeff Bergosh**: Ok great!  

**Brandon Bergosh**: Liked “Ok great!  ”

**Brandon Bergosh**: Can you make something other than steaks tomorrow night plz? :)

**Jeff Bergosh**: Like what?

**Jeff Bergosh**: How about chicken?

**Brandon Bergosh**: Perfect, yes!!❤️

**Jeff Bergosh**: Okay

**Jeff Bergosh**: 2 more came in this afternoon

**Brandon Bergosh**: Don’t let mom open those

**Brandon Bergosh**: Please

**Jeff Bergosh**: I won’t 

### CONVERSATION ON 10-11-2020

**Brandon Bergosh**: I’m home. I’ll lyk how tomorrow goes❤️

**Brandon Bergosh**: Pray for me

**Jeff Bergosh**: I will.  I love u and you will do great!!

**Brandon Bergosh**: Loved “I will.  I love u and you will do great!!”

**Brandon Bergosh**: Lemme know how mom reacts to her gift please! :)

**Jeff Bergosh**: She likes the book and the belt!  Very thoughtful thanks Brandon!

**Brandon Bergosh**: Loved “She likes the book and the belt!  Very thoughtful thanks Brandon!”

**Jeff Bergosh**: Goodnight and good luck at school tomorrow!

**Brandon Bergosh**: Thanks popps, goodnight!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-12-2020

**Jeff Bergosh**: Good luck this morning at school!!

**Brandon Bergosh**: Loved “Good luck this morning at school!!”

**Brandon Bergosh**: Actually I just coordinated with my advisor to help me apply to UF, FSU, and UWF on Wednesday. Would you still like to play Tennis later? :)

**Jeff Bergosh**: Sure would!

**Brandon Bergosh**: Loved “Sure would!”

**Brandon Bergosh**: Perfect, I have to chang after my next class, but I should be at the “house” by 3! 

**Jeff Bergosh**: Right on!

**Jeff Bergosh**: R we still playing tennis?

**Brandon Bergosh**: Yes

**Brandon Bergosh**: I literally just got done changing. I’m gonna eat something light & then head that way!

**Jeff Bergosh**: 👍

**Brandon Bergosh**: You have racquets right?

**Jeff Bergosh**: Yes

**Jeff Bergosh**: I got them out of moms car

**Brandon Bergosh**: Liked “I got them out of moms car”

**Brandon Bergosh**: Now you can’t blame me when something revolving that goes SOUTH. Flush it away, dad.. for me

**Jeff Bergosh**: Ok

**Brandon Bergosh**: “Actions speak louder than words”

**Jeff Bergosh**: OK just drive careful I’ll talk to you when you get to your house love you

**Brandon Bergosh**: Do what’s RIGHT

**Brandon Bergosh**: Is all

**Brandon Bergosh**: Made it home safe. Thanks for inviting me to play tennis today.❤️

**Jeff Bergosh**: Love u B

**Brandon Bergosh**: Loved “Love u B”

**Jeff Bergosh**: Great catch by Keenan Allen!!!

**Brandon Bergosh**: Our kicker is ass though, damnn..😂

**Brandon Bergosh**: Liked “Guyton did that yesterday too”

**Jeff Bergosh**: Wow Chargers!!

**Brandon Bergosh**: Liked “Letssss goooo”

**Brandon Bergosh**: Liked “Wow Chargers!!”

### CONVERSATION ON 10-13-2020

**Jeff Bergosh**: Dial in Brandon

**Brandon Bergosh**: Getting out of shower gimme a minute or so

**Brandon Bergosh**: “Hyper-intellectual”

**Brandon Bergosh**: Is what I might be

**Brandon Bergosh**: Maybe

**Brandon Bergosh**: Thoughts?🤔

**Jeff Bergosh**: According to the call today?

**Brandon Bergosh**: No, but research on my own.

**Brandon Bergosh**: Do you think that’s even possible?

**Jeff Bergosh**: I’d have to know more

**Brandon Bergosh**: Quit walking if you still are. I have a bad feeling about you walking rn.

**Jeff Bergosh**: Does it just spontaneously occur?

**Brandon Bergosh**: ^

**Brandon Bergosh**: Listen to me ^^

**Brandon Bergosh**: We’ll talk later about it.

**Brandon Bergosh**: But QUIT walking for real

**Jeff Bergosh**: What makes you think I’m walking?

**Brandon Bergosh**: When I was in the car I got bumped off of Napster.

**Jeff Bergosh**: I thought your on Spotify now??

**Brandon Bergosh**: I use both.

**Brandon Bergosh**: Nick has Spotify.

**Brandon Bergosh**: & quit trying to distract me

**Brandon Bergosh**: Quit Walking

**Jeff Bergosh**: ?

**Brandon Bergosh**: & that was a YOU & ME conversation. Please leave it that way.

**Brandon Bergosh**: Luv ya popps❤️

**Jeff Bergosh**: 👍love u too!

**Brandon Bergosh**: I prayed for you today, dad. :)

**Jeff Bergosh**: Thank you!!!

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: I love ya’ll.❤️

**Jeff Bergosh**: Love u too!  How was school?

**Brandon Bergosh**: I prayed for you all today. Luv ya❤️

**Brandon Bergosh**: Loved “Best message ever!! I prayed for all of you too!!”

### CONVERSATION ON 10-14-2020

**Brandon Bergosh**: Yo, dad!

**Jeff Bergosh**: Hey what’s up?

**Brandon Bergosh**: Wyd today?

**Jeff Bergosh**: Working— 

**Jeff Bergosh**: 5:00 at Beulah park

**Brandon Bergosh**: Make it at UWF & I’ll be there!😌🤙🏼

**Jeff Bergosh**: Ask Tori.  I don’t mind either way

**Jeff Bergosh**: I have two racquets and two sleeves of tennis balls

**Brandon Bergosh**: Same

**Brandon Bergosh**: Just communicate with Tori & lemme know

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Also-  looks like you bought something at Cordova Mall and at the Tom Thumb recently.  Other than that no other money moved out of your accounts

**Brandon Bergosh**: Idk dad

**Brandon Bergosh**: I’ll just keep looking for it.

**Jeff Bergosh**: Mom’s going to look at the clinic

**Brandon Bergosh**: It isn’t there.

**Jeff Bergosh**: Chick fil a?  

**Jeff Bergosh**: So trace steps

**Brandon Bergosh**: Yea, I went to play basketball with my friends.

**Jeff Bergosh**: Where?

**Jeff Bergosh**: That’s where your wallet will be

**Brandon Bergosh**: No, because we went to Tom Thumb after. I think I just lost it & don’t remember where I put it.

**Jeff Bergosh**: Call that Tom Thumb

**Jeff Bergosh**: What about school this morning— did you have it there with you today???

**Brandon Bergosh**: I’m running late to class

**Jeff Bergosh**: It’s not been turned in at Tom Thumb I just called

**Brandon Bergosh**: I’ll figure it out

**Jeff Bergosh**: Call me after class and I’ll help you figure it out

**Brandon Bergosh**: Yessirr

**Brandon Bergosh**: This is why I suggested that I can go get food

**Brandon Bergosh**: I have enough change for food

**Brandon Bergosh**: & I’m hungry as hell

**Jeff Bergosh**: 👍

**Brandon Bergosh**: So can I please stop & get food, dad?

**Jeff Bergosh**: Yes of course

**Jeff Bergosh**: But call me when u get home

**Brandon Bergosh**: Liked “Yes of course”

**Brandon Bergosh**: Family comes first. Praying for you, dad❤️

**Brandon Bergosh**: Found it!!!

**Brandon Bergosh**: Bitch was hiding tho lol

**Jeff Bergosh**: Where was it?

**Jeff Bergosh**: ???

**Brandon Bergosh**: Hidden under my bed..

**Brandon Bergosh**: I’m just dumb

**Jeff Bergosh**: How could you and your roommates not have seen it when you tore your room apart this morning though??

**Brandon Bergosh**: We half ass looked 

**Jeff Bergosh**: Well, I’m just glad you found it 🙏😎👍

**Brandon Bergosh**: Are we playing tennis later or nah

**Jeff Bergosh**: Yes— but what about your homework?

**Brandon Bergosh**: I’ll probably just do that instead of church. 

**Brandon Bergosh**: U & me on a team for tennis?

**Jeff Bergosh**: Me against u and Tori 😁

**Brandon Bergosh**: A pig can wish lmao

**Jeff Bergosh**: ??

**Brandon Bergosh**: Cuz your a 3 legged pig

**Jeff Bergosh**: Tori and me against u

**Brandon Bergosh**: hehe

**Brandon Bergosh**: That’s not fair

**Jeff Bergosh**: What teams then?

**Brandon Bergosh**: You against me n Tori 

**Brandon Bergosh**: Unless mom can maybe get off of work

**Jeff Bergosh**: Okay!

**Jeff Bergosh**: Tori will meet us at 5:00 at UWF tennis courts

**Brandon Bergosh**: Do u think mom would be able to join us?

**Jeff Bergosh**: Don’t know — she’s got work

**Brandon Bergosh**: Well damn

**Jeff Bergosh**: See u at UWF at 5:00

**Brandon Bergosh**: Sounds good

**Brandon Bergosh**: 6451 North W street

**Brandon Bergosh**: 32505

**Brandon Bergosh**: I should probably shower too, right?

**Jeff Bergosh**: Yes

**Brandon Bergosh**: Okay

**Brandon Bergosh**: I found my wallet btw

**Brandon Bergosh**: It was in my dresser

**Brandon Bergosh**: It was in my dresser

### CONVERSATION ON 10-15-2020

**Jeff Bergosh**: Hey Brandon— did you get some sleep last night?

**Jeff Bergosh**: Call me when you can please

**Brandon Bergosh**: Can u get a hold of mom?

**Jeff Bergosh**: She is in a meeting

**Brandon Bergosh**: Okay, I just wanted to call her too & let her know that I’m feeling a lot better today.

**Brandon Bergosh**: Do you wanna meet Tori & me at UWF tonight at 7?

**Brandon Bergosh**: Play some tennis or sum

**Jeff Bergosh**: Okay Brandon, your Athsma test is tomorrow morning at 10:30AM.  It will be at 

West Florida Hospital, 8383 N. Davis Hwy, 32514

Walk in the main entrance, get checked/screened for COVID, then go to first office on left, they’ll get you prepped.  Any issues, call 

Carol.   494-4298

**Brandon Bergosh**: Got it. Plz quit stressing me out with all of this though I’m not perfect

**Brandon Bergosh**: Just want everyone to know that I slept great last night.

### CONVERSATION ON 10-16-2020

**Jeff Bergosh**: Brandon— Mom and I are working to get you an appointment.  When u get done at West Florida Hospital go over to mom’s office at the Health and Hope Clinic and we will go from there

**Brandon Bergosh**: Okay, will do

**Brandon Bergosh**: They didn’t really check me for COVID though btw

**Jeff Bergosh**: Did you find your appointment?

**Brandon Bergosh**: They only put a sticker on me

**Brandon Bergosh**: Yes I did

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Just finished filling out forms!

**Brandon Bergosh**: This medication is making me not be myself.

**Brandon Bergosh**: Any chance you could make an appointment?

**Jeff Bergosh**: I’m doing it rn

**Brandon Bergosh**: Okay 

**Jeff Bergosh**: We’re calling a couple different places to try and get you in today that’s why right after you’re done there you need to go to moms office

**Brandon Bergosh**: Okay

**Brandon Bergosh**: I’m gonna get some food from McDonald’s first, but after that I’ll go to mom

**Jeff Bergosh**: Ok sounds good

**Jeff Bergosh**: Let me know how your athsma test goes!

**Brandon Bergosh**: Yessir

**Brandon Bergosh**: I will

**Brandon Bergosh**: I scheduled an appointment & took care of it. Please don’t let me stress you out. I’ll get better. I already feel like I am getting better. I’ll see you tonight, dad. Luv ya❤️

**Jeff Bergosh**: Love you Brandon!

**Brandon Bergosh**: Loved “Love you Brandon!”

**Brandon Bergosh**: But what I was trying to say is that I was having voices in my head (triggered by nicotine). Currently I do not have anything wrong. Just a bit drowsy.

**Jeff Bergosh**: Okay well that’s a big relief for me Brandon!  I hope you can get a quick nap before work.  Plus I’m glad you’ll be hanging with us this weekend!

**Brandon Bergosh**: I’m gonna try & get a nap. I’ll stay the night tonight as well.

**Jeff Bergosh**: Liked “I’m gonna try & get a nap. I’ll stay the night tonight as well.”

### CONVERSATION ON 10-17-2020

**Jeff Bergosh**: I’m going to bring McDonald’s home for breakfast when I finish playing tennis what would you like me to get for you?

**Brandon Bergosh**: Sausage egg & chz McMuffin 

**Brandon Bergosh**: Thanks :)

**Jeff Bergosh**: Got it!

**Brandon Bergosh**: Sweet😊

**Brandon Bergosh**: Coffee (caffeine) appears to help! :))

**Jeff Bergosh**: 👍

**Jeff Bergosh**: I just stopped at Publix and got you your spare inhaler in case you need it 👌👍

**Brandon Bergosh**: Thank ya :)

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Now I’ll have one at apartment & house👌🏼

**Jeff Bergosh**: Yep!

### CONVERSATION ON 10-18-2020

**Brandon Bergosh**: I made it home safe btw❤️

### CONVERSATION ON 10-19-2020

**Jeff Bergosh**: 👍did u get good sleep last night?

**Brandon Bergosh**: I got sleep, yessir! :)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Love u and I hope you have a great day like yesterday!!!

**Brandon Bergosh**: I will & I love you too dad! :)

### CONVERSATION ON 10-21-2020

**Brandon Bergosh**: Where/when do you think I should pick up my prescription?

**Jeff Bergosh**: I’ll get it for you— is it at Publix?

**Jeff Bergosh**: Also, are you supposed to finish current course first— then start the steppes-down dosage?

**Brandon Bergosh**: She said it depends on how I’m feeling. She said I could just quit cold turkey tho if I felt like I’m good.

**Brandon Bergosh**: What do you think?

**Jeff Bergosh**: I don’t recommend that.  

**Jeff Bergosh**: Let’s finish The first course and then will start on the two week course directly after I’ll pick it up for you

**Brandon Bergosh**: That goes against what the Doc told me to do.

**Jeff Bergosh**: Okay then just start on the lower dose medicine today then— but I would not encourage you to just get off of the medicine cold turkey

**Jeff Bergosh**: You could pick it up yourself if you want and I’ll reimburse you.  It’s like $6.79 total and it’s ready at Publix

**Brandon Bergosh**: Okay, I’ll go pick it up. Thanks dad!

**Jeff Bergosh**: Love u!!

**Brandon Bergosh**: Ditto

### CONVERSATION ON 10-22-2020

**Jeff Bergosh**: Hey Brandon— do u want to play tennis this afternoon?

**Jeff Bergosh**: I could meet you at like 4:30 at Beulah Park if you are able, just let me know.  

Love you!

**Brandon Bergosh**: Sure! :)

**Brandon Bergosh**: & ditto

**Jeff Bergosh**: Okay see u at 4:30👍

**Brandon Bergosh**: Loved “Okay see u at 4:30👍”

**Jeff Bergosh**: Do me a favor and bring 2 Raquets and some balls because I left mine in moms car okay.  Thx!

**Brandon Bergosh**: Got it

**Brandon Bergosh**: No I can’t actually

**Jeff Bergosh**: Why not Brandon?

**Brandon Bergosh**: I have clinic today

**Brandon Bergosh**: Volunteering

**Jeff Bergosh**: Oh—okay, I forgot about that.

**Jeff Bergosh**: We can play Saturday

**Brandon Bergosh**: Maybe uwf later tonight

**Jeff Bergosh**: While moms at her tournament

**Brandon Bergosh**: No we can’t

**Brandon Bergosh**: I have work Saturday

**Jeff Bergosh**: Because tonight’s the debate

**Jeff Bergosh**: Sunday?

**Brandon Bergosh**: Sunday I’m available, yes!

**Jeff Bergosh**: Okay it’s on!

**Brandon Bergosh**: Sounds good

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Can I take a pack of waters?

**Jeff Bergosh**: Yes of course u can!!

**Brandon Bergosh**: Okay cool, thanks!

**Brandon Bergosh**: I made it home safe and will actually get some sleep in MY bed tonight. Luv ya dad❤️

**Jeff Bergosh**: Love u!!! Get some sleep!

**Brandon Bergosh**: I will

**Brandon Bergosh**: Liked “Love u!!! Get some sleep!”

### CONVERSATION ON 10-24-2020

**Jeff Bergosh**: Fried Chicken luncheon at our cul-de-sac starts at 12:15.  Come by and get some!  Love u!!

**Brandon Bergosh**: I’m about to head that way. See u in a bit!

**Jeff Bergosh**: Right on!

### CONVERSATION ON 10-25-2020

**Brandon Bergosh**: I’m home. Love you!

**Jeff Bergosh**: Love you Brandon!!

**Brandon Bergosh**: I just forwarded the refund form to you

**Jeff Bergosh**: Okay I’ll take it for action and fill it out for you

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Thanks!

**Jeff Bergosh**: Did u send it to my jeffbergosh@gmail.com. ?

**Brandon Bergosh**: Yessir

### CONVERSATION ON 10-26-2020

**Jeff Bergosh**: I just sent it back completed.  You just need to have a PSC financial aid rep complete section 4 and then submit this to Mrs. Coxwell along with your Baptist Hospital Form (the same one you showed your professors and your boss at 5-sisters)

Love you!

**Jeff Bergosh**: Did you get it?

**Brandon Bergosh**: I’ve been busy. I’ll get to it.

**Jeff Bergosh**: ?????

**Jeff Bergosh**: You’re Welcome

**Brandon Bergosh**: I haven’t checked yet (I’ve been busy). Thank you, I love you too!

**Jeff Bergosh**: 👍😎

### CONVERSATION ON 10-28-2020

**Jeff Bergosh**: Hey Brandon— we are cooking Ribeye steaks tonight at the house, will be ready to eat at 6:00PM.  Swing by and join us for dinner if you can.  We love you!!

**Brandon Bergosh**: Church is more important, sorry, not sorry! Love you!❤️

**Jeff Bergosh**: Okay I was just thinking you could eat before you went but that’s fine we love you

**Brandon Bergosh**: You right, I’ll be there at 6!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-29-2020

**Brandon Bergosh**: I sign this?

**Jeff Bergosh**: Yes, and date it and turn it in with the other form

**Brandon Bergosh**: Okay

**Brandon Bergosh**: Thanks again dad!

**Jeff Bergosh**: Absolutely!  

**Brandon Bergosh**: I’m taking care of it now

**Jeff Bergosh**: Right on!

**Brandon Bergosh**: I’m quitting

**Jeff Bergosh**: Good Morning Brandon.  I heard on the radio this morning that PSC will be open today starting at 8 AM. I printed out those two forms for you they are on the desk right under your keys. On the one form you will need to have the financial aid office sign off. You will also need to provide your excuse from the hospital as a part of the submission. You should have one extra copy of your discharge paperwork in the blue folder.  Also the section on student aid and cares act: I checked yes and no you did not receive any student financial loans or aid but you did receive one cares act grant of $750 and if they ask you about it tell them it was to offset living expenses from being laid off at your job due to Covid. Love you hope you have a great day and it was great seeing you last night!

**Brandon Bergosh**: Loved “Good Morning Brandon.  I heard on the radio this morning that PSC will be open today starting at 8 AM. I printed out those two forms for you they are on the desk right under your keys. On the one form you will need to have the financial aid office sign off. You will also need to provide your excuse from the hospital as a part of the submission. You should have one extra copy of your discharge paperwork in the blue folder.  Also the section on student aid and cares act: I checked yes and no you did not receive any student financial loans or aid but you did receive one cares act grant of $750 and if they ask you about it tell them it was to offset living expenses from being laid off at your job due to Covid. Love you hope you have a great day and it was great seeing you last night!”

**Brandon Bergosh**: Thanks dad!

### CONVERSATION ON 10-30-2020

**Jeff Bergosh**: Good — I’m proud of you!

**Brandon Bergosh**: Loved “Good — I’m proud of you!”

### CONVERSATION ON 10-31-2020

**Jeff Bergosh**: Hey Brandon mom and I just put $375 into your checking account for your rent tomorrow. We got you covered for the month and we love you!

**Brandon Bergosh**: The best parents. Thanks dad, love you too!

**Jeff Bergosh**: Brandon— they need you to stop by the Kia Dealership with the car so they can install the spare tire kit I purchased for you.  

**Brandon Bergosh**: I have work at 5. I’ll try & swing by there tomorrow.

**Jeff Bergosh**: They’re closed Sundays so just swing by one day next week

**Jeff Bergosh**: 457-7772

**Brandon Bergosh**: Okay

**Jeff Bergosh**: Sad

**Brandon Bergosh**: Whoah

**Brandon Bergosh**: Take yours & lets see

**Brandon Bergosh**: Politicalcompass.org

**Brandon Bergosh**: Everyone should take it😌

### CONVERSATION ON 11-03-2020

**Jeff Bergosh**: Hey Brandon hope everything’s going good just wanted to remind you today is election day your last chance to vote so make sure that you do vote. The only place you can vote today is at our precinct which is Beulah free Will Baptist Church on Mobile Highway over by the equestrian Center. Love you man

**Brandon Bergosh**: I’m heading that way now. Love you too!❤️

**Jeff Bergosh**: Was it packed out??

**Brandon Bergosh**: I took a shower. I’m going now.

**Jeff Bergosh**: Let me know how packed it is

**Brandon Bergosh**: Will do! :)

**Brandon Bergosh**: Unfortunately we couldn’t get Nick to vote conservative. Line wasn’t to bad though.

**Jeff Bergosh**: Glad to hear you got your vote in.  I haven’t even talked with Nick about this year’s election.... figured he voted Biden.

**Brandon Bergosh**: Jennifer Brahier was a Professor of mine (fun fact) haha

### CONVERSATION ON 11-05-2020

**Jeff Bergosh**: Hey Brandon— I’m being sworn-in for my second term in office on Tuesday, November 17th at 9:00 in the morning downtown in the BCC chambers.  Please put it on your calendar I really want you all to be there with me as I take my oath.  It’s a big deal.  Love you!!

**Brandon Bergosh**: Loved “Hey Brandon— I’m being sworn-in for my second term in office on Tuesday, November 17th at 9:00 in the morning downtown in the BCC chambers.  Please put it on your calendar I really want you all to be there with me as I take my oath.  It’s a big deal.  Love you!!”

**Brandon Bergosh**: I’ll be there! :)

**Jeff Bergosh**: Right on!  Hey, also, don’t forget about going by Kia with the car to get the spare tire kit installed 😎👍

**Brandon Bergosh**: Going there now!

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-06-2020

**Brandon Bergosh**: Thanks for listening to me dad. I love you❤️

**Jeff Bergosh**: I love u too Brandon!

### CONVERSATION ON 11-07-2020

**Brandon Bergosh**: What golf course are you at?

**Jeff Bergosh**: Not there yet but will be heading to scenic hills after I get out of the shower

**Jeff Bergosh**: Want to meet me there and hit some golf balls?

**Brandon Bergosh**: Yea for sure!

**Jeff Bergosh**: Okay— let’s meet there at 11:15 okay

**Brandon Bergosh**: Okay!

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I’ll be a little late, but I’ll just meet you there!

**Jeff Bergosh**: Ok

### CONVERSATION ON 11-10-2020

**Jeff Bergosh**: Hey Brandon, don’t forget to take that $797 check to NFCU to deposit it into your savings acct to bring u back up to $13 K

**Brandon Bergosh**: Okay, got it!

### CONVERSATION ON 11-24-2020

**Brandon Bergosh**: Can you pick up more nicotine patches for me on your way home please

**Jeff Bergosh**: Okay

### CONVERSATION ON 11-25-2020

**Jeff Bergosh**: Hey do you want to go and pick up your bed and dresser today when I get off of work?

**Brandon Bergosh**: Yea sure!

**Jeff Bergosh**: OK when I get to the house I’ll take the cover off the back of my truck it’s really easy and will head over there and pick up your stuff

**Brandon Bergosh**: Okay sounds good

**Jeff Bergosh**: 👍love u

**Brandon Bergosh**: Love you too

### CONVERSATION ON 12-01-2020

**Jeff Bergosh**: Hey Brandon I just transferred $200 into your checking toward your rent.  Love u!

**Brandon Bergosh**: Thanks dad! Love you too!

**Jeff Bergosh**: 😎👍

### CONVERSATION ON 12-04-2020

**Jeff Bergosh**: Bike ride?

**Brandon Bergosh**: Yea

### CONVERSATION ON 12-08-2020

**Brandon Bergosh**: Got it, thank u! :)

**Brandon Bergosh**: It wasn’t a therapist meeting

**Jeff Bergosh**: What was it?

**Brandon Bergosh**: It was with that skinner lady & she prescribed me some medication to pick up 

**Jeff Bergosh**: Ok, good.  Was it helpful?

**Brandon Bergosh**: She only had 10 minutes to talk to me. She said I should talk to a therapist.

### CONVERSATION ON 12-10-2020

**Jeff Bergosh**: Hey Brandon the Chargers are playing New England in 10 minutes on channel 206 ESPN

**Jeff Bergosh**: Nvm Rams not Chargers

### CONVERSATION ON 12-17-2020

**Brandon Bergosh**: Your welcome

**Jeff Bergosh**: Thanks Brandon.  I’ve got a $20 for you

### CONVERSATION ON 12-26-2020

**Brandon Bergosh**: Turn around and head back

**Jeff Bergosh**: We r

### CONVERSATION ON 12-31-2020

**Jeff Bergosh**: Did you all get lost LOL

### CONVERSATION ON 01-04-2021

**Brandon Bergosh**: Oh yikes

### CONVERSATION ON 01-07-2021

**Brandon Bergosh**: We went to Mcguires & charged your number

**Jeff Bergosh**: LOL that’s great

**Brandon Bergosh**: When will you be home?

**Jeff Bergosh**: In a BCC meeting tonight right now

### CONVERSATION ON 01-08-2021

**Jeff Bergosh**: I hope they don’t stick you on the patio tonight at work!  It’s a cold, windy, winter day in Pensacola.  45 degrees and feels much colder than that with the wind....

**Brandon Bergosh**: nope I’m inside haha. That would suck

**Jeff Bergosh**: “Feels like temperature”. 39 degrees

**Brandon Bergosh**: Gotta love ole Pensacola weather

**Jeff Bergosh**: Just bundle up for your shift tonight if you’re going to be on the patio!

**Brandon Bergosh**: Liked “Just bundle up for your shift tonight if you’re going to be on the patio!”

### CONVERSATION ON 01-12-2021

**Jeff Bergosh**: Hey where r u and Tori?  I’m making Spaghetti on the hot plate tonight

**Jeff Bergosh**: Looks like a credit card!

**Brandon Bergosh**: Okay cool

**Brandon Bergosh**: I’m at Tyler’s

**Brandon Bergosh**: Tori is at work til 9

**Brandon Bergosh**: I’ll be home in a little

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-13-2021

**Brandon Bergosh**: Can I shower in your room yet?

**Jeff Bergosh**: Yep— it’s good to go

**Jeff Bergosh**: What time is your class?

**Brandon Bergosh**: 11

**Jeff Bergosh**: U better rush!!

**Brandon Bergosh**: 🤙🏼

### CONVERSATION ON 01-20-2021

**Brandon Bergosh**: Your gonna grow a third leg now right?!..😂

### CONVERSATION ON 01-27-2021

**Jeff Bergosh**: Hey Brandon are you at work? We’re about to go to bed and we’re turn off the lights anyway just checking on you love you.  Please lock the door when you get home

**Brandon Bergosh**: I’m leaving work yessir & will do! Love you too!

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Proud of ya Tori! :)

### CONVERSATION ON 01-29-2021

**Brandon Bergosh**: Laughed at “strange. I haven’t received one yet either. I’m surprised you weren’t one of the first people to get it... because you work with old people but also enjoy taco Tuesdays”

**Jeff Bergosh**: Hey everyone— I’m going to order papa johns stuffed crust pizza for dinner tonight for everyone!!😁😁😁.           Love,  Dad!

**Brandon Bergosh**: Loved “Hey everyone— I’m going to order papa johns stuffed crust pizza for dinner tonight for everyone!!😁😁😁.           Love,  Dad!”

### CONVERSATION ON 01-30-2021

**Jeff Bergosh**: Hey Brandon where are you?  Mom and I are worried about you.  Text us back and let us know where u are okay?

**Brandon Bergosh**: I’m okay

**Jeff Bergosh**: Okay we were worried.  You have to let us know if you’re leaving okay?

### CONVERSATION ON 02-05-2021

**Jeff Bergosh**: Hey Brandon— PSC just put money into your account—any idea what that’s for?  It’s $289.11 total.

**Brandon Bergosh**: No idea

**Jeff Bergosh**: Oh well- found money!

### CONVERSATION ON 02-17-2021

**Jeff Bergosh**: Hey Brandon, are you working tonight?

**Brandon Bergosh**: Yessir

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Hope you have a good night.  Love u!

**Brandon Bergosh**: ❤️

### CONVERSATION ON 02-23-2021

**Jeff Bergosh**: Hey are you awake Brandon?

**Jeff Bergosh**: Need to talk to u

**Brandon Bergosh**: Everything okay?

**Jeff Bergosh**: Yes— just wanting to coordinate with you:   

I have spoken to Dr Hirschhorn and set up your appointment with you him.  It is this Thursday, the 25th, at 1:00PM.  Because of COVID-19 it has to be over iPhone face time.  He will call you from this number 850-516-3740

**Jeff Bergosh**: Hi Brandon, Please do not forget your appt on Fri Feb 26 2021, 11:00am at Clarkson Eyecare - Nine Mile. We have added additional disinfection protocols at every step throughout your visit and taken every precaution for your safety. For details on how we are handling COVID-19 visit https://well.app/JIeyQW

In the event you are displaying flu like symptoms, we encourage you to reschedule your appointment. Please contact us at 850-479-2020 and we will be happy to reschedule your appointment.

**Brandon Bergosh**: Got it

**Jeff Bergosh**: 👍

### CONVERSATION ON 02-26-2021

**Jeff Bergosh**: 30 minutes from now

**Brandon Bergosh**: I know

**Brandon Bergosh**: Thanks

**Jeff Bergosh**: Use this card to pay for your visit today 😁.  Make sure to tell them that you need to leave today with a prescription for contact lenses because you need to order a years supply so make sure you leave today with a written contact lens prescription from this appointment so that I can take it and order your lenses for you

**Brandon Bergosh**: My vision got worse

**Jeff Bergosh**: Oh well that’s what happens...Minded too till I got Lasik. Meanwhile did you get your new prescription so I can order you a years worth of contacts?

**Brandon Bergosh**: Yea but the lady ordered a sample so I can try a different brand that won’t irritate my eyes as much

**Brandon Bergosh**: & I paid for the cover charge

**Jeff Bergosh**: Why didn’t you use the credit card I gave you?

**Brandon Bergosh**: Ohhh, I thought that was just the insurance card & they said they had it on file. Can you reimburse me?

**Jeff Bergosh**: How much?

**Brandon Bergosh**: $85

**Jeff Bergosh**: K

**Brandon Bergosh**: Thanks

**Jeff Bergosh**: Did u pay cash or your debit card?

**Brandon Bergosh**: Card

**Jeff Bergosh**: Okay

### CONVERSATION ON 03-06-2021

**Jeff Bergosh**: Brandon I am at the grocery store if there’s anything you’d like me to add to the list text it to me you were asleep when I made the list

**Brandon Bergosh**: Lunchables, licorice ropes, starbursts

**Brandon Bergosh**: & sweet tea

### CONVERSATION ON 03-11-2021

**Jeff Bergosh**: Also, did you find out about the contact lenses? Do They have the prescription so I can order them for you for the upcoming year?

**Brandon Bergosh**: I picked up the sample pair today

**Jeff Bergosh**: Okay

### CONVERSATION ON 03-12-2021

**Brandon Bergosh**: I got 1,500 from that cares grant from PSC

**Brandon Bergosh**: pretty sweet!

**Jeff Bergosh**: Nice!!!

### CONVERSATION ON 03-16-2021

**Jeff Bergosh**: R u at home?

**Brandon Bergosh**: Yessir

**Jeff Bergosh**: Do u want to meet at Beulah Park for tennis?

**Jeff Bergosh**: Let me know and I can change clothes here before I head home if u want to play

**Brandon Bergosh**: Not today

**Jeff Bergosh**: Okay

### CONVERSATION ON 03-18-2021

**Brandon Bergosh**: I need you to change it that won’t work

**Brandon Bergosh**: 1 pm or later

**Brandon Bergosh**: Or Tuesday anytime

**Brandon Bergosh**: I have therapist at 11am

**Brandon Bergosh**: That was the only time he had. Why can’t you change the dental appointment?

### CONVERSATION ON 03-19-2021

**Jeff Bergosh**: Hey Brandon me and mom ordered pizza for dinner tonight from Papa John’s stuffed crust so just wanted to know if you’re gonna be here for dinner love you!

**Brandon Bergosh**: I’ll be home by 10 from work. Plz save me some!

**Jeff Bergosh**: We did it’s in the fridge!

### CONVERSATION ON 03-24-2021

**Brandon Bergosh**: April 20 11:20

**Jeff Bergosh**: 👍

### CONVERSATION ON 03-25-2021

**Jeff Bergosh**: Liked “We did it’s in the fridge!”

**Brandon Bergosh**: Will do! Thanks dad, love you! :)

**Jeff Bergosh**: 👍

**Jeff Bergosh**: *front

**Brandon Bergosh**: Okay

### CONVERSATION ON 03-27-2021

**Jeff Bergosh**: Remember to put your uniform in the dryer

**Brandon Bergosh**: Okay

### CONVERSATION ON 04-01-2021

**Brandon Bergosh**: Laughed at “Dad I get a call like that every 5 minutes. I’m numb to them at this point ”

### CONVERSATION ON 04-02-2021

**Jeff Bergosh**: Hey Brandon do you want to meet for tennis this afternoon at Beulah Park when I get off of work? It’s a beautiful day out here!

**Jeff Bergosh**: Just let me know Brandon—- I’ve got my racket in my truck love you!

**Brandon Bergosh**: I have work at 5 otherwise I would :/

**Jeff Bergosh**: Oh. Okay bummer— I was thinking u worked day shift.  Alright well we need to play this weekend👍

**Jeff Bergosh**: Love u

**Brandon Bergosh**: Okiedokie

**Brandon Bergosh**: Love you too

**Brandon Bergosh**: Happy Birthday btw, old man😌

**Jeff Bergosh**: Thanks Brandon!  I can’t believe I’m 53.  I feel like I just turned 23..... it literally feels like yesterday!

**Brandon Bergosh**: Loved “Thanks Brandon!  I can’t believe I’m 53.  I feel like I just turned 23..... it literally feels like yesterday!”

**Brandon Bergosh**: haha I love you popps

**Brandon Bergosh**: Our pitching staff is gonna be clutch for us this year

### CONVERSATION ON 04-07-2021

**Brandon Bergosh**: Which guy?

### CONVERSATION ON 04-10-2021

**Brandon Bergosh**: Hey dad can u make sure my uniform is ready for work tonight? I’m gonna be stuck here for over an hour

**Jeff Bergosh**: Mom just put it in the washer 👍

**Brandon Bergosh**: Thanks

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-12-2021

**Jeff Bergosh**: Hey Brandon— this is your reminder to go pick up more uniform shirts and pants.  Also— I have you all set up for the passport renewal tomorrow.  I’ll tell you all about it when I get home. Love u-  Dad

**Brandon Bergosh**: Loved “Hey Brandon— this is your reminder to go pick up more uniform shirts and pants.  Also— I have you all set up for the passport renewal tomorrow.  I’ll tell you all about it when I get home. Love u-  Dad”

### CONVERSATION ON 04-13-2021

**Brandon Bergosh**: Where am I supposed to go?

**Jeff Bergosh**: Go to the front entrance and go through the metal detectors.  Ask security to point you to the clerks office.  It’s on the first floor off to the left from the security area in the lobby

**Brandon Bergosh**: Idk how to get there

**Jeff Bergosh**: Go downtown

**Jeff Bergosh**: 221 Palafox place

**Brandon Bergosh**: Okay got it

**Brandon Bergosh**: Thanks

**Jeff Bergosh**: Front of bldg

**Jeff Bergosh**: Then once you go to the metal detector ask them where do I how do I get to the clerk of the courts office is on the first floor? They’ll walk you through some double doors pass and vending machines on the left and then when you get in there ask for the passport office

**Brandon Bergosh**: Okay I took care of it

**Brandon Bergosh**: They said it’ll be shipped in like late May

**Jeff Bergosh**: Awesome.  How much were the checks.  Did u get a receipt?

**Jeff Bergosh**: So I can register it

**Brandon Bergosh**: It was expensive

**Jeff Bergosh**: In my checkbook 

**Brandon Bergosh**: I forget exactly how much

**Jeff Bergosh**: No receipt

**Jeff Bergosh**: ?

**Brandon Bergosh**: Nope

**Jeff Bergosh**: Ballpark? 

**Brandon Bergosh**: $173 & $86

**Jeff Bergosh**: Do those numbers look right?

**Brandon Bergosh**: Yeah

**Jeff Bergosh**: 👍

### CONVERSATION ON 04-15-2021

**Brandon Bergosh**: 1pm next Tuesday

**Jeff Bergosh**: ❤️❤️👍👍

### CONVERSATION ON 04-17-2021

**Brandon Bergosh**: That’s awesome dad, thankyou!!!❤️

**Jeff Bergosh**: 👍👍

**Brandon Bergosh**: I just requested those dates off! 

### CONVERSATION ON 04-18-2021

**Jeff Bergosh**: Hey Brandon I just called Publix they have two of your medicines ready for pick up if you want to stop by there on the way home if you’re off from work they’re ready to go

### CONVERSATION ON 04-20-2021

**Jeff Bergosh**: https://yapi.me/co?m=ndxgd1w9jypn4

**Brandon Bergosh**: Weird

**Brandon Bergosh**: What’s the address again?

**Jeff Bergosh**: 4461 Bayou Blvd

### CONVERSATION ON 04-22-2021

**Jeff Bergosh**: Hey Brandon— where r u??

**Brandon Bergosh**: Just got food what’s up

**Jeff Bergosh**: Just making sure you’re okay that’s all ❤️👍

### CONVERSATION ON 04-29-2021

**Brandon Bergosh**: Keep me posted

**Brandon Bergosh**: Bowling

### CONVERSATION ON 04-30-2021

**Jeff Bergosh**: Hey Brandon I would suggest you get some sleep now ——-because at 9 o’clock Danny is going to be there finishing the floor in the hallway. If the noise gets too loud you can always go crash in our room on the other side of the house. Love you

**Brandon Bergosh**: Love you too

### CONVERSATION ON 05-01-2021

**Brandon Bergosh**: What time are we leaving?

**Jeff Bergosh**: 12:30

### CONVERSATION ON 05-03-2021

**Brandon Bergosh**: hahaha

### CONVERSATION ON 05-04-2021

**Jeff Bergosh**: Happy Birthday and May the 4th be with you!!   Love you!

Dad

**Brandon Bergosh**: Thanks dad! Love you too! :)

**Jeff Bergosh**: Brandon-  let mom know I’m inside the restaurant and I’m at the table 

**Brandon Bergosh**: Okay we’re basically there!

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-06-2021

**Jeff Bergosh**: Hey Brandon I’m bringing a large Pizza home for you tonight—pepperoni and sausage from Graffiti Pizza

**Brandon Bergosh**: Awesome!

**Jeff Bergosh**: 👍

### CONVERSATION ON 05-08-2021

**Brandon Bergosh**: You got me here way too early

**Jeff Bergosh**: Have a snack at the restaurant

**Brandon Bergosh**: I had some drinks

**Jeff Bergosh**: Go easy.......

**Brandon Bergosh**: Only 2. Relax

**Jeff Bergosh**: U on plane yet??!!??

**Brandon Bergosh**: Not yet but we’re about to

**Jeff Bergosh**: Okay— have a safe flight!

**Jeff Bergosh**: Did u make it to Baltimore?

**Brandon Bergosh**: Yessirr

**Jeff Bergosh**: When do u catch the flight to Milwaukee?

**Brandon Bergosh**: 3:20

**Jeff Bergosh**: R u at your gate already?

**Brandon Bergosh**: Yeah

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Alright have a safe flight

**Brandon Bergosh**: That’s the plan lol

**Brandon Bergosh**: It would be cooled off by end of October/November 

### CONVERSATION ON 05-10-2021

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I don’t see $200?

**Brandon Bergosh**: Wack

### CONVERSATION ON 05-12-2021

**Brandon Bergosh**: Should be landing in Pcola @ 10:45

**Jeff Bergosh**: Okay Mom will be there

**Jeff Bergosh**: What flight #

**Brandon Bergosh**: Sounds good

**Brandon Bergosh**: #2602

**Jeff Bergosh**: From which airport?

**Brandon Bergosh**: Nashville

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Have a safe flight, love u!

**Brandon Bergosh**: Love you too❤️

### CONVERSATION ON 05-14-2021

**Jeff Bergosh**: Don’t know where you are or where you’ve been but when u get home park your car on the opposite side of the cul-de-sac by Mike’s house do not park in front of the mailbox where we won’t get our delivery. Move the car to the opposite side of the cul-de-sac please so that the window installers and cabinet installers who will be working all day at our house—-and their giant trucks—-have a place to park and so they don’t pull into the lawn and wreck my sprinkler pipes again!

**Brandon Bergosh**: I’ve been at Josh’s but okay will do!

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Josh Perdue?

**Brandon Bergosh**: Yeah

### CONVERSATION ON 05-16-2021

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: Disliked an image

### CONVERSATION ON 05-17-2021

**Brandon Bergosh**: Can u help?

**Jeff Bergosh**: Sure.  What is it?

**Brandon Bergosh**: I sent u a picture with blanks that I don’t know

**Brandon Bergosh**: ^

**Jeff Bergosh**: Is that information from my license?  And my vehicle?

**Brandon Bergosh**: No it’s for mine

**Brandon Bergosh**: Yikes 

### CONVERSATION ON 05-20-2021

**Jeff Bergosh**: Can you play tennis Saturday morning at 8:30 with me?

**Jeff Bergosh**: For about an hour and a half done by 10

**Brandon Bergosh**: Yeah!

**Jeff Bergosh**: Okay cool thanks!

### CONVERSATION ON 05-21-2021

**Jeff Bergosh**: Remember don’t drink and drive, no matter what.  Call me if u need a ride and I’ll pick u up.

**Brandon Bergosh**: I’m just staying the night at Josh’s 

**Brandon Bergosh**: & I know dad

**Jeff Bergosh**: Ok that’s a good idea.  Love u

**Brandon Bergosh**: Love you too

### CONVERSATION ON 05-23-2021

**Jeff Bergosh**: I’m making pot roast for dinner tonight!

**Brandon Bergosh**: Hell yea!

### CONVERSATION ON 05-24-2021

**Jeff Bergosh**: 👍👍

**Brandon Bergosh**: Loved a movie

### CONVERSATION ON 05-25-2021

**Brandon Bergosh**: Do we not have a blender anymore to make smoothies?!

**Jeff Bergosh**: Yes

**Jeff Bergosh**: Bottom shelf

**Brandon Bergosh**: Okay

**Jeff Bergosh**: Did u find it?

**Brandon Bergosh**: Yeah, thanks!

**Jeff Bergosh**: No prob

**Jeff Bergosh**: When u are done using it, rinse the blender part out thoroughly and put it in the dishwasher on the bottom rack, along with the lid on the top rack.  Then, put the base of the blender back into the cabinet where you got it.  Thanks 

**Brandon Bergosh**: k

**Jeff Bergosh**: 👍

**Brandon Bergosh**: That’s dope dude

### CONVERSATION ON 05-28-2021

**Jeff Bergosh**: Did u make it to Orlando safely?

**Brandon Bergosh**: Yessirrr

**Jeff Bergosh**: Have fun and be safe

**Jeff Bergosh**: Where are u staying?

**Brandon Bergosh**: Air bnb

**Jeff Bergosh**: Ha ha

**Jeff Bergosh**: I know

**Brandon Bergosh**: I’ll just send u my location

**Jeff Bergosh**: Ok

**Jeff Bergosh**: Thx!  So you’re staying at house of blues, very cool 😂 

**Brandon Bergosh**: hahah no we’re just at the bar there. It was happy hour. The beers on the walk here were $16 & they are $4 here so just being smart ya know😌😂

**Brandon Bergosh**: I wouldn’t wanna be the test dummy tho

### CONVERSATION ON 06-10-2021

**Jeff Bergosh**: Good for him!!

**Brandon Bergosh**: Wowww!!!

### CONVERSATION ON 06-17-2021

**Brandon Bergosh**: Nice

**Brandon Bergosh**: Your literally the worst

**Jeff Bergosh**: What???

**Brandon Bergosh**: I got food poisoning from Waffle House again

### CONVERSATION ON 06-26-2021

**Brandon Bergosh**: Guess whose at my table

**Jeff Bergosh**: Who?

**Jeff Bergosh**: Lumon?

**Brandon Bergosh**: Pastor Locke

**Jeff Bergosh**: Tell him I said Hi!

**Brandon Bergosh**: He said the same haha

**Jeff Bergosh**: 👍

### CONVERSATION ON 06-28-2021

**Brandon Bergosh**: I need to finish some stuff before I can make an appointment for classes. Can you help?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: What do u need?

**Brandon Bergosh**: I just sent u a pic of it

**Jeff Bergosh**: This will have to wait until I get home—I don’t have your shot records electronically they are hardcopy in the safe

**Brandon Bergosh**: Ok

**Jeff Bergosh**: We will get it sorted this afternoon

**Brandon Bergosh**: Okay

### CONVERSATION ON 06-29-2021

**Brandon Bergosh**: Sounds fun!

### CONVERSATION ON 06-30-2021

**Brandon Bergosh**: Hey dad did you happen to finish rent stuff?

**Jeff Bergosh**: Finishing it up this afternoon.  I’ll email it to u when it’s done.  The only thing I don’t have are your pay stubs.  Did u get them?

**Brandon Bergosh**: Yeah I have them!

**Brandon Bergosh**: Did you get a copy of my id?

**Jeff Bergosh**: You were going to take a picture of it

**Brandon Bergosh**: Ohhh that’s right okay!

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: Do u want me to print this out and bring it home— or scan it and send it to u?

**Brandon Bergosh**: Both if u can

**Jeff Bergosh**: Couldn’t scan them because you need to add some information to them. So I printed it out and I have it on top of your computer on the island in the kitchen. You need to sign it and add a few things a few details that I didn’t know and it’ll be all ready to go.

**Brandon Bergosh**: Okay

### CONVERSATION ON 07-03-2021

**Jeff Bergosh**: Hey Brandon I’m about to go to bed but if you need a ride I’ll come get you I know the restaurants closing soon so just let me know otherwise I guess you’d have to take an Uber.So if you’re ready for a ride by 10 o’clock let me know and I’ll head that way. Love you

**Brandon Bergosh**: k

**Jeff Bergosh**: Does that mean yes u want me to pick u up?

**Brandon Bergosh**: 1 sec

**Brandon Bergosh**: Yeah can u come get me 

**Jeff Bergosh**: Okay

### CONVERSATION ON 07-04-2021

**Jeff Bergosh**: R u getting off at 4:30?

**Brandon Bergosh**: Just doing side work rn

**Brandon Bergosh**: But if u can get me by 4:30 thats great!

**Jeff Bergosh**: Ok

**Jeff Bergosh**: Will be there @4:30

**Brandon Bergosh**: Okay

### CONVERSATION ON 07-05-2021

**Jeff Bergosh**: Mom and I left your key right there by your apron. You can drive to work and school and back for now. I put your uniform in the washer it needs to be moved to the dryer though you need to take care of that so that you’ll have a uniform ready by 10 do it right now

**Brandon Bergosh**: Liked “Mom and I left your key right there by your apron. You can drive to work and school and back for now. I put your uniform in the washer it needs to be moved to the dryer though you need to take care of that so that you’ll have a uniform ready by 10 do it right now”

**Jeff Bergosh**: Brandon where r u?

**Brandon Bergosh**: Leaving work

**Brandon Bergosh**: where r u?

**Jeff Bergosh**: We’re at home

### CONVERSATION ON 07-06-2021

**Brandon Bergosh**: I just registered for these classes!

**Jeff Bergosh**: Right on!

**Jeff Bergosh**: Are you going to get a fourth class to?

**Brandon Bergosh**: That is four classes

**Jeff Bergosh**: Awesome I miss read it and thought it said three classes. I’m happy are you excited?

**Brandon Bergosh**: Yeah!

**Brandon Bergosh**: Can u pick up more cream cheese & bagels on the way home please?

**Jeff Bergosh**: Yes 

**Brandon Bergosh**: Thank you!

**Jeff Bergosh**: 👍

### CONVERSATION ON 07-10-2021

**Jeff Bergosh**: Brandon drive safely after your work shift home tonight.  We’re here.

Love 

Dad

**Brandon Bergosh**: Will do

**Brandon Bergosh**: Love you!

### CONVERSATION ON 07-11-2021

**Jeff Bergosh**: Hey Brandon steaks are ready and we’re serving dinner are you on your way home?

### CONVERSATION ON 07-12-2021

**Jeff Bergosh**: Brandon— remember we are here if u need us and/or if u need a ride.  I’m assuming u are staying at Josh’s since you’re not home.  Let us know if that’s your plan,  no matter what, though——do NOT drive if you’ve had drinks.  Don’t do it.

We love u

Dad

**Brandon Bergosh**: I understand. Love you!

**Jeff Bergosh**: U staying at Josh’s?

**Brandon Bergosh**: Nah I’m finishing a movie at Josh’s I’ll be home in a bit

**Jeff Bergosh**: Okay be careful

### CONVERSATION ON 07-13-2021

**Jeff Bergosh**: R u going to watch the all-star game tonight at 6:30?

**Brandon Bergosh**: Maybe

**Brandon Bergosh**: Why?😂

**Jeff Bergosh**: Was just wondering

**Jeff Bergosh**: I’m going to watch it once I get home after I watch Mom’s tennis match at Roger Scott

**Brandon Bergosh**: Okay cool!

**Jeff Bergosh**: I think it starts at 6:30 so I’ll miss part of it

### CONVERSATION ON 07-15-2021

**Jeff Bergosh**: Remember, call if u need a ride.  Don’t drive if u are drinking.  No matter what!

### CONVERSATION ON 07-16-2021

**Brandon Bergosh**: I will

### CONVERSATION ON 07-20-2021

**Jeff Bergosh**: Are u working?  The NBA finals game 6 is on right now, and I brought Pizza home.

Love u

Dad

**Brandon Bergosh**: Watching at friends house!

**Jeff Bergosh**: Okay be safe and have fun!

**Jeff Bergosh**: Don’t drink and drive!

**Brandon Bergosh**: Sounds good

**Brandon Bergosh**: This game is tense

### CONVERSATION ON 07-24-2021

**Jeff Bergosh**: I’m getting this for you at Walmart it’s for smoothies

**Brandon Bergosh**: Yessss

**Brandon Bergosh**: Thx dad!

**Jeff Bergosh**: 👍👍

**Jeff Bergosh**: I remembered u asking about it, and I saw it today

**Brandon Bergosh**: Yeah that’s awesome

**Brandon Bergosh**: Moving in with josh on this Monday!

**Brandon Bergosh**: Always the plan

**Brandon Bergosh**: & nice! How is it?

**Brandon Bergosh**: Cool experience at least though

### CONVERSATION ON 07-26-2021

**Jeff Bergosh**: This popped up in my Facebook feed today.  I remember we didn’t catch any fish that day though!

**Brandon Bergosh**: Aww, I remember that! :)

**Jeff Bergosh**: I just remember it was HOT

**Brandon Bergosh**: It was a fun time though

**Jeff Bergosh**: Yep

### CONVERSATION ON 07-27-2021

**Brandon Bergosh**: This is how much my first semester of classes will cost.

**Jeff Bergosh**: Okay when is it due?

**Brandon Bergosh**: 8/29

**Jeff Bergosh**: Okay good I have some time to save up 👌🙂

**Brandon Bergosh**: Your gonna help me out?

**Jeff Bergosh**: Of course

### CONVERSATION ON 07-30-2021

**Jeff Bergosh**: Hey Brandon mom is bringing home Sonny’s BBQ so if you’re at the house just hang for a minute and you can take some with you

**Brandon Bergosh**: I’m at work :/

### CONVERSATION ON 08-02-2021

**Jeff Bergosh**: I just happened to speak with our head of Escambia public safety Eric Gilmore and he related to me that the three hospitals in Pensacola are now up to 216 COVID-19 patients as of this morning.  (Friday it was 160) ——-It’s exploding geometrically at this point so be safe and stay away from people if u can!

Love u all

Dad

**Brandon Bergosh**: If we’re vaccinated we should be fine though, right?

**Jeff Bergosh**: Yes— but there are some breakthrough cases happening, where vaccinated folks are getting infected...5-10 %.   So be aware of that.

### CONVERSATION ON 08-03-2021

**Brandon Bergosh**: Thursday night?!

### CONVERSATION ON 08-04-2021

**Jeff Bergosh**: Hey we’re in the IPC— r u here?

**Brandon Bergosh**: 15 away

**Jeff Bergosh**: Ok

**Jeff Bergosh**: Do u want me to order for u?

**Brandon Bergosh**: No that’s okay

**Jeff Bergosh**: 😀

### CONVERSATION ON 08-05-2021

**Jeff Bergosh**: Love u

**Brandon Bergosh**: Hahah

### CONVERSATION ON 08-06-2021

**Brandon Bergosh**: Hey dad I’m not feeling good. What clinic can I go to?

**Jeff Bergosh**: Marathon Health

**Jeff Bergosh**: What’s wrong?

**Brandon Bergosh**: Thank you

**Brandon Bergosh**: I have a sore throat, runny nose, fever, etc..

**Jeff Bergosh**: Uh oh!  But you had your shots right?

**Jeff Bergosh**: Call them first so they know you’re coming

**Brandon Bergosh**: Yeah I did

**Brandon Bergosh**: Do I need to call the place or can I just show up?

**Jeff Bergosh**: Call first

**Jeff Bergosh**: Show them these cards when you get there as well. You should be in their system

**Brandon Bergosh**: Okay will do. I’m on the phone with them rn.

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Thanks dad

**Jeff Bergosh**: No problem let me know how it turns out OK. Love you

**Brandon Bergosh**: Love you too

**Jeff Bergosh**: I hope it’s just a cold and not Covid

**Brandon Bergosh**: Same

**Jeff Bergosh**: Either which way though you’ll be fine

**Brandon Bergosh**: They just got done cotton swabbing my nostrils

**Brandon Bergosh**: Yuck

**Jeff Bergosh**: Did it hurt?

**Brandon Bergosh**: Nah, just felt weird & my eyes started watering haha

**Jeff Bergosh**: Howtest to come back?

**Brandon Bergosh**: They’re still testing it 

**Brandon Bergosh**: It came back negative

**Jeff Bergosh**: That’s fantastic will go home and get some sleep and just take a NyQuil

**Jeff Bergosh**: Top shelf above the stove I’ve got DayQuil and NyQuil

**Brandon Bergosh**: Ima pick some up on the way home

**Brandon Bergosh**: They think I should quarantine tho because she said it could be a false negative since it’s only been like 2 days. A healthcare provider is gonna call me again at like 1:30 too.

**Jeff Bergosh**: You should call your work and give them heads up

**Jeff Bergosh**: Just wear an astronaut suit so you don’t get us sick though :-)

**Brandon Bergosh**: Haha we’ll see

### CONVERSATION ON 08-07-2021

**Brandon Bergosh**: Call me

**Jeff Bergosh**: Trying— just rings and rings

**Jeff Bergosh**: I’m at tennis but I’ll keep trying to call u

**Brandon Bergosh**: It’s fine ima just tough it out at work and wear a mask

**Jeff Bergosh**: Okay love u

**Brandon Bergosh**: Love u too

**Jeff Bergosh**: Hey Brandon I’m just checking in on you man how are you feeling?

**Jeff Bergosh**: I hope that you’re feeling better let us know OK love you

**Brandon Bergosh**: Just powering through it, didn’t wanna miss any more work. 

**Brandon Bergosh**: I think it’s just a cold though

**Jeff Bergosh**: OK just let us know if you need us to take it in Tori said you couldn’t taste anything?

**Jeff Bergosh**: I suggest you get a good nights sleep tonight before brunch tomorrow

**Brandon Bergosh**: I was cap. I could taste fine

**Brandon Bergosh**: & yea I will for sure

**Brandon Bergosh**: Somebody call me back please

**Brandon Bergosh**: I talked to Tori. Yea

### CONVERSATION ON 08-08-2021

**Jeff Bergosh**: Hey Brandon Call me tomorrow and let me know how you’re feeling, and how the NFCU visit goes.  Also, I want to talk about your tuition 

Love u!

**Brandon Bergosh**: Sounds good, love u too

### CONVERSATION ON 08-09-2021

**Brandon Bergosh**: I just replaced my debit card

**Jeff Bergosh**: Good did they sort out the bad charges?

**Brandon Bergosh**: Yea

**Jeff Bergosh**: Good!

**Jeff Bergosh**: 🤪🤪🤪

**Brandon Bergosh**: Nooo

**Jeff Bergosh**: My new exercise shoes!

**Brandon Bergosh**: Wow u stole my shoes!🙈😂

**Jeff Bergosh**: 🤡🤡

**Jeff Bergosh**: They just look remarkably similar to a pair you must’ve missplaced lol

**Brandon Bergosh**: Your ridiculous hahaha

**Jeff Bergosh**: 😾😾

**Jeff Bergosh**: “5-Star”.  Just like Stuber!!

### CONVERSATION ON 08-13-2021

**Jeff Bergosh**: Hey Brandon me and mom have the condo all weekend if you’d like to come out and crash I’ve got the spare room or if you just wanna come by and swim or use the tennis courts we’ve got it all weekend. Love you hope all is going well!

Dad

**Brandon Bergosh**: Oh that’s awesome! I’m actually a double today & tomorrow and also work Sunday brunch but I’ll try & make it out there after I get off on Sunday! Love ya

**Jeff Bergosh**: Love you too Brandon!

### CONVERSATION ON 08-21-2021

**Brandon Bergosh**: Anyone home?

**Jeff Bergosh**: I am

**Jeff Bergosh**: Did u come by?

**Brandon Bergosh**: Oh okay nvm

**Jeff Bergosh**: R u working today?

**Brandon Bergosh**: I was gonna come by if everyone was home

**Brandon Bergosh**: I actually have a Saturday off for once lol

**Jeff Bergosh**: We’re at beach.  Come out and check out the condo

### CONVERSATION ON 08-22-2021

**Jeff Bergosh**: Brandon— we’re back from the condo and we’d love to have u over for dinner tonight.  Come on by if you can,  food will be ready at 6:30!

Love,

Dad

**Brandon Bergosh**: I start school tomorrow

**Jeff Bergosh**: I know!!

**Brandon Bergosh**: I’ll try

**Jeff Bergosh**: We’re excited!!

**Brandon Bergosh**: hey dad I’m not gonna make it tonight. I’m exhausted from work probably gonna sleep

**Jeff Bergosh**: Okay totally understand.  Love u!  Have a great first day back at school!  I’m excited for you!!!!!

**Brandon Bergosh**: Thx dad, love you

### CONVERSATION ON 08-23-2021

**Jeff Bergosh**: How was first day?

**Brandon Bergosh**: So far so good! :)

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-24-2021

**Jeff Bergosh**: How was day one?

**Brandon Bergosh**: Pretty good!

**Jeff Bergosh**: Do you like the classes?

**Brandon Bergosh**: So far so good, yea!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-25-2021

**Jeff Bergosh**: Is my lunch break this is my workout time I need my Napster

**Brandon Bergosh**: It’s mine too inbetween classes

**Brandon Bergosh**: Get off of it lol

**Jeff Bergosh**: The battle of Napster

**Brandon Bergosh**: hahahah

**Jeff Bergosh**: 😎👍

**Jeff Bergosh**: By the way when are you gonna pay your tuition? Isn’t it due? The sooner you pay the sooner we can refund you or half

**Brandon Bergosh**: I’ll pay it tomorrow

**Jeff Bergosh**: 👍

**Jeff Bergosh**: That should help right?

**Brandon Bergosh**: Yeah thanks

**Jeff Bergosh**: How are your classes

**Brandon Bergosh**: So far so good

**Brandon Bergosh**: I’ll be busy! Haha

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-26-2021

**Jeff Bergosh**: How did the burritos turn out?

**Brandon Bergosh**: They were great

**Brandon Bergosh**: I don’t think I got the right kinda meat but they still were great

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I just paid for it

**Brandon Bergosh**: & all my books 

**Jeff Bergosh**: Okay, me and mom will reimburse half

**Brandon Bergosh**: Liked “Okay, me and mom will reimburse half”

**Brandon Bergosh**: Thx dad, love you!

**Jeff Bergosh**: Love you!

**Jeff Bergosh**: You’ll probably be working but there will be a DUI checkpoint set up Friday night —-just so you know.  Drive safe always.

Love

Dad

**Brandon Bergosh**: I’m only catching rides from friends now when I go out lol but I will be!

**Jeff Bergosh**: 👍

### CONVERSATION ON 08-28-2021

**Jeff Bergosh**: Sorry I accidentally pocket dialed you love you

Dad

**Brandon Bergosh**: Love you too! Move everything into condo okay?

### CONVERSATION ON 08-29-2021

**Jeff Bergosh**: Yep got it done— thanks for your help!

**Jeff Bergosh**: Drive careful today it’s really, really windy

**Brandon Bergosh**: Yessir

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: That’s awesome

### CONVERSATION ON 08-30-2021

**Jeff Bergosh**: Brandon— I just transferred money into your checking account.  $200 toward your rent and $653.43 for half of what we owe you for your tuition payment.  Total of $853.43 today.  We will pay you the other half on October 1st.  So on October 1st it will be another payment of $853.43 then we’ll be square with this semester’s half of tuition.  Then on November 1st we’ll transfer $200 for rent, on December we’ll transfer $200 for rent, and so on.

Love you— drive safe in this crazy weather!

Dad

**Brandon Bergosh**: Thanks dad, love you too!

### CONVERSATION ON 08-31-2021

**Jeff Bergosh**: Brandon:  did u grab the spare key I had for your vehicle?  I’m missing two spare keys:  one for your vehicle and one for the Mom’s BMW— they’re not in my bag but we’re there two weeks ago.  Need to know where they are??

**Brandon Bergosh**: I haven’t grabbed any keys

**Jeff Bergosh**: So you only have the one key for your vehicle?

**Brandon Bergosh**: Just the same old one, yea

**Jeff Bergosh**: K

### CONVERSATION ON 09-01-2021

**Brandon Bergosh**: Get off my Napster fool

**Jeff Bergosh**: LOL

**Jeff Bergosh**: I’m on a workout

### CONVERSATION ON 09-02-2021

**Brandon Bergosh**: Did u change the Netflix stuff?

**Jeff Bergosh**: No, why?

**Jeff Bergosh**: Can u not get in?

**Brandon Bergosh**: Nope

**Jeff Bergosh**: Okay let me look into it

**Jeff Bergosh**: See if it works 🙂

**Brandon Bergosh**: Okay thx dad

**Jeff Bergosh**: 👍

**Brandon Bergosh**: You have to make a plan or something through Netflix 

**Brandon Bergosh**: I’ll let u handle that

**Jeff Bergosh**: What?  You can’t log in?

**Brandon Bergosh**: Nope

**Jeff Bergosh**: I’ll have to fix it when I get home.  In a BCC mtg rn

**Brandon Bergosh**: Okay

**Jeff Bergosh**: All right Brandon I think I got it figured out here’s the email

District1@myescambia.com

And the password 

Autumn2012

**Brandon Bergosh**: No the email was right

**Jeff Bergosh**: Nope

**Jeff Bergosh**: Try that combination

**Brandon Bergosh**: Oh okay

### CONVERSATION ON 09-04-2021

**Jeff Bergosh**: Hey Brandon mom and I are thinking about going to dinner at five sisters r u working tonight?

**Brandon Bergosh**: Nah, I left early bcuz it was slow

**Jeff Bergosh**: Do you want to go to dinner with us at Angela’s?

**Jeff Bergosh**: *Angelinas

**Brandon Bergosh**: I’m going on a date with girly

**Brandon Bergosh**: Next time!

**Jeff Bergosh**: All right no problem have fun and be safe we love you

**Brandon Bergosh**: Love you too!

**Jeff Bergosh**: Outstanding. Hey tomorrow MOM and I are going to go to brunch at flounder’s if you’d like to join us you’re welcome to do so just let us know and pack a swimsuit and you can see the condo after. Love you!

**Brandon Bergosh**: I work brunch tomorrow. But can I meet you at the condo after?

**Jeff Bergosh**: Of course! Come on out!

**Jeff Bergosh**: come on out whenever you all are able👍🙂

Gate and lobby code #7777

Front door of unit code

4021

Address

1200 Fort Pickens Road 
#2-C

**Brandon Bergosh**: Okay right on

**Brandon Bergosh**: Are you guys out there tonight too?

**Jeff Bergosh**: Yes

**Brandon Bergosh**: Does it take a key to get in?

**Jeff Bergosh**: We have it for the whole month of September

**Brandon Bergosh**: Oh sick

**Jeff Bergosh**: No, it’s electronic

**Brandon Bergosh**: Oh cool

### CONVERSATION ON 09-05-2021

**Jeff Bergosh**: Hey man we’re at Crabs if u want to come out and join us!  

**Brandon Bergosh**: I’m exhausted, probably just gonna relax here

**Brandon Bergosh**: I’ll prolly head out there tomorrow tho!

**Jeff Bergosh**: Okay no worries come out tomorrow

**Jeff Bergosh**: 😎👍

**Brandon Bergosh**: Liked “Okay no worries come out tomorrow”

### CONVERSATION ON 09-09-2021

**Jeff Bergosh**: Hey Brandon just checking in to see how you’re doing we love you hopefully you’ll make it out to our condo while we have it this month hope school is going well love you dad

**Brandon Bergosh**: Thanks dad & I hopefully will! Just been “hectic & busy” lately haha. Love you too

**Jeff Bergosh**: 👍

### CONVERSATION ON 09-12-2021

**Brandon Bergosh**: I gota hella homework otherwise I would

**Jeff Bergosh**: Right on we love u!

**Jeff Bergosh**: Did u work brunch?

**Brandon Bergosh**: Yeah I did! Love you too

### CONVERSATION ON 09-14-2021

**Jeff Bergosh**: If not- we’re  going to cook out on Saturday and go out to dinner Sunday.

**Brandon Bergosh**: I have fraternity stuff I think

**Jeff Bergosh**: If you’re working all weekend, what about Thursday?

**Brandon Bergosh**: I should be able to make it Sunday

**Jeff Bergosh**: Okay— I’ll set up dinner Sunday night— I’ll let u know the time

**Brandon Bergosh**: Okay cool sounds good

**Jeff Bergosh**: right on Brandon Sunday at the grand Marlin at 5:45 for dinner. Love you!!

### CONVERSATION ON 09-19-2021

**Jeff Bergosh**: Hey Brandon and Tori— 

Just reminding you that we have dinner reservations with grandma and Boppa tonight at the Grand Marlin at 5:45.  See you all there—love Dad and Mom

**Brandon Bergosh**: I thought it was at 6:30?

**Jeff Bergosh**: 5:45

**Brandon Bergosh**: okay

**Jeff Bergosh**: 👍

**Jeff Bergosh**: We’re here and seated

**Brandon Bergosh**: Liked “We’re here and seated”

### CONVERSATION ON 09-20-2021

**Jeff Bergosh**: Hey we’ve got McGuire’s back room reserved at 6:00’for dinner with Grandma and Boppa👍 and you all are both invited!!

**Brandon Bergosh**: Not gonna make it tonight

**Jeff Bergosh**: Sorry to hear that Brandon!!

**Jeff Bergosh**: How did your test go??

**Brandon Bergosh**: It went well

### CONVERSATION ON 09-26-2021

**Jeff Bergosh**: Congratulations!!!

**Brandon Bergosh**: That's awesome, congrats!! :)

### CONVERSATION ON 10-01-2021

**Jeff Bergosh**: Brandon— I just transferred money into your checking account.  $200 toward your October rent and $653.43 for the second half of what we owed you for your tuition payment for fall semester —- so a Total of $853.43 today.  We paid you the first half on Sept 1st.  So now we’re square with this semester’s half of tuition.  Next,  on November 1st we’ll transfer $200 for rent, on December we’ll transfer $200 for rent, and so on.

Love you— 

Dad

**Brandon Bergosh**: Loved “Brandon— I just transferred money into your checking account.  $200 toward your October rent and $653.43 for the second half of what we owed you for your tuition payment for fall semester —- so a Total of $853.43 today.  We paid you the first half on Sept 1st.  So now we’re square with this semester’s half of tuition.  Next,  on November 1st we’ll transfer $200 for rent, on December we’ll transfer $200 for rent, and so on.

Love you— 

Dad”

**Brandon Bergosh**: Awesome thx dad!

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-08-2021

**Brandon Bergosh**: Loved “We left Thursday at 10 am & we are now eating breakfast in London waiting for our flight to Denmark! Long-ass travel days! Then they had some BS rule in London that u could only have (1) sandwich plastic bag per passenger & u had to take it out of your luggage. I got it all in except hairspray & mouse. Oy Vey! We still haven’t slept but it’s an adventure! Travel now kids while you’re young!!❤️❤️”

**Brandon Bergosh**: That’s awesome, make some fun memories!

### CONVERSATION ON 10-15-2021

**Jeff Bergosh**: Hey Brandon!  Mom and I made it back safely from Denmark.  Just touching base to let you know and say Hi.  Hope all’s going well with school and work— we miss u!

Love,

Dad

**Brandon Bergosh**: Glad to hear that dad. All is well, love you too! :)

**Jeff Bergosh**: 😀👍

### CONVERSATION ON 10-20-2021

**Jeff Bergosh**: I saw it online and cracked up😂😂😂😂

**Brandon Bergosh**: Hahahah yeah someone said something at work about it😂😂😂

**Jeff Bergosh**: The video had my dying laughing

**Jeff Bergosh**: Me

**Brandon Bergosh**: Laughed at “The video had my dying laughing”

**Brandon Bergosh**: Woww

### CONVERSATION ON 10-21-2021

**Brandon Bergosh**: First day bartending!😌

**Jeff Bergosh**: That’s what I used to do!!!

**Brandon Bergosh**: Liked “That’s what I used to do!!!”

### CONVERSATION ON 10-22-2021

**Jeff Bergosh**: Hey are u bartending tonight at 5 sisters?

**Brandon Bergosh**: Nah, I’m serving a private party

**Jeff Bergosh**: When do you Barton next?

**Jeff Bergosh**: Bartend

**Brandon Bergosh**: I’m still just in the world of getting trained but I’ll lyk!

**Brandon Bergosh**: You’re in Hawaii?

### CONVERSATION ON 10-23-2021

**Brandon Bergosh**: Laughed at “That’s awesome. Make sure to stop in the ABC store for some spam masubi”

### CONVERSATION ON 10-26-2021

**Jeff Bergosh**: Thanks for picking up Tori today!!

**Brandon Bergosh**: No problem, anytime!

### CONVERSATION ON 10-28-2021

**Jeff Bergosh**: Hey Brandon I just put $200 into your checking account for our help with the November rent payment. Love you! Dad

**Brandon Bergosh**: Thanks dad! Love u

**Jeff Bergosh**: 👍

### CONVERSATION ON 10-29-2021

**Jeff Bergosh**: Brandon- I think you might have fraud on your account.  There are a bunch of repeated $40 dollar debits from your account—. A bunch of them and it adds up to a lot of cash.  You need to check your account and call NFCU if it’s fraud again like last time.  1-800-842-NFCU

Love,

Dad

**Brandon Bergosh**: Got it, thx dad 

**Jeff Bergosh**: Okay— I saw that and said “Holy Shit that’s a lot of money!!”

**Brandon Bergosh**: It’s not fraud but thanks for looking out 

**Jeff Bergosh**: Okay— as king as u know about it and it’s legit- that’s all I care about.  I just remember last time u had all those funky companies taking money out

**Brandon Bergosh**: Liked “Okay— as king as u know about it and it’s legit- that’s all I care about.  I just remember last time u had all those funky companies taking money out”

### CONVERSATION ON 10-31-2021

**Jeff Bergosh**: Hey Brandon— we’ll be barbecuing teriyaki chicken tonight with rice and veggies then passing out candy to trick or treaters.  We’d love to see you if you are not we lot king— stop by.  We love you!

Dad and mom

**Brandon Bergosh**: Aww, I would but I’ve already committed to plans… love you dad!

**Jeff Bergosh**: Love u most!

### CONVERSATION ON 11-03-2021

**Brandon Bergosh**: What are the dates that we’re gonna be outta town again?

**Jeff Bergosh**: Dec 22-28

**Jeff Bergosh**: You good on those dates?  I have your ticket 👍

**Brandon Bergosh**: Yeah I will be! Thanks dad, love you

**Jeff Bergosh**: Love u too!  When r u bartending next?

**Brandon Bergosh**: I’m training to bartend again tomorrow lunchtime

### CONVERSATION ON 11-07-2021

**Jeff Bergosh**: Hey Brandon— hope brunch went well.  I’m barbecuing Terriyaki Chicken tonight if you’d Lillie to come by.  It’s an open invitation — we’re going to eat at 6:30 so we’d love to see you if you are hungry 👍😊

**Jeff Bergosh**: Love u!


Dad

**Brandon Bergosh**: Love you too

### CONVERSATION ON 11-16-2021

**Jeff Bergosh**: Hey Brandon!  We’re having Thanksgiving at the house at 3:00 next Thursday and Mom, Tori and I hope you can come spend Thanksgiving with us.  We miss you— hope all is going well!

Love,

Dad

**Brandon Bergosh**: I’ll try & make it for sure after work!

**Jeff Bergosh**: Oh— u have to work?? — we can start later, at 4:00.  Would u be off by then?

**Brandon Bergosh**: I’m not sure how long we’ll be open, but I could just go straight there after I get off!

**Jeff Bergosh**: Right on!  We will have plenty of food!!! Mom will be really happy😊

**Brandon Bergosh**: Okay sounds good

### CONVERSATION ON 11-19-2021

**Brandon Bergosh**: Liked “Headed to Slovakia today”

### CONVERSATION ON 11-21-2021

**Jeff Bergosh**: Hey Brandon we’re making a honey baked ham for dinner if you’d like to come by and have some it’ll be ready around 6 o’clock love you!!

**Brandon Bergosh**: I’m going to fish house after work with a buddy to get food, but save me some leftovers! I’ll come by tomorrow evening to see you guys. Love ya dad :)

**Jeff Bergosh**: Right on love u too!

**Brandon Bergosh**: Loved “Right on love u too!”

### CONVERSATION ON 11-23-2021

**Jeff Bergosh**: Call them at 8:00 when they open.  They’ll get u in quick

**Brandon Bergosh**: Thx dad

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Show them this card when u get there

**Brandon Bergosh**: Ight 

**Brandon Bergosh**: I just called & left a message but they didn’t answer

**Jeff Bergosh**: Try calling them again if they don’t answer that means are on the call with someone else but they are open today

**Brandon Bergosh**: Okay

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Of course my glasses break somehow..

**Jeff Bergosh**: Go get a new pair I’ll pay for it

**Jeff Bergosh**: Do you still have your latest prescription? If not I’ll look for it I might have it

**Brandon Bergosh**: Idk but just awful timing bcuz I can’t wear my contacts rn 

**Brandon Bergosh**: Driving was difficult too cuz my eyes/eyelids are burning

**Jeff Bergosh**: Because of the pink eye

**Jeff Bergosh**: ?

**Brandon Bergosh**: Yeah I have it in both eyes

**Jeff Bergosh**: Okay We’ll see what the doc says you might just have to hold the glass is up to your face while you drive just to get your home I’ll check it on your prescription right now

**Brandon Bergosh**: Thank you

**Jeff Bergosh**: 850-479-2020

**Jeff Bergosh**: They wouldn’t give me the prescription since I’m not patient and you’re over 18 or else I would’ve done it myself

**Brandon Bergosh**: Okay

**Jeff Bergosh**: 👍

**Jeff Bergosh**: Will get it sorted out. Also I put your rent money in your checking account so you’re good to go now for that too.

**Brandon Bergosh**: Your the best, thx dad

**Jeff Bergosh**: It’s because I love you that’s why!

**Brandon Bergosh**: Loved “It’s because I love you that’s why!”

**Brandon Bergosh**: They’re gonna email my prescription to your email 

**Jeff Bergosh**: Okay then I’ll forward it to yours

**Brandon Bergosh**: Thanks

**Jeff Bergosh**: That’s the place to go for glasses quick.  

**Brandon Bergosh**: Okay ima have to go back to Publix in a few hours to pick up prescription. Have you gotten the email of my prescription yet?

**Jeff Bergosh**: Not yet— on phone with them rn

**Jeff Bergosh**: Head to opti club on Davis next—- they can get u a new pair quick

**Brandon Bergosh**: Okay perfect, will do!

**Jeff Bergosh**: U should have the prescription in your Gmail inbox

**Brandon Bergosh**: Alrighty

**Jeff Bergosh**: Have them call me for payment after u pick out your frames

**Brandon Bergosh**: Okay sounds good

**Jeff Bergosh**: This just came in my text….

**Jeff Bergosh**: That must be your eye drops ready

**Brandon Bergosh**: I just got the other prescriptions filled too so I’ll just go back to punlix after I get glasses

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Should I go to class tonight do u think? Or should I email my professor & tell him what’s going on

**Jeff Bergosh**: They’ll have it done in one hour

**Jeff Bergosh**: What time is class?

**Brandon Bergosh**: 6 pm

**Jeff Bergosh**: No you’ll be good to go by then

**Brandon Bergosh**: Okay cool

**Brandon Bergosh**: That’s the # you need to call

**Jeff Bergosh**: Already called and paid.  She’ll give u the receipt

**Jeff Bergosh**: Which I’ll need to get from u

**Brandon Bergosh**: Okay going back to Publix now. I can drop it off at home.

**Jeff Bergosh**: Thx

**Brandon Bergosh**: Just got the eye drops. About to make another trip back to eye glass store.

**Jeff Bergosh**: 👍

**Jeff Bergosh**: How’s your supply of contact lenses?

**Brandon Bergosh**: Thx for helping me through all this dad, I really appreciate it. Love you

**Brandon Bergosh**: & still good on contacts

**Jeff Bergosh**: Love u

**Brandon Bergosh**: Can’t wear them for a week tho

**Jeff Bergosh**: I may order you some more of the same type as I get toward the end of the year.  Do you like the type you’ve been using?

**Brandon Bergosh**: Yeah they’ve been great. 

**Jeff Bergosh**: 👍

**Brandon Bergosh**: I like the glasses though!

**Jeff Bergosh**: Nice!!  Can u see again??

**Brandon Bergosh**: Yeah thank goodness haha

**Jeff Bergosh**: Okay don’t break them LOL.  Keep em in the case

**Brandon Bergosh**: Will do!

**Brandon Bergosh**: I don’t think I should go to class tonight though

**Jeff Bergosh**: Why not Brandon?

**Brandon Bergosh**: Josh just said it’s highly contagious

**Brandon Bergosh**: What do you think?

**Jeff Bergosh**: Oh— okay .  We’ll make sure your professor knows then.  Love u!

**Brandon Bergosh**: Will do, love u too dad!

**Jeff Bergosh**: Love u

### CONVERSATION ON 11-24-2021

**Jeff Bergosh**: Are your eyes better today with the drops?

**Brandon Bergosh**: Still red but yeah

**Jeff Bergosh**: I got another ham for tomorrow so they’ll be plenty of leftovers when you come by!  Or Friday.  Love you!

**Brandon Bergosh**: awesome :)

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: Are u gonna make anything tonight for dinner or no?

**Jeff Bergosh**: Cooking the turkey rn

**Jeff Bergosh**: You should come by!

**Brandon Bergosh**: I might, yea

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-26-2021

**Jeff Bergosh**: Good morning Brandon!  Hope your Thanksgiving at work was busy!

We missed you— but we know u had to work.

Anyway— I just got this text, below, from Publix:

You have 2 prescriptions ready @ Publix #1343 for $2.71.  Save time. Pay now: https://rx.publix.com/7 Reply STOP to stop.

**Brandon Bergosh**: Okay cool

**Brandon Bergosh**: Thx dad!

**Jeff Bergosh**: 👍

### CONVERSATION ON 11-28-2021

**Brandon Bergosh**: I waited on a celebrity today haha

**Jeff Bergosh**: Jim Nance??

**Jeff Bergosh**: That’s cool what was he doing in Pensacola?

**Brandon Bergosh**: Yeah! & idk but cool guy

**Jeff Bergosh**: How’d u know it was him?  Did he tell u?

**Brandon Bergosh**: Yeah, I asked

**Brandon Bergosh**: I waited on Jim Nantz today, the sports commentator!

**Brandon Bergosh**: Super cool guy, he hooked me up with the tip too😌😂

**Brandon Bergosh**: Aww, I have plans but soon for sure!

### CONVERSATION ON 12-02-2021

**Brandon Bergosh**: Training behind the bar tonight! You should come by

**Jeff Bergosh**: Man I’d love too!!  I’m in a BCC mtg all night tonight

**Brandon Bergosh**: Oh alrightyy

**Jeff Bergosh**: How late will you be there working? Maybe I’ll stop by after

**Brandon Bergosh**: We close @ 8 tonight

**Jeff Bergosh**: Oops.  Well, I’ll be here till 10:00

**Brandon Bergosh**: Oh that’s tough

### CONVERSATION ON 12-03-2021

**Jeff Bergosh**: How that bartending shift go last night? Do you know how to make all the drinks yet?

**Brandon Bergosh**: fo the most part but if someone get something hard to make I could always just google

**Jeff Bergosh**: Do you like doing it?

**Brandon Bergosh**: Yeah for sure

**Jeff Bergosh**: Brandon— you got a package delivered yesterday to the house.  It is in a grey postal bag— feels like clothing of some variety. It’s at the house in my room over on the chest under the guitar hanging on the wall

**Brandon Bergosh**: Yeah I just came to get it, thanks!

**Jeff Bergosh**: Also-  I got u another year’s worth of contact lenses.  They are in my room on that chest also.  Grab those too

**Brandon Bergosh**: I’ll come back for them

**Brandon Bergosh**: Thx dad

**Jeff Bergosh**: U have to work tonight?

**Brandon Bergosh**: Yeah

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-04-2021

**Brandon Bergosh**: Loved “Came in 2nd place for my age group in the Runway 5k 👏🏼👏🏼”

**Brandon Bergosh**: Hell yeah! Congrats Tori!

### CONVERSATION ON 12-05-2021

**Brandon Bergosh**: Catch me behind the bar today!

**Jeff Bergosh**: All day?

**Brandon Bergosh**: Til we close at 4

**Brandon Bergosh**: Lotta bloodies & mimosas haha

### CONVERSATION ON 12-06-2021

**Jeff Bergosh**: Hey Brandon, mom said u are at the clinic and u got some bad news.  What’s going on— did u catch COVID?  Are u okay?  Call me and let me know okay?

### CONVERSATION ON 12-07-2021

**Jeff Bergosh**: I miss that guy!!!

**Brandon Bergosh**: Loved a movie

**Brandon Bergosh**: Aww

**Brandon Bergosh**: Our little Marley & me😢

### CONVERSATION ON 12-08-2021

**Brandon Bergosh**: I picked up my first bartending shift (not training) tonight! You should stop by after work!

**Jeff Bergosh**: I will!

**Jeff Bergosh**: What time?

**Brandon Bergosh**: I’ll get there @3 & we close at 8!

**Jeff Bergosh**: See u there!

**Brandon Bergosh**: Loved “See u there!”

**Brandon Bergosh**: Busy first solo shift haha

### CONVERSATION ON 12-09-2021

**Jeff Bergosh**: Yeah it was.  I wanted to jump in and help LOL

**Jeff Bergosh**: Hope u made some Cash$$$

**Brandon Bergosh**: I did haha

**Jeff Bergosh**: 👍

**Brandon Bergosh**: First time feeling kinda stressed in a while haha

**Jeff Bergosh**: Yeah it was busy!!

**Brandon Bergosh**: That’s good though. Best way to learn

**Jeff Bergosh**: Yes it is!

### CONVERSATION ON 12-12-2021

**Brandon Bergosh**: Congressman Matt Gaetz came into the restaurant today!

### CONVERSATION ON 12-13-2021

**Jeff Bergosh**: Wow small world.  I saw him at Church earlier in the day at Marcus Point

### CONVERSATION ON 12-14-2021

**Jeff Bergosh**: #juicerations

**Brandon Bergosh**: That’s ridiculous

**Brandon Bergosh**: Liked an image

**Jeff Bergosh**: Did u land anywhere yet Nick? Or are u still in Amsterdam?

**Brandon Bergosh**: Emphasized “Did u land anywhere yet Nick? Or are u still in Amsterdam?”

**Brandon Bergosh**: Liked “Just landed in Minneapolis! I snagged some cool pics of Greenland on the flight though ”

**Brandon Bergosh**: That’s sick

**Brandon Bergosh**: Liked “It’s all good, mom! Delta has to give me a hotel room because it was their fault ”

### CONVERSATION ON 12-16-2021

**Jeff Bergosh**: Chiefs are playing the Chargers tonight at 8:00 ET on Fox.  I might actually get to watch a full game this season!!

**Brandon Bergosh**: That’ll be a good one😌

**Jeff Bergosh**: Mom and I just got our Moderna Booster shots!

**Brandon Bergosh**: Loved an image

**Jeff Bergosh**: Brandon— mom has a few extra doses if u could get by the clinic before 8 u can get one

**Brandon Bergosh**: That’s tough :/

**Brandon Bergosh**: Loved “I about had an aneurysm when my grandma just changed the football game (on commercial) to young Sheldon…”

**Brandon Bergosh**: Laughed at “Then tried selling me on the show when I was visibly surprised lol”

### CONVERSATION ON 12-18-2021

**Jeff Bergosh**: Hey Brandon-- we are doing our Christmas gift exchange with Gary and Carissa and Alex and Ben Sunday night at 6:00 at McGuire's can u be there by 6:00?  We have to do it early as we leave Wednesday for San Diego

**Brandon Bergosh**: Okay yea sounds good!

**Jeff Bergosh**: 👍

### CONVERSATION ON 12-19-2021

**Brandon Bergosh**: Hey dad I don’t think I’m gonna make it

**Jeff Bergosh**: That’s okay— no worries!

**Brandon Bergosh**: Love you dad 

**Jeff Bergosh**: Love u too!  Don’t drink and drive B!!

**Brandon Bergosh**: Liked “Love u too!  Don’t drink and drive B!!”

### CONVERSATION ON 12-22-2021

**Brandon Bergosh**: Sweet!

**Jeff Bergosh**: Alright I have is all three “Checked-in” for tomorrow’s flight to San Diego and I have the boarding passes for all three of us.  We need to be on the road by 7:30.  I’m ordering pizza for us for dinner tonight and Brandon I’ll have the Murphy Bed all set for you to spend the night tonight.  Pizzas coming at 7:00PM.  San Diego here we come!!

**Brandon Bergosh**: Awesome

**Brandon Bergosh**: Tori isn’t going?

**Jeff Bergosh**: No- she is going to Italy instead

**Brandon Bergosh**: Oh wow haha

### CONVERSATION ON 12-23-2021

**Jeff Bergosh**: We just ordered your Irish coffee! Are you on the way back with our food?

**Brandon Bergosh**: I used the bathroom first. In line now!

**Jeff Bergosh**: All right man but your drink is on the way

**Jeff Bergosh**: 🎩🎩

**Brandon Bergosh**: What emoji is that?

**Jeff Bergosh**: Top Hat

**Brandon Bergosh**: What for 

**Jeff Bergosh**: Now do u understand????

**Brandon Bergosh**: hahahaha yea right

**Brandon Bergosh**: I AM

**Brandon Bergosh**: I’m keeping the change

**Jeff Bergosh**: U just got schooled! 

**Jeff Bergosh**: I want my change

**Jeff Bergosh**: Therefore I expect $13.85 in change

**Jeff Bergosh**: 🎩

**Brandon Bergosh**: Oh yikes

**Brandon Bergosh**: How many more drinks did u get?!

**Jeff Bergosh**: I got your Irish coffee

**Brandon Bergosh**: Mhmm, you guys took shots when I left

**Jeff Bergosh**: Where is our food?

**Brandon Bergosh**: Waiting on it, pig

**Brandon Bergosh**: Got it

**Jeff Bergosh**: We’re in cloud soup

**Brandon Bergosh**: We’re about to land

**Jeff Bergosh**: 👍

**Brandon Bergosh**: Nope

**Jeff Bergosh**: Watch close you’ll see us landing 

### CONVERSATION ON 12-26-2021

**Jeff Bergosh**: Order is in it will be a few minutes though……. These guys are slammed

**Brandon Bergosh**: No worries

**Brandon Bergosh**: Liked “Order is in it will be a few minutes though……. These guys are slammed”

### CONVERSATION ON 12-27-2021

**Brandon Bergosh**: 2 carne asada burrito orders for Nick & I please! :)

**Jeff Bergosh**: Got it!

**Jeff Bergosh**: It’s ordered

**Brandon Bergosh**: Liked “It’s ordered”

### CONVERSATION ON 12-28-2021

**Jeff Bergosh**: Let’s go Brandon we’re boarding

**Jeff Bergosh**: ?!????

**Brandon Bergosh**: Pooping

**Jeff Bergosh**: Hurry

**Brandon Bergosh**: No idea man

**Brandon Bergosh**: I’m probably due for an upgrade anyways tho

### CONVERSATION ON 12-30-2021

**Jeff Bergosh**: Hey Brandon!  We just transferred $200 into your checking account to help with January rent.  Hope u have a great day at work today and tomorrow.  At some point you need to stop by the house to get a package that arrived for you.  Looks important but We didn’t open it.  Love u!

**Brandon Bergosh**: Okay cool thx dad!

### CONVERSATION ON 01-07-2022

**Brandon Bergosh**: Loved “Free stay and wine tasting in Tuscany anyone? ”

**Brandon Bergosh**: hahaha

### CONVERSATION ON 01-09-2022

**Brandon Bergosh**: Classic

**Brandon Bergosh**: & damn, first Betty now Bob… hate to see it

**Brandon Bergosh**: Loved “We will be watching! ❤️”

**Jeff Bergosh**: Go Chargers!!! We’ll be watching tonight.   RIP. Bob Saget

**Brandon Bergosh**: Loved “Go Chargers!!! We’ll be watching tonight.   RIP. Bob Saget”

**Jeff Bergosh**: Chargers!

**Brandon Bergosh**: Loved “*Ekeler!!”

**Brandon Bergosh**: Home team refs…

**Brandon Bergosh**: I’m so exhausted from work wish I could make it, but my friends keep beating my parents to inviting me with friends🤷🏽‍♂️🙄

**Brandon Bergosh**: A friendly reminder during the day would be much appreciated though darling😋

**Brandon Bergosh**: & also I know dad is preparing for bed rn lol 

**Brandon Bergosh**: Penalties have been killing us this game though fr

**Brandon Bergosh**: Emphasized “We are making too many stupid mistakes… that was a 40 yard penalty ”

### CONVERSATION ON 01-10-2022

**Brandon Bergosh**: Dad, do you have a minute to chat?

**Jeff Bergosh**: Of course Brandon!  

**Brandon Bergosh**: Taking this semester off to save money to pay for classes in the future

**Brandon Bergosh**: Might try & pay for one to take online or something last minute

**Jeff Bergosh**: At least take a couple of classes Brandon.  What did your UWF Advisor say?

**Brandon Bergosh**: She just told me what sort of classes needed, but these classes are just so damn expensive.

### CONVERSATION ON 01-13-2022

**Jeff Bergosh**: Hey Brandon I’m wearing your Prada shades to an official event today! I really like them a lot thank you so much for giving them to me for Christmas. Also I got the number for the financial advisor I’ll forward it to you today so you can make an appointment with him and talk about investment options his name is Bob Oliff.  He’s a great guy!

**Brandon Bergosh**: Loved an image

**Brandon Bergosh**: That’s awesome dad, love you!

**Jeff Bergosh**: Love u!

**Brandon Bergosh**: Loved “Love u!”

**Brandon Bergosh**: I’m taking 2 in person classes & might end up taking an online class as well if my advisor can get me into it.

**Brandon Bergosh**: Loved “Very good Brandon!! 💕👏🏼”

**Brandon Bergosh**: Thx sis

### CONVERSATION ON 01-14-2022

**Brandon Bergosh**: Loved “I spoke at The Grand Marlin last night & guess who I met at the bar?”

**Brandon Bergosh**: That’s dope

### CONVERSATION ON 01-17-2022

**Jeff Bergosh**: Eric Weddle is playing tonight for the LA Rams!  They called him out of retirement

**Brandon Bergosh**: No way?!

### CONVERSATION ON 01-18-2022

**Brandon Bergosh**: Better opportunities out there for you. Don’t fret, you got this man🤙🏼

### CONVERSATION ON 01-21-2022

**Jeff Bergosh**: Hey Brandon!  I’ve got $200 for you to help with rent for the 1st.  Do you want me to transfer it over today or wait till the end of the month?  Your choice just let me know.  Love, Dad

**Jeff Bergosh**: Hey Brandon— did u get this?  Do u want me to wait till the 1st or do u want the $200 for rent early?

**Brandon Bergosh**: Either way works dad, thank you!! :)

**Jeff Bergosh**: No problem I’ll go ahead and put it in there rn

**Jeff Bergosh**: Have a great weekend and ai hope Schools going well

**Brandon Bergosh**: Thx dad, love you

**Brandon Bergosh**: Make pot roast Sunday night?👀

**Jeff Bergosh**: Love u too!  I can make pot roast sounds good actually!  You going to come have some with us?

**Brandon Bergosh**: Hell yea!

**Jeff Bergosh**: Right on — 6:00 Dinner Sunday!

**Brandon Bergosh**: I’ll head over right after work

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-23-2022

**Jeff Bergosh**: ???  U still at work??

**Brandon Bergosh**: Liked “Foods ready!”

**Brandon Bergosh**: I’m finna head ova

### CONVERSATION ON 01-24-2022

**Brandon Bergosh**: Anyone wanna play tennis on Wednesday?

### CONVERSATION ON 01-25-2022

**Brandon Bergosh**: Dad can u send me that info please.

**Jeff Bergosh**: I’m Bob Oliff the stock broker?

**Jeff Bergosh**: Will do

**Brandon Bergosh**: Yeah thank you!

**Brandon Bergosh**: Very cool

**Brandon Bergosh**: I need a racquet 

### CONVERSATION ON 01-26-2022

**Jeff Bergosh**: Hey Brandon I’d love to play tennis on Wednesday unfortunately I have a neighborhood watch meeting I’m speaking out from six till eight so I can’t but you can use my racket it’s at the house I left it on the bench at the dining room table on the right hand side just as you come in hopefully you and Tori can go to Roger Scott tonight play on her nice bike courts!

**Brandon Bergosh**: That would be cool. Thanks dad! Wish you could come :(

**Jeff Bergosh**: Me too— but next time!

**Brandon Bergosh**: Loved “Me too— but next time!”

**Brandon Bergosh**: Send me his info dad (oliff guy to invest) 

**Jeff Bergosh**: I will sorry just been slammed meeting after meeting—- I’m at one now

**Brandon Bergosh**: Oh okay no worries

**Brandon Bergosh**: Well we played a set & a half b4 Tori rage quitted🤷🏽‍♂️😂

**Brandon Bergosh**: 6-0 & then 3-0, me, before she got butthurt lol

**Brandon Bergosh**: Salty

**Brandon Bergosh**: One point didn’t decide that match Tori🙈😂

**Brandon Bergosh**: Mom is a work horse now bro😌

### CONVERSATION ON 01-27-2022

**Jeff Bergosh**: Bob Oliff

### CONVERSATION ON 01-29-2022

**Brandon Bergosh**: I’m behind the bar!

**Jeff Bergosh**: Right on!  What’s yours shift?

**Brandon Bergosh**: I just got off

**Jeff Bergosh**: What about tomorrow?

**Brandon Bergosh**: I work tomorrow night actually bcuz we’re open for restaurant week

**Jeff Bergosh**: 👍

### CONVERSATION ON 01-30-2022

**Brandon Bergosh**: I’m at the emergency room, busted my knee up at work & am lightheaded

**Jeff Bergosh**: What???

**Jeff Bergosh**: What’s the status Brandon?

**Brandon Bergosh**: I just got done at hospital 

**Brandon Bergosh**: Got stitches

**Brandon Bergosh**: X-ray came back & nothing broke

**Jeff Bergosh**: Thank God!! 

**Jeff Bergosh**: Do u need ride?

**Brandon Bergosh**: Yeah exactly

**Brandon Bergosh**: They didn’t ask for insurance at all

**Jeff Bergosh**: Ok good

**Brandon Bergosh**: With my friend

**Jeff Bergosh**: Can u drive though??

**Brandon Bergosh**: I’m not driving tonight but I think I should be good🤙🏼

**Jeff Bergosh**: How will I get your car?

**Jeff Bergosh**: U

**Brandon Bergosh**: I’ll figure it out

**Brandon Bergosh**: Not stressing about it

**Jeff Bergosh**: Ok call me if u need ride Brandon

**Brandon Bergosh**: No doubt popps. Love you

### CONVERSATION ON 01-31-2022

**Jeff Bergosh**: How is your leg Brandon?

**Brandon Bergosh**: I can walk

**Jeff Bergosh**: Jesus that looks horrible!!!

**Jeff Bergosh**: Dang!!

**Brandon Bergosh**: Yeah haha

**Brandon Bergosh**: Mom didn’t even ask if I was okay. All she did was give me shit

**Jeff Bergosh**: She was worried about u too like I was.  How did this happen again??? Horesplay??

**Brandon Bergosh**: Yeah

**Jeff Bergosh**: Are u in trouble at work over it?

**Brandon Bergosh**: Not at all

**Jeff Bergosh**: Good.  Love u

**Brandon Bergosh**: Ditto❤️

### CONVERSATION ON 02-01-2022

**Brandon Bergosh**: On your way home from work can u pick up my medicine from Publix?

**Jeff Bergosh**: Sure

**Jeff Bergosh**: Are you coming over to the house?

**Brandon Bergosh**: I have night class but I can after, or maybe when I wake up tomorrow

**Jeff Bergosh**: OK is it ready to be picked up and is it at the publics pharmacy right there at Pine Forest at 9 mile?

**Jeff Bergosh**: So I’ll definitely go get it and it’ll be at the house if it’s ready to be picked up I’ll have it at the house and I’ll put it on the dining room table so you can come by tonight after class if you want or tomorrow whatever works better

**Brandon Bergosh**: Okay perfect & I believe so

**Brandon Bergosh**: Took my last lexapro today.

**Jeff Bergosh**: Okay

**Jeff Bergosh**: How many are there for pickup?

**Brandon Bergosh**: Idk

**Jeff Bergosh**: I’ll check

**Brandon Bergosh**: Thankyou

