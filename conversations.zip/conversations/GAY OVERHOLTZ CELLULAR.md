

## CONVERSATIONS WITH GAY OVERHOLTZ CELLULAR

### CONVERSATION ON 11-01-2019

**Jeff Bergosh**: Hi Gaye!  Thanks again for all your support of my fundraiser! On my report I have to write what your occupation is so what should I write?

**Jeff Bergosh**: Thank you Gaye!! Good luck in the match!

